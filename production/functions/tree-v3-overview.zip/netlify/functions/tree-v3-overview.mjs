
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/tree-v3-overview.ts
import { ChannelCredentials } from "@grpc/grpc-js";
import { GrpcTransport } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient } from "@mysten/sui/grpc";

// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));
function normalizeSuiAddress(value) {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  return SUI_ADDRESS.test(normalized) ? normalized : null;
}

// netlify/lib/clmm-q64.ts
var CLMM_Q64 = 1n << 64n;
var CLMM_MIN_TICK = -443636;
var CLMM_MAX_TICK = 443636;
var NEGATIVE_TICK_FACTORS = [
  18445821805675392311n,
  18444899583751176498n,
  18443055278223354162n,
  18439367220385604838n,
  18431993317065449817n,
  18417254355718160513n,
  18387811781193591352n,
  18329067761203520168n,
  18212142134806085854n,
  17980523815641551639n,
  17526086738831147013n,
  16651378430235024244n,
  15030750278693429944n,
  12247334978882834399n,
  8131365268884822000n,
  3584323654723342297n,
  696457651847595233n,
  26294789957452057n,
  37481735321082n
];
var POSITIVE_TICK_FACTORS = [
  79232123823359799118286999567n,
  79236085330515764027303304731n,
  79244008939048815603706035061n,
  79259858533276714757314932305n,
  79291567232598584799939703904n,
  79355022692464371645785046466n,
  79482085999252804386437311141n,
  79736823300114093921829183326n,
  80248749790819932309965073892n,
  81282483887344747381513967011n,
  83390072131320151908154828281n,
  87770609709833876024991924138n,
  97234110755111693312479820773n,
  119332217159966728226237229890n,
  179736315981702064433883588727n,
  407748233172238350107850275304n,
  2098478828474011912436660412517n,
  55581415166113811149459800483533n,
  38992368544603139932233054999993551n
];
function tickToSqrtPriceQ64(tick) {
  if (!Number.isSafeInteger(tick) || tick < CLMM_MIN_TICK || tick > CLMM_MAX_TICK) {
    throw new RangeError(`CLMM tick ${tick} is outside [${CLMM_MIN_TICK}, ${CLMM_MAX_TICK}].`);
  }
  const absoluteTick = Math.abs(tick);
  if (tick < 0) {
    let ratio2 = (absoluteTick & 1) !== 0 ? NEGATIVE_TICK_FACTORS[0] : CLMM_Q64;
    for (let bit = 1; bit < NEGATIVE_TICK_FACTORS.length; bit += 1) {
      if ((absoluteTick & 1 << bit) !== 0) ratio2 = ratio2 * NEGATIVE_TICK_FACTORS[bit] >> 64n;
    }
    return ratio2;
  }
  let ratio = (absoluteTick & 1) !== 0 ? POSITIVE_TICK_FACTORS[0] : 79228162514264337593543950336n;
  for (let bit = 1; bit < POSITIVE_TICK_FACTORS.length; bit += 1) {
    if ((absoluteTick & 1 << bit) !== 0) ratio = ratio * POSITIVE_TICK_FACTORS[bit] >> 96n;
  }
  return ratio >> 32n;
}
function amountXDelta(lower, upper, liquidity) {
  if (liquidity <= 0n || lower <= 0n || upper <= lower) return 0n;
  return liquidity * (upper - lower) * CLMM_Q64 / (lower * upper);
}
function amountYDelta(lower, upper, liquidity) {
  if (liquidity <= 0n || lower <= 0n || upper <= lower) return 0n;
  return liquidity * (upper - lower) / CLMM_Q64;
}
function amountsForLiquidityQ64(currentSqrtPrice, lowerSqrtPrice, upperSqrtPrice, liquidity) {
  if (currentSqrtPrice <= 0n || lowerSqrtPrice <= 0n || upperSqrtPrice <= lowerSqrtPrice || liquidity <= 0n) {
    return { amountX: 0n, amountY: 0n };
  }
  if (currentSqrtPrice <= lowerSqrtPrice) {
    return { amountX: amountXDelta(lowerSqrtPrice, upperSqrtPrice, liquidity), amountY: 0n };
  }
  if (currentSqrtPrice >= upperSqrtPrice) {
    return { amountX: 0n, amountY: amountYDelta(lowerSqrtPrice, upperSqrtPrice, liquidity) };
  }
  return {
    amountX: amountXDelta(currentSqrtPrice, upperSqrtPrice, liquidity),
    amountY: amountYDelta(lowerSqrtPrice, currentSqrtPrice, liquidity)
  };
}

// netlify/lib/tree-v3-overview.ts
var TREE_V3_PACKAGE = "0xb5f529c1dcda6580a61bf7ee9fbd524b50be62f11044d137c8202c8cbace9e56";
var TREE_V3_POOL_ID = "0x39d5ba22e01e45bc4129ec28a0bef52e8fee8db5d07d337adf9540e3cb9074cf";
var TREE_V3_POSITION_TYPE = `${TREE_V3_PACKAGE}::position::Position`;
var SUI_COIN_TYPE = "0x2::sui::SUI";
var TREE_V3_FEE_PERCENT = 0.25;
var TREE_DECIMALS = 6;
var SUI_DECIMALS = 9;
var TREE_V3_REWARD_TOKENS = Object.freeze([
  Object.freeze({ coinType: "0xbfac5e1c6bf6ef29b12f7723857695fd2f4da9a11a7d88162c15e9124c243a4a::victory_token::VICTORY_TOKEN", symbol: "VICTORY", decimals: 6 }),
  Object.freeze({ coinType: TREE_COIN_TYPE, symbol: "TREE", decimals: TREE_DECIMALS }),
  Object.freeze({ coinType: "0xaafb102dd0902f5055cadecd687fb5b71ca82ef0e0285d90afde828ec58ca96b::btc::BTC", symbol: "wBTC", decimals: 8 })
]);
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function normalizeCoinType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  const parts = compact.split("::");
  if (parts.length !== 3 || !/^(0x)?[0-9a-f]+$/.test(parts[0]) || !parts[1] || !parts[2]) return null;
  const address = parts[0].replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${address}::${parts[1]}::${parts[2]}`;
}
function parseUnsigned(value) {
  if (typeof value === "bigint") return value >= 0n ? value : null;
  if (typeof value === "number") return Number.isSafeInteger(value) && value >= 0 ? BigInt(value) : null;
  if (typeof value !== "string" || !/^\d+$/.test(value.trim())) return null;
  try {
    return BigInt(value.trim());
  } catch {
    return null;
  }
}
function parseSignedI32(value) {
  const nested = record(value).bits;
  if (nested !== void 0) return parseSignedI32(nested);
  const numeric = typeof value === "number" ? value : typeof value === "string" && /^-?\d+$/.test(value.trim()) ? Number(value) : Number.NaN;
  if (!Number.isInteger(numeric) || numeric < -2147483648 || numeric > 4294967295) return null;
  return numeric > 2147483647 ? numeric - 4294967296 : numeric;
}
function formatRawAmount(raw, decimals, maximumFractionDigits = decimals) {
  const negative = raw < 0n;
  const value = negative ? -raw : raw;
  const scale = 10n ** BigInt(decimals);
  const whole = value / scale;
  const fraction = (value % scale).toString().padStart(decimals, "0").replace(/0+$/, "").slice(0, maximumFractionDigits);
  return `${negative ? "-" : ""}${whole.toString()}${fraction ? `.${fraction}` : ""}`;
}
function rationalToDecimal(numerator, denominator, digits = 14) {
  if (denominator <= 0n || numerator < 0n) return "0";
  const whole = numerator / denominator;
  let remainder = numerator % denominator;
  let fraction = "";
  for (let index = 0; index < digits && remainder > 0n; index += 1) {
    remainder *= 10n;
    fraction += (remainder / denominator).toString();
    remainder %= denominator;
  }
  fraction = fraction.replace(/0+$/, "");
  return `${whole.toString()}${fraction ? `.${fraction}` : ""}`;
}
function ownerAddress(node) {
  const owner = record(node.owner);
  if (owner.__typename !== "AddressOwner") return null;
  const addressValue = owner.address;
  return normalizeSuiAddress(typeof addressValue === "string" ? addressValue : record(addressValue).address);
}
var NORMALIZED_TREE = normalizeCoinType(TREE_COIN_TYPE);
var NORMALIZED_SUI = normalizeCoinType(SUI_COIN_TYPE);
function parseTreeV3Pool(jsonValue, prices) {
  const json = record(jsonValue);
  const poolId = normalizeSuiAddress(json.id);
  const tokenX = normalizeCoinType(json.type_x);
  const tokenY = normalizeCoinType(json.type_y);
  const currentTick = parseSignedI32(json.tick_index);
  const sqrtPrice = parseUnsigned(json.sqrt_price);
  const liquidity = parseUnsigned(json.liquidity);
  const reserveX = parseUnsigned(json.reserve_x);
  const reserveY = parseUnsigned(json.reserve_y);
  const tickSpacing = Number(json.tick_spacing);
  const swapFeeRate = Number(json.swap_fee_rate);
  if (poolId !== TREE_V3_POOL_ID || !tokenX || !tokenY || currentTick === null || sqrtPrice === null || sqrtPrice <= 0n || liquidity === null || reserveX === null || reserveY === null || tickSpacing !== 60 || swapFeeRate !== 2500) return null;
  const pair = /* @__PURE__ */ new Set([tokenX, tokenY]);
  if (!pair.has(NORMALIZED_TREE) || !pair.has(NORMALIZED_SUI) || pair.size !== 2) return null;
  const reserveSuiRaw = tokenX === NORMALIZED_SUI ? reserveX : reserveY;
  const reserveTreeRaw = tokenX === NORMALIZED_TREE ? reserveX : reserveY;
  const q128 = 1n << 128n;
  const rawYPerXNumerator = sqrtPrice * sqrtPrice;
  let suiPerTreeNumerator;
  let suiPerTreeDenominator;
  if (tokenX === NORMALIZED_TREE && tokenY === NORMALIZED_SUI) {
    suiPerTreeNumerator = rawYPerXNumerator * 10n ** BigInt(TREE_DECIMALS);
    suiPerTreeDenominator = q128 * 10n ** BigInt(SUI_DECIMALS);
  } else {
    suiPerTreeNumerator = q128 * 10n ** BigInt(TREE_DECIMALS);
    suiPerTreeDenominator = rawYPerXNumerator * 10n ** BigInt(SUI_DECIMALS);
  }
  if (suiPerTreeNumerator <= 0n || suiPerTreeDenominator <= 0n) return null;
  const treePerSuiNumerator = suiPerTreeDenominator;
  const treePerSuiDenominator = suiPerTreeNumerator;
  const suiUsd = Number(prices?.suiUsd);
  const treeUsd = Number(prices?.treeUsd);
  const reserveSui = Number(formatRawAmount(reserveSuiRaw, SUI_DECIMALS));
  const reserveTree = Number(formatRawAmount(reserveTreeRaw, TREE_DECIMALS));
  const tvlUsdEstimate = Number.isFinite(suiUsd) && suiUsd > 0 && Number.isFinite(treeUsd) && treeUsd > 0 ? reserveSui * suiUsd + reserveTree * treeUsd : null;
  return {
    verified: true,
    poolId,
    tokenX,
    tokenY,
    currentTick,
    sqrtPriceRaw: sqrtPrice.toString(),
    liquidityRaw: liquidity.toString(),
    reserveSuiRaw: reserveSuiRaw.toString(),
    reserveTreeRaw: reserveTreeRaw.toString(),
    reserveSui: formatRawAmount(reserveSuiRaw, SUI_DECIMALS, 6),
    reserveTree: formatRawAmount(reserveTreeRaw, TREE_DECIMALS, 2),
    priceSuiPerTree: rationalToDecimal(suiPerTreeNumerator, suiPerTreeDenominator, 12),
    priceTreePerSui: rationalToDecimal(treePerSuiNumerator, treePerSuiDenominator, 6),
    feePercent: TREE_V3_FEE_PERCENT,
    tickSpacing,
    tvlUsdEstimate: Number.isFinite(tvlUsdEstimate) ? tvlUsdEstimate : null,
    tvlSource: Number.isFinite(tvlUsdEstimate) ? "onchain-reserves-plus-coingecko" : "unavailable"
  };
}
function finiteNonNegative(value) {
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric >= 0 ? numeric : null;
}
function approximatelyEqual(left, right, absoluteTolerance = 0.1, relativeTolerance = 0.03) {
  return Math.abs(left - right) <= Math.max(absoluteTolerance, Math.max(Math.abs(left), Math.abs(right)) * relativeTolerance);
}
function parseSuiDexV3Analytics(payloadValue, pool, nowSeconds = Math.floor(Date.now() / 1e3)) {
  const payload = record(payloadValue);
  const pools = Array.isArray(payload.pools) ? payload.pools : [];
  const sourcePool = pools.map(record).find((item) => normalizeSuiAddress(item.pool_id) === pool.poolId);
  if (!sourcePool || sourcePool.approved !== true) return null;
  const tokenX = normalizeCoinType(sourcePool.token_x_type);
  const tokenY = normalizeCoinType(sourcePool.token_y_type);
  if (tokenX !== pool.tokenX || tokenY !== pool.tokenY || Number(sourcePool.fee_rate) !== 2500 || Number(sourcePool.tick_spacing) !== 60) return null;
  const tvlUsd = finiteNonNegative(sourcePool.tvl_usd);
  const volume24hUsd = finiteNonNegative(sourcePool.volume_24h_usd);
  const fees24hUsd = finiteNonNegative(sourcePool.fees_24h_usd);
  if (tvlUsd === null || tvlUsd <= 0 || volume24hUsd === null || fees24hUsd === null) return null;
  if (pool.tvlUsdEstimate !== null && !approximatelyEqual(tvlUsd, pool.tvlUsdEstimate, 1, 0.15)) return null;
  const expectedFees24h = volume24hUsd * pool.feePercent / 100;
  if (!approximatelyEqual(fees24hUsd, expectedFees24h, 0.02, 0.1)) return null;
  const tokenPrices = record(payload.tokenPrices);
  const rewards = [];
  const seenRewards = /* @__PURE__ */ new Set();
  const rewardRegistry = new Map(TREE_V3_REWARD_TOKENS.map((token) => [normalizeCoinType(token.coinType), token]));
  for (const rewardValue of Array.isArray(sourcePool.rewards) ? sourcePool.rewards : []) {
    const reward = record(rewardValue);
    const coinType = normalizeCoinType(reward.coin_type);
    const registeredReward = coinType ? rewardRegistry.get(coinType) : void 0;
    const decimals = Number(reward.decimals);
    const perDayRaw = parseUnsigned(reward.per_day);
    const priceUsd = finiteNonNegative(reward.price_usd);
    const endsAt = Number(reward.ended_at);
    if (!coinType || !registeredReward || seenRewards.has(coinType) || decimals !== registeredReward.decimals || perDayRaw === null || priceUsd === null || priceUsd <= 0 || !Number.isSafeInteger(endsAt) || endsAt <= nowSeconds) continue;
    const listedPrice = finiteNonNegative(tokenPrices[String(reward.coin_type)] ?? tokenPrices[coinType]);
    if (listedPrice === null || !approximatelyEqual(priceUsd, listedPrice, 1e-12, 0.02)) continue;
    const perDay = Number(formatRawAmount(perDayRaw, decimals));
    if (!Number.isFinite(perDay) || perDay <= 0) continue;
    const dailyUsd = perDay * priceUsd;
    const aprPercent2 = dailyUsd * 365 / tvlUsd * 100;
    seenRewards.add(coinType);
    rewards.push({
      coinType,
      symbol: registeredReward.symbol,
      decimals,
      perDayRaw: perDayRaw.toString(),
      perDay,
      priceUsd,
      dailyUsd,
      aprPercent: aprPercent2,
      endsAt: new Date(endsAt * 1e3).toISOString()
    });
  }
  const feeAprPercent = fees24hUsd * 365 / tvlUsd * 100;
  const rewardAprPercent = rewards.reduce((sum, reward) => sum + reward.aprPercent, 0);
  const aprPercent = feeAprPercent + rewardAprPercent;
  const publishedFeeApr = finiteNonNegative(sourcePool.fee_apr);
  const publishedRewardApr = finiteNonNegative(sourcePool.reward_apr);
  const publishedTotalApr = finiteNonNegative(sourcePool.total_apr);
  if (publishedFeeApr === null || publishedRewardApr === null || publishedTotalApr === null || !approximatelyEqual(feeAprPercent, publishedFeeApr) || !approximatelyEqual(rewardAprPercent, publishedRewardApr) || !approximatelyEqual(aprPercent, publishedTotalApr)) return null;
  return {
    source: "suidex-v3-pools-enriched",
    tvlUsd,
    volume24hUsd,
    fees24hUsd,
    feeAprPercent,
    rewardAprPercent,
    aprPercent,
    rewards,
    status: "verified"
  };
}
function parseTreeV3Position(nodeValue, owner, pool) {
  const node = record(nodeValue);
  const objectId = normalizeSuiAddress(node.address);
  const normalizedOwner = normalizeSuiAddress(owner);
  if (!objectId || !normalizedOwner || ownerAddress(node) !== normalizedOwner) return null;
  const json = record(record(node.contents ?? record(node.asMoveObject).contents).json);
  const poolId = normalizeSuiAddress(json.pool_id);
  const tokenX = normalizeCoinType(json.type_x);
  const tokenY = normalizeCoinType(json.type_y);
  const liquidity = parseUnsigned(json.liquidity);
  const tickLower = parseSignedI32(json.tick_lower_index);
  const tickUpper = parseSignedI32(json.tick_upper_index);
  if (poolId !== pool.poolId || tokenX !== pool.tokenX || tokenY !== pool.tokenY || liquidity === null || tickLower === null || tickUpper === null || tickLower >= tickUpper) return null;
  const owedX = parseUnsigned(json.owed_coin_x) ?? 0n;
  const owedY = parseUnsigned(json.owed_coin_y) ?? 0n;
  const feeGrowthXLast = parseUnsigned(json.fee_growth_inside_x_last);
  const feeGrowthYLast = parseUnsigned(json.fee_growth_inside_y_last);
  const rewardStates = Array.isArray(json.reward_infos) ? json.reward_infos.map((value) => {
    const reward = record(value);
    const growthInsideLast = parseUnsigned(reward.reward_growth_inside_last);
    const owed = parseUnsigned(reward.coins_owed_reward);
    return growthInsideLast === null || owed === null ? null : {
      growthInsideLastRaw: growthInsideLast.toString(),
      owedRaw: owed.toString()
    };
  }) : [];
  if (feeGrowthXLast === null || feeGrowthYLast === null || rewardStates.some((value) => value === null)) return null;
  const treeIsX = tokenX === NORMALIZED_TREE;
  return {
    objectId,
    poolId,
    liquidityRaw: liquidity.toString(),
    tickLower,
    tickUpper,
    currentTick: pool.currentTick,
    inRange: pool.currentTick >= tickLower && pool.currentTick < tickUpper,
    owedSuiRaw: (treeIsX ? owedY : owedX).toString(),
    owedTreeRaw: (treeIsX ? owedX : owedY).toString(),
    feeGrowthInsideSuiLastRaw: (treeIsX ? feeGrowthYLast : feeGrowthXLast).toString(),
    feeGrowthInsideTreeLastRaw: (treeIsX ? feeGrowthXLast : feeGrowthYLast).toString(),
    rewardStates
  };
}
function parseTreeV3PoolAccounting(jsonValue, pool) {
  const json = record(jsonValue);
  if (normalizeSuiAddress(json.id) !== pool.poolId) return null;
  const ticksTableId = normalizeSuiAddress(record(json.ticks).id);
  const feeGrowthGlobalX = parseUnsigned(json.fee_growth_global_x);
  const feeGrowthGlobalY = parseUnsigned(json.fee_growth_global_y);
  if (!ticksTableId || feeGrowthGlobalX === null || feeGrowthGlobalY === null) return null;
  const rewards = [];
  for (const value of Array.isArray(json.reward_infos) ? json.reward_infos : []) {
    const reward = record(value);
    const coinType = normalizeCoinType(reward.reward_coin_type);
    const rewardGrowthGlobal = parseUnsigned(reward.reward_growth_global);
    const rewardPerSecondX64 = parseUnsigned(reward.reward_per_seconds);
    const lastUpdateSeconds = Number(reward.last_update_time);
    const endsAtSeconds = Number(reward.ended_at_seconds);
    if (!coinType || rewardGrowthGlobal === null || rewardPerSecondX64 === null || !Number.isSafeInteger(lastUpdateSeconds) || lastUpdateSeconds < 0 || !Number.isSafeInteger(endsAtSeconds) || endsAtSeconds < 0) return null;
    rewards.push({
      coinType,
      rewardGrowthGlobalRaw: rewardGrowthGlobal.toString(),
      rewardPerSecondX64Raw: rewardPerSecondX64.toString(),
      lastUpdateSeconds,
      endsAtSeconds
    });
  }
  return {
    ticksTableId,
    feeGrowthGlobalXRaw: feeGrowthGlobalX.toString(),
    feeGrowthGlobalYRaw: feeGrowthGlobalY.toString(),
    rewards
  };
}
function parseTreeV3TickState(nameValue, valueValue) {
  const tick = parseSignedI32(nameValue);
  const value = record(valueValue);
  const feeGrowthOutsideX = parseUnsigned(value.fee_growth_outside_x);
  const feeGrowthOutsideY = parseUnsigned(value.fee_growth_outside_y);
  if (tick === null || feeGrowthOutsideX === null || feeGrowthOutsideY === null) return null;
  const rewardGrowthsOutsideRaw = [];
  for (const growthValue of Array.isArray(value.reward_growths_outside) ? value.reward_growths_outside : []) {
    const growth = parseUnsigned(growthValue);
    if (growth === null) return null;
    rewardGrowthsOutsideRaw.push(growth.toString());
  }
  return {
    tick,
    feeGrowthOutsideXRaw: feeGrowthOutsideX.toString(),
    feeGrowthOutsideYRaw: feeGrowthOutsideY.toString(),
    rewardGrowthsOutsideRaw
  };
}
var U128_MODULUS = 1n << 128n;
function subtractU128(left, right) {
  return (left - right + U128_MODULUS) % U128_MODULUS;
}
function growthInsideQ64(global, lowerOutside, upperOutside, currentTick, lowerTick, upperTick) {
  const below = currentTick >= lowerTick ? lowerOutside : subtractU128(global, lowerOutside);
  const above = currentTick < upperTick ? upperOutside : subtractU128(global, upperOutside);
  return subtractU128(subtractU128(global, below), above);
}
function amountUsd(raw, decimals, priceUsd) {
  if (priceUsd === null || !Number.isFinite(priceUsd) || priceUsd <= 0) return null;
  const amount = Number(formatRawAmount(raw, decimals));
  const value = amount * priceUsd;
  return Number.isFinite(value) && value >= 0 ? value : null;
}
function valueTreeV3Position(state, pool, accounting, tickStates, prices, nowSeconds = Math.floor(Date.now() / 1e3)) {
  const liquidity = parseUnsigned(state.liquidityRaw) ?? 0n;
  const amounts = amountsForLiquidityQ64(
    BigInt(pool.sqrtPriceRaw),
    tickToSqrtPriceQ64(state.tickLower),
    tickToSqrtPriceQ64(state.tickUpper),
    liquidity
  );
  const treeIsX = pool.tokenX === NORMALIZED_TREE;
  const principalSuiRaw = treeIsX ? amounts.amountY : amounts.amountX;
  const principalTreeRaw = treeIsX ? amounts.amountX : amounts.amountY;
  const principalSuiUsd = amountUsd(principalSuiRaw, SUI_DECIMALS, prices.suiUsd);
  const principalTreeUsd = amountUsd(principalTreeRaw, TREE_DECIMALS, prices.treeUsd);
  const base = {
    objectId: state.objectId,
    poolId: state.poolId,
    liquidityRaw: state.liquidityRaw,
    tickLower: state.tickLower,
    tickUpper: state.tickUpper,
    currentTick: state.currentTick,
    inRange: state.inRange,
    owedSuiRaw: state.owedSuiRaw,
    owedTreeRaw: state.owedTreeRaw,
    principalSuiRaw: principalSuiRaw.toString(),
    principalTreeRaw: principalTreeRaw.toString(),
    principalSui: formatRawAmount(principalSuiRaw, SUI_DECIMALS),
    principalTree: formatRawAmount(principalTreeRaw, TREE_DECIMALS),
    principalSuiUsd,
    principalTreeUsd,
    valueUsd: principalSuiUsd !== null && principalTreeUsd !== null ? principalSuiUsd + principalTreeUsd : null
  };
  const unavailable = {
    ...base,
    pendingFeeSuiRaw: null,
    pendingFeeTreeRaw: null,
    pendingFeeSui: null,
    pendingFeeTree: null,
    pendingFeesUsd: null,
    rewards: null,
    accountingStatus: "unavailable"
  };
  const lower = tickStates.get(state.tickLower);
  const upper = tickStates.get(state.tickUpper);
  if (!accounting || !lower || !upper || accounting.rewards.length !== state.rewardStates.length) return unavailable;
  const globalX = BigInt(accounting.feeGrowthGlobalXRaw);
  const globalY = BigInt(accounting.feeGrowthGlobalYRaw);
  const insideX = growthInsideQ64(globalX, BigInt(lower.feeGrowthOutsideXRaw), BigInt(upper.feeGrowthOutsideXRaw), state.currentTick, state.tickLower, state.tickUpper);
  const insideY = growthInsideQ64(globalY, BigInt(lower.feeGrowthOutsideYRaw), BigInt(upper.feeGrowthOutsideYRaw), state.currentTick, state.tickLower, state.tickUpper);
  const insideSui = treeIsX ? insideY : insideX;
  const insideTree = treeIsX ? insideX : insideY;
  const pendingFeeSuiRaw = BigInt(state.owedSuiRaw) + liquidity * subtractU128(insideSui, BigInt(state.feeGrowthInsideSuiLastRaw)) / CLMM_Q64;
  const pendingFeeTreeRaw = BigInt(state.owedTreeRaw) + liquidity * subtractU128(insideTree, BigInt(state.feeGrowthInsideTreeLastRaw)) / CLMM_Q64;
  const pendingFeeSuiUsd = amountUsd(pendingFeeSuiRaw, SUI_DECIMALS, prices.suiUsd);
  const pendingFeeTreeUsd = amountUsd(pendingFeeTreeRaw, TREE_DECIMALS, prices.treeUsd);
  const tokenRegistry = new Map(TREE_V3_REWARD_TOKENS.map((token) => [normalizeCoinType(token.coinType), token]));
  const rewards = [];
  for (let index = 0; index < accounting.rewards.length; index += 1) {
    const poolReward = accounting.rewards[index];
    const token = tokenRegistry.get(poolReward.coinType);
    if (!token) return unavailable;
    let globalGrowth = BigInt(poolReward.rewardGrowthGlobalRaw);
    const updateUntil = Math.min(nowSeconds, poolReward.endsAtSeconds);
    if (updateUntil > poolReward.lastUpdateSeconds && liquidity >= 0n) {
      const poolLiquidity = BigInt(pool.liquidityRaw);
      if (poolLiquidity <= 0n) return unavailable;
      globalGrowth += BigInt(poolReward.rewardPerSecondX64Raw) * BigInt(updateUntil - poolReward.lastUpdateSeconds) / poolLiquidity;
    }
    const lowerOutside = BigInt(lower.rewardGrowthsOutsideRaw[index] ?? "0");
    const upperOutside = BigInt(upper.rewardGrowthsOutsideRaw[index] ?? "0");
    const inside = growthInsideQ64(globalGrowth, lowerOutside, upperOutside, state.currentTick, state.tickLower, state.tickUpper);
    const positionReward = state.rewardStates[index];
    const amountRaw = BigInt(positionReward.owedRaw) + liquidity * subtractU128(inside, BigInt(positionReward.growthInsideLastRaw)) / CLMM_Q64;
    const priceUsd = prices.rewardsUsd[poolReward.coinType] ?? null;
    rewards.push({
      coinType: poolReward.coinType,
      symbol: token.symbol,
      decimals: token.decimals,
      amountRaw: amountRaw.toString(),
      amount: formatRawAmount(amountRaw, token.decimals),
      priceUsd,
      valueUsd: amountUsd(amountRaw, token.decimals, priceUsd),
      active: poolReward.endsAtSeconds > nowSeconds
    });
  }
  return {
    ...base,
    pendingFeeSuiRaw: pendingFeeSuiRaw.toString(),
    pendingFeeTreeRaw: pendingFeeTreeRaw.toString(),
    pendingFeeSui: formatRawAmount(pendingFeeSuiRaw, SUI_DECIMALS),
    pendingFeeTree: formatRawAmount(pendingFeeTreeRaw, TREE_DECIMALS),
    pendingFeesUsd: pendingFeeSuiUsd !== null && pendingFeeTreeUsd !== null ? pendingFeeSuiUsd + pendingFeeTreeUsd : null,
    rewards,
    accountingStatus: "verified"
  };
}

// netlify/functions/tree-v3-overview.ts
var GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var GRPC_HOST = "fullnode.mainnet.sui.io:443";
var MAX_POSITION_PAGES = 20;
var POSITION_PAGE_SIZE = 50;
var SUIDEX_ANALYTICS_URL = "https://dex.suidex.org/api/v3/pools-enriched";
var POSITION_SCAN_QUERY = `query ScanTreeV3Positions($owner: SuiAddress!, $first: Int!, $after: String, $type: String!) {
  address(address: $owner) {
    objects(first: $first, after: $after, filter: { type: $type }) {
      pageInfo { hasNextPage endCursor }
      nodes {
        address
        owner {
          __typename
          ... on AddressOwner { address { address } }
          ... on ObjectOwner { address { address } }
        }
        contents { json }
      }
    }
  }
}`;
var ALL_POSITION_SCAN_QUERY = `query ScanAllTreeV3Positions($first: Int!, $after: String, $type: String!) {
  objects(first: $first, after: $after, filter: { type: $type }) {
    pageInfo { hasNextPage endCursor }
    nodes {
      address
      owner {
        __typename
        ... on AddressOwner { address { address } }
        ... on ObjectOwner { address { address } }
      }
      asMoveObject { contents { json } }
    }
  }
}`;
var TICK_SCAN_QUERY = `query TreeV3Ticks($address: SuiAddress!) {
  address(address: $address) {
    dynamicFields(first: 50) {
      pageInfo { hasNextPage }
      nodes {
        name { json }
        value {
          __typename
          ... on MoveValue { json }
        }
      }
    }
  }
}`;
function response(body, status = 200, cache = "public, max-age=20, stale-while-revalidate=60") {
  return Response.json(body, {
    status,
    headers: {
      "Cache-Control": cache,
      "Content-Type": "application/json; charset=utf-8",
      "X-Content-Type-Options": "nosniff"
    }
  });
}
async function getPoolObject() {
  const client = new SuiGrpcClient({
    network: "mainnet",
    transport: new GrpcTransport({
      host: GRPC_HOST,
      channelCredentials: ChannelCredentials.createSsl()
    })
  });
  const { object } = await client.core.getObject({ objectId: TREE_V3_POOL_ID, include: { json: true } });
  return object?.json ?? null;
}
async function getReferencePrices() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 6e3);
  try {
    const url = "https://api.coingecko.com/api/v3/simple/price?ids=sui,thickquidity,bitcoin&vs_currencies=usd";
    const result = await fetch(url, { headers: { Accept: "application/json" }, signal: controller.signal });
    if (!result.ok) return { suiUsd: null, treeUsd: null, btcUsd: null };
    const payload = record(await result.json());
    return {
      suiUsd: Number(record(payload.sui).usd) || null,
      treeUsd: Number(record(payload.thickquidity).usd) || null,
      btcUsd: Number(record(payload.bitcoin).usd) || null
    };
  } catch {
    return { suiUsd: null, treeUsd: null, btcUsd: null };
  } finally {
    clearTimeout(timeout);
  }
}
async function getSuiDexAnalyticsPayload() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 9e3);
  try {
    const result = await fetch(SUIDEX_ANALYTICS_URL, { headers: { Accept: "application/json" }, signal: controller.signal });
    if (!result.ok) return null;
    return result.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}
async function getTickStates(ticksTableId) {
  const request = await fetch(GRAPHQL_URL, {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ query: TICK_SCAN_QUERY, variables: { address: ticksTableId } })
  });
  if (!request.ok) throw new Error(`Sui tick GraphQL returned HTTP ${request.status}`);
  const payload = record(await request.json());
  if (Array.isArray(payload.errors) && payload.errors.length) throw new Error("Sui tick GraphQL returned errors.");
  const dynamicFields = record(record(record(payload.data).address).dynamicFields);
  if (record(dynamicFields.pageInfo).hasNextPage === true) throw new Error("The V3 tick scan exceeded its verified bound.");
  const tickStates = /* @__PURE__ */ new Map();
  for (const nodeValue of Array.isArray(dynamicFields.nodes) ? dynamicFields.nodes : []) {
    const node = record(nodeValue);
    const value = record(node.value);
    if (value.__typename !== "MoveValue") continue;
    const tick = parseTreeV3TickState(record(node.name).json, value.json);
    if (!tick || tickStates.has(tick.tick)) throw new Error("The V3 tick table contained an invalid or duplicate tick.");
    tickStates.set(tick.tick, tick);
  }
  return tickStates;
}
function valuationPrices(prices, analyticsPayload) {
  const tokenPrices = record(record(analyticsPayload).tokenPrices);
  const finitePrice = (value) => {
    const numeric = Number(value);
    return Number.isFinite(numeric) && numeric > 0 ? numeric : null;
  };
  const rewardsUsd = {};
  for (const [key, value] of Object.entries(tokenPrices)) {
    const coinType = normalizeCoinType(key);
    const price = finitePrice(value);
    if (coinType && price !== null && TREE_V3_REWARD_TOKENS.some((token) => normalizeCoinType(token.coinType) === coinType)) rewardsUsd[coinType] = price;
  }
  const normalizedTree = normalizeCoinType(TREE_V3_REWARD_TOKENS[1].coinType);
  const normalizedBtc = normalizeCoinType(TREE_V3_REWARD_TOKENS[2].coinType);
  const treeUsd = finitePrice(prices.treeUsd) ?? rewardsUsd[normalizedTree] ?? null;
  const btcUsd = finitePrice(prices.btcUsd) ?? rewardsUsd[normalizedBtc] ?? null;
  if (treeUsd !== null) rewardsUsd[normalizedTree] = rewardsUsd[normalizedTree] ?? treeUsd;
  if (btcUsd !== null) rewardsUsd[normalizedBtc] = rewardsUsd[normalizedBtc] ?? btcUsd;
  return {
    suiUsd: finitePrice(prices.suiUsd) ?? finitePrice(tokenPrices.sui),
    treeUsd,
    rewardsUsd
  };
}
async function scanPositions(owner, pool) {
  const positions = [];
  const seen = /* @__PURE__ */ new Set();
  let after = null;
  let pagesScanned = 0;
  let objectsScanned = 0;
  let reachedEnd = false;
  for (let page = 0; page < MAX_POSITION_PAGES; page += 1) {
    const request = await fetch(GRAPHQL_URL, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({
        query: POSITION_SCAN_QUERY,
        variables: { owner, first: POSITION_PAGE_SIZE, after, type: TREE_V3_POSITION_TYPE }
      })
    });
    if (!request.ok) throw new Error(`Sui GraphQL returned HTTP ${request.status}`);
    const payload = record(await request.json());
    const errors = Array.isArray(payload.errors) ? payload.errors : [];
    if (errors.length) throw new Error(errors.map((item) => String(record(item).message || "GraphQL error")).join(" | "));
    const connection = record(record(record(payload.data).address).objects);
    const pageInfo = record(connection.pageInfo);
    const nodes = Array.isArray(connection.nodes) ? connection.nodes.filter((item) => Boolean(item && typeof item === "object")) : [];
    pagesScanned += 1;
    objectsScanned += nodes.length;
    for (const node of nodes) {
      const position = parseTreeV3Position(node, owner, pool);
      if (!position || seen.has(position.objectId)) continue;
      seen.add(position.objectId);
      positions.push(position);
    }
    if (pageInfo.hasNextPage !== true) {
      reachedEnd = true;
      break;
    }
    if (typeof pageInfo.endCursor !== "string" || !pageInfo.endCursor) break;
    after = pageInfo.endCursor;
  }
  return { positions, coverage: { pagesScanned, objectsScanned, reachedEnd, scanComplete: reachedEnd } };
}
function addressOwner(nodeValue) {
  const owner = record(record(nodeValue).owner);
  if (owner.__typename !== "AddressOwner") return null;
  const addressValue = owner.address;
  return normalizeSuiAddress(typeof addressValue === "string" ? addressValue : record(addressValue).address);
}
async function scanAllPositions(pool) {
  const seen = /* @__PURE__ */ new Set();
  let after = null;
  let pagesScanned = 0;
  let objectsScanned = 0;
  let reachedEnd = false;
  for (let page = 0; page < MAX_POSITION_PAGES; page += 1) {
    const request = await fetch(GRAPHQL_URL, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({
        query: ALL_POSITION_SCAN_QUERY,
        variables: { first: POSITION_PAGE_SIZE, after, type: TREE_V3_POSITION_TYPE }
      })
    });
    if (!request.ok) throw new Error(`Sui GraphQL returned HTTP ${request.status}`);
    const payload = record(await request.json());
    const errors = Array.isArray(payload.errors) ? payload.errors : [];
    if (errors.length) throw new Error(errors.map((item) => String(record(item).message || "GraphQL error")).join(" | "));
    const connection = record(record(payload.data).objects);
    const pageInfo = record(connection.pageInfo);
    const nodes = Array.isArray(connection.nodes) ? connection.nodes.filter((item) => Boolean(item && typeof item === "object")) : [];
    pagesScanned += 1;
    objectsScanned += nodes.length;
    for (const node of nodes) {
      const owner = addressOwner(node);
      if (!owner) continue;
      const position = parseTreeV3Position(node, owner, pool);
      if (!position || seen.has(position.objectId)) continue;
      seen.add(position.objectId);
    }
    if (pageInfo.hasNextPage !== true) {
      reachedEnd = true;
      break;
    }
    if (typeof pageInfo.endCursor !== "string" || !pageInfo.endCursor) break;
    after = pageInfo.endCursor;
  }
  return {
    positionCount: reachedEnd ? seen.size : null,
    coverage: { pagesScanned, objectsScanned, reachedEnd, scanComplete: reachedEnd }
  };
}
var tree_v3_overview_default = async (request) => {
  if (request.method !== "GET") return response({ status: "error", error: "method-not-allowed" }, 405, "no-store");
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const url = new URL(request.url);
  const ownerInput = url.searchParams.get("owner");
  const owner = ownerInput ? normalizeSuiAddress(ownerInput) : null;
  if (ownerInput && !owner) return response({ status: "error", error: "invalid-owner" }, 400, "no-store");
  try {
    const [poolObject, prices, analyticsPayload] = await Promise.all([getPoolObject(), getReferencePrices(), getSuiDexAnalyticsPayload()]);
    const pool = parseTreeV3Pool(poolObject, prices);
    if (!pool) return response({ status: "error", generatedAt, error: "pool-verification-failed" }, 503, "no-store");
    const analytics = parseSuiDexV3Analytics(analyticsPayload, pool);
    const accounting = parseTreeV3PoolAccounting(poolObject, pool);
    if (!owner) {
      const allPositionResult = await scanAllPositions(pool).catch(() => ({
        positionCount: null,
        coverage: { pagesScanned: 0, objectsScanned: 0, reachedEnd: false, scanComplete: false }
      }));
      return response({
        status: "ok",
        generatedAt,
        network: "sui-mainnet",
        provider: "sui-grpc-plus-verified-config",
        market: { ...prices, source: prices.suiUsd || prices.treeUsd ? "coingecko" : "unavailable" },
        pool,
        allPositionCount: allPositionResult.positionCount,
        allPositionCoverage: allPositionResult.coverage,
        analytics: analytics ?? {
          volume24hUsd: null,
          fees24hUsd: null,
          aprPercent: null,
          rewards: [],
          status: "not-published-without-verified-source",
          source: null
        },
        warnings: [
          ...analytics ? ["SuiDex TVL is verified against current on-chain reserves and independent USD reference prices."] : ["Pool TVL is unpublished because the SuiDex analytics and on-chain reserve cross-check did not both pass."],
          ...!analytics ? ["SuiDex volume, fee, and incentive analytics could not be independently validated."] : [],
          ...allPositionResult.positionCount === null ? ["The network-wide TREE V3 position count could not be fully verified."] : []
        ]
      });
    }
    const positionResult = await scanPositions(owner, pool);
    const tickStates = accounting ? await getTickStates(accounting.ticksTableId) : /* @__PURE__ */ new Map();
    const positionValues = positionResult.positions.map((position) => valueTreeV3Position(
      position,
      pool,
      accounting,
      tickStates,
      valuationPrices(prices, analyticsPayload),
      Math.floor(Date.now() / 1e3)
    ));
    return response({
      status: positionResult.coverage.scanComplete ? "ok" : "verification-incomplete",
      generatedAt,
      network: "sui-mainnet",
      provider: "sui-graphql-public-position-scan",
      owner,
      market: { ...prices, source: prices.suiUsd || prices.treeUsd ? "coingecko" : "unavailable" },
      pool,
      positionCount: positionValues.length,
      positions: positionResult.coverage.scanComplete ? positionValues : [],
      coverage: positionResult.coverage,
      warnings: positionResult.coverage.scanComplete ? [] : ["The public V3 position scan did not reach its natural end. Partial positions were not published."]
    }, 200, "private, no-store");
  } catch (error) {
    console.error("TREE V3 overview failed:", error);
    return response({
      status: "error",
      generatedAt,
      error: "v3-overview-unavailable",
      message: error instanceof Error ? error.message : String(error)
    }, 503, "no-store");
  }
};
var config = { path: "/api/tree-v3-overview" };
export {
  config,
  tree_v3_overview_default as default
};
