
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/leaderboard-background-worker.ts
import { createHash, randomUUID, timingSafeEqual } from "node:crypto";

// netlify/lib/leaderboard-cache.ts
import { getDeployStore, getStore } from "@netlify/blobs";

// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var TREE_DECIMALS = 6;
var TREE_TOTAL_SUPPLY_RAW = 1000000000000000n;
var METHODOLOGY_VERSION = "direct-tree-sui-graphql-poc-v2";
var SUI_GRAPHQL_PROVIDER = "sui-graphql";
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));
function tierForRank(rank) {
  if (rank <= 5) return "Ancient Grove";
  if (rank <= 10) return "Giant Sequoia";
  if (rank <= 20) return "Heritage Oak";
  if (rank <= 30) return "Canopy Guardian";
  return "Forest Keeper";
}
function normalizeSuiAddress(value) {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  return SUI_ADDRESS.test(normalized) ? normalized : null;
}
function excludedAddress(address) {
  return exclusionMap.get(address) || null;
}

// netlify/lib/leaderboard-cache.ts
var LEADERBOARD_STORE_NAME = "tree-leaderboard";
var COMPLETE_SNAPSHOT_KEY = "complete";
var REFRESH_STATUS_KEY = "refresh-status";
var REFRESH_LOCK_KEY = "refresh-lock";
var REFRESH_LOCK_TTL_MS = 20 * 60 * 1e3;
var defaultFactories = {
  getStore: (name, options) => getStore(name, options),
  getDeployStore: (name) => getDeployStore(name)
};
function selectLeaderboardStore(context, factories = defaultFactories) {
  return context === "production" ? factories.getStore(LEADERBOARD_STORE_NAME, { consistency: "strong" }) : factories.getDeployStore(LEADERBOARD_STORE_NAME);
}
function resolveStore(options) {
  return options.store ?? selectLeaderboardStore(options.context);
}
async function writeCompleteLeaderboardSnapshot(scan, options = {}) {
  const integrityValid = scan.coverage.malformedOwnerAddresses === 0 && scan.coverage.malformedBalances === 0 && scan.coverage.unknownOwnerObjectsSkipped === 0 && scan.coverage.duplicateObjectIds === 0;
  if (scan.outcome !== "complete" || !scan.coverage.scanComplete || !scan.coverage.reachedEnd || !scan.reconciliation.valid || !scan.coinMetadataVerified || !scan.coinSymbol || scan.coinSymbol.trim().toUpperCase() !== "TREE" || scan.coinDecimals !== TREE_DECIMALS || scan.totalSupplyRaw !== TREE_TOTAL_SUPPLY_RAW.toString() || !integrityValid || scan.verifiedAddressOwners === null || scan.eligibleRankedOwners === null || scan.holderCount === null) return false;
  const snapshot = {
    generatedAt: scan.generatedAt,
    provider: SUI_GRAPHQL_PROVIDER,
    methodologyVersion: METHODOLOGY_VERSION,
    coinSymbol: scan.coinSymbol,
    coinDecimals: scan.coinDecimals,
    totalSupplyRaw: scan.totalSupplyRaw,
    coinMetadataVerified: true,
    entries: scan.entries,
    verifiedAddressOwners: scan.verifiedAddressOwners,
    eligibleRankedOwners: scan.eligibleRankedOwners,
    excludedCoinObjects: scan.excludedCoinObjects,
    excludedUniqueOwners: scan.excludedUniqueOwners,
    holderCount: scan.holderCount,
    displayedCount: scan.displayedCount,
    excludedCount: scan.excludedCount,
    coverage: scan.coverage,
    reconciliation: scan.reconciliation,
    sourceCheckpoint: scan.sourceCheckpoint
  };
  await resolveStore(options).setJSON(COMPLETE_SNAPSHOT_KEY, snapshot);
  return true;
}
function sanitizeRefreshStatus(status) {
  return {
    state: status.state,
    runId: status.runId,
    startedAt: status.startedAt,
    updatedAt: status.updatedAt,
    completedAt: status.completedAt,
    coinMetadataVerified: status.coinMetadataVerified,
    coinSymbol: status.coinSymbol,
    coinDecimals: status.coinDecimals,
    totalSupplyRaw: status.totalSupplyRaw,
    pagesScanned: status.pagesScanned,
    objectsScanned: status.objectsScanned,
    addressOwnedCoinObjects: status.addressOwnedCoinObjects,
    uniqueAddressOwners: status.uniqueAddressOwners,
    excludedCoinObjects: status.excludedCoinObjects,
    excludedUniqueOwners: status.excludedUniqueOwners,
    excludedAddresses: status.excludedAddresses,
    elapsedMs: status.elapsedMs,
    hasNextPage: status.hasNextPage,
    reachedEnd: status.reachedEnd,
    scanComplete: status.scanComplete,
    message: status.message,
    commitRef: status.commitRef,
    deployId: status.deployId
  };
}
async function writeLeaderboardRefreshStatus(status, options = {}) {
  await resolveStore(options).setJSON(REFRESH_STATUS_KEY, sanitizeRefreshStatus(status));
}
async function readRefreshLock(options = {}) {
  const value = await resolveStore(options).get(REFRESH_LOCK_KEY, { type: "json" });
  return value && typeof value === "object" ? value : null;
}
async function writeRefreshLock(lock, options = {}) {
  await resolveStore(options).setJSON(REFRESH_LOCK_KEY, lock);
}
async function clearRefreshLock(runId, options = {}) {
  const store = resolveStore(options);
  const current = await readRefreshLock({ store });
  if (!current || current.runId !== runId) return false;
  await store.delete(REFRESH_LOCK_KEY);
  return true;
}

// netlify/lib/sui-graphql-background-config.ts
var DEFAULT_BACKGROUND_SUI_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var DEFAULT_BACKGROUND_PAGE_SIZE = 50;
var DEFAULT_BACKGROUND_MAX_PAGES = 5e3;
var DEFAULT_BACKGROUND_MAX_SCAN_MS = 84e4;
var DEFAULT_BACKGROUND_PROGRESS_PAGES = 25;
var DEFAULT_BACKGROUND_MAX_RETRIES = 5;
function boundedInteger(value, fallback, min, max) {
  if (typeof value !== "string" || !/^\d+$/.test(value.trim())) return fallback;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= min && parsed <= max ? parsed : fallback;
}
function endpoint(value) {
  if (!value) return DEFAULT_BACKGROUND_SUI_GRAPHQL_URL;
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:" || parsed.protocol === "http:" ? parsed.toString() : DEFAULT_BACKGROUND_SUI_GRAPHQL_URL;
  } catch {
    return DEFAULT_BACKGROUND_SUI_GRAPHQL_URL;
  }
}
function readSuiGraphqlBackgroundConfig(getEnv) {
  return {
    endpoint: endpoint(getEnv("SUI_GRAPHQL_URL")),
    pageSize: boundedInteger(getEnv("SUI_GRAPHQL_BACKGROUND_PAGE_SIZE"), DEFAULT_BACKGROUND_PAGE_SIZE, 1, 50),
    maxPages: boundedInteger(getEnv("SUI_GRAPHQL_BACKGROUND_MAX_PAGES"), DEFAULT_BACKGROUND_MAX_PAGES, 100, 1e4),
    maxScanMs: boundedInteger(getEnv("SUI_GRAPHQL_BACKGROUND_MAX_SCAN_MS"), DEFAULT_BACKGROUND_MAX_SCAN_MS, 3e4, 84e4),
    progressIntervalPages: boundedInteger(getEnv("SUI_GRAPHQL_BACKGROUND_PROGRESS_PAGES"), DEFAULT_BACKGROUND_PROGRESS_PAGES, 1, 100),
    maxRetries: boundedInteger(getEnv("SUI_GRAPHQL_BACKGROUND_MAX_RETRIES"), DEFAULT_BACKGROUND_MAX_RETRIES, 0, 10)
  };
}

// netlify/lib/sui-graphql-leaderboard-provider.ts
var DEFAULT_SUI_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var DEFAULT_PAGE_SIZE = 50;
var DEFAULT_MAX_PAGES = 40;
var DEFAULT_MAX_SCAN_MS = 8e3;
var TREE_COIN_METADATA_QUERY = `query GetTreeCoinMetadata($coinType: String!) {
  coinMetadata(coinType: $coinType) {
    name
    symbol
    decimals
    supply
  }
}`;
var TREE_COIN_OBJECTS_QUERY = `query TreeCoinObjects(
  $first: Int!
  $after: String
  $coinObjectType: String!
) {
  objects(
    first: $first
    after: $after
    filter: { type: $coinObjectType }
  ) {
    pageInfo {
      hasNextPage
      endCursor
    }
    nodes {
      address
      owner {
        __typename
        ... on AddressOwner {
          address {
            address
          }
        }
        ... on ObjectOwner {
          address {
            address
          }
        }
      }
      asMoveObject {
        contents {
          json
          balanceField: extract(path: "balance") {
            json
          }
        }
      }
    }
  }
}`;
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function boundedInteger2(value, fallback, min, max) {
  if (typeof value !== "string" || !/^\d+$/.test(value.trim())) return fallback;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= min && parsed <= max ? parsed : fallback;
}
function readSuiGraphqlConfig(getEnv = (name) => Netlify.env.get(name)) {
  const endpointValue = getEnv("SUI_GRAPHQL_URL");
  let endpoint2 = DEFAULT_SUI_GRAPHQL_URL;
  if (endpointValue) {
    try {
      const parsed = new URL(endpointValue);
      if (parsed.protocol === "https:" || parsed.protocol === "http:") endpoint2 = parsed.toString();
    } catch {
    }
  }
  return {
    endpoint: endpoint2,
    pageSize: boundedInteger2(getEnv("SUI_GRAPHQL_PAGE_SIZE"), DEFAULT_PAGE_SIZE, 1, 50),
    maxPages: boundedInteger2(getEnv("SUI_GRAPHQL_MAX_PAGES"), DEFAULT_MAX_PAGES, 1, 100),
    maxScanMs: boundedInteger2(getEnv("SUI_GRAPHQL_MAX_SCAN_MS"), DEFAULT_MAX_SCAN_MS, 1e3, 2e4)
  };
}
function parseRawBalance(value) {
  if (typeof value !== "string" || !/^\d+$/.test(value)) return null;
  try {
    return BigInt(value);
  } catch {
    return null;
  }
}
function verifyTreeCoinMetadata(value) {
  const metadata = record(value);
  const name = typeof metadata.name === "string" && metadata.name.trim() ? metadata.name : null;
  const symbol = typeof metadata.symbol === "string" ? metadata.symbol : null;
  const decimals = metadata.decimals;
  const supplyRaw = parseRawBalance(metadata.supply);
  if (!name || !symbol || symbol.trim().toUpperCase() !== "TREE" || typeof decimals !== "number" || !Number.isSafeInteger(decimals) || decimals !== TREE_DECIMALS || supplyRaw !== TREE_TOTAL_SUPPLY_RAW) return null;
  return { name, symbol, decimals, supplyRaw };
}
function formatBaseUnits(raw, coinDecimals) {
  const negative = raw < 0n;
  const absolute = negative ? -raw : raw;
  const base = 10n ** BigInt(coinDecimals);
  const whole = absolute / base;
  const fraction = (absolute % base).toString().padStart(coinDecimals, "0").replace(/0+$/, "");
  return `${negative ? "-" : ""}${whole.toString()}${fraction ? `.${fraction}` : ""}`;
}
function compareBigIntDescending(left, right) {
  return left > right ? -1 : left < right ? 1 : 0;
}
function formatPercentFromRaw(raw, total, precision = 9) {
  if (total <= 0n) return "0";
  const scale = 10n ** BigInt(precision);
  const scaled = raw * 100n * scale / total;
  return formatBaseUnits(scaled, precision);
}
function initialCoverage() {
  return {
    coinMetadataVerified: false,
    coinSymbol: null,
    coinDecimals: null,
    totalSupplyRaw: null,
    pagesScanned: 0,
    objectsScanned: 0,
    addressOwnedCoinObjects: 0,
    uniqueAddressOwners: 0,
    objectOwnedObjectsSkipped: 0,
    sharedObjectsSkipped: 0,
    immutableObjectsSkipped: 0,
    consensusOwnedObjectsSkipped: 0,
    unknownOwnerObjectsSkipped: 0,
    malformedOwnerAddresses: 0,
    malformedBalances: 0,
    excludedCoinObjects: 0,
    excludedUniqueOwners: 0,
    excludedAddresses: 0,
    duplicateObjectIds: 0,
    elapsedMs: 0,
    hasNextPage: false,
    endCursorPresent: false,
    reachedEnd: false,
    pageLimitReached: false,
    timeLimitReached: false,
    rateLimited: false,
    graphqlErrors: [],
    networkError: null,
    cursorInconsistent: false,
    requestAttempts: 0,
    retriedRequests: 0,
    rateLimitRetries: 0,
    networkRetries: 0,
    serverErrorRetries: 0,
    scanComplete: false
  };
}
function rawBalanceFromNode(node) {
  const moveObject = record(node.asMoveObject);
  const contents = record(moveObject.contents);
  const extracted = record(contents.balanceField);
  const json = record(contents.json);
  return extracted.json ?? json.balance;
}
function ownerAddress(owner) {
  const address = owner.address;
  return typeof address === "string" ? address : record(address).address;
}
function addBalance(map, wallet, raw) {
  const prior = map.get(wallet);
  map.set(wallet, prior ? { wallet, raw: prior.raw + raw, coinObjectCount: prior.coinObjectCount + 1 } : { wallet, raw, coinObjectCount: 1 });
}
function buildEntries(candidates, coinDecimals, totalSupplyRaw) {
  return [...candidates.values()].sort((left, right) => compareBigIntDescending(left.raw, right.raw) || left.wallet.localeCompare(right.wallet)).slice(0, 50).map((candidate, index) => ({
    rank: index + 1,
    wallet: candidate.wallet,
    suinsName: null,
    directTreeRaw: candidate.raw.toString(),
    directTree: formatBaseUnits(candidate.raw, coinDecimals),
    supplyPercent: formatPercentFromRaw(candidate.raw, totalSupplyRaw),
    tier: tierForRank(index + 1),
    coinObjectCount: candidate.coinObjectCount,
    moonbagsLocks: null,
    suiDexV2: null,
    suiDexV3: null,
    turbos: null,
    nftreeCount: null
  }));
}
function buildExposureCandidates(candidates) {
  return [...candidates.values()].sort((left, right) => compareBigIntDescending(left.raw, right.raw) || left.wallet.localeCompare(right.wallet)).map((candidate) => ({
    wallet: candidate.wallet,
    suinsName: null,
    directTreeRaw: candidate.raw.toString(),
    coinObjectCount: candidate.coinObjectCount
  }));
}
function reconcile(addressOwnedRaw, coinDecimals, totalSupplyRaw) {
  const valid = addressOwnedRaw <= totalSupplyRaw;
  const remainder = valid ? totalSupplyRaw - addressOwnedRaw : null;
  return {
    valid,
    totalSupplyRaw: totalSupplyRaw.toString(),
    addressOwnedRaw: addressOwnedRaw.toString(),
    addressOwnedTree: formatBaseUnits(addressOwnedRaw, coinDecimals),
    addressOwnedPercentOfTotal: formatPercentFromRaw(addressOwnedRaw, totalSupplyRaw),
    nonAddressOwnedOrEmbeddedRawEstimate: remainder?.toString() ?? null,
    nonAddressOwnedOrEmbeddedTreeEstimate: remainder === null ? null : formatBaseUnits(remainder, coinDecimals),
    nonAddressOwnedOrEmbeddedLabel: "TREE not represented by address-owned Coin<TREE> objects"
  };
}
function graphqlErrorMessages(value) {
  if (!Array.isArray(value)) return [];
  return value.map((error) => {
    const message = record(error).message;
    return typeof message === "string" && message ? message : "Unknown GraphQL error";
  });
}
async function scanSuiGraphqlLeaderboard(options = {}) {
  const defaults = readSuiGraphqlConfig(() => void 0);
  const config = {
    endpoint: options.endpoint ?? defaults.endpoint,
    pageSize: options.pageSize ?? defaults.pageSize,
    maxPages: options.maxPages ?? defaults.maxPages,
    maxScanMs: options.maxScanMs ?? defaults.maxScanMs
  };
  const fetchImpl = options.fetchImpl ?? fetch;
  const now = options.now ?? Date.now;
  const sleepImpl = options.sleepImpl ?? ((milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)));
  const randomImpl = options.randomImpl ?? Math.random;
  const progressIntervalPages = Math.max(1, Math.floor(options.progressIntervalPages ?? 1));
  const maxRetries = Math.max(0, Math.floor(options.maxRetries ?? 0));
  const startedAt = now();
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const coverage = initialCoverage();
  const seenObjectIds = /* @__PURE__ */ new Set();
  const allAddressOwners = /* @__PURE__ */ new Map();
  const rankingCandidates = /* @__PURE__ */ new Map();
  const excludedWallets = /* @__PURE__ */ new Set();
  let metadataVerificationFailed = false;
  let addressOwnedRaw = 0n;
  let after = null;
  const controller = new AbortController();
  const externalAbort = () => controller.abort();
  options.abortSignal?.addEventListener("abort", externalAbort, { once: true });
  if (options.abortSignal?.aborted) controller.abort();
  const timeout = setTimeout(() => controller.abort(), config.maxScanMs);
  const remainingMs = () => Math.max(0, config.maxScanMs - (now() - startedAt));
  const retryDelay = (retryIndex, response) => {
    const retryAfter = response?.headers.get("Retry-After");
    if (retryAfter && /^\d+(\.\d+)?$/.test(retryAfter.trim())) {
      const milliseconds = Number(retryAfter) * 1e3;
      if (Number.isFinite(milliseconds) && milliseconds >= 0 && milliseconds < remainingMs()) return milliseconds;
    }
    const base = Math.min(1e4, 1e3 * 2 ** retryIndex);
    return Math.min(1e4, base + Math.floor(base * 0.2 * Math.max(0, Math.min(1, randomImpl()))));
  };
  const waitForRetry = async (milliseconds) => {
    if (milliseconds >= remainingMs() || controller.signal.aborted) {
      coverage.timeLimitReached = true;
      return false;
    }
    await sleepImpl(milliseconds);
    if (now() - startedAt >= config.maxScanMs || controller.signal.aborted) {
      coverage.timeLimitReached = true;
      return false;
    }
    return true;
  };
  const emitProgress = async () => {
    if (!options.onProgress) return true;
    try {
      await options.onProgress({
        coinMetadataVerified: coverage.coinMetadataVerified,
        coinSymbol: coverage.coinSymbol,
        coinDecimals: coverage.coinDecimals,
        totalSupplyRaw: coverage.totalSupplyRaw,
        pagesScanned: coverage.pagesScanned,
        objectsScanned: coverage.objectsScanned,
        addressOwnedCoinObjects: coverage.addressOwnedCoinObjects,
        uniqueAddressOwners: allAddressOwners.size,
        excludedCoinObjects: coverage.excludedCoinObjects,
        excludedUniqueOwners: excludedWallets.size,
        excludedAddresses: coverage.excludedCoinObjects,
        elapsedMs: Math.max(0, now() - startedAt),
        hasNextPage: coverage.hasNextPage
      });
      return true;
    } catch {
      coverage.networkError = "Leaderboard refresh progress could not be recorded";
      return false;
    }
  };
  const requestGraphql = async (body) => {
    let response = null;
    for (let retryIndex = 0; ; retryIndex += 1) {
      coverage.requestAttempts += 1;
      try {
        response = await fetchImpl(config.endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "x-sui-rpc-show-usage": "true"
          },
          body: JSON.stringify(body),
          signal: controller.signal
        });
      } catch (error) {
        if (controller.signal.aborted || now() - startedAt >= config.maxScanMs) {
          coverage.timeLimitReached = true;
          return null;
        }
        if (retryIndex < maxRetries) {
          coverage.retriedRequests += 1;
          coverage.networkRetries += 1;
          if (!await waitForRetry(retryDelay(retryIndex))) return null;
          continue;
        }
        coverage.networkError = error instanceof Error ? error.message : "Sui GraphQL network request failed";
        return null;
      }
      const retryableStatus = response.status === 429 || [500, 502, 503, 504].includes(response.status);
      if (retryableStatus && retryIndex < maxRetries) {
        coverage.retriedRequests += 1;
        if (response.status === 429) coverage.rateLimitRetries += 1;
        else coverage.serverErrorRetries += 1;
        if (!await waitForRetry(retryDelay(retryIndex, response))) return null;
        response = null;
        continue;
      }
      if (response.status === 429) coverage.rateLimited = true;
      else if (retryableStatus) coverage.networkError = `Sui GraphQL returned HTTP ${response.status}`;
      break;
    }
    if (!response || coverage.timeLimitReached || coverage.rateLimited || coverage.networkError) return null;
    if (!response.ok) {
      coverage.networkError = `Sui GraphQL returned HTTP ${response.status}`;
      return null;
    }
    let payload;
    try {
      payload = record(await response.json());
    } catch {
      coverage.networkError = "Sui GraphQL returned an unreadable JSON response";
      return null;
    }
    const errors = graphqlErrorMessages(payload.errors);
    if (errors.length) {
      coverage.graphqlErrors.push(...errors);
      return null;
    }
    return payload;
  };
  try {
    const metadataPayload = await requestGraphql({
      query: TREE_COIN_METADATA_QUERY,
      variables: { coinType: TREE_COIN_TYPE }
    });
    const metadataValue = metadataPayload ? record(metadataPayload.data).coinMetadata : null;
    const rawMetadata = record(metadataValue);
    coverage.coinSymbol = typeof rawMetadata.symbol === "string" ? rawMetadata.symbol : null;
    coverage.coinDecimals = typeof rawMetadata.decimals === "number" && Number.isSafeInteger(rawMetadata.decimals) ? rawMetadata.decimals : null;
    coverage.totalSupplyRaw = typeof rawMetadata.supply === "string" && /^\d+$/.test(rawMetadata.supply) ? rawMetadata.supply : null;
    const verifiedMetadata = verifyTreeCoinMetadata(metadataValue);
    coverage.coinMetadataVerified = verifiedMetadata !== null;
    metadataVerificationFailed = !coverage.coinMetadataVerified;
    while (coverage.coinMetadataVerified && coverage.pagesScanned < config.maxPages) {
      if (now() - startedAt >= config.maxScanMs) {
        coverage.timeLimitReached = true;
        break;
      }
      const payload = await requestGraphql({
        query: TREE_COIN_OBJECTS_QUERY,
        variables: { first: config.pageSize, after, coinObjectType: TREE_COIN_OBJECT_TYPE }
      });
      if (!payload) break;
      const objectsValue = record(payload.data).objects;
      const objects = record(objectsValue);
      if (!objectsValue || typeof objectsValue !== "object" || !Array.isArray(objects.nodes) || !objects.pageInfo || typeof objects.pageInfo !== "object") {
        coverage.networkError = "Sui GraphQL returned an unreadable response structure";
        break;
      }
      const nodes = objects.nodes;
      const pageInfo = record(objects.pageInfo);
      coverage.pagesScanned += 1;
      coverage.objectsScanned += nodes.length;
      for (const rawNode of nodes) {
        const node = record(rawNode);
        const objectId = typeof node.address === "string" ? node.address.toLowerCase() : null;
        if (objectId && seenObjectIds.has(objectId)) {
          coverage.duplicateObjectIds += 1;
          continue;
        }
        if (objectId) seenObjectIds.add(objectId);
        const owner = record(node.owner);
        const ownerKind = typeof owner.__typename === "string" ? owner.__typename : "Unknown";
        if (ownerKind !== "AddressOwner") {
          if (ownerKind === "ObjectOwner") coverage.objectOwnedObjectsSkipped += 1;
          else if (ownerKind === "Shared" || ownerKind === "SharedOwner") coverage.sharedObjectsSkipped += 1;
          else if (ownerKind === "Immutable" || ownerKind === "ImmutableOwner") coverage.immutableObjectsSkipped += 1;
          else if (ownerKind === "ConsensusAddressOwner") coverage.consensusOwnedObjectsSkipped += 1;
          else coverage.unknownOwnerObjectsSkipped += 1;
          continue;
        }
        const wallet = normalizeSuiAddress(ownerAddress(owner));
        if (!wallet) {
          coverage.malformedOwnerAddresses += 1;
          continue;
        }
        const balance = parseRawBalance(rawBalanceFromNode(node));
        if (balance === null) {
          coverage.malformedBalances += 1;
          continue;
        }
        coverage.addressOwnedCoinObjects += 1;
        addressOwnedRaw += balance;
        addBalance(allAddressOwners, wallet, balance);
        if (excludedAddress(wallet)) {
          coverage.excludedCoinObjects += 1;
          coverage.excludedAddresses = coverage.excludedCoinObjects;
          excludedWallets.add(wallet);
          continue;
        }
        addBalance(rankingCandidates, wallet, balance);
      }
      coverage.hasNextPage = pageInfo.hasNextPage === true;
      coverage.endCursorPresent = typeof pageInfo.endCursor === "string" && pageInfo.endCursor.length > 0;
      if (!coverage.hasNextPage) {
        coverage.reachedEnd = true;
        break;
      }
      if (!coverage.endCursorPresent) {
        coverage.cursorInconsistent = true;
        break;
      }
      after = pageInfo.endCursor;
      if (now() - startedAt >= config.maxScanMs) {
        coverage.timeLimitReached = true;
        break;
      }
      if (coverage.pagesScanned % progressIntervalPages === 0 && !await emitProgress()) break;
    }
  } finally {
    clearTimeout(timeout);
    options.abortSignal?.removeEventListener("abort", externalAbort);
  }
  coverage.pageLimitReached = coverage.hasNextPage && coverage.pagesScanned >= config.maxPages && !coverage.reachedEnd;
  coverage.uniqueAddressOwners = allAddressOwners.size;
  coverage.excludedUniqueOwners = excludedWallets.size;
  coverage.elapsedMs = Math.max(0, now() - startedAt);
  await emitProgress();
  const dataIntegrityValid = coverage.malformedOwnerAddresses === 0 && coverage.malformedBalances === 0 && coverage.unknownOwnerObjectsSkipped === 0 && coverage.duplicateObjectIds === 0;
  coverage.scanComplete = coverage.coinMetadataVerified && coverage.reachedEnd && coverage.graphqlErrors.length === 0 && !coverage.networkError && !coverage.rateLimited && !coverage.pageLimitReached && !coverage.timeLimitReached && !coverage.cursorInconsistent && dataIntegrityValid;
  const verifiedCoinDecimals = coverage.coinMetadataVerified ? coverage.coinDecimals : null;
  const verifiedTotalSupplyRaw = coverage.coinMetadataVerified && coverage.totalSupplyRaw ? BigInt(coverage.totalSupplyRaw) : null;
  const reconciliation = verifiedCoinDecimals !== null && verifiedTotalSupplyRaw !== null ? reconcile(addressOwnedRaw, verifiedCoinDecimals, verifiedTotalSupplyRaw) : {
    valid: false,
    totalSupplyRaw: coverage.totalSupplyRaw ?? "",
    addressOwnedRaw: addressOwnedRaw.toString(),
    addressOwnedTree: "",
    addressOwnedPercentOfTotal: "",
    nonAddressOwnedOrEmbeddedRawEstimate: null,
    nonAddressOwnedOrEmbeddedTreeEstimate: null,
    nonAddressOwnedOrEmbeddedLabel: "TREE not represented by address-owned Coin<TREE> objects"
  };
  const complete = coverage.coinMetadataVerified && coverage.scanComplete && reconciliation.valid;
  const providerError = !metadataVerificationFailed && (coverage.graphqlErrors.length > 0 || Boolean(coverage.networkError) || coverage.rateLimited);
  const outcome = complete ? "complete" : providerError ? "error" : "verification-incomplete";
  const entries = complete && verifiedCoinDecimals !== null && verifiedTotalSupplyRaw !== null ? buildEntries(rankingCandidates, verifiedCoinDecimals, verifiedTotalSupplyRaw) : [];
  const exposureCandidates = complete && options.includeExposureCandidates ? buildExposureCandidates(rankingCandidates) : null;
  const warnings = ["Phase 2.2C measures direct address-owned TREE only, not total TREE exposure."];
  if (!coverage.coinMetadataVerified) warnings.push("TREE coin metadata could not be verified; rankings were not published.");
  if (!coverage.scanComplete) warnings.push("The Sui-native Coin<TREE> verification did not complete; partial ranks were not published.");
  if (coverage.coinMetadataVerified && !reconciliation.valid) warnings.push("Address-owned raw TREE exceeded total supply; reconciliation is invalid and ranks were not published.");
  if (coverage.rateLimited) warnings.push("The public Sui GraphQL endpoint rate-limited the scan.");
  if (coverage.graphqlErrors.length) warnings.push("Sui GraphQL returned one or more errors.");
  if (coverage.networkError) warnings.push("The Sui GraphQL request failed before verification completed.");
  if (coverage.malformedOwnerAddresses) warnings.push("Malformed address-owned wallet data prevented complete verification.");
  if (coverage.malformedBalances) warnings.push("Malformed TREE balance data prevented complete verification.");
  if (coverage.unknownOwnerObjectsSkipped) warnings.push("An unknown Sui owner variant prevented complete verification.");
  if (coverage.duplicateObjectIds) warnings.push("Duplicate Coin<TREE> object IDs prevented complete verification.");
  if (coverage.excludedCoinObjects) warnings.push(`${coverage.excludedCoinObjects} excluded protocol or system Coin<TREE> object(s) across ${excludedWallets.size} unique owner(s) were omitted from ranking.`);
  return {
    outcome,
    provider: SUI_GRAPHQL_PROVIDER,
    generatedAt,
    methodologyVersion: METHODOLOGY_VERSION,
    coverage,
    reconciliation,
    coinSymbol: coverage.coinMetadataVerified ? coverage.coinSymbol : null,
    coinDecimals: verifiedCoinDecimals,
    totalSupplyRaw: verifiedTotalSupplyRaw?.toString() ?? null,
    coinMetadataVerified: coverage.coinMetadataVerified,
    verifiedAddressOwners: complete ? allAddressOwners.size : null,
    eligibleRankedOwners: complete ? rankingCandidates.size : null,
    excludedCoinObjects: coverage.excludedCoinObjects,
    excludedUniqueOwners: coverage.excludedUniqueOwners,
    holderCount: complete ? allAddressOwners.size : null,
    displayedCount: entries.length,
    excludedCount: coverage.excludedCoinObjects,
    entries,
    exposureCandidates,
    warnings,
    sourceCheckpoint: {
      pagesScanned: coverage.pagesScanned,
      objectsScanned: coverage.objectsScanned,
      reachedEnd: coverage.reachedEnd,
      endCursorPresent: coverage.endCursorPresent
    }
  };
}

// netlify/lib/suins-name-resolver.ts
var DEFAULT_SUINS_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var MAX_SUINS_NAMES_PER_REQUEST = 50;
var MAX_SUINS_NAMES_PER_GRAPHQL_BATCH = 20;
var DEFAULT_SUINS_CONCURRENCY = 8;
function record2(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function safeName(value) {
  if (typeof value !== "string") return null;
  const name = value.trim();
  if (!name || name.length > 255 || /[\u0000-\u001f\u007f]/.test(name)) return null;
  return name;
}
function errorMessage(error) {
  return error instanceof Error ? error.message : String(error || "Unknown SuiNS resolution error");
}
function isExpectedMissingName(error) {
  const source = error && typeof error === "object" ? error : {};
  if (source.code === 5 || source.status === 5 || source.code === "NOT_FOUND" || source.status === "NOT_FOUND") return true;
  const rawMessage = errorMessage(error).toLowerCase();
  let message = rawMessage;
  try {
    message = decodeURIComponent(rawMessage.replace(/\+/g, " "));
  } catch {
  }
  return message.includes("not_found") || message.includes("not found") || message.includes("name has expired") || message.includes("name does not exist");
}
function withTimeout(promise, timeoutMs) {
  if (timeoutMs <= 0) return Promise.reject(new Error("SuiNS resolution timed out."));
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("SuiNS resolution timed out.")), timeoutMs);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}
function graphqlErrors(value) {
  if (!Array.isArray(value)) return [];
  return value.map((item) => {
    const message = record2(item).message;
    return typeof message === "string" && message ? message : "Unknown SuiNS GraphQL error";
  });
}
function buildDefaultSuinsQuery(addresses) {
  const definitions = addresses.map((_, index) => `$address${index}: SuiAddress!`).join(", ");
  const fields = addresses.map((_, index) => `name${index}: address(address: $address${index}) { defaultNameRecord { domain } }`).join("\n");
  return {
    query: `query ResolveDefaultSuinsNames(${definitions}) {
${fields}
}`,
    variables: Object.fromEntries(addresses.map((address, index) => [`address${index}`, address]))
  };
}
async function resolveWithGraphql(normalized, names, options) {
  const controller = new AbortController();
  const externalAbort = () => controller.abort();
  options.abortSignal?.addEventListener("abort", externalAbort, { once: true });
  if (options.abortSignal?.aborted) controller.abort();
  const timeout = setTimeout(() => controller.abort(), Math.max(1e3, options.timeoutMs ?? 15e3));
  let networkError = null;
  const errors = [];
  try {
    const batches = Array.from(
      { length: Math.ceil(normalized.length / MAX_SUINS_NAMES_PER_GRAPHQL_BATCH) },
      (_, index) => normalized.slice(
        index * MAX_SUINS_NAMES_PER_GRAPHQL_BATCH,
        (index + 1) * MAX_SUINS_NAMES_PER_GRAPHQL_BATCH
      )
    );
    const results = await Promise.all(batches.map(async (batch) => {
      const response = await (options.fetchImpl || fetch)(options.endpoint || DEFAULT_SUINS_GRAPHQL_URL, {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify(buildDefaultSuinsQuery(batch)),
        signal: controller.signal
      });
      if (!response.ok) return { errors: [], networkError: `SuiNS GraphQL returned HTTP ${response.status}` };
      const payload = record2(await response.json());
      const batchErrors = graphqlErrors(payload.errors);
      const data = record2(payload.data);
      batch.forEach((address, index) => {
        const nameRecord = record2(record2(data[`name${index}`]).defaultNameRecord);
        names[address] = safeName(nameRecord.domain);
      });
      return { errors: batchErrors, networkError: null };
    }));
    results.forEach((result) => {
      errors.push(...result.errors);
      networkError ||= result.networkError;
    });
  } catch (error) {
    networkError = controller.signal.aborted ? "SuiNS resolution timed out." : errorMessage(error);
  } finally {
    clearTimeout(timeout);
    options.abortSignal?.removeEventListener("abort", externalAbort);
  }
  return { errors, networkError };
}
async function resolveWithInjectedClient(normalized, names, options) {
  const now = options.now ?? Date.now;
  const client = options.client ?? options.clientFactory?.(options.endpoint || DEFAULT_SUINS_GRAPHQL_URL);
  if (!client) return { errors: ["SuiNS client is unavailable."], networkError: "SuiNS client is unavailable." };
  const deadline = now() + Math.max(1e3, options.timeoutMs ?? 15e3);
  const concurrency = Math.max(1, Math.min(16, Math.trunc(options.concurrency ?? DEFAULT_SUINS_CONCURRENCY)));
  const unexpectedErrors = [];
  let cursor = 0;
  async function worker() {
    while (cursor < normalized.length) {
      if (options.abortSignal?.aborted) {
        unexpectedErrors.push("SuiNS resolution aborted.");
        return;
      }
      const current = cursor;
      cursor += 1;
      const address = normalized[current];
      try {
        const response = await withTimeout(client.core.defaultNameServiceName({ address }), deadline - now());
        let name = safeName(response?.name);
        if (!name && client.nameService?.reverseLookupName) {
          const reverse = await withTimeout(client.nameService.reverseLookupName({ address }), deadline - now());
          name = safeName(reverse?.response?.record?.name);
        }
        names[address] = name;
      } catch (error) {
        if (isExpectedMissingName(error)) {
          names[address] = null;
          continue;
        }
        unexpectedErrors.push(errorMessage(error));
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, normalized.length) }, () => worker()));
  const errors = [...new Set(unexpectedErrors)].slice(0, 10);
  return { errors, networkError: errors[0] || null };
}
async function resolveDefaultSuinsNames(addresses, options = {}) {
  const normalized = [...new Set(addresses.map(normalizeSuiAddress).filter((value) => Boolean(value)))].slice(0, MAX_SUINS_NAMES_PER_REQUEST);
  const names = Object.fromEntries(normalized.map((address) => [address, null]));
  const now = options.now ?? Date.now;
  const generatedAt = new Date(now()).toISOString();
  if (!normalized.length) {
    return { names, requestedCount: 0, resolvedCount: 0, complete: true, graphqlErrors: [], networkError: null, generatedAt };
  }
  const result = options.client || options.clientFactory ? await resolveWithInjectedClient(normalized, names, options) : await resolveWithGraphql(normalized, names, options);
  const resolvedCount = Object.values(names).filter(Boolean).length;
  const errors = [...result.errors];
  if (normalized.length >= 10 && resolvedCount === 0 && errors.length === 0 && !result.networkError) {
    errors.push(`SuiNS reverse lookup returned zero names for ${normalized.length} addresses.`);
  }
  const uniqueErrors = [...new Set(errors)].slice(0, 10);
  const networkError = result.networkError || uniqueErrors[0] || null;
  return {
    names,
    requestedCount: normalized.length,
    resolvedCount,
    complete: !networkError && uniqueErrors.length === 0,
    graphqlErrors: uniqueErrors,
    networkError,
    generatedAt
  };
}

// netlify/lib/leaderboard-background-worker.ts
function timingSafeSecretEqual(left, right) {
  const leftDigest = createHash("sha256").update(left).digest();
  const rightDigest = createHash("sha256").update(right).digest();
  return timingSafeEqual(leftDigest, rightDigest);
}
function statusFromProgress(base, progress, updatedAt) {
  return {
    ...base,
    state: "running",
    updatedAt,
    coinMetadataVerified: progress.coinMetadataVerified,
    coinSymbol: progress.coinSymbol,
    coinDecimals: progress.coinDecimals,
    totalSupplyRaw: progress.totalSupplyRaw,
    pagesScanned: progress.pagesScanned,
    objectsScanned: progress.objectsScanned,
    addressOwnedCoinObjects: progress.addressOwnedCoinObjects,
    uniqueAddressOwners: progress.uniqueAddressOwners,
    excludedCoinObjects: progress.excludedCoinObjects,
    excludedUniqueOwners: progress.excludedUniqueOwners,
    excludedAddresses: progress.excludedAddresses,
    elapsedMs: progress.elapsedMs,
    hasNextPage: progress.hasNextPage,
    reachedEnd: false,
    scanComplete: false,
    message: "Building a complete verified TREE leaderboard snapshot."
  };
}
async function runLeaderboardBackgroundWorker(request, dependencies = {}) {
  if (request.method !== "POST") return { accepted: false, started: false, outcome: "method-not-allowed" };
  const getEnv = dependencies.getEnv ?? ((name) => Netlify.env.get(name));
  const configuredSecret = getEnv("TREE_LEADERBOARD_REFRESH_SECRET") || "";
  const requestSecret = request.headers.get("x-tree-refresh-secret") || "";
  if (!configuredSecret || !requestSecret || !timingSafeSecretEqual(configuredSecret, requestSecret)) {
    return { accepted: false, started: false, outcome: "authentication-failed" };
  }
  const now = dependencies.now ?? Date.now;
  const createRunId = dependencies.createRunId ?? randomUUID;
  const scan = dependencies.scan ?? scanSuiGraphqlLeaderboard;
  const resolveSuins = dependencies.resolveSuins ?? resolveDefaultSuinsNames;
  const logger = dependencies.logger ?? console;
  const deployContext = dependencies.deployContext || "dev";
  const storeOptions = { context: deployContext, store: dependencies.store };
  const commitRef = getEnv("COMMIT_REF") || null;
  const deployId = dependencies.deployId || getEnv("DEPLOY_ID") || null;
  const currentLock = await readRefreshLock(storeOptions);
  if (currentLock && Date.parse(currentLock.expiresAt) > now()) {
    logger.info("TREE leaderboard refresh is already active.");
    return { accepted: true, started: false, outcome: "already-active" };
  }
  const runId = createRunId();
  const startedMs = now();
  const startedAt = new Date(startedMs).toISOString();
  await writeRefreshLock({
    runId,
    startedAt,
    expiresAt: new Date(startedMs + REFRESH_LOCK_TTL_MS).toISOString(),
    commitRef,
    deployId
  }, storeOptions);
  let status = {
    state: "queued",
    runId,
    startedAt,
    updatedAt: startedAt,
    completedAt: null,
    coinMetadataVerified: false,
    coinSymbol: null,
    coinDecimals: null,
    totalSupplyRaw: null,
    pagesScanned: 0,
    objectsScanned: 0,
    addressOwnedCoinObjects: 0,
    uniqueAddressOwners: 0,
    excludedCoinObjects: 0,
    excludedUniqueOwners: 0,
    excludedAddresses: 0,
    elapsedMs: 0,
    hasNextPage: false,
    reachedEnd: false,
    scanComplete: false,
    message: "TREE leaderboard refresh queued.",
    commitRef,
    deployId
  };
  try {
    await writeLeaderboardRefreshStatus(status, storeOptions);
    status = { ...status, state: "running", updatedAt: new Date(now()).toISOString(), message: "Building a complete verified TREE leaderboard snapshot." };
    await writeLeaderboardRefreshStatus(status, storeOptions);
    const config = readSuiGraphqlBackgroundConfig(getEnv);
    const result = await scan({
      ...config,
      onProgress: async (progress) => {
        status = statusFromProgress(status, progress, new Date(now()).toISOString());
        await writeLeaderboardRefreshStatus(status, storeOptions);
      }
    });
    let snapshotResult = result;
    if (result.outcome === "complete") {
      try {
        const resolution = await resolveSuins(result.entries.map((entry) => entry.wallet));
        snapshotResult = {
          ...result,
          entries: result.entries.map((entry) => ({ ...entry, suinsName: resolution.names[entry.wallet] || null })),
          warnings: [
            ...result.warnings,
            ...!resolution.complete ? ["Some default SuiNS names could not be resolved during this refresh."] : []
          ]
        };
      } catch {
        snapshotResult = {
          ...result,
          entries: result.entries.map((entry) => ({ ...entry, suinsName: null })),
          warnings: [...result.warnings, "Default SuiNS name resolution was unavailable during this refresh."]
        };
      }
    }
    const completedAt = new Date(now()).toISOString();
    const terminalState = snapshotResult.outcome === "complete" ? "complete" : snapshotResult.outcome;
    let snapshotWritten = false;
    if (terminalState === "complete") snapshotWritten = await writeCompleteLeaderboardSnapshot(snapshotResult, storeOptions);
    const effectiveState = terminalState === "complete" && !snapshotWritten ? "verification-incomplete" : terminalState;
    status = {
      ...status,
      state: effectiveState,
      updatedAt: completedAt,
      completedAt,
      coinMetadataVerified: snapshotResult.coverage.coinMetadataVerified,
      coinSymbol: snapshotResult.coverage.coinSymbol,
      coinDecimals: snapshotResult.coverage.coinDecimals,
      totalSupplyRaw: snapshotResult.coverage.totalSupplyRaw,
      pagesScanned: snapshotResult.coverage.pagesScanned,
      objectsScanned: snapshotResult.coverage.objectsScanned,
      addressOwnedCoinObjects: snapshotResult.coverage.addressOwnedCoinObjects,
      uniqueAddressOwners: snapshotResult.coverage.uniqueAddressOwners,
      excludedCoinObjects: snapshotResult.coverage.excludedCoinObjects,
      excludedUniqueOwners: snapshotResult.coverage.excludedUniqueOwners,
      excludedAddresses: snapshotResult.coverage.excludedAddresses,
      elapsedMs: snapshotResult.coverage.elapsedMs,
      hasNextPage: snapshotResult.coverage.hasNextPage,
      reachedEnd: snapshotResult.coverage.reachedEnd,
      scanComplete: snapshotWritten,
      message: snapshotWritten ? "A complete verified TREE leaderboard snapshot is available." : effectiveState === "error" ? "The TREE leaderboard refresh failed without replacing verified rankings." : "The TREE leaderboard refresh was incomplete; verified rankings were preserved."
    };
    await writeLeaderboardRefreshStatus(status, storeOptions);
    return { accepted: true, started: true, outcome: effectiveState };
  } catch {
    const completedAt = new Date(now()).toISOString();
    status = {
      ...status,
      state: "error",
      updatedAt: completedAt,
      completedAt,
      scanComplete: false,
      message: "The TREE leaderboard refresh failed without replacing verified rankings."
    };
    try {
      await writeLeaderboardRefreshStatus(status, storeOptions);
    } catch {
    }
    logger.error("TREE leaderboard background refresh failed.");
    return { accepted: true, started: true, outcome: "error" };
  } finally {
    try {
      await clearRefreshLock(runId, storeOptions);
    } catch {
    }
  }
}

// netlify/functions/tree-leaderboard-refresh-background.ts
async function handleTreeLeaderboardBackgroundRequest(request, context, runWorker = runLeaderboardBackgroundWorker) {
  await runWorker(request, {
    deployContext: context?.deploy?.context || "dev",
    deployId: context?.deploy?.id
  });
}
var tree_leaderboard_refresh_background_default = async (request, context) => {
  await handleTreeLeaderboardBackgroundRequest(request, context);
};
export {
  tree_leaderboard_refresh_background_default as default,
  handleTreeLeaderboardBackgroundRequest
};
