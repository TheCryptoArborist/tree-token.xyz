
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/leaderboard-cache.ts
import { getDeployStore, getStore } from "@netlify/blobs";

// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var TREE_DECIMALS = 6;
var TREE_TOTAL_SUPPLY_RAW = 1000000000000000n;
var METHODOLOGY_VERSION = "direct-tree-sui-graphql-poc-v2";
var SUI_GRAPHQL_PROVIDER = "sui-graphql";
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));

// netlify/lib/leaderboard-cache.ts
var LEADERBOARD_STORE_NAME = "tree-leaderboard";
var COMPLETE_SNAPSHOT_KEY = "complete";
var REFRESH_STATUS_KEY = "refresh-status";
var REFRESH_LOCK_TTL_MS = 20 * 60 * 1e3;
var defaultFactories = {
  getStore: (name, options) => getStore(name, options),
  getDeployStore: (name) => getDeployStore(name)
};
function selectLeaderboardStore(context, factories = defaultFactories) {
  return context === "production" ? factories.getStore(LEADERBOARD_STORE_NAME, { consistency: "strong" }) : factories.getDeployStore(LEADERBOARD_STORE_NAME);
}
function resolveStore(options) {
  return options.store ?? selectLeaderboardStore(options.context);
}
async function readCompleteLeaderboardSnapshot(options = {}) {
  const value = await resolveStore(options).get(COMPLETE_SNAPSHOT_KEY, { type: "json" });
  if (!value || typeof value !== "object") return null;
  const snapshot = value;
  if (snapshot.methodologyVersion !== METHODOLOGY_VERSION || snapshot.provider !== SUI_GRAPHQL_PROVIDER || !Number.isFinite(Date.parse(snapshot.generatedAt)) || !Array.isArray(snapshot.entries) || snapshot.coinMetadataVerified !== true || typeof snapshot.coinSymbol !== "string" || snapshot.coinSymbol.trim().toUpperCase() !== "TREE" || snapshot.coinDecimals !== TREE_DECIMALS || snapshot.totalSupplyRaw !== TREE_TOTAL_SUPPLY_RAW.toString() || snapshot.coverage?.coinMetadataVerified !== true || snapshot.coverage?.coinDecimals !== TREE_DECIMALS || snapshot.coverage?.totalSupplyRaw !== TREE_TOTAL_SUPPLY_RAW.toString() || snapshot.coverage?.scanComplete !== true || snapshot.coverage?.reachedEnd !== true || snapshot.reconciliation?.valid !== true) return null;
  return snapshot;
}
async function readLeaderboardRefreshStatus(options = {}) {
  const value = await resolveStore(options).get(REFRESH_STATUS_KEY, { type: "json" });
  return value && typeof value === "object" ? value : null;
}

// netlify/lib/sui-graphql-background-config.ts
var DEFAULT_LEADERBOARD_STALE_AFTER_MS = 288e5;
function boundedInteger(value, fallback, min, max) {
  if (typeof value !== "string" || !/^\d+$/.test(value.trim())) return fallback;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= min && parsed <= max ? parsed : fallback;
}
function readLeaderboardStaleAfterMs(getEnv) {
  return boundedInteger(getEnv("TREE_LEADERBOARD_STALE_AFTER_MS"), DEFAULT_LEADERBOARD_STALE_AFTER_MS, 3e5, 864e5);
}

// netlify/lib/leaderboard-snapshot-endpoint.ts
function publicRefreshStatus(status) {
  if (!status) return null;
  return {
    state: status.state,
    startedAt: status.startedAt,
    updatedAt: status.updatedAt,
    completedAt: status.completedAt,
    coinMetadataVerified: status.coinMetadataVerified ?? false,
    coinSymbol: status.coinSymbol ?? null,
    coinDecimals: status.coinDecimals ?? null,
    totalSupplyRaw: status.totalSupplyRaw ?? null,
    pagesScanned: status.pagesScanned,
    objectsScanned: status.objectsScanned,
    addressOwnedCoinObjects: status.addressOwnedCoinObjects,
    uniqueAddressOwners: status.uniqueAddressOwners,
    excludedCoinObjects: status.excludedCoinObjects ?? status.excludedAddresses ?? 0,
    excludedUniqueOwners: status.excludedUniqueOwners ?? 0,
    excludedAddresses: status.excludedAddresses,
    elapsedMs: status.elapsedMs,
    hasNextPage: status.hasNextPage,
    reachedEnd: status.reachedEnd,
    scanComplete: status.scanComplete,
    message: status.message
  };
}
async function resolveLeaderboardSnapshotPayload(dependencies = {}) {
  const now = dependencies.now ?? Date.now;
  const getEnv = dependencies.getEnv ?? ((name) => Netlify.env.get(name));
  const context = dependencies.context || "dev";
  const readSnapshot = dependencies.readSnapshot ?? (() => readCompleteLeaderboardSnapshot({ context }));
  const readStatus = dependencies.readRefreshStatus ?? (() => readLeaderboardRefreshStatus({ context }));
  const [snapshot, storedStatus] = await Promise.all([readSnapshot(), readStatus()]);
  const refreshStatus = publicRefreshStatus(storedStatus);
  const refreshState = refreshStatus?.state ?? "idle";
  const responseGeneratedAt = new Date(now()).toISOString();
  if (!snapshot) {
    const refreshing = refreshState === "queued" || refreshState === "running";
    const message = refreshing ? "Building the first verified TREE leaderboard snapshot." : "A complete verified TREE leaderboard snapshot is not available yet.";
    return {
      status: refreshing ? "refreshing" : "not-ready",
      provider: "sui-graphql-snapshot",
      generatedAt: responseGeneratedAt,
      snapshotGeneratedAt: null,
      snapshotAgeMs: null,
      refreshState,
      refreshStatus,
      methodologyVersion: METHODOLOGY_VERSION,
      coinSymbol: refreshStatus?.coinSymbol ?? null,
      coinDecimals: refreshStatus?.coinDecimals ?? null,
      totalSupplyRaw: refreshStatus?.totalSupplyRaw ?? null,
      coinMetadataVerified: refreshStatus?.coinMetadataVerified ?? false,
      coverage: null,
      reconciliation: null,
      verifiedAddressOwners: null,
      eligibleRankedOwners: null,
      holderCount: null,
      displayedCount: 0,
      excludedCoinObjects: refreshStatus?.excludedCoinObjects ?? 0,
      excludedUniqueOwners: refreshStatus?.excludedUniqueOwners ?? 0,
      excludedCount: refreshStatus?.excludedCoinObjects ?? 0,
      entries: [],
      warnings: refreshState === "verification-incomplete" || refreshState === "error" ? ["The latest background refresh did not produce a complete verified snapshot."] : [],
      message
    };
  }
  const snapshotAgeMs = Math.max(0, now() - Date.parse(snapshot.generatedAt));
  const staleAfterMs = readLeaderboardStaleAfterMs(getEnv);
  const stale = snapshotAgeMs > staleAfterMs;
  return {
    status: stale ? "stale" : "ok",
    provider: "sui-graphql-snapshot",
    generatedAt: responseGeneratedAt,
    snapshotGeneratedAt: snapshot.generatedAt,
    snapshotAgeMs,
    refreshState,
    refreshStatus,
    methodologyVersion: snapshot.methodologyVersion,
    coinSymbol: snapshot.coinSymbol,
    coinDecimals: snapshot.coinDecimals,
    totalSupplyRaw: snapshot.totalSupplyRaw,
    coinMetadataVerified: snapshot.coinMetadataVerified,
    coverage: snapshot.coverage,
    reconciliation: snapshot.reconciliation,
    verifiedAddressOwners: snapshot.verifiedAddressOwners,
    eligibleRankedOwners: snapshot.eligibleRankedOwners,
    holderCount: snapshot.holderCount,
    displayedCount: snapshot.displayedCount,
    excludedCoinObjects: snapshot.excludedCoinObjects,
    excludedUniqueOwners: snapshot.excludedUniqueOwners,
    excludedCount: snapshot.excludedCount,
    entries: snapshot.entries,
    warnings: stale ? [`Displayed rows are from the last verified snapshot at ${snapshot.generatedAt}.`] : [],
    message: stale ? "Showing the last complete verified TREE leaderboard snapshot." : "Showing the current complete verified TREE leaderboard snapshot."
  };
}
async function createLeaderboardSnapshotResponse(request, dependencies = {}) {
  if (request.method !== "GET") {
    return Response.json({ error: "method-not-allowed" }, { status: 405, headers: { Allow: "GET", "Cache-Control": "no-store" } });
  }
  try {
    const payload = await resolveLeaderboardSnapshotPayload(dependencies);
    const cacheable = payload.status === "ok" || payload.status === "stale";
    return Response.json(payload, {
      headers: { "Cache-Control": cacheable ? "public, max-age=15, s-maxage=30, stale-while-revalidate=60" : "no-store" }
    });
  } catch {
    return Response.json({
      status: "error",
      provider: "sui-graphql-snapshot",
      generatedAt: new Date((dependencies.now ?? Date.now)()).toISOString(),
      snapshotGeneratedAt: null,
      snapshotAgeMs: null,
      refreshState: "error",
      refreshStatus: null,
      methodologyVersion: METHODOLOGY_VERSION,
      coinSymbol: null,
      coinDecimals: null,
      totalSupplyRaw: null,
      coinMetadataVerified: false,
      coverage: null,
      reconciliation: null,
      verifiedAddressOwners: null,
      eligibleRankedOwners: null,
      holderCount: null,
      displayedCount: 0,
      excludedCoinObjects: 0,
      excludedUniqueOwners: 0,
      excludedCount: 0,
      entries: [],
      warnings: ["The verified TREE leaderboard snapshot is temporarily unavailable."],
      message: "Leaderboard unavailable."
    }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}

// netlify/functions/tree-leaderboard.ts
async function handleTreeLeaderboardRequest(request, context, createResponse = createLeaderboardSnapshotResponse) {
  return createResponse(request, {
    context: context?.deploy?.context || "dev"
  });
}
var tree_leaderboard_default = async (request, context) => handleTreeLeaderboardRequest(request, context);
var config = { path: "/api/tree-leaderboard" };
export {
  config,
  tree_leaderboard_default as default,
  handleTreeLeaderboardRequest
};
