
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-badge-background-worker.ts
import { randomUUID as randomUUID2 } from "node:crypto";

// netlify/lib/leaderboard-background-worker.ts
import { createHash, randomUUID, timingSafeEqual } from "node:crypto";

// netlify/lib/leaderboard-cache.ts
import { getDeployStore, getStore } from "@netlify/blobs";

// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var TREE_DECIMALS = 6;
var TREE_TOTAL_SUPPLY_RAW = 1000000000000000n;
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));
function normalizeSuiAddress(value) {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  return SUI_ADDRESS.test(normalized) ? normalized : null;
}

// netlify/lib/leaderboard-cache.ts
var REFRESH_LOCK_TTL_MS = 20 * 60 * 1e3;

// netlify/lib/sui-graphql-leaderboard-provider.ts
function formatBaseUnits(raw, coinDecimals) {
  const negative = raw < 0n;
  const absolute = negative ? -raw : raw;
  const base = 10n ** BigInt(coinDecimals);
  const whole = absolute / base;
  const fraction = (absolute % base).toString().padStart(coinDecimals, "0").replace(/0+$/, "");
  return `${negative ? "-" : ""}${whole.toString()}${fraction ? `.${fraction}` : ""}`;
}
function formatPercentFromRaw(raw, total, precision = 9) {
  if (total <= 0n) return "0";
  const scale = 10n ** BigInt(precision);
  const scaled = raw * 100n * scale / total;
  return formatBaseUnits(scaled, precision);
}

// netlify/lib/leaderboard-background-worker.ts
function timingSafeSecretEqual(left, right) {
  const leftDigest = createHash("sha256").update(left).digest();
  const rightDigest = createHash("sha256").update(right).digest();
  return timingSafeEqual(leftDigest, rightDigest);
}

// netlify/lib/tree-exposure-cache.ts
import { getDeployStore as getDeployStore2, getStore as getStore2 } from "@netlify/blobs";

// netlify/lib/tree-exposure-types.ts
var TREE_EXPOSURE_METHODOLOGY_VERSION = "verified-tree-exposure-v1";
var LP_PROVIDER_BADGE = "lp-provider";
var LP_MAXI_BADGE = "lp-maxi";
var DIAMOND_HANDS_BADGE = "diamond-hands";
var PAPER_HANDS_BADGE = "paper-hands";
var ACCUMULATOR_BADGE = "accumulator";
var BURNED_BADGE = "burned";
function formatTreeRaw(raw) {
  return formatBaseUnits(raw, TREE_DECIMALS);
}
function formatTreeSupplyPercent(raw) {
  return formatPercentFromRaw(raw, TREE_TOTAL_SUPPLY_RAW);
}
function parseUnsignedRaw(value) {
  if (typeof value !== "string" || !/^\d+$/.test(value)) return null;
  try {
    return BigInt(value);
  } catch {
    return null;
  }
}

// netlify/lib/tree-exposure-cache.ts
var EXPOSURE_STORE_NAME = "tree-exposure";
var COMPLETE_EXPOSURE_SNAPSHOT_KEY = "complete";
var EXPOSURE_REFRESH_LOCK_TTL_MS = 30 * 60 * 1e3;
var EXPOSURE_SNAPSHOT_PROVIDER = "tree-exposure-snapshot";
var defaultFactories = {
  getStore: (name, options) => getStore2(name, options),
  getDeployStore: (name) => getDeployStore2(name)
};
function selectExposureStore(context, factories = defaultFactories) {
  return context === "production" ? factories.getStore(EXPOSURE_STORE_NAME, { consistency: "strong" }) : factories.getDeployStore(EXPOSURE_STORE_NAME);
}
function resolveStore(options) {
  return options.store ?? selectExposureStore(options.context);
}
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function safeNonNegativeInteger(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function safeGeneratedAt(value) {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}
function safeSuinsName(value) {
  return value === null || typeof value === "string" && value.trim() === value && value.length > 0 && value.length <= 255 && !/[\u0000-\u001f\u007f]/.test(value);
}
function expectedBadges(liquidRaw, lpRaw, entry) {
  const badges = [];
  if (lpRaw > 0n) badges.push(LP_PROVIDER_BADGE);
  if (lpRaw > liquidRaw && lpRaw > 0n) badges.push(LP_MAXI_BADGE);
  if (entry.activity30d !== void 0 && entry.activity30d !== null) {
    const activity = record(entry.activity30d);
    const buyRaw = parseUnsignedRaw(activity.buyTreeRaw);
    const sellRaw = parseUnsignedRaw(activity.sellTreeRaw);
    if (buyRaw === null || sellRaw === null || !safeNonNegativeInteger(activity.buyCount) || !safeNonNegativeInteger(activity.sellCount) || !safeGeneratedAt(activity.windowStart) || !safeGeneratedAt(activity.windowEnd) || activity.buyTree !== formatTreeRaw(buyRaw) || activity.sellTree !== formatTreeRaw(sellRaw)) return null;
    if (activity.sellCount === 0) badges.push(DIAMOND_HANDS_BADGE);
    if (sellRaw > buyRaw && sellRaw >= 100000000000n) badges.push(PAPER_HANDS_BADGE);
    if (activity.buyCount >= 10 && buyRaw >= 100000000000n && buyRaw > sellRaw) badges.push(ACCUMULATOR_BADGE);
  }
  if (entry.burnedTreeRaw !== void 0 && entry.burnedTreeRaw !== null) {
    const burnedRaw = parseUnsignedRaw(entry.burnedTreeRaw);
    if (burnedRaw === null || entry.burnedTree !== formatTreeRaw(burnedRaw)) return null;
    if (burnedRaw >= 500000000000n) badges.push(BURNED_BADGE);
  } else if (entry.burnedTree !== void 0 && entry.burnedTree !== null) return null;
  return badges;
}
function validateEntry(value, expectedRank) {
  const entry = record(value);
  const wallet = normalizeSuiAddress(entry.wallet);
  if (!wallet || wallet !== entry.wallet || entry.rank !== expectedRank || !safeSuinsName(entry.suinsName)) return false;
  const liquidRaw = parseUnsignedRaw(entry.liquidTreeRaw);
  const lpRaw = parseUnsignedRaw(entry.lpTreeRaw);
  const totalRaw = parseUnsignedRaw(entry.totalExposureRaw);
  const breakdown = record(entry.lpBreakdown);
  const v2Raw = parseUnsignedRaw(breakdown.suiDexV2Raw);
  const v3Raw = parseUnsignedRaw(breakdown.suiDexV3Raw);
  const turbosRaw = parseUnsignedRaw(breakdown.turbosRaw);
  if (liquidRaw === null || lpRaw === null || totalRaw === null || v2Raw === null || v3Raw === null || turbosRaw === null || totalRaw <= 0n || totalRaw > TREE_TOTAL_SUPPLY_RAW || lpRaw !== v2Raw + v3Raw + turbosRaw || totalRaw !== liquidRaw + lpRaw) return false;
  if (entry.liquidTree !== formatTreeRaw(liquidRaw) || entry.lpTree !== formatTreeRaw(lpRaw) || entry.totalExposure !== formatTreeRaw(totalRaw) || entry.supplyPercent !== formatTreeSupplyPercent(totalRaw) || breakdown.suiDexV2 !== formatTreeRaw(v2Raw) || breakdown.suiDexV3 !== formatTreeRaw(v3Raw) || breakdown.turbos !== formatTreeRaw(turbosRaw) || !safeNonNegativeInteger(entry.liquidCoinObjectCount) || !safeNonNegativeInteger(entry.lpPositionCount)) return false;
  const badges = Array.isArray(entry.badges) ? entry.badges : [];
  const expected = expectedBadges(liquidRaw, lpRaw, entry);
  if (!expected) return false;
  return badges.length === expected.length && badges.every((badge, index) => badge === expected[index]);
}
function validateSource(snapshot) {
  const source = record(snapshot.source);
  const direct = record(source.direct);
  if (direct.outcome !== "complete" || !safeNonNegativeInteger(direct.pagesScanned) || !safeNonNegativeInteger(direct.objectsScanned) || !safeNonNegativeInteger(direct.verifiedAddressOwners) || !safeNonNegativeInteger(direct.eligibleDirectOwners) || !safeNonNegativeInteger(direct.exposureCandidateCount) || direct.exposureCandidateCount !== direct.eligibleDirectOwners || parseUnsignedRaw(direct.addressOwnedRaw) === null) return false;
  const venues = record(source.venues);
  for (const venue of ["suiDexV2", "suiDexV3", "turbos"]) {
    const summary = record(venues[venue]);
    if (summary.outcome !== "complete" || !safeNonNegativeInteger(summary.walletCount) || !safeNonNegativeInteger(summary.positionCount) || parseUnsignedRaw(summary.principalTreeRaw) === null || !Array.isArray(summary.warnings) || !summary.warnings.every((warning) => typeof warning === "string") || !summary.coverage || typeof summary.coverage !== "object") return false;
  }
  const suins = record(source.suins);
  return safeNonNegativeInteger(suins.requestedCount) && safeNonNegativeInteger(suins.resolvedCount) && suins.resolvedCount <= suins.requestedCount && typeof suins.complete === "boolean" && safeGeneratedAt(suins.generatedAt) && Array.isArray(suins.warnings) && suins.warnings.every((warning) => typeof warning === "string");
}
function validateCompleteExposureSnapshot(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const snapshot = value;
  if (snapshot.outcome !== "complete" || snapshot.provider !== EXPOSURE_SNAPSHOT_PROVIDER || snapshot.methodologyVersion !== TREE_EXPOSURE_METHODOLOGY_VERSION || !safeGeneratedAt(snapshot.generatedAt) || snapshot.coinSymbol !== "TREE" || snapshot.coinDecimals !== TREE_DECIMALS || snapshot.totalSupplyRaw !== TREE_TOTAL_SUPPLY_RAW.toString() || snapshot.displayedCount !== 50 || !Array.isArray(snapshot.entries) || snapshot.entries.length !== 50 || !safeNonNegativeInteger(snapshot.eligibleOwnerCount) || snapshot.eligibleOwnerCount < 50 || snapshot.coverage?.directTreeComplete !== true || snapshot.coverage?.suiDexV2Complete !== true || snapshot.coverage?.suiDexV3Complete !== true || snapshot.coverage?.turbosComplete !== true || snapshot.coverage?.totalExposureComplete !== true || !Array.isArray(snapshot.warnings) || !snapshot.warnings.every((warning) => typeof warning === "string")) return false;
  const wallets = /* @__PURE__ */ new Set();
  let top50TotalRaw = 0n;
  let top50LiquidRaw = 0n;
  let top50LpRaw = 0n;
  let lpProvider = 0;
  let lpMaxi = 0;
  let diamondHands = 0;
  let paperHands = 0;
  let accumulator = 0;
  let burned = 0;
  let previousTotalRaw = null;
  let previousLiquidRaw = null;
  let previousWallet = null;
  for (let index = 0; index < snapshot.entries.length; index += 1) {
    const entry = snapshot.entries[index];
    if (!validateEntry(entry, index + 1) || wallets.has(entry.wallet)) return false;
    const currentTotalRaw = BigInt(entry.totalExposureRaw);
    const currentLiquidRaw = BigInt(entry.liquidTreeRaw);
    if (previousTotalRaw !== null && previousLiquidRaw !== null && previousWallet !== null) {
      if (currentTotalRaw > previousTotalRaw || currentTotalRaw === previousTotalRaw && currentLiquidRaw > previousLiquidRaw || currentTotalRaw === previousTotalRaw && currentLiquidRaw === previousLiquidRaw && entry.wallet.localeCompare(previousWallet) < 0) return false;
    }
    previousTotalRaw = currentTotalRaw;
    previousLiquidRaw = currentLiquidRaw;
    previousWallet = entry.wallet;
    wallets.add(entry.wallet);
    top50TotalRaw += currentTotalRaw;
    top50LiquidRaw += currentLiquidRaw;
    top50LpRaw += BigInt(entry.lpTreeRaw);
    if (entry.badges.includes(LP_PROVIDER_BADGE)) lpProvider += 1;
    if (entry.badges.includes(LP_MAXI_BADGE)) lpMaxi += 1;
    if (entry.badges.includes(DIAMOND_HANDS_BADGE)) diamondHands += 1;
    if (entry.badges.includes(PAPER_HANDS_BADGE)) paperHands += 1;
    if (entry.badges.includes(ACCUMULATOR_BADGE)) accumulator += 1;
    if (entry.badges.includes(BURNED_BADGE)) burned += 1;
  }
  if (top50TotalRaw > TREE_TOTAL_SUPPLY_RAW) return false;
  const summary = record(snapshot.summary);
  const badgeCounts = record(summary.badgeCounts);
  return summary.top50TotalRaw === top50TotalRaw.toString() && summary.top50LiquidRaw === top50LiquidRaw.toString() && summary.top50LpRaw === top50LpRaw.toString() && summary.rank50CutoffRaw === snapshot.entries[49].totalExposureRaw && badgeCounts.lpProvider === lpProvider && badgeCounts.lpMaxi === lpMaxi && (badgeCounts.diamondHands === void 0 || badgeCounts.diamondHands === diamondHands) && (badgeCounts.paperHands === void 0 || badgeCounts.paperHands === paperHands) && (badgeCounts.accumulator === void 0 || badgeCounts.accumulator === accumulator) && (badgeCounts.burned === void 0 || badgeCounts.burned === burned) && validateSource(snapshot);
}
async function readCompleteExposureSnapshot(options = {}) {
  const value = await resolveStore(options).get(COMPLETE_EXPOSURE_SNAPSHOT_KEY, { type: "json" });
  return validateCompleteExposureSnapshot(value) ? value : null;
}

// netlify/lib/tree-badge-cache.ts
import { getDeployStore as getDeployStore3, getStore as getStore3 } from "@netlify/blobs";

// netlify/lib/tree-badge-types.ts
var TREE_BADGE_METHODOLOGY_VERSION = "verified-tree-behavior-badges-v1";
var TREE_BADGE_SNAPSHOT_PROVIDER = "tree-badge-snapshot";
var DIAMOND_HANDS_BADGE2 = "diamond-hands";
var PAPER_HANDS_BADGE2 = "paper-hands";
var ACCUMULATOR_BADGE2 = "accumulator";
var BURNED_BADGE2 = "burned";
var BEHAVIOR_BADGE_ORDER = [
  DIAMOND_HANDS_BADGE2,
  PAPER_HANDS_BADGE2,
  ACCUMULATOR_BADGE2,
  BURNED_BADGE2
];
var TREE_ACTIVITY_WINDOW_MS = 30 * 24 * 60 * 60 * 1e3;
var TREE_ACTIVITY_MIN_VOLUME_RAW = 100000000000n;
var TREE_ACTIVITY_ACCUMULATOR_BUYS = 10;
var BURNED_BADGE_THRESHOLD_RAW = 500000000000n;
function validDate(value) {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}
function validCount(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function expectedBehaviorBadges(activity, burn) {
  const buyRaw = parseUnsignedRaw(activity.buyTreeRaw);
  const sellRaw = parseUnsignedRaw(activity.sellTreeRaw);
  const burnedRaw = parseUnsignedRaw(burn.burnedTreeRaw);
  if (buyRaw === null || sellRaw === null || burnedRaw === null || !validCount(activity.buyCount) || !validCount(activity.sellCount) || !validDate(activity.windowStart) || !validDate(activity.windowEnd) || Date.parse(activity.windowStart) >= Date.parse(activity.windowEnd) || activity.buyTree !== formatTreeRaw(buyRaw) || activity.sellTree !== formatTreeRaw(sellRaw) || burn.burnedTree !== formatTreeRaw(burnedRaw) || typeof burn.indexedThroughCheckpoint !== "string" || !/^\d+$/.test(burn.indexedThroughCheckpoint)) return null;
  const badges = [];
  if (activity.sellCount === 0) badges.push(DIAMOND_HANDS_BADGE2);
  if (sellRaw > buyRaw && sellRaw >= TREE_ACTIVITY_MIN_VOLUME_RAW) badges.push(PAPER_HANDS_BADGE2);
  if (activity.buyCount >= TREE_ACTIVITY_ACCUMULATOR_BUYS && buyRaw >= TREE_ACTIVITY_MIN_VOLUME_RAW && buyRaw > sellRaw) badges.push(ACCUMULATOR_BADGE2);
  if (burnedRaw >= BURNED_BADGE_THRESHOLD_RAW) badges.push(BURNED_BADGE2);
  return badges;
}

// netlify/lib/tree-badge-cache.ts
var TREE_BADGE_STORE_NAME = "tree-leaderboard-badges";
var COMPLETE_TREE_BADGE_SNAPSHOT_KEY = "complete";
var TREE_BADGE_REFRESH_STATUS_KEY = "refresh-status";
var TREE_BADGE_REFRESH_LOCK_KEY = "refresh-lock";
var TREE_ACTIVITY_INDEX_KEY = "activity-index";
var TREE_BURN_INDEX_KEY = "burn-index";
var TREE_BADGE_REFRESH_LOCK_TTL_MS = 30 * 60 * 1e3;
var defaultFactories2 = {
  getStore: (name, options) => getStore3(name, options),
  getDeployStore: (name) => getDeployStore3(name)
};
function selectTreeBadgeStore(context, factories = defaultFactories2) {
  return context === "production" ? factories.getStore(TREE_BADGE_STORE_NAME, { consistency: "strong" }) : factories.getDeployStore(TREE_BADGE_STORE_NAME);
}
function resolveStore2(options) {
  return options.store ?? selectTreeBadgeStore(options.context);
}
function record2(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function validDate2(value) {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}
function validNonNegativeInteger(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function validateEntry2(value, expectedRank) {
  const entry = record2(value);
  const wallet = normalizeSuiAddress(entry.wallet);
  if (!wallet || wallet !== entry.wallet || entry.rank !== expectedRank) return false;
  const activity = record2(entry.activity30d);
  const burn = record2(entry.burn);
  const expected = expectedBehaviorBadges(activity, burn);
  if (!expected || !Array.isArray(entry.badges)) return false;
  return entry.badges.length === expected.length && entry.badges.every((badge, index) => badge === expected[index]);
}
function validateCompleteTreeBadgeSnapshot(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const snapshot = value;
  if (snapshot.outcome !== "complete" || snapshot.provider !== TREE_BADGE_SNAPSHOT_PROVIDER || snapshot.methodologyVersion !== TREE_BADGE_METHODOLOGY_VERSION || !validDate2(snapshot.generatedAt) || !validDate2(snapshot.exposureSnapshotGeneratedAt) || snapshot.displayedCount !== 50 || !Array.isArray(snapshot.entries) || snapshot.entries.length !== 50 || !Array.isArray(snapshot.warnings) || !snapshot.warnings.every((warning) => typeof warning === "string")) return false;
  const wallets = /* @__PURE__ */ new Set();
  const counts = Object.fromEntries(BEHAVIOR_BADGE_ORDER.map((badge) => [badge, 0]));
  for (let index = 0; index < snapshot.entries.length; index += 1) {
    const entry = snapshot.entries[index];
    if (!validateEntry2(entry, index + 1) || wallets.has(entry.wallet)) return false;
    wallets.add(entry.wallet);
    for (const badge of entry.badges) counts[badge] += 1;
  }
  const source = record2(snapshot.source);
  const activity = record2(source.activity);
  const burns = record2(source.burns);
  if (activity.outcome !== "complete" || burns.outcome !== "complete" || !validDate2(activity.generatedAt) || !validDate2(activity.windowStart) || !validDate2(activity.windowEnd) || !validNonNegativeInteger(activity.poolCount) || !validNonNegativeInteger(activity.transactionCount) || !Array.isArray(activity.warnings) || !activity.warnings.every((warning) => typeof warning === "string") || !validDate2(burns.generatedAt) || typeof burns.indexedThroughCheckpoint !== "string" || !/^\d+$/.test(burns.indexedThroughCheckpoint) || !validNonNegativeInteger(burns.walletCount) || !Array.isArray(burns.warnings) || !burns.warnings.every((warning) => typeof warning === "string")) return false;
  const summary = record2(snapshot.summary);
  return summary.diamondHands === counts["diamond-hands"] && summary.paperHands === counts["paper-hands"] && summary.accumulator === counts.accumulator && summary.burned === counts.burned;
}
async function writeCompleteTreeBadgeSnapshot(snapshot, options = {}) {
  if (!validateCompleteTreeBadgeSnapshot(snapshot)) return false;
  await resolveStore2(options).setJSON(COMPLETE_TREE_BADGE_SNAPSHOT_KEY, snapshot);
  return true;
}
function sanitizeStatus(status) {
  return {
    state: status.state,
    stage: status.stage,
    runId: status.runId,
    startedAt: status.startedAt,
    updatedAt: status.updatedAt,
    completedAt: status.completedAt,
    exposureSnapshotGeneratedAt: status.exposureSnapshotGeneratedAt,
    activityOutcome: status.activityOutcome,
    burnOutcome: status.burnOutcome,
    displayedCount: status.displayedCount,
    message: status.message,
    commitRef: status.commitRef,
    deployId: status.deployId
  };
}
async function writeTreeBadgeRefreshStatus(status, options = {}) {
  await resolveStore2(options).setJSON(TREE_BADGE_REFRESH_STATUS_KEY, sanitizeStatus(status));
}
async function readTreeBadgeRefreshLock(options = {}) {
  const value = await resolveStore2(options).get(TREE_BADGE_REFRESH_LOCK_KEY, { type: "json" });
  return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}
async function writeTreeBadgeRefreshLock(lock, options = {}) {
  await resolveStore2(options).setJSON(TREE_BADGE_REFRESH_LOCK_KEY, lock);
}
async function clearTreeBadgeRefreshLock(runId, options = {}) {
  const store = resolveStore2(options);
  const current = await readTreeBadgeRefreshLock({ store });
  if (!current || current.runId !== runId) return false;
  await store.delete(TREE_BADGE_REFRESH_LOCK_KEY);
  return true;
}
async function readInternalBadgeValue(key, options = {}) {
  const value = await resolveStore2(options).get(key, { type: "json" });
  return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}
async function writeInternalBadgeValue(key, value, options = {}) {
  await resolveStore2(options).setJSON(key, value);
}

// netlify/lib/cetus-tree-constants.ts
var CETUS_TREE_POOL_ID = "0x2ebaff75b8745896404085babb9ef3a77ccbb6c7d3f4db31626cefff04f7f355";
var CETUS_INTEGRATE_PACKAGE = "0xae9c208cf58fd5ba36737c9ee5dcfa7f152d0fb5a5a99eebb7c881ebc2fe59e0";
var CETUS_TREE_POOL_URL = `https://app.cetus.zone/clmm?tab=deposit&poolAddress=${CETUS_TREE_POOL_ID}`;

// netlify/lib/suidex-v2-tree-lp-provider.ts
import { ChannelCredentials } from "@grpc/grpc-js";
import { GrpcTransport } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient } from "@mysten/sui/grpc";
var SUIDEX_V2_PACKAGE = "0xbfac5e1c6bf6ef29b12f7723857695fd2f4da9a11a7d88162c15e9124c243a4a";
var SUIDEX_V2_TREE_POOL_ID = "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc";
var SUI_COIN_TYPE = "0x2::sui::SUI";
var SUIDEX_V2_TREE_LP_TYPE = `${SUIDEX_V2_PACKAGE}::pair::LPCoin<${SUI_COIN_TYPE},${TREE_COIN_TYPE}>`;
var SUIDEX_V2_TREE_LP_COIN_TYPE = `0x2::coin::Coin<${SUIDEX_V2_TREE_LP_TYPE}>`;
var SUIDEX_V2_TREE_FARM_POSITION_TYPE = `${SUIDEX_V2_PACKAGE}::farm::StakingPosition<${SUIDEX_V2_TREE_LP_TYPE}>`;

// netlify/lib/suidex-v3-tree-lp-provider.ts
import { ChannelCredentials as ChannelCredentials2 } from "@grpc/grpc-js";
import { GrpcTransport as GrpcTransport2 } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient as SuiGrpcClient2 } from "@mysten/sui/grpc";

// netlify/lib/clmm-q64.ts
var CLMM_Q64 = 1n << 64n;

// netlify/lib/suidex-v3-tree-lp-provider.ts
var SUIDEX_V3_PACKAGE = "0xb5f529c1dcda6580a61bf7ee9fbd524b50be62f11044d137c8202c8cbace9e56";
var SUIDEX_V3_POSITION_TYPE = `${SUIDEX_V3_PACKAGE}::position::Position`;
function normalizeCoinType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  const parts = compact.split("::");
  if (parts.length !== 3 || !/^(0x)?[0-9a-f]+$/.test(parts[0]) || !parts[1] || !parts[2]) return null;
  const address = parts[0].replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${address}::${parts[1]}::${parts[2]}`;
}
var NORMALIZED_TREE = normalizeCoinType(TREE_COIN_TYPE);

// netlify/lib/turbos-tree-lp-provider.ts
import { ChannelCredentials as ChannelCredentials3 } from "@grpc/grpc-js";
import { GrpcTransport as GrpcTransport3 } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient as SuiGrpcClient3 } from "@mysten/sui/grpc";
var TURBOS_PACKAGE = "0x91bfbc386a41afcfd9b2533058d7e915a1d3829089cc268ff4333d54d6339ca1";
var TURBOS_POSITION_NFT_TYPE = `${TURBOS_PACKAGE}::position_nft::TurbosPositionNFT`;
var TURBOS_POSITION_TYPE = `${TURBOS_PACKAGE}::position_manager::Position`;
var TURBOS_POOL_POSITION_VALUE_TYPE = `${TURBOS_PACKAGE}::pool::Position`;
var TURBOS_TREE_POOL_IDS = [
  "0x4a8c450d393fee360fc8c2a2ed30bf6f9e4de5077024e9628cd3510e272bf490",
  "0xaa133ce1f8fd55d85b6fc87c1b3054cb717d83be477ef3635c661c21fbdfa0ee",
  "0xc327fdc9b129602e91df9bd59cf3e4a921ce5509844a3b6c8adddc5ed320636d",
  "0xd5d7d9a614327feed096a437f416aa98f440393d9ac52d97c87e6e0dd6e719bb",
  "0xe1468ece8e4d2940b30dec776eaee9b235b23458868027da871bc42817263a12"
];
function canonicalAddress(value) {
  const address = value.toLowerCase().replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${address}`;
}
function normalizeStructType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  const parts = compact.split("::");
  if (parts.length !== 3 || !/^(0x)?[0-9a-f]+$/.test(parts[0]) || !parts[1] || !parts[2]) return null;
  return `${canonicalAddress(parts[0])}::${parts[1]}::${parts[2]}`;
}
function canonicalizeMoveType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  if (!compact) return null;
  return compact.replace(/(^|[<,])((?:0x)?[0-9a-f]+)(?=::)/g, (_match, prefix, address) => `${prefix}${canonicalAddress(address)}`);
}
var NORMALIZED_TREE2 = normalizeStructType(TREE_COIN_TYPE);
var NORMALIZED_PACKAGE = canonicalAddress(TURBOS_PACKAGE);
var NORMALIZED_POSITION_TYPE = canonicalizeMoveType(TURBOS_POSITION_TYPE);
var NORMALIZED_POOL_POSITION_VALUE_TYPE = canonicalizeMoveType(TURBOS_POOL_POSITION_VALUE_TYPE);

// netlify/lib/tree-activity-index.ts
var TREE_ACTIVITY_INDEX_METHODOLOGY_VERSION = "sui-native-tree-trade-ledger-v4";
var SUIDEX_V3_TREE_POOL_ID = "0x39d5ba22e01e45bc4129ec28a0bef52e8fee8db5d07d337adf9540e3cb9074cf";
var TURBOS_SWAP_PACKAGE = "0x626c8509478fe57ddf69e4141080b062911063f541c55cd0e8d602c6a0874573";
var TURBOS_POSITION_MANAGER_PACKAGE = "0xa5a0c25c79e428eba04fb98b3fb2a34db45ab26d4c8faf0d7e39d66a63891e64";
var DEFAULT_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var DEFAULT_PAGE_SIZE = 50;
var DEFAULT_MAX_PAGES_PER_POOL = 2e3;
var DEFAULT_MAX_RETRIES = 5;
var DEFAULT_MAX_SCAN_MS = 10 * 60 * 1e3;
var SUI_ZERO_ADDRESS = `0x${"0".repeat(64)}`;
var TREE_ACTIVITY_SOURCES = [
  { poolId: SUIDEX_V2_TREE_POOL_ID, protocol: "suidex-v2", venue: "suidex-v2" },
  { poolId: SUIDEX_V3_TREE_POOL_ID, protocol: "suidex-v3", venue: "suidex-v3" },
  { poolId: CETUS_TREE_POOL_ID, protocol: "cetus-v3", venue: "cetus" },
  ...TURBOS_TREE_POOL_IDS.map((poolId) => ({ poolId, protocol: "turbos", venue: "turbos" }))
];
var LATEST_CHECKPOINT_QUERY = `query LatestCheckpoint {
  checkpoints(last: 1) { nodes { sequenceNumber timestamp } }
}`;
var CHECKPOINT_AT_QUERY = `query CheckpointAt($sequenceNumber: UInt53!) {
  checkpoint(sequenceNumber: $sequenceNumber) { sequenceNumber timestamp }
}`;
var POOL_TRANSACTIONS_QUERY = `query PoolTransactions(
  $pool: SuiAddress!
  $first: Int!
  $after: String
  $afterCheckpoint: UInt53!
  $beforeCheckpoint: UInt53!
) {
  transactions(
    first: $first
    after: $after
    filter: {
      affectedObject: $pool
      afterCheckpoint: $afterCheckpoint
      beforeCheckpoint: $beforeCheckpoint
    }
  ) {
    pageInfo { hasNextPage endCursor }
    nodes {
      digest
      sender { address }
      transactionJson
      effects {
        status
        timestamp
        checkpoint { sequenceNumber }
        balanceChanges(first: 50) {
          pageInfo { hasNextPage }
          nodes {
            owner { address }
            coinType { repr }
            amount
          }
        }
      }
    }
  }
}`;
function record3(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function canonicalCoinType(value) {
  if (value && typeof value === "object") {
    const nested = record3(value);
    return canonicalCoinType(nested.repr ?? nested.coin_type ?? nested.coinType);
  }
  if (typeof value !== "string") return null;
  const parts = value.trim().toLowerCase().split("::");
  if (parts.length !== 3) return null;
  const address = parts[0].replace(/^0x/, "");
  if (!/^[0-9a-f]{1,64}$/.test(address)) return null;
  return `0x${address.padStart(64, "0")}::${parts[1]}::${parts[2]}`;
}
var NORMALIZED_TREE3 = canonicalCoinType(TREE_COIN_TYPE);
function containsTreeType(value) {
  if (typeof value !== "string") return false;
  const normalized = value.toLowerCase().replace(/0x0+/g, "0x");
  const tree = TREE_COIN_TYPE.toLowerCase().replace(/^0x0*/, "0x");
  return canonicalCoinType(value) === NORMALIZED_TREE3 || normalized.includes(tree);
}
function parseUnsignedCheckpoint(value) {
  const numeric = typeof value === "number" ? value : Number(value);
  return Number.isSafeInteger(numeric) && numeric >= 0 ? numeric : null;
}
function parseSignedRaw(value) {
  if (typeof value === "bigint") return value;
  if (typeof value === "number" && Number.isSafeInteger(value)) return BigInt(value);
  if (typeof value === "string" && /^-?\d+$/.test(value)) return BigInt(value);
  return null;
}
function validDate3(value) {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}
function normalizeWallets(values) {
  return [...new Set(values.map(normalizeSuiAddress).filter((value) => Boolean(value)))].sort();
}
function sameWalletSet(left, right) {
  return left.length === right.length && left.every((wallet, index) => wallet === right[index]);
}
function normalizeSources(values) {
  const sources = /* @__PURE__ */ new Map();
  for (const value of values) {
    const poolId = normalizeSuiAddress(value.poolId);
    if (!poolId || !["suidex-v2", "suidex-v3", "turbos", "cetus"].includes(value.venue)) continue;
    sources.set(poolId, {
      poolId,
      protocol: String(value.protocol || value.venue),
      venue: value.venue
    });
  }
  return [...sources.values()].sort((a, b) => a.poolId.localeCompare(b.poolId));
}
function extractMoveCalls(value) {
  const calls = [];
  const visit = (node) => {
    if (Array.isArray(node)) {
      node.forEach(visit);
      return;
    }
    if (!node || typeof node !== "object") return;
    const object = record3(node);
    const packageValue = object.package ?? object.packageId ?? object.package_id ?? object.packageAddress ?? object.package_address;
    const moduleValue = object.module ?? object.moduleName ?? object.module_name;
    const functionValue = object.function ?? object.functionName ?? object.function_name;
    const packageId = normalizeSuiAddress(packageValue);
    if (packageId && typeof moduleValue === "string" && typeof functionValue === "string") {
      const rawTypeArguments = object.typeArguments ?? object.type_arguments ?? object.typeArgs;
      calls.push({
        packageId,
        moduleName: moduleValue.toLowerCase(),
        functionName: functionValue.toLowerCase(),
        typeArguments: Array.isArray(rawTypeArguments) ? rawTypeArguments.filter((item) => typeof item === "string") : []
      });
    }
    Object.values(object).forEach(visit);
  };
  visit(value);
  return calls;
}
function callContainsTree(call) {
  return call.typeArguments.some(containsTreeType);
}
function recognizedSwapVenue(call) {
  if (!callContainsTree(call)) return null;
  if (call.packageId === normalizeSuiAddress(SUIDEX_V2_PACKAGE) && call.moduleName === "router" && call.functionName.includes("swap")) return "suidex-v2";
  if (call.packageId === normalizeSuiAddress(SUIDEX_V3_PACKAGE) && call.moduleName === "trade" && call.functionName.includes("swap") && !call.functionName.startsWith("repay")) return "suidex-v3";
  if (call.packageId === normalizeSuiAddress(TURBOS_SWAP_PACKAGE) && call.moduleName === "turbos" && call.functionName.includes("swap")) return "turbos";
  if (call.packageId === normalizeSuiAddress(CETUS_INTEGRATE_PACKAGE) && call.moduleName === "pool_script_v2" && ["swap_a2b", "swap_b2a"].includes(call.functionName)) return "cetus";
  return null;
}
function disqualifyingTreeAction(call) {
  if (!callContainsTree(call)) return false;
  const recognizedPackages = /* @__PURE__ */ new Set([
    normalizeSuiAddress(SUIDEX_V2_PACKAGE),
    normalizeSuiAddress(SUIDEX_V3_PACKAGE),
    normalizeSuiAddress(TURBOS_SWAP_PACKAGE),
    normalizeSuiAddress(TURBOS_PACKAGE),
    normalizeSuiAddress(TURBOS_POSITION_MANAGER_PACKAGE),
    normalizeSuiAddress(CETUS_INTEGRATE_PACKAGE)
  ]);
  if (!recognizedPackages.has(call.packageId)) return false;
  const action = `${call.moduleName}::${call.functionName}`;
  return /(liquidity|position|farm|staking|reward|collect|deposit|withdraw|stake|unstake|mint|open_position|close_position|add_liquidity|remove_liquidity|burn_nft)/.test(action);
}
function sourcePoolForVenue(venue, queriedPool) {
  if (venue === "suidex-v2") return SUIDEX_V2_TREE_POOL_ID;
  if (venue === "suidex-v3") return SUIDEX_V3_TREE_POOL_ID;
  if (venue === "cetus") return CETUS_TREE_POOL_ID;
  return TURBOS_TREE_POOL_IDS.includes(queriedPool) ? queriedPool : TURBOS_TREE_POOL_IDS[0];
}
function classifyTransaction(nodeValue, queriedPool, targetWallets, windowStartMs, windowEndMs) {
  const node = record3(nodeValue);
  const digest = typeof node.digest === "string" ? node.digest.trim() : "";
  const wallet = normalizeSuiAddress(record3(node.sender).address);
  const effects = record3(node.effects);
  const timestamp = Date.parse(String(effects.timestamp || ""));
  const checkpoint = parseUnsignedCheckpoint(record3(effects.checkpoint).sequenceNumber);
  if (!digest || !wallet || !targetWallets.has(wallet) || effects.status !== "SUCCESS" || !Number.isFinite(timestamp) || timestamp < windowStartMs || timestamp > windowEndMs || checkpoint === null) return null;
  const balanceChanges = record3(effects.balanceChanges);
  if (record3(balanceChanges.pageInfo).hasNextPage === true) return null;
  const changes = Array.isArray(balanceChanges.nodes) ? balanceChanges.nodes : [];
  let senderTreeDelta = 0n;
  let zeroAddressTreeCredit = 0n;
  for (const changeValue of changes) {
    const change = record3(changeValue);
    if (canonicalCoinType(record3(change.coinType).repr) !== NORMALIZED_TREE3) continue;
    const owner = normalizeSuiAddress(record3(change.owner).address);
    const amount = parseSignedRaw(change.amount);
    if (!owner || amount === null) return null;
    if (owner === wallet) senderTreeDelta += amount;
    if (owner === SUI_ZERO_ADDRESS && amount > 0n) zeroAddressTreeCredit += amount;
  }
  if (senderTreeDelta === 0n || zeroAddressTreeCredit > 0n) return null;
  const calls = extractMoveCalls(node.transactionJson);
  if (calls.some(disqualifyingTreeAction)) return null;
  const venues = [...new Set(calls.map(recognizedSwapVenue).filter((value) => Boolean(value)))];
  if (!venues.length) return null;
  const source = sourcePoolForVenue(venues[0], queriedPool);
  return {
    wallet,
    digest,
    timestamp,
    checkpoint: String(checkpoint),
    source,
    legs: { [source]: senderTreeDelta.toString() }
  };
}
function validateTreeActivityIndex(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const index = value;
  if (index.methodologyVersion !== TREE_ACTIVITY_INDEX_METHODOLOGY_VERSION || !validDate3(index.generatedAt) || !validDate3(index.windowStart) || !validDate3(index.windowEnd) || Date.parse(index.windowStart) >= Date.parse(index.windowEnd) || typeof index.windowStartCheckpoint !== "string" || !/^\d+$/.test(index.windowStartCheckpoint) || typeof index.indexedThroughCheckpoint !== "string" || !/^\d+$/.test(index.indexedThroughCheckpoint) || !Array.isArray(index.wallets) || !sameWalletSet(index.wallets, normalizeWallets(index.wallets)) || !index.pools || typeof index.pools !== "object" || !index.transactions || typeof index.transactions !== "object") return false;
  for (const [poolId, pool] of Object.entries(index.pools)) {
    if (normalizeSuiAddress(poolId) !== poolId || typeof pool.protocol !== "string" || !Number.isSafeInteger(pool.indexedThroughMs) || pool.indexedThroughMs < 0 || !/^\d+$/.test(pool.indexedThroughCheckpoint) || !/^\d+$/.test(pool.rangeStartCheckpoint) || !/^\d+$/.test(pool.rangeEndCheckpoint) || pool.nextCursor !== null && typeof pool.nextCursor !== "string" || typeof pool.inProgress !== "boolean") return false;
  }
  const walletSet = new Set(index.wallets);
  for (const [key, transaction] of Object.entries(index.transactions)) {
    if (key !== `${transaction.wallet}:${transaction.digest}` || !walletSet.has(transaction.wallet) || normalizeSuiAddress(transaction.wallet) !== transaction.wallet || typeof transaction.digest !== "string" || !transaction.digest || !Number.isSafeInteger(transaction.timestamp) || transaction.timestamp < 0 || !/^\d+$/.test(transaction.checkpoint) || normalizeSuiAddress(transaction.source) !== transaction.source || !transaction.legs || typeof transaction.legs !== "object") return false;
    const legs = Object.entries(transaction.legs);
    if (legs.length !== 1) return false;
    for (const [poolId, raw] of legs) {
      if (normalizeSuiAddress(poolId) !== poolId || typeof raw !== "string" || !/^-?\d+$/.test(raw) || raw === "0") return false;
    }
  }
  return true;
}
function emptyIndex(wallets, windowStartMs, windowEndMs, windowStartCheckpoint) {
  return {
    methodologyVersion: TREE_ACTIVITY_INDEX_METHODOLOGY_VERSION,
    generatedAt: new Date(windowEndMs).toISOString(),
    windowStart: new Date(windowStartMs).toISOString(),
    windowEnd: new Date(windowEndMs).toISOString(),
    windowStartCheckpoint: String(windowStartCheckpoint),
    indexedThroughCheckpoint: String(Math.max(0, windowStartCheckpoint - 1)),
    wallets,
    pools: {},
    transactions: {}
  };
}
function copyIndex(prior, wallets, windowStartMs, windowEndMs, windowStartCheckpoint) {
  if (!prior || !sameWalletSet(prior.wallets, wallets)) {
    return emptyIndex(wallets, windowStartMs, windowEndMs, windowStartCheckpoint);
  }
  const transactions = {};
  for (const [key, transaction] of Object.entries(prior.transactions)) {
    if (transaction.timestamp >= windowStartMs && transaction.timestamp <= windowEndMs) {
      transactions[key] = { ...transaction, legs: { ...transaction.legs } };
    }
  }
  return {
    ...prior,
    generatedAt: new Date(windowEndMs).toISOString(),
    windowStart: new Date(windowStartMs).toISOString(),
    windowEnd: new Date(windowEndMs).toISOString(),
    windowStartCheckpoint: String(windowStartCheckpoint),
    wallets,
    pools: Object.fromEntries(Object.entries(prior.pools).map(([poolId, pool]) => [poolId, { ...pool }])),
    transactions
  };
}
async function requestGraphql(endpoint, query, variables, fetchImpl, maxRetries, sleepImpl, coverage, deadline) {
  let lastError = null;
  for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
    if (Date.now() >= deadline) {
      coverage.timeLimitReached = true;
      throw new Error("The TREE activity scan reached its bounded deadline.");
    }
    try {
      const response = await fetchImpl(endpoint, {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify({ query, variables })
      });
      if (response.status === 429 || response.status >= 500) {
        throw new Error(`Sui GraphQL returned ${response.status}.`);
      }
      if (!response.ok) throw new Error(`Sui GraphQL returned ${response.status}.`);
      const payload = record3(await response.json());
      const errors = Array.isArray(payload.errors) ? payload.errors : [];
      if (errors.length) {
        throw new Error(errors.map((error) => String(record3(error).message || "Sui GraphQL error")).join(" "));
      }
      return payload;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error("Sui GraphQL request failed.");
      if (attempt >= maxRetries) break;
      coverage.retries += 1;
      await sleepImpl(Math.min(4e3, 250 * 2 ** attempt));
    }
  }
  throw lastError || new Error("Sui GraphQL request failed.");
}
async function latestCheckpoint(endpoint, fetchImpl, maxRetries, sleepImpl, coverage, deadline) {
  coverage.checkpointQueries += 1;
  const payload = await requestGraphql(endpoint, LATEST_CHECKPOINT_QUERY, {}, fetchImpl, maxRetries, sleepImpl, coverage, deadline);
  const nodes = record3(record3(payload.data).checkpoints).nodes;
  const node = Array.isArray(nodes) ? record3(nodes[0]) : {};
  const sequenceNumber = parseUnsignedCheckpoint(node.sequenceNumber);
  const timestamp = Date.parse(String(node.timestamp || ""));
  if (sequenceNumber === null || !Number.isFinite(timestamp)) {
    throw new Error("The latest Sui checkpoint could not be resolved.");
  }
  return { sequenceNumber, timestamp };
}
async function checkpointAt(sequenceNumber, endpoint, fetchImpl, maxRetries, sleepImpl, coverage, deadline) {
  coverage.checkpointQueries += 1;
  const payload = await requestGraphql(
    endpoint,
    CHECKPOINT_AT_QUERY,
    { sequenceNumber },
    fetchImpl,
    maxRetries,
    sleepImpl,
    coverage,
    deadline
  );
  const node = record3(record3(payload.data).checkpoint);
  const resolvedSequence = parseUnsignedCheckpoint(node.sequenceNumber);
  const timestamp = Date.parse(String(node.timestamp || ""));
  if (resolvedSequence === null || resolvedSequence !== sequenceNumber || !Number.isFinite(timestamp)) {
    throw new Error(`Sui checkpoint ${sequenceNumber} could not be resolved.`);
  }
  return { sequenceNumber: resolvedSequence, timestamp };
}
async function resolveWindowStartCheckpoint(targetTimestamp, latest, endpoint, fetchImpl, maxRetries, sleepImpl, coverage, deadline) {
  if (targetTimestamp >= latest.timestamp) return latest.sequenceNumber;
  let low = 0;
  let high = latest.sequenceNumber;
  while (low < high) {
    const midpoint = Math.floor((low + high) / 2);
    const checkpoint = await checkpointAt(midpoint, endpoint, fetchImpl, maxRetries, sleepImpl, coverage, deadline);
    if (checkpoint.timestamp < targetTimestamp) low = midpoint + 1;
    else high = midpoint;
  }
  return low;
}
async function persistProgress(index, options) {
  const callback = options.onProgress ?? options.onPoolComplete;
  await callback?.(index);
}
async function scanSource(index, source, targetWallets, windowStartMs, windowEndMs, windowStartCheckpoint, latestCheckpointNumber, endpoint, fetchImpl, pageSize, maxPages, maxRetries, sleepImpl, coverage, deadline, options) {
  const minimumExclusiveCheckpoint = Math.max(0, windowStartCheckpoint - 1);
  while (true) {
    let state = index.pools[source.poolId];
    if (!state || !state.inProgress) {
      const indexedThrough = state ? Number(state.indexedThroughCheckpoint) : minimumExclusiveCheckpoint;
      const rangeStart2 = Math.max(minimumExclusiveCheckpoint, Number.isSafeInteger(indexedThrough) ? indexedThrough : minimumExclusiveCheckpoint);
      if (rangeStart2 >= latestCheckpointNumber) {
        index.pools[source.poolId] = {
          protocol: source.protocol,
          indexedThroughMs: windowEndMs,
          indexedThroughCheckpoint: String(latestCheckpointNumber),
          rangeStartCheckpoint: String(rangeStart2),
          rangeEndCheckpoint: String(latestCheckpointNumber),
          nextCursor: null,
          inProgress: false
        };
        await persistProgress(index, options);
        return true;
      }
      state = {
        protocol: source.protocol,
        indexedThroughMs: state?.indexedThroughMs ?? windowStartMs,
        indexedThroughCheckpoint: String(rangeStart2),
        rangeStartCheckpoint: String(rangeStart2),
        rangeEndCheckpoint: String(latestCheckpointNumber),
        nextCursor: null,
        inProgress: true
      };
      index.pools[source.poolId] = state;
      await persistProgress(index, options);
    }
    const rangeStart = Number(state.rangeStartCheckpoint);
    const rangeEnd = Number(state.rangeEndCheckpoint);
    let cursor = state.nextCursor;
    let reachedEnd = false;
    for (let page = 0; page < maxPages; page += 1) {
      if (Date.now() >= deadline) {
        coverage.timeLimitReached = true;
        return false;
      }
      const payload = await requestGraphql(
        endpoint,
        POOL_TRANSACTIONS_QUERY,
        {
          pool: source.poolId,
          first: pageSize,
          after: cursor,
          afterCheckpoint: rangeStart,
          beforeCheckpoint: rangeEnd + 1
        },
        fetchImpl,
        maxRetries,
        sleepImpl,
        coverage,
        deadline
      );
      const connection = record3(record3(payload.data).transactions);
      const nodes = Array.isArray(connection.nodes) ? connection.nodes : [];
      coverage.pagesScanned += 1;
      coverage.eventsScanned += nodes.length;
      for (const node of nodes) {
        const transaction = classifyTransaction(node, source.poolId, targetWallets, windowStartMs, windowEndMs);
        if (!transaction) continue;
        const key = `${transaction.wallet}:${transaction.digest}`;
        const previous = index.transactions[key];
        if (previous) {
          const previousRaw = Object.values(previous.legs)[0];
          const currentRaw = Object.values(transaction.legs)[0];
          if (previous.wallet !== transaction.wallet || previous.timestamp !== transaction.timestamp || previous.checkpoint !== transaction.checkpoint || previousRaw !== currentRaw) {
            coverage.malformedEvents += 1;
            throw new Error(`Conflicting duplicate TREE trade ${transaction.digest}.`);
          }
          coverage.duplicateEvents += 1;
          continue;
        }
        index.transactions[key] = transaction;
      }
      const pageInfo = record3(connection.pageInfo);
      if (pageInfo.hasNextPage !== true) {
        reachedEnd = true;
        cursor = null;
      } else if (typeof pageInfo.endCursor !== "string" || !pageInfo.endCursor || pageInfo.endCursor === cursor) {
        throw new Error(`The Sui transaction cursor was missing or repeated for ${source.poolId}.`);
      } else {
        cursor = pageInfo.endCursor;
      }
      index.pools[source.poolId] = {
        ...state,
        nextCursor: cursor,
        inProgress: !reachedEnd
      };
      await persistProgress(index, options);
      if (reachedEnd) break;
    }
    if (!reachedEnd) return false;
    index.pools[source.poolId] = {
      protocol: source.protocol,
      indexedThroughMs: windowEndMs,
      indexedThroughCheckpoint: String(rangeEnd),
      rangeStartCheckpoint: String(rangeEnd),
      rangeEndCheckpoint: String(rangeEnd),
      nextCursor: null,
      inProgress: false
    };
    await persistProgress(index, options);
    if (rangeEnd >= latestCheckpointNumber) return true;
  }
}
async function refreshTreeActivityIndex(priorValue, options = {}) {
  const now = options.now ?? Date.now;
  const startedAt = now();
  const windowEndMs = startedAt;
  const windowStartMs = windowEndMs - TREE_ACTIVITY_WINDOW_MS;
  const coverage = {
    poolsRequested: 0,
    poolsCompleted: 0,
    pagesScanned: 0,
    eventsScanned: 0,
    tradeTransactions: 0,
    duplicateEvents: 0,
    malformedEvents: 0,
    retries: 0,
    checkpointQueries: 0,
    reachedEnd: false,
    timeLimitReached: false
  };
  const wallets = normalizeWallets(options.wallets || (validateTreeActivityIndex(priorValue) ? priorValue.wallets : []));
  if (!wallets.length) {
    return {
      outcome: "error",
      index: null,
      coverage,
      warnings: ["The Sui-native TREE activity index requires the current ranked wallet set."]
    };
  }
  const getEnv = options.getEnv ?? ((name) => typeof Netlify !== "undefined" ? Netlify.env.get(name) : void 0);
  const endpoint = getEnv("SUI_GRAPHQL_URL") || DEFAULT_GRAPHQL_URL;
  const fetchImpl = options.fetchImpl ?? fetch;
  const pageSize = Math.max(1, Math.min(50, Math.trunc(options.pageSize ?? DEFAULT_PAGE_SIZE)));
  const maxPages = Math.max(1, Math.min(1e4, Math.trunc(options.maxPagesPerPool ?? DEFAULT_MAX_PAGES_PER_POOL)));
  const maxRetries = Math.max(0, Math.min(8, Math.trunc(options.maxRetries ?? DEFAULT_MAX_RETRIES)));
  const maxScanMs = Math.max(3e4, Math.trunc(options.maxScanMs ?? DEFAULT_MAX_SCAN_MS));
  const sleepImpl = options.sleepImpl ?? ((milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)));
  const sources = normalizeSources(options.sources || TREE_ACTIVITY_SOURCES);
  coverage.poolsRequested = sources.length;
  const deadline = Date.now() + maxScanMs;
  let index = null;
  try {
    const latest = await latestCheckpoint(endpoint, fetchImpl, maxRetries, sleepImpl, coverage, deadline);
    const windowStartCheckpoint = await resolveWindowStartCheckpoint(
      windowStartMs,
      latest,
      endpoint,
      fetchImpl,
      maxRetries,
      sleepImpl,
      coverage,
      deadline
    );
    const prior = validateTreeActivityIndex(priorValue) ? priorValue : null;
    index = copyIndex(prior, wallets, windowStartMs, windowEndMs, windowStartCheckpoint);
    const targetWallets = new Set(wallets);
    for (const source of sources) {
      const complete = await scanSource(
        index,
        source,
        targetWallets,
        windowStartMs,
        windowEndMs,
        windowStartCheckpoint,
        latest.sequenceNumber,
        endpoint,
        fetchImpl,
        pageSize,
        maxPages,
        maxRetries,
        sleepImpl,
        coverage,
        deadline,
        options
      );
      if (!complete) {
        return {
          outcome: "verification-incomplete",
          index,
          coverage,
          warnings: [
            coverage.timeLimitReached ? "The Sui-native TREE activity scan reached its deadline; stored cursors will resume the same bounded range." : `The Sui-native TREE activity scan did not reach the natural end for ${source.poolId}; stored cursors will resume it.`
          ]
        };
      }
      coverage.poolsCompleted += 1;
    }
    index.generatedAt = new Date(windowEndMs).toISOString();
    index.indexedThroughCheckpoint = String(latest.sequenceNumber);
    coverage.tradeTransactions = Object.keys(index.transactions).length;
    coverage.reachedEnd = coverage.poolsCompleted === coverage.poolsRequested;
    if (!coverage.reachedEnd || !validateTreeActivityIndex(index)) {
      return {
        outcome: "verification-incomplete",
        index,
        coverage,
        warnings: ["The Sui-native TREE activity index failed final integrity validation."]
      };
    }
    return {
      outcome: "complete",
      index,
      coverage,
      warnings: [
        "The rolling activity index uses successful Sui transactions, exact sender TREE balance changes, and recognized SuiDex V2, SuiDex V3, and Turbos swap calls.",
        "Transfers, LP joins and exits, staking, farming, fee and reward collection, and burns are excluded from buy/sell classification."
      ]
    };
  } catch (error) {
    return {
      outcome: coverage.timeLimitReached ? "verification-incomplete" : "error",
      index,
      coverage,
      warnings: [error instanceof Error ? error.message : "The Sui-native TREE activity index failed."]
    };
  }
}
function summarizeTreeActivity(index, walletValues) {
  const wallets = normalizeWallets(walletValues);
  const mutable = new Map(wallets.map((wallet) => [wallet, {
    buyCount: 0,
    sellCount: 0,
    buyRaw: 0n,
    sellRaw: 0n
  }]));
  for (const transaction of Object.values(index.transactions)) {
    const stats = mutable.get(transaction.wallet);
    if (!stats) continue;
    const net = Object.values(transaction.legs).reduce((sum, raw) => sum + BigInt(raw), 0n);
    if (net > 0n) {
      stats.buyCount += 1;
      stats.buyRaw += net;
    } else if (net < 0n) {
      stats.sellCount += 1;
      stats.sellRaw += -net;
    }
  }
  return Object.fromEntries([...mutable.entries()].map(([wallet, stats]) => [wallet, {
    buyCount: stats.buyCount,
    sellCount: stats.sellCount,
    buyTreeRaw: stats.buyRaw.toString(),
    buyTree: formatTreeRaw(stats.buyRaw),
    sellTreeRaw: stats.sellRaw.toString(),
    sellTree: formatTreeRaw(stats.sellRaw)
  }]));
}

// netlify/lib/tree-burn-index.ts
var TREE_BURN_INDEX_METHODOLOGY_VERSION = "sui-sender-burn-checkpoints-v3";
var SUI_ZERO_ADDRESS2 = `0x${"0".repeat(64)}`;
var TREE_TOKEN_CREATION_CHECKPOINT = "169361209";
var DEFAULT_GRAPHQL_URL2 = "https://graphql.mainnet.sui.io/graphql";
var DEFAULT_PAGE_SIZE2 = 50;
var DEFAULT_MAX_PAGES_PER_WALLET = 5e3;
var DEFAULT_CONCURRENCY = 4;
var DEFAULT_MAX_RETRIES2 = 5;
var DEFAULT_MAX_SCAN_MS2 = 10 * 60 * 1e3;
var LATEST_CHECKPOINT_QUERY2 = `query LatestCheckpoint {
  checkpoints(last: 1) { nodes { sequenceNumber } }
}`;
var WALLET_TRANSACTIONS_QUERY = `query WalletTreeBurns(
  $sender: SuiAddress!
  $first: Int!
  $after: String
  $afterCheckpoint: UInt53!
  $beforeCheckpoint: UInt53!
) {
  transactions(
    first: $first
    after: $after
    filter: {
      sentAddress: $sender
      afterCheckpoint: $afterCheckpoint
      beforeCheckpoint: $beforeCheckpoint
    }
  ) {
    pageInfo { hasNextPage endCursor }
    nodes {
      digest
      sender { address }
      effects {
        status
        checkpoint { sequenceNumber }
        balanceChanges(first: 50) {
          pageInfo { hasNextPage }
          nodes {
            owner { address }
            coinType { repr }
            amount
          }
        }
      }
    }
  }
}`;
function record4(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function canonicalCoinType2(value) {
  if (typeof value !== "string") return null;
  const parts = value.trim().toLowerCase().split("::");
  if (parts.length !== 3) return null;
  const address = parts[0].replace(/^0x/, "");
  if (!/^[0-9a-f]{1,64}$/.test(address)) return null;
  return `0x${address.padStart(64, "0")}::${parts[1]}::${parts[2]}`;
}
var NORMALIZED_TREE4 = canonicalCoinType2(TREE_COIN_TYPE);
function validDate4(value) {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}
function parseCheckpoint(value) {
  const numeric = typeof value === "number" ? value : Number(value);
  return Number.isSafeInteger(numeric) && numeric >= 0 ? numeric : null;
}
function parseUnsignedRaw2(value) {
  if (typeof value === "bigint" && value >= 0n) return value;
  if (typeof value === "number" && Number.isSafeInteger(value) && value >= 0) return BigInt(value);
  if (typeof value === "string" && /^\d+$/.test(value)) return BigInt(value);
  return null;
}
function parseSignedRaw2(value) {
  if (typeof value === "bigint") return value;
  if (typeof value === "number" && Number.isSafeInteger(value)) return BigInt(value);
  if (typeof value === "string" && /^-?\d+$/.test(value)) return BigInt(value);
  return null;
}
function normalizeWallets2(values) {
  return [...new Set(values.map(normalizeSuiAddress).filter((value) => Boolean(value)))].sort();
}
function validProgress(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const progress = value;
  return /^\d+$/.test(progress.rangeStartCheckpoint) && /^\d+$/.test(progress.rangeEndCheckpoint) && BigInt(progress.rangeEndCheckpoint) >= BigInt(progress.rangeStartCheckpoint) && (progress.nextCursor === null || typeof progress.nextCursor === "string") && /^\d+$/.test(progress.accumulatedBurnedTreeRaw);
}
function validateTreeBurnIndex(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const index = value;
  if (index.methodologyVersion !== TREE_BURN_INDEX_METHODOLOGY_VERSION || !validDate4(index.generatedAt) || !/^\d+$/.test(index.indexedThroughCheckpoint) || !/^\d+$/.test(index.creationCheckpoint) || !index.wallets || typeof index.wallets !== "object") return false;
  for (const [wallet, entry] of Object.entries(index.wallets)) {
    if (normalizeSuiAddress(wallet) !== wallet || typeof entry.burnedTreeRaw !== "string" || !/^\d+$/.test(entry.burnedTreeRaw) || typeof entry.indexedThroughCheckpoint !== "string" || !/^\d+$/.test(entry.indexedThroughCheckpoint) || typeof entry.completeBackfill !== "boolean" || entry.progress !== null && !validProgress(entry.progress) || entry.completeBackfill && entry.progress !== null) return false;
  }
  return true;
}
async function requestGraphql2(endpoint, query, variables, fetchImpl, maxRetries, sleepImpl, coverage, deadline) {
  let lastError = null;
  for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
    if (Date.now() >= deadline) {
      coverage.timeLimitReached = true;
      throw new Error("The TREE burn scan reached its bounded deadline.");
    }
    try {
      const response = await fetchImpl(endpoint, {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify({ query, variables })
      });
      if (response.status === 429 || response.status >= 500) {
        throw new Error(`Sui GraphQL returned ${response.status}.`);
      }
      if (!response.ok) throw new Error(`Sui GraphQL returned ${response.status}.`);
      const payload = record4(await response.json());
      const errors = Array.isArray(payload.errors) ? payload.errors : [];
      if (errors.length) {
        throw new Error(errors.map((error) => String(record4(error).message || "Sui GraphQL error")).join(" "));
      }
      return payload;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error("Sui GraphQL request failed.");
      if (attempt >= maxRetries) break;
      coverage.retries += 1;
      await sleepImpl(Math.min(4e3, 250 * 2 ** attempt));
    }
  }
  throw lastError || new Error("Sui GraphQL request failed.");
}
async function latestCheckpoint2(endpoint, fetchImpl, maxRetries, sleepImpl, coverage, deadline) {
  const payload = await requestGraphql2(endpoint, LATEST_CHECKPOINT_QUERY2, {}, fetchImpl, maxRetries, sleepImpl, coverage, deadline);
  const nodes = record4(record4(payload.data).checkpoints).nodes;
  const node = Array.isArray(nodes) ? record4(nodes[0]) : {};
  const sequence = parseCheckpoint(node.sequenceNumber);
  if (sequence === null) throw new Error("The latest Sui checkpoint could not be resolved.");
  return String(sequence);
}
function copyIndex2(prior, generatedAt, creationCheckpoint, wallets) {
  const minimumCheckpoint = String(Math.max(0, Number(creationCheckpoint) - 1));
  const entries = {};
  for (const wallet of wallets) {
    const existing = prior?.creationCheckpoint === creationCheckpoint ? prior.wallets[wallet] : null;
    entries[wallet] = existing ? {
      ...existing,
      progress: existing.progress ? { ...existing.progress } : null
    } : {
      burnedTreeRaw: "0",
      indexedThroughCheckpoint: minimumCheckpoint,
      completeBackfill: false,
      progress: null
    };
  }
  return {
    methodologyVersion: TREE_BURN_INDEX_METHODOLOGY_VERSION,
    generatedAt,
    indexedThroughCheckpoint: prior?.creationCheckpoint === creationCheckpoint ? prior.indexedThroughCheckpoint : minimumCheckpoint,
    creationCheckpoint,
    wallets: entries
  };
}
async function persistProgress2(index, wallet, options, enqueue) {
  const callback = options.onProgress ?? options.onWalletComplete;
  if (!callback) return;
  await enqueue(async () => callback(index, wallet));
}
async function scanWallet(index, wallet, latest, endpoint, fetchImpl, pageSize, maxPages, maxRetries, sleepImpl, coverage, deadline, options, enqueue) {
  while (true) {
    let entry = index.wallets[wallet];
    let rangeStart;
    let rangeEnd;
    let cursor;
    let accumulated;
    if (entry.progress) {
      rangeStart = Number(entry.progress.rangeStartCheckpoint);
      rangeEnd = Number(entry.progress.rangeEndCheckpoint);
      cursor = entry.progress.nextCursor;
      accumulated = BigInt(entry.progress.accumulatedBurnedTreeRaw);
    } else {
      rangeStart = Number(entry.indexedThroughCheckpoint);
      if (rangeStart >= latest) {
        index.wallets[wallet] = {
          ...entry,
          indexedThroughCheckpoint: String(latest),
          completeBackfill: true,
          progress: null
        };
        await persistProgress2(index, wallet, options, enqueue);
        return;
      }
      rangeEnd = latest;
      cursor = null;
      accumulated = BigInt(entry.burnedTreeRaw);
      entry = {
        ...entry,
        completeBackfill: false,
        progress: {
          rangeStartCheckpoint: String(rangeStart),
          rangeEndCheckpoint: String(rangeEnd),
          nextCursor: null,
          accumulatedBurnedTreeRaw: accumulated.toString()
        }
      };
      index.wallets[wallet] = entry;
      await persistProgress2(index, wallet, options, enqueue);
    }
    let reachedEnd = false;
    const seenCursors = /* @__PURE__ */ new Set();
    for (let page = 0; page < maxPages; page += 1) {
      if (Date.now() >= deadline) {
        coverage.timeLimitReached = true;
        throw new Error(`Burn history reached its deadline while scanning ${wallet}.`);
      }
      const payload = await requestGraphql2(
        endpoint,
        WALLET_TRANSACTIONS_QUERY,
        {
          sender: wallet,
          first: pageSize,
          after: cursor,
          afterCheckpoint: rangeStart,
          beforeCheckpoint: rangeEnd + 1
        },
        fetchImpl,
        maxRetries,
        sleepImpl,
        coverage,
        deadline
      );
      const connection = record4(record4(payload.data).transactions);
      const nodes = Array.isArray(connection.nodes) ? connection.nodes : [];
      coverage.pagesScanned += 1;
      coverage.transactionsScanned += nodes.length;
      const pageDigests = /* @__PURE__ */ new Set();
      for (const nodeValue of nodes) {
        const node = record4(nodeValue);
        const digest = typeof node.digest === "string" ? node.digest.trim() : "";
        const sender = normalizeSuiAddress(record4(node.sender).address);
        const effects = record4(node.effects);
        const checkpoint = parseCheckpoint(record4(effects.checkpoint).sequenceNumber);
        const changes = record4(effects.balanceChanges);
        const changeNodes = Array.isArray(changes.nodes) ? changes.nodes : [];
        if (!digest || sender !== wallet || effects.status !== "SUCCESS" || checkpoint === null || checkpoint <= rangeStart || checkpoint > rangeEnd || record4(changes.pageInfo).hasNextPage === true) {
          coverage.malformedTransactions += 1;
          continue;
        }
        if (pageDigests.has(digest)) {
          coverage.duplicateTransactions += 1;
          continue;
        }
        pageDigests.add(digest);
        let transactionBurnRaw = 0n;
        for (const changeValue of changeNodes) {
          const change = record4(changeValue);
          const owner = normalizeSuiAddress(record4(change.owner).address);
          const coinType = canonicalCoinType2(record4(change.coinType).repr);
          const amount = parseSignedRaw2(change.amount);
          if (!owner || amount === null) {
            coverage.malformedTransactions += 1;
            continue;
          }
          if (owner === SUI_ZERO_ADDRESS2 && coinType === NORMALIZED_TREE4 && amount > 0n) {
            transactionBurnRaw += amount;
          }
        }
        if (transactionBurnRaw > 0n) {
          accumulated += transactionBurnRaw;
          coverage.treeBurnTransactions += 1;
        }
      }
      const pageInfo = record4(connection.pageInfo);
      if (pageInfo.hasNextPage !== true) {
        reachedEnd = true;
        cursor = null;
      } else if (typeof pageInfo.endCursor !== "string" || !pageInfo.endCursor || pageInfo.endCursor === cursor || seenCursors.has(pageInfo.endCursor)) {
        throw new Error(`Burn history cursor was missing or repeated for ${wallet}.`);
      } else {
        cursor = pageInfo.endCursor;
        seenCursors.add(cursor);
      }
      index.wallets[wallet] = {
        burnedTreeRaw: entry.burnedTreeRaw,
        indexedThroughCheckpoint: entry.indexedThroughCheckpoint,
        completeBackfill: false,
        progress: {
          rangeStartCheckpoint: String(rangeStart),
          rangeEndCheckpoint: String(rangeEnd),
          nextCursor: cursor,
          accumulatedBurnedTreeRaw: accumulated.toString()
        }
      };
      await persistProgress2(index, wallet, options, enqueue);
      if (reachedEnd) break;
    }
    if (!reachedEnd) throw new Error(`Burn history did not reach the natural end for ${wallet}.`);
    index.wallets[wallet] = {
      burnedTreeRaw: accumulated.toString(),
      indexedThroughCheckpoint: String(rangeEnd),
      completeBackfill: true,
      progress: null
    };
    await persistProgress2(index, wallet, options, enqueue);
    if (rangeEnd >= latest) return;
  }
}
async function refreshTreeBurnIndex(priorValue, walletValues, options = {}) {
  const now = options.now ?? Date.now;
  const generatedAt = new Date(now()).toISOString();
  const prior = validateTreeBurnIndex(priorValue) ? priorValue : null;
  const wallets = normalizeWallets2(walletValues);
  const coverage = {
    latestCheckpoint: null,
    walletsRequested: wallets.length,
    walletsCompleted: 0,
    pagesScanned: 0,
    transactionsScanned: 0,
    treeBurnTransactions: 0,
    duplicateTransactions: 0,
    malformedTransactions: 0,
    retries: 0,
    reachedEnd: false,
    timeLimitReached: false
  };
  if (!wallets.length) {
    return {
      outcome: "error",
      index: null,
      coverage,
      warnings: ["The TREE burn index requires the current ranked wallet set."]
    };
  }
  const getEnv = options.getEnv ?? ((name) => typeof Netlify !== "undefined" ? Netlify.env.get(name) : void 0);
  const creationCheckpointValue = options.creationCheckpoint || getEnv("TREE_TOKEN_CREATION_CHECKPOINT") || TREE_TOKEN_CREATION_CHECKPOINT;
  const creationCheckpoint = parseCheckpoint(creationCheckpointValue);
  if (creationCheckpoint === null || creationCheckpoint < 1) {
    return {
      outcome: "error",
      index: null,
      coverage,
      warnings: ["TREE_TOKEN_CREATION_CHECKPOINT is invalid."]
    };
  }
  const endpoint = options.endpoint || getEnv("SUI_GRAPHQL_URL") || DEFAULT_GRAPHQL_URL2;
  const fetchImpl = options.fetchImpl ?? fetch;
  const pageSize = Math.max(1, Math.min(50, Math.trunc(options.pageSize ?? DEFAULT_PAGE_SIZE2)));
  const maxPages = Math.max(1, Math.min(1e4, Math.trunc(options.maxPagesPerWallet ?? DEFAULT_MAX_PAGES_PER_WALLET)));
  const concurrency = Math.max(1, Math.min(10, Math.trunc(options.concurrency ?? DEFAULT_CONCURRENCY)));
  const maxRetries = Math.max(0, Math.min(8, Math.trunc(options.maxRetries ?? DEFAULT_MAX_RETRIES2)));
  const maxScanMs = Math.max(3e4, Math.trunc(options.maxScanMs ?? DEFAULT_MAX_SCAN_MS2));
  const sleepImpl = options.sleepImpl ?? ((milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)));
  const deadline = Date.now() + maxScanMs;
  let index = null;
  let persistQueue = Promise.resolve();
  const enqueue = async (work) => {
    persistQueue = persistQueue.then(work, work);
    await persistQueue;
  };
  try {
    const latest = await latestCheckpoint2(endpoint, fetchImpl, maxRetries, sleepImpl, coverage, deadline);
    coverage.latestCheckpoint = latest;
    index = copyIndex2(prior, generatedAt, String(creationCheckpoint), wallets);
    let nextWallet = 0;
    let failure = null;
    const worker = async () => {
      while (!failure) {
        const current = nextWallet;
        nextWallet += 1;
        if (current >= wallets.length) return;
        const wallet = wallets[current];
        try {
          await scanWallet(
            index,
            wallet,
            Number(latest),
            endpoint,
            fetchImpl,
            pageSize,
            maxPages,
            maxRetries,
            sleepImpl,
            coverage,
            deadline,
            options,
            enqueue
          );
          coverage.walletsCompleted += 1;
        } catch (error) {
          failure = error instanceof Error ? error : new Error(`Burn history failed for ${wallet}.`);
        }
      }
    };
    await Promise.all(Array.from({ length: Math.min(concurrency, wallets.length) }, () => worker()));
    await persistQueue;
    if (failure) throw failure;
    index.generatedAt = generatedAt;
    index.indexedThroughCheckpoint = latest;
    coverage.reachedEnd = coverage.walletsCompleted === coverage.walletsRequested && wallets.every((wallet) => index.wallets[wallet]?.completeBackfill && index.wallets[wallet]?.progress === null && index.wallets[wallet]?.indexedThroughCheckpoint === latest);
    if (!coverage.reachedEnd || !validateTreeBurnIndex(index)) {
      return {
        outcome: "verification-incomplete",
        index,
        coverage,
        warnings: ["The TREE burn index failed final completeness or integrity validation."]
      };
    }
    return {
      outcome: "complete",
      index,
      coverage,
      warnings: [
        `Burned badges use cumulative TREE credited to the Sui zero address in successful transactions sent by each ranked wallet from checkpoint ${creationCheckpoint}.`,
        "Per-wallet page cursors and accumulated TREE totals are persisted so interrupted backfills resume instead of restarting."
      ]
    };
  } catch (error) {
    await persistQueue;
    const message = error instanceof Error ? error.message : "TREE burn indexing failed.";
    const incomplete = coverage.timeLimitReached || /natural end|deadline|cursor/i.test(message);
    return {
      outcome: incomplete ? "verification-incomplete" : "error",
      index,
      coverage,
      warnings: [message]
    };
  }
}
function burnEvidenceForWallet(index, walletValue) {
  const wallet = normalizeSuiAddress(walletValue);
  const entry = wallet ? index.wallets[wallet] : null;
  if (!entry || !entry.completeBackfill || entry.progress !== null || entry.indexedThroughCheckpoint !== index.indexedThroughCheckpoint) return null;
  const raw = parseUnsignedRaw2(entry.burnedTreeRaw);
  if (raw === null) return null;
  return {
    burnedTreeRaw: raw.toString(),
    burnedTree: formatTreeRaw(raw),
    indexedThroughCheckpoint: entry.indexedThroughCheckpoint,
    qualifies: raw >= BURNED_BADGE_THRESHOLD_RAW
  };
}

// netlify/lib/tree-badge-snapshot-builder.ts
function buildCompleteTreeBadgeSnapshot(input) {
  if (!validateTreeActivityIndex(input.activityIndex) || !validateTreeBurnIndex(input.burnIndex) || input.exposure.outcome !== "complete" || input.exposure.entries.length !== 50 || input.exposure.displayedCount !== 50) return null;
  const wallets = input.exposure.entries.map((entry) => entry.wallet);
  const activity = summarizeTreeActivity(input.activityIndex, wallets);
  const entries = [];
  for (const exposureEntry of input.exposure.entries) {
    const activitySummary = activity[exposureEntry.wallet];
    const burnEvidence = burnEvidenceForWallet(input.burnIndex, exposureEntry.wallet);
    if (!activitySummary || !burnEvidence) return null;
    const activityEvidence = {
      windowStart: input.activityIndex.windowStart,
      windowEnd: input.activityIndex.windowEnd,
      ...activitySummary
    };
    const burn = {
      burnedTreeRaw: burnEvidence.burnedTreeRaw,
      burnedTree: burnEvidence.burnedTree,
      indexedThroughCheckpoint: burnEvidence.indexedThroughCheckpoint
    };
    const badges = expectedBehaviorBadges(activityEvidence, burn);
    if (!badges) return null;
    entries.push({
      rank: exposureEntry.rank,
      wallet: exposureEntry.wallet,
      activity30d: activityEvidence,
      burn,
      badges
    });
  }
  const snapshot = {
    outcome: "complete",
    provider: TREE_BADGE_SNAPSHOT_PROVIDER,
    methodologyVersion: TREE_BADGE_METHODOLOGY_VERSION,
    generatedAt: input.generatedAt || (/* @__PURE__ */ new Date()).toISOString(),
    exposureSnapshotGeneratedAt: input.exposure.generatedAt,
    displayedCount: 50,
    entries,
    source: {
      activity: {
        outcome: "complete",
        methodologyVersion: input.activityIndex.methodologyVersion,
        generatedAt: input.activityIndex.generatedAt,
        windowStart: input.activityIndex.windowStart,
        windowEnd: input.activityIndex.windowEnd,
        poolCount: Object.keys(input.activityIndex.pools).length,
        transactionCount: Object.keys(input.activityIndex.transactions).length,
        warnings: [...input.activityWarnings || []]
      },
      burns: {
        outcome: "complete",
        methodologyVersion: input.burnIndex.methodologyVersion,
        generatedAt: input.burnIndex.generatedAt,
        indexedThroughCheckpoint: input.burnIndex.indexedThroughCheckpoint,
        walletCount: wallets.length,
        warnings: [...input.burnWarnings || []]
      }
    },
    summary: {
      diamondHands: entries.filter((entry) => entry.badges.includes("diamond-hands")).length,
      paperHands: entries.filter((entry) => entry.badges.includes("paper-hands")).length,
      accumulator: entries.filter((entry) => entry.badges.includes("accumulator")).length,
      burned: entries.filter((entry) => entry.badges.includes("burned")).length
    },
    warnings: [...input.activityWarnings || [], ...input.burnWarnings || []]
  };
  return validateCompleteTreeBadgeSnapshot(snapshot) ? snapshot : null;
}

// netlify/lib/tree-badge-background-worker.ts
function enabled(value) {
  return (value || "").trim().toLowerCase() === "true";
}
async function waitForExposure(context, readExposure, sleepImpl, waitMs) {
  const deadline = Date.now() + waitMs;
  do {
    const snapshot = await readExposure(context);
    if (snapshot) return snapshot;
    if (Date.now() >= deadline) break;
    await sleepImpl(5e3);
  } while (true);
  return null;
}
async function runTreeBadgeBackgroundWorker(request, dependencies = {}) {
  if (request.method !== "POST") return { accepted: false, started: false, outcome: "method-not-allowed" };
  const getEnv = dependencies.getEnv ?? ((name) => Netlify.env.get(name));
  const context = dependencies.deployContext || "dev";
  if (context === "production" && !enabled(getEnv("TREE_BADGE_PRODUCTION_ENABLED"))) {
    return { accepted: false, started: false, outcome: "production-disabled" };
  }
  const configuredSecret = getEnv("TREE_BADGE_REFRESH_SECRET") || getEnv("TREE_LEADERBOARD_REFRESH_SECRET") || "";
  const requestSecret = request.headers.get("x-tree-badge-refresh-secret") || request.headers.get("x-tree-refresh-secret") || "";
  if (!configuredSecret || !requestSecret || !timingSafeSecretEqual(configuredSecret, requestSecret)) {
    return { accepted: false, started: false, outcome: "authentication-failed" };
  }
  const now = dependencies.now ?? Date.now;
  const createRunId = dependencies.createRunId ?? randomUUID2;
  const sleepImpl = dependencies.sleepImpl ?? ((milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)));
  const logger = dependencies.logger ?? console;
  const storeOptions = { context, store: dependencies.store };
  const currentLock = await readTreeBadgeRefreshLock(storeOptions);
  if (currentLock && Date.parse(currentLock.expiresAt) > now()) {
    return { accepted: true, started: false, outcome: "already-active" };
  }
  const runId = createRunId();
  const startedMs = now();
  const startedAt = new Date(startedMs).toISOString();
  const commitRef = getEnv("COMMIT_REF") || null;
  const deployId = dependencies.deployId || getEnv("DEPLOY_ID") || null;
  await writeTreeBadgeRefreshLock({
    runId,
    startedAt,
    expiresAt: new Date(startedMs + TREE_BADGE_REFRESH_LOCK_TTL_MS).toISOString(),
    commitRef,
    deployId
  }, storeOptions);
  let status = {
    state: "queued",
    stage: "queued",
    runId,
    startedAt,
    updatedAt: startedAt,
    completedAt: null,
    exposureSnapshotGeneratedAt: null,
    activityOutcome: "pending",
    burnOutcome: "pending",
    displayedCount: 0,
    message: "TREE behavioral badge refresh queued.",
    commitRef,
    deployId
  };
  const saveStatus = async (patch) => {
    status = { ...status, ...patch, updatedAt: new Date(now()).toISOString() };
    await writeTreeBadgeRefreshStatus(status, storeOptions);
  };
  try {
    await writeTreeBadgeRefreshStatus(status, storeOptions);
    await saveStatus({ state: "running", stage: "waiting-for-exposure", message: "Waiting for a complete TREE exposure snapshot." });
    const readExposure = dependencies.readExposure ?? ((deployContext) => readCompleteExposureSnapshot({ context: deployContext }));
    const shouldWaitForExposure = context === "deploy-preview" || enabled(getEnv("TREE_BADGE_AUTO_BOOTSTRAP"));
    const waitMs = shouldWaitForExposure ? 5 * 60 * 1e3 : 0;
    const exposure = await waitForExposure(context, readExposure, sleepImpl, waitMs);
    if (!exposure) {
      await saveStatus({
        state: "verification-incomplete",
        stage: "failed",
        completedAt: new Date(now()).toISOString(),
        message: "A complete exposure snapshot was not available; the prior badge snapshot was preserved."
      });
      return { accepted: true, started: true, outcome: "exposure-not-ready" };
    }
    await saveStatus({ exposureSnapshotGeneratedAt: exposure.generatedAt });
    const rankedWallets = exposure.entries.map((entry) => entry.wallet);
    const priorActivity = await readInternalBadgeValue(TREE_ACTIVITY_INDEX_KEY, storeOptions);
    await saveStatus({ stage: "activity", message: "Refreshing the resumable Sui-native rolling 30-day TREE trade ledger." });
    const refreshActivity = dependencies.refreshActivity ?? refreshTreeActivityIndex;
    const activity = await refreshActivity(priorActivity, {
      getEnv,
      now,
      wallets: rankedWallets,
      onProgress: (index) => writeInternalBadgeValue(TREE_ACTIVITY_INDEX_KEY, index, storeOptions)
    });
    await saveStatus({ activityOutcome: activity.outcome === "complete" ? "complete" : activity.outcome === "error" ? "error" : "verification-incomplete" });
    if (activity.outcome !== "complete" || !activity.index) {
      if (activity.index) await writeInternalBadgeValue(TREE_ACTIVITY_INDEX_KEY, activity.index, storeOptions);
      await saveStatus({
        state: activity.outcome === "error" ? "error" : "verification-incomplete",
        stage: "failed",
        completedAt: new Date(now()).toISOString(),
        message: `Activity index ${activity.outcome}: ${activity.warnings[0] || "No diagnostic was returned."} The prior complete badge snapshot was preserved.`
      });
      return { accepted: true, started: true, outcome: activity.outcome === "error" ? "error" : "verification-incomplete" };
    }
    await writeInternalBadgeValue(TREE_ACTIVITY_INDEX_KEY, activity.index, storeOptions);
    const priorBurns = await readInternalBadgeValue(TREE_BURN_INDEX_KEY, storeOptions);
    await saveStatus({ stage: "burns", message: "Refreshing the page-resumable lifetime TREE burn index for the current Top 50." });
    const refreshBurns = dependencies.refreshBurns ?? refreshTreeBurnIndex;
    const burns = await refreshBurns(
      priorBurns,
      rankedWallets,
      {
        getEnv,
        now,
        sleepImpl,
        onProgress: (index) => writeInternalBadgeValue(TREE_BURN_INDEX_KEY, index, storeOptions)
      }
    );
    await saveStatus({ burnOutcome: burns.outcome === "complete" ? "complete" : burns.outcome === "error" ? "error" : "verification-incomplete" });
    if (burns.outcome !== "complete" || !burns.index) {
      if (burns.index) await writeInternalBadgeValue(TREE_BURN_INDEX_KEY, burns.index, storeOptions);
      await saveStatus({
        state: burns.outcome === "error" ? "error" : "verification-incomplete",
        stage: "failed",
        completedAt: new Date(now()).toISOString(),
        message: `Burn index ${burns.outcome}: ${burns.warnings[0] || "No diagnostic was returned."} The prior complete badge snapshot was preserved.`
      });
      return { accepted: true, started: true, outcome: burns.outcome === "error" ? "error" : "verification-incomplete" };
    }
    await writeInternalBadgeValue(TREE_BURN_INDEX_KEY, burns.index, storeOptions);
    await saveStatus({ stage: "aggregate", message: "Building the complete six-badge Top 50 snapshot." });
    const snapshot = buildCompleteTreeBadgeSnapshot({
      exposure,
      activityIndex: activity.index,
      burnIndex: burns.index,
      activityWarnings: activity.warnings,
      burnWarnings: burns.warnings,
      generatedAt: new Date(now()).toISOString()
    });
    if (!snapshot || !await writeCompleteTreeBadgeSnapshot(snapshot, storeOptions)) {
      await saveStatus({
        state: "verification-incomplete",
        stage: "failed",
        completedAt: new Date(now()).toISOString(),
        message: "Final badge integrity validation failed; the prior complete badge snapshot was preserved."
      });
      return { accepted: true, started: true, outcome: "verification-incomplete" };
    }
    const completedAt = new Date(now()).toISOString();
    await saveStatus({
      state: "complete",
      stage: "complete",
      completedAt,
      displayedCount: snapshot.entries.length,
      message: "Complete verified TREE behavioral badge snapshot stored."
    });
    logger.info("TREE behavioral badge refresh completed.");
    return { accepted: true, started: true, outcome: "complete" };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "TREE badge refresh failed.";
    logger.error(errorMessage);
    await saveStatus({
      state: "error",
      stage: "failed",
      completedAt: new Date(now()).toISOString(),
      message: `TREE badge refresh failed: ${errorMessage} The prior complete badge snapshot was preserved.`
    });
    return { accepted: true, started: true, outcome: "error" };
  } finally {
    await clearTreeBadgeRefreshLock(runId, storeOptions);
  }
}

// netlify/functions/tree-badges-refresh-background.ts
var tree_badges_refresh_background_default = async (request, context) => {
  await runTreeBadgeBackgroundWorker(request, {
    deployContext: context?.deploy?.context || "dev",
    deployId: context?.deploy?.id
  });
};
export {
  tree_badges_refresh_background_default as default
};
