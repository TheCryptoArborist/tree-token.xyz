
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-badge-cache.ts
import { getDeployStore, getStore } from "@netlify/blobs";

// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var TREE_DECIMALS = 6;
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));
function normalizeSuiAddress(value) {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  return SUI_ADDRESS.test(normalized) ? normalized : null;
}

// netlify/lib/sui-graphql-leaderboard-provider.ts
function formatBaseUnits(raw, coinDecimals) {
  const negative = raw < 0n;
  const absolute = negative ? -raw : raw;
  const base = 10n ** BigInt(coinDecimals);
  const whole = absolute / base;
  const fraction = (absolute % base).toString().padStart(coinDecimals, "0").replace(/0+$/, "");
  return `${negative ? "-" : ""}${whole.toString()}${fraction ? `.${fraction}` : ""}`;
}

// netlify/lib/tree-exposure-types.ts
function formatTreeRaw(raw) {
  return formatBaseUnits(raw, TREE_DECIMALS);
}
function parseUnsignedRaw(value) {
  if (typeof value !== "string" || !/^\d+$/.test(value)) return null;
  try {
    return BigInt(value);
  } catch {
    return null;
  }
}

// netlify/lib/tree-badge-types.ts
var TREE_BADGE_METHODOLOGY_VERSION = "verified-tree-behavior-badges-v1";
var TREE_BADGE_SNAPSHOT_PROVIDER = "tree-badge-snapshot";
var DIAMOND_HANDS_BADGE = "diamond-hands";
var PAPER_HANDS_BADGE = "paper-hands";
var ACCUMULATOR_BADGE = "accumulator";
var BURNED_BADGE = "burned";
var BEHAVIOR_BADGE_ORDER = [
  DIAMOND_HANDS_BADGE,
  PAPER_HANDS_BADGE,
  ACCUMULATOR_BADGE,
  BURNED_BADGE
];
var TREE_ACTIVITY_WINDOW_MS = 30 * 24 * 60 * 60 * 1e3;
var TREE_ACTIVITY_MIN_VOLUME_RAW = 100000000000n;
var TREE_ACTIVITY_ACCUMULATOR_BUYS = 10;
var BURNED_BADGE_THRESHOLD_RAW = 500000000000n;
function validDate(value) {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}
function validCount(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function expectedBehaviorBadges(activity, burn) {
  const buyRaw = parseUnsignedRaw(activity.buyTreeRaw);
  const sellRaw = parseUnsignedRaw(activity.sellTreeRaw);
  const burnedRaw = parseUnsignedRaw(burn.burnedTreeRaw);
  if (buyRaw === null || sellRaw === null || burnedRaw === null || !validCount(activity.buyCount) || !validCount(activity.sellCount) || !validDate(activity.windowStart) || !validDate(activity.windowEnd) || Date.parse(activity.windowStart) >= Date.parse(activity.windowEnd) || activity.buyTree !== formatTreeRaw(buyRaw) || activity.sellTree !== formatTreeRaw(sellRaw) || burn.burnedTree !== formatTreeRaw(burnedRaw) || typeof burn.indexedThroughCheckpoint !== "string" || !/^\d+$/.test(burn.indexedThroughCheckpoint)) return null;
  const badges = [];
  if (activity.sellCount === 0) badges.push(DIAMOND_HANDS_BADGE);
  if (sellRaw > buyRaw && sellRaw >= TREE_ACTIVITY_MIN_VOLUME_RAW) badges.push(PAPER_HANDS_BADGE);
  if (activity.buyCount >= TREE_ACTIVITY_ACCUMULATOR_BUYS && buyRaw >= TREE_ACTIVITY_MIN_VOLUME_RAW && buyRaw > sellRaw) badges.push(ACCUMULATOR_BADGE);
  if (burnedRaw >= BURNED_BADGE_THRESHOLD_RAW) badges.push(BURNED_BADGE);
  return badges;
}

// netlify/lib/tree-badge-cache.ts
var TREE_BADGE_STORE_NAME = "tree-leaderboard-badges";
var COMPLETE_TREE_BADGE_SNAPSHOT_KEY = "complete";
var TREE_BADGE_REFRESH_LOCK_TTL_MS = 30 * 60 * 1e3;
var defaultFactories = {
  getStore: (name, options) => getStore(name, options),
  getDeployStore: (name) => getDeployStore(name)
};
function selectTreeBadgeStore(context, factories = defaultFactories) {
  return context === "production" ? factories.getStore(TREE_BADGE_STORE_NAME, { consistency: "strong" }) : factories.getDeployStore(TREE_BADGE_STORE_NAME);
}
function resolveStore(options) {
  return options.store ?? selectTreeBadgeStore(options.context);
}
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function validDate2(value) {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}
function validNonNegativeInteger(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function validateEntry(value, expectedRank) {
  const entry = record(value);
  const wallet = normalizeSuiAddress(entry.wallet);
  if (!wallet || wallet !== entry.wallet || entry.rank !== expectedRank) return false;
  const activity = record(entry.activity30d);
  const burn = record(entry.burn);
  const expected = expectedBehaviorBadges(activity, burn);
  if (!expected || !Array.isArray(entry.badges)) return false;
  return entry.badges.length === expected.length && entry.badges.every((badge, index) => badge === expected[index]);
}
function validateCompleteTreeBadgeSnapshot(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const snapshot = value;
  if (snapshot.outcome !== "complete" || snapshot.provider !== TREE_BADGE_SNAPSHOT_PROVIDER || snapshot.methodologyVersion !== TREE_BADGE_METHODOLOGY_VERSION || !validDate2(snapshot.generatedAt) || !validDate2(snapshot.exposureSnapshotGeneratedAt) || snapshot.displayedCount !== 50 || !Array.isArray(snapshot.entries) || snapshot.entries.length !== 50 || !Array.isArray(snapshot.warnings) || !snapshot.warnings.every((warning) => typeof warning === "string")) return false;
  const wallets = /* @__PURE__ */ new Set();
  const counts = Object.fromEntries(BEHAVIOR_BADGE_ORDER.map((badge) => [badge, 0]));
  for (let index = 0; index < snapshot.entries.length; index += 1) {
    const entry = snapshot.entries[index];
    if (!validateEntry(entry, index + 1) || wallets.has(entry.wallet)) return false;
    wallets.add(entry.wallet);
    for (const badge of entry.badges) counts[badge] += 1;
  }
  const source = record(snapshot.source);
  const activity = record(source.activity);
  const burns = record(source.burns);
  if (activity.outcome !== "complete" || burns.outcome !== "complete" || !validDate2(activity.generatedAt) || !validDate2(activity.windowStart) || !validDate2(activity.windowEnd) || !validNonNegativeInteger(activity.poolCount) || !validNonNegativeInteger(activity.transactionCount) || !Array.isArray(activity.warnings) || !activity.warnings.every((warning) => typeof warning === "string") || !validDate2(burns.generatedAt) || typeof burns.indexedThroughCheckpoint !== "string" || !/^\d+$/.test(burns.indexedThroughCheckpoint) || !validNonNegativeInteger(burns.walletCount) || !Array.isArray(burns.warnings) || !burns.warnings.every((warning) => typeof warning === "string")) return false;
  const summary = record(snapshot.summary);
  return summary.diamondHands === counts["diamond-hands"] && summary.paperHands === counts["paper-hands"] && summary.accumulator === counts.accumulator && summary.burned === counts.burned;
}
async function readCompleteTreeBadgeSnapshot(options = {}) {
  const value = await resolveStore(options).get(COMPLETE_TREE_BADGE_SNAPSHOT_KEY, { type: "json" });
  return validateCompleteTreeBadgeSnapshot(value) ? value : null;
}

// netlify/functions/tree-badges-on-deploy.ts
function enabled(value) {
  return (value || "").trim().toLowerCase() === "true";
}
async function runTreeBadgeDeployBootstrap(event, dependencies = {}) {
  const getEnv = dependencies.getEnv ?? ((name) => Netlify.env.get(name));
  const logger = dependencies.logger ?? console;
  const context = event.deploy.context;
  const isPreview = context === "deploy-preview";
  const isProduction = context === "production";
  if (!isPreview && !isProduction) return { attempted: false, outcome: "skipped-context" };
  if (isPreview) {
    const expectedBranch = (getEnv("TREE_BADGE_PREVIEW_BRANCH") || "").trim();
    if (!expectedBranch || event.deploy.branch !== expectedBranch) {
      return { attempted: false, outcome: "skipped-branch" };
    }
  }
  if (isProduction && !enabled(getEnv("TREE_BADGE_PRODUCTION_ENABLED"))) {
    return { attempted: false, outcome: "disabled" };
  }
  if (!enabled(getEnv("TREE_BADGE_AUTO_BOOTSTRAP"))) {
    return { attempted: false, outcome: "disabled" };
  }
  const readSnapshot = dependencies.readSnapshot ?? ((deployContext) => readCompleteTreeBadgeSnapshot({ context: deployContext }));
  if (await readSnapshot(context)) {
    logger.info(`TREE badge snapshot already exists for ${context} deploy ${event.deploy.id}.`);
    return { attempted: false, outcome: "already-ready" };
  }
  const secret = getEnv("TREE_BADGE_REFRESH_SECRET") || getEnv("TREE_LEADERBOARD_REFRESH_SECRET") || "";
  if (!secret) return { attempted: false, outcome: "missing-secret" };
  const deployUrl = (getEnv("DEPLOY_PRIME_URL") || (isProduction ? getEnv("URL") : "") || event.deploy.url || "").replace(/\/$/, "");
  if (!deployUrl) return { attempted: false, outcome: "missing-deploy-url" };
  const fetchImpl = dependencies.fetchImpl ?? fetch;
  const response = await fetchImpl(`${deployUrl}/.netlify/functions/tree-badges-refresh-background`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "x-tree-badge-refresh-secret": secret
    }
  });
  if (response.status !== 202) {
    logger.error(`TREE badge background trigger returned ${response.status}.`);
    return { attempted: true, outcome: "trigger-failed" };
  }
  logger.info(`TREE badge background refresh accepted for ${context} deploy ${event.deploy.id}.`);
  return { attempted: true, outcome: "accepted" };
}
var tree_badges_on_deploy_default = {
  async deploySucceeded(event) {
    const result = await runTreeBadgeDeployBootstrap(event);
    const failed = result.outcome === "missing-secret" || result.outcome === "missing-deploy-url" || result.outcome === "trigger-failed";
    if (!failed) return;
    if (event.deploy.context === "deploy-preview") {
      throw new Error(`TREE badge preview bootstrap ended with ${result.outcome}.`);
    }
    console.error(`TREE badge production bootstrap ended with ${result.outcome}; scheduled refresh will retry.`);
  }
};
export {
  tree_badges_on_deploy_default as default,
  runTreeBadgeDeployBootstrap
};
