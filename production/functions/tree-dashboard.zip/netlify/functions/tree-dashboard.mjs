
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// data/tree-project-snapshot.json
var tree_project_snapshot_default = {
  snapshotTime: "2026-06-22T19:28:00Z",
  tree: {
    totalSupply: 1e9,
    zeroAddressBalance: 60354124554633e-6,
    effectiveSupply: 939645875445367e-6,
    moonbagsLocked: 54532780688377e-6,
    nextUnlock2027: 34151744570978e-6,
    nextUnlock2027Date: "2027-01-01T06:00:00.000Z",
    nextUnlock2028: 20381036117399e-6,
    nextUnlock2028Date: "2028-01-01T06:00:00.000Z",
    timeLockSource: "Moonbags open TREE lock contracts"
  },
  liquidity: {
    recognizedLiquidityUsd: 14470.62,
    primaryPoolTvlUsd: 14253.64,
    suiDexV3TvlUsd: 7239.79,
    turbosTvlUsd: 5037.42,
    suiDexV2TvlUsd: 1976.43,
    suiDexV2FarmApr: 52.69,
    suiDexV2LpStakedPercent: 94.19
  },
  nftree: {
    mintPriceSui: 25,
    totalMintedOrLoaded: 300,
    holderOwned: 87,
    salePool: 213,
    holderWallets: 28,
    rarity: {
      common: 93,
      rare: 65,
      epic: 32,
      legendary: 17,
      mythic: 6
    }
  }
};

// netlify/lib/tree-dashboard-normalizer.ts
function emptyLive() {
  return {
    price: null,
    priceChange1h: null,
    priceChange24h: null,
    priceChange7d: null,
    volume24h: null,
    liquidity: null,
    marketCap: null,
    fdv: null,
    holderCount: null,
    sourceUpdatedAt: null
  };
}
function record(value) {
  return value && typeof value === "object" ? value : {};
}
function numberFrom(...values) {
  for (const value of values) {
    const parsed = typeof value === "string" ? Number(value.replace(/,/g, "")) : Number(value);
    if (value !== null && value !== void 0 && value !== "" && Number.isFinite(parsed)) return parsed;
  }
  return null;
}

// netlify/lib/coingecko-market.ts
var TREE_COINGECKO_ID = "thickquidity";
function coinGeckoRequestConfig(config2 = {}) {
  const apiKey = (config2.apiKey || "").trim();
  const pro = (config2.plan || "").trim().toLowerCase() === "pro";
  const headers = { Accept: "application/json" };
  if (apiKey) headers[pro ? "x-cg-pro-api-key" : "x-cg-demo-api-key"] = apiKey;
  return {
    baseUrl: pro ? "https://pro-api.coingecko.com/api/v3" : "https://api.coingecko.com/api/v3",
    headers
  };
}
function normalizeCoinGeckoSimplePrice(payload) {
  const tree = record(record(payload)[TREE_COINGECKO_ID]);
  const updated = numberFrom(tree.last_updated_at);
  return {
    ...emptyLive(),
    price: numberFrom(tree.usd),
    priceChange24h: numberFrom(tree.usd_24h_change),
    volume24h: numberFrom(tree.usd_24h_vol),
    marketCap: numberFrom(tree.usd_market_cap),
    fdv: null,
    sourceUpdatedAt: updated ? new Date(updated * 1e3).toISOString() : null
  };
}
async function fetchCoinGeckoTreeMarket(config2 = {}) {
  const requestConfig = coinGeckoRequestConfig(config2);
  const url = new URL(`${requestConfig.baseUrl}/simple/price`);
  url.searchParams.set("ids", TREE_COINGECKO_ID);
  url.searchParams.set("vs_currencies", "usd");
  url.searchParams.set("include_market_cap", "true");
  url.searchParams.set("include_24hr_vol", "true");
  url.searchParams.set("include_24hr_change", "true");
  url.searchParams.set("include_last_updated_at", "true");
  url.searchParams.set("precision", "full");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8e3);
  try {
    const response = await fetch(url, { headers: requestConfig.headers, signal: controller.signal });
    if (!response.ok) throw new Error(`CoinGecko returned ${response.status}`);
    const data = normalizeCoinGeckoSimplePrice(await response.json());
    if (data.price === null || data.marketCap === null) throw new Error("CoinGecko returned incomplete TREE market data.");
    return data;
  } finally {
    clearTimeout(timeout);
  }
}

// netlify/lib/tree-dashboard-cache.ts
import { getStore } from "@netlify/blobs";
var TREE_DASHBOARD_STORE_NAME = "tree-dashboard-market";
var TREE_DASHBOARD_LAST_VERIFIED_KEY = "last-verified-v2-coingecko";
var CORE_MARKET_FIELDS = ["price", "marketCap", "volume24h"];
function defaultStore() {
  return getStore(TREE_DASHBOARD_STORE_NAME, { consistency: "strong" });
}
function hasCoreMarketFields(data) {
  return CORE_MARKET_FIELDS.every((field) => data?.[field] !== null && data?.[field] !== void 0 && Number.isFinite(Number(data[field])));
}
function validCachedTreeMarket(value) {
  if (!value || typeof value !== "object") return false;
  const cached = value;
  return cached.source === "CoinGecko" && Number.isFinite(Date.parse(cached.generatedAt)) && hasCoreMarketFields(cached.data);
}
async function readCachedTreeMarket(store = defaultStore()) {
  const value = await store.get(TREE_DASHBOARD_LAST_VERIFIED_KEY, { type: "json" });
  return validCachedTreeMarket(value) ? value : null;
}
async function writeCachedTreeMarket(snapshot, store = defaultStore()) {
  if (!validCachedTreeMarket(snapshot)) return false;
  await store.setJSON(TREE_DASHBOARD_LAST_VERIFIED_KEY, snapshot);
  return true;
}

// netlify/functions/tree-dashboard.ts
var tree_dashboard_default = async (request) => {
  if (request.method !== "GET") {
    return Response.json({ error: "method-not-allowed" }, { status: 405, headers: { Allow: "GET", "Cache-Control": "no-store" } });
  }
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const warnings = [];
  let cachedMarket = null;
  try {
    cachedMarket = await readCachedTreeMarket();
  } catch (error) {
    warnings.push("The durable market cache is temporarily unavailable.");
    console.error(error);
  }
  let status = "error";
  let liveData = null;
  let verifiedAt = cachedMarket?.generatedAt ?? null;
  try {
    liveData = await fetchCoinGeckoTreeMarket({
      apiKey: Netlify.env.get("COINGECKO_API_KEY") || "",
      plan: Netlify.env.get("COINGECKO_API_PLAN") || "demo"
    });
    status = "ok";
    verifiedAt = liveData.sourceUpdatedAt || generatedAt;
    if (hasCoreMarketFields(liveData)) {
      try {
        await writeCachedTreeMarket({ generatedAt, source: "CoinGecko", data: liveData });
      } catch (error) {
        warnings.push("The latest CoinGecko market snapshot could not be saved.");
        console.error(error);
      }
    }
  } catch (error) {
    console.error("CoinGecko TREE market request failed.", error);
    const lastVerified = cachedMarket;
    if (lastVerified) {
      status = "fallback";
      liveData = lastVerified.data;
      verifiedAt = lastVerified.generatedAt;
      warnings.push(`CoinGecko is temporarily unavailable. Displaying the last verified CoinGecko snapshot from ${lastVerified.generatedAt}.`);
    } else warnings.push("CoinGecko market data is temporarily unavailable.");
  }
  const coverage = Object.fromEntries(Object.entries(liveData ?? emptyLive()).map(([field, value]) => [field, value !== null]));
  return Response.json({
    generatedAt,
    live: { status, source: "CoinGecko", data: liveData, verifiedAt },
    snapshot: tree_project_snapshot_default,
    sources: { displayed: { name: "CoinGecko", status }, market: { name: "CoinGecko", status, coverage, warnings: [...warnings] } },
    coverage,
    warnings
  }, { headers: { "Cache-Control": status === "ok" || status === "fallback" ? "public, max-age=30, s-maxage=60, stale-while-revalidate=120" : "no-store" } });
};
var config = { path: "/api/tree-dashboard" };
export {
  config,
  tree_dashboard_default as default
};
