
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// data/tree-project-snapshot.json
var tree_project_snapshot_default = {
  snapshotTime: "2026-06-22T19:28:00Z",
  tree: {
    totalSupply: 1e9,
    zeroAddressBalance: 60354124554633e-6,
    effectiveSupply: 939645875445367e-6,
    moonbagsLocked: 54532780688377e-6,
    nextUnlock2027: 34151744570978e-6,
    nextUnlock2027Date: "2027-01-01T06:00:00.000Z",
    nextUnlock2028: 20381036117399e-6,
    nextUnlock2028Date: "2028-01-01T06:00:00.000Z",
    timeLockSource: "Moonbags open TREE lock contracts"
  },
  liquidity: {
    recognizedLiquidityUsd: 14470.62,
    primaryPoolTvlUsd: 14253.64,
    suiDexV3TvlUsd: 7239.79,
    turbosTvlUsd: 5037.42,
    suiDexV2TvlUsd: 1976.43,
    suiDexV2FarmApr: 52.69,
    suiDexV2LpStakedPercent: 94.19
  },
  nftree: {
    mintPriceSui: 25,
    totalMintedOrLoaded: 300,
    holderOwned: 87,
    salePool: 213,
    holderWallets: 28,
    rarity: {
      common: 93,
      rare: 65,
      epic: 32,
      legendary: 17,
      mythic: 6
    }
  }
};

// data/tree-market-last-verified.json
var tree_market_last_verified_default = {
  generatedAt: "2026-08-21T21:28:47.928Z",
  source: "Noodles.fi",
  data: {
    price: 234e-7,
    priceChange1h: 0,
    priceChange24h: 12.72,
    priceChange7d: 24.14,
    volume24h: 74.43,
    liquidity: 16443,
    marketCap: 23408,
    fdv: 23408,
    holderCount: 602,
    sourceUpdatedAt: null
  }
};

// netlify/lib/tree-dashboard-cache.ts
import { getStore } from "@netlify/blobs";

// netlify/lib/tree-dashboard-normalizer.ts
function emptyLive() {
  return {
    price: null,
    priceChange1h: null,
    priceChange24h: null,
    priceChange7d: null,
    volume24h: null,
    liquidity: null,
    marketCap: null,
    fdv: null,
    holderCount: null,
    sourceUpdatedAt: null
  };
}
function record(value) {
  return value && typeof value === "object" ? value : {};
}
function numberFrom(...values) {
  for (const value of values) {
    const parsed = typeof value === "string" ? Number(value.replace(/,/g, "")) : Number(value);
    if (value !== null && value !== void 0 && value !== "" && Number.isFinite(parsed)) return parsed;
  }
  return null;
}
function stringFrom(...values) {
  const value = values.find((candidate) => typeof candidate === "string" && candidate.trim());
  return typeof value === "string" ? value : null;
}
function normalizeNoodlesCoinDetails(payload) {
  const root = record(payload);
  const data = record(root.data ?? root);
  const coin = record(data.coin ?? data.market ?? data);
  const changes = record(data.changes ?? coin.changes ?? data.price_change ?? coin.price_change ?? coin.priceChange);
  return {
    price: numberFrom(changes.price, coin.price, data.price, coin.price_usd, coin.priceUsd),
    priceChange1h: numberFrom(changes.price_change_1h, changes.h1, changes["1h"], coin.price_change_1h, coin.priceChange1h),
    priceChange24h: numberFrom(changes.price_change_1d, changes.price_change_24h, changes.h24, changes["24h"], changes.d1, coin.price_change_24h, coin.priceChange24h),
    priceChange7d: numberFrom(changes.price_change_7d, changes.d7, changes["7d"], coin.price_change_7d, coin.priceChange7d),
    volume24h: numberFrom(coin.volume_24h, coin.volume24h, coin.volume_usd_24h, data.volume24h),
    liquidity: numberFrom(coin.liquidity, coin.liquidity_usd, data.liquidity),
    marketCap: numberFrom(coin.market_cap, coin.marketCap, coin.market_cap_usd, data.marketCap),
    fdv: numberFrom(coin.fdv, coin.fully_diluted_valuation, coin.fullyDilutedValuation, data.fdv),
    holderCount: numberFrom(coin.holders, coin.holder_count, coin.holderCount, data.holderCount),
    sourceUpdatedAt: stringFrom(coin.updated_at, coin.updatedAt, data.updated_at, data.updatedAt, root.updatedAt)
  };
}
function normalizeNoodlesPriceVolume(payload) {
  const root = record(payload);
  const data = record(root.data ?? root);
  return {
    price: numberFrom(data.price, root.price),
    priceChange24h: numberFrom(data.price_change_24h, root.price_change_24h),
    volume24h: numberFrom(data.volume_24h, root.volume_24h)
  };
}
function mergeNoodlesFields(details, priceVolume) {
  const merged = details ? { ...details } : emptyLive();
  if (priceVolume) {
    merged.price = merged.price ?? priceVolume.price;
    merged.priceChange24h = merged.priceChange24h ?? priceVolume.priceChange24h;
    merged.volume24h = priceVolume.volume24h ?? merged.volume24h;
  }
  return merged;
}

// netlify/lib/tree-dashboard-cache.ts
var TREE_DASHBOARD_STORE_NAME = "tree-dashboard-market";
var TREE_DASHBOARD_LAST_VERIFIED_KEY = "last-verified-v1";
var CORE_MARKET_FIELDS = ["price", "marketCap", "liquidity", "holderCount"];
function defaultStore() {
  return getStore(TREE_DASHBOARD_STORE_NAME, { consistency: "strong" });
}
function hasCoreMarketFields(data) {
  return CORE_MARKET_FIELDS.every((field) => data?.[field] !== null && data?.[field] !== void 0 && Number.isFinite(Number(data[field])));
}
function mergeLiveFields(primary, fallback) {
  const merged = emptyLive();
  for (const field of Object.keys(merged)) {
    const value = primary?.[field];
    merged[field] = value !== null && value !== void 0 ? value : fallback?.[field] ?? null;
  }
  return merged;
}
function validCachedTreeMarket(value) {
  if (!value || typeof value !== "object") return false;
  const cached = value;
  return cached.source === "Noodles.fi" && Number.isFinite(Date.parse(cached.generatedAt)) && hasCoreMarketFields(cached.data);
}
async function readCachedTreeMarket(store = defaultStore()) {
  const value = await store.get(TREE_DASHBOARD_LAST_VERIFIED_KEY, { type: "json" });
  return validCachedTreeMarket(value) ? value : null;
}
async function writeCachedTreeMarket(snapshot, store = defaultStore()) {
  if (!validCachedTreeMarket(snapshot)) return false;
  await store.setJSON(TREE_DASHBOARD_LAST_VERIFIED_KEY, snapshot);
  return true;
}

// netlify/functions/tree-dashboard.ts
var noodlesHeaders = (apiKey) => ({ Accept: "application/json", "x-api-key": apiKey, "x-chain": "sui" });
async function requestJson(url, apiKey, label) {
  const response = await fetch(url, { headers: noodlesHeaders(apiKey) });
  if (!response.ok) throw new Error(`${label} returned ${response.status}`);
  return response.json();
}
function coinIdFromDetailsUrl(apiUrl) {
  try {
    return new URL(apiUrl).searchParams.get("coin_id");
  } catch {
    return null;
  }
}
function priceVolumeUrl(coinId) {
  const url = new URL("https://api.noodles.fi/api/v1/partner/coin-price-volume");
  url.searchParams.set("coin_id", coinId);
  return url.href;
}
async function getCoinGecko(apiKey, plan) {
  const pro = plan.toLowerCase() === "pro";
  const base = pro ? "https://pro-api.coingecko.com/api/v3" : "https://api.coingecko.com/api/v3";
  const keyHeader = pro ? "x-cg-pro-api-key" : "x-cg-demo-api-key";
  const url = `${base}/coins/thickquidity?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false`;
  const response = await fetch(url, { headers: { Accept: "application/json", [keyHeader]: apiKey } });
  if (!response.ok) throw new Error(`CoinGecko returned ${response.status}`);
  const payload = record(await response.json());
  const market = record(payload.market_data);
  return {
    ...emptyLive(),
    price: numberFrom(record(market.current_price).usd),
    priceChange24h: numberFrom(market.price_change_percentage_24h),
    volume24h: numberFrom(record(market.total_volume).usd),
    marketCap: numberFrom(record(market.market_cap).usd),
    fdv: numberFrom(record(market.fully_diluted_valuation).usd),
    sourceUpdatedAt: stringFrom(market.last_updated, payload.last_updated)
  };
}
var tree_dashboard_default = async (request) => {
  if (request.method !== "GET") {
    return Response.json({ error: "method-not-allowed" }, { status: 405, headers: { Allow: "GET", "Cache-Control": "no-store" } });
  }
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const noodlesKey = Netlify.env.get("NOODLES_API_KEY") || "";
  const noodlesUrl = Netlify.env.get("NOODLES_API_URL") || "";
  const coinGeckoKey = Netlify.env.get("COINGECKO_API_KEY") || "";
  const coinGeckoPlan = Netlify.env.get("COINGECKO_API_PLAN") || "demo";
  const coinId = noodlesUrl ? coinIdFromDetailsUrl(noodlesUrl) : null;
  const warnings = [];
  let details = null;
  let volume = null;
  let crossCheck = null;
  let detailsStatus = "not-configured";
  let volumeStatus = "not-configured";
  let coinGeckoStatus = "not-configured";
  const detailsTask = noodlesKey && noodlesUrl ? requestJson(noodlesUrl, noodlesKey, "Noodles Coin Details").then((payload) => {
    details = normalizeNoodlesCoinDetails(payload);
    detailsStatus = "ok";
  }).catch((error) => {
    detailsStatus = "error";
    warnings.push("Noodles Coin Details is temporarily unavailable.");
    console.error(error);
  }) : Promise.resolve(warnings.push("Noodles Coin Details is not configured.")).then(() => void 0);
  const volumeTask = noodlesKey && coinId ? requestJson(priceVolumeUrl(coinId), noodlesKey, "Noodles Coin Price Volume").then((payload) => {
    volume = normalizeNoodlesPriceVolume(payload);
    volumeStatus = "ok";
  }).catch((error) => {
    volumeStatus = "error";
    warnings.push("Noodles Coin Price Volume is temporarily unavailable.");
    console.error(error);
  }) : Promise.resolve(warnings.push(noodlesKey ? "Noodles Coin Price Volume could not derive coin_id from NOODLES_API_URL." : "Noodles Coin Price Volume is not configured.")).then(() => void 0);
  const coinGeckoTask = coinGeckoKey ? getCoinGecko(coinGeckoKey, coinGeckoPlan).then((value) => {
    crossCheck = value;
    coinGeckoStatus = "ok";
  }).catch((error) => {
    coinGeckoStatus = "error";
    warnings.push("CoinGecko cross-check is temporarily unavailable.");
    console.error(error);
  }) : Promise.resolve();
  await Promise.all([detailsTask, volumeTask, coinGeckoTask]);
  const noodlesSucceeded = detailsStatus === "ok" || volumeStatus === "ok";
  const noodlesData = mergeNoodlesFields(details, volume);
  const seededMarket = validCachedTreeMarket(tree_market_last_verified_default) ? tree_market_last_verified_default : null;
  let cachedMarket = null;
  try {
    cachedMarket = await readCachedTreeMarket();
  } catch (error) {
    warnings.push("The durable market cache is temporarily unavailable.");
    console.error(error);
  }
  const lastVerified = cachedMarket ?? seededMarket;
  let status;
  let source;
  let liveData;
  let verifiedAt = lastVerified?.generatedAt ?? null;
  if (noodlesSucceeded && hasCoreMarketFields(noodlesData)) {
    status = "ok";
    source = "Noodles.fi";
    liveData = noodlesData;
    verifiedAt = generatedAt;
    try {
      await writeCachedTreeMarket({ generatedAt, source: "Noodles.fi", data: noodlesData });
    } catch (error) {
      warnings.push("The latest verified market snapshot could not be saved.");
      console.error(error);
    }
  } else if (noodlesSucceeded && lastVerified) {
    status = "fallback";
    source = "Noodles.fi";
    liveData = mergeLiveFields(noodlesData, lastVerified.data);
    warnings.push("Displaying available live Noodles fields with the last verified market snapshot.");
  } else if (coinGeckoStatus === "ok" && crossCheck) {
    status = "fallback";
    source = "CoinGecko";
    liveData = lastVerified ? mergeLiveFields(crossCheck, lastVerified.data) : crossCheck;
    warnings.push(lastVerified ? "Displaying current CoinGecko fields with the last verified Noodles market snapshot." : "Displaying CoinGecko fallback fields; holder count and recognized protocol liquidity are unavailable.");
  } else if (lastVerified) {
    status = "fallback";
    source = "Noodles.fi";
    liveData = lastVerified.data;
    warnings.push(`Displaying the last verified market snapshot from ${lastVerified.generatedAt} because the live provider is temporarily unavailable.`);
  } else {
    const anyConfigured = Boolean(noodlesKey || coinGeckoKey);
    status = anyConfigured ? "error" : "not-configured";
    source = null;
    liveData = null;
    verifiedAt = null;
  }
  if (noodlesData.price !== null && crossCheck?.price !== null && crossCheck?.price !== void 0) {
    const difference = Math.abs(noodlesData.price - crossCheck.price) / Math.max(noodlesData.price, crossCheck.price) * 100;
    if (difference > 3) warnings.push(`Noodles and CoinGecko prices differ by ${difference.toFixed(2)}%.`);
  }
  const coverageFor = (data, fields) => Object.fromEntries(fields.map((field) => [field, data?.[field] !== null && data?.[field] !== void 0]));
  const sourceWarnings = (statusValue, missing, failed) => statusValue === "not-configured" ? [missing] : statusValue === "error" ? [failed] : [];
  return Response.json({
    generatedAt,
    live: { status, source, data: liveData, verifiedAt },
    snapshot: tree_project_snapshot_default,
    sources: {
      displayed: { name: source, status },
      noodlesCoinDetails: {
        name: "Noodles.fi Coin Details",
        status: detailsStatus,
        coverage: coverageFor(details, ["price", "priceChange1h", "priceChange24h", "priceChange7d", "liquidity", "marketCap", "fdv", "holderCount", "sourceUpdatedAt"]),
        warnings: sourceWarnings(detailsStatus, "Noodles Coin Details is not configured.", "Noodles Coin Details is temporarily unavailable.")
      },
      noodlesPriceVolume: {
        name: "Noodles.fi Coin Price Volume",
        status: volumeStatus,
        coverage: coverageFor(volume, ["price", "priceChange24h", "volume24h"]),
        warnings: sourceWarnings(volumeStatus, "Noodles Coin Price Volume is not configured.", "Noodles Coin Price Volume is temporarily unavailable.")
      },
      crossCheck: {
        name: "CoinGecko",
        status: coinGeckoStatus,
        data: crossCheck,
        coverage: coverageFor(crossCheck, ["price", "priceChange24h", "volume24h", "marketCap", "fdv", "sourceUpdatedAt"]),
        warnings: sourceWarnings(coinGeckoStatus, "CoinGecko cross-check is not configured.", "CoinGecko cross-check is temporarily unavailable.")
      }
    },
    coverage: Object.fromEntries(Object.entries(liveData ?? emptyLive()).map(([field, value]) => [field, value !== null])),
    warnings
  }, {
    headers: { "Cache-Control": status === "ok" || status === "fallback" ? "public, max-age=30, s-maxage=60, stale-while-revalidate=120" : "no-store" }
  });
};
var config = { path: "/api/tree-dashboard" };
export {
  config,
  tree_dashboard_default as default
};
