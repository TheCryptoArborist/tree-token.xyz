
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-raffle-core.ts
var TREE_RAFFLE_RULES_VERSION = "canopy-draw-proposal-v2";
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_RAFFLE_WBTC_TYPE = "0xaafb102dd0902f5055cadecd687fb5b71ca82ef0e0285d90afde828ec58ca96b::btc::BTC";
var TREE_RAFFLE_DAILY_PRIZE = Object.freeze({
  symbol: "TREE",
  coinType: TREE_COIN_TYPE,
  amountRaw: "50000000000",
  decimals: 6
});
var TREE_RAFFLE_DAILY_LUCKY_LEAF_PLAN = Object.freeze({
  symbol: "wBTC",
  coinType: TREE_RAFFLE_WBTC_TYPE,
  decimals: 8,
  mondayThroughSaturdayUsdCents: 250,
  sundayUsdCents: 1e3,
  weeklyBudgetUsdCents: 2500
});
var TREE_RAFFLE_STREAK_MULTIPLIERS_BASIS_POINTS = Object.freeze([
  1e4,
  11e3,
  12500,
  14e3,
  15e3,
  16e3,
  17500,
  18500,
  19500,
  2e4,
  21e3,
  22e3,
  23e3,
  24e3,
  25e3
]);
var TREE_RAFFLE_RULES = Object.freeze({
  version: TREE_RAFFLE_RULES_VERSION,
  status: "development",
  acceptingEntries: false,
  claimsEnabled: false,
  prizesFunded: false,
  dailyEnabled: true,
  dailyLuckyLeafEnabled: false,
  weeklyEnabled: false,
  minimumQualifyingUsdCents: 500,
  ticketExponent: 0.9457,
  ticketCoefficient: 0.288368,
  luckyLeafTicketsPerQualifyingTransaction: 1,
  maxStreakDays: 15,
  maxStreakMultiplierBasisPoints: 25e3,
  streakMultipliersBasisPoints: TREE_RAFFLE_STREAK_MULTIPLIERS_BASIS_POINTS,
  milestoneBonusUsdCents: Object.freeze({ 7: 5e3, 15: 2e4 }),
  schedule: Object.freeze({
    timezone: "America/New_York",
    daily: "10:00",
    weekly: "Sunday 10:05"
  }),
  prizes: Object.freeze({
    dailyMain: TREE_RAFFLE_DAILY_PRIZE,
    dailyLuckyLeafPlan: TREE_RAFFLE_DAILY_LUCKY_LEAF_PLAN,
    weeklyMain: null,
    weeklyLuckyLeaf: null
  }),
  eligibleTransaction: Object.freeze({
    network: "sui-mainnet",
    direction: "SUI_TO_TREE",
    requiresSuccessfulFinalizedTransaction: true,
    allowlistedRoutesRequired: true
  })
});

// netlify/lib/tree-raffle-sui-draw.ts
var SUI_ID = /^0x[0-9a-fA-F]{1,64}$/;
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var SUI_DIGEST = /^[1-9A-HJ-NP-Za-km-z]{40,64}$/;
var U64_MAX = 18446744073709551615n;
function suiId(value, label) {
  if (!SUI_ID.test(value)) throw new Error(`Invalid TREE raffle ${label}.`);
  return value.toLowerCase();
}
function u64(value, label) {
  if (!/^(0|[1-9][0-9]*)$/.test(value)) throw new Error(`Invalid TREE raffle ${label}.`);
  const parsed = BigInt(value);
  if (parsed > U64_MAX) throw new Error(`Invalid TREE raffle ${label}.`);
  return parsed;
}
function byteArray(value, label) {
  if (Array.isArray(value) && !value.some((byte) => !Number.isInteger(byte) || byte < 0 || byte > 255)) {
    return value;
  }
  if (typeof value === "string" && value.length > 0 && value.length % 4 === 0 && /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) {
    try {
      return [...atob(value)].map((character) => character.charCodeAt(0));
    } catch {
    }
  }
  throw new Error(`Sui returned an invalid TREE raffle ${label}.`);
}
function normalizedSuiId(value) {
  return `0x${value.slice(2).toLowerCase().replace(/^0+/, "") || "0"}`;
}
function verifyTreeRaffleClaimTransaction(input) {
  const tx = input.transaction;
  const digest = tx?.digest ?? tx?.transaction?.digest;
  const status = tx?.effects?.status?.status ?? tx?.effects?.status ?? tx?.transaction?.effects?.status?.status;
  if (!SUI_DIGEST.test(String(digest || "")) || status !== "success") {
    throw new Error("TREE raffle claim transaction did not finalize successfully.");
  }
  if (!SUI_ADDRESS.test(input.wallet) || !input.tokenType.includes("::")) {
    throw new Error("Invalid TREE raffle expected claim values.");
  }
  const expectedAmount = u64(input.amountRaw, "prize amount");
  const packageId = normalizedSuiId(suiId(input.packageId, "package ID"));
  const events = Array.isArray(tx?.events) ? tx.events : [];
  const matches = events.filter((event2) => {
    const type = String(event2?.type || "");
    const separator = type.indexOf("::");
    if (separator < 0) return false;
    const eventPackage = type.slice(0, separator);
    return SUI_ID.test(eventPackage) && normalizedSuiId(eventPackage) === packageId && type.slice(separator) === `::prize_pool::PrizeClaimed<${input.tokenType}>`;
  });
  if (matches.length !== 1) throw new Error("Sui returned an invalid TREE raffle claim event count.");
  const event = matches[0].json ?? matches[0].parsedJson;
  if (!event || typeof event !== "object") throw new Error("Sui returned malformed TREE raffle claim data.");
  const drawId2 = new TextDecoder().decode(Uint8Array.from(byteArray(event.draw_id, "claim draw ID")));
  const amount = u64(String(event.amount), "claimed amount");
  if (drawId2 !== input.onchainDrawId || String(event.winner).toLowerCase() !== input.wallet || amount !== expectedAmount) {
    throw new Error("Sui TREE raffle claim event does not match the recorded prize.");
  }
  return { digest: String(digest), wallet: input.wallet, amountRaw: amount.toString() };
}

// netlify/lib/tree-raffle-claim.ts
var SUI_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var SUI_ADDRESS2 = /^0x[0-9a-f]{64}$/;
var SUI_DIGEST2 = /^[1-9A-HJ-NP-Za-km-z]{40,64}$/;
var TREE_RAFFLE_CLAIM_QUERY = `query TreeRaffleClaim($digest: String!) {
  transaction(digest: $digest) {
    digest
    sender { address }
    effects {
      status
      events(first: 10) {
        pageInfo { hasNextPage }
        nodes { contents { type { repr } json } }
      }
    }
  }
}`;
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
async function fetchFinalizedTreeRaffleClaim(digest, options = {}) {
  if (!SUI_DIGEST2.test(digest)) throw new Error("A valid Sui transaction digest is required.");
  const response = await (options.fetchImpl ?? fetch)(options.endpoint ?? SUI_GRAPHQL_URL, {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ query: TREE_RAFFLE_CLAIM_QUERY, variables: { digest } }),
    signal: AbortSignal.timeout(options.timeoutMs ?? 8e3)
  });
  if (!response.ok) throw new Error(`Sui claim verification returned ${response.status}.`);
  const payload = record(await response.json());
  if (Array.isArray(payload.errors) && payload.errors.length) throw new Error("Sui claim verification returned a GraphQL error.");
  const transaction = record(record(payload.data).transaction);
  const effects = record(transaction.effects);
  const events = record(effects.events);
  const sender = String(record(transaction.sender).address || "").toLowerCase();
  if (transaction.digest !== digest || !SUI_ADDRESS2.test(sender) || String(effects.status || "").toLowerCase() !== "success" || record(events.pageInfo).hasNextPage === true || !Array.isArray(events.nodes)) {
    throw new Error("The Sui raffle claim was not found, successful, or complete.");
  }
  const parsedEvents = events.nodes.map((node) => {
    const contents = record(record(node).contents);
    return { type: String(record(contents.type).repr || ""), json: record(contents.json) };
  });
  return { digest, sender, effects: { status: "success" }, events: parsedEvents };
}

// netlify/lib/tree-knowledge-trial-correction.ts
var SEPTEMBER_22_CORRECTION = Object.freeze({
  incidentId: "knowledge:2026-09-22:display-correction",
  originalRoundId: "knowledge:2026-09-22",
  originalDrawId: "knowledge:2026-09-22:award",
  originalClaimDigest: "Ej9Wyaf8fWyLUf9sBAwu65wn2QWaVZYWkeY5DtfqyRvA",
  onchainDrawId: "knowledge:2026-09-22:correction",
  wallet: "0x18d72fc2a3df6d92d0806da3b04d92be056e2d6d35882a56c16ddb25f48d35d6",
  tokenType: "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE",
  amountRaw: "49000000000"
});
var SUI_GRAPHQL_URL2 = "https://graphql.mainnet.sui.io/graphql";
var SUI_ADDRESS3 = /^0x[0-9a-f]{64}$/;
var SUI_DIGEST3 = /^[1-9A-HJ-NP-Za-km-z]{40,64}$/;
var CORRECTION_EVENTS_QUERY = `query ChallengeCorrectionEvents($type: String!, $before: String) {
  events(last: 50, before: $before, filter: { type: $type }) {
    pageInfo { hasPreviousPage startCursor }
    nodes { transaction { digest } contents { type { repr } json } }
  }
}`;
function record2(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function json(body, status = 200) {
  return Response.json(body, {
    status,
    headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "X-Robots-Tag": "noindex" }
  });
}
function bytes(value) {
  if (Array.isArray(value) && !value.some((byte) => !Number.isInteger(byte) || byte < 0 || byte > 255)) {
    return value;
  }
  if (typeof value === "string" && value.length > 0 && value.length % 4 === 0 && /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) {
    try {
      return [...atob(value)].map((character) => character.charCodeAt(0));
    } catch {
    }
  }
  throw new Error("Sui returned an invalid correction draw ID.");
}
function drawId(value) {
  return new TextDecoder().decode(Uint8Array.from(bytes(value)));
}
function matchingEvent(event, expectedType, correction = SEPTEMBER_22_CORRECTION) {
  const amount = String(event.json.amount || "");
  return event.type === expectedType && drawId(event.json.draw_id) === correction.onchainDrawId && String(event.json.winner || "").toLowerCase() === correction.wallet && amount === correction.amountRaw;
}
async function fetchEvents(eventType, dependencies) {
  if (dependencies.readEvents) return dependencies.readEvents(eventType);
  const fetchImpl = dependencies.fetchImpl ?? fetch;
  const events = [];
  let before = null;
  for (let page = 0; page < 10; page += 1) {
    const response = await fetchImpl(SUI_GRAPHQL_URL2, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({ query: CORRECTION_EVENTS_QUERY, variables: { type: eventType, before } }),
      signal: AbortSignal.timeout(8e3)
    });
    if (!response.ok) throw new Error(`Sui correction lookup returned ${response.status}.`);
    const payload = record2(await response.json());
    if (Array.isArray(payload.errors) && payload.errors.length) throw new Error("Sui correction lookup returned a GraphQL error.");
    const connection = record2(record2(payload.data).events);
    if (!Array.isArray(connection.nodes)) throw new Error("Sui returned malformed correction events.");
    for (const nodeValue of connection.nodes) {
      const node = record2(nodeValue);
      const contents = record2(node.contents);
      events.push({
        digest: String(record2(node.transaction).digest || ""),
        type: String(record2(contents.type).repr || ""),
        json: record2(contents.json)
      });
    }
    const pageInfo = record2(connection.pageInfo);
    if (pageInfo.hasPreviousPage !== true) break;
    const previous = String(pageInfo.startCursor || "");
    if (!previous || previous === before) throw new Error("Sui correction lookup returned an invalid cursor.");
    before = previous;
  }
  return events;
}
async function readSupplementalCorrection(dependencies = {}) {
  const env = dependencies.env ?? process.env;
  const packageId = String(env.TREE_RAFFLE_PACKAGE_ID || "").toLowerCase();
  if (!/^0x[0-9a-f]{64}$/.test(packageId)) throw new Error("The Challenge package is not configured.");
  const registeredType = `${packageId}::prize_pool::WinnerRegistered<${SEPTEMBER_22_CORRECTION.tokenType}>`;
  const claimedType = `${packageId}::prize_pool::PrizeClaimed<${SEPTEMBER_22_CORRECTION.tokenType}>`;
  const [claimEvents, registrationEvents] = await Promise.all([
    fetchEvents(claimedType, dependencies),
    fetchEvents(registeredType, dependencies)
  ]);
  const claims = claimEvents.filter((event) => matchingEvent(event, claimedType));
  const registrations = registrationEvents.filter((event) => matchingEvent(event, registeredType));
  if (claims.length > 1 || registrations.length > 1) throw new Error("Sui returned conflicting correction events.");
  const claim = claims[0] ?? null;
  const registration = registrations[0] ?? null;
  const status = claim ? "claimed" : registration ? "claimable" : "pending-registration";
  return {
    ...SEPTEMBER_22_CORRECTION,
    status,
    claimable: status === "claimable",
    claimed: status === "claimed",
    registerTxDigest: registration?.digest || null,
    claimTxDigest: claim?.digest || null
  };
}
function createTreeKnowledgeTrialCorrectionHandler(dependencies = {}) {
  const env = dependencies.env ?? process.env;
  return async (request) => {
    if (request.method === "GET") {
      try {
        return json({ status: "ok", correction: await readSupplementalCorrection(dependencies) });
      } catch (error) {
        console.error("TREE Challenge correction lookup failed", error);
        return json({ status: "error", error: "correction-unavailable" }, 503);
      }
    }
    if (request.method !== "POST") return json({ status: "error", error: "method-not-allowed" }, 405);
    let digest = "";
    let wallet = "";
    try {
      const body = await request.json();
      if (!body || typeof body !== "object" || Array.isArray(body) || Object.keys(body).length !== 2 || typeof body.digest !== "string" || typeof body.wallet !== "string") throw new Error("invalid");
      digest = body.digest.trim();
      wallet = body.wallet.trim().toLowerCase();
      if (!SUI_DIGEST3.test(digest) || !SUI_ADDRESS3.test(wallet) || wallet !== SEPTEMBER_22_CORRECTION.wallet) throw new Error("invalid");
    } catch {
      return json({ status: "error", error: "invalid-request" }, 400);
    }
    try {
      const transaction = await (dependencies.fetchClaim ?? fetchFinalizedTreeRaffleClaim)(digest);
      if (transaction.sender !== wallet) throw new Error("The correction claim sender does not match the approved wallet.");
      const verified = verifyTreeRaffleClaimTransaction({
        transaction,
        packageId: env.TREE_RAFFLE_PACKAGE_ID || "",
        onchainDrawId: SEPTEMBER_22_CORRECTION.onchainDrawId,
        wallet,
        tokenType: SEPTEMBER_22_CORRECTION.tokenType,
        amountRaw: SEPTEMBER_22_CORRECTION.amountRaw
      });
      return json({ status: "ok", outcome: "verified", wallet, digest: verified.digest });
    } catch (error) {
      console.error("TREE Challenge correction claim verification failed", error);
      return json({ status: "error", error: "verification-failed" }, 422);
    }
  };
}

// netlify/functions/tree-knowledge-trial-correction.ts
var ENVIRONMENT_KEYS = [
  "TREE_RAFFLE_PACKAGE_ID",
  "TREE_RAFFLE_PRIZE_POOL_ID"
];
function runtimeEnvironment() {
  const netlify = globalThis.Netlify;
  return Object.fromEntries(ENVIRONMENT_KEYS.map((key) => [
    key,
    netlify?.env?.get?.(key) ?? process.env[key]
  ]));
}
var tree_knowledge_trial_correction_default = (request) => createTreeKnowledgeTrialCorrectionHandler({
  env: runtimeEnvironment()
})(request);
var config = { path: "/api/tree-knowledge-trial-correction" };
export {
  config,
  tree_knowledge_trial_correction_default as default
};
