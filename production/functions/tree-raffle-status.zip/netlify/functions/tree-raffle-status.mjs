
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-raffle-core.ts
var TREE_RAFFLE_RULES_VERSION = "canopy-draw-proposal-v2";
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_RAFFLE_WBTC_TYPE = "0xaafb102dd0902f5055cadecd687fb5b71ca82ef0e0285d90afde828ec58ca96b::btc::BTC";
var TREE_RAFFLE_DAILY_PRIZE = Object.freeze({
  symbol: "TREE",
  coinType: TREE_COIN_TYPE,
  amountRaw: "50000000000",
  decimals: 6
});
var TREE_RAFFLE_DAILY_LUCKY_LEAF_PLAN = Object.freeze({
  symbol: "wBTC",
  coinType: TREE_RAFFLE_WBTC_TYPE,
  decimals: 8,
  mondayThroughSaturdayUsdCents: 250,
  sundayUsdCents: 1e3,
  weeklyBudgetUsdCents: 2500
});
var TREE_RAFFLE_STREAK_MULTIPLIERS_BASIS_POINTS = Object.freeze([
  1e4,
  11e3,
  12500,
  14e3,
  15e3,
  16e3,
  17500,
  18500,
  19500,
  2e4,
  21e3,
  22e3,
  23e3,
  24e3,
  25e3
]);
var TREE_RAFFLE_RULES = Object.freeze({
  version: TREE_RAFFLE_RULES_VERSION,
  status: "development",
  acceptingEntries: false,
  claimsEnabled: false,
  prizesFunded: false,
  dailyEnabled: true,
  dailyLuckyLeafEnabled: false,
  weeklyEnabled: false,
  minimumQualifyingUsdCents: 500,
  ticketExponent: 0.9457,
  ticketCoefficient: 0.288368,
  luckyLeafTicketsPerQualifyingTransaction: 1,
  maxStreakDays: 15,
  maxStreakMultiplierBasisPoints: 25e3,
  streakMultipliersBasisPoints: TREE_RAFFLE_STREAK_MULTIPLIERS_BASIS_POINTS,
  milestoneBonusUsdCents: Object.freeze({ 7: 5e3, 15: 2e4 }),
  schedule: Object.freeze({
    timezone: "America/New_York",
    daily: "10:00",
    weekly: "Sunday 10:05"
  }),
  prizes: Object.freeze({
    dailyMain: TREE_RAFFLE_DAILY_PRIZE,
    dailyLuckyLeafPlan: TREE_RAFFLE_DAILY_LUCKY_LEAF_PLAN,
    weeklyMain: null,
    weeklyLuckyLeaf: null
  }),
  eligibleTransaction: Object.freeze({
    network: "sui-mainnet",
    direction: "SUI_TO_TREE",
    requiresSuccessfulFinalizedTransaction: true,
    allowlistedRoutesRequired: true
  })
});
function parseBooleanEnv(value, fallback = false) {
  if (value === void 0 || value === null) return fallback;
  const normalized = String(value).trim().toLowerCase();
  return normalized === "1" || normalized === "true" || normalized === "yes" || normalized === "on";
}
function treeRaffleRulesForEnvironment(env = process.env) {
  return {
    ...TREE_RAFFLE_RULES,
    acceptingEntries: parseBooleanEnv(env.TREE_RAFFLE_ACCEPTING_ENTRIES, TREE_RAFFLE_RULES.acceptingEntries),
    claimsEnabled: parseBooleanEnv(env.TREE_RAFFLE_CLAIMS_ENABLED, TREE_RAFFLE_RULES.claimsEnabled),
    prizesFunded: parseBooleanEnv(env.TREE_RAFFLE_PRIZES_FUNDED, TREE_RAFFLE_RULES.prizesFunded),
    dailyEnabled: parseBooleanEnv(env.TREE_RAFFLE_DAILY_ENABLED, TREE_RAFFLE_RULES.dailyEnabled),
    dailyLuckyLeafEnabled: parseBooleanEnv(
      env.TREE_RAFFLE_DAILY_LUCKY_ENABLED,
      TREE_RAFFLE_RULES.dailyLuckyLeafEnabled
    ),
    weeklyEnabled: parseBooleanEnv(env.TREE_RAFFLE_WEEKLY_ENABLED, TREE_RAFFLE_RULES.weeklyEnabled)
  };
}
function raffleLaunchBlockers(rules = TREE_RAFFLE_RULES) {
  const blockers = [
    !rules.prizesFunded && "The prize pool must be funded and prizes reserved before rounds open.",
    !rules.claimsEnabled && "The prize claim path is disabled.",
    !rules.acceptingEntries && "Entry recording is disabled."
  ];
  return blockers.filter((value) => Boolean(value));
}
function raffleOperationalReadiness(env = process.env, rules = treeRaffleRulesForEnvironment(env)) {
  const transactionalLedgerConfigured = Boolean(
    (env.TREE_RAFFLE_SUPABASE_URL || "").trim() && (env.TREE_RAFFLE_SUPABASE_SECRET_KEY || "").trim()
  );
  const onchainPrizePoolConfigured = Boolean(
    (env.TREE_RAFFLE_PACKAGE_ID || "").trim() && (env.TREE_RAFFLE_PRIZE_POOL_ID || "").trim() && (env.TREE_RAFFLE_OPERATOR_CAP_ID || "").trim()
  );
  const drawExecutorConfigured = env.TREE_RAFFLE_DRAW_EXECUTOR_READY === "true" && onchainPrizePoolConfigured;
  const verifiedBuyIngestionEnabled = Boolean(
    env.TREE_RAFFLE_INGEST_ENABLED === "true" && (rules.dailyEnabled || rules.weeklyEnabled) && rules.acceptingEntries && rules.claimsEnabled && rules.prizesFunded && transactionalLedgerConfigured && drawExecutorConfigured
  );
  const infrastructureBlockers = [
    !transactionalLedgerConfigured && "The transactional raffle ledger is not connected.",
    !onchainPrizePoolConfigured && "The on-chain prize pool is not published and configured.",
    !drawExecutorConfigured && "The verifiable draw executor is not ready."
  ].filter((value) => Boolean(value));
  return {
    transactionalLedgerConfigured,
    onchainPrizePoolConfigured,
    drawExecutorConfigured,
    verifiedBuyIngestionEnabled,
    launchBlockers: [...raffleLaunchBlockers(rules), ...infrastructureBlockers]
  };
}

// netlify/lib/tree-raffle-supabase-ledger.ts
function requiredConfigValue(value, label) {
  const normalized = value?.trim();
  if (!normalized) throw new Error(`${label} is not configured.`);
  return normalized;
}
function treeRaffleSupabaseConfig(env = process.env) {
  const url = requiredConfigValue(env.TREE_RAFFLE_SUPABASE_URL, "TREE_RAFFLE_SUPABASE_URL");
  const secretKey = requiredConfigValue(
    env.TREE_RAFFLE_SUPABASE_SECRET_KEY,
    "TREE_RAFFLE_SUPABASE_SECRET_KEY"
  );
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error("TREE_RAFFLE_SUPABASE_URL must be a valid HTTPS URL.");
  }
  if (parsed.protocol !== "https:") {
    throw new Error("TREE_RAFFLE_SUPABASE_URL must use HTTPS.");
  }
  return {
    url: parsed.origin,
    secretKey,
    weeklyEnabled: env.TREE_RAFFLE_WEEKLY_ENABLED === "true"
  };
}

// netlify/lib/tree-raffle-supabase-read.ts
function validSnapshot(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const candidate = value;
  return Boolean(candidate.rounds && typeof candidate.rounds === "object" && !Array.isArray(candidate.rounds)) && Array.isArray(candidate.history) && (candidate.wallet === null || typeof candidate.wallet === "object" && !Array.isArray(candidate.wallet));
}
var SupabaseTreeRaffleReadModel = class {
  config;
  fetchImpl;
  constructor(config2, fetchImpl = fetch) {
    this.config = config2;
    this.fetchImpl = fetchImpl;
  }
  async snapshot(wallet) {
    const response = await this.fetchImpl(
      `${this.config.url}/rest/v1/rpc/read_tree_raffle_public_snapshot`,
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.config.secretKey}`,
          apikey: this.config.secretKey,
          "X-Client-Info": "tree-command-center-raffle-read/1"
        },
        body: JSON.stringify({ p_wallet: wallet }),
        signal: AbortSignal.timeout(5e3)
      }
    );
    if (!response.ok) throw new Error(`Supabase raffle snapshot request failed with HTTP ${response.status}.`);
    const payload = await response.json();
    if (!validSnapshot(payload)) throw new Error("Supabase returned an invalid raffle public snapshot.");
    return payload;
  }
};
function configuredSupabaseTreeRaffleReadModel(env = process.env, fetchImpl = fetch) {
  return new SupabaseTreeRaffleReadModel(treeRaffleSupabaseConfig(env), fetchImpl);
}

// netlify/functions/tree-raffle-status.ts
function publicLaunchAt(env) {
  const configured = String(env.TREE_RAFFLE_PUBLIC_LAUNCH_AT || "").trim();
  if (!configured) return null;
  const parsed = new Date(configured);
  return Number.isFinite(parsed.valueOf()) ? parsed.toISOString() : null;
}
function treeRaffleStatus(generatedAt = (/* @__PURE__ */ new Date()).toISOString(), env = process.env) {
  const rules = treeRaffleRulesForEnvironment(env);
  const readiness = raffleOperationalReadiness(env, rules);
  const {
    transactionalLedgerConfigured,
    onchainPrizePoolConfigured,
    drawExecutorConfigured,
    verifiedBuyIngestionEnabled
  } = readiness;
  const entriesRecorded = verifiedBuyIngestionEnabled;
  return {
    status: "ok",
    generatedAt,
    publicLaunchAt: publicLaunchAt(env),
    rules,
    contracts: onchainPrizePoolConfigured ? {
      packageId: env.TREE_RAFFLE_PACKAGE_ID.trim(),
      poolId: env.TREE_RAFFLE_PRIZE_POOL_ID.trim()
    } : null,
    rounds: {
      daily: { state: "not-scheduled", cadence: "Daily at 10:00 America/New_York", prize: rules.prizes.dailyMain, opensAt: null, closesAt: null },
      weekly: { state: "not-scheduled", cadence: "Sunday at 10:05 America/New_York", prize: null, opensAt: null, closesAt: null }
    },
    history: [],
    launchBlockers: readiness.launchBlockers,
    safeguards: {
      replaySafeLedgerModel: true,
      finalizedBuyVerifierImplemented: true,
      transactionalLedgerConfigured,
      onchainPrizePoolConfigured,
      drawExecutorConfigured,
      verifiedBuyIngestionEnabled,
      entriesRecorded,
      paymentsAccepted: false,
      winnerSelectionEnabled: drawExecutorConfigured
    }
  };
}
function normalizedWallet(request) {
  const wallet = new URL(request.url).searchParams.get("wallet");
  if (!wallet) return null;
  const normalized = wallet.trim().toLowerCase();
  if (!/^0x[0-9a-f]{64}$/.test(normalized)) throw new Error("invalid-wallet");
  return normalized;
}
var tree_raffle_status_default = async (request) => {
  if (request.method !== "GET") {
    return Response.json(
      { status: "error", error: "method-not-allowed" },
      { status: 405, headers: { Allow: "GET", "Cache-Control": "no-store" } }
    );
  }
  let wallet;
  try {
    wallet = normalizedWallet(request);
  } catch {
    return Response.json(
      { status: "error", error: "invalid-wallet" },
      { status: 400, headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } }
    );
  }
  const status = treeRaffleStatus();
  let snapshot = null;
  let snapshotError = null;
  try {
    if (status.safeguards.transactionalLedgerConfigured) {
      snapshot = await configuredSupabaseTreeRaffleReadModel().snapshot(wallet);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : "unknown error";
    const httpStatus = message.match(/HTTP (\d{3})/i)?.[1];
    snapshotError = httpStatus ? `http-${httpStatus}` : /timeout|aborted/i.test(message) ? "timeout" : "invalid-response";
    console.error(`TREE raffle public snapshot unavailable: ${message}`);
  }
  return Response.json({
    ...status,
    rounds: snapshot?.rounds && Object.keys(snapshot.rounds).length ? {
      ...status.rounds,
      ...snapshot.rounds,
      daily: {
        ...status.rounds.daily,
        ...snapshot.rounds.daily,
        prize: snapshot.rounds.daily?.prize ?? status.rounds.daily.prize
      }
    } : status.rounds,
    history: snapshot?.history ?? status.history,
    wallet: snapshot?.wallet ?? (wallet ? { address: wallet, streak: null, unclaimedPrizes: [] } : null),
    safeguards: {
      ...status.safeguards,
      publicLedgerReadAvailable: snapshot !== null,
      publicLedgerReadError: snapshotError
    }
  }, {
    headers: {
      "Cache-Control": wallet ? "private, no-store" : "public, max-age=30, s-maxage=60, stale-while-revalidate=300",
      "X-Content-Type-Options": "nosniff"
    }
  });
};
var config = { path: "/api/tree-raffle-status" };
export {
  config,
  tree_raffle_status_default as default,
  treeRaffleStatus
};
