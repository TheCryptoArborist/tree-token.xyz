
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-exposure-background-worker.ts
import { randomUUID as randomUUID2 } from "node:crypto";

// netlify/lib/leaderboard-background-worker.ts
import { createHash, randomUUID, timingSafeEqual } from "node:crypto";

// netlify/lib/leaderboard-cache.ts
import { getDeployStore, getStore } from "@netlify/blobs";

// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var TREE_DECIMALS = 6;
var TREE_TOTAL_SUPPLY_RAW = 1000000000000000n;
var METHODOLOGY_VERSION = "direct-tree-sui-graphql-poc-v2";
var SUI_GRAPHQL_PROVIDER = "sui-graphql";
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));
function tierForRank(rank) {
  if (rank <= 5) return "Ancient Grove";
  if (rank <= 10) return "Giant Sequoia";
  if (rank <= 20) return "Heritage Oak";
  if (rank <= 30) return "Canopy Guardian";
  return "Forest Keeper";
}
function normalizeSuiAddress(value) {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  return SUI_ADDRESS.test(normalized) ? normalized : null;
}
function excludedAddress(address) {
  return exclusionMap.get(address) || null;
}

// netlify/lib/leaderboard-cache.ts
var REFRESH_LOCK_TTL_MS = 20 * 60 * 1e3;

// netlify/lib/sui-graphql-background-config.ts
var DEFAULT_BACKGROUND_SUI_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var DEFAULT_BACKGROUND_PAGE_SIZE = 50;
var DEFAULT_BACKGROUND_MAX_PAGES = 5e3;
var DEFAULT_BACKGROUND_MAX_SCAN_MS = 84e4;
var DEFAULT_BACKGROUND_PROGRESS_PAGES = 25;
var DEFAULT_BACKGROUND_MAX_RETRIES = 5;
function boundedInteger(value, fallback, min, max) {
  if (typeof value !== "string" || !/^\d+$/.test(value.trim())) return fallback;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= min && parsed <= max ? parsed : fallback;
}
function endpoint(value) {
  if (!value) return DEFAULT_BACKGROUND_SUI_GRAPHQL_URL;
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:" || parsed.protocol === "http:" ? parsed.toString() : DEFAULT_BACKGROUND_SUI_GRAPHQL_URL;
  } catch {
    return DEFAULT_BACKGROUND_SUI_GRAPHQL_URL;
  }
}
function readSuiGraphqlBackgroundConfig(getEnv) {
  return {
    endpoint: endpoint(getEnv("SUI_GRAPHQL_URL")),
    pageSize: boundedInteger(getEnv("SUI_GRAPHQL_BACKGROUND_PAGE_SIZE"), DEFAULT_BACKGROUND_PAGE_SIZE, 1, 50),
    maxPages: boundedInteger(getEnv("SUI_GRAPHQL_BACKGROUND_MAX_PAGES"), DEFAULT_BACKGROUND_MAX_PAGES, 100, 1e4),
    maxScanMs: boundedInteger(getEnv("SUI_GRAPHQL_BACKGROUND_MAX_SCAN_MS"), DEFAULT_BACKGROUND_MAX_SCAN_MS, 3e4, 84e4),
    progressIntervalPages: boundedInteger(getEnv("SUI_GRAPHQL_BACKGROUND_PROGRESS_PAGES"), DEFAULT_BACKGROUND_PROGRESS_PAGES, 1, 100),
    maxRetries: boundedInteger(getEnv("SUI_GRAPHQL_BACKGROUND_MAX_RETRIES"), DEFAULT_BACKGROUND_MAX_RETRIES, 0, 10)
  };
}

// netlify/lib/sui-graphql-leaderboard-provider.ts
var DEFAULT_SUI_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var DEFAULT_PAGE_SIZE = 50;
var DEFAULT_MAX_PAGES = 40;
var DEFAULT_MAX_SCAN_MS = 8e3;
var TREE_COIN_METADATA_QUERY = `query GetTreeCoinMetadata($coinType: String!) {
  coinMetadata(coinType: $coinType) {
    name
    symbol
    decimals
    supply
  }
}`;
var TREE_COIN_OBJECTS_QUERY = `query TreeCoinObjects(
  $first: Int!
  $after: String
  $coinObjectType: String!
) {
  objects(
    first: $first
    after: $after
    filter: { type: $coinObjectType }
  ) {
    pageInfo {
      hasNextPage
      endCursor
    }
    nodes {
      address
      owner {
        __typename
        ... on AddressOwner {
          address {
            address
          }
        }
        ... on ObjectOwner {
          address {
            address
          }
        }
      }
      asMoveObject {
        contents {
          json
          balanceField: extract(path: "balance") {
            json
          }
        }
      }
    }
  }
}`;
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function boundedInteger2(value, fallback, min, max) {
  if (typeof value !== "string" || !/^\d+$/.test(value.trim())) return fallback;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= min && parsed <= max ? parsed : fallback;
}
function readSuiGraphqlConfig(getEnv = (name) => Netlify.env.get(name)) {
  const endpointValue = getEnv("SUI_GRAPHQL_URL");
  let endpoint2 = DEFAULT_SUI_GRAPHQL_URL;
  if (endpointValue) {
    try {
      const parsed = new URL(endpointValue);
      if (parsed.protocol === "https:" || parsed.protocol === "http:") endpoint2 = parsed.toString();
    } catch {
    }
  }
  return {
    endpoint: endpoint2,
    pageSize: boundedInteger2(getEnv("SUI_GRAPHQL_PAGE_SIZE"), DEFAULT_PAGE_SIZE, 1, 50),
    maxPages: boundedInteger2(getEnv("SUI_GRAPHQL_MAX_PAGES"), DEFAULT_MAX_PAGES, 1, 100),
    maxScanMs: boundedInteger2(getEnv("SUI_GRAPHQL_MAX_SCAN_MS"), DEFAULT_MAX_SCAN_MS, 1e3, 2e4)
  };
}
function parseRawBalance(value) {
  if (typeof value !== "string" || !/^\d+$/.test(value)) return null;
  try {
    return BigInt(value);
  } catch {
    return null;
  }
}
function verifyTreeCoinMetadata(value) {
  const metadata = record(value);
  const name = typeof metadata.name === "string" && metadata.name.trim() ? metadata.name : null;
  const symbol = typeof metadata.symbol === "string" ? metadata.symbol : null;
  const decimals = metadata.decimals;
  const supplyRaw = parseRawBalance(metadata.supply);
  if (!name || !symbol || symbol.trim().toUpperCase() !== "TREE" || typeof decimals !== "number" || !Number.isSafeInteger(decimals) || decimals !== TREE_DECIMALS || supplyRaw !== TREE_TOTAL_SUPPLY_RAW) return null;
  return { name, symbol, decimals, supplyRaw };
}
function formatBaseUnits(raw, coinDecimals) {
  const negative = raw < 0n;
  const absolute = negative ? -raw : raw;
  const base = 10n ** BigInt(coinDecimals);
  const whole = absolute / base;
  const fraction = (absolute % base).toString().padStart(coinDecimals, "0").replace(/0+$/, "");
  return `${negative ? "-" : ""}${whole.toString()}${fraction ? `.${fraction}` : ""}`;
}
function compareBigIntDescending(left, right) {
  return left > right ? -1 : left < right ? 1 : 0;
}
function formatPercentFromRaw(raw, total, precision = 9) {
  if (total <= 0n) return "0";
  const scale = 10n ** BigInt(precision);
  const scaled = raw * 100n * scale / total;
  return formatBaseUnits(scaled, precision);
}
function initialCoverage() {
  return {
    coinMetadataVerified: false,
    coinSymbol: null,
    coinDecimals: null,
    totalSupplyRaw: null,
    pagesScanned: 0,
    objectsScanned: 0,
    addressOwnedCoinObjects: 0,
    uniqueAddressOwners: 0,
    objectOwnedObjectsSkipped: 0,
    sharedObjectsSkipped: 0,
    immutableObjectsSkipped: 0,
    consensusOwnedObjectsSkipped: 0,
    unknownOwnerObjectsSkipped: 0,
    malformedOwnerAddresses: 0,
    malformedBalances: 0,
    excludedCoinObjects: 0,
    excludedUniqueOwners: 0,
    excludedAddresses: 0,
    duplicateObjectIds: 0,
    elapsedMs: 0,
    hasNextPage: false,
    endCursorPresent: false,
    reachedEnd: false,
    pageLimitReached: false,
    timeLimitReached: false,
    rateLimited: false,
    graphqlErrors: [],
    networkError: null,
    cursorInconsistent: false,
    requestAttempts: 0,
    retriedRequests: 0,
    rateLimitRetries: 0,
    networkRetries: 0,
    serverErrorRetries: 0,
    scanComplete: false
  };
}
function rawBalanceFromNode(node) {
  const moveObject = record(node.asMoveObject);
  const contents = record(moveObject.contents);
  const extracted = record(contents.balanceField);
  const json = record(contents.json);
  return extracted.json ?? json.balance;
}
function ownerAddress(owner) {
  const address = owner.address;
  return typeof address === "string" ? address : record(address).address;
}
function addBalance(map, wallet, raw) {
  const prior = map.get(wallet);
  map.set(wallet, prior ? { wallet, raw: prior.raw + raw, coinObjectCount: prior.coinObjectCount + 1 } : { wallet, raw, coinObjectCount: 1 });
}
function buildEntries(candidates, coinDecimals, totalSupplyRaw) {
  return [...candidates.values()].sort((left, right) => compareBigIntDescending(left.raw, right.raw) || left.wallet.localeCompare(right.wallet)).slice(0, 50).map((candidate, index) => ({
    rank: index + 1,
    wallet: candidate.wallet,
    suinsName: null,
    directTreeRaw: candidate.raw.toString(),
    directTree: formatBaseUnits(candidate.raw, coinDecimals),
    supplyPercent: formatPercentFromRaw(candidate.raw, totalSupplyRaw),
    tier: tierForRank(index + 1),
    coinObjectCount: candidate.coinObjectCount,
    moonbagsLocks: null,
    suiDexV2: null,
    suiDexV3: null,
    turbos: null,
    nftreeCount: null
  }));
}
function buildExposureCandidates(candidates) {
  return [...candidates.values()].sort((left, right) => compareBigIntDescending(left.raw, right.raw) || left.wallet.localeCompare(right.wallet)).map((candidate) => ({
    wallet: candidate.wallet,
    suinsName: null,
    directTreeRaw: candidate.raw.toString(),
    coinObjectCount: candidate.coinObjectCount
  }));
}
function reconcile(addressOwnedRaw, coinDecimals, totalSupplyRaw) {
  const valid = addressOwnedRaw <= totalSupplyRaw;
  const remainder = valid ? totalSupplyRaw - addressOwnedRaw : null;
  return {
    valid,
    totalSupplyRaw: totalSupplyRaw.toString(),
    addressOwnedRaw: addressOwnedRaw.toString(),
    addressOwnedTree: formatBaseUnits(addressOwnedRaw, coinDecimals),
    addressOwnedPercentOfTotal: formatPercentFromRaw(addressOwnedRaw, totalSupplyRaw),
    nonAddressOwnedOrEmbeddedRawEstimate: remainder?.toString() ?? null,
    nonAddressOwnedOrEmbeddedTreeEstimate: remainder === null ? null : formatBaseUnits(remainder, coinDecimals),
    nonAddressOwnedOrEmbeddedLabel: "TREE not represented by address-owned Coin<TREE> objects"
  };
}
function graphqlErrorMessages(value) {
  if (!Array.isArray(value)) return [];
  return value.map((error) => {
    const message = record(error).message;
    return typeof message === "string" && message ? message : "Unknown GraphQL error";
  });
}
async function scanSuiGraphqlLeaderboard(options = {}) {
  const defaults = readSuiGraphqlConfig(() => void 0);
  const config = {
    endpoint: options.endpoint ?? defaults.endpoint,
    pageSize: options.pageSize ?? defaults.pageSize,
    maxPages: options.maxPages ?? defaults.maxPages,
    maxScanMs: options.maxScanMs ?? defaults.maxScanMs
  };
  const fetchImpl = options.fetchImpl ?? fetch;
  const now = options.now ?? Date.now;
  const sleepImpl = options.sleepImpl ?? ((milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)));
  const randomImpl = options.randomImpl ?? Math.random;
  const progressIntervalPages = Math.max(1, Math.floor(options.progressIntervalPages ?? 1));
  const maxRetries = Math.max(0, Math.floor(options.maxRetries ?? 0));
  const startedAt = now();
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const coverage = initialCoverage();
  const seenObjectIds = /* @__PURE__ */ new Set();
  const allAddressOwners = /* @__PURE__ */ new Map();
  const rankingCandidates = /* @__PURE__ */ new Map();
  const excludedWallets = /* @__PURE__ */ new Set();
  let metadataVerificationFailed = false;
  let addressOwnedRaw = 0n;
  let after = null;
  const controller = new AbortController();
  const externalAbort = () => controller.abort();
  options.abortSignal?.addEventListener("abort", externalAbort, { once: true });
  if (options.abortSignal?.aborted) controller.abort();
  const timeout = setTimeout(() => controller.abort(), config.maxScanMs);
  const remainingMs = () => Math.max(0, config.maxScanMs - (now() - startedAt));
  const retryDelay = (retryIndex, response) => {
    const retryAfter = response?.headers.get("Retry-After");
    if (retryAfter && /^\d+(\.\d+)?$/.test(retryAfter.trim())) {
      const milliseconds = Number(retryAfter) * 1e3;
      if (Number.isFinite(milliseconds) && milliseconds >= 0 && milliseconds < remainingMs()) return milliseconds;
    }
    const base = Math.min(1e4, 1e3 * 2 ** retryIndex);
    return Math.min(1e4, base + Math.floor(base * 0.2 * Math.max(0, Math.min(1, randomImpl()))));
  };
  const waitForRetry = async (milliseconds) => {
    if (milliseconds >= remainingMs() || controller.signal.aborted) {
      coverage.timeLimitReached = true;
      return false;
    }
    await sleepImpl(milliseconds);
    if (now() - startedAt >= config.maxScanMs || controller.signal.aborted) {
      coverage.timeLimitReached = true;
      return false;
    }
    return true;
  };
  const emitProgress = async () => {
    if (!options.onProgress) return true;
    try {
      await options.onProgress({
        coinMetadataVerified: coverage.coinMetadataVerified,
        coinSymbol: coverage.coinSymbol,
        coinDecimals: coverage.coinDecimals,
        totalSupplyRaw: coverage.totalSupplyRaw,
        pagesScanned: coverage.pagesScanned,
        objectsScanned: coverage.objectsScanned,
        addressOwnedCoinObjects: coverage.addressOwnedCoinObjects,
        uniqueAddressOwners: allAddressOwners.size,
        excludedCoinObjects: coverage.excludedCoinObjects,
        excludedUniqueOwners: excludedWallets.size,
        excludedAddresses: coverage.excludedCoinObjects,
        elapsedMs: Math.max(0, now() - startedAt),
        hasNextPage: coverage.hasNextPage
      });
      return true;
    } catch {
      coverage.networkError = "Leaderboard refresh progress could not be recorded";
      return false;
    }
  };
  const requestGraphql = async (body) => {
    let response = null;
    for (let retryIndex = 0; ; retryIndex += 1) {
      coverage.requestAttempts += 1;
      try {
        response = await fetchImpl(config.endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "x-sui-rpc-show-usage": "true"
          },
          body: JSON.stringify(body),
          signal: controller.signal
        });
      } catch (error) {
        if (controller.signal.aborted || now() - startedAt >= config.maxScanMs) {
          coverage.timeLimitReached = true;
          return null;
        }
        if (retryIndex < maxRetries) {
          coverage.retriedRequests += 1;
          coverage.networkRetries += 1;
          if (!await waitForRetry(retryDelay(retryIndex))) return null;
          continue;
        }
        coverage.networkError = error instanceof Error ? error.message : "Sui GraphQL network request failed";
        return null;
      }
      const retryableStatus = response.status === 429 || [500, 502, 503, 504].includes(response.status);
      if (retryableStatus && retryIndex < maxRetries) {
        coverage.retriedRequests += 1;
        if (response.status === 429) coverage.rateLimitRetries += 1;
        else coverage.serverErrorRetries += 1;
        if (!await waitForRetry(retryDelay(retryIndex, response))) return null;
        response = null;
        continue;
      }
      if (response.status === 429) coverage.rateLimited = true;
      else if (retryableStatus) coverage.networkError = `Sui GraphQL returned HTTP ${response.status}`;
      break;
    }
    if (!response || coverage.timeLimitReached || coverage.rateLimited || coverage.networkError) return null;
    if (!response.ok) {
      coverage.networkError = `Sui GraphQL returned HTTP ${response.status}`;
      return null;
    }
    let payload;
    try {
      payload = record(await response.json());
    } catch {
      coverage.networkError = "Sui GraphQL returned an unreadable JSON response";
      return null;
    }
    const errors = graphqlErrorMessages(payload.errors);
    if (errors.length) {
      coverage.graphqlErrors.push(...errors);
      return null;
    }
    return payload;
  };
  try {
    const metadataPayload = await requestGraphql({
      query: TREE_COIN_METADATA_QUERY,
      variables: { coinType: TREE_COIN_TYPE }
    });
    const metadataValue = metadataPayload ? record(metadataPayload.data).coinMetadata : null;
    const rawMetadata = record(metadataValue);
    coverage.coinSymbol = typeof rawMetadata.symbol === "string" ? rawMetadata.symbol : null;
    coverage.coinDecimals = typeof rawMetadata.decimals === "number" && Number.isSafeInteger(rawMetadata.decimals) ? rawMetadata.decimals : null;
    coverage.totalSupplyRaw = typeof rawMetadata.supply === "string" && /^\d+$/.test(rawMetadata.supply) ? rawMetadata.supply : null;
    const verifiedMetadata = verifyTreeCoinMetadata(metadataValue);
    coverage.coinMetadataVerified = verifiedMetadata !== null;
    metadataVerificationFailed = !coverage.coinMetadataVerified;
    while (coverage.coinMetadataVerified && coverage.pagesScanned < config.maxPages) {
      if (now() - startedAt >= config.maxScanMs) {
        coverage.timeLimitReached = true;
        break;
      }
      const payload = await requestGraphql({
        query: TREE_COIN_OBJECTS_QUERY,
        variables: { first: config.pageSize, after, coinObjectType: TREE_COIN_OBJECT_TYPE }
      });
      if (!payload) break;
      const objectsValue = record(payload.data).objects;
      const objects = record(objectsValue);
      if (!objectsValue || typeof objectsValue !== "object" || !Array.isArray(objects.nodes) || !objects.pageInfo || typeof objects.pageInfo !== "object") {
        coverage.networkError = "Sui GraphQL returned an unreadable response structure";
        break;
      }
      const nodes = objects.nodes;
      const pageInfo = record(objects.pageInfo);
      coverage.pagesScanned += 1;
      coverage.objectsScanned += nodes.length;
      for (const rawNode of nodes) {
        const node = record(rawNode);
        const objectId = typeof node.address === "string" ? node.address.toLowerCase() : null;
        if (objectId && seenObjectIds.has(objectId)) {
          coverage.duplicateObjectIds += 1;
          continue;
        }
        if (objectId) seenObjectIds.add(objectId);
        const owner = record(node.owner);
        const ownerKind = typeof owner.__typename === "string" ? owner.__typename : "Unknown";
        if (ownerKind !== "AddressOwner") {
          if (ownerKind === "ObjectOwner") coverage.objectOwnedObjectsSkipped += 1;
          else if (ownerKind === "Shared" || ownerKind === "SharedOwner") coverage.sharedObjectsSkipped += 1;
          else if (ownerKind === "Immutable" || ownerKind === "ImmutableOwner") coverage.immutableObjectsSkipped += 1;
          else if (ownerKind === "ConsensusAddressOwner") coverage.consensusOwnedObjectsSkipped += 1;
          else coverage.unknownOwnerObjectsSkipped += 1;
          continue;
        }
        const wallet = normalizeSuiAddress(ownerAddress(owner));
        if (!wallet) {
          coverage.malformedOwnerAddresses += 1;
          continue;
        }
        const balance = parseRawBalance(rawBalanceFromNode(node));
        if (balance === null) {
          coverage.malformedBalances += 1;
          continue;
        }
        coverage.addressOwnedCoinObjects += 1;
        addressOwnedRaw += balance;
        addBalance(allAddressOwners, wallet, balance);
        if (excludedAddress(wallet)) {
          coverage.excludedCoinObjects += 1;
          coverage.excludedAddresses = coverage.excludedCoinObjects;
          excludedWallets.add(wallet);
          continue;
        }
        addBalance(rankingCandidates, wallet, balance);
      }
      coverage.hasNextPage = pageInfo.hasNextPage === true;
      coverage.endCursorPresent = typeof pageInfo.endCursor === "string" && pageInfo.endCursor.length > 0;
      if (!coverage.hasNextPage) {
        coverage.reachedEnd = true;
        break;
      }
      if (!coverage.endCursorPresent) {
        coverage.cursorInconsistent = true;
        break;
      }
      after = pageInfo.endCursor;
      if (now() - startedAt >= config.maxScanMs) {
        coverage.timeLimitReached = true;
        break;
      }
      if (coverage.pagesScanned % progressIntervalPages === 0 && !await emitProgress()) break;
    }
  } finally {
    clearTimeout(timeout);
    options.abortSignal?.removeEventListener("abort", externalAbort);
  }
  coverage.pageLimitReached = coverage.hasNextPage && coverage.pagesScanned >= config.maxPages && !coverage.reachedEnd;
  coverage.uniqueAddressOwners = allAddressOwners.size;
  coverage.excludedUniqueOwners = excludedWallets.size;
  coverage.elapsedMs = Math.max(0, now() - startedAt);
  await emitProgress();
  const dataIntegrityValid = coverage.malformedOwnerAddresses === 0 && coverage.malformedBalances === 0 && coverage.unknownOwnerObjectsSkipped === 0 && coverage.duplicateObjectIds === 0;
  coverage.scanComplete = coverage.coinMetadataVerified && coverage.reachedEnd && coverage.graphqlErrors.length === 0 && !coverage.networkError && !coverage.rateLimited && !coverage.pageLimitReached && !coverage.timeLimitReached && !coverage.cursorInconsistent && dataIntegrityValid;
  const verifiedCoinDecimals = coverage.coinMetadataVerified ? coverage.coinDecimals : null;
  const verifiedTotalSupplyRaw = coverage.coinMetadataVerified && coverage.totalSupplyRaw ? BigInt(coverage.totalSupplyRaw) : null;
  const reconciliation = verifiedCoinDecimals !== null && verifiedTotalSupplyRaw !== null ? reconcile(addressOwnedRaw, verifiedCoinDecimals, verifiedTotalSupplyRaw) : {
    valid: false,
    totalSupplyRaw: coverage.totalSupplyRaw ?? "",
    addressOwnedRaw: addressOwnedRaw.toString(),
    addressOwnedTree: "",
    addressOwnedPercentOfTotal: "",
    nonAddressOwnedOrEmbeddedRawEstimate: null,
    nonAddressOwnedOrEmbeddedTreeEstimate: null,
    nonAddressOwnedOrEmbeddedLabel: "TREE not represented by address-owned Coin<TREE> objects"
  };
  const complete = coverage.coinMetadataVerified && coverage.scanComplete && reconciliation.valid;
  const providerError = !metadataVerificationFailed && (coverage.graphqlErrors.length > 0 || Boolean(coverage.networkError) || coverage.rateLimited);
  const outcome = complete ? "complete" : providerError ? "error" : "verification-incomplete";
  const entries = complete && verifiedCoinDecimals !== null && verifiedTotalSupplyRaw !== null ? buildEntries(rankingCandidates, verifiedCoinDecimals, verifiedTotalSupplyRaw) : [];
  const exposureCandidates = complete && options.includeExposureCandidates ? buildExposureCandidates(rankingCandidates) : null;
  const warnings = ["Phase 2.2C measures direct address-owned TREE only, not total TREE exposure."];
  if (!coverage.coinMetadataVerified) warnings.push("TREE coin metadata could not be verified; rankings were not published.");
  if (!coverage.scanComplete) warnings.push("The Sui-native Coin<TREE> verification did not complete; partial ranks were not published.");
  if (coverage.coinMetadataVerified && !reconciliation.valid) warnings.push("Address-owned raw TREE exceeded total supply; reconciliation is invalid and ranks were not published.");
  if (coverage.rateLimited) warnings.push("The public Sui GraphQL endpoint rate-limited the scan.");
  if (coverage.graphqlErrors.length) warnings.push("Sui GraphQL returned one or more errors.");
  if (coverage.networkError) warnings.push("The Sui GraphQL request failed before verification completed.");
  if (coverage.malformedOwnerAddresses) warnings.push("Malformed address-owned wallet data prevented complete verification.");
  if (coverage.malformedBalances) warnings.push("Malformed TREE balance data prevented complete verification.");
  if (coverage.unknownOwnerObjectsSkipped) warnings.push("An unknown Sui owner variant prevented complete verification.");
  if (coverage.duplicateObjectIds) warnings.push("Duplicate Coin<TREE> object IDs prevented complete verification.");
  if (coverage.excludedCoinObjects) warnings.push(`${coverage.excludedCoinObjects} excluded protocol or system Coin<TREE> object(s) across ${excludedWallets.size} unique owner(s) were omitted from ranking.`);
  return {
    outcome,
    provider: SUI_GRAPHQL_PROVIDER,
    generatedAt,
    methodologyVersion: METHODOLOGY_VERSION,
    coverage,
    reconciliation,
    coinSymbol: coverage.coinMetadataVerified ? coverage.coinSymbol : null,
    coinDecimals: verifiedCoinDecimals,
    totalSupplyRaw: verifiedTotalSupplyRaw?.toString() ?? null,
    coinMetadataVerified: coverage.coinMetadataVerified,
    verifiedAddressOwners: complete ? allAddressOwners.size : null,
    eligibleRankedOwners: complete ? rankingCandidates.size : null,
    excludedCoinObjects: coverage.excludedCoinObjects,
    excludedUniqueOwners: coverage.excludedUniqueOwners,
    holderCount: complete ? allAddressOwners.size : null,
    displayedCount: entries.length,
    excludedCount: coverage.excludedCoinObjects,
    entries,
    exposureCandidates,
    warnings,
    sourceCheckpoint: {
      pagesScanned: coverage.pagesScanned,
      objectsScanned: coverage.objectsScanned,
      reachedEnd: coverage.reachedEnd,
      endCursorPresent: coverage.endCursorPresent
    }
  };
}

// netlify/lib/suins-name-resolver.ts
var DEFAULT_SUINS_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var MAX_SUINS_NAMES_PER_REQUEST = 50;
var MAX_SUINS_NAMES_PER_GRAPHQL_BATCH = 20;
var DEFAULT_SUINS_CONCURRENCY = 8;
function record2(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function safeName(value) {
  if (typeof value !== "string") return null;
  const name = value.trim();
  if (!name || name.length > 255 || /[\u0000-\u001f\u007f]/.test(name)) return null;
  return name;
}
function errorMessage(error) {
  return error instanceof Error ? error.message : String(error || "Unknown SuiNS resolution error");
}
function isExpectedMissingName(error) {
  const source = error && typeof error === "object" ? error : {};
  if (source.code === 5 || source.status === 5 || source.code === "NOT_FOUND" || source.status === "NOT_FOUND") return true;
  const rawMessage = errorMessage(error).toLowerCase();
  let message = rawMessage;
  try {
    message = decodeURIComponent(rawMessage.replace(/\+/g, " "));
  } catch {
  }
  return message.includes("not_found") || message.includes("not found") || message.includes("name has expired") || message.includes("name does not exist");
}
function withTimeout(promise, timeoutMs) {
  if (timeoutMs <= 0) return Promise.reject(new Error("SuiNS resolution timed out."));
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("SuiNS resolution timed out.")), timeoutMs);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}
function graphqlErrors(value) {
  if (!Array.isArray(value)) return [];
  return value.map((item) => {
    const message = record2(item).message;
    return typeof message === "string" && message ? message : "Unknown SuiNS GraphQL error";
  });
}
function buildDefaultSuinsQuery(addresses) {
  const definitions = addresses.map((_, index) => `$address${index}: SuiAddress!`).join(", ");
  const fields = addresses.map((_, index) => `name${index}: address(address: $address${index}) { defaultNameRecord { domain } }`).join("\n");
  return {
    query: `query ResolveDefaultSuinsNames(${definitions}) {
${fields}
}`,
    variables: Object.fromEntries(addresses.map((address, index) => [`address${index}`, address]))
  };
}
async function resolveWithGraphql(normalized, names, options) {
  const controller = new AbortController();
  const externalAbort = () => controller.abort();
  options.abortSignal?.addEventListener("abort", externalAbort, { once: true });
  if (options.abortSignal?.aborted) controller.abort();
  const timeout = setTimeout(() => controller.abort(), Math.max(1e3, options.timeoutMs ?? 15e3));
  let networkError = null;
  const errors = [];
  try {
    const batches = Array.from(
      { length: Math.ceil(normalized.length / MAX_SUINS_NAMES_PER_GRAPHQL_BATCH) },
      (_, index) => normalized.slice(
        index * MAX_SUINS_NAMES_PER_GRAPHQL_BATCH,
        (index + 1) * MAX_SUINS_NAMES_PER_GRAPHQL_BATCH
      )
    );
    const results = await Promise.all(batches.map(async (batch) => {
      const response = await (options.fetchImpl || fetch)(options.endpoint || DEFAULT_SUINS_GRAPHQL_URL, {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify(buildDefaultSuinsQuery(batch)),
        signal: controller.signal
      });
      if (!response.ok) return { errors: [], networkError: `SuiNS GraphQL returned HTTP ${response.status}` };
      const payload = record2(await response.json());
      const batchErrors = graphqlErrors(payload.errors);
      const data = record2(payload.data);
      batch.forEach((address, index) => {
        const nameRecord = record2(record2(data[`name${index}`]).defaultNameRecord);
        names[address] = safeName(nameRecord.domain);
      });
      return { errors: batchErrors, networkError: null };
    }));
    results.forEach((result) => {
      errors.push(...result.errors);
      networkError ||= result.networkError;
    });
  } catch (error) {
    networkError = controller.signal.aborted ? "SuiNS resolution timed out." : errorMessage(error);
  } finally {
    clearTimeout(timeout);
    options.abortSignal?.removeEventListener("abort", externalAbort);
  }
  return { errors, networkError };
}
async function resolveWithInjectedClient(normalized, names, options) {
  const now = options.now ?? Date.now;
  const client = options.client ?? options.clientFactory?.(options.endpoint || DEFAULT_SUINS_GRAPHQL_URL);
  if (!client) return { errors: ["SuiNS client is unavailable."], networkError: "SuiNS client is unavailable." };
  const deadline = now() + Math.max(1e3, options.timeoutMs ?? 15e3);
  const concurrency = Math.max(1, Math.min(16, Math.trunc(options.concurrency ?? DEFAULT_SUINS_CONCURRENCY)));
  const unexpectedErrors = [];
  let cursor = 0;
  async function worker() {
    while (cursor < normalized.length) {
      if (options.abortSignal?.aborted) {
        unexpectedErrors.push("SuiNS resolution aborted.");
        return;
      }
      const current = cursor;
      cursor += 1;
      const address = normalized[current];
      try {
        const response = await withTimeout(client.core.defaultNameServiceName({ address }), deadline - now());
        let name = safeName(response?.name);
        if (!name && client.nameService?.reverseLookupName) {
          const reverse = await withTimeout(client.nameService.reverseLookupName({ address }), deadline - now());
          name = safeName(reverse?.response?.record?.name);
        }
        names[address] = name;
      } catch (error) {
        if (isExpectedMissingName(error)) {
          names[address] = null;
          continue;
        }
        unexpectedErrors.push(errorMessage(error));
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, normalized.length) }, () => worker()));
  const errors = [...new Set(unexpectedErrors)].slice(0, 10);
  return { errors, networkError: errors[0] || null };
}
async function resolveDefaultSuinsNames(addresses, options = {}) {
  const normalized = [...new Set(addresses.map(normalizeSuiAddress).filter((value) => Boolean(value)))].slice(0, MAX_SUINS_NAMES_PER_REQUEST);
  const names = Object.fromEntries(normalized.map((address) => [address, null]));
  const now = options.now ?? Date.now;
  const generatedAt = new Date(now()).toISOString();
  if (!normalized.length) {
    return { names, requestedCount: 0, resolvedCount: 0, complete: true, graphqlErrors: [], networkError: null, generatedAt };
  }
  const result = options.client || options.clientFactory ? await resolveWithInjectedClient(normalized, names, options) : await resolveWithGraphql(normalized, names, options);
  const resolvedCount = Object.values(names).filter(Boolean).length;
  const errors = [...result.errors];
  if (normalized.length >= 10 && resolvedCount === 0 && errors.length === 0 && !result.networkError) {
    errors.push(`SuiNS reverse lookup returned zero names for ${normalized.length} addresses.`);
  }
  const uniqueErrors = [...new Set(errors)].slice(0, 10);
  const networkError = result.networkError || uniqueErrors[0] || null;
  return {
    names,
    requestedCount: normalized.length,
    resolvedCount,
    complete: !networkError && uniqueErrors.length === 0,
    graphqlErrors: uniqueErrors,
    networkError,
    generatedAt
  };
}

// netlify/lib/leaderboard-background-worker.ts
function timingSafeSecretEqual(left, right) {
  const leftDigest = createHash("sha256").update(left).digest();
  const rightDigest = createHash("sha256").update(right).digest();
  return timingSafeEqual(leftDigest, rightDigest);
}

// netlify/lib/tree-exposure-cache.ts
import { getDeployStore as getDeployStore2, getStore as getStore2 } from "@netlify/blobs";

// netlify/lib/tree-exposure-types.ts
var TREE_EXPOSURE_METHODOLOGY_VERSION = "verified-tree-exposure-v1";
var LP_PROVIDER_BADGE = "lp-provider";
var LP_MAXI_BADGE = "lp-maxi";
var DIAMOND_HANDS_BADGE = "diamond-hands";
var PAPER_HANDS_BADGE = "paper-hands";
var ACCUMULATOR_BADGE = "accumulator";
var BURNED_BADGE = "burned";
function formatTreeRaw(raw) {
  return formatBaseUnits(raw, TREE_DECIMALS);
}
function formatTreeSupplyPercent(raw) {
  return formatPercentFromRaw(raw, TREE_TOTAL_SUPPLY_RAW);
}
function parseUnsignedRaw(value) {
  if (typeof value !== "string" || !/^\d+$/.test(value)) return null;
  try {
    return BigInt(value);
  } catch {
    return null;
  }
}

// netlify/lib/tree-exposure-cache.ts
var EXPOSURE_STORE_NAME = "tree-exposure";
var COMPLETE_EXPOSURE_SNAPSHOT_KEY = "complete";
var EXPOSURE_REFRESH_STATUS_KEY = "refresh-status";
var EXPOSURE_REFRESH_LOCK_KEY = "refresh-lock";
var EXPOSURE_REFRESH_LOCK_TTL_MS = 30 * 60 * 1e3;
var EXPOSURE_SNAPSHOT_PROVIDER = "tree-exposure-snapshot";
var defaultFactories = {
  getStore: (name, options) => getStore2(name, options),
  getDeployStore: (name) => getDeployStore2(name)
};
function selectExposureStore(context, factories = defaultFactories) {
  return context === "production" ? factories.getStore(EXPOSURE_STORE_NAME, { consistency: "strong" }) : factories.getDeployStore(EXPOSURE_STORE_NAME);
}
function resolveStore(options) {
  return options.store ?? selectExposureStore(options.context);
}
function record3(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function safeNonNegativeInteger(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function safeGeneratedAt(value) {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}
function safeSuinsName(value) {
  return value === null || typeof value === "string" && value.trim() === value && value.length > 0 && value.length <= 255 && !/[\u0000-\u001f\u007f]/.test(value);
}
function expectedBadges(liquidRaw, lpRaw, entry) {
  const badges = [];
  if (lpRaw > 0n) badges.push(LP_PROVIDER_BADGE);
  if (lpRaw > liquidRaw && lpRaw > 0n) badges.push(LP_MAXI_BADGE);
  if (entry.activity30d !== void 0 && entry.activity30d !== null) {
    const activity = record3(entry.activity30d);
    const buyRaw = parseUnsignedRaw(activity.buyTreeRaw);
    const sellRaw = parseUnsignedRaw(activity.sellTreeRaw);
    if (buyRaw === null || sellRaw === null || !safeNonNegativeInteger(activity.buyCount) || !safeNonNegativeInteger(activity.sellCount) || !safeGeneratedAt(activity.windowStart) || !safeGeneratedAt(activity.windowEnd) || activity.buyTree !== formatTreeRaw(buyRaw) || activity.sellTree !== formatTreeRaw(sellRaw)) return null;
    if (activity.sellCount === 0) badges.push(DIAMOND_HANDS_BADGE);
    if (sellRaw > buyRaw && sellRaw >= 100000000000n) badges.push(PAPER_HANDS_BADGE);
    if (activity.buyCount >= 10 && buyRaw >= 100000000000n && buyRaw > sellRaw) badges.push(ACCUMULATOR_BADGE);
  }
  if (entry.burnedTreeRaw !== void 0 && entry.burnedTreeRaw !== null) {
    const burnedRaw = parseUnsignedRaw(entry.burnedTreeRaw);
    if (burnedRaw === null || entry.burnedTree !== formatTreeRaw(burnedRaw)) return null;
    if (burnedRaw >= 500000000000n) badges.push(BURNED_BADGE);
  } else if (entry.burnedTree !== void 0 && entry.burnedTree !== null) return null;
  return badges;
}
function validateEntry(value, expectedRank) {
  const entry = record3(value);
  const wallet = normalizeSuiAddress(entry.wallet);
  if (!wallet || wallet !== entry.wallet || entry.rank !== expectedRank || !safeSuinsName(entry.suinsName)) return false;
  const liquidRaw = parseUnsignedRaw(entry.liquidTreeRaw);
  const lpRaw = parseUnsignedRaw(entry.lpTreeRaw);
  const totalRaw = parseUnsignedRaw(entry.totalExposureRaw);
  const breakdown = record3(entry.lpBreakdown);
  const v2Raw = parseUnsignedRaw(breakdown.suiDexV2Raw);
  const v3Raw = parseUnsignedRaw(breakdown.suiDexV3Raw);
  const turbosRaw = parseUnsignedRaw(breakdown.turbosRaw);
  if (liquidRaw === null || lpRaw === null || totalRaw === null || v2Raw === null || v3Raw === null || turbosRaw === null || totalRaw <= 0n || totalRaw > TREE_TOTAL_SUPPLY_RAW || lpRaw !== v2Raw + v3Raw + turbosRaw || totalRaw !== liquidRaw + lpRaw) return false;
  if (entry.liquidTree !== formatTreeRaw(liquidRaw) || entry.lpTree !== formatTreeRaw(lpRaw) || entry.totalExposure !== formatTreeRaw(totalRaw) || entry.supplyPercent !== formatTreeSupplyPercent(totalRaw) || breakdown.suiDexV2 !== formatTreeRaw(v2Raw) || breakdown.suiDexV3 !== formatTreeRaw(v3Raw) || breakdown.turbos !== formatTreeRaw(turbosRaw) || !safeNonNegativeInteger(entry.liquidCoinObjectCount) || !safeNonNegativeInteger(entry.lpPositionCount)) return false;
  const badges = Array.isArray(entry.badges) ? entry.badges : [];
  const expected = expectedBadges(liquidRaw, lpRaw, entry);
  if (!expected) return false;
  return badges.length === expected.length && badges.every((badge, index) => badge === expected[index]);
}
function validateSource(snapshot) {
  const source = record3(snapshot.source);
  const direct = record3(source.direct);
  if (direct.outcome !== "complete" || !safeNonNegativeInteger(direct.pagesScanned) || !safeNonNegativeInteger(direct.objectsScanned) || !safeNonNegativeInteger(direct.verifiedAddressOwners) || !safeNonNegativeInteger(direct.eligibleDirectOwners) || !safeNonNegativeInteger(direct.exposureCandidateCount) || direct.exposureCandidateCount !== direct.eligibleDirectOwners || parseUnsignedRaw(direct.addressOwnedRaw) === null) return false;
  const venues = record3(source.venues);
  for (const venue of ["suiDexV2", "suiDexV3", "turbos"]) {
    const summary = record3(venues[venue]);
    if (summary.outcome !== "complete" || !safeNonNegativeInteger(summary.walletCount) || !safeNonNegativeInteger(summary.positionCount) || parseUnsignedRaw(summary.principalTreeRaw) === null || !Array.isArray(summary.warnings) || !summary.warnings.every((warning) => typeof warning === "string") || !summary.coverage || typeof summary.coverage !== "object") return false;
  }
  const suins = record3(source.suins);
  return safeNonNegativeInteger(suins.requestedCount) && safeNonNegativeInteger(suins.resolvedCount) && suins.resolvedCount <= suins.requestedCount && typeof suins.complete === "boolean" && safeGeneratedAt(suins.generatedAt) && Array.isArray(suins.warnings) && suins.warnings.every((warning) => typeof warning === "string");
}
function validateCompleteExposureSnapshot(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const snapshot = value;
  if (snapshot.outcome !== "complete" || snapshot.provider !== EXPOSURE_SNAPSHOT_PROVIDER || snapshot.methodologyVersion !== TREE_EXPOSURE_METHODOLOGY_VERSION || !safeGeneratedAt(snapshot.generatedAt) || snapshot.coinSymbol !== "TREE" || snapshot.coinDecimals !== TREE_DECIMALS || snapshot.totalSupplyRaw !== TREE_TOTAL_SUPPLY_RAW.toString() || snapshot.displayedCount !== 50 || !Array.isArray(snapshot.entries) || snapshot.entries.length !== 50 || !safeNonNegativeInteger(snapshot.eligibleOwnerCount) || snapshot.eligibleOwnerCount < 50 || snapshot.coverage?.directTreeComplete !== true || snapshot.coverage?.suiDexV2Complete !== true || snapshot.coverage?.suiDexV3Complete !== true || snapshot.coverage?.turbosComplete !== true || snapshot.coverage?.totalExposureComplete !== true || !Array.isArray(snapshot.warnings) || !snapshot.warnings.every((warning) => typeof warning === "string")) return false;
  const wallets = /* @__PURE__ */ new Set();
  let top50TotalRaw = 0n;
  let top50LiquidRaw = 0n;
  let top50LpRaw = 0n;
  let lpProvider = 0;
  let lpMaxi = 0;
  let diamondHands = 0;
  let paperHands = 0;
  let accumulator = 0;
  let burned = 0;
  let previousTotalRaw = null;
  let previousLiquidRaw = null;
  let previousWallet = null;
  for (let index = 0; index < snapshot.entries.length; index += 1) {
    const entry = snapshot.entries[index];
    if (!validateEntry(entry, index + 1) || wallets.has(entry.wallet)) return false;
    const currentTotalRaw = BigInt(entry.totalExposureRaw);
    const currentLiquidRaw = BigInt(entry.liquidTreeRaw);
    if (previousTotalRaw !== null && previousLiquidRaw !== null && previousWallet !== null) {
      if (currentTotalRaw > previousTotalRaw || currentTotalRaw === previousTotalRaw && currentLiquidRaw > previousLiquidRaw || currentTotalRaw === previousTotalRaw && currentLiquidRaw === previousLiquidRaw && entry.wallet.localeCompare(previousWallet) < 0) return false;
    }
    previousTotalRaw = currentTotalRaw;
    previousLiquidRaw = currentLiquidRaw;
    previousWallet = entry.wallet;
    wallets.add(entry.wallet);
    top50TotalRaw += currentTotalRaw;
    top50LiquidRaw += currentLiquidRaw;
    top50LpRaw += BigInt(entry.lpTreeRaw);
    if (entry.badges.includes(LP_PROVIDER_BADGE)) lpProvider += 1;
    if (entry.badges.includes(LP_MAXI_BADGE)) lpMaxi += 1;
    if (entry.badges.includes(DIAMOND_HANDS_BADGE)) diamondHands += 1;
    if (entry.badges.includes(PAPER_HANDS_BADGE)) paperHands += 1;
    if (entry.badges.includes(ACCUMULATOR_BADGE)) accumulator += 1;
    if (entry.badges.includes(BURNED_BADGE)) burned += 1;
  }
  if (top50TotalRaw > TREE_TOTAL_SUPPLY_RAW) return false;
  const summary = record3(snapshot.summary);
  const badgeCounts = record3(summary.badgeCounts);
  return summary.top50TotalRaw === top50TotalRaw.toString() && summary.top50LiquidRaw === top50LiquidRaw.toString() && summary.top50LpRaw === top50LpRaw.toString() && summary.rank50CutoffRaw === snapshot.entries[49].totalExposureRaw && badgeCounts.lpProvider === lpProvider && badgeCounts.lpMaxi === lpMaxi && (badgeCounts.diamondHands === void 0 || badgeCounts.diamondHands === diamondHands) && (badgeCounts.paperHands === void 0 || badgeCounts.paperHands === paperHands) && (badgeCounts.accumulator === void 0 || badgeCounts.accumulator === accumulator) && (badgeCounts.burned === void 0 || badgeCounts.burned === burned) && validateSource(snapshot);
}
async function writeCompleteExposureSnapshot(snapshot, options = {}) {
  if (!validateCompleteExposureSnapshot(snapshot)) return false;
  await resolveStore(options).setJSON(COMPLETE_EXPOSURE_SNAPSHOT_KEY, snapshot);
  return true;
}
function sanitizeRefreshStatus(status) {
  return {
    state: status.state,
    stage: status.stage,
    runId: status.runId,
    startedAt: status.startedAt,
    updatedAt: status.updatedAt,
    completedAt: status.completedAt,
    directPagesScanned: status.directPagesScanned,
    directObjectsScanned: status.directObjectsScanned,
    directUniqueOwners: status.directUniqueOwners,
    venueOutcomes: {
      suiDexV2: status.venueOutcomes.suiDexV2,
      suiDexV3: status.venueOutcomes.suiDexV3,
      turbos: status.venueOutcomes.turbos
    },
    totalExposureComplete: status.totalExposureComplete,
    displayedCount: status.displayedCount,
    message: status.message,
    commitRef: status.commitRef,
    deployId: status.deployId
  };
}
async function writeExposureRefreshStatus(status, options = {}) {
  await resolveStore(options).setJSON(EXPOSURE_REFRESH_STATUS_KEY, sanitizeRefreshStatus(status));
}
async function readExposureRefreshLock(options = {}) {
  const value = await resolveStore(options).get(EXPOSURE_REFRESH_LOCK_KEY, { type: "json" });
  return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}
async function writeExposureRefreshLock(lock, options = {}) {
  await resolveStore(options).setJSON(EXPOSURE_REFRESH_LOCK_KEY, lock);
}
async function clearExposureRefreshLock(runId, options = {}) {
  const store = resolveStore(options);
  const current = await readExposureRefreshLock({ store });
  if (!current || current.runId !== runId) return false;
  await store.delete(EXPOSURE_REFRESH_LOCK_KEY);
  return true;
}

// netlify/lib/suidex-v2-tree-lp-provider.ts
import { ChannelCredentials } from "@grpc/grpc-js";
import { GrpcTransport } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient } from "@mysten/sui/grpc";
var SUIDEX_V2_PACKAGE = "0xbfac5e1c6bf6ef29b12f7723857695fd2f4da9a11a7d88162c15e9124c243a4a";
var SUIDEX_V2_TREE_POOL_ID = "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc";
var SUI_COIN_TYPE = "0x2::sui::SUI";
var SUIDEX_V2_TREE_LP_TYPE = `${SUIDEX_V2_PACKAGE}::pair::LPCoin<${SUI_COIN_TYPE},${TREE_COIN_TYPE}>`;
var SUIDEX_V2_TREE_LP_COIN_TYPE = `0x2::coin::Coin<${SUIDEX_V2_TREE_LP_TYPE}>`;
var SUIDEX_V2_TREE_FARM_POSITION_TYPE = `${SUIDEX_V2_PACKAGE}::farm::StakingPosition<${SUIDEX_V2_TREE_LP_TYPE}>`;
var SUIDEX_V2_PROVIDER = "suidex-v2-onchain";
var SUIDEX_V2_METHODOLOGY_VERSION = "suidex-v2-tree-lp-v1";
var DEFAULT_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var DEFAULT_GRPC_HOST = "fullnode.mainnet.sui.io:443";
var TYPE_SCAN_QUERY = `query ScanTypedObjects($first: Int!, $after: String, $type: String!) {
  objects(first: $first, after: $after, filter: { type: $type }) {
    pageInfo { hasNextPage endCursor }
    nodes {
      address
      owner {
        __typename
        ... on AddressOwner { address { address } }
        ... on ObjectOwner { address { address } }
      }
      asMoveObject {
        contents {
          json
          balanceField: extract(path: "balance") { json }
          amountField: extract(path: "amount") { json }
        }
      }
    }
  }
}`;
function record4(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function ownerAddress2(node) {
  const owner = record4(node.owner);
  if (owner.__typename !== "AddressOwner") return null;
  const address = owner.address;
  return normalizeSuiAddress(typeof address === "string" ? address : record4(address).address);
}
function rawField(node, field) {
  const contents = record4(record4(node.asMoveObject).contents);
  const extracted = record4(contents[`${field}Field`]).json;
  const json = record4(contents.json);
  return parseUnsignedRaw(extracted ?? json[field]);
}
async function defaultPoolObject(grpcHost) {
  const client = new SuiGrpcClient({
    network: "mainnet",
    transport: new GrpcTransport({
      host: grpcHost.replace(/^https?:\/\//, ""),
      channelCredentials: ChannelCredentials.createSsl()
    })
  });
  const { object } = await client.core.getObject({ objectId: SUIDEX_V2_TREE_POOL_ID, include: { json: true } });
  return object ? { type: object.type, json: object.json } : {};
}
async function defaultScanType(type, endpoint2, fetchImpl) {
  const nodes = [];
  let after = null;
  for (let page = 0; page < 100; page += 1) {
    const response = await fetchImpl(endpoint2, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({ query: TYPE_SCAN_QUERY, variables: { first: 50, after, type } })
    });
    if (!response.ok) throw new Error(`Sui GraphQL returned HTTP ${response.status}`);
    const payload = record4(await response.json());
    const errors = Array.isArray(payload.errors) ? payload.errors : [];
    if (errors.length) throw new Error(errors.map((item) => String(record4(item).message || "GraphQL error")).join(" | "));
    const connection = record4(record4(payload.data).objects);
    const pageInfo = record4(connection.pageInfo);
    const pageNodes = Array.isArray(connection.nodes) ? connection.nodes.filter((item) => Boolean(item && typeof item === "object")) : [];
    nodes.push(...pageNodes);
    if (pageInfo.hasNextPage !== true) return { nodes, reachedEnd: true, pages: page + 1 };
    if (typeof pageInfo.endCursor !== "string" || !pageInfo.endCursor) return { nodes, reachedEnd: false, pages: page + 1 };
    after = pageInfo.endCursor;
  }
  return { nodes, reachedEnd: false, pages: 100 };
}
function verifyPool(value) {
  const json = record4(value.json);
  const reserveTreeRaw = parseUnsignedRaw(json.reserve1);
  const totalSupplyRaw = parseUnsignedRaw(json.total_supply);
  const lpSupplyRaw = parseUnsignedRaw(record4(json.lp_supply).value);
  const type = typeof value.type === "string" ? value.type.toLowerCase() : "";
  const expectedTree = TREE_COIN_TYPE.toLowerCase().replace(/^0x/, "");
  const validType = type.includes("::pair::pair<") && type.includes("::sui::sui") && type.includes(expectedTree);
  const validSupply = totalSupplyRaw !== null && totalSupplyRaw > 0n && lpSupplyRaw === totalSupplyRaw;
  return {
    valid: validType && reserveTreeRaw !== null && reserveTreeRaw >= 0n && validSupply,
    reserveTreeRaw,
    totalSupplyRaw
  };
}
function lpRawToTreeRaw(lpRaw, reserveTreeRaw, totalLpSupplyRaw) {
  if (lpRaw <= 0n || reserveTreeRaw <= 0n || totalLpSupplyRaw <= 0n) return 0n;
  return lpRaw * reserveTreeRaw / totalLpSupplyRaw;
}
async function scanSuiDexV2TreeLp(options = {}) {
  const generatedAt = options.generatedAt || (/* @__PURE__ */ new Date()).toISOString();
  const coverage = {
    poolVerified: false,
    poolId: SUIDEX_V2_TREE_POOL_ID,
    reserveTreeRaw: null,
    totalLpSupplyRaw: null,
    pagesScanned: 0,
    directLpCoinObjects: 0,
    farmPositionObjects: 0,
    uniqueOwners: 0,
    directLpRaw: "0",
    stakedLpRaw: "0",
    attributedLpRaw: "0",
    malformedOwners: 0,
    malformedBalances: 0,
    duplicateObjectIds: 0,
    excludedObjects: 0,
    reachedEnd: false,
    scanComplete: false,
    networkError: null,
    graphqlErrors: []
  };
  const warnings = [];
  const positions = [];
  try {
    const pool = verifyPool(await (options.getPoolObject || (() => defaultPoolObject(options.grpcHost || DEFAULT_GRPC_HOST)))());
    coverage.poolVerified = pool.valid;
    coverage.reserveTreeRaw = pool.reserveTreeRaw?.toString() ?? null;
    coverage.totalLpSupplyRaw = pool.totalSupplyRaw?.toString() ?? null;
    if (!pool.valid || pool.reserveTreeRaw === null || pool.totalSupplyRaw === null) {
      warnings.push("The SuiDex V2 TREE/SUI pool could not be verified; no LP exposure was published.");
      return {
        venue: "suiDexV2",
        outcome: "verification-incomplete",
        provider: SUIDEX_V2_PROVIDER,
        methodologyVersion: SUIDEX_V2_METHODOLOGY_VERSION,
        generatedAt,
        positions,
        coverage,
        pool: { poolId: SUIDEX_V2_TREE_POOL_ID, reserveTreeRaw: coverage.reserveTreeRaw, totalLpSupplyRaw: coverage.totalLpSupplyRaw },
        warnings
      };
    }
    const scan = options.scanType || ((type) => defaultScanType(type, options.graphqlUrl || DEFAULT_GRAPHQL_URL, options.fetchImpl || fetch));
    const [direct, farm] = await Promise.all([scan(SUIDEX_V2_TREE_LP_COIN_TYPE), scan(SUIDEX_V2_TREE_FARM_POSITION_TYPE)]);
    coverage.pagesScanned = direct.pages + farm.pages;
    coverage.directLpCoinObjects = direct.nodes.length;
    coverage.farmPositionObjects = farm.nodes.length;
    coverage.reachedEnd = direct.reachedEnd && farm.reachedEnd;
    const seen = /* @__PURE__ */ new Set();
    const wallets = /* @__PURE__ */ new Map();
    const consume = (node, field) => {
      const objectId = normalizeSuiAddress(node.address);
      if (!objectId || seen.has(objectId)) {
        coverage.duplicateObjectIds += seen.has(objectId || "") ? 1 : 0;
        return;
      }
      seen.add(objectId);
      const wallet = ownerAddress2(node);
      if (!wallet) {
        coverage.malformedOwners += 1;
        return;
      }
      if (excludedAddress(wallet)) {
        coverage.excludedObjects += 1;
        return;
      }
      const raw = rawField(node, field);
      if (raw === null) {
        coverage.malformedBalances += 1;
        return;
      }
      const prior = wallets.get(wallet) || { directLpRaw: 0n, stakedLpRaw: 0n, positionCount: 0 };
      if (field === "balance") prior.directLpRaw += raw;
      else prior.stakedLpRaw += raw;
      prior.positionCount += 1;
      wallets.set(wallet, prior);
    };
    direct.nodes.forEach((node) => consume(node, "balance"));
    farm.nodes.forEach((node) => consume(node, "amount"));
    let directLpRaw = 0n;
    let stakedLpRaw = 0n;
    for (const [wallet, value] of wallets) {
      directLpRaw += value.directLpRaw;
      stakedLpRaw += value.stakedLpRaw;
      const totalLpRaw = value.directLpRaw + value.stakedLpRaw;
      const lpTreeRaw = lpRawToTreeRaw(totalLpRaw, pool.reserveTreeRaw, pool.totalSupplyRaw);
      if (lpTreeRaw > 0n) positions.push({
        wallet,
        venue: "suiDexV2",
        lpTreeRaw: lpTreeRaw.toString(),
        positionCount: value.positionCount,
        metadata: {
          directLpRaw: value.directLpRaw.toString(),
          stakedLpRaw: value.stakedLpRaw.toString(),
          totalLpRaw: totalLpRaw.toString()
        }
      });
    }
    const attributedLpRaw = directLpRaw + stakedLpRaw;
    coverage.uniqueOwners = positions.length;
    coverage.directLpRaw = directLpRaw.toString();
    coverage.stakedLpRaw = stakedLpRaw.toString();
    coverage.attributedLpRaw = attributedLpRaw.toString();
    const integrityValid = coverage.malformedOwners === 0 && coverage.malformedBalances === 0 && coverage.duplicateObjectIds === 0 && attributedLpRaw <= pool.totalSupplyRaw;
    coverage.scanComplete = coverage.poolVerified && coverage.reachedEnd && integrityValid;
    if (!coverage.reachedEnd) warnings.push("The SuiDex V2 LP scan did not reach the natural end; partial exposure was not published.");
    if (!integrityValid) warnings.push("SuiDex V2 LP data integrity verification failed; partial exposure was not published.");
    if (!coverage.scanComplete) positions.length = 0;
    return {
      venue: "suiDexV2",
      outcome: coverage.scanComplete ? "complete" : "verification-incomplete",
      provider: SUIDEX_V2_PROVIDER,
      methodologyVersion: SUIDEX_V2_METHODOLOGY_VERSION,
      generatedAt,
      positions,
      coverage,
      pool: { poolId: SUIDEX_V2_TREE_POOL_ID, reserveTreeRaw: coverage.reserveTreeRaw, totalLpSupplyRaw: coverage.totalLpSupplyRaw },
      warnings
    };
  } catch (error) {
    coverage.networkError = error instanceof Error ? error.message : "SuiDex V2 LP scan failed.";
    warnings.push("The SuiDex V2 LP provider failed; no partial exposure was published.");
    return {
      venue: "suiDexV2",
      outcome: "error",
      provider: SUIDEX_V2_PROVIDER,
      methodologyVersion: SUIDEX_V2_METHODOLOGY_VERSION,
      generatedAt,
      positions: [],
      coverage,
      pool: { poolId: SUIDEX_V2_TREE_POOL_ID, reserveTreeRaw: coverage.reserveTreeRaw, totalLpSupplyRaw: coverage.totalLpSupplyRaw },
      warnings
    };
  }
}

// netlify/lib/suidex-v3-tree-lp-provider.ts
import { ChannelCredentials as ChannelCredentials2 } from "@grpc/grpc-js";
import { GrpcTransport as GrpcTransport2 } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient as SuiGrpcClient2 } from "@mysten/sui/grpc";

// netlify/lib/clmm-q64.ts
var CLMM_Q64 = 1n << 64n;
var CLMM_MIN_TICK = -443636;
var CLMM_MAX_TICK = 443636;
var NEGATIVE_TICK_FACTORS = [
  18445821805675392311n,
  18444899583751176498n,
  18443055278223354162n,
  18439367220385604838n,
  18431993317065449817n,
  18417254355718160513n,
  18387811781193591352n,
  18329067761203520168n,
  18212142134806085854n,
  17980523815641551639n,
  17526086738831147013n,
  16651378430235024244n,
  15030750278693429944n,
  12247334978882834399n,
  8131365268884822000n,
  3584323654723342297n,
  696457651847595233n,
  26294789957452057n,
  37481735321082n
];
var POSITIVE_TICK_FACTORS = [
  79232123823359799118286999567n,
  79236085330515764027303304731n,
  79244008939048815603706035061n,
  79259858533276714757314932305n,
  79291567232598584799939703904n,
  79355022692464371645785046466n,
  79482085999252804386437311141n,
  79736823300114093921829183326n,
  80248749790819932309965073892n,
  81282483887344747381513967011n,
  83390072131320151908154828281n,
  87770609709833876024991924138n,
  97234110755111693312479820773n,
  119332217159966728226237229890n,
  179736315981702064433883588727n,
  407748233172238350107850275304n,
  2098478828474011912436660412517n,
  55581415166113811149459800483533n,
  38992368544603139932233054999993551n
];
function parseUnsignedInteger(value, maximum) {
  let candidate = value;
  if (candidate && typeof candidate === "object" && !Array.isArray(candidate)) {
    candidate = candidate.bits;
  }
  if (typeof candidate === "number") {
    if (!Number.isSafeInteger(candidate) || candidate < 0) return null;
    candidate = String(candidate);
  }
  if (typeof candidate !== "string" || !/^\d+$/.test(candidate)) return null;
  try {
    const parsed = BigInt(candidate);
    if (maximum !== void 0 && parsed > maximum) return null;
    return parsed;
  } catch {
    return null;
  }
}
function parseSignedI32(value) {
  const raw = parseUnsignedInteger(value, 0xffffffffn);
  if (raw === null) return null;
  const signed = raw >= 0x80000000n ? raw - 0x100000000n : raw;
  const result = Number(signed);
  return Number.isSafeInteger(result) ? result : null;
}
function tickToSqrtPriceQ64(tick) {
  if (!Number.isSafeInteger(tick) || tick < CLMM_MIN_TICK || tick > CLMM_MAX_TICK) {
    throw new RangeError(`CLMM tick ${tick} is outside [${CLMM_MIN_TICK}, ${CLMM_MAX_TICK}].`);
  }
  const absoluteTick = Math.abs(tick);
  if (tick < 0) {
    let ratio2 = (absoluteTick & 1) !== 0 ? NEGATIVE_TICK_FACTORS[0] : CLMM_Q64;
    for (let bit = 1; bit < NEGATIVE_TICK_FACTORS.length; bit += 1) {
      if ((absoluteTick & 1 << bit) !== 0) ratio2 = ratio2 * NEGATIVE_TICK_FACTORS[bit] >> 64n;
    }
    return ratio2;
  }
  let ratio = (absoluteTick & 1) !== 0 ? POSITIVE_TICK_FACTORS[0] : 79228162514264337593543950336n;
  for (let bit = 1; bit < POSITIVE_TICK_FACTORS.length; bit += 1) {
    if ((absoluteTick & 1 << bit) !== 0) ratio = ratio * POSITIVE_TICK_FACTORS[bit] >> 96n;
  }
  return ratio >> 32n;
}
function amountXDelta(lower, upper, liquidity) {
  if (liquidity <= 0n || lower <= 0n || upper <= lower) return 0n;
  return liquidity * (upper - lower) * CLMM_Q64 / (lower * upper);
}
function amountYDelta(lower, upper, liquidity) {
  if (liquidity <= 0n || lower <= 0n || upper <= lower) return 0n;
  return liquidity * (upper - lower) / CLMM_Q64;
}
function amountsForLiquidityQ64(currentSqrtPrice, lowerSqrtPrice, upperSqrtPrice, liquidity) {
  if (currentSqrtPrice <= 0n || lowerSqrtPrice <= 0n || upperSqrtPrice <= lowerSqrtPrice || liquidity <= 0n) {
    return { amountX: 0n, amountY: 0n };
  }
  if (currentSqrtPrice <= lowerSqrtPrice) {
    return { amountX: amountXDelta(lowerSqrtPrice, upperSqrtPrice, liquidity), amountY: 0n };
  }
  if (currentSqrtPrice >= upperSqrtPrice) {
    return { amountX: 0n, amountY: amountYDelta(lowerSqrtPrice, upperSqrtPrice, liquidity) };
  }
  return {
    amountX: amountXDelta(currentSqrtPrice, upperSqrtPrice, liquidity),
    amountY: amountYDelta(lowerSqrtPrice, currentSqrtPrice, liquidity)
  };
}

// netlify/lib/suidex-v3-tree-lp-provider.ts
var SUIDEX_V3_PACKAGE = "0xb5f529c1dcda6580a61bf7ee9fbd524b50be62f11044d137c8202c8cbace9e56";
var SUIDEX_V3_POSITION_TYPE = `${SUIDEX_V3_PACKAGE}::position::Position`;
var SUIDEX_V3_PROVIDER = "suidex-v3-onchain";
var SUIDEX_V3_METHODOLOGY_VERSION = "suidex-v3-tree-principal-v1";
var DEFAULT_GRAPHQL_URL2 = "https://graphql.mainnet.sui.io/graphql";
var DEFAULT_GRPC_HOST2 = "fullnode.mainnet.sui.io:443";
var DEFAULT_MAX_PAGES2 = 100;
var DEFAULT_PAGE_SIZE2 = 50;
var POSITION_SCAN_QUERY = `query ScanSuiDexV3Positions($first: Int!, $after: String, $type: String!) {
  objects(first: $first, after: $after, filter: { type: $type }) {
    pageInfo { hasNextPage endCursor }
    nodes {
      address
      owner {
        __typename
        ... on AddressOwner { address { address } }
        ... on ObjectOwner { address { address } }
      }
      asMoveObject { contents { json } }
    }
  }
}`;
function record5(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function normalizeCoinType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  const parts = compact.split("::");
  if (parts.length !== 3 || !/^(0x)?[0-9a-f]+$/.test(parts[0]) || !parts[1] || !parts[2]) return null;
  const address = parts[0].replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${address}::${parts[1]}::${parts[2]}`;
}
var NORMALIZED_TREE = normalizeCoinType(TREE_COIN_TYPE);
function ownerAddress3(node) {
  const owner = record5(node.owner);
  const addressValue = owner.address;
  const rawAddress = typeof addressValue === "string" ? addressValue : record5(addressValue).address;
  return {
    kind: typeof owner.__typename === "string" ? owner.__typename : "Unknown",
    address: normalizeSuiAddress(rawAddress)
  };
}
function optionalUnsigned(value) {
  if (value === void 0 || value === null) return 0n;
  return parseUnsignedRaw(value);
}
async function defaultScanPositions(endpoint2, fetchImpl, pageSize, maxPages) {
  const nodes = [];
  let after = null;
  for (let page = 0; page < maxPages; page += 1) {
    const response = await fetchImpl(endpoint2, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({
        query: POSITION_SCAN_QUERY,
        variables: { first: pageSize, after, type: SUIDEX_V3_POSITION_TYPE }
      })
    });
    if (!response.ok) throw new Error(`Sui GraphQL returned HTTP ${response.status}`);
    const payload = record5(await response.json());
    const errors = Array.isArray(payload.errors) ? payload.errors : [];
    if (errors.length) throw new Error(errors.map((item) => String(record5(item).message || "GraphQL error")).join(" | "));
    const connection = record5(record5(payload.data).objects);
    const pageInfo = record5(connection.pageInfo);
    const pageNodes = Array.isArray(connection.nodes) ? connection.nodes.filter((item) => Boolean(item && typeof item === "object")) : [];
    nodes.push(...pageNodes);
    if (pageInfo.hasNextPage !== true) return { nodes, reachedEnd: true, pages: page + 1 };
    if (typeof pageInfo.endCursor !== "string" || !pageInfo.endCursor) return { nodes, reachedEnd: false, pages: page + 1 };
    after = pageInfo.endCursor;
  }
  return { nodes, reachedEnd: false, pages: maxPages };
}
function defaultPoolGetter(grpcHost) {
  const client = new SuiGrpcClient2({
    network: "mainnet",
    transport: new GrpcTransport2({
      host: grpcHost.replace(/^https?:\/\//, ""),
      channelCredentials: ChannelCredentials2.createSsl()
    })
  });
  return async (poolId) => {
    const { object } = await client.core.getObject({ objectId: poolId, include: { json: true } });
    return object ? { type: object.type, json: object.json } : {};
  };
}
function poolObjectTypeVerified(value) {
  if (typeof value !== "string") return false;
  const compact = value.toLowerCase().replace(/\s+/g, "");
  return compact.includes(SUIDEX_V3_PACKAGE.slice(2).toLowerCase()) && compact.includes("::pool::pool<");
}
function verifyPool2(poolId, value, expectedTokenX, expectedTokenY) {
  const json = record5(value.json);
  const id = normalizeSuiAddress(json.id);
  const tokenX = normalizeCoinType(json.type_x);
  const tokenY = normalizeCoinType(json.type_y);
  const currentSqrtPrice = parseUnsignedRaw(json.sqrt_price);
  const currentTick = parseSignedI32(json.tick_index);
  const reserveX = parseUnsignedRaw(json.reserve_x);
  const reserveY = parseUnsignedRaw(json.reserve_y);
  const poolLiquidity = parseUnsignedRaw(json.liquidity);
  if (!poolObjectTypeVerified(value.type) || id !== poolId || tokenX !== expectedTokenX || tokenY !== expectedTokenY || tokenX !== NORMALIZED_TREE && tokenY !== NORMALIZED_TREE || tokenX === tokenY || currentSqrtPrice === null || currentSqrtPrice <= 0n || currentTick === null || currentTick < CLMM_MIN_TICK || currentTick > CLMM_MAX_TICK || reserveX === null || reserveY === null || poolLiquidity === null) return null;
  const lowerBoundary = tickToSqrtPriceQ64(currentTick);
  const upperBoundary = currentTick < CLMM_MAX_TICK ? tickToSqrtPriceQ64(currentTick + 1) : currentSqrtPrice + 1n;
  if (currentSqrtPrice < lowerBoundary || currentSqrtPrice >= upperBoundary) return null;
  return { poolId, tokenX, tokenY, currentSqrtPrice, reserveX, reserveY };
}
async function scanSuiDexV3TreeLp(options = {}) {
  const generatedAt = options.generatedAt || (/* @__PURE__ */ new Date()).toISOString();
  const coverage = {
    positionType: SUIDEX_V3_POSITION_TYPE,
    pagesScanned: 0,
    objectsScanned: 0,
    treePositionObjects: 0,
    addressOwnedTreePositions: 0,
    nonAddressOwnedTreePositions: 0,
    uniqueOwners: 0,
    uniquePools: 0,
    verifiedPools: 0,
    poolIds: [],
    malformedObjects: 0,
    malformedOwners: 0,
    duplicateObjectIds: 0,
    excludedObjects: 0,
    excludedPrincipalTreeRaw: "0",
    aggregatePrincipalTreeRaw: "0",
    unclaimedTreeRawExcluded: "0",
    reconciliationFailures: 0,
    reachedEnd: false,
    scanComplete: false,
    networkError: null,
    graphqlErrors: []
  };
  const warnings = ["SuiDex V3 exposure includes current principal liquidity only; unclaimed fees and incentive rewards are excluded."];
  try {
    const pageSize = Math.max(1, Math.min(50, Math.trunc(options.pageSize ?? DEFAULT_PAGE_SIZE2)));
    const maxPages = Math.max(1, Math.min(500, Math.trunc(options.maxPages ?? DEFAULT_MAX_PAGES2)));
    const scan = await (options.scanPositions || (() => defaultScanPositions(
      options.graphqlUrl || DEFAULT_GRAPHQL_URL2,
      options.fetchImpl || fetch,
      pageSize,
      maxPages
    )))();
    coverage.pagesScanned = scan.pages;
    coverage.objectsScanned = scan.nodes.length;
    coverage.reachedEnd = scan.reachedEnd;
    const seenObjectIds = /* @__PURE__ */ new Set();
    const expectedPools = /* @__PURE__ */ new Map();
    const parsedPositions = [];
    for (const node of scan.nodes) {
      const objectId = normalizeSuiAddress(node.address);
      if (!objectId) {
        coverage.malformedObjects += 1;
        continue;
      }
      if (seenObjectIds.has(objectId)) {
        coverage.duplicateObjectIds += 1;
        continue;
      }
      seenObjectIds.add(objectId);
      const json = record5(record5(record5(node.asMoveObject).contents).json);
      const tokenX = normalizeCoinType(json.type_x);
      const tokenY = normalizeCoinType(json.type_y);
      if (!tokenX || !tokenY) {
        coverage.malformedObjects += 1;
        continue;
      }
      const treeSide = tokenX === NORMALIZED_TREE ? "x" : tokenY === NORMALIZED_TREE ? "y" : null;
      if (!treeSide) continue;
      coverage.treePositionObjects += 1;
      if (tokenX === tokenY) {
        coverage.malformedObjects += 1;
        continue;
      }
      const owner = ownerAddress3(node);
      if (owner.kind !== "AddressOwner") {
        coverage.nonAddressOwnedTreePositions += 1;
        continue;
      }
      if (!owner.address) {
        coverage.malformedOwners += 1;
        continue;
      }
      coverage.addressOwnedTreePositions += 1;
      const poolId = normalizeSuiAddress(json.pool_id);
      const liquidity = parseUnsignedRaw(json.liquidity);
      const tickLower = parseSignedI32(json.tick_lower_index);
      const tickUpper = parseSignedI32(json.tick_upper_index);
      const unclaimedTreeRaw = optionalUnsigned(treeSide === "x" ? json.owed_coin_x : json.owed_coin_y);
      if (!poolId || liquidity === null || tickLower === null || tickUpper === null || tickLower < CLMM_MIN_TICK || tickUpper > CLMM_MAX_TICK || tickLower >= tickUpper || unclaimedTreeRaw === null) {
        coverage.malformedObjects += 1;
        continue;
      }
      const expected = expectedPools.get(poolId);
      if (expected && (expected.tokenX !== tokenX || expected.tokenY !== tokenY)) {
        coverage.malformedObjects += 1;
        continue;
      }
      expectedPools.set(poolId, { tokenX, tokenY });
      parsedPositions.push({
        objectId,
        wallet: owner.address,
        excluded: Boolean(excludedAddress(owner.address)),
        poolId,
        tokenX,
        tokenY,
        treeSide,
        tickLower,
        tickUpper,
        liquidity,
        unclaimedTreeRaw
      });
    }
    coverage.uniquePools = expectedPools.size;
    coverage.poolIds = [...expectedPools.keys()].sort();
    const getPoolObject = options.getPoolObject || defaultPoolGetter(options.grpcHost || DEFAULT_GRPC_HOST2);
    const verifiedPools = /* @__PURE__ */ new Map();
    for (const [poolId, expected] of expectedPools) {
      const verified = verifyPool2(poolId, await getPoolObject(poolId), expected.tokenX, expected.tokenY);
      if (!verified) {
        coverage.malformedObjects += 1;
        continue;
      }
      verifiedPools.set(poolId, verified);
    }
    coverage.verifiedPools = verifiedPools.size;
    const walletTotals = /* @__PURE__ */ new Map();
    const poolTotals = /* @__PURE__ */ new Map();
    let aggregatePrincipalTreeRaw = 0n;
    let excludedPrincipalTreeRaw = 0n;
    let unclaimedTreeRawExcluded = 0n;
    for (const position of parsedPositions) {
      const pool = verifiedPools.get(position.poolId);
      if (!pool) continue;
      const lowerSqrtPrice = tickToSqrtPriceQ64(position.tickLower);
      const upperSqrtPrice = tickToSqrtPriceQ64(position.tickUpper);
      const amounts = amountsForLiquidityQ64(
        pool.currentSqrtPrice,
        lowerSqrtPrice,
        upperSqrtPrice,
        position.liquidity
      );
      const poolTotal = poolTotals.get(position.poolId) || { amountX: 0n, amountY: 0n };
      poolTotal.amountX += amounts.amountX;
      poolTotal.amountY += amounts.amountY;
      poolTotals.set(position.poolId, poolTotal);
      const principalTreeRaw = position.treeSide === "x" ? amounts.amountX : amounts.amountY;
      aggregatePrincipalTreeRaw += principalTreeRaw;
      unclaimedTreeRawExcluded += position.unclaimedTreeRaw;
      if (position.excluded) {
        coverage.excludedObjects += 1;
        excludedPrincipalTreeRaw += principalTreeRaw;
        continue;
      }
      if (principalTreeRaw <= 0n) continue;
      const prior = walletTotals.get(position.wallet) || {
        treeRaw: 0n,
        unclaimedTreeRaw: 0n,
        positionCount: 0,
        poolIds: /* @__PURE__ */ new Set()
      };
      prior.treeRaw += principalTreeRaw;
      prior.unclaimedTreeRaw += position.unclaimedTreeRaw;
      prior.positionCount += 1;
      prior.poolIds.add(position.poolId);
      walletTotals.set(position.wallet, prior);
    }
    for (const [poolId, totals] of poolTotals) {
      const pool = verifiedPools.get(poolId);
      if (!pool || totals.amountX > pool.reserveX || totals.amountY > pool.reserveY) {
        coverage.reconciliationFailures += 1;
      }
    }
    coverage.uniqueOwners = walletTotals.size;
    coverage.aggregatePrincipalTreeRaw = aggregatePrincipalTreeRaw.toString();
    coverage.excludedPrincipalTreeRaw = excludedPrincipalTreeRaw.toString();
    coverage.unclaimedTreeRawExcluded = unclaimedTreeRawExcluded.toString();
    const integrityValid = coverage.malformedObjects === 0 && coverage.malformedOwners === 0 && coverage.duplicateObjectIds === 0 && coverage.nonAddressOwnedTreePositions === 0 && coverage.verifiedPools === coverage.uniquePools && coverage.reconciliationFailures === 0;
    coverage.scanComplete = coverage.reachedEnd && integrityValid;
    if (!coverage.reachedEnd) warnings.push("The SuiDex V3 position scan did not reach its natural end; partial exposure was not published.");
    if (coverage.nonAddressOwnedTreePositions) warnings.push("One or more TREE positions were not directly address-owned; owner attribution was incomplete.");
    if (!integrityValid) warnings.push("SuiDex V3 TREE position integrity verification failed; partial exposure was not published.");
    const positions = coverage.scanComplete ? [...walletTotals.entries()].sort(([left], [right]) => left.localeCompare(right)).map(([wallet, value]) => ({
      wallet,
      venue: "suiDexV3",
      lpTreeRaw: value.treeRaw.toString(),
      positionCount: value.positionCount,
      metadata: {
        principalOnly: true,
        poolIds: [...value.poolIds].sort(),
        unclaimedTreeRawExcluded: value.unclaimedTreeRaw.toString()
      }
    })) : [];
    return {
      venue: "suiDexV3",
      outcome: coverage.scanComplete ? "complete" : "verification-incomplete",
      provider: SUIDEX_V3_PROVIDER,
      methodologyVersion: SUIDEX_V3_METHODOLOGY_VERSION,
      generatedAt,
      positions,
      coverage,
      warnings
    };
  } catch (error) {
    coverage.networkError = error instanceof Error ? error.message : "SuiDex V3 TREE LP scan failed.";
    warnings.push("The SuiDex V3 provider failed; no partial exposure was published.");
    return {
      venue: "suiDexV3",
      outcome: "error",
      provider: SUIDEX_V3_PROVIDER,
      methodologyVersion: SUIDEX_V3_METHODOLOGY_VERSION,
      generatedAt,
      positions: [],
      coverage,
      warnings
    };
  }
}

// netlify/lib/turbos-tree-lp-provider.ts
import { ChannelCredentials as ChannelCredentials3 } from "@grpc/grpc-js";
import { GrpcTransport as GrpcTransport3 } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient as SuiGrpcClient3 } from "@mysten/sui/grpc";
var TURBOS_PACKAGE = "0x91bfbc386a41afcfd9b2533058d7e915a1d3829089cc268ff4333d54d6339ca1";
var TURBOS_POSITION_NFT_TYPE = `${TURBOS_PACKAGE}::position_nft::TurbosPositionNFT`;
var TURBOS_POSITION_TYPE = `${TURBOS_PACKAGE}::position_manager::Position`;
var TURBOS_PROVIDER = "turbos-onchain";
var TURBOS_METHODOLOGY_VERSION = "turbos-tree-principal-pool-index-v2";
var TURBOS_POOL_POSITION_VALUE_TYPE = `${TURBOS_PACKAGE}::pool::Position`;
var TURBOS_TREE_POOL_IDS = [
  "0x4a8c450d393fee360fc8c2a2ed30bf6f9e4de5077024e9628cd3510e272bf490",
  "0xaa133ce1f8fd55d85b6fc87c1b3054cb717d83be477ef3635c661c21fbdfa0ee",
  "0xc327fdc9b129602e91df9bd59cf3e4a921ce5509844a3b6c8adddc5ed320636d",
  "0xd5d7d9a614327feed096a437f416aa98f440393d9ac52d97c87e6e0dd6e719bb",
  "0xe1468ece8e4d2940b30dec776eaee9b235b23458868027da871bc42817263a12"
];
var DEFAULT_GRPC_HOST3 = "fullnode.mainnet.sui.io:443";
var DEFAULT_MAX_PAGES3 = 2e3;
var DEFAULT_PAGE_SIZE3 = 50;
var DEFAULT_MAX_RETRIES = 6;
function record6(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function canonicalAddress(value) {
  const address = value.toLowerCase().replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${address}`;
}
function normalizeStructType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  const parts = compact.split("::");
  if (parts.length !== 3 || !/^(0x)?[0-9a-f]+$/.test(parts[0]) || !parts[1] || !parts[2]) return null;
  return `${canonicalAddress(parts[0])}::${parts[1]}::${parts[2]}`;
}
function canonicalizeMoveType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  if (!compact) return null;
  return compact.replace(/(^|[<,])((?:0x)?[0-9a-f]+)(?=::)/g, (_match, prefix, address) => `${prefix}${canonicalAddress(address)}`);
}
var NORMALIZED_TREE2 = normalizeStructType(TREE_COIN_TYPE);
var NORMALIZED_PACKAGE = canonicalAddress(TURBOS_PACKAGE);
var NORMALIZED_POSITION_TYPE = canonicalizeMoveType(TURBOS_POSITION_TYPE);
var NORMALIZED_POOL_POSITION_VALUE_TYPE = canonicalizeMoveType(TURBOS_POOL_POSITION_VALUE_TYPE);
function ownerAddress4(node) {
  const owner = record6(node.owner);
  const addressValue = owner.address;
  const rawAddress = typeof addressValue === "string" ? addressValue : record6(addressValue).address;
  return {
    kind: typeof owner.__typename === "string" ? owner.__typename : "Unknown",
    address: normalizeSuiAddress(rawAddress)
  };
}
function optionalUnsigned2(value) {
  if (value === void 0 || value === null) return 0n;
  return parseUnsignedRaw(value);
}
async function defaultScanNfts(grpcHost, maxPages, coverage) {
  const client = new SuiGrpcClient3({
    network: "mainnet",
    transport: new GrpcTransport3({
      host: grpcHost.replace(/^https?:\/\//, ""),
      channelCredentials: ChannelCredentials3.createSsl()
    })
  });
  const positionFieldIds = [];
  let pages = 0;
  let objectsScanned = 0;
  let malformedTypeObjects = 0;
  let malformedObjectIds = 0;
  let duplicateObjectIds = 0;
  for (const poolId of TURBOS_TREE_POOL_IDS) {
    let cursor;
    let reachedPoolEnd = false;
    for (let page = 0; page < maxPages; page += 1) {
      const result = await client.core.listDynamicFields({
        parentId: poolId,
        cursor,
        limit: 1e3
      });
      coverage.requestAttempts += 1;
      pages += 1;
      const fields = Array.isArray(result.dynamicFields) ? result.dynamicFields : [];
      objectsScanned += fields.length;
      for (const field of fields) {
        if (canonicalizeMoveType(field.valueType) !== NORMALIZED_POOL_POSITION_VALUE_TYPE) continue;
        const fieldId = normalizeSuiAddress(field.fieldId);
        if (!fieldId) {
          malformedObjectIds += 1;
          continue;
        }
        positionFieldIds.push(fieldId);
      }
      if (!result.hasNextPage) {
        reachedPoolEnd = true;
        break;
      }
      if (typeof result.cursor !== "string" || !result.cursor) break;
      cursor = result.cursor;
    }
    if (!reachedPoolEnd) {
      return {
        treeNodes: [],
        reachedEnd: false,
        pages,
        objectsScanned,
        malformedTypeObjects,
        malformedObjectIds,
        duplicateObjectIds
      };
    }
  }
  const nftReferences = [];
  const seenReferences = /* @__PURE__ */ new Set();
  for (let index = 0; index < positionFieldIds.length; index += 50) {
    const { objects } = await client.core.getObjects({
      objectIds: positionFieldIds.slice(index, index + 50),
      include: { json: true }
    });
    coverage.requestAttempts += 1;
    for (const object of objects) {
      if (object instanceof Error) throw object;
      const json = record6(object.json);
      const nameValue = record6(json.name).name;
      const name = typeof nameValue === "string" ? nameValue.trim().toLowerCase() : "";
      const match = name.match(/^(?:0x)?([0-9a-f]{1,64})-/);
      if (!match) {
        malformedObjectIds += 1;
        continue;
      }
      const nftId = normalizeSuiAddress(`0x${match[1].padStart(64, "0")}`);
      const value = record6(json.value);
      const poolId = normalizeSuiAddress(value.pool_id ?? value.poolId);
      if (!nftId) {
        malformedObjectIds += 1;
        continue;
      }
      const referenceKey = `${nftId}:${poolId || ""}`;
      if (seenReferences.has(referenceKey)) {
        duplicateObjectIds += 1;
        continue;
      }
      seenReferences.add(referenceKey);
      nftReferences.push({ nftId, poolId: poolId || "" });
    }
  }
  const treeNodes = [];
  const seenLiveNfts = /* @__PURE__ */ new Set();
  for (let index = 0; index < nftReferences.length; index += 50) {
    const batch = nftReferences.slice(index, index + 50);
    const { objects } = await client.core.getObjects({
      objectIds: batch.map((item) => item.nftId),
      include: { json: true }
    });
    coverage.requestAttempts += 1;
    for (let offset = 0; offset < objects.length; offset += 1) {
      const object = objects[offset];
      const reference = batch[offset];
      if (object instanceof Error) {
        if (/not found/i.test(object.message)) continue;
        throw object;
      }
      const nftId = normalizeSuiAddress(object.objectId);
      if (!nftId || nftId !== reference.nftId) {
        malformedObjectIds += 1;
        continue;
      }
      if (seenLiveNfts.has(nftId)) {
        duplicateObjectIds += 1;
        continue;
      }
      seenLiveNfts.add(nftId);
      if (canonicalizeMoveType(object.type) !== canonicalizeMoveType(TURBOS_POSITION_NFT_TYPE)) {
        malformedTypeObjects += 1;
        continue;
      }
      const json = record6(object.json);
      const poolId = normalizeSuiAddress(json.pool_id);
      if (!poolId || !TURBOS_TREE_POOL_IDS.includes(poolId)) {
        malformedTypeObjects += 1;
        continue;
      }
      if (reference.poolId && reference.poolId !== poolId) {
        malformedTypeObjects += 1;
        continue;
      }
      const ownerRecord = record6(object.owner);
      const ownerKind = typeof ownerRecord.$kind === "string" ? ownerRecord.$kind : "Unknown";
      const ownerValue = ownerRecord[ownerKind];
      const ownerAddressValue = typeof ownerValue === "string" ? ownerValue : record6(ownerValue).address;
      treeNodes.push({
        address: nftId,
        owner: {
          __typename: ownerKind,
          address: ownerAddressValue ? { address: ownerAddressValue } : void 0
        },
        asMoveObject: { contents: { json } }
      });
    }
  }
  return {
    treeNodes,
    reachedEnd: true,
    pages,
    objectsScanned,
    malformedTypeObjects,
    malformedObjectIds,
    duplicateObjectIds
  };
}
function defaultObjectGetters(grpcHost) {
  const client = new SuiGrpcClient3({
    network: "mainnet",
    transport: new GrpcTransport3({
      host: grpcHost.replace(/^https?:\/\//, ""),
      channelCredentials: ChannelCredentials3.createSsl()
    })
  });
  const getObject = async (objectId) => {
    const { object } = await client.core.getObject({ objectId, include: { json: true } });
    return object ? { type: object.type, json: object.json } : {};
  };
  return { getPoolObject: getObject, getPositionObject: getObject };
}
function verifyPool3(poolId, value, tokenA, tokenB, feeType) {
  const expectedType = `${NORMALIZED_PACKAGE}::pool::pool<${tokenA},${tokenB},${feeType}>`;
  const json = record6(value.json);
  const id = normalizeSuiAddress(json.id);
  const currentSqrtPrice = parseUnsignedRaw(json.sqrt_price);
  const currentTick = parseSignedI32(json.tick_current_index);
  const reserveA = parseUnsignedRaw(json.coin_a);
  const reserveB = parseUnsignedRaw(json.coin_b);
  const poolLiquidity = parseUnsignedRaw(json.liquidity);
  if (canonicalizeMoveType(value.type) !== expectedType || id !== poolId || currentSqrtPrice === null || currentSqrtPrice <= 0n || currentTick === null || currentTick < CLMM_MIN_TICK || currentTick > CLMM_MAX_TICK || reserveA === null || reserveB === null || poolLiquidity === null) return null;
  const lowerBoundary = tickToSqrtPriceQ64(currentTick);
  const upperBoundary = currentTick < CLMM_MAX_TICK ? tickToSqrtPriceQ64(currentTick + 1) : currentSqrtPrice + 1n;
  if (currentSqrtPrice < lowerBoundary || currentSqrtPrice >= upperBoundary) return null;
  return { poolId, tokenA, tokenB, feeType, currentSqrtPrice, reserveA, reserveB };
}
function verifyPosition(nft, value) {
  if (canonicalizeMoveType(value.type) !== NORMALIZED_POSITION_TYPE) return null;
  const json = record6(value.json);
  const id = normalizeSuiAddress(json.id);
  const liquidity = parseUnsignedRaw(json.liquidity);
  const tickLower = parseSignedI32(json.tick_lower_index);
  const tickUpper = parseSignedI32(json.tick_upper_index);
  const unclaimedTreeRaw = optionalUnsigned2(nft.treeSide === "a" ? json.tokens_owed_a : json.tokens_owed_b);
  if (id !== nft.positionId || liquidity === null || tickLower === null || tickUpper === null || tickLower < CLMM_MIN_TICK || tickUpper > CLMM_MAX_TICK || tickLower >= tickUpper || unclaimedTreeRaw === null) return null;
  return { ...nft, liquidity, tickLower, tickUpper, unclaimedTreeRaw };
}
async function scanTurbosTreeLp(options = {}) {
  const generatedAt = options.generatedAt || (/* @__PURE__ */ new Date()).toISOString();
  const coverage = {
    nftType: TURBOS_POSITION_NFT_TYPE,
    pagesScanned: 0,
    objectsScanned: 0,
    treePositionNfts: 0,
    addressOwnedTreePositions: 0,
    nonAddressOwnedTreePositions: 0,
    uniqueOwners: 0,
    uniquePools: 0,
    verifiedPools: 0,
    verifiedPositions: 0,
    poolIds: [],
    malformedObjects: 0,
    malformedOwners: 0,
    malformedObjectIds: 0,
    duplicateObjectIds: 0,
    duplicatePositionIds: 0,
    excludedObjects: 0,
    excludedPrincipalTreeRaw: "0",
    aggregatePrincipalTreeRaw: "0",
    unclaimedTreeRawExcluded: "0",
    reconciliationFailures: 0,
    reachedEnd: false,
    scanComplete: false,
    requestAttempts: 0,
    retriedRequests: 0,
    rateLimitRetries: 0,
    networkRetries: 0,
    serverErrorRetries: 0,
    rateLimited: false,
    networkError: null,
    graphqlErrors: []
  };
  const warnings = ["Turbos exposure includes current principal liquidity only; unclaimed fees and incentive rewards are excluded."];
  try {
    const pageSize = Math.max(1, Math.min(50, Math.trunc(options.pageSize ?? DEFAULT_PAGE_SIZE3)));
    const maxPages = Math.max(1, Math.min(5e3, Math.trunc(options.maxPages ?? DEFAULT_MAX_PAGES3)));
    const maxRetries = Math.max(0, Math.min(10, Math.trunc(options.maxRetries ?? DEFAULT_MAX_RETRIES)));
    const sleepImpl = options.sleepImpl || ((milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)));
    const scan = await (options.scanNfts || (() => defaultScanNfts(
      options.grpcHost || DEFAULT_GRPC_HOST3,
      maxPages,
      coverage
    )))();
    coverage.pagesScanned = scan.pages;
    coverage.objectsScanned = scan.objectsScanned;
    coverage.reachedEnd = scan.reachedEnd;
    coverage.malformedObjects += scan.malformedTypeObjects;
    coverage.malformedObjectIds += scan.malformedObjectIds;
    coverage.duplicateObjectIds += scan.duplicateObjectIds;
    coverage.treePositionNfts = scan.treeNodes.length;
    const parsedNfts = [];
    const expectedPools = /* @__PURE__ */ new Map();
    const seenPositionIds = /* @__PURE__ */ new Set();
    for (const node of scan.treeNodes) {
      const nftId = normalizeSuiAddress(node.address);
      if (!nftId) {
        coverage.malformedObjectIds += 1;
        continue;
      }
      const owner = ownerAddress4(node);
      if (owner.kind !== "AddressOwner") {
        coverage.nonAddressOwnedTreePositions += 1;
        continue;
      }
      if (!owner.address) {
        coverage.malformedOwners += 1;
        continue;
      }
      coverage.addressOwnedTreePositions += 1;
      const json = record6(record6(record6(node.asMoveObject).contents).json);
      const poolId = normalizeSuiAddress(json.pool_id);
      const positionId = normalizeSuiAddress(json.position_id);
      const tokenA = normalizeStructType(json.coin_type_a);
      const tokenB = normalizeStructType(json.coin_type_b);
      const feeType = normalizeStructType(json.fee_type);
      const treeSide = tokenA === NORMALIZED_TREE2 ? "a" : tokenB === NORMALIZED_TREE2 ? "b" : null;
      if (!poolId || !positionId || !tokenA || !tokenB || !feeType || !treeSide || tokenA === tokenB) {
        coverage.malformedObjects += 1;
        continue;
      }
      if (seenPositionIds.has(positionId)) {
        coverage.duplicatePositionIds += 1;
        continue;
      }
      seenPositionIds.add(positionId);
      const expected = expectedPools.get(poolId);
      if (expected && (expected.tokenA !== tokenA || expected.tokenB !== tokenB || expected.feeType !== feeType)) {
        coverage.malformedObjects += 1;
        continue;
      }
      expectedPools.set(poolId, { tokenA, tokenB, feeType });
      parsedNfts.push({
        nftId,
        wallet: owner.address,
        excluded: Boolean(excludedAddress(owner.address)),
        poolId,
        positionId,
        tokenA,
        tokenB,
        feeType,
        treeSide
      });
    }
    coverage.uniquePools = expectedPools.size;
    coverage.poolIds = [...expectedPools.keys()].sort();
    const defaults = defaultObjectGetters(options.grpcHost || DEFAULT_GRPC_HOST3);
    const getPoolObject = options.getPoolObject || defaults.getPoolObject;
    const getPositionObject = options.getPositionObject || defaults.getPositionObject;
    const verifiedPools = /* @__PURE__ */ new Map();
    for (const [poolId, expected] of expectedPools) {
      const pool = verifyPool3(poolId, await getPoolObject(poolId), expected.tokenA, expected.tokenB, expected.feeType);
      if (!pool) {
        coverage.malformedObjects += 1;
        continue;
      }
      verifiedPools.set(poolId, pool);
    }
    coverage.verifiedPools = verifiedPools.size;
    const verifiedPositions = [];
    for (const nft of parsedNfts) {
      const position = verifyPosition(nft, await getPositionObject(nft.positionId));
      if (!position) {
        coverage.malformedObjects += 1;
        continue;
      }
      verifiedPositions.push(position);
    }
    coverage.verifiedPositions = verifiedPositions.length;
    const walletTotals = /* @__PURE__ */ new Map();
    const poolTotals = /* @__PURE__ */ new Map();
    let aggregatePrincipalTreeRaw = 0n;
    let excludedPrincipalTreeRaw = 0n;
    let unclaimedTreeRawExcluded = 0n;
    for (const position of verifiedPositions) {
      const pool = verifiedPools.get(position.poolId);
      if (!pool) continue;
      const amounts = amountsForLiquidityQ64(
        pool.currentSqrtPrice,
        tickToSqrtPriceQ64(position.tickLower),
        tickToSqrtPriceQ64(position.tickUpper),
        position.liquidity
      );
      const poolTotal = poolTotals.get(position.poolId) || { amountA: 0n, amountB: 0n };
      poolTotal.amountA += amounts.amountX;
      poolTotal.amountB += amounts.amountY;
      poolTotals.set(position.poolId, poolTotal);
      const principalTreeRaw = position.treeSide === "a" ? amounts.amountX : amounts.amountY;
      aggregatePrincipalTreeRaw += principalTreeRaw;
      unclaimedTreeRawExcluded += position.unclaimedTreeRaw;
      if (position.excluded) {
        coverage.excludedObjects += 1;
        excludedPrincipalTreeRaw += principalTreeRaw;
        continue;
      }
      if (principalTreeRaw <= 0n) continue;
      const prior = walletTotals.get(position.wallet) || {
        treeRaw: 0n,
        unclaimedTreeRaw: 0n,
        positionCount: 0,
        poolIds: /* @__PURE__ */ new Set()
      };
      prior.treeRaw += principalTreeRaw;
      prior.unclaimedTreeRaw += position.unclaimedTreeRaw;
      prior.positionCount += 1;
      prior.poolIds.add(position.poolId);
      walletTotals.set(position.wallet, prior);
    }
    for (const [poolId, totals] of poolTotals) {
      const pool = verifiedPools.get(poolId);
      if (!pool || totals.amountA > pool.reserveA || totals.amountB > pool.reserveB) {
        coverage.reconciliationFailures += 1;
      }
    }
    coverage.uniqueOwners = walletTotals.size;
    coverage.aggregatePrincipalTreeRaw = aggregatePrincipalTreeRaw.toString();
    coverage.excludedPrincipalTreeRaw = excludedPrincipalTreeRaw.toString();
    coverage.unclaimedTreeRawExcluded = unclaimedTreeRawExcluded.toString();
    const integrityValid = coverage.malformedObjects === 0 && coverage.malformedOwners === 0 && coverage.malformedObjectIds === 0 && coverage.duplicateObjectIds === 0 && coverage.duplicatePositionIds === 0 && coverage.nonAddressOwnedTreePositions === 0 && coverage.verifiedPools === coverage.uniquePools && coverage.verifiedPositions === parsedNfts.length && coverage.reconciliationFailures === 0 && coverage.graphqlErrors.length === 0 && !coverage.networkError && !coverage.rateLimited;
    coverage.scanComplete = coverage.reachedEnd && integrityValid;
    if (!coverage.reachedEnd) warnings.push("The Turbos position NFT scan did not reach its natural end; partial exposure was not published.");
    if (coverage.nonAddressOwnedTreePositions) warnings.push("One or more Turbos TREE position NFTs were not directly address-owned; owner attribution was incomplete.");
    if (!integrityValid) warnings.push("Turbos TREE position integrity verification failed; partial exposure was not published.");
    const positions = coverage.scanComplete ? [...walletTotals.entries()].sort(([left], [right]) => left.localeCompare(right)).map(([wallet, value]) => ({
      wallet,
      venue: "turbos",
      lpTreeRaw: value.treeRaw.toString(),
      positionCount: value.positionCount,
      metadata: {
        principalOnly: true,
        poolIds: [...value.poolIds].sort(),
        unclaimedTreeRawExcluded: value.unclaimedTreeRaw.toString()
      }
    })) : [];
    return {
      venue: "turbos",
      outcome: coverage.scanComplete ? "complete" : "verification-incomplete",
      provider: TURBOS_PROVIDER,
      methodologyVersion: TURBOS_METHODOLOGY_VERSION,
      generatedAt,
      positions,
      coverage,
      warnings
    };
  } catch (error) {
    coverage.networkError = error instanceof Error ? error.message : "Turbos TREE LP scan failed.";
    warnings.push("The Turbos provider failed; no partial exposure was published.");
    return {
      venue: "turbos",
      outcome: "error",
      provider: TURBOS_PROVIDER,
      methodologyVersion: TURBOS_METHODOLOGY_VERSION,
      generatedAt,
      positions: [],
      coverage,
      warnings
    };
  }
}

// netlify/lib/tree-exposure-aggregator.ts
function buildVerifiedExposureSnapshot(input) {
  const coverage = {
    directTreeComplete: input.directTreeComplete,
    suiDexV2Complete: input.venueResults.suiDexV2.outcome === "complete",
    suiDexV3Complete: input.venueResults.suiDexV3.outcome === "complete",
    turbosComplete: input.venueResults.turbos.outcome === "complete",
    totalExposureComplete: false
  };
  coverage.totalExposureComplete = coverage.directTreeComplete && coverage.suiDexV2Complete && coverage.suiDexV3Complete && coverage.turbosComplete;
  const warnings = [
    ...Object.values(input.venueResults).flatMap((result) => result.warnings || [])
  ];
  if (!coverage.totalExposureComplete) {
    warnings.push("Total verified TREE exposure is incomplete; partial exposure rankings were not published.");
    return {
      outcome: "verification-incomplete",
      generatedAt: input.generatedAt || (/* @__PURE__ */ new Date()).toISOString(),
      methodologyVersion: TREE_EXPOSURE_METHODOLOGY_VERSION,
      entries: [],
      eligibleOwnerCount: null,
      coverage,
      warnings
    };
  }
  const aggregates = /* @__PURE__ */ new Map();
  const ensure = (walletValue) => {
    const wallet = normalizeSuiAddress(walletValue);
    if (!wallet) return null;
    const prior = aggregates.get(wallet);
    if (prior) return prior;
    const created = {
      wallet,
      suinsName: null,
      liquidRaw: 0n,
      coinObjectCount: 0,
      lpRaw: { suiDexV2: 0n, suiDexV3: 0n, turbos: 0n },
      lpPositionCount: 0
    };
    aggregates.set(wallet, created);
    return created;
  };
  for (const entry of input.directEntries) {
    const aggregate = ensure(entry.wallet);
    const raw = parseUnsignedRaw(entry.directTreeRaw);
    if (!aggregate || raw === null) continue;
    aggregate.liquidRaw += raw;
    aggregate.coinObjectCount += Number(entry.coinObjectCount) || 0;
    if (!aggregate.suinsName && typeof entry.suinsName === "string" && entry.suinsName.trim()) aggregate.suinsName = entry.suinsName.trim();
  }
  for (const [venue, result] of Object.entries(input.venueResults)) {
    for (const position of result.positions) {
      const aggregate = ensure(position.wallet);
      const raw = parseUnsignedRaw(position.lpTreeRaw);
      if (!aggregate || raw === null) continue;
      aggregate.lpRaw[venue] += raw;
      aggregate.lpPositionCount += Number(position.positionCount) || 0;
    }
  }
  const limit = Math.max(1, Math.min(500, Math.trunc(input.limit ?? 50)));
  const entries = [...aggregates.values()].map((aggregate) => {
    const lpRaw = aggregate.lpRaw.suiDexV2 + aggregate.lpRaw.suiDexV3 + aggregate.lpRaw.turbos;
    const totalRaw = aggregate.liquidRaw + lpRaw;
    return { aggregate, lpRaw, totalRaw };
  }).filter(({ totalRaw }) => totalRaw > 0n && totalRaw <= TREE_TOTAL_SUPPLY_RAW).sort((left, right) => left.totalRaw > right.totalRaw ? -1 : left.totalRaw < right.totalRaw ? 1 : left.aggregate.liquidRaw > right.aggregate.liquidRaw ? -1 : left.aggregate.liquidRaw < right.aggregate.liquidRaw ? 1 : left.aggregate.wallet.localeCompare(right.aggregate.wallet)).slice(0, limit).map(({ aggregate, lpRaw, totalRaw }, index) => {
    const badges = [];
    if (lpRaw > 0n) badges.push(LP_PROVIDER_BADGE);
    if (lpRaw > aggregate.liquidRaw && lpRaw > 0n) badges.push(LP_MAXI_BADGE);
    return {
      rank: index + 1,
      wallet: aggregate.wallet,
      suinsName: aggregate.suinsName,
      liquidTreeRaw: aggregate.liquidRaw.toString(),
      liquidTree: formatTreeRaw(aggregate.liquidRaw),
      lpTreeRaw: lpRaw.toString(),
      lpTree: formatTreeRaw(lpRaw),
      totalExposureRaw: totalRaw.toString(),
      totalExposure: formatTreeRaw(totalRaw),
      supplyPercent: formatTreeSupplyPercent(totalRaw),
      liquidCoinObjectCount: aggregate.coinObjectCount,
      lpPositionCount: aggregate.lpPositionCount,
      lpBreakdown: {
        suiDexV2Raw: aggregate.lpRaw.suiDexV2.toString(),
        suiDexV2: formatTreeRaw(aggregate.lpRaw.suiDexV2),
        suiDexV3Raw: aggregate.lpRaw.suiDexV3.toString(),
        suiDexV3: formatTreeRaw(aggregate.lpRaw.suiDexV3),
        turbosRaw: aggregate.lpRaw.turbos.toString(),
        turbos: formatTreeRaw(aggregate.lpRaw.turbos)
      },
      badges
    };
  });
  return {
    outcome: "complete",
    generatedAt: input.generatedAt || (/* @__PURE__ */ new Date()).toISOString(),
    methodologyVersion: TREE_EXPOSURE_METHODOLOGY_VERSION,
    entries,
    eligibleOwnerCount: aggregates.size,
    coverage,
    warnings
  };
}

// netlify/lib/tree-exposure-scan-runner.ts
function venueSummary(result) {
  return {
    outcome: "complete",
    walletCount: result.positions.length,
    positionCount: result.positions.reduce((sum, position) => sum + position.positionCount, 0),
    principalTreeRaw: result.positions.reduce((sum, position) => sum + BigInt(position.lpTreeRaw), 0n).toString(),
    coverage: result.coverage,
    warnings: [...result.warnings]
  };
}
function failed(outcome, stage, warnings) {
  return { outcome, stage, snapshot: null, warnings };
}
async function runCompleteTreeExposureScan(dependencies = {}) {
  const getEnv = dependencies.getEnv ?? ((name) => Netlify.env.get(name));
  const directScan = dependencies.directScan ?? scanSuiGraphqlLeaderboard;
  const suiDexV2Scan = dependencies.suiDexV2Scan ?? scanSuiDexV2TreeLp;
  const suiDexV3Scan = dependencies.suiDexV3Scan ?? scanSuiDexV3TreeLp;
  const turbosScan = dependencies.turbosScan ?? scanTurbosTreeLp;
  const resolveSuins = dependencies.resolveSuins ?? resolveDefaultSuinsNames;
  const now = dependencies.now ?? Date.now;
  const venueOutcomes = {
    suiDexV2: "pending",
    suiDexV3: "pending",
    turbos: "pending"
  };
  let directPagesScanned = 0;
  let directObjectsScanned = 0;
  let directUniqueOwners = 0;
  const emit = async (stage, message) => {
    await dependencies.onProgress?.({
      stage,
      message,
      directPagesScanned,
      directObjectsScanned,
      directUniqueOwners,
      venueOutcomes: { ...venueOutcomes }
    });
  };
  try {
    await emit("direct-tree", "Scanning the complete address-owned Coin<TREE> set.");
    const backgroundConfig = readSuiGraphqlBackgroundConfig(getEnv);
    const callerProgress = dependencies.directOptions?.onProgress;
    const direct = await directScan({
      ...backgroundConfig,
      ...dependencies.directOptions,
      includeExposureCandidates: true,
      onProgress: async (progress) => {
        directPagesScanned = progress.pagesScanned;
        directObjectsScanned = progress.objectsScanned;
        directUniqueOwners = progress.uniqueAddressOwners;
        await callerProgress?.(progress);
        await emit("direct-tree", "Scanning the complete address-owned Coin<TREE> set.");
      }
    });
    directPagesScanned = direct.coverage.pagesScanned;
    directObjectsScanned = direct.coverage.objectsScanned;
    directUniqueOwners = direct.coverage.uniqueAddressOwners;
    if (direct.outcome !== "complete" || !direct.exposureCandidates || direct.verifiedAddressOwners === null || direct.eligibleRankedOwners === null) {
      return failed(
        direct.outcome === "error" ? "error" : "verification-incomplete",
        "direct-tree",
        [...direct.warnings, "The total-exposure run stopped because direct TREE verification was incomplete."]
      );
    }
    await emit("suidex-v2", "Scanning SuiDex V2 direct and farm-staked TREE LP.");
    const suiDexV2 = await suiDexV2Scan();
    venueOutcomes.suiDexV2 = suiDexV2.outcome;
    await emit("suidex-v2", `SuiDex V2 scan ${suiDexV2.outcome}.`);
    if (suiDexV2.outcome !== "complete") {
      return failed(
        suiDexV2.outcome === "error" ? "error" : "verification-incomplete",
        "suidex-v2",
        [...suiDexV2.warnings, "The total-exposure run stopped because SuiDex V2 verification was incomplete."]
      );
    }
    await emit("suidex-v3", "Scanning SuiDex V3 TREE concentrated-liquidity positions.");
    const suiDexV3 = await suiDexV3Scan();
    venueOutcomes.suiDexV3 = suiDexV3.outcome;
    await emit("suidex-v3", `SuiDex V3 scan ${suiDexV3.outcome}.`);
    if (suiDexV3.outcome !== "complete") {
      return failed(
        suiDexV3.outcome === "error" ? "error" : "verification-incomplete",
        "suidex-v3",
        [...suiDexV3.warnings, "The total-exposure run stopped because SuiDex V3 verification was incomplete."]
      );
    }
    await emit("turbos", "Scanning the complete Turbos position-NFT set for TREE positions.");
    const turbos = await turbosScan();
    venueOutcomes.turbos = turbos.outcome;
    await emit("turbos", `Turbos scan ${turbos.outcome}.`);
    if (turbos.outcome !== "complete") {
      return failed(
        turbos.outcome === "error" ? "error" : "verification-incomplete",
        "turbos",
        [...turbos.warnings, "The total-exposure run stopped because Turbos verification was incomplete."]
      );
    }
    await emit("aggregate", "Combining Liquid TREE and verified LP principal.");
    const venueResults = { suiDexV2, suiDexV3, turbos };
    const aggregate = buildVerifiedExposureSnapshot({
      directEntries: direct.exposureCandidates,
      directTreeComplete: true,
      venueResults,
      generatedAt: new Date(now()).toISOString(),
      limit: 50
    });
    if (aggregate.outcome !== "complete" || aggregate.entries.length !== 50 || aggregate.eligibleOwnerCount === null) {
      return failed(
        "verification-incomplete",
        "aggregate",
        [...aggregate.warnings, "The complete exposure aggregate did not produce exactly 50 verified entries."]
      );
    }
    await emit("suins", "Resolving verified default SuiNS names for the final Top 50.");
    let suins;
    try {
      suins = await resolveSuins(aggregate.entries.map((entry) => entry.wallet));
    } catch (error) {
      const message = error instanceof Error ? error.message : "SuiNS resolution failed.";
      suins = {
        names: Object.fromEntries(aggregate.entries.map((entry) => [entry.wallet, null])),
        requestedCount: aggregate.entries.length,
        resolvedCount: 0,
        complete: false,
        graphqlErrors: [message],
        networkError: message,
        generatedAt: new Date(now()).toISOString()
      };
    }
    const suinsWarnings = suins.complete ? [] : ["Some verified default SuiNS names could not be resolved; wallet exposure remains complete."];
    const entries = aggregate.entries.map((entry) => ({
      ...entry,
      suinsName: suins.names[entry.wallet] || null
    }));
    const source = {
      direct: {
        outcome: "complete",
        pagesScanned: direct.coverage.pagesScanned,
        objectsScanned: direct.coverage.objectsScanned,
        verifiedAddressOwners: direct.verifiedAddressOwners,
        eligibleDirectOwners: direct.eligibleRankedOwners,
        exposureCandidateCount: direct.exposureCandidates.length,
        addressOwnedRaw: direct.reconciliation.addressOwnedRaw
      },
      venues: {
        suiDexV2: venueSummary(suiDexV2),
        suiDexV3: venueSummary(suiDexV3),
        turbos: venueSummary(turbos)
      },
      suins: {
        requestedCount: suins.requestedCount,
        resolvedCount: suins.resolvedCount,
        complete: suins.complete,
        generatedAt: suins.generatedAt,
        warnings: suinsWarnings
      }
    };
    const top50TotalRaw = entries.reduce((sum, entry) => sum + BigInt(entry.totalExposureRaw), 0n);
    const top50LiquidRaw = entries.reduce((sum, entry) => sum + BigInt(entry.liquidTreeRaw), 0n);
    const top50LpRaw = entries.reduce((sum, entry) => sum + BigInt(entry.lpTreeRaw), 0n);
    const snapshot = {
      ...aggregate,
      outcome: "complete",
      provider: EXPOSURE_SNAPSHOT_PROVIDER,
      coinSymbol: "TREE",
      coinDecimals: TREE_DECIMALS,
      totalSupplyRaw: TREE_TOTAL_SUPPLY_RAW.toString(),
      displayedCount: 50,
      entries,
      warnings: [...aggregate.warnings, ...suinsWarnings],
      source,
      summary: {
        top50TotalRaw: top50TotalRaw.toString(),
        top50LiquidRaw: top50LiquidRaw.toString(),
        top50LpRaw: top50LpRaw.toString(),
        rank50CutoffRaw: entries[49].totalExposureRaw,
        badgeCounts: {
          lpProvider: entries.filter((entry) => entry.badges.includes(LP_PROVIDER_BADGE)).length,
          lpMaxi: entries.filter((entry) => entry.badges.includes(LP_MAXI_BADGE)).length
        }
      }
    };
    if (!validateCompleteExposureSnapshot(snapshot)) {
      return failed("verification-incomplete", "aggregate", [
        ...snapshot.warnings,
        "The complete exposure snapshot failed final cache-integrity validation."
      ]);
    }
    await emit("complete", "A complete verified TREE exposure snapshot is ready.");
    return { outcome: "complete", stage: "complete", snapshot, warnings: snapshot.warnings };
  } catch (error) {
    const message = error instanceof Error ? error.message : "TREE exposure scan failed.";
    await emit("failed", "The TREE exposure scan failed without publishing partial rankings.");
    return failed("error", "failed", [message, "No partial exposure ranking was published."]);
  }
}

// netlify/lib/tree-exposure-background-worker.ts
function productionEnabled(getEnv) {
  return (getEnv("TREE_EXPOSURE_PRODUCTION_ENABLED") || "").trim().toLowerCase() === "true";
}
function cacheStage(stage) {
  return stage === "failed" ? "failed" : stage;
}
function statusFromProgress(base, progress, updatedAt) {
  return {
    ...base,
    state: progress.stage === "complete" ? "running" : "running",
    stage: cacheStage(progress.stage),
    updatedAt,
    directPagesScanned: progress.directPagesScanned,
    directObjectsScanned: progress.directObjectsScanned,
    directUniqueOwners: progress.directUniqueOwners,
    venueOutcomes: { ...progress.venueOutcomes },
    message: progress.message
  };
}
async function runExposureBackgroundWorker(request, dependencies = {}) {
  if (request.method !== "POST") return { accepted: false, started: false, outcome: "method-not-allowed" };
  const getEnv = dependencies.getEnv ?? ((name) => Netlify.env.get(name));
  const deployContext = dependencies.deployContext || "dev";
  if (deployContext === "production" && !productionEnabled(getEnv)) {
    return { accepted: false, started: false, outcome: "production-disabled" };
  }
  const configuredSecret = getEnv("TREE_EXPOSURE_REFRESH_SECRET") || getEnv("TREE_LEADERBOARD_REFRESH_SECRET") || "";
  const requestSecret = request.headers.get("x-tree-exposure-refresh-secret") || request.headers.get("x-tree-refresh-secret") || "";
  if (!configuredSecret || !requestSecret || !timingSafeSecretEqual(configuredSecret, requestSecret)) {
    return { accepted: false, started: false, outcome: "authentication-failed" };
  }
  const now = dependencies.now ?? Date.now;
  const createRunId = dependencies.createRunId ?? randomUUID2;
  const runScan = dependencies.runScan ?? runCompleteTreeExposureScan;
  const logger = dependencies.logger ?? console;
  const storeOptions = { context: deployContext, store: dependencies.store };
  const commitRef = getEnv("COMMIT_REF") || null;
  const deployId = dependencies.deployId || getEnv("DEPLOY_ID") || null;
  const currentLock = await readExposureRefreshLock(storeOptions);
  if (currentLock && Date.parse(currentLock.expiresAt) > now()) {
    logger.info("TREE exposure refresh is already active.");
    return { accepted: true, started: false, outcome: "already-active" };
  }
  const runId = createRunId();
  const startedMs = now();
  const startedAt = new Date(startedMs).toISOString();
  await writeExposureRefreshLock({
    runId,
    startedAt,
    expiresAt: new Date(startedMs + EXPOSURE_REFRESH_LOCK_TTL_MS).toISOString(),
    commitRef,
    deployId
  }, storeOptions);
  let status = {
    state: "queued",
    stage: "queued",
    runId,
    startedAt,
    updatedAt: startedAt,
    completedAt: null,
    directPagesScanned: 0,
    directObjectsScanned: 0,
    directUniqueOwners: 0,
    venueOutcomes: {
      suiDexV2: "pending",
      suiDexV3: "pending",
      turbos: "pending"
    },
    totalExposureComplete: false,
    displayedCount: 0,
    message: "TREE exposure refresh queued.",
    commitRef,
    deployId
  };
  try {
    await writeExposureRefreshStatus(status, storeOptions);
    status = {
      ...status,
      state: "running",
      stage: "direct-tree",
      updatedAt: new Date(now()).toISOString(),
      message: "Building a complete verified Liquid TREE plus LP snapshot."
    };
    await writeExposureRefreshStatus(status, storeOptions);
    const result = await runScan({
      ...dependencies.scanDependencies,
      getEnv,
      now,
      onProgress: async (progress) => {
        status = statusFromProgress(status, progress, new Date(now()).toISOString());
        await writeExposureRefreshStatus(status, storeOptions);
      }
    });
    const completedAt = new Date(now()).toISOString();
    let effectiveOutcome = result.outcome;
    let snapshotWritten = false;
    if (result.outcome === "complete" && result.snapshot) {
      snapshotWritten = await writeCompleteExposureSnapshot(result.snapshot, storeOptions);
      if (!snapshotWritten) effectiveOutcome = "verification-incomplete";
    }
    status = {
      ...status,
      state: effectiveOutcome === "complete" ? "complete" : effectiveOutcome === "error" ? "error" : "verification-incomplete",
      stage: effectiveOutcome === "complete" ? "complete" : "failed",
      updatedAt: completedAt,
      completedAt,
      totalExposureComplete: effectiveOutcome === "complete" && snapshotWritten,
      displayedCount: effectiveOutcome === "complete" && result.snapshot ? result.snapshot.entries.length : 0,
      message: effectiveOutcome === "complete" ? "Complete verified TREE exposure snapshot stored." : result.outcome === "complete" ? "The completed scan failed final cache validation; the prior snapshot was preserved." : "The exposure refresh did not produce a complete snapshot; the prior snapshot was preserved."
    };
    await writeExposureRefreshStatus(status, storeOptions);
    logger.info(`TREE exposure refresh finished with outcome ${effectiveOutcome}.`);
    return { accepted: true, started: true, outcome: effectiveOutcome };
  } catch (error) {
    const completedAt = new Date(now()).toISOString();
    status = {
      ...status,
      state: "error",
      stage: "failed",
      updatedAt: completedAt,
      completedAt,
      totalExposureComplete: false,
      displayedCount: 0,
      message: "TREE exposure refresh failed; the prior complete snapshot was preserved."
    };
    await writeExposureRefreshStatus(status, storeOptions);
    logger.error(error instanceof Error ? error.message : "TREE exposure refresh failed.");
    return { accepted: true, started: true, outcome: "error" };
  } finally {
    await clearExposureRefreshLock(runId, storeOptions);
  }
}

// netlify/functions/tree-exposure-refresh-background.ts
async function handleTreeExposureBackgroundRequest(request, context, runWorker = runExposureBackgroundWorker) {
  await runWorker(request, {
    deployContext: context?.deploy?.context || "dev",
    deployId: context?.deploy?.id
  });
}
var tree_exposure_refresh_background_default = async (request, context) => {
  await handleTreeExposureBackgroundRequest(request, context);
};
export {
  tree_exposure_refresh_background_default as default,
  handleTreeExposureBackgroundRequest
};
