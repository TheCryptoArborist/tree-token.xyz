
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-dashboard-normalizer.ts
function emptyLive() {
  return {
    price: null,
    priceChange1h: null,
    priceChange24h: null,
    priceChange7d: null,
    volume24h: null,
    liquidity: null,
    marketCap: null,
    fdv: null,
    holderCount: null,
    sourceUpdatedAt: null
  };
}
function record(value) {
  return value && typeof value === "object" ? value : {};
}
function numberFrom(...values) {
  for (const value of values) {
    const parsed = typeof value === "string" ? Number(value.replace(/,/g, "")) : Number(value);
    if (value !== null && value !== void 0 && value !== "" && Number.isFinite(parsed)) return parsed;
  }
  return null;
}

// netlify/lib/coingecko-market.ts
var TREE_COINGECKO_ID = "thickquidity";
function coinGeckoRequestConfig(config2 = {}) {
  const apiKey = (config2.apiKey || "").trim();
  const pro = (config2.plan || "").trim().toLowerCase() === "pro";
  const headers = { Accept: "application/json" };
  if (apiKey) headers[pro ? "x-cg-pro-api-key" : "x-cg-demo-api-key"] = apiKey;
  return {
    baseUrl: pro ? "https://pro-api.coingecko.com/api/v3" : "https://api.coingecko.com/api/v3",
    headers
  };
}
function normalizeCoinGeckoSimplePrice(payload) {
  const tree = record(record(payload)[TREE_COINGECKO_ID]);
  const updated = numberFrom(tree.last_updated_at);
  return {
    ...emptyLive(),
    price: numberFrom(tree.usd),
    priceChange24h: numberFrom(tree.usd_24h_change),
    volume24h: numberFrom(tree.usd_24h_vol),
    marketCap: numberFrom(tree.usd_market_cap),
    fdv: null,
    sourceUpdatedAt: updated ? new Date(updated * 1e3).toISOString() : null
  };
}
async function fetchCoinGeckoTreeMarket(config2 = {}) {
  const requestConfig = coinGeckoRequestConfig(config2);
  const url = new URL(`${requestConfig.baseUrl}/simple/price`);
  url.searchParams.set("ids", TREE_COINGECKO_ID);
  url.searchParams.set("vs_currencies", "usd");
  url.searchParams.set("include_market_cap", "true");
  url.searchParams.set("include_24hr_vol", "true");
  url.searchParams.set("include_24hr_change", "true");
  url.searchParams.set("include_last_updated_at", "true");
  url.searchParams.set("precision", "full");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8e3);
  try {
    const response = await fetch(url, { headers: requestConfig.headers, signal: controller.signal });
    if (!response.ok) throw new Error(`CoinGecko returned ${response.status}`);
    const data = normalizeCoinGeckoSimplePrice(await response.json());
    if (data.price === null || data.marketCap === null) throw new Error("CoinGecko returned incomplete TREE market data.");
    return data;
  } finally {
    clearTimeout(timeout);
  }
}

// netlify/functions/tree-market.ts
var tree_market_default = async (request) => {
  if (request.method !== "GET") {
    return Response.json({ error: "method-not-allowed" }, { status: 405, headers: { Allow: "GET", "Cache-Control": "no-store" } });
  }
  try {
    const market = await fetchCoinGeckoTreeMarket({
      apiKey: Netlify.env.get("COINGECKO_API_KEY") || "",
      plan: Netlify.env.get("COINGECKO_API_PLAN") || "demo"
    });
    return Response.json({ source: "CoinGecko", data: {
      coin: { market_cap: market.marketCap, fdv: market.fdv, volume_24h: market.volume24h },
      price_change: { price: market.price, price_change_1d: market.priceChange24h },
      updated_at: market.sourceUpdatedAt
    } }, { headers: { "Cache-Control": "public, max-age=30, s-maxage=60, stale-while-revalidate=300" } });
  } catch (error) {
    console.error("CoinGecko TREE market proxy failed", error);
    return Response.json({ error: "Market data unavailable" }, { status: 502, headers: { "Cache-Control": "no-store" } });
  }
};
var config = { path: "/api/tree-market" };
export {
  config,
  tree_market_default as default
};
