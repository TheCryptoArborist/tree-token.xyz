
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/tree-limit-orders.ts
import { Aftermath } from "aftermath-ts-sdk";

// netlify/lib/tree-limit-orders.ts
var TREE_LIMIT_SUI_TYPE = "0x2::sui::SUI";
var TREE_LIMIT_TREE_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_LIMIT_AFTERMATH_PACKAGE = "0xe57ee3613b7dece546f8a2d8a53145cbab41d32b86037b94f9ebfcbcfa66885a";
var TREE_LIMIT_MIN_EXPIRY_MS = 36e5;
var TREE_LIMIT_MAX_EXPIRY_MS = 2592e6;
function record(value) {
  return value && typeof value === "object" ? value : {};
}
function normalizeSuiAddress(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/^0x/, "");
  return /^[0-9a-f]{1,64}$/.test(compact) ? `0x${compact.padStart(64, "0")}` : null;
}
function normalizeCoinType(value) {
  if (typeof value !== "string") return null;
  const parts = value.trim().split("::");
  const address = normalizeSuiAddress(parts[0]);
  return parts.length === 3 && address && parts[1] && parts[2] ? `${address}::${parts[1].toLowerCase()}::${parts[2].toLowerCase()}` : null;
}
function decimalText(value) {
  const text = String(value ?? "").trim();
  if (!/^\d+(?:\.\d{1,18})?$/.test(text)) throw new Error("Enter a valid target price without exponent notation.");
  const numeric = Number(text);
  if (!Number.isFinite(numeric) || numeric < 1e-12 || numeric > 1e6) throw new Error("Target price is outside the supported range.");
  return { text, numeric };
}
function validateTreeLimitCreate(value) {
  const input = record(value);
  const walletAddress = normalizeSuiAddress(input.walletAddress);
  if (!walletAddress) throw new Error("A valid Sui wallet address is required.");
  const direction = input.direction;
  if (direction !== "buy-tree" && direction !== "sell-tree") throw new Error("Limit direction must buy or sell TREE.");
  if (typeof input.allocateCoinAmount !== "string" || !/^\d+$/.test(input.allocateCoinAmount)) throw new Error("Allocated amount must be an integer string.");
  const allocateCoinAmount = BigInt(input.allocateCoinAmount);
  if (allocateCoinAmount <= 0n || allocateCoinAmount > 1000000000000000n) throw new Error("Allocated amount is outside the supported range.");
  const expiryDurationMs = Number(input.expiryDurationMs);
  if (!Number.isSafeInteger(expiryDurationMs) || expiryDurationMs % TREE_LIMIT_MIN_EXPIRY_MS !== 0 || expiryDurationMs < TREE_LIMIT_MIN_EXPIRY_MS || expiryDurationMs > TREE_LIMIT_MAX_EXPIRY_MS) {
    throw new Error("Expiration must be a whole number of hours between 1 hour and 30 days.");
  }
  const price = decimalText(input.targetPriceSuiPerTree);
  const allocateCoinType = direction === "buy-tree" ? TREE_LIMIT_SUI_TYPE : TREE_LIMIT_TREE_TYPE;
  const buyCoinType = direction === "buy-tree" ? TREE_LIMIT_TREE_TYPE : TREE_LIMIT_SUI_TYPE;
  const outputToInputExchangeRate = direction === "buy-tree" ? price.numeric : 1 / price.numeric;
  if (!Number.isFinite(outputToInputExchangeRate) || outputToInputExchangeRate <= 0) throw new Error("Target exchange rate is invalid.");
  return {
    walletAddress,
    direction,
    allocateCoinType,
    buyCoinType,
    allocateCoinAmount,
    targetPriceSuiPerTree: price.text,
    outputToInputExchangeRate,
    expiryDurationMs
  };
}
function assertAllowedTreeLimitTransaction(transaction, expected) {
  const data = record(transaction.getData());
  const commands = Array.isArray(data.commands) ? data.commands.map(record) : [];
  if (commands.length !== 3) throw new Error("Unexpected limit-order command count.");
  for (const command of commands.slice(0, 2)) {
    const split = record(command.SplitCoins);
    const coin = record(split.coin);
    if (command.$kind !== "SplitCoins" || coin.$kind !== "GasCoin" || !Array.isArray(split.amounts) || split.amounts.length !== 1) {
      throw new Error("Unexpected limit-order gas allocation command.");
    }
  }
  const moveCommand = commands[2];
  const move = record(moveCommand.MoveCall);
  const types = Array.isArray(move.typeArguments) ? move.typeArguments.map(normalizeCoinType) : [];
  if (moveCommand.$kind !== "MoveCall" || normalizeSuiAddress(move.package) !== normalizeSuiAddress(TREE_LIMIT_AFTERMATH_PACKAGE) || move.module !== "order" || move.function !== "create_order_with_integrator_fee" || types.length !== 2 || types[0] !== normalizeCoinType(expected.allocateCoinType) || types[1] !== normalizeCoinType(expected.buyCoinType)) {
    throw new Error("Limit-order Move call is not allowlisted.");
  }
  return true;
}
function validateTreeLimitProof(value) {
  const input = record(value);
  const walletAddress = normalizeSuiAddress(input.walletAddress);
  const bytes = typeof input.bytes === "string" && /^[A-Za-z0-9+/_=-]{1,2048}$/.test(input.bytes) ? input.bytes : null;
  const signature = typeof input.signature === "string" && /^[A-Za-z0-9+/_=-]{1,2048}$/.test(input.signature) ? input.signature : null;
  if (!walletAddress || !bytes || !signature) throw new Error("Valid wallet authorization is required.");
  return { walletAddress, bytes, signature };
}
function treeLimitProofMessage(bytes) {
  try {
    const decoded = Uint8Array.from(atob(bytes), (character) => character.charCodeAt(0));
    return record(JSON.parse(new TextDecoder().decode(decoded)));
  } catch {
    throw new Error("Wallet authorization message is invalid.");
  }
}
function assertTreeLimitAccountProof(bytes) {
  const message = treeLimitProofMessage(bytes);
  if (message.action !== "CREATE_USER_ACCOUNT" || Object.keys(message).length !== 1) throw new Error("Wallet authorization action is invalid.");
  return true;
}
function assertTreeLimitCancelProof(bytes, expectedOrderId) {
  const message = treeLimitProofMessage(bytes);
  const ids = Array.isArray(message.order_object_ids) ? message.order_object_ids.map(validateTreeLimitOrderId) : [];
  if (message.action !== "CANCEL_LIMIT_ORDERS" || ids.length !== 1 || ids[0] !== expectedOrderId) throw new Error("Cancellation authorization does not match this order.");
  return true;
}
function validateTreeLimitOrderId(value) {
  const orderId = normalizeSuiAddress(value);
  if (!orderId) throw new Error("A valid limit-order object ID is required.");
  return orderId;
}
function isTreeLimitOrder(value) {
  const order = record(value);
  const allocated = normalizeCoinType(record(order.allocatedCoin).coin);
  const bought = normalizeCoinType(record(order.buyCoin).coin);
  const sui = normalizeCoinType(TREE_LIMIT_SUI_TYPE);
  const tree = normalizeCoinType(TREE_LIMIT_TREE_TYPE);
  return allocated === sui && bought === tree || allocated === tree && bought === sui;
}
function jsonSafeTreeLimitOrder(value) {
  if (!isTreeLimitOrder(value)) return null;
  return JSON.parse(JSON.stringify(value, (_key, item) => typeof item === "bigint" ? item.toString() : item));
}

// netlify/functions/tree-limit-orders.ts
var MAX_BODY_BYTES = 8192;
var PREVIEW_HOST = /^deploy-preview-\d+--tree-token\.netlify\.app$/;
var sdkPromise = null;
function json(body2, status = 200) {
  return Response.json(body2, {
    status,
    headers: {
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
      "X-Robots-Tag": "noindex"
    }
  });
}
function allowedOrigin(request) {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  try {
    const url = new URL(origin);
    return url.protocol === "https:" && (url.hostname === "tree-token.xyz" || url.hostname === "www.tree-token.xyz" || PREVIEW_HOST.test(url.hostname)) || url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  } catch {
    return false;
  }
}
async function sdk() {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    sdkPromise ||= Aftermath.create({ network: "MAINNET" });
    try {
      return await sdkPromise;
    } catch (error) {
      sdkPromise = null;
      if (attempt === 1) throw error;
    }
  }
  throw new Error("Aftermath Mainnet initialization failed.");
}
async function retrySafeAftermath(operation) {
  let lastError;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      return await operation(await sdk());
    } catch (error) {
      lastError = error;
      sdkPromise = null;
    }
  }
  throw lastError;
}
async function body(request) {
  const length = Number(request.headers.get("content-length") || "0");
  if (length > MAX_BODY_BYTES) throw new Error("Request body is too large.");
  const text = await request.text();
  if (!text || text.length > MAX_BODY_BYTES) throw new Error("Request body is invalid.");
  return record(JSON.parse(text));
}
function orders(values, walletAddress) {
  return (Array.isArray(values) ? values : []).filter((order) => isTreeLimitOrder(order) && normalizeSuiAddress(record(order).recipient) === walletAddress).map(jsonSafeTreeLimitOrder).filter(Boolean);
}
var tree_limit_orders_default = async (request) => {
  if (!allowedOrigin(request)) return json({ status: "error", error: "origin-not-allowed" }, 403);
  const url = new URL(request.url);
  const action = url.searchParams.get("action") || "";
  try {
    if (request.method === "GET" && action === "config") {
      const minOrderSizeUsd = await retrySafeAftermath((aftermath) => aftermath.LimitOrders().getMinOrderSizeUsd());
      return json({ status: "ok", provider: "Aftermath Mainnet", minOrderSizeUsd });
    }
    if (request.method === "GET" && action === "past") {
      const walletAddress = normalizeSuiAddress(url.searchParams.get("owner"));
      if (!walletAddress) return json({ status: "error", error: "invalid-owner" }, 400);
      const values = await retrySafeAftermath((aftermath) => aftermath.LimitOrders().getPastLimitOrders({ walletAddress }));
      return json({ status: "ok", orders: orders(values, walletAddress) });
    }
    if (request.method !== "POST") return json({ status: "error", error: "method-not-allowed" }, 405);
    const input = await body(request);
    if (action === "user-key") {
      const walletAddress = normalizeSuiAddress(input.walletAddress);
      if (!walletAddress) return json({ status: "error", error: "invalid-owner" }, 400);
      const publicKey = await retrySafeAftermath((aftermath) => aftermath.UserData().getUserPublicKey({ walletAddress }));
      return json({ status: "ok", registered: Boolean(publicKey) });
    }
    if (action === "register-user") {
      const proof = validateTreeLimitProof(input);
      assertTreeLimitAccountProof(proof.bytes);
      const aftermath = await sdk();
      const registered = await aftermath.UserData().createUserPublicKey(proof);
      return json({ status: registered ? "ok" : "error", registered: Boolean(registered) }, registered ? 200 : 502);
    }
    if (action === "create") {
      const validated = validateTreeLimitCreate(input);
      const transaction = await retrySafeAftermath((aftermath) => aftermath.LimitOrders().getCreateLimitOrderTx({
        walletAddress: validated.walletAddress,
        allocateCoinType: validated.allocateCoinType,
        allocateCoinAmount: validated.allocateCoinAmount,
        buyCoinType: validated.buyCoinType,
        expiryDurationMs: validated.expiryDurationMs,
        outputToInputExchangeRate: validated.outputToInputExchangeRate,
        outputToInputStopLossExchangeRate: 0,
        isSponsoredTx: false
      }));
      assertAllowedTreeLimitTransaction(transaction, validated);
      return json({
        status: "ok",
        transaction: transaction.serialize(),
        order: {
          walletAddress: validated.walletAddress,
          direction: validated.direction,
          allocateCoinType: validated.allocateCoinType,
          buyCoinType: validated.buyCoinType,
          allocateCoinAmount: validated.allocateCoinAmount.toString(),
          targetPriceSuiPerTree: validated.targetPriceSuiPerTree,
          expiryDurationMs: validated.expiryDurationMs
        }
      });
    }
    if (action === "active") {
      const proof = validateTreeLimitProof(input);
      assertTreeLimitAccountProof(proof.bytes);
      const values = await retrySafeAftermath((aftermath) => aftermath.LimitOrders().getActiveLimitOrders(proof));
      return json({ status: "ok", orders: orders(values, proof.walletAddress) });
    }
    if (action === "cancel") {
      const proof = validateTreeLimitProof(input);
      const orderId = validateTreeLimitOrderId(input.orderId);
      assertTreeLimitCancelProof(proof.bytes, orderId);
      const aftermath = await sdk();
      const canceled = await aftermath.LimitOrders().cancelLimitOrder(proof);
      return json({ status: canceled ? "ok" : "error", canceled: Boolean(canceled) }, canceled ? 200 : 502);
    }
    return json({ status: "error", error: "unknown-action" }, 400);
  } catch (error) {
    console.error("TREE limit-order request failed", error);
    const message = error instanceof Error && /^(A valid|Allocated|Choose|Enter|Limit|Target|Unexpected)/.test(error.message) ? error.message : "The TREE limit-order service could not complete this request.";
    const retryable = ["config", "past", "user-key", "create", "active"].includes(action);
    return json({ status: "error", error: "limit-order-unavailable", stage: action || "service", retryable, message }, 502);
  }
};
var config = { path: "/api/tree-limit-orders" };
export {
  config,
  tree_limit_orders_default as default
};
