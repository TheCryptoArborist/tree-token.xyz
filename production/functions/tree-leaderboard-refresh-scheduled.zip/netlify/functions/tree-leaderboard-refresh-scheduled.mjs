
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/leaderboard-scheduled-trigger.ts
var BACKGROUND_FUNCTION_PATH = "/.netlify/functions/tree-leaderboard-refresh-background";
var REQUEST_TIMEOUT_MS = 2e4;
async function runLeaderboardScheduledTrigger(context, dependencies = {}) {
  const logger = dependencies.logger ?? console;
  if (context?.deploy?.context !== "production") {
    logger.info("TREE leaderboard scheduled refresh skipped outside production.");
    return { attempted: false, accepted: false, reason: "not-production" };
  }
  const getEnv = dependencies.getEnv ?? ((name) => Netlify.env.get(name));
  const secret = getEnv("TREE_LEADERBOARD_REFRESH_SECRET") || "";
  if (!secret) {
    logger.error("TREE leaderboard scheduled refresh is not configured.");
    return { attempted: false, accepted: false, reason: "missing-secret" };
  }
  const siteUrl = context?.site?.url || getEnv("URL") || "https://tree-token.xyz";
  let endpoint;
  try {
    endpoint = new URL(BACKGROUND_FUNCTION_PATH, siteUrl);
  } catch {
    logger.error("TREE leaderboard scheduled refresh could not start.");
    return { attempted: false, accepted: false, reason: "network-error" };
  }
  const fetchImpl = dependencies.fetchImpl ?? fetch;
  const setTimeoutImpl = dependencies.setTimeoutImpl ?? setTimeout;
  const clearTimeoutImpl = dependencies.clearTimeoutImpl ?? clearTimeout;
  const controller = new AbortController();
  const timeout = setTimeoutImpl(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetchImpl(endpoint, {
      method: "POST",
      headers: { "x-tree-refresh-secret": secret },
      signal: controller.signal
    });
    if (response.status !== 202) {
      logger.error("TREE leaderboard scheduled refresh was not accepted.");
      return { attempted: true, accepted: false, reason: "unexpected-status" };
    }
    logger.info("TREE leaderboard scheduled refresh was accepted.");
    return { attempted: true, accepted: true, reason: "accepted" };
  } catch (error) {
    if (controller.signal.aborted || error instanceof Error && error.name === "AbortError") {
      logger.error("TREE leaderboard scheduled refresh timed out.");
      return { attempted: true, accepted: false, reason: "timeout" };
    }
    logger.error("TREE leaderboard scheduled refresh request failed.");
    return { attempted: true, accepted: false, reason: "network-error" };
  } finally {
    clearTimeoutImpl(timeout);
  }
}

// netlify/functions/tree-leaderboard-refresh-scheduled.ts
var tree_leaderboard_refresh_scheduled_default = async (_request, context) => {
  await runLeaderboardScheduledTrigger(context);
};
var config = {
  schedule: "17 */6 * * *"
};
export {
  config,
  tree_leaderboard_refresh_scheduled_default as default
};
