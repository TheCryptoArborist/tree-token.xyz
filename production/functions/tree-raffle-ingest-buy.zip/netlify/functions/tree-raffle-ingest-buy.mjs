
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-raffle-ingest.ts
import { createHash, timingSafeEqual } from "node:crypto";

// netlify/lib/tree-raffle-core.ts
var TREE_RAFFLE_RULES_VERSION = "canopy-draw-proposal-v2";
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_RAFFLE_WBTC_TYPE = "0xaafb102dd0902f5055cadecd687fb5b71ca82ef0e0285d90afde828ec58ca96b::btc::BTC";
var TREE_RAFFLE_DAILY_PRIZE = Object.freeze({
  symbol: "TREE",
  coinType: TREE_COIN_TYPE,
  amountRaw: "50000000000",
  decimals: 6
});
var TREE_RAFFLE_DAILY_LUCKY_LEAF_PLAN = Object.freeze({
  symbol: "wBTC",
  coinType: TREE_RAFFLE_WBTC_TYPE,
  decimals: 8,
  mondayThroughSaturdayUsdCents: 250,
  sundayUsdCents: 1e3,
  weeklyBudgetUsdCents: 2500
});
var TREE_RAFFLE_STREAK_MULTIPLIERS_BASIS_POINTS = Object.freeze([
  1e4,
  11e3,
  12500,
  14e3,
  15e3,
  16e3,
  17500,
  18500,
  19500,
  2e4,
  21e3,
  22e3,
  23e3,
  24e3,
  25e3
]);
var TREE_RAFFLE_RULES = Object.freeze({
  version: TREE_RAFFLE_RULES_VERSION,
  status: "development",
  acceptingEntries: false,
  claimsEnabled: false,
  prizesFunded: false,
  dailyEnabled: true,
  dailyLuckyLeafEnabled: false,
  weeklyEnabled: false,
  minimumQualifyingUsdCents: 500,
  ticketExponent: 0.9457,
  ticketCoefficient: 0.288368,
  luckyLeafTicketsPerQualifyingTransaction: 1,
  maxStreakDays: 15,
  maxStreakMultiplierBasisPoints: 25e3,
  streakMultipliersBasisPoints: TREE_RAFFLE_STREAK_MULTIPLIERS_BASIS_POINTS,
  milestoneBonusUsdCents: Object.freeze({ 7: 5e3, 15: 2e4 }),
  schedule: Object.freeze({
    timezone: "America/New_York",
    daily: "10:00",
    weekly: "Sunday 10:05"
  }),
  prizes: Object.freeze({
    dailyMain: TREE_RAFFLE_DAILY_PRIZE,
    dailyLuckyLeafPlan: TREE_RAFFLE_DAILY_LUCKY_LEAF_PLAN,
    weeklyMain: null,
    weeklyLuckyLeaf: null
  }),
  eligibleTransaction: Object.freeze({
    network: "sui-mainnet",
    direction: "SUI_TO_TREE",
    requiresSuccessfulFinalizedTransaction: true,
    allowlistedRoutesRequired: true
  })
});
function parseBooleanEnv(value, fallback = false) {
  if (value === void 0 || value === null) return fallback;
  const normalized = String(value).trim().toLowerCase();
  return normalized === "1" || normalized === "true" || normalized === "yes" || normalized === "on";
}
function treeRaffleRulesForEnvironment(env = process.env) {
  return {
    ...TREE_RAFFLE_RULES,
    acceptingEntries: parseBooleanEnv(env.TREE_RAFFLE_ACCEPTING_ENTRIES, TREE_RAFFLE_RULES.acceptingEntries),
    claimsEnabled: parseBooleanEnv(env.TREE_RAFFLE_CLAIMS_ENABLED, TREE_RAFFLE_RULES.claimsEnabled),
    prizesFunded: parseBooleanEnv(env.TREE_RAFFLE_PRIZES_FUNDED, TREE_RAFFLE_RULES.prizesFunded),
    dailyEnabled: parseBooleanEnv(env.TREE_RAFFLE_DAILY_ENABLED, TREE_RAFFLE_RULES.dailyEnabled),
    dailyLuckyLeafEnabled: parseBooleanEnv(
      env.TREE_RAFFLE_DAILY_LUCKY_ENABLED,
      TREE_RAFFLE_RULES.dailyLuckyLeafEnabled
    ),
    weeklyEnabled: parseBooleanEnv(env.TREE_RAFFLE_WEEKLY_ENABLED, TREE_RAFFLE_RULES.weeklyEnabled)
  };
}
function raffleLaunchBlockers(rules = TREE_RAFFLE_RULES) {
  const blockers = [
    !rules.prizesFunded && "The prize pool must be funded and prizes reserved before rounds open.",
    !rules.claimsEnabled && "The prize claim path is disabled.",
    !rules.acceptingEntries && "Entry recording is disabled."
  ];
  return blockers.filter((value) => Boolean(value));
}
function raffleOperationalReadiness(env = process.env, rules = treeRaffleRulesForEnvironment(env)) {
  const transactionalLedgerConfigured = Boolean(
    (env.TREE_RAFFLE_SUPABASE_URL || "").trim() && (env.TREE_RAFFLE_SUPABASE_SECRET_KEY || "").trim()
  );
  const onchainPrizePoolConfigured = Boolean(
    (env.TREE_RAFFLE_PACKAGE_ID || "").trim() && (env.TREE_RAFFLE_PRIZE_POOL_ID || "").trim() && (env.TREE_RAFFLE_OPERATOR_CAP_ID || "").trim()
  );
  const drawExecutorConfigured = env.TREE_RAFFLE_DRAW_EXECUTOR_READY === "true" && onchainPrizePoolConfigured;
  const verifiedBuyIngestionEnabled = Boolean(
    env.TREE_RAFFLE_INGEST_ENABLED === "true" && (rules.dailyEnabled || rules.weeklyEnabled) && rules.acceptingEntries && rules.claimsEnabled && rules.prizesFunded && transactionalLedgerConfigured && drawExecutorConfigured
  );
  const infrastructureBlockers = [
    !transactionalLedgerConfigured && "The transactional raffle ledger is not connected.",
    !onchainPrizePoolConfigured && "The on-chain prize pool is not published and configured.",
    !drawExecutorConfigured && "The verifiable draw executor is not ready."
  ].filter((value) => Boolean(value));
  return {
    transactionalLedgerConfigured,
    onchainPrizePoolConfigured,
    drawExecutorConfigured,
    verifiedBuyIngestionEnabled,
    launchBlockers: [...raffleLaunchBlockers(rules), ...infrastructureBlockers]
  };
}

// netlify/lib/cetus-tree-constants.ts
var CETUS_TREE_POOL_ID = "0x2ebaff75b8745896404085babb9ef3a77ccbb6c7d3f4db31626cefff04f7f355";
var CETUS_CLMM_PACKAGE = "0x1eabed72c53feb3805120a081dc15963c204dc8d091542592abaf7a35689b2fb";
var CETUS_INTEGRATE_PACKAGE = "0xae9c208cf58fd5ba36737c9ee5dcfa7f152d0fb5a5a99eebb7c881ebc2fe59e0";
var CETUS_TREE_POOL_URL = `https://app.cetus.zone/clmm?tab=deposit&poolAddress=${CETUS_TREE_POOL_ID}`;

// netlify/lib/tree-swap-route.ts
var SUI_TYPE = "0x2::sui::SUI";
var TREE_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var SUIDEX_V2_TREE_POOL = "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc";
var SUIDEX_V3_TREE_POOL = "0x39d5ba22e01e45bc4129ec28a0bef52e8fee8db5d07d337adf9540e3cb9074cf";
var MAX_TREE_RAW = 1000000000n * 1000000n;
var MAX_SUI_RAW = 1000000000n * 1000000000n;
function normalizeMoveType(type) {
  const parts = String(type || "").trim().split("::");
  if (parts.length < 3) return String(type || "").trim().toLowerCase();
  const rawAddress = parts.shift() || "";
  const addressBody = rawAddress.toLowerCase().replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${addressBody}::${parts.join("::")}`.toLowerCase();
}

// netlify/lib/tree-raffle-buy-verifier.ts
var SUI_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var SUIDEX_V2_PACKAGE = "0xbfac5e1c6bf6ef29b12f7723857695fd2f4da9a11a7d88162c15e9124c243a4a";
var SUIDEX_V3_PACKAGE = "0xb5f529c1dcda6580a61bf7ee9fbd524b50be62f11044d137c8202c8cbace9e56";
var TURBOS_PACKAGE = "0xa5a0c25c79e428eba04fb98b3fb2a34db45ab26d4c8faf0d7e39d66a63891e64";
var TURBOS_EVENT_PACKAGE = "0x91bfbc386a41afcfd9b2533058d7e915a1d3829089cc268ff4333d54d6339ca1";
var TURBOS_SUI_TREE_POOL = "0xaa133ce1f8fd55d85b6fc87c1b3054cb717d83be477ef3635c661c21fbdfa0ee";
var TURBOS_SUI_TREE_FEE_TYPE = "0x91bfbc386a41afcfd9b2533058d7e915a1d3829089cc268ff4333d54d6339ca1::fee10000bps::FEE10000BPS";
var DIGEST_PATTERN = /^[1-9A-HJ-NP-Za-km-z]{40,64}$/;
var TREE_RAFFLE_BUY_QUERY = `query TreeRaffleBuy($digest: String!) {
  transaction(digest: $digest) {
    digest
    sender { address }
    transactionJson
    effects {
      status
      timestamp
      checkpoint { sequenceNumber }
      balanceChanges(first: 50) {
        pageInfo { hasNextPage }
        nodes { owner { address } coinType { repr } amount }
      }
      events(first: 50) {
        pageInfo { hasNextPage }
        nodes {
          sender { address }
          transactionModule { fullyQualifiedName }
          contents { type { repr } json }
        }
      }
    }
  }
}`;
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function normalizeAddress(value) {
  if (typeof value !== "string") return null;
  const body = value.trim().toLowerCase().replace(/^0x/, "");
  if (!/^[0-9a-f]{1,64}$/.test(body)) return null;
  return `0x${body.padStart(64, "0")}`;
}
function parseUnsigned(value) {
  const text = typeof value === "bigint" ? value.toString() : String(value ?? "").trim();
  return /^(?:0|[1-9][0-9]*)$/.test(text) ? BigInt(text) : null;
}
function parseSigned(value) {
  const text = typeof value === "bigint" ? value.toString() : String(value ?? "").trim();
  return /^-?(?:0|[1-9][0-9]*)$/.test(text) ? BigInt(text) : null;
}
function extractMoveCalls(value) {
  const calls = [];
  const visit = (node) => {
    if (Array.isArray(node)) return void node.forEach(visit);
    const object = record(node);
    if (!Object.keys(object).length) return;
    const packageId = normalizeAddress(object.package ?? object.packageId ?? object.package_id ?? object.packageAddress);
    const moduleName = object.module ?? object.moduleName ?? object.module_name;
    const functionName = object.function ?? object.functionName ?? object.function_name;
    if (packageId && typeof moduleName === "string" && typeof functionName === "string") {
      const rawTypes = object.typeArguments ?? object.type_arguments ?? object.typeArgs;
      calls.push({
        packageId,
        moduleName: moduleName.toLowerCase(),
        functionName: functionName.toLowerCase(),
        typeArguments: Array.isArray(rawTypes) ? rawTypes.filter((item) => typeof item === "string") : []
      });
    }
    Object.values(object).forEach(visit);
  };
  visit(value);
  return calls;
}
var NORMAL_SUI = normalizeMoveType(SUI_TYPE);
var NORMAL_TREE = normalizeMoveType(TREE_TYPE);
var NORMAL_FEE = normalizeMoveType(TURBOS_SUI_TREE_FEE_TYPE);
var NORMAL_V2_PACKAGE = normalizeAddress(SUIDEX_V2_PACKAGE);
var NORMAL_V3_PACKAGE = normalizeAddress(SUIDEX_V3_PACKAGE);
var NORMAL_TURBOS_PACKAGE = normalizeAddress(TURBOS_PACKAGE);
var NORMAL_CETUS_PACKAGE = normalizeAddress(CETUS_INTEGRATE_PACKAGE);
function exactTypes(call, expected) {
  return call.typeArguments.length === expected.length && call.typeArguments.every((value, index) => normalizeMoveType(value) === expected[index]);
}
function recognizedSwapCall(call) {
  if (call.packageId === NORMAL_V2_PACKAGE && call.moduleName === "router" && call.functionName === "swap_exact_tokens0_for_tokens1" && exactTypes(call, [NORMAL_SUI, NORMAL_TREE])) return "suidex-v2";
  if (call.packageId === NORMAL_V3_PACKAGE && call.moduleName === "trade" && call.functionName === "flash_swap" && exactTypes(call, [NORMAL_SUI, NORMAL_TREE])) return "suidex-v3";
  if (call.packageId === NORMAL_TURBOS_PACKAGE && call.moduleName === "swap_router" && call.functionName === "swap_b_a" && exactTypes(call, [NORMAL_TREE, NORMAL_SUI, NORMAL_FEE])) return "turbos";
  if (call.packageId === NORMAL_CETUS_PACKAGE && call.moduleName === "pool_script_v2" && call.functionName === "swap_b2a" && exactTypes(call, [NORMAL_TREE, NORMAL_SUI])) return "cetus";
  return null;
}
function disqualifyingCall(call) {
  if (![NORMAL_V2_PACKAGE, NORMAL_V3_PACKAGE, NORMAL_TURBOS_PACKAGE, NORMAL_CETUS_PACKAGE].includes(call.packageId)) return false;
  const containsTree = call.typeArguments.some((type) => normalizeMoveType(type) === NORMAL_TREE);
  if (!containsTree) return false;
  return /(liquidity|position|farm|staking|reward|collect|deposit|withdraw|stake|unstake|mint|open|close|add_|remove_)/.test(`${call.moduleName}::${call.functionName}`);
}
function eventType(event) {
  return String(record(record(event.contents).type).repr || "").toLowerCase();
}
function eventJson(event) {
  return record(record(event.contents).json);
}
function eventParty(event, json2, field) {
  return normalizeAddress(json2[field]) ?? normalizeAddress(record(event.sender).address);
}
function parseSwapEvent(eventValue, buyer) {
  const event = record(eventValue);
  const type = eventType(event);
  const json2 = eventJson(event);
  if (type.startsWith(`${SUIDEX_V2_PACKAGE}::pair::swap<`) && normalizeMoveType(type.slice(type.indexOf("<") + 1, type.lastIndexOf(">")).split(",")[0]) === NORMAL_SUI && normalizeMoveType(type.slice(type.indexOf("<") + 1, type.lastIndexOf(">")).split(",")[1]) === NORMAL_TREE) {
    const input = parseUnsigned(json2.amount0_in);
    const otherInput = parseUnsigned(json2.amount1_in);
    const inputOutput = parseUnsigned(json2.amount0_out);
    const output = parseUnsigned(json2.amount1_out);
    if (eventParty(event, json2, "sender") === buyer && input && input > 0n && otherInput === 0n && inputOutput === 0n && output && output > 0n) {
      return { route: "suidex-v2", input, output };
    }
    return null;
  }
  if (type === `${SUIDEX_V3_PACKAGE}::trade::swapevent`) {
    const input = parseUnsigned(json2.amount_x);
    const output = parseUnsigned(json2.amount_y);
    if (normalizeAddress(json2.pool_id) === normalizeAddress(SUIDEX_V3_TREE_POOL) && json2.x_for_y === true && eventParty(event, json2, "sender") === buyer && input && input > 0n && output && output > 0n) return { route: "suidex-v3", input, output };
    return null;
  }
  if (type === `${TURBOS_EVENT_PACKAGE}::pool::swapevent`) {
    const input = parseUnsigned(json2.amount_b);
    const output = parseUnsigned(json2.amount_a);
    if (normalizeAddress(json2.pool) === normalizeAddress(TURBOS_SUI_TREE_POOL) && json2.a_to_b === false && json2.is_exact_in === true && eventParty(event, json2, "recipient") === buyer && input && input > 0n && output && output > 0n) return { route: "turbos", input, output };
  }
  if (type === `${CETUS_CLMM_PACKAGE}::pool::swapevent`) {
    const input = parseUnsigned(json2.amount_in);
    const output = parseUnsigned(json2.amount_out);
    if (normalizeAddress(json2.pool) === normalizeAddress(CETUS_TREE_POOL_ID) && json2.atob === false && eventParty(event, json2, "sender") === buyer && input && input > 0n && output && output > 0n) return { route: "cetus", input, output };
  }
  return null;
}
function newYorkDate(isoTimestamp) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(new Date(isoTimestamp));
  const read = (type) => parts.find((part) => part.type === type)?.value || "";
  return `${read("year")}-${read("month")}-${read("day")}`;
}
function containsPool(transactionJson, pool) {
  return JSON.stringify(transactionJson).toLowerCase().includes(pool.toLowerCase());
}
function verifyFinalizedTreeBuyNode(nodeValue, expectedDigest) {
  const node = record(nodeValue);
  const digest = typeof node.digest === "string" ? node.digest.trim() : "";
  if (!DIGEST_PATTERN.test(digest) || expectedDigest && digest !== expectedDigest) throw new Error("Transaction digest did not match the requested Sui transaction.");
  const buyer = normalizeAddress(record(node.sender).address);
  if (!buyer) throw new Error("Transaction sender is unavailable.");
  const effects = record(node.effects);
  if (effects.status !== "SUCCESS") throw new Error("Only successful finalized transactions can qualify.");
  const finalizedAt = new Date(String(effects.timestamp || "")).toISOString();
  const checkpointRaw = parseUnsigned(record(effects.checkpoint).sequenceNumber);
  if (!checkpointRaw || checkpointRaw > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("Finalized checkpoint is unavailable.");
  const events = record(effects.events);
  const balances = record(effects.balanceChanges);
  if (record(events.pageInfo).hasNextPage === true || record(balances.pageInfo).hasNextPage === true) {
    throw new Error("Transaction evidence exceeded the verifier page limit.");
  }
  const eventNodes = Array.isArray(events.nodes) ? events.nodes : [];
  const disqualifyingEvent = eventNodes.some((value) => /(lpmint|liquidity|position|farm|stake|deposit|withdraw|reward)/i.test(eventType(record(value))));
  if (disqualifyingEvent) throw new Error("Liquidity, zap, farm, and position transactions do not earn raffle tickets.");
  const calls = extractMoveCalls(node.transactionJson);
  if (calls.some(disqualifyingCall)) throw new Error("Liquidity, zap, farm, and position transactions do not earn raffle tickets.");
  const swapCalls = calls.map(recognizedSwapCall).filter((route) => Boolean(route));
  if (swapCalls.length !== 1) throw new Error("A qualifying buy must contain exactly one allowlisted TREE swap.");
  const evidence = eventNodes.map((value) => parseSwapEvent(value, buyer)).filter((value) => Boolean(value));
  if (evidence.length !== 1 || evidence[0].route !== swapCalls[0]) throw new Error("The allowlisted swap event could not be uniquely verified.");
  const requiredPool = evidence[0].route === "suidex-v2" ? SUIDEX_V2_TREE_POOL : evidence[0].route === "suidex-v3" ? SUIDEX_V3_TREE_POOL : evidence[0].route === "turbos" ? TURBOS_SUI_TREE_POOL : CETUS_TREE_POOL_ID;
  if (!containsPool(node.transactionJson, requiredPool)) throw new Error("The swap did not use the exact allowlisted SUI/TREE pool.");
  let suiDelta = 0n;
  let treeDelta = 0n;
  for (const value of Array.isArray(balances.nodes) ? balances.nodes : []) {
    const change = record(value);
    if (normalizeAddress(record(change.owner).address) !== buyer) continue;
    const amount = parseSigned(change.amount);
    if (amount === null) throw new Error("Transaction balance evidence is malformed.");
    const coinType = normalizeMoveType(record(change.coinType).repr);
    if (coinType === NORMAL_SUI) suiDelta += amount;
    if (coinType === NORMAL_TREE) treeDelta += amount;
  }
  if (treeDelta !== evidence[0].output || suiDelta > -evidence[0].input) {
    throw new Error("Sender balance changes do not reconcile with the verified swap event.");
  }
  return {
    txDigest: digest,
    buyer,
    route: evidence[0].route,
    suiSpentRaw: evidence[0].input.toString(),
    treeAmountRaw: evidence[0].output.toString(),
    finalizedCheckpoint: Number(checkpointRaw),
    finalizedAt,
    raffleDate: newYorkDate(finalizedAt)
  };
}
async function fetchFinalizedTreeBuy(digest, options = {}) {
  if (!DIGEST_PATTERN.test(digest)) throw new Error("A valid Sui transaction digest is required.");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), options.timeoutMs ?? 8e3);
  try {
    const response = await (options.fetchImpl ?? fetch)(options.endpoint ?? SUI_GRAPHQL_URL, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({ query: TREE_RAFFLE_BUY_QUERY, variables: { digest } }),
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`Sui transaction verification returned ${response.status}.`);
    const payload = record(await response.json());
    if (Array.isArray(payload.errors) && payload.errors.length) throw new Error("Sui transaction verification returned a GraphQL error.");
    const transaction = record(record(payload.data).transaction);
    if (!Object.keys(transaction).length) throw new Error("The Sui transaction was not found or is not finalized.");
    return verifyFinalizedTreeBuyNode(transaction, digest);
  } finally {
    clearTimeout(timeout);
  }
}

// netlify/lib/tree-raffle-supabase-ledger.ts
function requiredConfigValue(value, label) {
  const normalized = value?.trim();
  if (!normalized) throw new Error(`${label} is not configured.`);
  return normalized;
}
function treeRaffleSupabaseConfig(env = process.env) {
  const url = requiredConfigValue(env.TREE_RAFFLE_SUPABASE_URL, "TREE_RAFFLE_SUPABASE_URL");
  const secretKey = requiredConfigValue(
    env.TREE_RAFFLE_SUPABASE_SECRET_KEY,
    "TREE_RAFFLE_SUPABASE_SECRET_KEY"
  );
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error("TREE_RAFFLE_SUPABASE_URL must be a valid HTTPS URL.");
  }
  if (parsed.protocol !== "https:") {
    throw new Error("TREE_RAFFLE_SUPABASE_URL must use HTTPS.");
  }
  return {
    url: parsed.origin,
    secretKey,
    weeklyEnabled: env.TREE_RAFFLE_WEEKLY_ENABLED === "true"
  };
}
function integerResult(value, label) {
  const parsed = typeof value === "string" ? Number(value) : value;
  if (!Number.isSafeInteger(parsed) || parsed < 0) {
    throw new Error(`Supabase returned an invalid ${label}.`);
  }
  return parsed;
}
function parseLedgerResult(value) {
  if (!value || typeof value !== "object") {
    throw new Error("Supabase returned an invalid raffle ledger response.");
  }
  const row = value;
  if (row.outcome !== "recorded" && row.outcome !== "duplicate") {
    throw new Error("Supabase returned an invalid raffle ledger outcome.");
  }
  if (typeof row.qualifies !== "boolean") {
    throw new Error("Supabase returned an invalid raffle qualification state.");
  }
  const streakDays = row.streakDays === null ? null : integerResult(row.streakDays, "streak day count");
  if (typeof row.dailyRoundId !== "string" || typeof row.weeklyRoundId !== "string") {
    throw new Error("Supabase returned invalid raffle round identifiers.");
  }
  return {
    outcome: row.outcome,
    qualifies: row.qualifies,
    streakDays,
    mainTickets: integerResult(row.mainTickets, "main ticket count"),
    luckyLeafTickets: integerResult(row.luckyLeafTickets, "Lucky Leaf ticket count"),
    dailyRoundId: row.dailyRoundId,
    weeklyRoundId: row.weeklyRoundId
  };
}
var SupabaseTreeRaffleLedger = class {
  config;
  fetchImpl;
  constructor(config2, fetchImpl = fetch) {
    this.config = config2;
    this.fetchImpl = fetchImpl;
  }
  async recordVerifiedBuy(input) {
    const rpc = this.config.weeklyEnabled ? "record_tree_raffle_verified_buy" : "record_tree_raffle_verified_buy_daily_only";
    const response = await this.fetchImpl(
      `${this.config.url}/rest/v1/rpc/${rpc}`,
      {
        method: "POST",
        headers: {
          apikey: this.config.secretKey,
          Authorization: `Bearer ${this.config.secretKey}`,
          "Content-Type": "application/json",
          "X-Client-Info": "tree-command-center-raffle/1"
        },
        body: JSON.stringify({
          p_tx_digest: input.txDigest,
          p_buyer: input.buyer,
          p_tree_amount_raw: input.treeAmountRaw,
          p_qualifying_usd_cents: input.qualifyingUsdCents,
          p_route: input.route,
          p_finalized_checkpoint: input.finalizedCheckpoint,
          p_finalized_at: input.finalizedAt,
          p_raffle_date: input.raffleDate,
          p_daily_round_id: input.dailyRoundId,
          p_weekly_round_id: input.weeklyRoundId
        }),
        signal: AbortSignal.timeout(1e4)
      }
    );
    const payload = await response.json().catch(() => null);
    if (!response.ok) {
      const message = payload && typeof payload === "object" && typeof payload.message === "string" ? payload.message : `Supabase raffle ledger request failed with HTTP ${response.status}.`;
      throw new Error(message);
    }
    return parseLedgerResult(payload);
  }
};
function configuredSupabaseTreeRaffleLedger(env = process.env, fetchImpl = fetch) {
  return new SupabaseTreeRaffleLedger(treeRaffleSupabaseConfig(env), fetchImpl);
}

// netlify/lib/tree-raffle-price.ts
var PRICE_SCALE = 100000000n;
var SUI_BASE_UNITS = 1000000000n;
var CENTS_PER_DOLLAR = 100n;
function scaledDecimal(value) {
  const number = Number(value);
  if (!Number.isFinite(number) || number <= 0 || number > 1e4) return null;
  const fixed = number.toFixed(8);
  const [whole, fraction = ""] = fixed.split(".");
  return BigInt(whole) * PRICE_SCALE + BigInt(fraction.padEnd(8, "0"));
}
async function fetchSuiUsdPriceScaled(fetchImpl = fetch) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 6e3);
  try {
    const response = await fetchImpl(
      "https://api.coingecko.com/api/v3/simple/price?ids=sui&vs_currencies=usd",
      { headers: { Accept: "application/json", "User-Agent": "TREE-Command-Center-Raffle/1.0" }, signal: controller.signal }
    );
    if (!response.ok) throw new Error(`SUI price verification returned ${response.status}.`);
    const payload = await response.json();
    const price = scaledDecimal(payload.sui?.usd);
    if (!price) throw new Error("SUI price verification returned no usable USD price.");
    return price;
  } finally {
    clearTimeout(timeout);
  }
}
function qualifyingUsdCentsFromSuiRaw(suiRaw, priceScaled) {
  if (!/^[1-9][0-9]*$/.test(suiRaw) || priceScaled <= 0n) throw new Error("Verified SUI value is invalid.");
  const cents = BigInt(suiRaw) * priceScaled * CENTS_PER_DOLLAR / (SUI_BASE_UNITS * PRICE_SCALE);
  if (cents > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("Verified USD value exceeds the supported range.");
  return Number(cents);
}

// netlify/lib/tree-raffle-ingest.ts
function json(body, status = 200) {
  return Response.json(body, {
    status,
    headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "X-Robots-Tag": "noindex" }
  });
}
function secretMatches(received, expected) {
  if (!received || !expected) return false;
  const left = createHash("sha256").update(received).digest();
  const right = createHash("sha256").update(expected).digest();
  return timingSafeEqual(left, right);
}
function weeklyRoundDate(raffleDate) {
  const date = /* @__PURE__ */ new Date(`${raffleDate}T00:00:00.000Z`);
  date.setUTCDate(date.getUTCDate() + (7 - date.getUTCDay()) % 7);
  return date.toISOString().slice(0, 10);
}
function completeVerifiedBuy(buy, qualifyingUsdCents) {
  return {
    ...buy,
    qualifyingUsdCents,
    dailyRoundId: `daily:${buy.raffleDate}`,
    weeklyRoundId: `weekly:${weeklyRoundDate(buy.raffleDate)}`
  };
}
function createTreeRaffleIngestHandler(dependencies = {}) {
  const env = dependencies.env ?? process.env;
  return async (request) => {
    if (request.method !== "POST") return json({ status: "error", error: "method-not-allowed" }, 405);
    const rules = treeRaffleRulesForEnvironment(env);
    const raffleIngestionEnabled = env.TREE_RAFFLE_INGEST_ENABLED === "true" && (dependencies.allowEntries ?? raffleOperationalReadiness(env, rules).verifiedBuyIngestionEnabled);
    const knowledgeTrialIngestionEnabled = env.TREE_KNOWLEDGE_TRIAL_INGEST_ENABLED === "true";
    const enabled = raffleIngestionEnabled || knowledgeTrialIngestionEnabled;
    if (!enabled) return json({ status: "disabled", error: "raffle-entries-disabled" }, 503);
    const configuredSecret = env.TREE_RAFFLE_INGEST_SECRET?.trim() || "";
    if (!secretMatches(request.headers.get("x-tree-raffle-ingest-secret") || "", configuredSecret)) {
      return json({ status: "error", error: "unauthorized" }, 401);
    }
    let digest = "";
    try {
      const body = await request.json();
      if (!body || typeof body !== "object" || Array.isArray(body) || Object.keys(body).length !== 1 || typeof body.digest !== "string") throw new Error("invalid");
      digest = body.digest.trim();
    } catch {
      return json({ status: "error", error: "invalid-request", message: "Send one finalized Sui transaction digest." }, 400);
    }
    const verify = dependencies.verifyBuy ?? fetchFinalizedTreeBuy;
    let buy;
    try {
      buy = await verify(digest);
    } catch (error) {
      console.info("TREE raffle candidate did not qualify", digest, error);
      return json({
        status: "ignored",
        error: "not-qualifying",
        message: "The finalized transaction is not a qualifying direct SUI-to-TREE purchase."
      }, 422);
    }
    try {
      const readPrice = dependencies.priceScaled ?? (() => fetchSuiUsdPriceScaled());
      const ledger = dependencies.ledger ?? configuredSupabaseTreeRaffleLedger(env);
      const priceScaled = await readPrice();
      const input = completeVerifiedBuy(buy, qualifyingUsdCentsFromSuiRaw(buy.suiSpentRaw, priceScaled));
      const result = await ledger.recordVerifiedBuy(input);
      return json({ status: "ok", txDigest: buy.txDigest, ...result });
    } catch (error) {
      console.error("TREE raffle verified-buy ingestion failed", error);
      return json({
        status: "error",
        error: "temporary-ingest-failure",
        message: "The qualifying TREE purchase could not be recorded yet."
      }, 503);
    }
  };
}

// netlify/functions/tree-raffle-ingest-buy.ts
var tree_raffle_ingest_buy_default = createTreeRaffleIngestHandler();
var config = { path: "/api/tree-raffle-ingest-buy" };
export {
  config,
  tree_raffle_ingest_buy_default as default
};
