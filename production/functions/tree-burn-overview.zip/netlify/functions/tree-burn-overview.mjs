
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/tree-burn-overview.ts
import { ChannelCredentials as ChannelCredentials2 } from "@grpc/grpc-js";
import { GrpcTransport as GrpcTransport2 } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient as SuiGrpcClient2 } from "@mysten/sui/grpc";

// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var TREE_DECIMALS = 6;
var TREE_TOTAL_SUPPLY_RAW = 1000000000000000n;
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));

// netlify/lib/tree-badge-types.ts
var TREE_ACTIVITY_WINDOW_MS = 30 * 24 * 60 * 60 * 1e3;

// netlify/lib/tree-burn-index.ts
var SUI_ZERO_ADDRESS = `0x${"0".repeat(64)}`;
var DEFAULT_MAX_SCAN_MS = 10 * 60 * 1e3;
function canonicalCoinType(value) {
  if (typeof value !== "string") return null;
  const parts = value.trim().toLowerCase().split("::");
  if (parts.length !== 3) return null;
  const address = parts[0].replace(/^0x/, "");
  if (!/^[0-9a-f]{1,64}$/.test(address)) return null;
  return `0x${address.padStart(64, "0")}::${parts[1]}::${parts[2]}`;
}
var NORMALIZED_TREE = canonicalCoinType(TREE_COIN_TYPE);

// netlify/lib/tree-burn-history-snapshot.ts
var TREE_BURN_HISTORY_SNAPSHOT = {
  generatedAt: "2026-08-18T20:52:06.422Z",
  source: "Sui Mainnet zero-address TREE coin objects",
  coinObjects: 1507,
  totalTransactions: 722,
  totalBurned: "60422789.609865",
  recentBurns: [
    {
      digest: "45RWDeLWdMgy28kT1CASSft2SF5QgTV41BbZhSQ8Syhc",
      amount: "1658.854024",
      timestamp: "2026-08-16T02:15:10.519Z"
    },
    {
      digest: "4HL6UCLRKAtKbo9YtmXgpkqPckmhyuqwAPMZRrpzCNFu",
      amount: "4088.141633",
      timestamp: "2026-08-16T02:15:10.519Z"
    },
    {
      digest: "nyAXpV85DtyP3xe2rPHAseSWrboojYhowo9jk5hJoDw",
      amount: "4474.967929",
      timestamp: "2026-08-16T02:09:09.082Z"
    }
  ]
};
function burnAge(timestamp, nowMs = Date.now()) {
  const timestampMs = Date.parse(timestamp);
  if (!Number.isFinite(timestampMs) || timestampMs > nowMs) return "\u2014";
  const days = Math.floor((nowMs - timestampMs) / 864e5);
  if (days > 0) return `${days}d`;
  const hours = Math.floor((nowMs - timestampMs) / 36e5);
  if (hours > 0) return `${hours}h`;
  return `${Math.max(0, Math.floor((nowMs - timestampMs) / 6e4))}m`;
}
function verifiedBurnHistory(nowMs = Date.now()) {
  return {
    ...TREE_BURN_HISTORY_SNAPSHOT,
    recentBurns: TREE_BURN_HISTORY_SNAPSHOT.recentBurns.map((burn) => ({
      ...burn,
      age: burnAge(burn.timestamp, nowMs)
    }))
  };
}

// netlify/lib/tree-burn-history-live.ts
import { ChannelCredentials } from "@grpc/grpc-js";
import { GrpcTransport } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient } from "@mysten/sui/grpc";
function createClient() {
  return new SuiGrpcClient({
    network: "mainnet",
    transport: new GrpcTransport({
      host: "fullnode.mainnet.sui.io:443",
      channelCredentials: ChannelCredentials.createSsl()
    })
  });
}
async function loadAllBurnCoinObjects(client, deadlineAt) {
  const objects = [];
  let cursor = null;
  let pagesScanned = 0;
  do {
    if (Date.now() >= deadlineAt) throw new Error("Live burn coin scan reached its deadline.");
    const page = await client.core.listOwnedObjects({
      owner: SUI_ZERO_ADDRESS,
      type: `0x2::coin::Coin<${TREE_COIN_TYPE}>`,
      cursor: cursor || void 0,
      limit: 50,
      include: { previousTransaction: true, json: true }
    });
    pagesScanned += 1;
    for (const value of page.objects) {
      if ("reason" in value) continue;
      const json = value.json && typeof value.json === "object" ? value.json : {};
      objects.push({
        objectId: value.objectId,
        version: value.version,
        balanceRaw: typeof json.balance === "string" ? json.balance : "",
        previousTransaction: typeof value.previousTransaction === "string" ? value.previousTransaction : ""
      });
    }
    if (!page.hasNextPage) return { objects, pagesScanned };
    if (!page.cursor || page.cursor === cursor) throw new Error("Live burn coin cursor was missing or repeated.");
    cursor = page.cursor;
  } while (true);
}
async function loadTransactionTimestamps(digests) {
  const timestamps = /* @__PURE__ */ new Map();
  const query = `query TreeBurnTimestamp($digest: String!) {
    transaction(digest: $digest) { effects { timestamp } }
  }`;
  await Promise.all(digests.map(async (digest) => {
    try {
      const response = await fetch("https://graphql.mainnet.sui.io/graphql", {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify({ query, variables: { digest } })
      });
      if (!response.ok) return;
      const payload = await response.json();
      const timestamp = payload?.data?.transaction?.effects?.timestamp;
      if (typeof timestamp === "string") timestamps.set(digest, timestamp);
    } catch {
    }
  }));
  return timestamps;
}
function formatRaw(raw) {
  const base = 10n ** BigInt(TREE_DECIMALS);
  const whole = raw / base;
  const fraction = (raw % base).toString().padStart(TREE_DECIMALS, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
}
function burnAge2(timestamp, nowMs) {
  const then = Date.parse(timestamp);
  if (!Number.isFinite(then) || then > nowMs) return "\u2014";
  const elapsed = nowMs - then;
  const minutes = Math.floor(elapsed / 6e4);
  if (minutes < 60) return `${Math.max(1, minutes)}m`;
  const hours = Math.floor(elapsed / 36e5);
  if (hours < 24) return `${hours}h`;
  return `${Math.floor(elapsed / 864e5)}d`;
}
async function scanLiveTreeBurnHistory(options = {}) {
  const now = options.now ?? Date.now;
  const startedAt = now();
  const generatedAt = new Date(startedAt).toISOString();
  const maxScanMs = Math.max(1e3, Math.trunc(options.maxScanMs ?? 22e3));
  const client = options.loadObjects && options.loadTimestamps ? null : createClient();
  const coverage = {
    pagesScanned: 0,
    coinObjectsScanned: 0,
    burnTransactions: 0,
    duplicateTransactions: 0,
    malformedObjects: 0,
    reachedEnd: false
  };
  try {
    const loaded = options.loadObjects ? await options.loadObjects() : await loadAllBurnCoinObjects(client, startedAt + maxScanMs);
    coverage.pagesScanned = loaded.pagesScanned;
    coverage.coinObjectsScanned = loaded.objects.length;
    const transactions = /* @__PURE__ */ new Map();
    let totalRaw = 0n;
    for (const object of loaded.objects) {
      if (!/^\d+$/.test(object.balanceRaw) || !/^\d+$/.test(object.version) || !object.previousTransaction) {
        coverage.malformedObjects += 1;
        continue;
      }
      const raw = BigInt(object.balanceRaw);
      const version = BigInt(object.version);
      totalRaw += raw;
      const existing = transactions.get(object.previousTransaction);
      if (existing) {
        existing.raw += raw;
        if (version > existing.newestVersion) existing.newestVersion = version;
        coverage.duplicateTransactions += 1;
      } else {
        transactions.set(object.previousTransaction, { raw, newestVersion: version });
      }
    }
    if (coverage.malformedObjects) {
      return {
        outcome: "verification-incomplete",
        generatedAt,
        totalBurnedRaw: totalRaw.toString(),
        totalTransactions: null,
        coinObjects: null,
        recentBurns: [],
        coverage,
        warnings: ["One or more zero-address TREE coin objects could not be verified."]
      };
    }
    coverage.reachedEnd = true;
    coverage.burnTransactions = transactions.size;
    const recentCandidates = [...transactions.entries()].sort((a, b) => a[1].newestVersion > b[1].newestVersion ? -1 : a[1].newestVersion < b[1].newestVersion ? 1 : 0).slice(0, 20);
    const timestamps = options.loadTimestamps ? await options.loadTimestamps(recentCandidates.map(([digest]) => digest)) : await loadTransactionTimestamps(recentCandidates.map(([digest]) => digest));
    const recentBurns = recentCandidates.map(([digest, transaction]) => ({ digest, raw: transaction.raw, timestamp: timestamps.get(digest) || "" })).filter((burn) => Number.isFinite(Date.parse(burn.timestamp))).sort((a, b) => Date.parse(b.timestamp) - Date.parse(a.timestamp)).slice(0, 5).map((burn) => ({
      digest: burn.digest,
      amount: formatRaw(burn.raw),
      timestamp: burn.timestamp,
      age: burnAge2(burn.timestamp, startedAt)
    }));
    return {
      outcome: "complete",
      generatedAt,
      totalBurnedRaw: totalRaw.toString(),
      totalTransactions: transactions.size,
      coinObjects: loaded.objects.length,
      recentBurns,
      coverage,
      warnings: []
    };
  } catch (error) {
    return {
      outcome: "error",
      generatedAt,
      totalBurnedRaw: "0",
      totalTransactions: null,
      coinObjects: null,
      recentBurns: [],
      coverage,
      warnings: [error instanceof Error ? error.message : "Live burn history failed."]
    };
  }
}

// netlify/functions/tree-burn-overview.ts
function formatRaw2(raw) {
  const base = 10n ** BigInt(TREE_DECIMALS);
  const whole = raw / base;
  const fraction = (raw % base).toString().padStart(TREE_DECIMALS, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
}
function burnOverviewFromRaw(rawValue) {
  if (!/^\d+$/.test(rawValue)) throw new Error("Invalid TREE balance.");
  const zeroAddressBalanceRaw = BigInt(rawValue);
  if (zeroAddressBalanceRaw > TREE_TOTAL_SUPPLY_RAW) throw new Error("TREE balance exceeds verified supply.");
  const effectiveSupplyRaw = TREE_TOTAL_SUPPLY_RAW - zeroAddressBalanceRaw;
  const removalPercentage = Number(zeroAddressBalanceRaw * 100000000n / TREE_TOTAL_SUPPLY_RAW) / 1e6;
  return {
    coinType: TREE_COIN_TYPE,
    zeroAddress: SUI_ZERO_ADDRESS,
    totalSupplyRaw: TREE_TOTAL_SUPPLY_RAW.toString(),
    totalSupply: formatRaw2(TREE_TOTAL_SUPPLY_RAW),
    zeroAddressBalanceRaw: zeroAddressBalanceRaw.toString(),
    zeroAddressBalance: formatRaw2(zeroAddressBalanceRaw),
    effectiveSupplyRaw: effectiveSupplyRaw.toString(),
    effectiveSupply: formatRaw2(effectiveSupplyRaw),
    removalPercentage
  };
}
async function liveZeroAddressBalance() {
  const client = new SuiGrpcClient2({
    network: "mainnet",
    transport: new GrpcTransport2({
      host: "fullnode.mainnet.sui.io:443",
      channelCredentials: ChannelCredentials2.createSsl()
    })
  });
  let timeout;
  try {
    const result = await Promise.race([
      client.core.getBalance({ owner: SUI_ZERO_ADDRESS, coinType: TREE_COIN_TYPE }),
      new Promise((_, reject) => {
        timeout = setTimeout(() => reject(new Error("Sui gRPC balance lookup timed out.")), 8e3);
      })
    ]);
    return result.balance.balance;
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}
var tree_burn_overview_default = async (request) => {
  if (request.method !== "GET") {
    return Response.json({ status: "error", error: "method-not-allowed" }, { status: 405, headers: { Allow: "GET", "Cache-Control": "no-store" } });
  }
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  try {
    const overview = burnOverviewFromRaw(await liveZeroAddressBalance());
    const liveHistory = await scanLiveTreeBurnHistory();
    const liveHistoryMatchesBalance = liveHistory.outcome === "complete" && liveHistory.totalBurnedRaw === overview.zeroAddressBalanceRaw;
    const fallbackHistory = verifiedBurnHistory(Date.parse(generatedAt));
    return Response.json({
      status: "ok",
      generatedAt,
      network: "sui-mainnet",
      source: "Sui Mainnet gRPC",
      ...overview,
      totalTransactions: liveHistoryMatchesBalance ? liveHistory.totalTransactions : null,
      burnCoinObjects: liveHistoryMatchesBalance ? liveHistory.coinObjects : null,
      recentBurns: liveHistoryMatchesBalance ? liveHistory.recentBurns : [],
      historyGeneratedAt: liveHistoryMatchesBalance ? liveHistory.generatedAt : fallbackHistory.generatedAt,
      historySource: liveHistoryMatchesBalance ? "Sui Mainnet gRPC zero-address TREE coin scan with archival GraphQL timestamps" : fallbackHistory.source,
      historyCoverage: liveHistory.coverage,
      warnings: liveHistoryMatchesBalance ? [] : ["Burn history could not be reconciled exactly to the latest live zero-address balance.", ...liveHistory.warnings]
    }, {
      headers: { "Cache-Control": "public, max-age=15, s-maxage=30, stale-while-revalidate=120", "X-Content-Type-Options": "nosniff" }
    });
  } catch (error) {
    console.error("TREE burn overview failed", error);
    return Response.json({ status: "error", generatedAt, error: "burn-overview-unavailable", warnings: ["Live Sui burn data is temporarily unavailable."] }, {
      status: 503,
      headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" }
    });
  }
};
var config = { path: "/api/tree-burn-overview" };
export {
  burnOverviewFromRaw,
  config,
  tree_burn_overview_default as default
};
