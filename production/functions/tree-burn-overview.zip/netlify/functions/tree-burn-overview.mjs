
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/tree-burn-overview.ts
import { ChannelCredentials } from "@grpc/grpc-js";
import { GrpcTransport } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient } from "@mysten/sui/grpc";

// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var TREE_DECIMALS = 6;
var TREE_TOTAL_SUPPLY_RAW = 1000000000000000n;
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));

// netlify/lib/tree-badge-types.ts
var TREE_ACTIVITY_WINDOW_MS = 30 * 24 * 60 * 60 * 1e3;

// netlify/lib/tree-burn-index.ts
var SUI_ZERO_ADDRESS = `0x${"0".repeat(64)}`;
var DEFAULT_MAX_SCAN_MS = 10 * 60 * 1e3;
function canonicalCoinType(value) {
  if (typeof value !== "string") return null;
  const parts = value.trim().toLowerCase().split("::");
  if (parts.length !== 3) return null;
  const address = parts[0].replace(/^0x/, "");
  if (!/^[0-9a-f]{1,64}$/.test(address)) return null;
  return `0x${address.padStart(64, "0")}::${parts[1]}::${parts[2]}`;
}
var NORMALIZED_TREE = canonicalCoinType(TREE_COIN_TYPE);

// netlify/lib/tree-burn-history-snapshot.ts
var TREE_BURN_HISTORY_SNAPSHOT = {
  generatedAt: "2026-08-18T20:52:06.422Z",
  source: "Sui Mainnet zero-address TREE coin objects",
  coinObjects: 1507,
  totalTransactions: 722,
  totalBurned: "60422789.609865",
  recentBurns: [
    {
      digest: "45RWDeLWdMgy28kT1CASSft2SF5QgTV41BbZhSQ8Syhc",
      amount: "1658.854024",
      timestamp: "2026-08-16T02:15:10.519Z"
    },
    {
      digest: "4HL6UCLRKAtKbo9YtmXgpkqPckmhyuqwAPMZRrpzCNFu",
      amount: "4088.141633",
      timestamp: "2026-08-16T02:15:10.519Z"
    },
    {
      digest: "nyAXpV85DtyP3xe2rPHAseSWrboojYhowo9jk5hJoDw",
      amount: "4474.967929",
      timestamp: "2026-08-16T02:09:09.082Z"
    }
  ]
};
function burnAge(timestamp, nowMs = Date.now()) {
  const timestampMs = Date.parse(timestamp);
  if (!Number.isFinite(timestampMs) || timestampMs > nowMs) return "\u2014";
  const days = Math.floor((nowMs - timestampMs) / 864e5);
  if (days > 0) return `${days}d`;
  const hours = Math.floor((nowMs - timestampMs) / 36e5);
  if (hours > 0) return `${hours}h`;
  return `${Math.max(0, Math.floor((nowMs - timestampMs) / 6e4))}m`;
}
function verifiedBurnHistory(nowMs = Date.now()) {
  return {
    ...TREE_BURN_HISTORY_SNAPSHOT,
    recentBurns: TREE_BURN_HISTORY_SNAPSHOT.recentBurns.map((burn) => ({
      ...burn,
      age: burnAge(burn.timestamp, nowMs)
    }))
  };
}

// netlify/functions/tree-burn-overview.ts
function formatRaw(raw) {
  const base = 10n ** BigInt(TREE_DECIMALS);
  const whole = raw / base;
  const fraction = (raw % base).toString().padStart(TREE_DECIMALS, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
}
function burnOverviewFromRaw(rawValue) {
  if (!/^\d+$/.test(rawValue)) throw new Error("Invalid TREE balance.");
  const zeroAddressBalanceRaw = BigInt(rawValue);
  if (zeroAddressBalanceRaw > TREE_TOTAL_SUPPLY_RAW) throw new Error("TREE balance exceeds verified supply.");
  const effectiveSupplyRaw = TREE_TOTAL_SUPPLY_RAW - zeroAddressBalanceRaw;
  const removalPercentage = Number(zeroAddressBalanceRaw * 100000000n / TREE_TOTAL_SUPPLY_RAW) / 1e6;
  return {
    coinType: TREE_COIN_TYPE,
    zeroAddress: SUI_ZERO_ADDRESS,
    totalSupplyRaw: TREE_TOTAL_SUPPLY_RAW.toString(),
    totalSupply: formatRaw(TREE_TOTAL_SUPPLY_RAW),
    zeroAddressBalanceRaw: zeroAddressBalanceRaw.toString(),
    zeroAddressBalance: formatRaw(zeroAddressBalanceRaw),
    effectiveSupplyRaw: effectiveSupplyRaw.toString(),
    effectiveSupply: formatRaw(effectiveSupplyRaw),
    removalPercentage
  };
}
async function liveZeroAddressBalance() {
  const client = new SuiGrpcClient({
    network: "mainnet",
    transport: new GrpcTransport({
      host: "fullnode.mainnet.sui.io:443",
      channelCredentials: ChannelCredentials.createSsl()
    })
  });
  let timeout;
  try {
    const result = await Promise.race([
      client.core.getBalance({ owner: SUI_ZERO_ADDRESS, coinType: TREE_COIN_TYPE }),
      new Promise((_, reject) => {
        timeout = setTimeout(() => reject(new Error("Sui gRPC balance lookup timed out.")), 8e3);
      })
    ]);
    return result.balance.balance;
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}
var tree_burn_overview_default = async (request) => {
  if (request.method !== "GET") {
    return Response.json({ status: "error", error: "method-not-allowed" }, { status: 405, headers: { Allow: "GET", "Cache-Control": "no-store" } });
  }
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  try {
    const overview = burnOverviewFromRaw(await liveZeroAddressBalance());
    const history = verifiedBurnHistory(Date.parse(generatedAt));
    const historyMatchesBalance = history.totalBurned === overview.zeroAddressBalance;
    return Response.json({
      status: "ok",
      generatedAt,
      network: "sui-mainnet",
      source: "Sui Mainnet gRPC",
      ...overview,
      totalTransactions: historyMatchesBalance ? history.totalTransactions : null,
      burnCoinObjects: historyMatchesBalance ? history.coinObjects : null,
      recentBurns: historyMatchesBalance ? history.recentBurns : [],
      historyGeneratedAt: history.generatedAt,
      historySource: history.source,
      warnings: historyMatchesBalance ? [] : ["Burn history is refreshing to match the latest live balance."]
    }, {
      headers: { "Cache-Control": "public, max-age=15, s-maxage=30, stale-while-revalidate=120", "X-Content-Type-Options": "nosniff" }
    });
  } catch (error) {
    console.error("TREE burn overview failed", error);
    return Response.json({ status: "error", generatedAt, error: "burn-overview-unavailable", warnings: ["Live Sui burn data is temporarily unavailable."] }, {
      status: 503,
      headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" }
    });
  }
};
var config = { path: "/api/tree-burn-overview" };
export {
  burnOverviewFromRaw,
  config,
  tree_burn_overview_default as default
};
