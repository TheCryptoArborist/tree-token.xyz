
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/cetus-tree-constants.ts
var CETUS_TREE_POOL_ID = "0x2ebaff75b8745896404085babb9ef3a77ccbb6c7d3f4db31626cefff04f7f355";
var CETUS_TREE_FEE_RATE = 2500;
var CETUS_TREE_FEE_PERCENT = 0.25;
var CETUS_TREE_TICK_SPACING = 60;
var CETUS_TREE_POOL_URL = `https://app.cetus.zone/clmm?tab=deposit&poolAddress=${CETUS_TREE_POOL_ID}`;

// netlify/lib/tree-swap-route.ts
var SUI_TYPE = "0x2::sui::SUI";
var TREE_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var SUI_DECIMALS = 9;
var TREE_DECIMALS = 6;
var SUIDEX_V2_TREE_POOL = "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc";
var SUIDEX_V3_TREE_POOL = "0x39d5ba22e01e45bc4129ec28a0bef52e8fee8db5d07d337adf9540e3cb9074cf";
var TURBOS_SUI_TREE_POOL = "0xaa133ce1f8fd55d85b6fc87c1b3054cb717d83be477ef3635c661c21fbdfa0ee";
var TURBOS_SUI_TREE_FEE_TYPE = "0x91bfbc386a41afcfd9b2533058d7e915a1d3829089cc268ff4333d54d6339ca1::fee10000bps::FEE10000BPS";
var ROUTE_MAX_AGE_MS = 3e4;
var MAX_TREE_RAW = 1000000000n * 1000000n;
var MAX_SUI_RAW = 1000000000n * 1000000000n;
function normalizeMoveType(type) {
  const parts = String(type || "").trim().split("::");
  if (parts.length < 3) return String(type || "").trim().toLowerCase();
  const rawAddress = parts.shift() || "";
  const addressBody = rawAddress.toLowerCase().replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${addressBody}::${parts.join("::")}`.toLowerCase();
}
function isTreeSwapPair(tokenIn, tokenOut) {
  const input = normalizeMoveType(tokenIn);
  const output = normalizeMoveType(tokenOut);
  const sui = normalizeMoveType(SUI_TYPE);
  const tree = normalizeMoveType(TREE_TYPE);
  return input === sui && output === tree || input === tree && output === sui;
}
function validateSwapRequest(input) {
  const tokenIn = String(input.tokenIn || "");
  const tokenOut = String(input.tokenOut || "");
  if (!isTreeSwapPair(tokenIn, tokenOut)) throw new Error("Only the SUI/TREE pair is supported.");
  const amountText = String(input.amountIn || "");
  if (!/^\d+$/.test(amountText)) throw new Error("amountIn must be an unsigned base-unit integer.");
  const amount = BigInt(amountText);
  if (amount <= 0n) throw new Error("amountIn must be greater than zero.");
  const max = normalizeMoveType(tokenIn) === normalizeMoveType(SUI_TYPE) ? MAX_SUI_RAW : MAX_TREE_RAW;
  if (amount > max) throw new Error("amountIn exceeds the supported safety bound.");
  const slippageBps = Number(input.slippageBps);
  if (!Number.isInteger(slippageBps) || slippageBps < 10 || slippageBps > 500) {
    throw new Error("slippageBps must be an integer from 10 to 500.");
  }
  return { tokenIn: normalizeMoveType(tokenIn) === normalizeMoveType(SUI_TYPE) ? SUI_TYPE : TREE_TYPE, tokenOut: normalizeMoveType(tokenOut) === normalizeMoveType(SUI_TYPE) ? SUI_TYPE : TREE_TYPE, amountIn: amount.toString(), slippageBps };
}
function record(value) {
  return value && typeof value === "object" ? value : {};
}
function unsigned(value) {
  const text = String(value ?? "");
  if (!/^\d+$/.test(text)) return null;
  try {
    return BigInt(text) > 0n ? BigInt(text).toString() : null;
  } catch {
    return null;
  }
}
function finite(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}
function minOutForRoute(root, route, pairId, amountOut, slippageBps) {
  const metadata = record(root.buildMetadata);
  const metadataHops = Array.isArray(metadata.hops) ? metadata.hops : [];
  const match = metadataHops.map(record).find((hop) => String(hop.pairId || "") === pairId);
  const fromMetadata = unsigned(match?.minAmountOut);
  if (fromMetadata) return fromMetadata;
  const expected = BigInt(amountOut);
  return (expected - expected * BigInt(slippageBps) / 10000n).toString();
}
function sanitizeRoute(root, routeValue, request) {
  const route = record(routeValue);
  if (route.type !== "direct") return null;
  const hops = Array.isArray(route.hops) ? route.hops : [];
  if (hops.length !== 1) return null;
  const hop = record(hops[0]);
  const venue = String(hop.venue || "").toLowerCase();
  if (venue !== "suidex" && venue !== "v3") return null;
  const pairId = String(hop.pairId || "").toLowerCase();
  const expectedPair = venue === "suidex" ? SUIDEX_V2_TREE_POOL : SUIDEX_V3_TREE_POOL;
  if (pairId !== expectedPair) return null;
  if (!isTreeSwapPair(hop.tokenIn, hop.tokenOut)) return null;
  if (normalizeMoveType(hop.tokenIn) !== normalizeMoveType(request.tokenIn) || normalizeMoveType(hop.tokenOut) !== normalizeMoveType(request.tokenOut)) return null;
  const amountIn = unsigned(hop.amountIn || route.totalAmountIn);
  const amountOut = unsigned(hop.amountOut || route.totalAmountOut);
  if (!amountIn || !amountOut || amountIn !== request.amountIn) return null;
  let coinAType = null;
  let coinBType = null;
  if (venue === "v3") {
    coinAType = String(hop.coinAType || "");
    coinBType = String(hop.coinBType || "");
    if (!isTreeSwapPair(coinAType, coinBType)) return null;
  }
  const priceImpactPercent3 = finite(route.totalPriceImpact ?? hop.priceImpact, 0);
  if (priceImpactPercent3 < 0 || priceImpactPercent3 > 100) return null;
  const rawFee = finite(hop.feeRate, 0);
  const feePercent = venue === "v3" && rawFee > 0 ? rawFee / 1e4 : 0.3;
  return {
    type: "direct",
    venue,
    venueLabel: venue === "suidex" ? "SuiDex V2" : "SuiDex V3",
    executionKind: venue === "suidex" ? "suidex-v2-direct" : "suidex-v3-direct",
    pairId,
    tokenIn: request.tokenIn,
    tokenOut: request.tokenOut,
    amountIn,
    amountOut,
    minAmountOut: minOutForRoute(root, route, pairId, amountOut, request.slippageBps),
    priceImpactPercent: priceImpactPercent3,
    priceImpactTier: String(route.priceImpactTier || "unknown"),
    gasEstimate: unsigned(route.gasEstimate) || "0",
    feePercent,
    coinAType,
    coinBType
  };
}
function sanitizeTurbosRoute(routeValue, request) {
  const route = record(routeValue);
  if (route.type !== "direct" || route.venue !== "turbos" || route.executionKind !== "turbos-direct") return null;
  const pairId = String(route.pairId || "").toLowerCase();
  if (pairId !== TURBOS_SUI_TREE_POOL) return null;
  if (normalizeMoveType(route.tokenIn) !== normalizeMoveType(request.tokenIn) || normalizeMoveType(route.tokenOut) !== normalizeMoveType(request.tokenOut)) return null;
  const amountIn = unsigned(route.amountIn);
  const amountOut = unsigned(route.amountOut);
  const minAmountOut = unsigned(route.minAmountOut);
  if (!amountIn || !amountOut || !minAmountOut || amountIn !== request.amountIn || BigInt(minAmountOut) > BigInt(amountOut)) return null;
  const coinAType = String(route.coinAType || "");
  const coinBType = String(route.coinBType || "");
  const feeType = String(route.feeType || "");
  if (!isTreeSwapPair(coinAType, coinBType)) return null;
  if (normalizeMoveType(feeType) !== normalizeMoveType(TURBOS_SUI_TREE_FEE_TYPE)) return null;
  const aToB = route.aToB === true;
  if (normalizeMoveType(request.tokenIn) !== normalizeMoveType(aToB ? coinAType : coinBType)) return null;
  const nextTickIndex = Number(route.nextTickIndex);
  if (!Number.isInteger(nextTickIndex) || nextTickIndex < -443636 || nextTickIndex > 443636) return null;
  const priceImpactPercent3 = finite(route.priceImpactPercent, -1);
  const feePercent = finite(route.feePercent, -1);
  if (priceImpactPercent3 < 0 || priceImpactPercent3 > 100 || feePercent < 0 || feePercent > 10) return null;
  return {
    type: "direct",
    venue: "turbos",
    venueLabel: "Turbos",
    executionKind: "turbos-direct",
    pairId,
    tokenIn: request.tokenIn,
    tokenOut: request.tokenOut,
    amountIn,
    amountOut,
    minAmountOut,
    priceImpactPercent: priceImpactPercent3,
    priceImpactTier: String(route.priceImpactTier || "unknown"),
    gasEstimate: unsigned(route.gasEstimate) || "0",
    feePercent,
    coinAType,
    coinBType,
    feeType,
    aToB,
    nextTickIndex
  };
}
function sanitizeCetusRoute(routeValue, request) {
  const route = record(routeValue);
  if (route.type !== "direct" || route.venue !== "cetus" || route.executionKind !== "cetus-v3-direct" || String(route.pairId || "").toLowerCase() !== CETUS_TREE_POOL_ID) return null;
  if (normalizeMoveType(route.tokenIn) !== normalizeMoveType(request.tokenIn) || normalizeMoveType(route.tokenOut) !== normalizeMoveType(request.tokenOut)) return null;
  const amountIn = unsigned(route.amountIn);
  const amountOut = unsigned(route.amountOut);
  const minAmountOut = unsigned(route.minAmountOut);
  if (!amountIn || !amountOut || !minAmountOut || amountIn !== request.amountIn || BigInt(minAmountOut) > BigInt(amountOut)) return null;
  const coinAType = String(route.coinAType || "");
  const coinBType = String(route.coinBType || "");
  if (!isTreeSwapPair(coinAType, coinBType)) return null;
  const aToB = route.aToB === true;
  if (normalizeMoveType(request.tokenIn) !== normalizeMoveType(aToB ? coinAType : coinBType)) return null;
  const priceImpactPercent3 = finite(route.priceImpactPercent, -1);
  const feePercent = finite(route.feePercent, -1);
  if (priceImpactPercent3 < 0 || priceImpactPercent3 > 100 || feePercent !== 0.25) return null;
  return {
    type: "direct",
    venue: "cetus",
    venueLabel: "Cetus V3",
    executionKind: "cetus-v3-direct",
    pairId: String(route.pairId || "").toLowerCase(),
    tokenIn: request.tokenIn,
    tokenOut: request.tokenOut,
    amountIn,
    amountOut,
    minAmountOut,
    priceImpactPercent: priceImpactPercent3,
    priceImpactTier: String(route.priceImpactTier || "verified"),
    gasEstimate: unsigned(route.gasEstimate) || "0",
    feePercent,
    coinAType,
    coinBType,
    aToB
  };
}
function normalizeTreeSwapQuote(payload, requestInput, additionalRoutes = []) {
  const request = validateSwapRequest(requestInput);
  const root = record(payload);
  const routeValues = [root.bestRoute, ...Array.isArray(root.directRoutes) ? root.directRoutes : []].filter(Boolean);
  const deduped = /* @__PURE__ */ new Map();
  for (const value of routeValues) {
    const route = sanitizeRoute(root, value, request);
    if (!route) continue;
    const key = `${route.venue}:${route.pairId}:${route.amountOut}`;
    deduped.set(key, route);
  }
  for (const value of additionalRoutes) {
    const candidate = record(value);
    const route = candidate.venue === "cetus" ? sanitizeCetusRoute(value, request) : sanitizeTurbosRoute(value, request);
    if (!route) continue;
    deduped.set(`${route.venue}:${route.pairId}:${route.amountOut}`, route);
  }
  const routes = [...deduped.values()].sort((left, right) => {
    const amountOrder = BigInt(right.minAmountOut) > BigInt(left.minAmountOut) ? 1 : BigInt(right.minAmountOut) < BigInt(left.minAmountOut) ? -1 : 0;
    if (amountOrder) return amountOrder;
    return BigInt(left.gasEstimate || "0") < BigInt(right.gasEstimate || "0") ? -1 : 1;
  });
  if (!routes.length) throw new Error("No allowlisted direct SuiDex, Turbos, or Cetus route was returned.");
  const generatedAt = requestInput.generatedAt || (/* @__PURE__ */ new Date()).toISOString();
  const generatedMs = Date.parse(generatedAt);
  const expiresAt = new Date((Number.isFinite(generatedMs) ? generatedMs : Date.now()) + ROUTE_MAX_AGE_MS).toISOString();
  return {
    status: "ok",
    generatedAt,
    expiresAt,
    source: "TREE verified multi-venue route service",
    executionScope: "Direct SuiDex V2, SuiDex V3, Turbos, and Cetus V3 SUI/TREE routes",
    tokenIn: request.tokenIn,
    tokenOut: request.tokenOut,
    decimalsIn: normalizeMoveType(request.tokenIn) === normalizeMoveType(SUI_TYPE) ? SUI_DECIMALS : TREE_DECIMALS,
    decimalsOut: normalizeMoveType(request.tokenOut) === normalizeMoveType(SUI_TYPE) ? SUI_DECIMALS : TREE_DECIMALS,
    amountIn: request.amountIn,
    slippageBps: request.slippageBps,
    selectedRoute: routes[0],
    routes,
    warnings: routes.length < 4 ? ["One or more allowlisted TREE venues were unavailable for this amount."] : []
  };
}

// netlify/lib/cetus-tree-swap.ts
import { CetusClmmSDK } from "@cetusprotocol/sui-clmm-sdk";
function unsigned2(value) {
  const text = String(value ?? "").trim();
  return /^\d+$/.test(text) ? BigInt(text) : null;
}
function address(value) {
  return String(value || "").toLowerCase();
}
function priceImpactPercent(amountIn, amountOut, sqrtPrice, aToB) {
  const q128 = 1n << 128n;
  const effectiveIn = amountIn * BigInt(1e6 - CETUS_TREE_FEE_RATE) / 1000000n;
  const sqrtSquared = sqrtPrice * sqrtPrice;
  const expected = aToB ? effectiveIn * sqrtSquared / q128 : effectiveIn * q128 / sqrtSquared;
  if (expected <= 0n || amountOut >= expected) return 0;
  const millionths = (expected - amountOut) * 100000000n / expected;
  return Number(millionths) / 1e6;
}
function verifyPool(pool) {
  const coinA = String(pool.coin_type_a || "");
  const coinB = String(pool.coin_type_b || "");
  const status = pool.pool_status || {};
  const liquidity = unsigned2(pool.liquidity);
  const sqrtPrice = unsigned2(pool.current_sqrt_price);
  if (address(pool.id) !== CETUS_TREE_POOL_ID || normalizeMoveType(coinA) !== normalizeMoveType(TREE_TYPE) || normalizeMoveType(coinB) !== normalizeMoveType(SUI_TYPE) || Number(pool.fee_rate) !== CETUS_TREE_FEE_RATE || Number(pool.tick_spacing) !== CETUS_TREE_TICK_SPACING || !liquidity || !sqrtPrice || status.disable_swap === true) {
    throw new Error("The allowlisted Cetus TREE/SUI pool failed Mainnet verification.");
  }
  return { coinA, coinB, sqrtPrice };
}
async function quoteCetusTreeSwap(request, options = {}) {
  const sdk2 = options.getPool && options.preSwap ? null : CetusClmmSDK.createSDK({ env: "mainnet" });
  const pool = await (options.getPool || (() => sdk2.Pool.getPool(CETUS_TREE_POOL_ID, true, false)))();
  const verified = verifyPool(pool);
  const aToB = normalizeMoveType(request.tokenIn) === normalizeMoveType(verified.coinA);
  const quote = await (options.preSwap || ((input) => sdk2.Swap.preSwap(input)))({
    pool,
    current_sqrt_price: pool.current_sqrt_price,
    coin_type_a: verified.coinA,
    coin_type_b: verified.coinB,
    decimals_a: 6,
    decimals_b: 9,
    a2b: aToB,
    by_amount_in: true,
    amount: request.amountIn
  });
  const amountIn = unsigned2(quote.estimated_amount_in);
  const amountOut = unsigned2(quote.estimated_amount_out);
  if (address(quote.pool_address) !== CETUS_TREE_POOL_ID || amountIn?.toString() !== request.amountIn || !amountOut || quote.is_exceed === true || quote.a2b !== aToB || quote.by_amount_in !== true) {
    throw new Error("Cetus returned no executable direct TREE/SUI quote.");
  }
  const minAmountOut = amountOut - amountOut * BigInt(request.slippageBps) / 10000n;
  if (minAmountOut <= 0n) throw new Error("The Cetus minimum output is invalid.");
  return {
    type: "direct",
    venue: "cetus",
    venueLabel: "Cetus V3",
    executionKind: "cetus-v3-direct",
    pairId: CETUS_TREE_POOL_ID,
    tokenIn: request.tokenIn,
    tokenOut: request.tokenOut,
    amountIn: amountIn.toString(),
    amountOut: amountOut.toString(),
    minAmountOut: minAmountOut.toString(),
    priceImpactPercent: priceImpactPercent(amountIn, amountOut, verified.sqrtPrice, aToB),
    priceImpactTier: "verified",
    gasEstimate: "0",
    feePercent: CETUS_TREE_FEE_PERCENT,
    coinAType: verified.coinA,
    coinBType: verified.coinB,
    aToB
  };
}

// netlify/lib/turbos-tree-swap.ts
import { SuiGrpcClient } from "@mysten/sui/grpc";
import { Network, TurbosSdk } from "turbos-clmm-sdk";
var QUOTE_SENDER = "0x0000000000000000000000000000000000000000000000000000000000000001";
var Q64 = 18446744073709552e3;
var client = new SuiGrpcClient({ network: "mainnet", baseUrl: "https://fullnode.mainnet.sui.io:443" });
var sdk = new TurbosSdk(Network.mainnet, client);
function priceImpactPercent2(inputRaw, outputRaw, aToB, sqrtPrice) {
  const sqrt = Number(sqrtPrice);
  if (!Number.isFinite(sqrt) || sqrt <= 0 || inputRaw <= 0n || outputRaw <= 0n) return 0;
  const rawBPerA = (sqrt / Q64) ** 2;
  const idealOutput = aToB ? Number(inputRaw) * rawBPerA : Number(inputRaw) / rawBPerA;
  if (!Number.isFinite(idealOutput) || idealOutput <= 0) return 0;
  return Math.max(0, Math.min(100, (1 - Number(outputRaw) / idealOutput) * 100));
}
async function quoteTurbosTreeSwap(requestInput) {
  const request = validateSwapRequest(requestInput);
  const pool = await sdk.pool.getPool(TURBOS_SUI_TREE_POOL);
  const [coinAType, coinBType] = pool.types;
  const feeType = pool.types[2];
  const expected = /* @__PURE__ */ new Set([normalizeMoveType(SUI_TYPE), normalizeMoveType(TREE_TYPE)]);
  if (!expected.has(normalizeMoveType(coinAType)) || !expected.has(normalizeMoveType(coinBType))) throw new Error("The allowlisted Turbos pool no longer contains SUI/TREE.");
  if (normalizeMoveType(feeType) !== normalizeMoveType(TURBOS_SUI_TREE_FEE_TYPE)) throw new Error("The allowlisted Turbos pool fee type changed.");
  const aToB = normalizeMoveType(request.tokenIn) === normalizeMoveType(coinAType);
  const [result] = await sdk.trade.computeSwapResult({
    pools: [{ pool: TURBOS_SUI_TREE_POOL, a2b: aToB }],
    address: QUOTE_SENDER,
    amountSpecified: request.amountIn,
    amountSpecifiedIsInput: true
  });
  if (!result || result.pool.toLowerCase() !== TURBOS_SUI_TREE_POOL || result.a_to_b !== aToB || result.is_exact_in !== true) throw new Error("Turbos returned an invalid route result.");
  const resultInput = BigInt(aToB ? result.amount_a : result.amount_b);
  const amountOut = BigInt(aToB ? result.amount_b : result.amount_a);
  if (resultInput !== BigInt(request.amountIn) || amountOut <= 0n) throw new Error("Turbos returned no executable output for this amount.");
  const minAmountOut = amountOut - amountOut * BigInt(request.slippageBps) / 10000n;
  const impact = priceImpactPercent2(resultInput, amountOut, aToB, pool.sqrt_price);
  return {
    type: "direct",
    venue: "turbos",
    venueLabel: "Turbos",
    executionKind: "turbos-direct",
    pairId: TURBOS_SUI_TREE_POOL,
    tokenIn: request.tokenIn,
    tokenOut: request.tokenOut,
    amountIn: resultInput.toString(),
    amountOut: amountOut.toString(),
    minAmountOut: minAmountOut.toString(),
    priceImpactPercent: impact,
    priceImpactTier: impact > 5 ? "high" : impact > 1 ? "medium" : "low",
    gasEstimate: "0",
    feePercent: Number(pool.fee) / 1e4,
    coinAType,
    coinBType,
    feeType,
    aToB,
    nextTickIndex: sdk.math.bitsToNumber(result.tick_current_index.bits)
  };
}

// netlify/functions/tree-swap-quote.ts
var UPSTREAM_URL = "https://dex.suidex.org/api/v3/route";
function withTimeout(promise, timeoutMs, message) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(message)), timeoutMs);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}
function json(body, status = 200, cacheControl = "no-store") {
  return Response.json(body, {
    status,
    headers: {
      "Cache-Control": cacheControl,
      "X-Content-Type-Options": "nosniff",
      "X-Robots-Tag": "noindex"
    }
  });
}
var tree_swap_quote_default = async (request) => {
  if (request.method !== "GET") return json({ status: "error", error: "method-not-allowed" }, 405);
  const url = new URL(request.url);
  let validated;
  try {
    validated = validateSwapRequest({
      tokenIn: url.searchParams.get("tokenIn") || "",
      tokenOut: url.searchParams.get("tokenOut") || "",
      amountIn: url.searchParams.get("amountIn") || "",
      slippageBps: Number(url.searchParams.get("slippageBps") || "100")
    });
  } catch (error) {
    return json({ status: "error", error: "invalid-request", message: error instanceof Error ? error.message : "Invalid request." }, 400);
  }
  const upstream = new URL(UPSTREAM_URL);
  upstream.searchParams.set("tokenIn", validated.tokenIn);
  upstream.searchParams.set("tokenOut", validated.tokenOut);
  upstream.searchParams.set("amountIn", validated.amountIn);
  upstream.searchParams.set("slippageBps", String(validated.slippageBps));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12e3);
  try {
    const [suiDexResult, turbosResult, cetusResult] = await Promise.allSettled([
      fetch(upstream, {
        signal: controller.signal,
        cache: "no-store",
        headers: { Accept: "application/json", "User-Agent": "TREE-Command-Center/1.0" }
      }).then(async (response) => {
        if (!response.ok) throw new Error(`SuiDex route service returned ${response.status}.`);
        return response.json();
      }),
      withTimeout(quoteTurbosTreeSwap(validated), 12e3, "The Turbos quote timed out."),
      withTimeout(quoteCetusTreeSwap(validated), 12e3, "The Cetus quote timed out.")
    ]);
    const suiDexPayload = suiDexResult.status === "fulfilled" ? suiDexResult.value : {};
    const additionalRoutes = [
      ...turbosResult.status === "fulfilled" ? [turbosResult.value] : [],
      ...cetusResult.status === "fulfilled" ? [cetusResult.value] : []
    ];
    const normalized = normalizeTreeSwapQuote(suiDexPayload, { ...validated, generatedAt: (/* @__PURE__ */ new Date()).toISOString() }, additionalRoutes);
    if (suiDexResult.status === "rejected") normalized.warnings.push("SuiDex quotes were temporarily unavailable.");
    if (turbosResult.status === "rejected") normalized.warnings.push("The Turbos quote was temporarily unavailable.");
    if (cetusResult.status === "rejected") normalized.warnings.push("The Cetus quote was temporarily unavailable.");
    return json(normalized);
  } catch (error) {
    console.error("TREE swap quote failed", error);
    return json({ status: "error", error: "quote-unavailable", message: "The best-route quote is temporarily unavailable." }, 502);
  } finally {
    clearTimeout(timer);
  }
};
var config = { path: "/api/tree-swap-quote" };
export {
  config,
  tree_swap_quote_default as default
};
