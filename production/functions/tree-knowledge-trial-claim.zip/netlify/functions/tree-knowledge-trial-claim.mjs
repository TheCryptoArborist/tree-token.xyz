
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-raffle-core.ts
var TREE_RAFFLE_RULES_VERSION = "canopy-draw-proposal-v2";
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_RAFFLE_WBTC_TYPE = "0xaafb102dd0902f5055cadecd687fb5b71ca82ef0e0285d90afde828ec58ca96b::btc::BTC";
var TREE_RAFFLE_DAILY_PRIZE = Object.freeze({
  symbol: "TREE",
  coinType: TREE_COIN_TYPE,
  amountRaw: "50000000000",
  decimals: 6
});
var TREE_RAFFLE_DAILY_LUCKY_LEAF_PLAN = Object.freeze({
  symbol: "wBTC",
  coinType: TREE_RAFFLE_WBTC_TYPE,
  decimals: 8,
  mondayThroughSaturdayUsdCents: 250,
  sundayUsdCents: 1e3,
  weeklyBudgetUsdCents: 2500
});
var TREE_RAFFLE_STREAK_MULTIPLIERS_BASIS_POINTS = Object.freeze([
  1e4,
  11e3,
  12500,
  14e3,
  15e3,
  16e3,
  17500,
  18500,
  19500,
  2e4,
  21e3,
  22e3,
  23e3,
  24e3,
  25e3
]);
var TREE_RAFFLE_RULES = Object.freeze({
  version: TREE_RAFFLE_RULES_VERSION,
  status: "development",
  acceptingEntries: false,
  claimsEnabled: false,
  prizesFunded: false,
  dailyEnabled: true,
  dailyLuckyLeafEnabled: false,
  weeklyEnabled: false,
  minimumQualifyingUsdCents: 500,
  ticketExponent: 0.9457,
  ticketCoefficient: 0.288368,
  luckyLeafTicketsPerQualifyingTransaction: 1,
  maxStreakDays: 15,
  maxStreakMultiplierBasisPoints: 25e3,
  streakMultipliersBasisPoints: TREE_RAFFLE_STREAK_MULTIPLIERS_BASIS_POINTS,
  milestoneBonusUsdCents: Object.freeze({ 7: 5e3, 15: 2e4 }),
  schedule: Object.freeze({
    timezone: "America/New_York",
    daily: "10:00",
    weekly: "Sunday 10:05"
  }),
  prizes: Object.freeze({
    dailyMain: TREE_RAFFLE_DAILY_PRIZE,
    dailyLuckyLeafPlan: TREE_RAFFLE_DAILY_LUCKY_LEAF_PLAN,
    weeklyMain: null,
    weeklyLuckyLeaf: null
  }),
  eligibleTransaction: Object.freeze({
    network: "sui-mainnet",
    direction: "SUI_TO_TREE",
    requiresSuccessfulFinalizedTransaction: true,
    allowlistedRoutesRequired: true
  })
});

// netlify/lib/tree-raffle-sui-draw.ts
var SUI_ID = /^0x[0-9a-fA-F]{1,64}$/;
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var SUI_DIGEST = /^[1-9A-HJ-NP-Za-km-z]{40,64}$/;
var U64_MAX = 18446744073709551615n;
function suiId(value, label) {
  if (!SUI_ID.test(value)) throw new Error(`Invalid TREE raffle ${label}.`);
  return value.toLowerCase();
}
function u64(value, label) {
  if (!/^(0|[1-9][0-9]*)$/.test(value)) throw new Error(`Invalid TREE raffle ${label}.`);
  const parsed = BigInt(value);
  if (parsed > U64_MAX) throw new Error(`Invalid TREE raffle ${label}.`);
  return parsed;
}
function byteArray(value, label) {
  if (Array.isArray(value) && !value.some((byte) => !Number.isInteger(byte) || byte < 0 || byte > 255)) {
    return value;
  }
  if (typeof value === "string" && value.length > 0 && value.length % 4 === 0 && /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) {
    try {
      return [...atob(value)].map((character) => character.charCodeAt(0));
    } catch {
    }
  }
  throw new Error(`Sui returned an invalid TREE raffle ${label}.`);
}
function normalizedSuiId(value) {
  return `0x${value.slice(2).toLowerCase().replace(/^0+/, "") || "0"}`;
}
function verifyTreeRaffleClaimTransaction(input) {
  const tx = input.transaction;
  const digest = tx?.digest ?? tx?.transaction?.digest;
  const status = tx?.effects?.status?.status ?? tx?.effects?.status ?? tx?.transaction?.effects?.status?.status;
  if (!SUI_DIGEST.test(String(digest || "")) || status !== "success") {
    throw new Error("TREE raffle claim transaction did not finalize successfully.");
  }
  if (!SUI_ADDRESS.test(input.wallet) || !input.tokenType.includes("::")) {
    throw new Error("Invalid TREE raffle expected claim values.");
  }
  const expectedAmount = u64(input.amountRaw, "prize amount");
  const packageId = normalizedSuiId(suiId(input.packageId, "package ID"));
  const events = Array.isArray(tx?.events) ? tx.events : [];
  const matches = events.filter((event2) => {
    const type = String(event2?.type || "");
    const separator = type.indexOf("::");
    if (separator < 0) return false;
    const eventPackage = type.slice(0, separator);
    return SUI_ID.test(eventPackage) && normalizedSuiId(eventPackage) === packageId && type.slice(separator) === `::prize_pool::PrizeClaimed<${input.tokenType}>`;
  });
  if (matches.length !== 1) throw new Error("Sui returned an invalid TREE raffle claim event count.");
  const event = matches[0].json ?? matches[0].parsedJson;
  if (!event || typeof event !== "object") throw new Error("Sui returned malformed TREE raffle claim data.");
  const drawId = new TextDecoder().decode(Uint8Array.from(byteArray(event.draw_id, "claim draw ID")));
  const amount = u64(String(event.amount), "claimed amount");
  if (drawId !== input.onchainDrawId || String(event.winner).toLowerCase() !== input.wallet || amount !== expectedAmount) {
    throw new Error("Sui TREE raffle claim event does not match the recorded prize.");
  }
  return { digest: String(digest), wallet: input.wallet, amountRaw: amount.toString() };
}

// netlify/lib/tree-raffle-claim.ts
var SUI_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var SUI_ADDRESS2 = /^0x[0-9a-f]{64}$/;
var SUI_DIGEST2 = /^[1-9A-HJ-NP-Za-km-z]{40,64}$/;
var TREE_RAFFLE_CLAIM_QUERY = `query TreeRaffleClaim($digest: String!) {
  transaction(digest: $digest) {
    digest
    sender { address }
    effects {
      status
      events(first: 10) {
        pageInfo { hasNextPage }
        nodes { contents { type { repr } json } }
      }
    }
  }
}`;
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
async function fetchFinalizedTreeRaffleClaim(digest, options = {}) {
  if (!SUI_DIGEST2.test(digest)) throw new Error("A valid Sui transaction digest is required.");
  const response = await (options.fetchImpl ?? fetch)(options.endpoint ?? SUI_GRAPHQL_URL, {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ query: TREE_RAFFLE_CLAIM_QUERY, variables: { digest } }),
    signal: AbortSignal.timeout(options.timeoutMs ?? 8e3)
  });
  if (!response.ok) throw new Error(`Sui claim verification returned ${response.status}.`);
  const payload = record(await response.json());
  if (Array.isArray(payload.errors) && payload.errors.length) throw new Error("Sui claim verification returned a GraphQL error.");
  const transaction = record(record(payload.data).transaction);
  const effects = record(transaction.effects);
  const events = record(effects.events);
  const sender = String(record(transaction.sender).address || "").toLowerCase();
  if (transaction.digest !== digest || !SUI_ADDRESS2.test(sender) || String(effects.status || "").toLowerCase() !== "success" || record(events.pageInfo).hasNextPage === true || !Array.isArray(events.nodes)) {
    throw new Error("The Sui raffle claim was not found, successful, or complete.");
  }
  const parsedEvents = events.nodes.map((node) => {
    const contents = record(record(node).contents);
    return { type: String(record(contents.type).repr || ""), json: record(contents.json) };
  });
  return { digest, sender, effects: { status: "success" }, events: parsedEvents };
}

// netlify/lib/tree-knowledge-trial-supabase.ts
function record2(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function required(value, label) {
  const normalized = value?.trim();
  if (!normalized) throw new Error(`${label} is not configured.`);
  return normalized;
}
function treeKnowledgeTrialSupabaseConfig(env) {
  const rawUrl = env.TREE_KNOWLEDGE_TRIAL_SUPABASE_URL || env.TREE_RAFFLE_SUPABASE_URL;
  const rawKey = env.TREE_KNOWLEDGE_TRIAL_SUPABASE_SECRET_KEY || env.TREE_RAFFLE_SUPABASE_SECRET_KEY;
  const url = required(rawUrl, "TREE_KNOWLEDGE_TRIAL_SUPABASE_URL");
  const secretKey = required(rawKey, "TREE_KNOWLEDGE_TRIAL_SUPABASE_SECRET_KEY");
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error("TREE_KNOWLEDGE_TRIAL_SUPABASE_URL must be a valid HTTPS URL.");
  }
  if (parsed.protocol !== "https:") throw new Error("TREE_KNOWLEDGE_TRIAL_SUPABASE_URL must use HTTPS.");
  return { url: parsed.origin, secretKey };
}
function text(value, label) {
  if (typeof value !== "string" || !value.trim()) throw new Error(`Supabase returned an invalid ${label}.`);
  return value;
}
function boolean(value, label) {
  if (typeof value !== "boolean") throw new Error(`Supabase returned an invalid ${label}.`);
  return value;
}
function integer(value, label) {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 1) throw new Error(`Supabase returned an invalid ${label}.`);
  return parsed;
}
function parseChallenge(value) {
  const row = record2(value);
  return {
    challengeId: text(row.challengeId, "challenge ID"),
    roundId: text(row.roundId, "round ID"),
    wallet: text(row.wallet, "challenge wallet"),
    qualifyingTxDigest: text(row.qualifyingTxDigest, "qualifying transaction digest"),
    message: text(row.message, "wallet challenge message"),
    expiresAt: text(row.expiresAt, "challenge expiration"),
    consumed: boolean(row.consumed, "challenge consumption state")
  };
}
function parseAttemptContext(value) {
  const row = record2(value);
  return {
    attemptId: text(row.attemptId, "attempt ID"),
    roundId: text(row.roundId, "attempt round ID"),
    wallet: text(row.wallet, "attempt wallet"),
    questionSetVersion: text(row.questionSetVersion, "question-set version"),
    startedAt: text(row.startedAt, "attempt start time"),
    expiresAt: text(row.expiresAt, "attempt expiration"),
    submitted: boolean(row.submitted, "attempt submission state")
  };
}
function parseTiebreakChallenge(value) {
  const row = record2(value);
  return {
    challengeId: text(row.challengeId, "sudden-death challenge ID"),
    roundId: text(row.roundId, "sudden-death round ID"),
    wallet: text(row.wallet, "sudden-death wallet"),
    stage: integer(row.stage, "sudden-death stage"),
    message: text(row.message, "sudden-death wallet challenge message"),
    expiresAt: text(row.expiresAt, "sudden-death challenge expiration"),
    consumed: boolean(row.consumed, "sudden-death challenge consumption state")
  };
}
function parseTiebreakAttemptContext(value) {
  const row = record2(value);
  return {
    attemptId: text(row.attemptId, "sudden-death attempt ID"),
    roundId: text(row.roundId, "sudden-death attempt round ID"),
    wallet: text(row.wallet, "sudden-death attempt wallet"),
    stage: integer(row.stage, "sudden-death attempt stage"),
    startedAt: text(row.startedAt, "sudden-death attempt start time"),
    expiresAt: text(row.expiresAt, "sudden-death attempt expiration"),
    submitted: boolean(row.submitted, "sudden-death attempt submission state")
  };
}
var SupabaseTreeKnowledgeTrialStore = class {
  config;
  fetchImpl;
  constructor(config2, fetchImpl = fetch) {
    this.config = config2;
    this.fetchImpl = fetchImpl;
  }
  async rpc(name, body, timeoutMs = 7500) {
    const response = await this.fetchImpl(`${this.config.url}/rest/v1/rpc/${name}`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.config.secretKey}`,
        apikey: this.config.secretKey,
        "X-Client-Info": "tree-command-center-knowledge-trial/1"
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs)
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok) {
      const message = typeof record2(payload).message === "string" ? String(record2(payload).message) : `Supabase Knowledge Trial request failed with HTTP ${response.status}.`;
      throw new Error(message);
    }
    return payload;
  }
  async publicSnapshot() {
    const value = record2(await this.rpc("read_tree_knowledge_trial_public_snapshot_v1", {}));
    if (value.round !== null && (!value.round || typeof value.round !== "object")) {
      throw new Error("Supabase returned an invalid Knowledge Trial round snapshot.");
    }
    if (!Array.isArray(value.leaderboard)) throw new Error("Supabase returned an invalid Knowledge Trial leaderboard.");
    return { round: value.round, leaderboard: value.leaderboard, submissionCount: Number(value.submissionCount || 0) };
  }
  async createChallenge(input) {
    return parseChallenge(await this.rpc("create_tree_knowledge_trial_wallet_challenge_v1", {
      p_round_id: input.roundId,
      p_wallet: input.wallet,
      p_qualifying_tx_digest: input.qualifyingTxDigest,
      p_nonce_sha256: input.nonceSha256,
      p_message_prefix: input.messagePrefix,
      p_request_fingerprint: input.requestFingerprint,
      p_expires_at: input.expiresAt
    }));
  }
  async readChallenge(challengeId) {
    return parseChallenge(await this.rpc("read_tree_knowledge_trial_wallet_challenge_v1", {
      p_challenge_id: challengeId
    }));
  }
  async consumeChallenge(challengeId, wallet, roundId) {
    return parseChallenge(await this.rpc("consume_tree_knowledge_trial_wallet_challenge_v1", {
      p_challenge_id: challengeId,
      p_wallet: wallet,
      p_round_id: roundId
    }));
  }
  async issuePass(roundId, wallet, qualifyingTxDigest) {
    return record2(await this.rpc("issue_tree_knowledge_trial_pass_v1", {
      p_round_id: roundId,
      p_wallet: wallet,
      p_qualifying_tx_digest: qualifyingTxDigest
    }));
  }
  async startAttempt(roundId, wallet, attemptTokenSha256) {
    return parseAttemptContext(await this.rpc("start_tree_knowledge_trial_attempt_v2", {
      p_round_id: roundId,
      p_wallet: wallet,
      p_attempt_token_sha256: attemptTokenSha256
    }));
  }
  async readAttempt(attemptTokenSha256) {
    return parseAttemptContext(await this.rpc("read_tree_knowledge_trial_attempt_context_v1", {
      p_attempt_token_sha256: attemptTokenSha256
    }));
  }
  async questionSet(questionSetVersion) {
    const value = record2(await this.rpc("read_tree_knowledge_trial_question_set_v1", {
      p_question_set_version: questionSetVersion
    }));
    return value.questions;
  }
  async submitAttempt(attemptTokenSha256, answers, correctCount) {
    return record2(await this.rpc("submit_tree_knowledge_trial_attempt_v2", {
      p_attempt_token_sha256: attemptTokenSha256,
      p_answers: answers,
      p_correct_count: correctCount
    }));
  }
  async createTiebreakChallenge(input) {
    return parseTiebreakChallenge(await this.rpc("create_tree_knowledge_trial_tiebreak_challenge_v1", {
      p_round_id: input.roundId,
      p_wallet: input.wallet,
      p_nonce_sha256: input.nonceSha256,
      p_message: input.message,
      p_request_fingerprint: input.requestFingerprint,
      p_expires_at: input.expiresAt
    }));
  }
  async readTiebreakChallenge(challengeId) {
    return parseTiebreakChallenge(await this.rpc("read_tree_knowledge_trial_tiebreak_challenge_v1", {
      p_challenge_id: challengeId
    }));
  }
  async consumeTiebreakChallenge(challengeId, wallet, roundId, stage) {
    return parseTiebreakChallenge(await this.rpc("consume_tree_knowledge_trial_tiebreak_challenge_v1", {
      p_challenge_id: challengeId,
      p_wallet: wallet,
      p_round_id: roundId,
      p_stage: stage
    }));
  }
  async startTiebreakAttempt(roundId, wallet, stage, attemptTokenSha256) {
    return parseTiebreakAttemptContext(await this.rpc("start_tree_knowledge_trial_tiebreak_attempt_v1", {
      p_round_id: roundId,
      p_wallet: wallet,
      p_stage: stage,
      p_attempt_token_sha256: attemptTokenSha256
    }));
  }
  async readTiebreakAttempt(attemptTokenSha256) {
    return parseTiebreakAttemptContext(await this.rpc("read_tree_knowledge_trial_tiebreak_attempt_context_v1", {
      p_attempt_token_sha256: attemptTokenSha256
    }));
  }
  async tiebreakQuestion(roundId, stage) {
    return record2(await this.rpc("read_tree_knowledge_trial_tiebreak_question_v1", {
      p_round_id: roundId,
      p_stage: stage
    }));
  }
  async submitTiebreakAttempt(attemptTokenSha256, selectedOptionId) {
    return record2(await this.rpc("submit_tree_knowledge_trial_tiebreak_attempt_v1", {
      p_attempt_token_sha256: attemptTokenSha256,
      p_selected_option_id: selectedOptionId
    }));
  }
  async prepareDraft(input) {
    return record2(await this.rpc("prepare_tree_knowledge_trial_round_v1", {
      p_round_id: input.roundId,
      p_question_set_version: input.questionSetVersion,
      p_questions: input.questions,
      p_tiebreak_questions: input.tiebreakQuestions,
      p_purchase_window_opens_at: input.purchaseWindowOpensAt,
      p_purchase_window_closes_at: input.purchaseWindowClosesAt,
      p_challenge_opens_at: input.challengeOpensAt,
      p_challenge_closes_at: input.challengeClosesAt,
      p_prize_token_type: input.prizeTokenType,
      p_prize_amount_raw: input.prizeAmountRaw,
      p_request_sha256: input.requestSha256
    }));
  }
  async readDraftSetup(roundId) {
    const value = await this.rpc("read_tree_knowledge_trial_round_setup_v1", {
      p_round_id: roundId
    });
    return value === null ? null : record2(value);
  }
  async scheduleRound(roundId) {
    return record2(await this.rpc("schedule_tree_knowledge_trial_round_v1", {
      p_round_id: roundId
    }));
  }
  async resolveRound(roundId) {
    return record2(await this.rpc("resolve_tree_knowledge_trial_round_v2", {
      p_round_id: roundId
    }));
  }
  async readAward(roundId, wallet) {
    const value = await this.rpc("read_tree_knowledge_trial_award_v1", {
      p_round_id: roundId,
      p_wallet: wallet
    });
    return value === null ? null : record2(value);
  }
  async recordClaim(roundId, wallet, claimTxDigest) {
    return record2(await this.rpc("record_tree_knowledge_trial_claim_v1", {
      p_round_id: roundId,
      p_wallet: wallet,
      p_claim_tx_digest: claimTxDigest
    }));
  }
};
function configuredSupabaseTreeKnowledgeTrialStore(env, fetchImpl = fetch) {
  return new SupabaseTreeKnowledgeTrialStore(treeKnowledgeTrialSupabaseConfig(env), fetchImpl);
}

// netlify/lib/tree-knowledge-trial-claim.ts
var SUI_ADDRESS3 = /^0x[0-9a-f]{64}$/;
var SUI_DIGEST3 = /^[1-9A-HJ-NP-Za-km-z]{40,64}$/;
var ROUND_ID = /^knowledge:[0-9]{4}-[0-9]{2}-[0-9]{2}$/;
function json(body, status = 200) {
  return Response.json(body, {
    status,
    headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "X-Robots-Tag": "noindex" }
  });
}
function parseAward(value, roundId, wallet) {
  if (!value || value.roundId !== roundId || value.wallet !== wallet || typeof value.onchainDrawId !== "string" || typeof value.tokenType !== "string" || !value.tokenType.includes("::") || typeof value.amountRaw !== "string" || !/^[1-9][0-9]*$/.test(value.amountRaw) || typeof value.claimed !== "boolean") return null;
  return value;
}
function createTreeKnowledgeTrialClaimHandler(dependencies = {}) {
  const env = dependencies.env ?? process.env;
  return async (request) => {
    if (request.method !== "POST") return json({ status: "error", error: "method-not-allowed" }, 405);
    const enabled = dependencies.allowClaims ?? (env.TREE_KNOWLEDGE_TRIAL_CLAIMS_ENABLED === "true" && env.TREE_KNOWLEDGE_TRIAL_PRIZE_SETTLEMENT_READY === "true" && Boolean(env.TREE_RAFFLE_PACKAGE_ID?.trim()) && Boolean(env.TREE_RAFFLE_PRIZE_POOL_ID?.trim()));
    if (!enabled) return json({ status: "disabled", error: "knowledge-trial-claims-disabled" }, 503);
    let digest = "";
    let wallet = "";
    let roundId = "";
    try {
      const body = await request.json();
      if (!body || typeof body !== "object" || Array.isArray(body) || Object.keys(body).length !== 3 || typeof body.digest !== "string" || typeof body.wallet !== "string" || typeof body.roundId !== "string") throw new Error("invalid");
      digest = body.digest.trim();
      wallet = body.wallet.trim().toLowerCase();
      roundId = body.roundId.trim();
      if (!SUI_DIGEST3.test(digest) || !SUI_ADDRESS3.test(wallet) || !ROUND_ID.test(roundId)) throw new Error("invalid");
    } catch {
      return json({ status: "error", error: "invalid-request" }, 400);
    }
    try {
      const store = !dependencies.readAward || !dependencies.recordClaim ? configuredSupabaseTreeKnowledgeTrialStore(env) : null;
      const award = parseAward(await (dependencies.readAward ? dependencies.readAward(roundId, wallet) : store.readAward(roundId, wallet)), roundId, wallet);
      if (!award || award.claimed) return json({ status: "error", error: "award-not-claimable" }, 404);
      const transaction = await (dependencies.fetchClaim ?? fetchFinalizedTreeRaffleClaim)(digest);
      if (transaction.sender !== wallet) throw new Error("The claim sender does not match the Knowledge Trial winner.");
      const verified = verifyTreeRaffleClaimTransaction({
        transaction,
        packageId: env.TREE_RAFFLE_PACKAGE_ID || "",
        onchainDrawId: award.onchainDrawId,
        wallet,
        tokenType: award.tokenType,
        amountRaw: award.amountRaw
      });
      const recorded = await (dependencies.recordClaim ? dependencies.recordClaim(roundId, wallet, verified.digest) : store.recordClaim(roundId, wallet, verified.digest));
      return json({ status: "ok", roundId, wallet, digest: verified.digest, ...recorded });
    } catch (error) {
      console.error("TREE Knowledge Trial prize claim reconciliation failed", error);
      return json({
        status: "error",
        error: "verification-failed",
        message: "The finalized Knowledge Trial prize claim could not be independently verified and recorded."
      }, 422);
    }
  };
}

// netlify/functions/tree-knowledge-trial-claim.ts
var ENVIRONMENT_KEYS = [
  "TREE_KNOWLEDGE_TRIAL_CLAIMS_ENABLED",
  "TREE_KNOWLEDGE_TRIAL_PRIZE_SETTLEMENT_READY",
  "TREE_KNOWLEDGE_TRIAL_SUPABASE_URL",
  "TREE_KNOWLEDGE_TRIAL_SUPABASE_SECRET_KEY",
  "TREE_RAFFLE_SUPABASE_URL",
  "TREE_RAFFLE_SUPABASE_SECRET_KEY",
  "TREE_RAFFLE_PACKAGE_ID",
  "TREE_RAFFLE_PRIZE_POOL_ID"
];
function runtimeEnvironment() {
  const netlify = globalThis.Netlify;
  return Object.fromEntries(ENVIRONMENT_KEYS.map((key) => [
    key,
    netlify?.env?.get?.(key) ?? process.env[key]
  ]));
}
var tree_knowledge_trial_claim_default = (request) => createTreeKnowledgeTrialClaimHandler({
  env: runtimeEnvironment()
})(request);
var config = { path: "/api/tree-knowledge-trial-claim" };
export {
  config,
  tree_knowledge_trial_claim_default as default
};
