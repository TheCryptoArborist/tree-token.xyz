
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/production-snapshot-preview.ts
function json(value, status = 200, cache = "no-store") {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": cache
    }
  });
}
async function proxyProductionSnapshotForPreview(request, context, productionUrl, label, dependencies = {}) {
  if (request.method !== "GET") return json({ status: "error", message: "Method not allowed." }, 405);
  if (context?.deploy?.context !== "deploy-preview") return json({ status: "error", message: "Not found." }, 404);
  const fetchImpl = dependencies.fetchImpl || fetch;
  try {
    const response = await fetchImpl(productionUrl, { headers: { Accept: "application/json" } });
    if (!response.ok) return json({ status: "error", message: `Production ${label} snapshot is unavailable.` }, 502);
    const payload = await response.json();
    return json({
      ...payload,
      previewSource: "production-complete-snapshot",
      previewMessage: `Deploy Preview is displaying the current public production ${label} snapshot for review.`,
      warnings: [
        ...Array.isArray(payload.warnings) ? payload.warnings : [],
        `Deploy Preview is displaying the current public production ${label} snapshot for review.`
      ]
    }, 200, "public, max-age=60, s-maxage=120");
  } catch {
    return json({ status: "error", message: `Production ${label} preview proxy failed.` }, 502);
  }
}

// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));
function normalizeSuiAddress(value) {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  return SUI_ADDRESS.test(normalized) ? normalized : null;
}

// netlify/lib/suins-name-resolver.ts
var DEFAULT_SUINS_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var MAX_SUINS_NAMES_PER_REQUEST = 50;
var MAX_SUINS_NAMES_PER_GRAPHQL_BATCH = 20;
var DEFAULT_SUINS_CONCURRENCY = 8;
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function safeName(value) {
  if (typeof value !== "string") return null;
  const name = value.trim();
  if (!name || name.length > 255 || /[\u0000-\u001f\u007f]/.test(name)) return null;
  return name;
}
function errorMessage(error) {
  return error instanceof Error ? error.message : String(error || "Unknown SuiNS resolution error");
}
function isExpectedMissingName(error) {
  const source = error && typeof error === "object" ? error : {};
  if (source.code === 5 || source.status === 5 || source.code === "NOT_FOUND" || source.status === "NOT_FOUND") return true;
  const rawMessage = errorMessage(error).toLowerCase();
  let message = rawMessage;
  try {
    message = decodeURIComponent(rawMessage.replace(/\+/g, " "));
  } catch {
  }
  return message.includes("not_found") || message.includes("not found") || message.includes("name has expired") || message.includes("name does not exist");
}
function withTimeout(promise, timeoutMs) {
  if (timeoutMs <= 0) return Promise.reject(new Error("SuiNS resolution timed out."));
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("SuiNS resolution timed out.")), timeoutMs);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}
function graphqlErrors(value) {
  if (!Array.isArray(value)) return [];
  return value.map((item) => {
    const message = record(item).message;
    return typeof message === "string" && message ? message : "Unknown SuiNS GraphQL error";
  });
}
function buildDefaultSuinsQuery(addresses) {
  const definitions = addresses.map((_, index) => `$address${index}: SuiAddress!`).join(", ");
  const fields = addresses.map((_, index) => `name${index}: address(address: $address${index}) { defaultNameRecord { domain } }`).join("\n");
  return {
    query: `query ResolveDefaultSuinsNames(${definitions}) {
${fields}
}`,
    variables: Object.fromEntries(addresses.map((address, index) => [`address${index}`, address]))
  };
}
async function resolveWithGraphql(normalized, names, options) {
  const controller = new AbortController();
  const externalAbort = () => controller.abort();
  options.abortSignal?.addEventListener("abort", externalAbort, { once: true });
  if (options.abortSignal?.aborted) controller.abort();
  const timeout = setTimeout(() => controller.abort(), Math.max(1e3, options.timeoutMs ?? 15e3));
  let networkError = null;
  const errors = [];
  try {
    const batches = Array.from(
      { length: Math.ceil(normalized.length / MAX_SUINS_NAMES_PER_GRAPHQL_BATCH) },
      (_, index) => normalized.slice(
        index * MAX_SUINS_NAMES_PER_GRAPHQL_BATCH,
        (index + 1) * MAX_SUINS_NAMES_PER_GRAPHQL_BATCH
      )
    );
    const results = await Promise.all(batches.map(async (batch) => {
      const response = await (options.fetchImpl || fetch)(options.endpoint || DEFAULT_SUINS_GRAPHQL_URL, {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify(buildDefaultSuinsQuery(batch)),
        signal: controller.signal
      });
      if (!response.ok) return { errors: [], networkError: `SuiNS GraphQL returned HTTP ${response.status}` };
      const payload = record(await response.json());
      const batchErrors = graphqlErrors(payload.errors);
      const data = record(payload.data);
      batch.forEach((address, index) => {
        const nameRecord = record(record(data[`name${index}`]).defaultNameRecord);
        names[address] = safeName(nameRecord.domain);
      });
      return { errors: batchErrors, networkError: null };
    }));
    results.forEach((result) => {
      errors.push(...result.errors);
      networkError ||= result.networkError;
    });
  } catch (error) {
    networkError = controller.signal.aborted ? "SuiNS resolution timed out." : errorMessage(error);
  } finally {
    clearTimeout(timeout);
    options.abortSignal?.removeEventListener("abort", externalAbort);
  }
  return { errors, networkError };
}
async function resolveWithInjectedClient(normalized, names, options) {
  const now = options.now ?? Date.now;
  const client = options.client ?? options.clientFactory?.(options.endpoint || DEFAULT_SUINS_GRAPHQL_URL);
  if (!client) return { errors: ["SuiNS client is unavailable."], networkError: "SuiNS client is unavailable." };
  const deadline = now() + Math.max(1e3, options.timeoutMs ?? 15e3);
  const concurrency = Math.max(1, Math.min(16, Math.trunc(options.concurrency ?? DEFAULT_SUINS_CONCURRENCY)));
  const unexpectedErrors = [];
  let cursor = 0;
  async function worker() {
    while (cursor < normalized.length) {
      if (options.abortSignal?.aborted) {
        unexpectedErrors.push("SuiNS resolution aborted.");
        return;
      }
      const current = cursor;
      cursor += 1;
      const address = normalized[current];
      try {
        const response = await withTimeout(client.core.defaultNameServiceName({ address }), deadline - now());
        let name = safeName(response?.name);
        if (!name && client.nameService?.reverseLookupName) {
          const reverse = await withTimeout(client.nameService.reverseLookupName({ address }), deadline - now());
          name = safeName(reverse?.response?.record?.name);
        }
        names[address] = name;
      } catch (error) {
        if (isExpectedMissingName(error)) {
          names[address] = null;
          continue;
        }
        unexpectedErrors.push(errorMessage(error));
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, normalized.length) }, () => worker()));
  const errors = [...new Set(unexpectedErrors)].slice(0, 10);
  return { errors, networkError: errors[0] || null };
}
async function resolveDefaultSuinsNames(addresses, options = {}) {
  const normalized = [...new Set(addresses.map(normalizeSuiAddress).filter((value) => Boolean(value)))].slice(0, MAX_SUINS_NAMES_PER_REQUEST);
  const names = Object.fromEntries(normalized.map((address) => [address, null]));
  const now = options.now ?? Date.now;
  const generatedAt = new Date(now()).toISOString();
  if (!normalized.length) {
    return { names, requestedCount: 0, resolvedCount: 0, complete: true, graphqlErrors: [], networkError: null, generatedAt };
  }
  const result = options.client || options.clientFactory ? await resolveWithInjectedClient(normalized, names, options) : await resolveWithGraphql(normalized, names, options);
  const resolvedCount = Object.values(names).filter(Boolean).length;
  const errors = [...result.errors];
  if (normalized.length >= 10 && resolvedCount === 0 && errors.length === 0 && !result.networkError) {
    errors.push(`SuiNS reverse lookup returned zero names for ${normalized.length} addresses.`);
  }
  const uniqueErrors = [...new Set(errors)].slice(0, 10);
  const networkError = result.networkError || uniqueErrors[0] || null;
  return {
    names,
    requestedCount: normalized.length,
    resolvedCount,
    complete: !networkError && uniqueErrors.length === 0,
    graphqlErrors: uniqueErrors,
    networkError,
    generatedAt
  };
}

// netlify/functions/tree-exposure-preview.ts
function json2(value, status = 200, cache = "no-store") {
  return new Response(JSON.stringify(value), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": cache }
  });
}
async function handleTreeExposurePreviewRequest(request, context, dependencies = {}) {
  const response = await proxyProductionSnapshotForPreview(
    request,
    context,
    "https://tree-token.xyz/api/tree-exposure",
    "TREE exposure",
    { fetchImpl: dependencies.fetchImpl }
  );
  if (!response.ok) return response;
  const payload = await response.json();
  const entries = Array.isArray(payload.entries) ? payload.entries : [];
  if (!entries.length) return json2(payload, 200, "public, max-age=60, s-maxage=120");
  try {
    const resolveNames = dependencies.resolveNames || resolveDefaultSuinsNames;
    const resolution = await resolveNames(entries.map((entry) => String(entry.wallet || "")));
    const enriched = entries.map((entry) => {
      const wallet = String(entry.wallet || "").toLowerCase();
      return { ...entry, suinsName: resolution.names[wallet] || null };
    });
    return json2({
      ...payload,
      entries: enriched,
      identityResolution: {
        provider: "sui-graphql-default-name-record",
        requestedCount: resolution.requestedCount,
        resolvedCount: resolution.resolvedCount,
        complete: resolution.complete,
        generatedAt: resolution.generatedAt
      },
      warnings: [
        ...Array.isArray(payload.warnings) ? payload.warnings : [],
        ...!resolution.complete ? ["Some SuiNS identities could not be resolved for this preview."] : []
      ]
    }, 200, resolution.complete ? "public, max-age=120, s-maxage=300" : "no-store");
  } catch {
    return json2({
      ...payload,
      entries,
      warnings: [
        ...Array.isArray(payload.warnings) ? payload.warnings : [],
        "SuiNS identity enrichment was unavailable for this preview."
      ]
    });
  }
}
var tree_exposure_preview_default = async (request, context) => handleTreeExposurePreviewRequest(request, context);
var config = { path: "/api/tree-exposure-preview" };
export {
  config,
  tree_exposure_preview_default as default,
  handleTreeExposurePreviewRequest
};
