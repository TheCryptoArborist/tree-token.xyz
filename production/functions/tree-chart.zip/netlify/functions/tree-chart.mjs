
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/coingecko-market.ts
function coinGeckoRequestConfig(config2 = {}) {
  const apiKey = (config2.apiKey || "").trim();
  const pro = (config2.plan || "").trim().toLowerCase() === "pro";
  const headers = { Accept: "application/json" };
  if (apiKey) headers[pro ? "x-cg-pro-api-key" : "x-cg-demo-api-key"] = apiKey;
  return {
    baseUrl: pro ? "https://pro-api.coingecko.com/api/v3" : "https://api.coingecko.com/api/v3",
    headers
  };
}

// netlify/lib/tree-chart-cache.ts
import { getStore } from "@netlify/blobs";
var STORE_NAME = "tree-market-charts";
var keyFor = (range, pair) => `last-success-v1:${range}:${pair}`;
function defaultStore() {
  return getStore(STORE_NAME, { consistency: "strong" });
}
function validCachedTreeChart(value) {
  if (!value || typeof value !== "object") return false;
  const chart = value;
  return Number.isFinite(Date.parse(chart.generatedAt)) && typeof chart.source === "string" && ["1h", "24h", "7d", "30d", "all"].includes(chart.range) && ["usd", "sui"].includes(chart.pair) && Array.isArray(chart.candles) && chart.candles.length > 1 && chart.candles.every((candle) => [candle.timestamp, candle.open, candle.high, candle.low, candle.close, candle.volume].every(Number.isFinite) && candle.timestamp > 0 && candle.open > 0 && candle.high > 0 && candle.low > 0 && candle.close > 0 && candle.volume >= 0);
}
async function readCachedTreeChart(range, pair, store = defaultStore()) {
  const value = await store.get(keyFor(range, pair), { type: "json" });
  return validCachedTreeChart(value) && value.range === range && value.pair === pair ? value : null;
}
async function writeCachedTreeChart(chart, store = defaultStore()) {
  if (!validCachedTreeChart(chart)) return false;
  await store.setJSON(keyFor(chart.range, chart.pair), chart);
  return true;
}

// netlify/functions/tree-chart.ts
var RANGE_CONFIG = {
  "1h": { limit: 60, days: 1 },
  "24h": { limit: 96, days: 1 },
  "7d": { limit: 168, days: 7 },
  "30d": { limit: 180, days: 30 },
  "all": { limit: 1e3, days: 365 }
};
function sampleChartCandles(candles, limit) {
  if (candles.length <= limit) return candles;
  const step = Math.ceil(candles.length / limit);
  const sampled = candles.filter((_, index) => index % step === 0);
  const last = candles.at(-1);
  if (last && sampled.at(-1)?.timestamp !== last.timestamp) sampled.push(last);
  return sampled.slice(-limit);
}
function normalizeCoinGeckoCandles(payload, limit) {
  const root = payload && typeof payload === "object" ? payload : {};
  const prices = Array.isArray(root.prices) ? root.prices : [];
  const volumes = new Map((Array.isArray(root.total_volumes) ? root.total_volumes : []).flatMap((row) => {
    if (!Array.isArray(row) || row.length < 2) return [];
    const timestamp = Number(row[0]);
    const volume = Number(row[1]);
    return Number.isFinite(timestamp) && Number.isFinite(volume) ? [[timestamp, volume]] : [];
  }));
  const candles = prices.flatMap((row) => {
    if (!Array.isArray(row) || row.length < 2) return [];
    const timestamp = Number(row[0]);
    const price = Number(row[1]);
    if (!Number.isFinite(timestamp) || !Number.isFinite(price) || price <= 0) return [];
    return [{ timestamp, open: price, high: price, low: price, close: price, volume: volumes.get(timestamp) || 0 }];
  }).sort((a, b) => a.timestamp - b.timestamp);
  return sampleChartCandles(candles, limit);
}
function normalizeSuiPairCandles(treePayload, suiPayload, limit) {
  const treeCandles = normalizeCoinGeckoCandles(treePayload, Number.MAX_SAFE_INTEGER);
  const suiPrices = normalizeCoinGeckoCandles(suiPayload, Number.MAX_SAFE_INTEGER);
  if (!treeCandles.length || !suiPrices.length) return [];
  let suiIndex = 0;
  return sampleChartCandles(treeCandles.flatMap((treeCandle) => {
    while (suiIndex + 1 < suiPrices.length && Math.abs(suiPrices[suiIndex + 1].timestamp - treeCandle.timestamp) <= Math.abs(suiPrices[suiIndex].timestamp - treeCandle.timestamp)) suiIndex += 1;
    const suiUsd = Number(suiPrices[suiIndex]?.close);
    if (!Number.isFinite(suiUsd) || suiUsd <= 0) return [];
    return [{ ...treeCandle, open: treeCandle.open / suiUsd, high: treeCandle.high / suiUsd, low: treeCandle.low / suiUsd, close: treeCandle.close / suiUsd }];
  }), limit);
}
async function coinGeckoPayload(coinId, days, apiKey, plan) {
  const config2 = coinGeckoRequestConfig({ apiKey, plan });
  const url = new URL(`${config2.baseUrl}/coins/${coinId}/market_chart`);
  url.searchParams.set("vs_currency", "usd");
  url.searchParams.set("days", String(days));
  url.searchParams.set("precision", "full");
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8e3);
    try {
      const response = await fetch(url, { headers: config2.headers, signal: controller.signal });
      if (response.ok) return response.json();
      if (![429, 500, 502, 503, 504].includes(response.status) || attempt === 2) throw new Error(`CoinGecko chart returned ${response.status}`);
    } finally {
      clearTimeout(timeout);
    }
    await new Promise((resolve) => setTimeout(resolve, 400 * (attempt + 1)));
  }
  throw new Error("CoinGecko chart retry limit reached.");
}
async function coinGeckoCandles(range, pair, apiKey, plan) {
  const config2 = RANGE_CONFIG[range];
  const treePayload = await coinGeckoPayload("thickquidity", config2.days, apiKey, plan);
  const candles = pair === "sui" ? normalizeSuiPairCandles(treePayload, await coinGeckoPayload("sui", config2.days, apiKey, plan), config2.limit) : normalizeCoinGeckoCandles(treePayload, config2.limit);
  const result = range === "1h" ? candles.slice(-13) : candles;
  if (result.length < 2) throw new Error("CoinGecko chart returned insufficient TREE prices.");
  return result;
}
var tree_chart_default = async (request) => {
  if (request.method !== "GET") return Response.json({ error: "method-not-allowed" }, { status: 405, headers: { Allow: "GET", "Cache-Control": "no-store" } });
  const url = new URL(request.url);
  const range = url.searchParams.get("range") || "24h";
  const pair = url.searchParams.get("pair") || "usd";
  if (!(range in RANGE_CONFIG)) return Response.json({ error: "invalid-range", allowed: Object.keys(RANGE_CONFIG) }, { status: 400, headers: { "Cache-Control": "no-store" } });
  if (!["usd", "sui"].includes(pair)) return Response.json({ error: "invalid-pair", allowed: ["usd", "sui"] }, { status: 400, headers: { "Cache-Control": "no-store" } });
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const base = { range, pair, generatedAt };
  try {
    const candles = await coinGeckoCandles(range, pair, Netlify.env.get("COINGECKO_API_KEY") || "", Netlify.env.get("COINGECKO_API_PLAN") || "demo");
    const source = pair === "sui" ? "CoinGecko TREE/SUI cross-rate" : "CoinGecko";
    try {
      await writeCachedTreeChart({ generatedAt, source, range, pair, candles });
    } catch (error) {
      console.error("TREE chart cache write failed", error);
    }
    return Response.json({ status: "ok", ...base, source, candles, warnings: pair === "sui" ? ["TREE/SUI history is calculated from matched CoinGecko TREE/USD and SUI/USD observations."] : [] }, { headers: { "Cache-Control": "public, max-age=30, s-maxage=60, stale-while-revalidate=120" } });
  } catch (error) {
    console.error("CoinGecko TREE chart request failed", error);
    try {
      const cached = await readCachedTreeChart(range, pair);
      if (cached) return Response.json({ status: "ok", ...base, source: `${cached.source} \xB7 last successful chart`, candles: cached.candles, cachedAt: cached.generatedAt, stale: true, warnings: ["CoinGecko chart refresh was temporarily unavailable; the last successful chart is shown."] }, { headers: { "Cache-Control": "public, max-age=15, s-maxage=30, stale-while-revalidate=300" } });
    } catch (cacheError) {
      console.error("TREE chart cache read failed", cacheError);
    }
    return Response.json({ status: "error", ...base, source: "CoinGecko", candles: [], warnings: ["CoinGecko chart data is temporarily unavailable."] }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
};
var config = { path: "/api/tree-chart" };
export {
  config,
  tree_chart_default as default,
  normalizeCoinGeckoCandles,
  normalizeSuiPairCandles,
  sampleChartCandles
};
