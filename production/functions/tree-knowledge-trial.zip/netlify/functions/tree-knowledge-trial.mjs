
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/tree-knowledge-trial.ts
import { verifyPersonalMessageSignature } from "@mysten/sui/verify";

// netlify/lib/tree-knowledge-trial-core.ts
var TREE_KNOWLEDGE_TRIAL_VERSION = "tree-knowledge-trial-v1";
var TREE_KNOWLEDGE_TRIAL_QUESTION_SET = "tree-ecosystem-rotating-v3";
var TREE_KNOWLEDGE_TRIAL_DURATION_SECONDS = 90;
var TREE_KNOWLEDGE_TRIAL_QUESTION_COUNT = 3;
var TREE_KNOWLEDGE_TRIAL_MINIMUM_USD_CENTS = 500;
var TREE_KNOWLEDGE_TRIAL_QUESTION_BANK = Object.freeze([
  {
    id: "network",
    prompt: "Which network is the TREE ecosystem built on?",
    options: Object.freeze([
      { id: "a", label: "Ethereum Mainnet" },
      { id: "b", label: "Sui Mainnet" },
      { id: "c", label: "Solana Mainnet" },
      { id: "d", label: "Base" }
    ]),
    correctOptionId: "b",
    explanation: "TREE is a Sui-native utility ecosystem."
  },
  {
    id: "nftree-access",
    prompt: "What is the primary role of an NFTree in the ecosystem?",
    options: Object.freeze([
      { id: "a", label: "Access to holder rewards, games, identity, and future utilities" },
      { id: "b", label: "A replacement for the TREE token" },
      { id: "c", label: "A guaranteed investment return" },
      { id: "d", label: "A Sui validator license" }
    ]),
    correctOptionId: "a",
    explanation: "NFTree is the ecosystem access asset for rewards, games, identity, and future utility."
  },
  {
    id: "treedrop",
    prompt: "What does TreeDrop provide?",
    options: Object.freeze([
      { id: "a", label: "Automatic token trading" },
      { id: "b", label: "NFTree holder reward checks and protected distribution rounds" },
      { id: "c", label: "A centralized exchange account" },
      { id: "d", label: "A random NFT mint" }
    ]),
    correctOptionId: "b",
    explanation: "TreeDrop lets eligible NFTrees claim configured rewards once per applicable round."
  },
  {
    id: "canopy-board",
    prompt: "What does the verified Canopy Board rank?",
    options: Object.freeze([
      { id: "a", label: "Only social-media followers" },
      { id: "b", label: "Only NFT artwork rarity" },
      { id: "c", label: "Liquid TREE plus verified TREE principal in supported LP positions" },
      { id: "d", label: "Wallet age on Sui" }
    ]),
    correctOptionId: "c",
    explanation: "The board combines liquid TREE with verified principal from supported liquidity positions."
  },
  {
    id: "liquidity-venues",
    prompt: "Which venues are recognized for TREE liquidity in the Command Center?",
    options: Object.freeze([
      { id: "a", label: "SuiDex V2, SuiDex V3, Turbos, and Cetus" },
      { id: "b", label: "Uniswap and Curve only" },
      { id: "c", label: "Coinbase and Kraken only" },
      { id: "d", label: "No liquidity venues are recognized" }
    ]),
    correctOptionId: "a",
    explanation: "The verified TREE liquidity view combines SuiDex V2, SuiDex V3, Turbos, and Cetus."
  },
  {
    id: "burned-tree",
    prompt: "How does the site define burned TREE?",
    options: Object.freeze([
      { id: "a", label: "TREE held by any exchange wallet" },
      { id: "b", label: "TREE temporarily locked in liquidity" },
      { id: "c", label: "TREE held by the Sui zero address" },
      { id: "d", label: "TREE moved between personal wallets" }
    ]),
    correctOptionId: "c",
    explanation: "TREE held by the Sui zero address is reported as burned."
  },
  {
    id: "nftree-mint",
    prompt: "What is the published NFTree mint price?",
    options: Object.freeze([
      { id: "a", label: "5 SUI" },
      { id: "b", label: "10 SUI" },
      { id: "c", label: "25 SUI" },
      { id: "d", label: "100 SUI" }
    ]),
    correctOptionId: "c",
    explanation: "The current published NFTree mint price is 25 SUI."
  },
  {
    id: "coin-type",
    prompt: "What should a user verify before approving a TREE transaction?",
    options: Object.freeze([
      { id: "a", label: "Only the ticker symbol" },
      { id: "b", label: "Only the token logo" },
      { id: "c", label: "The complete TREE coin type" },
      { id: "d", label: "The wallet color theme" }
    ]),
    correctOptionId: "c",
    explanation: "A name, symbol, or shortened address is not enough; verify the complete coin type."
  },
  {
    id: "v3-liquidity",
    prompt: "What does the V3 section manage?",
    options: Object.freeze([
      { id: "a", label: "Concentrated SUI/TREE liquidity positions" },
      { id: "b", label: "Email subscriptions" },
      { id: "c", label: "NFT artwork generation" },
      { id: "d", label: "Sui validator voting" }
    ]),
    correctOptionId: "a",
    explanation: "V3 is the concentrated-liquidity workspace for verified SUI/TREE positions."
  },
  {
    id: "tree-fund",
    prompt: "What share of NFTree sales is donated to supported causes such as TREE Fund and Saluting Branches?",
    options: Object.freeze([
      { id: "a", label: "1%" },
      { id: "b", label: "5%" },
      { id: "c", label: "25%" },
      { id: "d", label: "50%" }
    ]),
    correctOptionId: "b",
    explanation: "Five percent of NFTree sales is donated to supported causes such as TREE Fund and Saluting Branches."
  },
  {
    id: "root-token",
    prompt: "Which asset is described as the root token of the TREE ecosystem?",
    options: Object.freeze([
      { id: "a", label: "TREE" },
      { id: "b", label: "NFTree" },
      { id: "c", label: "SUI" },
      { id: "d", label: "wBTC" }
    ]),
    correctOptionId: "a",
    explanation: "TREE is the root token connecting the ecosystem utilities."
  },
  {
    id: "swap-routing",
    prompt: "What is the TREE swap router designed to compare?",
    options: Object.freeze([
      { id: "a", label: "Only centralized exchanges" },
      { id: "b", label: "Verified TREE routes across SuiDex V2, SuiDex V3, Turbos, and Cetus" },
      { id: "c", label: "Only NFT marketplaces" },
      { id: "d", label: "Validator commission rates" }
    ]),
    correctOptionId: "b",
    explanation: "The swap interface compares supported SuiDex V2, SuiDex V3, Turbos, and Cetus routes for TREE."
  },
  {
    id: "v2-location",
    prompt: "Where are SUI/TREE V2 liquidity positions managed in the Command Center?",
    options: Object.freeze([
      { id: "a", label: "Earn" },
      { id: "b", label: "Burn" },
      { id: "c", label: "Canopy" },
      { id: "d", label: "Docs" }
    ]),
    correctOptionId: "a",
    explanation: "The Earn section contains the SUI/TREE V2 position and reward tools."
  },
  {
    id: "v3-location",
    prompt: "Where are concentrated SUI/TREE liquidity positions managed?",
    options: Object.freeze([
      { id: "a", label: "The V3 section" },
      { id: "b", label: "The Burn section" },
      { id: "c", label: "The Canopy badge guide" },
      { id: "d", label: "The homepage footer" }
    ]),
    correctOptionId: "a",
    explanation: "Concentrated SUI/TREE positions are managed in the dedicated V3 section."
  },
  {
    id: "limit-cancel",
    prompt: "What can a user do with an open supported limit order?",
    options: Object.freeze([
      { id: "a", label: "Cancel it before it fills" },
      { id: "b", label: "Convert it into an NFTree" },
      { id: "c", label: "Use it as a validator vote" },
      { id: "d", label: "Erase it from Sui history" }
    ]),
    correctOptionId: "a",
    explanation: "Supported open limit orders can be reviewed and cancelled before execution."
  },
  {
    id: "supported-wallets",
    prompt: "Which group contains supported Sui wallets shown by the TREE app?",
    options: Object.freeze([
      { id: "a", label: "Slush, Phantom, and Nightly" },
      { id: "b", label: "MetaMask only" },
      { id: "c", label: "Bitcoin Core only" },
      { id: "d", label: "No external wallets" }
    ]),
    correctOptionId: "a",
    explanation: "The wallet selector supports Sui wallets including Slush, Phantom, and Nightly."
  },
  {
    id: "victory-v2",
    prompt: "Which incentive token is emitted by the supported SUI/TREE V2 position?",
    options: Object.freeze([
      { id: "a", label: "VICTORY" },
      { id: "b", label: "ETH" },
      { id: "c", label: "DOGE" },
      { id: "d", label: "USDC only" }
    ]),
    correctOptionId: "a",
    explanation: "The supported SUI/TREE V2 position includes VICTORY incentives."
  },
  {
    id: "v3-claim-all",
    prompt: "What is the V3 Claim All action intended to collect?",
    options: Object.freeze([
      { id: "a", label: "Available position fees and rewards" },
      { id: "b", label: "Only wallet gas rebates" },
      { id: "c", label: "NFT artwork files" },
      { id: "d", label: "Leaderboard badges" }
    ]),
    correctOptionId: "a",
    explanation: "Claim All combines the available trading-fee and incentive-reward claims for a V3 position."
  },
  {
    id: "v3-close",
    prompt: "What is the guarded V3 Close action designed to do?",
    options: Object.freeze([
      { id: "a", label: "Withdraw the position assets and collect available fees and rewards" },
      { id: "b", label: "Delete the connected wallet" },
      { id: "c", label: "Burn every token in the wallet" },
      { id: "d", label: "Transfer the NFTree collection" }
    ]),
    correctOptionId: "a",
    explanation: "Closing a V3 position withdraws its assets and collects what is available from that position."
  },
  {
    id: "victory-reinvest",
    prompt: "What does a full VICTORY reinvest do?",
    options: Object.freeze([
      { id: "a", label: "Uses VICTORY toward TREE liquidity reinvestment" },
      { id: "b", label: "Mints an unrelated NFT" },
      { id: "c", label: "Changes the wallet address" },
      { id: "d", label: "Removes TREE from circulation automatically" }
    ]),
    correctOptionId: "a",
    explanation: "The full reinvest workflow uses VICTORY toward TREE and the selected liquidity destination."
  },
  {
    id: "sustainable-reinvest",
    prompt: "How does the sustainable VICTORY reinvest differ from a full reinvest?",
    options: Object.freeze([
      { id: "a", label: "It divides the selected VICTORY between reinvestment and locking" },
      { id: "b", label: "It guarantees a fixed return" },
      { id: "c", label: "It sends every token to an exchange" },
      { id: "d", label: "It skips wallet approval" }
    ]),
    correctOptionId: "a",
    explanation: "The sustainable path divides the selected VICTORY between TREE reinvestment and a VICTORY lock."
  },
  {
    id: "stats-purpose",
    prompt: "What is the purpose of the TREE Stats section?",
    options: Object.freeze([
      { id: "a", label: "Show verified TREE market, liquidity, volume, and ecosystem data" },
      { id: "b", label: "Store wallet recovery phrases" },
      { id: "c", label: "Create email accounts" },
      { id: "d", label: "Run a validator node in the browser" }
    ]),
    correctOptionId: "a",
    explanation: "Stats consolidates verified TREE market and ecosystem information."
  },
  {
    id: "canopy-size",
    prompt: "How many ranked wallets are displayed on the verified Canopy Board?",
    options: Object.freeze([
      { id: "a", label: "10" },
      { id: "b", label: "25" },
      { id: "c", label: "50" },
      { id: "d", label: "1,000" }
    ]),
    correctOptionId: "c",
    explanation: "The Canopy Board is the verified Top 50 TREE leaderboard."
  },
  {
    id: "canopy-badges",
    prompt: "What do badges beside a Canopy wallet represent?",
    options: Object.freeze([
      { id: "a", label: "Verified ecosystem milestones or recent wallet behavior" },
      { id: "b", label: "Guaranteed future profits" },
      { id: "c", label: "The wallet password strength" },
      { id: "d", label: "A centralized exchange rating" }
    ]),
    correctOptionId: "a",
    explanation: "Canopy badges identify defined ecosystem milestones or qualifying recent behavior."
  },
  {
    id: "arcade-access",
    prompt: "What serves as the access key for TREE ecosystem games?",
    options: Object.freeze([
      { id: "a", label: "An NFTree" },
      { id: "b", label: "An email subscription" },
      { id: "c", label: "A centralized exchange account" },
      { id: "d", label: "A paper wallet printout" }
    ]),
    correctOptionId: "a",
    explanation: "Holding an NFTree provides access to TREE ecosystem game utilities."
  },
  {
    id: "arcade-games",
    prompt: "Which group contains TREE Arcade projects?",
    options: Object.freeze([
      { id: "a", label: "Garden Battles, Arboretum, and TREE FORCE \u201989" },
      { id: "b", label: "Fortnite, Roblox, and Minecraft" },
      { id: "c", label: "Uniswap, Curve, and Aave" },
      { id: "d", label: "No games are planned" }
    ]),
    correctOptionId: "a",
    explanation: "The TREE Arcade presents Garden Battles, Arboretum, TREE FORCE \u201989, and future ecosystem games."
  },
  {
    id: "qualifying-minimum",
    prompt: "What is the minimum TREE purchase required to unlock one daily Knowledge Trial attempt?",
    options: Object.freeze([
      { id: "a", label: "$1" },
      { id: "b", label: "$5" },
      { id: "c", label: "$25" },
      { id: "d", label: "$100" }
    ]),
    correctOptionId: "b",
    explanation: "A verified purchase worth at least five US dollars unlocks one attempt for that round."
  },
  {
    id: "qualification-direction",
    prompt: "Which trade direction qualifies for Knowledge Trial access?",
    options: Object.freeze([
      { id: "a", label: "A supported SUI-to-TREE purchase" },
      { id: "b", label: "Selling TREE for SUI" },
      { id: "c", label: "Moving TREE between personal wallets" },
      { id: "d", label: "Claiming an NFT reward" }
    ]),
    correctOptionId: "a",
    explanation: "Eligibility requires a verified supported purchase of TREE using SUI."
  },
  {
    id: "one-attempt",
    prompt: "How many scored Knowledge Trial attempts can one wallet use in a daily round?",
    options: Object.freeze([
      { id: "a", label: "One" },
      { id: "b", label: "Three" },
      { id: "c", label: "One per purchase" },
      { id: "d", label: "Unlimited" }
    ]),
    correctOptionId: "a",
    explanation: "One qualifying wallet can use one scored attempt in each daily round."
  },
  {
    id: "purchase-multiplicity",
    prompt: "Do additional qualifying purchases create extra Knowledge Trial attempts in the same round?",
    options: Object.freeze([
      { id: "a", label: "No, the wallet still receives one attempt" },
      { id: "b", label: "Yes, every purchase creates ten attempts" },
      { id: "c", label: "Only if the wallet changes its name" },
      { id: "d", label: "Only on centralized exchanges" }
    ]),
    correctOptionId: "a",
    explanation: "Extra purchases do not create extra scored attempts for the same wallet and round."
  },
  {
    id: "trial-length",
    prompt: "How many questions are in the daily TREE Knowledge Trial?",
    options: Object.freeze([
      { id: "a", label: "Three" },
      { id: "b", label: "Five" },
      { id: "c", label: "Ten" },
      { id: "d", label: "Twenty-five" }
    ]),
    correctOptionId: "a",
    explanation: "The daily skill challenge contains three questions."
  },
  {
    id: "trial-timer",
    prompt: "How much time is allowed for the three-question daily Knowledge Trial?",
    options: Object.freeze([
      { id: "a", label: "30 seconds" },
      { id: "b", label: "90 seconds" },
      { id: "c", label: "10 minutes" },
      { id: "d", label: "There is no time limit" }
    ]),
    correctOptionId: "b",
    explanation: "Each daily three-question attempt has a 90-second limit."
  },
  {
    id: "scoring-primary",
    prompt: "What is the primary ranking factor in the Knowledge Trial?",
    options: Object.freeze([
      { id: "a", label: "Number of correct answers" },
      { id: "b", label: "Wallet balance" },
      { id: "c", label: "Number of purchases" },
      { id: "d", label: "NFT artwork rarity" }
    ]),
    correctOptionId: "a",
    explanation: "Accuracy ranks first in the Knowledge Trial."
  },
  {
    id: "scoring-secondary",
    prompt: "When two participants have the same score, what ranks them next?",
    options: Object.freeze([
      { id: "a", label: "Verified completion time" },
      { id: "b", label: "Wallet balance" },
      { id: "c", label: "Social-media followers" },
      { id: "d", label: "A random coin flip" }
    ]),
    correctOptionId: "a",
    explanation: "Faster verified completion time ranks equal scores."
  },
  {
    id: "exact-tie",
    prompt: "How is an exact tie for the leading Knowledge Trial result resolved?",
    options: Object.freeze([
      { id: "a", label: "A private sudden-death question" },
      { id: "b", label: "The larger wallet wins" },
      { id: "c", label: "The prize is always cancelled" },
      { id: "d", label: "A random drawing" }
    ]),
    correctOptionId: "a",
    explanation: "Exactly tied leaders advance to a private sudden-death question."
  },
  {
    id: "daily-prize",
    prompt: "What is the planned prize for the single daily Knowledge Trial winner?",
    options: Object.freeze([
      { id: "a", label: "50,000 TREE" },
      { id: "b", label: "A guaranteed NFTree mint" },
      { id: "c", label: "One validator node" },
      { id: "d", label: "No prize" }
    ]),
    correctOptionId: "a",
    explanation: "The planned daily skill prize is 50,000 TREE for one winner."
  },
  {
    id: "wallet-signature",
    prompt: "What does the Knowledge Trial wallet-ownership signature authorize?",
    options: Object.freeze([
      { id: "a", label: "Proof that the participant controls the qualifying wallet" },
      { id: "b", label: "An automatic transfer of every wallet asset" },
      { id: "c", label: "A new validator account" },
      { id: "d", label: "A token sale" }
    ]),
    correctOptionId: "a",
    explanation: "The signed personal message proves wallet control and does not authorize a fund transfer."
  },
  {
    id: "winner-claim-wallet",
    prompt: "Which wallet must claim a Knowledge Trial prize?",
    options: Object.freeze([
      { id: "a", label: "The verified winning wallet" },
      { id: "b", label: "Any wallet that visits the site" },
      { id: "c", label: "A centralized exchange deposit wallet" },
      { id: "d", label: "The fastest wallet to connect after the round" }
    ]),
    correctOptionId: "a",
    explanation: "Only the verified winning wallet can claim its awarded prize."
  },
  {
    id: "practice-mode",
    prompt: "Does completing a practice trial consume a qualifying daily attempt?",
    options: Object.freeze([
      { id: "a", label: "No" },
      { id: "b", label: "Yes, always" },
      { id: "c", label: "Only when all answers are correct" },
      { id: "d", label: "Only on mobile" }
    ]),
    correctOptionId: "a",
    explanation: "Practice mode does not consume a pass, affect the leaderboard, or award a prize."
  },
  {
    id: "sui-gas",
    prompt: "Which token pays network gas for TREE app transactions on Sui?",
    options: Object.freeze([
      { id: "a", label: "SUI" },
      { id: "b", label: "TREE only" },
      { id: "c", label: "BTC" },
      { id: "d", label: "ETH" }
    ]),
    correctOptionId: "a",
    explanation: "SUI is the native gas token used for transactions on the Sui network."
  },
  {
    id: "safe-simulation",
    prompt: "Why does the Command Center simulate supported transactions before wallet approval?",
    options: Object.freeze([
      { id: "a", label: "To check whether the transaction is expected to succeed safely" },
      { id: "b", label: "To reveal the wallet recovery phrase" },
      { id: "c", label: "To guarantee investment profit" },
      { id: "d", label: "To bypass the connected wallet" }
    ]),
    correctOptionId: "a",
    explanation: "Simulation checks the prepared transaction before the user is asked for wallet approval."
  },
  {
    id: "purchase-window",
    prompt: "When must a qualifying TREE purchase occur for a daily Knowledge Trial round?",
    options: Object.freeze([
      { id: "a", label: "Inside that round\u2019s published purchase window" },
      { id: "b", label: "At any time in the project\u2019s history" },
      { id: "c", label: "Only after the winner is announced" },
      { id: "d", label: "Only during a centralized exchange listing" }
    ]),
    correctOptionId: "a",
    explanation: "The verified purchase must finalize inside the applicable round window."
  },
  {
    id: "one-daily-winner",
    prompt: "How many winners are selected from a completed daily Knowledge Trial round?",
    options: Object.freeze([
      { id: "a", label: "One" },
      { id: "b", label: "Every qualifying buyer" },
      { id: "c", label: "Fifty" },
      { id: "d", label: "None" }
    ]),
    correctOptionId: "a",
    explanation: "The daily trial produces one skill-ranked winner."
  },
  {
    id: "suidex-v2-v3-difference",
    prompt: "What is the main liquidity difference between SuiDex V2 and SuiDex V3?",
    options: Object.freeze([
      { id: "a", label: "V3 can concentrate liquidity inside chosen price ranges, while V2 uses a full-range pool model" },
      { id: "b", label: "V2 supports only NFTs, while V3 supports only stablecoins" },
      { id: "c", label: "V2 runs on Bitcoin, while V3 runs on Ethereum" },
      { id: "d", label: "There is no difference in how liquidity is positioned" }
    ]),
    correctOptionId: "a",
    explanation: "SuiDex V3 lets providers choose concentrated price ranges; V2 liquidity follows the pool\u2019s full-range model."
  },
  {
    id: "suidex-route-output",
    prompt: "When the TREE swap compares routes for the same input, which result matters most?",
    options: Object.freeze([
      { id: "a", label: "The highest protected executable output after route costs" },
      { id: "b", label: "The venue with the largest logo" },
      { id: "c", label: "The pool with the highest advertised APR" },
      { id: "d", label: "The route listed first alphabetically" }
    ]),
    correctOptionId: "a",
    explanation: "Best-route selection should compare the protected amount the wallet can actually receive for the entered trade."
  },
  {
    id: "suidex-wallet-review",
    prompt: "What should a user review before approving a SuiDex swap in a wallet?",
    options: Object.freeze([
      { id: "a", label: "Trade direction, input amount, expected output, and minimum received" },
      { id: "b", label: "Only the color of the confirmation button" },
      { id: "c", label: "Only the token ticker shown on social media" },
      { id: "d", label: "Nothing, because every wallet request is automatically safe" }
    ]),
    correctOptionId: "a",
    explanation: "Review the assets, amounts, and protected minimum before signing any swap transaction."
  },
  {
    id: "suidex-slippage",
    prompt: "What does a swap slippage setting control?",
    options: Object.freeze([
      { id: "a", label: "How much execution movement the user will accept before the swap should fail" },
      { id: "b", label: "How many wallet accounts can connect at once" },
      { id: "c", label: "How long a token has existed" },
      { id: "d", label: "The number of validators on Sui" }
    ]),
    correctOptionId: "a",
    explanation: "Slippage tolerance limits how far execution may move from the quoted result before protection rejects the trade."
  },
  {
    id: "suidex-price-impact",
    prompt: "What most directly increases price impact on a SuiDex pool?",
    options: Object.freeze([
      { id: "a", label: "A trade that is large relative to the pool\u2019s available liquidity" },
      { id: "b", label: "Changing the wallet theme" },
      { id: "c", label: "Viewing the Stats tab" },
      { id: "d", label: "Holding an unrelated NFT" }
    ]),
    correctOptionId: "a",
    explanation: "Trades consume pool liquidity, so a larger trade relative to available depth generally moves the execution price more."
  },
  {
    id: "suidex-fee-source",
    prompt: "Where do liquidity-provider trading fees generally come from?",
    options: Object.freeze([
      { id: "a", label: "Fees paid by swaps that use the pool" },
      { id: "b", label: "Guaranteed payments from the Sui network" },
      { id: "c", label: "Wallet connection fees" },
      { id: "d", label: "Automatic NFT sales" }
    ]),
    correctOptionId: "a",
    explanation: "A portion of swap fees is allocated to eligible liquidity positions according to the pool\u2019s rules."
  },
  {
    id: "suidex-v3-in-range",
    prompt: "When is a SuiDex V3 position in range?",
    options: Object.freeze([
      { id: "a", label: "When the current pool price is between the position\u2019s selected lower and upper prices" },
      { id: "b", label: "Whenever the wallet is connected" },
      { id: "c", label: "Only when SUI has risen during the last 24 hours" },
      { id: "d", label: "Whenever the position contains equal token counts" }
    ]),
    correctOptionId: "a",
    explanation: "A concentrated-liquidity position is in range while the current pool price sits inside its chosen bounds."
  },
  {
    id: "suidex-liquidity-risk",
    prompt: "What risk can make a liquidity position perform differently from simply holding both tokens?",
    options: Object.freeze([
      { id: "a", label: "Relative token-price movement can change the position\u2019s token mix and value" },
      { id: "b", label: "The wallet automatically reveals its recovery phrase" },
      { id: "c", label: "The blockchain deletes every position after one day" },
      { id: "d", label: "Every liquidity position guarantees a fixed return" }
    ]),
    correctOptionId: "a",
    explanation: "As relative prices move, an automated-market-maker position can hold a different token mix and underperform simple holding."
  },
  {
    id: "suidex-v3-zap",
    prompt: "What is the purpose of the SuiDex V3 Zap workflow?",
    options: Object.freeze([
      { id: "a", label: "Create or increase a position from one token by preparing the needed token mix" },
      { id: "b", label: "Move every wallet asset to a centralized exchange" },
      { id: "c", label: "Remove all liquidity without wallet approval" },
      { id: "d", label: "Guarantee that a position always remains in range" }
    ]),
    correctOptionId: "a",
    explanation: "Zap simplifies liquidity entry by using one deposit token and preparing the pair needed for the selected V3 position."
  }
]);
var ROTATION_POOLS = Object.freeze({
  easy: Object.freeze([
    "network",
    "nftree-access",
    "root-token",
    "supported-wallets",
    "arcade-access",
    "arcade-games",
    "qualifying-minimum",
    "trial-length",
    "trial-timer",
    "daily-prize",
    "one-daily-winner",
    "practice-mode",
    "sui-gas",
    "tree-fund",
    "nftree-mint",
    "suidex-v2-v3-difference",
    "suidex-route-output",
    "suidex-wallet-review"
  ]),
  medium: Object.freeze([
    "treedrop",
    "liquidity-venues",
    "burned-tree",
    "coin-type",
    "v3-liquidity",
    "swap-routing",
    "v2-location",
    "v3-location",
    "limit-cancel",
    "victory-v2",
    "stats-purpose",
    "canopy-size",
    "qualification-direction",
    "winner-claim-wallet",
    "suidex-slippage",
    "suidex-price-impact",
    "suidex-fee-source"
  ]),
  hard: Object.freeze([
    "canopy-board",
    "v3-claim-all",
    "v3-close",
    "victory-reinvest",
    "sustainable-reinvest",
    "canopy-badges",
    "one-attempt",
    "purchase-multiplicity",
    "scoring-primary",
    "scoring-secondary",
    "exact-tie",
    "wallet-signature",
    "safe-simulation",
    "purchase-window",
    "suidex-v3-in-range",
    "suidex-liquidity-risk",
    "suidex-v3-zap"
  ])
});
var bankIds = TREE_KNOWLEDGE_TRIAL_QUESTION_BANK.map(({ id }) => id);
var rotationIds = [...ROTATION_POOLS.easy, ...ROTATION_POOLS.medium, ...ROTATION_POOLS.hard];
if (new Set(bankIds).size !== bankIds.length || new Set(rotationIds).size !== rotationIds.length || bankIds.some((id) => !rotationIds.includes(id)) || rotationIds.some((id) => !bankIds.includes(id))) {
  throw new Error("The TREE Knowledge Trial rotation pools must cover the private question bank exactly once.");
}
var TREE_KNOWLEDGE_TRIAL_QUESTIONS = Object.freeze(
  TREE_KNOWLEDGE_TRIAL_QUESTION_BANK.slice(0, TREE_KNOWLEDGE_TRIAL_QUESTION_COUNT)
);
if (TREE_KNOWLEDGE_TRIAL_QUESTIONS.length !== TREE_KNOWLEDGE_TRIAL_QUESTION_COUNT) {
  throw new Error("The TREE Knowledge Trial question count does not match its published rules.");
}
function validateTreeKnowledgeQuestionSet(value, expectedCount = TREE_KNOWLEDGE_TRIAL_QUESTION_COUNT) {
  if (!Array.isArray(value) || value.length !== expectedCount) {
    throw new Error("The Knowledge Trial question set has an invalid question count.");
  }
  const ids = /* @__PURE__ */ new Set();
  return value.map((item) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) throw new Error("A Knowledge Trial question is invalid.");
    const row = item;
    const id = typeof row.id === "string" && /^[a-z0-9][a-z0-9-]{1,63}$/.test(row.id) ? row.id : null;
    const prompt = typeof row.prompt === "string" && row.prompt.trim().length >= 8 && row.prompt.length <= 500 ? row.prompt.trim() : null;
    if (!id || ids.has(id) || !prompt || !Array.isArray(row.options) || row.options.length < 2 || row.options.length > 6) {
      throw new Error("A Knowledge Trial question is invalid.");
    }
    ids.add(id);
    const optionIds = /* @__PURE__ */ new Set();
    const options = row.options.map((option) => {
      if (!option || typeof option !== "object" || Array.isArray(option)) throw new Error("A Knowledge Trial option is invalid.");
      const candidate = option;
      const optionId = typeof candidate.id === "string" && /^[a-z0-9]{1,8}$/.test(candidate.id) ? candidate.id : null;
      const label = typeof candidate.label === "string" && candidate.label.trim().length >= 1 && candidate.label.length <= 300 ? candidate.label.trim() : null;
      if (!optionId || optionIds.has(optionId) || !label) throw new Error("A Knowledge Trial option is invalid.");
      optionIds.add(optionId);
      return { id: optionId, label };
    });
    const correctOptionId = typeof row.correctOptionId === "string" && optionIds.has(row.correctOptionId) ? row.correctOptionId : null;
    const explanation = typeof row.explanation === "string" && row.explanation.trim().length >= 3 && row.explanation.length <= 1e3 ? row.explanation.trim() : null;
    if (!correctOptionId || !explanation) throw new Error("A Knowledge Trial answer key is invalid.");
    return { id, prompt, options, correctOptionId, explanation };
  });
}
function publicTreeKnowledgeQuestions(questions = TREE_KNOWLEDGE_TRIAL_QUESTIONS) {
  return questions.map(({ id, prompt, options }) => ({ id, prompt, options }));
}
function validElapsedMs(value) {
  const elapsedMs = Number(value);
  if (!Number.isSafeInteger(elapsedMs) || elapsedMs < 0 || elapsedMs > 36e5) {
    throw new Error("Elapsed time must be a non-negative whole number of milliseconds.");
  }
  return elapsedMs;
}
function scoreTreeKnowledgeTrialAgainst(questions, rawAnswers, rawElapsedMs) {
  if (!Array.isArray(rawAnswers) || rawAnswers.length > questions.length) {
    throw new Error("Knowledge Trial answers are invalid.");
  }
  const elapsedMs = validElapsedMs(rawElapsedMs);
  const submitted = /* @__PURE__ */ new Map();
  for (const answer of rawAnswers) {
    if (!answer || typeof answer.questionId !== "string" || typeof answer.optionId !== "string") {
      throw new Error("Every Knowledge Trial answer must identify a question and option.");
    }
    const question = questions.find(({ id }) => id === answer.questionId);
    if (!question || !question.options.some(({ id }) => id === answer.optionId)) {
      throw new Error("A Knowledge Trial answer references an unknown question or option.");
    }
    if (submitted.has(answer.questionId)) throw new Error("A Knowledge Trial question was answered more than once.");
    submitted.set(answer.questionId, answer.optionId);
  }
  const answers = questions.map((question) => {
    const optionId = submitted.get(question.id) ?? null;
    return {
      questionId: question.id,
      optionId,
      correct: optionId === question.correctOptionId,
      correctOptionId: question.correctOptionId,
      explanation: question.explanation
    };
  });
  const correctCount = answers.filter(({ correct }) => correct).length;
  return {
    correctCount,
    totalQuestions: questions.length,
    percentage: Math.round(correctCount * 1e4 / questions.length) / 100,
    elapsedMs,
    elapsedSeconds: Math.round(elapsedMs / 100) / 10,
    timedOut: elapsedMs > TREE_KNOWLEDGE_TRIAL_DURATION_SECONDS * 1e3,
    answers
  };
}
function scoreTreeKnowledgeTrial(rawAnswers, rawElapsedMs) {
  return scoreTreeKnowledgeTrialAgainst(TREE_KNOWLEDGE_TRIAL_QUESTIONS, rawAnswers, rawElapsedMs);
}
function treeKnowledgeTrialStatus(env = process.env) {
  const legalApproved = env.TREE_KNOWLEDGE_TRIAL_LEGAL_APPROVED === "true";
  const databaseReady = env.TREE_KNOWLEDGE_TRIAL_DATABASE_READY === "true";
  const questionSetReady = env.TREE_KNOWLEDGE_TRIAL_QUESTION_SET_READY === "true";
  const prizeSettlementReady = env.TREE_KNOWLEDGE_TRIAL_PRIZE_SETTLEMENT_READY === "true";
  const claimsEnabled = env.TREE_KNOWLEDGE_TRIAL_CLAIMS_ENABLED === "true" && prizeSettlementReady;
  const requestedEnabled = env.TREE_KNOWLEDGE_TRIAL_ENABLED === "true";
  return {
    version: TREE_KNOWLEDGE_TRIAL_VERSION,
    questionSetVersion: TREE_KNOWLEDGE_TRIAL_QUESTION_SET,
    publicAttemptsEnabled: requestedEnabled && legalApproved && databaseReady && questionSetReady && prizeSettlementReady,
    claimsEnabled,
    practiceEnabled: true,
    durationSeconds: TREE_KNOWLEDGE_TRIAL_DURATION_SECONDS,
    questionCount: TREE_KNOWLEDGE_TRIAL_QUESTION_COUNT,
    minimumQualifyingUsdCents: TREE_KNOWLEDGE_TRIAL_MINIMUM_USD_CENTS,
    scoring: Object.freeze({ primary: "correct-answers", secondary: "elapsed-time", exactTie: "sudden-death" }),
    activation: { requestedEnabled, legalApproved, databaseReady, questionSetReady, prizeSettlementReady }
  };
}

// netlify/lib/tree-knowledge-trial-supabase.ts
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function required(value, label) {
  const normalized = value?.trim();
  if (!normalized) throw new Error(`${label} is not configured.`);
  return normalized;
}
function treeKnowledgeTrialSupabaseConfig(env) {
  const rawUrl = env.TREE_RAFFLE_SUPABASE_URL || env.TREE_KNOWLEDGE_TRIAL_SUPABASE_URL;
  const rawKey = env.TREE_RAFFLE_SUPABASE_SECRET_KEY || env.TREE_KNOWLEDGE_TRIAL_SUPABASE_SECRET_KEY;
  const url = required(rawUrl, "TREE_KNOWLEDGE_TRIAL_SUPABASE_URL");
  const secretKey = required(rawKey, "TREE_KNOWLEDGE_TRIAL_SUPABASE_SECRET_KEY");
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error("TREE_KNOWLEDGE_TRIAL_SUPABASE_URL must be a valid HTTPS URL.");
  }
  if (parsed.protocol !== "https:") throw new Error("TREE_KNOWLEDGE_TRIAL_SUPABASE_URL must use HTTPS.");
  return { url: parsed.origin, secretKey };
}
function text(value, label) {
  if (typeof value !== "string" || !value.trim()) throw new Error(`Supabase returned an invalid ${label}.`);
  return value;
}
function boolean(value, label) {
  if (typeof value !== "boolean") throw new Error(`Supabase returned an invalid ${label}.`);
  return value;
}
function integer(value, label) {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 1) throw new Error(`Supabase returned an invalid ${label}.`);
  return parsed;
}
function nonnegativeInteger(value, label) {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 0) throw new Error(`Supabase returned an invalid ${label}.`);
  return parsed;
}
function parseEligibility(value) {
  const row = record(value);
  const status = String(row.status || "");
  if (!["not-eligible", "eligible", "pass-issued", "attempt-started", "completed"].includes(status)) {
    throw new Error("Supabase returned an invalid Knowledge Trial eligibility state.");
  }
  const qualifyingUsdCents = row.qualifyingUsdCents == null ? null : nonnegativeInteger(row.qualifyingUsdCents, "qualifying purchase value");
  const verifiedAt = row.verifiedAt == null ? null : text(row.verifiedAt, "qualifying purchase verification time");
  return {
    roundId: text(row.roundId, "eligibility round ID"),
    wallet: text(row.wallet, "eligibility wallet"),
    eligible: boolean(row.eligible, "eligibility result"),
    status,
    minimumQualifyingUsdCents: nonnegativeInteger(row.minimumQualifyingUsdCents, "minimum qualifying value"),
    qualifyingUsdCents,
    verifiedAt,
    passIssued: boolean(row.passIssued, "pass issuance state"),
    attemptStarted: boolean(row.attemptStarted, "attempt start state"),
    attemptCompleted: boolean(row.attemptCompleted, "attempt completion state")
  };
}
function parseChallenge(value) {
  const row = record(value);
  return {
    challengeId: text(row.challengeId, "challenge ID"),
    roundId: text(row.roundId, "round ID"),
    wallet: text(row.wallet, "challenge wallet"),
    qualifyingTxDigest: text(row.qualifyingTxDigest, "qualifying transaction digest"),
    message: text(row.message, "wallet challenge message"),
    expiresAt: text(row.expiresAt, "challenge expiration"),
    consumed: boolean(row.consumed, "challenge consumption state")
  };
}
function parseAttemptContext(value) {
  const row = record(value);
  return {
    attemptId: text(row.attemptId, "attempt ID"),
    roundId: text(row.roundId, "attempt round ID"),
    wallet: text(row.wallet, "attempt wallet"),
    questionSetVersion: text(row.questionSetVersion, "question-set version"),
    startedAt: text(row.startedAt, "attempt start time"),
    expiresAt: text(row.expiresAt, "attempt expiration"),
    submitted: boolean(row.submitted, "attempt submission state")
  };
}
function parseTiebreakChallenge(value) {
  const row = record(value);
  return {
    challengeId: text(row.challengeId, "sudden-death challenge ID"),
    roundId: text(row.roundId, "sudden-death round ID"),
    wallet: text(row.wallet, "sudden-death wallet"),
    stage: integer(row.stage, "sudden-death stage"),
    message: text(row.message, "sudden-death wallet challenge message"),
    expiresAt: text(row.expiresAt, "sudden-death challenge expiration"),
    consumed: boolean(row.consumed, "sudden-death challenge consumption state")
  };
}
function parseTiebreakAttemptContext(value) {
  const row = record(value);
  return {
    attemptId: text(row.attemptId, "sudden-death attempt ID"),
    roundId: text(row.roundId, "sudden-death attempt round ID"),
    wallet: text(row.wallet, "sudden-death attempt wallet"),
    stage: integer(row.stage, "sudden-death attempt stage"),
    startedAt: text(row.startedAt, "sudden-death attempt start time"),
    expiresAt: text(row.expiresAt, "sudden-death attempt expiration"),
    submitted: boolean(row.submitted, "sudden-death attempt submission state")
  };
}
var SupabaseTreeKnowledgeTrialStore = class {
  config;
  fetchImpl;
  constructor(config2, fetchImpl = fetch) {
    this.config = config2;
    this.fetchImpl = fetchImpl;
  }
  // The private Knowledge Trial snapshot joins rounds, passes, attempts, and
  // recent history. Supabase can legitimately take longer than 7.5 seconds
  // after an idle period, so keep the request inside Netlify's execution
  // window instead of returning a false empty round during a cold start.
  async rpc(name, body, timeoutMs = 2e4) {
    const response = await this.fetchImpl(`${this.config.url}/rest/v1/rpc/${name}`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.config.secretKey}`,
        apikey: this.config.secretKey,
        "X-Client-Info": "tree-command-center-knowledge-trial/1"
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs)
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok) {
      const message = typeof record(payload).message === "string" ? String(record(payload).message) : `Supabase Knowledge Trial request failed with HTTP ${response.status}.`;
      throw new Error(message);
    }
    return payload;
  }
  async publicSnapshot() {
    let value;
    try {
      value = record(await this.rpc("read_tree_knowledge_trial_public_snapshot_v2", {}));
    } catch (error) {
      if (!/could not find|does not exist|PGRST202|HTTP 404/i.test(error instanceof Error ? error.message : "")) throw error;
      value = record(await this.rpc("read_tree_knowledge_trial_public_snapshot_v1", {}));
    }
    if (value.round !== null && (!value.round || typeof value.round !== "object")) {
      throw new Error("Supabase returned an invalid Knowledge Trial round snapshot.");
    }
    if (!Array.isArray(value.leaderboard)) throw new Error("Supabase returned an invalid Knowledge Trial leaderboard.");
    const participation = record(value.participation);
    const submissionCount = nonnegativeInteger(value.submissionCount || 0, "submission count");
    return {
      round: value.round,
      leaderboard: value.leaderboard,
      submissionCount,
      participation: {
        verifiedPasses: nonnegativeInteger(participation.verifiedPasses || 0, "verified pass count"),
        attemptsStarted: nonnegativeInteger(participation.attemptsStarted || 0, "attempt start count"),
        completedAttempts: nonnegativeInteger(participation.completedAttempts ?? submissionCount, "completed attempt count"),
        completionRatePercent: nonnegativeInteger(participation.completionRatePercent || 0, "completion rate")
      },
      recentRounds: Array.isArray(value.recentRounds) ? value.recentRounds : []
    };
  }
  async readEligibility(roundId2, wallet) {
    return parseEligibility(await this.rpc("read_tree_knowledge_trial_wallet_eligibility_v1", {
      p_round_id: roundId2,
      p_wallet: wallet
    }));
  }
  async createChallenge(input) {
    return parseChallenge(await this.rpc("create_tree_knowledge_trial_wallet_challenge_v1", {
      p_round_id: input.roundId,
      p_wallet: input.wallet,
      p_qualifying_tx_digest: input.qualifyingTxDigest,
      p_nonce_sha256: input.nonceSha256,
      p_message_prefix: input.messagePrefix,
      p_request_fingerprint: input.requestFingerprint,
      p_expires_at: input.expiresAt
    }));
  }
  async readChallenge(challengeId) {
    return parseChallenge(await this.rpc("read_tree_knowledge_trial_wallet_challenge_v1", {
      p_challenge_id: challengeId
    }));
  }
  async consumeChallenge(challengeId, wallet, roundId2) {
    return parseChallenge(await this.rpc("consume_tree_knowledge_trial_wallet_challenge_v1", {
      p_challenge_id: challengeId,
      p_wallet: wallet,
      p_round_id: roundId2
    }));
  }
  async issuePass(roundId2, wallet, qualifyingTxDigest) {
    return record(await this.rpc("issue_tree_knowledge_trial_pass_v1", {
      p_round_id: roundId2,
      p_wallet: wallet,
      p_qualifying_tx_digest: qualifyingTxDigest
    }));
  }
  async startAttempt(roundId2, wallet, attemptTokenSha256) {
    return parseAttemptContext(await this.rpc("start_tree_knowledge_trial_attempt_v2", {
      p_round_id: roundId2,
      p_wallet: wallet,
      p_attempt_token_sha256: attemptTokenSha256
    }));
  }
  async readAttempt(attemptTokenSha256) {
    return parseAttemptContext(await this.rpc("read_tree_knowledge_trial_attempt_context_v1", {
      p_attempt_token_sha256: attemptTokenSha256
    }));
  }
  async questionSet(questionSetVersion) {
    const value = record(await this.rpc("read_tree_knowledge_trial_question_set_v1", {
      p_question_set_version: questionSetVersion
    }));
    return value.questions;
  }
  async submitAttempt(attemptTokenSha256, answers, correctCount) {
    return record(await this.rpc("submit_tree_knowledge_trial_attempt_v2", {
      p_attempt_token_sha256: attemptTokenSha256,
      p_answers: answers,
      p_correct_count: correctCount
    }));
  }
  async createTiebreakChallenge(input) {
    return parseTiebreakChallenge(await this.rpc("create_tree_knowledge_trial_tiebreak_challenge_v1", {
      p_round_id: input.roundId,
      p_wallet: input.wallet,
      p_nonce_sha256: input.nonceSha256,
      p_message: input.message,
      p_request_fingerprint: input.requestFingerprint,
      p_expires_at: input.expiresAt
    }));
  }
  async readTiebreakChallenge(challengeId) {
    return parseTiebreakChallenge(await this.rpc("read_tree_knowledge_trial_tiebreak_challenge_v1", {
      p_challenge_id: challengeId
    }));
  }
  async consumeTiebreakChallenge(challengeId, wallet, roundId2, stage) {
    return parseTiebreakChallenge(await this.rpc("consume_tree_knowledge_trial_tiebreak_challenge_v1", {
      p_challenge_id: challengeId,
      p_wallet: wallet,
      p_round_id: roundId2,
      p_stage: stage
    }));
  }
  async startTiebreakAttempt(roundId2, wallet, stage, attemptTokenSha256) {
    return parseTiebreakAttemptContext(await this.rpc("start_tree_knowledge_trial_tiebreak_attempt_v1", {
      p_round_id: roundId2,
      p_wallet: wallet,
      p_stage: stage,
      p_attempt_token_sha256: attemptTokenSha256
    }));
  }
  async readTiebreakAttempt(attemptTokenSha256) {
    return parseTiebreakAttemptContext(await this.rpc("read_tree_knowledge_trial_tiebreak_attempt_context_v1", {
      p_attempt_token_sha256: attemptTokenSha256
    }));
  }
  async tiebreakQuestion(roundId2, stage) {
    return record(await this.rpc("read_tree_knowledge_trial_tiebreak_question_v1", {
      p_round_id: roundId2,
      p_stage: stage
    }));
  }
  async submitTiebreakAttempt(attemptTokenSha256, selectedOptionId) {
    return record(await this.rpc("submit_tree_knowledge_trial_tiebreak_attempt_v1", {
      p_attempt_token_sha256: attemptTokenSha256,
      p_selected_option_id: selectedOptionId
    }));
  }
  async prepareDraft(input) {
    return record(await this.rpc("prepare_tree_knowledge_trial_round_v2", {
      p_round_id: input.roundId,
      p_question_set_version: input.questionSetVersion,
      p_questions: input.questions,
      p_tiebreak_questions: input.tiebreakQuestions,
      p_purchase_window_opens_at: input.purchaseWindowOpensAt,
      p_purchase_window_closes_at: input.purchaseWindowClosesAt,
      p_challenge_opens_at: input.challengeOpensAt,
      p_challenge_closes_at: input.challengeClosesAt,
      p_prize_token_type: input.prizeTokenType,
      p_prize_amount_raw: input.prizeAmountRaw,
      p_request_sha256: input.requestSha256
    }));
  }
  async readDraftSetup(roundId2) {
    const value = await this.rpc("read_tree_knowledge_trial_round_setup_v2", {
      p_round_id: roundId2
    });
    return value === null ? null : record(value);
  }
  async scheduleRound(roundId2) {
    return record(await this.rpc("schedule_tree_knowledge_trial_round_v2", {
      p_round_id: roundId2
    }));
  }
  async resolveRound(roundId2) {
    return record(await this.rpc("resolve_tree_knowledge_trial_round_v2", {
      p_round_id: roundId2
    }));
  }
  async nextResolvableRound() {
    const value = await this.rpc("read_next_resolvable_tree_knowledge_trial_round_v1", {});
    return value === null ? null : record(value);
  }
  async readAward(roundId2, wallet) {
    const value = await this.rpc("read_tree_knowledge_trial_award_v1", {
      p_round_id: roundId2,
      p_wallet: wallet
    });
    return value === null ? null : record(value);
  }
  async recordClaim(roundId2, wallet, claimTxDigest) {
    return record(await this.rpc("record_tree_knowledge_trial_claim_v1", {
      p_round_id: roundId2,
      p_wallet: wallet,
      p_claim_tx_digest: claimTxDigest
    }));
  }
};
function configuredSupabaseTreeKnowledgeTrialStore(env, fetchImpl = fetch) {
  return new SupabaseTreeKnowledgeTrialStore(treeKnowledgeTrialSupabaseConfig(env), fetchImpl);
}

// netlify/functions/tree-knowledge-trial.ts
var MAX_BODY_BYTES = 16384;
var NETLIFY_PREVIEW_HOST = /^(?:deploy-preview-\d+|[a-f0-9]{24})--tree-token\.netlify\.app$/;
var SUI_WALLET = /^0x[0-9a-f]{64}$/;
var SUI_DIGEST = /^[1-9A-HJ-NP-Za-km-z]{40,64}$/;
var ROUND_ID = /^knowledge:[0-9]{4}-[0-9]{2}-[0-9]{2}$/;
var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
var SIGNATURE = /^[A-Za-z0-9+/_=-]{40,2048}$/;
var TOKEN = /^[0-9a-f]{64}$/;
var ENVIRONMENT_KEYS = [
  "TREE_KNOWLEDGE_TRIAL_ENABLED",
  "TREE_KNOWLEDGE_TRIAL_LEGAL_APPROVED",
  "TREE_KNOWLEDGE_TRIAL_DATABASE_READY",
  "TREE_KNOWLEDGE_TRIAL_QUESTION_SET_READY",
  "TREE_KNOWLEDGE_TRIAL_PRIZE_SETTLEMENT_READY",
  "TREE_KNOWLEDGE_TRIAL_CLAIMS_ENABLED",
  "TREE_KNOWLEDGE_TRIAL_RATE_LIMIT_SECRET",
  "TREE_KNOWLEDGE_TRIAL_SUPABASE_URL",
  "TREE_KNOWLEDGE_TRIAL_SUPABASE_SECRET_KEY",
  "TREE_RAFFLE_SUPABASE_URL",
  "TREE_RAFFLE_SUPABASE_SECRET_KEY",
  "TREE_RAFFLE_PACKAGE_ID",
  "TREE_RAFFLE_PRIZE_POOL_ID"
];
function runtimeEnvironment() {
  const netlify = globalThis.Netlify;
  return Object.fromEntries(ENVIRONMENT_KEYS.map((key) => [
    key,
    netlify?.env?.get?.(key) ?? process.env[key]
  ]));
}
function json(body, status = 200) {
  return Response.json(body, {
    status,
    headers: {
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      "X-Robots-Tag": "noindex"
    }
  });
}
function allowedOrigin(request) {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  try {
    const url = new URL(origin);
    return url.protocol === "https:" && (url.hostname === "tree-token.xyz" || url.hostname === "www.tree-token.xyz" || NETLIFY_PREVIEW_HOST.test(url.hostname)) || url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  } catch {
    return false;
  }
}
async function requestBody(request) {
  const length = Number(request.headers.get("content-length") || "0");
  if (length > MAX_BODY_BYTES) throw new Error("request-too-large");
  const bodyText = await request.text();
  if (!bodyText || bodyText.length > MAX_BODY_BYTES) throw new Error("invalid-request");
  const value = JSON.parse(bodyText);
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("invalid-request");
  return value;
}
function normalizedWallet(value) {
  const wallet = typeof value === "string" ? value.trim().toLowerCase() : "";
  if (!SUI_WALLET.test(wallet)) throw new Error("invalid-wallet");
  return wallet;
}
function roundId(value) {
  if (typeof value !== "string" || !ROUND_ID.test(value)) throw new Error("invalid-round");
  return value;
}
function randomHex(bytes) {
  const value = new Uint8Array(bytes);
  crypto.getRandomValues(value);
  return [...value].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
async function sha256Hex(value) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
async function requestFingerprint(secret, ip) {
  if (secret.length < 32) throw new Error("rate-limit-secret-not-configured");
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const digest = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(ip || "unknown"));
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function safeMessage(error) {
  const message = error instanceof Error ? error.message : "";
  if (/qualifying TREE purchase|not accepting|no qualifying Challenge Pass|expired|already used|too many|sudden-death|not eligible/i.test(message)) return message;
  return "The Knowledge Trial could not complete this request.";
}
function publicTiebreakQuestion(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("invalid-sudden-death-question");
  const question = value;
  const id = typeof question.id === "string" ? question.id.trim() : "";
  const prompt = typeof question.prompt === "string" ? question.prompt.trim() : "";
  if (!id || id.length > 96 || !prompt || prompt.length > 500 || !Array.isArray(question.options)) {
    throw new Error("invalid-sudden-death-question");
  }
  const options = question.options.map((value2) => {
    if (!value2 || typeof value2 !== "object" || Array.isArray(value2)) throw new Error("invalid-sudden-death-question");
    const option = value2;
    const optionId = typeof option.id === "string" ? option.id.trim() : "";
    const label = typeof option.label === "string" ? option.label.trim() : "";
    if (!optionId || optionId.length > 64 || !label || label.length > 300) throw new Error("invalid-sudden-death-question");
    return { id: optionId, label };
  });
  if (options.length < 2 || options.length > 8 || new Set(options.map(({ id: optionId }) => optionId)).size !== options.length) {
    throw new Error("invalid-sudden-death-question");
  }
  return { id, prompt, options };
}
function validatedStoredQuestionSet(value) {
  const count = Array.isArray(value) ? value.length : 0;
  if (count !== 3 && count !== 5) throw new Error("invalid-private-question-set");
  return validateTreeKnowledgeQuestionSet(value, count);
}
function createTreeKnowledgeTrialHandler(dependencies = {}) {
  return async (request, context) => {
    if (!allowedOrigin(request)) return json({ status: "error", error: "origin-not-allowed" }, 403);
    const url = new URL(request.url);
    const action = url.searchParams.get("action") || "status";
    const env = dependencies.env || runtimeEnvironment();
    const trial = treeKnowledgeTrialStatus(env);
    const getStore = () => dependencies.store || configuredSupabaseTreeKnowledgeTrialStore(env);
    if (request.method === "GET" && action === "status") {
      let publicRound = null;
      let leaderboard = [];
      let submissionCount = 0;
      let participation = { verifiedPasses: 0, attemptsStarted: 0, completedAttempts: 0, completionRatePercent: 0 };
      let recentRounds = [];
      if (trial.activation.databaseReady) {
        try {
          const snapshot = await getStore().publicSnapshot();
          publicRound = snapshot.round;
          leaderboard = snapshot.leaderboard;
          submissionCount = snapshot.submissionCount;
          participation = snapshot.participation;
          recentRounds = snapshot.recentRounds;
        } catch (error) {
          console.error("TREE Knowledge Trial snapshot failed", error);
        }
      }
      return json({
        status: "ok",
        generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        trial,
        contracts: {
          packageId: env.TREE_RAFFLE_PACKAGE_ID || null,
          poolId: env.TREE_RAFFLE_PRIZE_POOL_ID || null
        },
        plannedPrize: { symbol: "TREE", amount: "50,000", cadence: "daily", winnerCount: 1 },
        practice: { questionSetVersion: TREE_KNOWLEDGE_TRIAL_QUESTION_SET, questions: publicTreeKnowledgeQuestions() },
        publicRound,
        leaderboard,
        submissionCount,
        participation,
        recentRounds
      });
    }
    if (request.method !== "POST") return json({ status: "error", error: "method-not-allowed" }, 405);
    if (action === "practice-submit") {
      try {
        const body = await requestBody(request);
        const answers = Array.isArray(body.answers) ? body.answers : [];
        const score = scoreTreeKnowledgeTrial(answers, Number(body.elapsedMs));
        return json({ status: "ok", practice: true, score });
      } catch {
        return json({ status: "error", error: "invalid-practice-submission" }, 400);
      }
    }
    if (action === "eligibility") {
      try {
        const body = await requestBody(request);
        const wallet = normalizedWallet(body.wallet);
        const selectedRoundId = roundId(body.roundId);
        const eligibility = await getStore().readEligibility(selectedRoundId, wallet);
        return json({ status: "ok", eligibility });
      } catch (error) {
        console.error("TREE Knowledge Trial eligibility check failed", error);
        const status = /invalid-/i.test(error instanceof Error ? error.message : "") ? 400 : 409;
        return json({ status: "error", error: "knowledge-trial-eligibility-failed", message: safeMessage(error) }, status);
      }
    }
    if (!["challenge", "start", "submit", "tiebreak-challenge", "tiebreak-start", "tiebreak-submit"].includes(action)) {
      return json({ status: "error", error: "unknown-action" }, 400);
    }
    if (!trial.publicAttemptsEnabled) {
      return json({
        status: "disabled",
        error: "knowledge-trial-not-active",
        message: "Public Challenge Passes and scored attempts remain disabled while the rules and production ledger are completed."
      }, 503);
    }
    try {
      const body = await requestBody(request);
      const store = getStore();
      const now = dependencies.now?.() || /* @__PURE__ */ new Date();
      const createRandomHex = dependencies.randomHex || randomHex;
      if (action === "tiebreak-challenge") {
        const wallet = normalizedWallet(body.wallet);
        const selectedRoundId = roundId(body.roundId);
        const stage = Number(body.stage);
        if (!Number.isInteger(stage) || stage < 1 || stage > 100) throw new Error("invalid-sudden-death-stage");
        const nonce = createRandomHex(24);
        const expiresAt = new Date(now.getTime() + 5 * 6e4).toISOString();
        const message = [
          "TREE Knowledge Trial",
          `Action: Start sudden-death stage ${stage}`,
          `Wallet: ${wallet}`,
          `Round: ${selectedRoundId}`,
          `Stage: ${stage}`,
          `Nonce: ${nonce}`,
          `Expires: ${expiresAt}`,
          "This signature does not authorize a transaction or move funds."
        ].join("\n");
        const rateSecret = env.TREE_KNOWLEDGE_TRIAL_RATE_LIMIT_SECRET || "";
        const ip = dependencies.requestIp?.(context) || String(context?.ip || "unknown");
        const challenge = await store.createTiebreakChallenge({
          roundId: selectedRoundId,
          wallet,
          nonceSha256: await sha256Hex(nonce),
          message,
          requestFingerprint: await requestFingerprint(rateSecret, ip),
          expiresAt
        });
        return json({
          status: "ok",
          challenge: {
            challengeId: challenge.challengeId,
            roundId: challenge.roundId,
            wallet: challenge.wallet,
            stage: challenge.stage,
            message: challenge.message,
            expiresAt: challenge.expiresAt
          }
        });
      }
      if (action === "tiebreak-start") {
        const wallet = normalizedWallet(body.wallet);
        const challengeId = typeof body.challengeId === "string" && UUID.test(body.challengeId) ? body.challengeId : null;
        const signature = typeof body.signature === "string" && SIGNATURE.test(body.signature) ? body.signature : null;
        if (!challengeId || !signature) throw new Error("invalid-wallet-authorization");
        const challenge = await store.readTiebreakChallenge(challengeId);
        if (challenge.wallet !== wallet || challenge.consumed || new Date(challenge.expiresAt).getTime() <= now.getTime()) {
          throw new Error("The sudden-death wallet challenge is invalid, expired, or already used.");
        }
        const verify = dependencies.verifySignature || (async (message, signed, address) => {
          await verifyPersonalMessageSignature(message, signed, { address });
        });
        await verify(new TextEncoder().encode(challenge.message), signature, wallet);
        const consumed = await store.consumeTiebreakChallenge(
          challengeId,
          wallet,
          challenge.roundId,
          challenge.stage
        );
        const attemptToken2 = createRandomHex(32);
        const attempt2 = await store.startTiebreakAttempt(
          consumed.roundId,
          wallet,
          consumed.stage,
          await sha256Hex(attemptToken2)
        );
        const question = publicTiebreakQuestion(await store.tiebreakQuestion(attempt2.roundId, attempt2.stage));
        return json({
          status: "ok",
          attempt: {
            attemptId: attempt2.attemptId,
            roundId: attempt2.roundId,
            stage: attempt2.stage,
            startedAt: attempt2.startedAt,
            expiresAt: attempt2.expiresAt,
            attemptToken: attemptToken2,
            questions: [question]
          }
        });
      }
      if (action === "tiebreak-submit") {
        const attemptToken2 = typeof body.attemptToken === "string" && TOKEN.test(body.attemptToken) ? body.attemptToken : null;
        if (!attemptToken2 || !Array.isArray(body.answers) || body.answers.length !== 1) {
          throw new Error("invalid-sudden-death-submission");
        }
        const tokenSha2562 = await sha256Hex(attemptToken2);
        const attempt2 = await store.readTiebreakAttempt(tokenSha2562);
        if (attempt2.submitted) return json({ status: "error", error: "attempt-already-submitted" }, 409);
        const question = publicTiebreakQuestion(await store.tiebreakQuestion(attempt2.roundId, attempt2.stage));
        const answer = body.answers[0];
        const questionId = typeof answer?.questionId === "string" ? answer.questionId : "";
        const optionId = typeof answer?.optionId === "string" ? answer.optionId : "";
        if (questionId !== question.id || !question.options.some((option) => option.id === optionId)) {
          throw new Error("invalid-sudden-death-submission");
        }
        const recorded2 = await store.submitTiebreakAttempt(tokenSha2562, optionId);
        return json({
          status: "ok",
          result: {
            outcome: recorded2.outcome,
            correctCount: recorded2.correct === true ? 1 : 0,
            totalQuestions: 1,
            elapsedMs: Number(recorded2.elapsedMs),
            stage: Number(recorded2.stage)
          }
        });
      }
      if (action === "challenge") {
        const wallet = normalizedWallet(body.wallet);
        const selectedRoundId = roundId(body.roundId);
        let qualifyingTxDigest = null;
        if (body.qualifyingTxDigest != null && body.qualifyingTxDigest !== "") {
          if (typeof body.qualifyingTxDigest !== "string" || !SUI_DIGEST.test(body.qualifyingTxDigest)) {
            throw new Error("invalid-transaction-digest");
          }
          qualifyingTxDigest = body.qualifyingTxDigest;
        }
        const nonce = createRandomHex(24);
        const expiresAt = new Date(now.getTime() + 5 * 6e4).toISOString();
        const prefix = [
          "TREE Knowledge Trial",
          "Action: Start one scored challenge attempt",
          `Wallet: ${wallet}`,
          `Round: ${selectedRoundId}`,
          `Nonce: ${nonce}`,
          `Expires: ${expiresAt}`,
          "This signature does not authorize a transaction or move funds."
        ].join("\n");
        const rateSecret = env.TREE_KNOWLEDGE_TRIAL_RATE_LIMIT_SECRET || "";
        const ip = dependencies.requestIp?.(context) || String(context?.ip || "unknown");
        const challenge = await store.createChallenge({
          roundId: selectedRoundId,
          wallet,
          qualifyingTxDigest,
          nonceSha256: await sha256Hex(nonce),
          messagePrefix: prefix,
          requestFingerprint: await requestFingerprint(rateSecret, ip),
          expiresAt
        });
        return json({
          status: "ok",
          challenge: {
            challengeId: challenge.challengeId,
            roundId: challenge.roundId,
            wallet: challenge.wallet,
            message: challenge.message,
            expiresAt: challenge.expiresAt
          }
        });
      }
      if (action === "start") {
        const wallet = normalizedWallet(body.wallet);
        const challengeId = typeof body.challengeId === "string" && UUID.test(body.challengeId) ? body.challengeId : null;
        const signature = typeof body.signature === "string" && SIGNATURE.test(body.signature) ? body.signature : null;
        if (!challengeId || !signature) throw new Error("invalid-wallet-authorization");
        const challenge = await store.readChallenge(challengeId);
        if (challenge.wallet !== wallet || challenge.consumed || new Date(challenge.expiresAt).getTime() <= now.getTime()) {
          throw new Error("The wallet challenge is invalid, expired, or already used.");
        }
        const verify = dependencies.verifySignature || (async (message, signed, address) => {
          await verifyPersonalMessageSignature(message, signed, { address });
        });
        await verify(new TextEncoder().encode(challenge.message), signature, wallet);
        const consumed = await store.consumeChallenge(challengeId, wallet, challenge.roundId);
        await store.issuePass(challenge.roundId, wallet, consumed.qualifyingTxDigest);
        const attemptToken2 = createRandomHex(32);
        const attempt2 = await store.startAttempt(challenge.roundId, wallet, await sha256Hex(attemptToken2));
        if (attempt2.submitted) return json({ status: "error", error: "attempt-already-submitted" }, 409);
        if (new Date(attempt2.expiresAt).getTime() <= now.getTime()) return json({ status: "error", error: "attempt-expired" }, 409);
        const questions2 = validatedStoredQuestionSet(await store.questionSet(attempt2.questionSetVersion));
        return json({
          status: "ok",
          attempt: {
            attemptId: attempt2.attemptId,
            roundId: attempt2.roundId,
            startedAt: attempt2.startedAt,
            expiresAt: attempt2.expiresAt,
            attemptToken: attemptToken2,
            questions: publicTreeKnowledgeQuestions(questions2)
          }
        });
      }
      const attemptToken = typeof body.attemptToken === "string" && TOKEN.test(body.attemptToken) ? body.attemptToken : null;
      if (!attemptToken || !Array.isArray(body.answers)) throw new Error("invalid-attempt-submission");
      const tokenSha256 = await sha256Hex(attemptToken);
      const attempt = await store.readAttempt(tokenSha256);
      if (attempt.submitted) return json({ status: "error", error: "attempt-already-submitted" }, 409);
      const questions = validatedStoredQuestionSet(await store.questionSet(attempt.questionSetVersion));
      const score = scoreTreeKnowledgeTrialAgainst(
        questions,
        body.answers,
        0
      );
      const recorded = await store.submitAttempt(tokenSha256, score.answers, score.correctCount);
      return json({
        status: "ok",
        result: {
          outcome: recorded.outcome,
          correctCount: Number(recorded.correctCount),
          totalQuestions: questions.length,
          elapsedMs: Number(recorded.elapsedMs)
        }
      });
    } catch (error) {
      console.error("TREE Knowledge Trial request failed", error);
      const status = /invalid-/i.test(error instanceof Error ? error.message : "") ? 400 : 409;
      return json({ status: "error", error: "knowledge-trial-request-failed", message: safeMessage(error) }, status);
    }
  };
}
var tree_knowledge_trial_default = createTreeKnowledgeTrialHandler();
var config = { path: "/api/tree-knowledge-trial" };
export {
  config,
  createTreeKnowledgeTrialHandler,
  tree_knowledge_trial_default as default
};
