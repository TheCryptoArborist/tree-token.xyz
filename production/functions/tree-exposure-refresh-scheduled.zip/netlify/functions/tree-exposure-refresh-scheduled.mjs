
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-snapshot-scheduled-trigger.ts
var CONFIG = {
  exposure: {
    label: "TREE exposure",
    enabledEnv: "TREE_EXPOSURE_PRODUCTION_ENABLED",
    secretEnvs: ["TREE_EXPOSURE_REFRESH_SECRET", "TREE_LEADERBOARD_REFRESH_SECRET"],
    header: "x-tree-exposure-refresh-secret",
    path: "/.netlify/functions/tree-exposure-refresh-background"
  },
  badges: {
    label: "TREE behavioral badge",
    enabledEnv: "TREE_BADGE_PRODUCTION_ENABLED",
    secretEnvs: ["TREE_BADGE_REFRESH_SECRET", "TREE_LEADERBOARD_REFRESH_SECRET"],
    header: "x-tree-badge-refresh-secret",
    path: "/.netlify/functions/tree-badges-refresh-background"
  }
};
function enabled(value) {
  return (value || "").trim().toLowerCase() === "true";
}
async function runTreeSnapshotScheduledTrigger(kind, context, dependencies = {}) {
  const settings = CONFIG[kind];
  const logger = dependencies.logger ?? console;
  const getEnv = dependencies.getEnv ?? ((name) => Netlify.env.get(name));
  if (!enabled(getEnv(settings.enabledEnv))) {
    logger.info(`${settings.label} scheduled refresh is disabled.`);
    return { attempted: false, accepted: false, reason: "disabled" };
  }
  const secret = settings.secretEnvs.map((name) => getEnv(name) || "").find(Boolean) || "";
  if (!secret) {
    logger.error(`${settings.label} scheduled refresh has no configured secret.`);
    return { attempted: false, accepted: false, reason: "missing-secret" };
  }
  const siteUrl = context?.site?.url || getEnv("URL") || "https://tree-token.xyz";
  let endpoint;
  try {
    endpoint = new URL(settings.path, siteUrl);
  } catch {
    logger.error(`${settings.label} scheduled refresh could not resolve its endpoint.`);
    return { attempted: false, accepted: false, reason: "network-error" };
  }
  const fetchImpl = dependencies.fetchImpl ?? fetch;
  const setTimeoutImpl = dependencies.setTimeoutImpl ?? setTimeout;
  const clearTimeoutImpl = dependencies.clearTimeoutImpl ?? clearTimeout;
  const controller = new AbortController();
  const timeout = setTimeoutImpl(() => controller.abort(), dependencies.requestTimeoutMs ?? 2e4);
  try {
    const response = await fetchImpl(endpoint, {
      method: "POST",
      headers: { [settings.header]: secret },
      signal: controller.signal
    });
    if (response.status !== 202) {
      logger.error(`${settings.label} scheduled refresh was not accepted.`);
      return { attempted: true, accepted: false, reason: "unexpected-status" };
    }
    logger.info(`${settings.label} scheduled refresh was accepted.`);
    return { attempted: true, accepted: true, reason: "accepted" };
  } catch (error) {
    if (controller.signal.aborted || error instanceof Error && error.name === "AbortError") {
      logger.error(`${settings.label} scheduled refresh timed out.`);
      return { attempted: true, accepted: false, reason: "timeout" };
    }
    logger.error(`${settings.label} scheduled refresh request failed.`);
    return { attempted: true, accepted: false, reason: "network-error" };
  } finally {
    clearTimeoutImpl(timeout);
  }
}

// netlify/functions/tree-exposure-refresh-scheduled.ts
var tree_exposure_refresh_scheduled_default = async (_request, context) => {
  await runTreeSnapshotScheduledTrigger("exposure", context);
};
var config = {
  schedule: "27 */6 * * *"
};
export {
  config,
  tree_exposure_refresh_scheduled_default as default
};
