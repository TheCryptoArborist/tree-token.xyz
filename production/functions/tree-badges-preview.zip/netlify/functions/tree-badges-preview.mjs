
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/production-snapshot-preview.ts
function json(value, status = 200, cache = "no-store") {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": cache
    }
  });
}
async function proxyProductionSnapshotForPreview(request, context, productionUrl, label, dependencies = {}) {
  if (request.method !== "GET") return json({ status: "error", message: "Method not allowed." }, 405);
  if (context?.deploy?.context !== "deploy-preview") return json({ status: "error", message: "Not found." }, 404);
  const fetchImpl = dependencies.fetchImpl || fetch;
  try {
    const response = await fetchImpl(productionUrl, { headers: { Accept: "application/json" } });
    if (!response.ok) return json({ status: "error", message: `Production ${label} snapshot is unavailable.` }, 502);
    const payload = await response.json();
    return json({
      ...payload,
      previewSource: "production-complete-snapshot",
      previewMessage: `Deploy Preview is displaying the current public production ${label} snapshot for review.`,
      warnings: [
        ...Array.isArray(payload.warnings) ? payload.warnings : [],
        `Deploy Preview is displaying the current public production ${label} snapshot for review.`
      ]
    }, 200, "public, max-age=60, s-maxage=120");
  } catch {
    return json({ status: "error", message: `Production ${label} preview proxy failed.` }, 502);
  }
}

// netlify/functions/tree-badges-preview.ts
var tree_badges_preview_default = async (request, context) => proxyProductionSnapshotForPreview(
  request,
  context,
  "https://tree-token.xyz/api/tree-badges",
  "TREE badge"
);
var config = { path: "/api/tree-badges-preview" };
export {
  config,
  tree_badges_preview_default as default
};
