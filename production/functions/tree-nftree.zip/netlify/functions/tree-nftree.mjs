
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-nftree-overview.ts
var NFTREE_PACKAGE_ID = "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705";
var NFTREE_TYPE = `${NFTREE_PACKAGE_ID}::collection::NFT`;
var NFTREE_MINT_CONFIG_ID = "0xe83616020f61f73b30c40fd3f888ed397626afd071bd4666374c306d8e98b06b";
var NFTREE_SALE_POOL_IDS = [
  "0x8cb91464eec7ada1af801a439207647d78de66bc0d4f124d6437091745a0163a",
  "0xedd6b2d96968197bc121ad7bed064a43b5ad7d84cbb8b7c00d8fd78bea3e2e4d",
  "0xed43f2ffb52ef542ea2cfccd0358431923460fec8ef659febda111614e20457a"
];
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function normalizedId(value) {
  const id = String(value || "").toLowerCase();
  return /^0x[a-f0-9]{64}$/.test(id) ? id : null;
}
function nftId(value) {
  return normalizedId(record(value).id);
}
function calculateNftreeOverview(input) {
  if (input.holderScanReachedEnd !== true) throw new Error("NFTree holder scan did not reach the final page.");
  if (input.salePools.length !== NFTREE_SALE_POOL_IDS.length) throw new Error("Not all NFTree sale pools were returned.");
  const mintPriceMist = String(record(input.mintConfig).mint_price_mist || "");
  if (!/^\d+$/.test(mintPriceMist) || BigInt(mintPriceMist) <= 0n) throw new Error("NFTree mint price was not verified.");
  const holderIds = /* @__PURE__ */ new Set();
  const directWallets = /* @__PURE__ */ new Set();
  let directHolderOwned = 0;
  let marketplaceOrCustody = 0;
  for (const node of input.holderNodes) {
    const id = normalizedId(node.address);
    if (!id) throw new Error("NFTree holder object had an invalid object ID.");
    if (holderIds.has(id)) throw new Error(`Duplicate NFTree holder object ${id}.`);
    holderIds.add(id);
    const ownerKind = String(node.owner?.__typename || "");
    if (ownerKind === "AddressOwner") {
      const wallet = normalizedId(node.owner?.address?.address);
      if (!wallet) throw new Error(`NFTree ${id} had an invalid address owner.`);
      directHolderOwned += 1;
      directWallets.add(wallet);
    } else if (ownerKind === "ObjectOwner") {
      marketplaceOrCustody += 1;
    } else {
      throw new Error(`NFTree ${id} had unsupported ownership ${ownerKind || "Unknown"}.`);
    }
  }
  const salePoolIds = /* @__PURE__ */ new Set();
  const poolInventory = input.salePools.map((pool) => {
    if (!NFTREE_SALE_POOL_IDS.includes(pool.poolId)) {
      throw new Error(`Unrecognized NFTree sale pool ${pool.poolId}.`);
    }
    for (const nft of pool.nfts) {
      const id = nftId(nft);
      if (!id) throw new Error(`Sale pool ${pool.poolId} contained an invalid NFTree object.`);
      if (salePoolIds.has(id)) throw new Error(`NFTree ${id} appeared in more than one sale pool.`);
      if (holderIds.has(id)) throw new Error(`NFTree ${id} appeared as both holder-owned and sale-pool inventory.`);
      salePoolIds.add(id);
    }
    return { poolId: pool.poolId, count: pool.nfts.length };
  });
  const holderOwned = holderIds.size;
  const salePool = salePoolIds.size;
  const totalLoaded = holderOwned + salePool;
  if (directHolderOwned + marketplaceOrCustody !== holderOwned) throw new Error("NFTree ownership reconciliation failed.");
  if (poolInventory.reduce((sum, pool) => sum + pool.count, 0) !== salePool) throw new Error("NFTree sale-pool reconciliation failed.");
  const mistPerSui = 1000000000n;
  const whole = BigInt(mintPriceMist) / mistPerSui;
  const remainder = BigInt(mintPriceMist) % mistPerSui;
  const mintPriceSui = Number(whole) + Number(remainder) / Number(mistPerSui);
  return {
    mintPriceMist,
    mintPriceSui,
    totalLoaded,
    holderOwned,
    salePool,
    directHolderOwned,
    marketplaceOrCustody,
    directHolderWallets: directWallets.size,
    poolInventory,
    reconciliation: {
      loadedEqualsHolderPlusPool: totalLoaded === holderOwned + salePool,
      holderOwnershipComplete: directHolderOwned + marketplaceOrCustody === holderOwned,
      salePoolObjectIdsUnique: true
    }
  };
}
var NFTREE_HOLDERS_QUERY = `query NftreeObjects($first: Int!, $after: String, $type: String!) {
  objects(first: $first, after: $after, filter: { type: $type }) {
    pageInfo { hasNextPage endCursor }
    nodes {
      address
      owner {
        __typename
        ... on AddressOwner { address { address } }
        ... on ObjectOwner { address { address } }
      }
    }
  }
}`;
function nftreePoolQuery() {
  const pools = NFTREE_SALE_POOL_IDS.map((id, index) => `p${index}: object(address: "${id}") { asMoveObject { contents { json } } }`).join("\n");
  return `query NftreePoolsAndConfig {
    config: object(address: "${NFTREE_MINT_CONFIG_ID}") { asMoveObject { contents { json } } }
    ${pools}
  }`;
}
function parseNftreePoolResponse(data) {
  const root = record(data);
  const mintConfig = record(record(record(root.config).asMoveObject).contents).json;
  const salePools = NFTREE_SALE_POOL_IDS.map((poolId, index) => {
    const json = record(record(record(root[`p${index}`]).asMoveObject).contents).json;
    const nfts = record(json).nfts;
    if (!Array.isArray(nfts)) throw new Error(`NFTree sale pool ${poolId} was unavailable.`);
    return { poolId, nfts };
  });
  return { mintConfig, salePools };
}

// netlify/functions/tree-nftree.ts
var GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
function response(body, status = 200, cache = "public, max-age=30, s-maxage=60, stale-while-revalidate=180") {
  return Response.json(body, { status, headers: { "Cache-Control": cache, "X-Content-Type-Options": "nosniff" } });
}
async function graphql(query, variables, signal) {
  const result = await fetch(GRAPHQL_URL, {
    method: "POST",
    signal,
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ query, variables })
  });
  if (!result.ok) throw new Error(`Sui GraphQL returned HTTP ${result.status}.`);
  const payload = await result.json();
  if (Array.isArray(payload.errors) && payload.errors.length) {
    throw new Error(payload.errors.map((error) => error?.message || "Unknown GraphQL error").join(" "));
  }
  return payload.data;
}
async function getHolderObjects(signal) {
  const nodes = [];
  let after = null;
  let reachedEnd = false;
  let pagesScanned = 0;
  while (pagesScanned < 20) {
    const data = await graphql(NFTREE_HOLDERS_QUERY, { first: 50, after, type: NFTREE_TYPE }, signal);
    const connection = data?.objects;
    if (!Array.isArray(connection?.nodes)) throw new Error("NFTree holder page was unavailable.");
    nodes.push(...connection.nodes);
    pagesScanned += 1;
    if (connection.pageInfo?.hasNextPage !== true) {
      reachedEnd = true;
      break;
    }
    after = connection.pageInfo?.endCursor || null;
    if (!after) throw new Error("NFTree holder scan lacked a continuation cursor.");
  }
  return { nodes, reachedEnd, pagesScanned };
}
var tree_nftree_default = async (request) => {
  if (request.method !== "GET") return response({ status: "error", error: "method-not-allowed" }, 405, "no-store");
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 2e4);
  try {
    const [holders, poolData] = await Promise.all([
      getHolderObjects(controller.signal),
      graphql(nftreePoolQuery(), {}, controller.signal).then(parseNftreePoolResponse)
    ]);
    const nftree = calculateNftreeOverview({
      mintConfig: poolData.mintConfig,
      holderNodes: holders.nodes,
      holderScanReachedEnd: holders.reachedEnd,
      salePools: poolData.salePools
    });
    return response({
      status: "ok",
      generatedAt,
      network: "sui-mainnet",
      source: "Sui Mainnet GraphQL",
      methodology: "verified-nftree-ownership-v1",
      nftree,
      coverage: {
        holderPagesScanned: holders.pagesScanned,
        holderObjectsScanned: holders.nodes.length,
        salePoolsScanned: poolData.salePools.length,
        reachedEnd: holders.reachedEnd
      },
      warnings: nftree.marketplaceOrCustody > 0 ? [`${nftree.marketplaceOrCustody} holder-owned NFTrees are object-owned by marketplace or custody objects, so the wallet count reports directly verifiable address owners only.`] : []
    });
  } catch (error) {
    console.error("NFTree overview failed:", error);
    return response({
      status: "error",
      generatedAt,
      error: "nftree-verification-unavailable",
      message: error instanceof Error ? error.message : String(error)
    }, 503, "no-store");
  } finally {
    clearTimeout(timeout);
  }
};
var config = { path: "/api/tree-nftree" };
export {
  config,
  tree_nftree_default as default
};
