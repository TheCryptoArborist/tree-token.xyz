
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/arcade-wallet-link.ts
import { verifyPersonalMessageSignature } from "@mysten/sui/verify";
import { getAddress, verifyMessage } from "viem";

// netlify/lib/nftree-wallet-verification.ts
function normalizeSuiAddress(value) {
  const match = String(value || "").toLowerCase().match(/^0x([a-f0-9]{1,64})$/);
  return match ? `0x${match[1].padStart(64, "0")}` : null;
}

// netlify/lib/tree-nftree-overview.ts
var NFTREE_PACKAGE_ID = "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705";
var NFTREE_TYPE = `${NFTREE_PACKAGE_ID}::collection::NFT`;

// netlify/functions/nftree-wallet.ts
var GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var KIOSK_OWNER_CAP_TYPE = "0x2::kiosk::KioskOwnerCap";
var KIOSK_ITEM_SUFFIX = "::kiosk::Item";
async function graphql(query, variables, signal) {
  const result = await fetch(GRAPHQL_URL, {
    method: "POST",
    signal,
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ query, variables })
  });
  const payload = await result.json().catch(() => ({}));
  if (!result.ok || Array.isArray(payload.errors) && payload.errors.length) throw new Error("Sui GraphQL verification failed.");
  return payload.data;
}
var OWNED_OBJECTS_QUERY = `query OwnedObjects($first: Int!, $after: String, $type: String!, $owner: SuiAddress!) {
  objects(first: $first, after: $after, filter: { type: $type, owner: $owner }) {
    pageInfo { hasNextPage endCursor }
    nodes { address asMoveObject { contents { json } } }
  }
}`;
async function getOwnedObjects(owner, type, signal) {
  const nodes = [];
  const ids = /* @__PURE__ */ new Set();
  let after = null;
  for (let pageNumber = 0; pageNumber < 100; pageNumber += 1) {
    const data = await graphql(OWNED_OBJECTS_QUERY, { first: 50, after, type, owner }, signal);
    const connection = data?.objects;
    if (!Array.isArray(connection?.nodes)) throw new Error("Owned object page was unavailable.");
    for (const node of connection.nodes) {
      const id = normalizeSuiAddress(node?.address);
      if (!id || ids.has(id)) throw new Error("Owned object identities were invalid.");
      ids.add(id);
      nodes.push(node);
    }
    if (connection.pageInfo?.hasNextPage !== true) return nodes;
    after = connection.pageInfo?.endCursor || null;
    if (!after) throw new Error("Owned object scan lacked a cursor.");
  }
  throw new Error("Owned object scan did not reach its end.");
}
var KIOSK_FIELDS_QUERY = `query KioskFields($kiosk: SuiAddress!, $first: Int!, $after: String) {
  object(address: $kiosk) {
    dynamicFields(first: $first, after: $after) {
      pageInfo { hasNextPage endCursor }
      nodes { name { type { repr } json } }
    }
  }
}`;
async function getKioskItemIds(kiosk, signal) {
  const ids = /* @__PURE__ */ new Set();
  let after = null;
  for (let pageNumber = 0; pageNumber < 100; pageNumber += 1) {
    const data = await graphql(KIOSK_FIELDS_QUERY, { kiosk, first: 50, after }, signal);
    const fields = data?.object?.dynamicFields;
    if (!Array.isArray(fields?.nodes)) throw new Error("Kiosk contents were unavailable.");
    for (const node of fields.nodes) {
      if (!String(node?.name?.type?.repr || "").endsWith(KIOSK_ITEM_SUFFIX)) continue;
      const id = normalizeSuiAddress(node?.name?.json?.id);
      if (!id || ids.has(id)) throw new Error("Kiosk item identities were invalid.");
      ids.add(id);
    }
    if (fields.pageInfo?.hasNextPage !== true) return [...ids];
    after = fields.pageInfo?.endCursor || null;
    if (!after) throw new Error("Kiosk scan lacked a cursor.");
  }
  throw new Error("Kiosk scan did not reach its end.");
}
async function getObjectTypes(ids, signal) {
  const result = /* @__PURE__ */ new Map();
  const batches = [];
  for (let offset = 0; offset < ids.length; offset += 20) batches.push(ids.slice(offset, offset + 20));
  const responses = await Promise.all(batches.map(async (batch) => {
    const fields = batch.map((id, index) => `o${index}: object(address: "${id}") { asMoveObject { contents { type { repr } } } }`).join("\n");
    const data = await graphql(`query KioskItemTypes { ${fields} }`, {}, signal);
    return { batch, data };
  }));
  responses.forEach(({ batch, data }) => batch.forEach((id, index) => {
    const type = String(data?.[`o${index}`]?.asMoveObject?.contents?.type?.repr || "");
    if (!type) throw new Error("A Kiosk item type was unavailable.");
    result.set(id, type);
  }));
  return result;
}
async function getCanonicalNftreeOwnership(address) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 26e3);
  try {
    const [directNftrees, ownerCaps] = await Promise.all([
      getOwnedObjects(address, NFTREE_TYPE, controller.signal),
      getOwnedObjects(address, KIOSK_OWNER_CAP_TYPE, controller.signal)
    ]);
    const kioskIds = ownerCaps.map((cap) => normalizeSuiAddress(cap.asMoveObject?.contents?.json?.for));
    if (kioskIds.some((id) => !id) || new Set(kioskIds).size !== kioskIds.length) throw new Error("Kiosk ownership capabilities were invalid.");
    const kioskItems = (await Promise.all(kioskIds.map((id) => getKioskItemIds(id, controller.signal)))).flat();
    if (new Set(kioskItems).size !== kioskItems.length) throw new Error("Kiosk item identities overlapped.");
    const itemTypes = await getObjectTypes(kioskItems, controller.signal);
    const kioskCount = kioskItems.filter((id) => itemTypes.get(id) === NFTREE_TYPE).length;
    const directCount = directNftrees.length;
    return {
      address,
      network: "sui-mainnet",
      nftreeType: NFTREE_TYPE,
      methodology: "canonical-nftree-direct-and-kiosk-cap-v2",
      nftreeCount: directCount + kioskCount,
      directCount,
      kioskCount,
      kiosksScanned: kioskIds.length,
      kioskItemsScanned: kioskItems.length
    };
  } finally {
    clearTimeout(timeout);
  }
}

// netlify/functions/arcade-wallet-link.ts
var LINK_VERSION = 1;
var LINK_LIFETIME_MS = 7 * 24 * 60 * 60 * 1e3;
var CLOCK_SKEW_MS = 5 * 60 * 1e3;
var PURPOSE = "Link these wallets for NFTree access. No transaction or token approval.";
function json(body, status = 200) {
  return Response.json(body, {
    status,
    headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" }
  });
}
function normalizeEvmAddress(value) {
  try {
    return getAddress(String(value || "")).toLowerCase();
  } catch {
    return null;
  }
}
function requestDomain(request) {
  return new URL(request.url).host.toLowerCase();
}
function buildMessage(domain, fields) {
  return [
    "TREE Arcade Wallet Link",
    `Version: ${LINK_VERSION}`,
    `Domain: ${domain}`,
    `Sui address: ${fields.suiAddress}`,
    `EVM address: ${fields.evmAddress}`,
    `Issued at: ${fields.issuedAt}`,
    `Expires at: ${fields.expiresAt}`,
    `Nonce: ${fields.nonce}`,
    `Purpose: ${PURPOSE}`
  ].join("\n");
}
function randomHex(bytes) {
  const value = new Uint8Array(bytes);
  crypto.getRandomValues(value);
  return [...value].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function validatedFields(input, now = Date.now()) {
  const suiAddress = normalizeSuiAddress(input.suiAddress);
  const evmAddress = normalizeEvmAddress(input.evmAddress);
  const issuedAt = String(input.issuedAt || "");
  const expiresAt = String(input.expiresAt || "");
  const nonce = String(input.nonce || "").toLowerCase();
  const issuedMs = Date.parse(issuedAt);
  const expiresMs = Date.parse(expiresAt);
  if (!suiAddress || !evmAddress || !/^[a-f0-9]{64}$/.test(nonce)) return null;
  if (!Number.isFinite(issuedMs) || !Number.isFinite(expiresMs)) return null;
  if (issuedMs > now + CLOCK_SKEW_MS || issuedMs < now - LINK_LIFETIME_MS - CLOCK_SKEW_MS) return null;
  if (expiresMs <= now || expiresMs <= issuedMs || expiresMs > issuedMs + LINK_LIFETIME_MS) return null;
  return { suiAddress, evmAddress, issuedAt, expiresAt, nonce };
}
async function verifyWalletLinkSignatures(fields, message, suiSignature, evmSignature) {
  await verifyPersonalMessageSignature(new TextEncoder().encode(message), suiSignature, { address: fields.suiAddress });
  return verifyMessage({
    address: getAddress(fields.evmAddress),
    message,
    signature: evmSignature
  });
}
var arcade_wallet_link_default = async (request) => {
  if (request.method !== "POST") return json({ status: "error", error: "method-not-allowed" }, 405);
  const raw = await request.text();
  if (raw.length > 24e3) return json({ status: "error", error: "request-too-large" }, 413);
  let body;
  try {
    body = JSON.parse(raw);
  } catch {
    return json({ status: "error", error: "invalid-json" }, 400);
  }
  const domain = requestDomain(request);
  if (body.action === "challenge") {
    const suiAddress = normalizeSuiAddress(body.suiAddress);
    const evmAddress = normalizeEvmAddress(body.evmAddress);
    if (!suiAddress || !evmAddress) return json({ status: "error", error: "invalid-address" }, 400);
    const issuedAt = (/* @__PURE__ */ new Date()).toISOString();
    const expiresAt = new Date(Date.now() + LINK_LIFETIME_MS).toISOString();
    const fields2 = { suiAddress, evmAddress, issuedAt, expiresAt, nonce: randomHex(32) };
    return json({ status: "ok", fields: fields2, message: buildMessage(domain, fields2) });
  }
  if (body.action !== "verify") return json({ status: "error", error: "invalid-action" }, 400);
  const fields = validatedFields(body.fields || {});
  const message = String(body.message || "");
  const suiSignature = String(body.suiSignature || "");
  const evmSignature = String(body.evmSignature || "");
  if (!fields || message !== buildMessage(domain, fields) || !suiSignature || !/^0x[a-f0-9]+$/i.test(evmSignature)) {
    return json({ status: "error", error: "invalid-proof" }, 400);
  }
  try {
    const evmValid = await verifyWalletLinkSignatures(fields, message, suiSignature, evmSignature);
    if (!evmValid) return json({ status: "error", error: "signature-mismatch" }, 401);
  } catch (error) {
    console.error("TREE Arcade wallet-link signature verification failed:", error);
    return json({ status: "error", error: "signature-mismatch" }, 401);
  }
  try {
    const ownership = await getCanonicalNftreeOwnership(fields.suiAddress);
    if (ownership.nftreeCount < 1) {
      return json({ status: "denied", error: "nftree-required", nftreeCount: 0 }, 403);
    }
    return json({
      status: "ok",
      linked: true,
      suiAddress: fields.suiAddress,
      evmAddress: fields.evmAddress,
      nftreeCount: ownership.nftreeCount,
      verifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
      expiresAt: fields.expiresAt
    });
  } catch (error) {
    console.error("TREE Arcade linked NFTree verification failed:", error);
    return json({ status: "error", error: "nftree-verification-unavailable" }, 503);
  }
};
var config = { path: "/api/arcade-wallet-link" };
export {
  buildMessage,
  config,
  arcade_wallet_link_default as default,
  normalizeEvmAddress,
  validatedFields,
  verifyWalletLinkSignatures
};
