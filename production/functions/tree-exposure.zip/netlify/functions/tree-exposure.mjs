
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-exposure-cache.ts
import { getDeployStore, getStore } from "@netlify/blobs";

// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var TREE_DECIMALS = 6;
var TREE_TOTAL_SUPPLY_RAW = 1000000000000000n;
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));
function normalizeSuiAddress(value) {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  return SUI_ADDRESS.test(normalized) ? normalized : null;
}

// netlify/lib/sui-graphql-leaderboard-provider.ts
function formatBaseUnits(raw, coinDecimals) {
  const negative = raw < 0n;
  const absolute = negative ? -raw : raw;
  const base = 10n ** BigInt(coinDecimals);
  const whole = absolute / base;
  const fraction = (absolute % base).toString().padStart(coinDecimals, "0").replace(/0+$/, "");
  return `${negative ? "-" : ""}${whole.toString()}${fraction ? `.${fraction}` : ""}`;
}
function formatPercentFromRaw(raw, total, precision = 9) {
  if (total <= 0n) return "0";
  const scale = 10n ** BigInt(precision);
  const scaled = raw * 100n * scale / total;
  return formatBaseUnits(scaled, precision);
}

// netlify/lib/tree-exposure-types.ts
var TREE_EXPOSURE_METHODOLOGY_VERSION = "verified-tree-exposure-v1";
var LP_PROVIDER_BADGE = "lp-provider";
var LP_MAXI_BADGE = "lp-maxi";
var DIAMOND_HANDS_BADGE = "diamond-hands";
var PAPER_HANDS_BADGE = "paper-hands";
var ACCUMULATOR_BADGE = "accumulator";
var BURNED_BADGE = "burned";
function formatTreeRaw(raw) {
  return formatBaseUnits(raw, TREE_DECIMALS);
}
function formatTreeSupplyPercent(raw) {
  return formatPercentFromRaw(raw, TREE_TOTAL_SUPPLY_RAW);
}
function parseUnsignedRaw(value) {
  if (typeof value !== "string" || !/^\d+$/.test(value)) return null;
  try {
    return BigInt(value);
  } catch {
    return null;
  }
}

// netlify/lib/tree-exposure-cache.ts
var EXPOSURE_STORE_NAME = "tree-exposure";
var COMPLETE_EXPOSURE_SNAPSHOT_KEY = "complete";
var EXPOSURE_REFRESH_STATUS_KEY = "refresh-status";
var EXPOSURE_REFRESH_LOCK_TTL_MS = 30 * 60 * 1e3;
var EXPOSURE_SNAPSHOT_PROVIDER = "tree-exposure-snapshot";
var defaultFactories = {
  getStore: (name, options) => getStore(name, options),
  getDeployStore: (name) => getDeployStore(name)
};
function selectExposureStore(context, factories = defaultFactories) {
  return context === "production" ? factories.getStore(EXPOSURE_STORE_NAME, { consistency: "strong" }) : factories.getDeployStore(EXPOSURE_STORE_NAME);
}
function resolveStore(options) {
  return options.store ?? selectExposureStore(options.context);
}
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function safeNonNegativeInteger(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function safeGeneratedAt(value) {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}
function safeSuinsName(value) {
  return value === null || typeof value === "string" && value.trim() === value && value.length > 0 && value.length <= 255 && !/[\u0000-\u001f\u007f]/.test(value);
}
function expectedBadges(liquidRaw, lpRaw, entry) {
  const badges = [];
  if (lpRaw > 0n) badges.push(LP_PROVIDER_BADGE);
  if (lpRaw > liquidRaw && lpRaw > 0n) badges.push(LP_MAXI_BADGE);
  if (entry.activity30d !== void 0 && entry.activity30d !== null) {
    const activity = record(entry.activity30d);
    const buyRaw = parseUnsignedRaw(activity.buyTreeRaw);
    const sellRaw = parseUnsignedRaw(activity.sellTreeRaw);
    if (buyRaw === null || sellRaw === null || !safeNonNegativeInteger(activity.buyCount) || !safeNonNegativeInteger(activity.sellCount) || !safeGeneratedAt(activity.windowStart) || !safeGeneratedAt(activity.windowEnd) || activity.buyTree !== formatTreeRaw(buyRaw) || activity.sellTree !== formatTreeRaw(sellRaw)) return null;
    if (activity.sellCount === 0) badges.push(DIAMOND_HANDS_BADGE);
    if (sellRaw > buyRaw && sellRaw >= 100000000000n) badges.push(PAPER_HANDS_BADGE);
    if (activity.buyCount >= 10 && buyRaw >= 100000000000n && buyRaw > sellRaw) badges.push(ACCUMULATOR_BADGE);
  }
  if (entry.burnedTreeRaw !== void 0 && entry.burnedTreeRaw !== null) {
    const burnedRaw = parseUnsignedRaw(entry.burnedTreeRaw);
    if (burnedRaw === null || entry.burnedTree !== formatTreeRaw(burnedRaw)) return null;
    if (burnedRaw >= 500000000000n) badges.push(BURNED_BADGE);
  } else if (entry.burnedTree !== void 0 && entry.burnedTree !== null) return null;
  return badges;
}
function validateEntry(value, expectedRank) {
  const entry = record(value);
  const wallet = normalizeSuiAddress(entry.wallet);
  if (!wallet || wallet !== entry.wallet || entry.rank !== expectedRank || !safeSuinsName(entry.suinsName)) return false;
  const liquidRaw = parseUnsignedRaw(entry.liquidTreeRaw);
  const lpRaw = parseUnsignedRaw(entry.lpTreeRaw);
  const totalRaw = parseUnsignedRaw(entry.totalExposureRaw);
  const breakdown = record(entry.lpBreakdown);
  const v2Raw = parseUnsignedRaw(breakdown.suiDexV2Raw);
  const v3Raw = parseUnsignedRaw(breakdown.suiDexV3Raw);
  const turbosRaw = parseUnsignedRaw(breakdown.turbosRaw);
  if (liquidRaw === null || lpRaw === null || totalRaw === null || v2Raw === null || v3Raw === null || turbosRaw === null || totalRaw <= 0n || totalRaw > TREE_TOTAL_SUPPLY_RAW || lpRaw !== v2Raw + v3Raw + turbosRaw || totalRaw !== liquidRaw + lpRaw) return false;
  if (entry.liquidTree !== formatTreeRaw(liquidRaw) || entry.lpTree !== formatTreeRaw(lpRaw) || entry.totalExposure !== formatTreeRaw(totalRaw) || entry.supplyPercent !== formatTreeSupplyPercent(totalRaw) || breakdown.suiDexV2 !== formatTreeRaw(v2Raw) || breakdown.suiDexV3 !== formatTreeRaw(v3Raw) || breakdown.turbos !== formatTreeRaw(turbosRaw) || !safeNonNegativeInteger(entry.liquidCoinObjectCount) || !safeNonNegativeInteger(entry.lpPositionCount)) return false;
  const badges = Array.isArray(entry.badges) ? entry.badges : [];
  const expected = expectedBadges(liquidRaw, lpRaw, entry);
  if (!expected) return false;
  return badges.length === expected.length && badges.every((badge, index) => badge === expected[index]);
}
function validateSource(snapshot) {
  const source = record(snapshot.source);
  const direct = record(source.direct);
  if (direct.outcome !== "complete" || !safeNonNegativeInteger(direct.pagesScanned) || !safeNonNegativeInteger(direct.objectsScanned) || !safeNonNegativeInteger(direct.verifiedAddressOwners) || !safeNonNegativeInteger(direct.eligibleDirectOwners) || !safeNonNegativeInteger(direct.exposureCandidateCount) || direct.exposureCandidateCount !== direct.eligibleDirectOwners || parseUnsignedRaw(direct.addressOwnedRaw) === null) return false;
  const venues = record(source.venues);
  for (const venue of ["suiDexV2", "suiDexV3", "turbos"]) {
    const summary = record(venues[venue]);
    if (summary.outcome !== "complete" || !safeNonNegativeInteger(summary.walletCount) || !safeNonNegativeInteger(summary.positionCount) || parseUnsignedRaw(summary.principalTreeRaw) === null || !Array.isArray(summary.warnings) || !summary.warnings.every((warning) => typeof warning === "string") || !summary.coverage || typeof summary.coverage !== "object") return false;
  }
  const suins = record(source.suins);
  return safeNonNegativeInteger(suins.requestedCount) && safeNonNegativeInteger(suins.resolvedCount) && suins.resolvedCount <= suins.requestedCount && typeof suins.complete === "boolean" && safeGeneratedAt(suins.generatedAt) && Array.isArray(suins.warnings) && suins.warnings.every((warning) => typeof warning === "string");
}
function validateCompleteExposureSnapshot(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const snapshot = value;
  if (snapshot.outcome !== "complete" || snapshot.provider !== EXPOSURE_SNAPSHOT_PROVIDER || snapshot.methodologyVersion !== TREE_EXPOSURE_METHODOLOGY_VERSION || !safeGeneratedAt(snapshot.generatedAt) || snapshot.coinSymbol !== "TREE" || snapshot.coinDecimals !== TREE_DECIMALS || snapshot.totalSupplyRaw !== TREE_TOTAL_SUPPLY_RAW.toString() || snapshot.displayedCount !== 50 || !Array.isArray(snapshot.entries) || snapshot.entries.length !== 50 || !safeNonNegativeInteger(snapshot.eligibleOwnerCount) || snapshot.eligibleOwnerCount < 50 || snapshot.coverage?.directTreeComplete !== true || snapshot.coverage?.suiDexV2Complete !== true || snapshot.coverage?.suiDexV3Complete !== true || snapshot.coverage?.turbosComplete !== true || snapshot.coverage?.totalExposureComplete !== true || !Array.isArray(snapshot.warnings) || !snapshot.warnings.every((warning) => typeof warning === "string")) return false;
  const wallets = /* @__PURE__ */ new Set();
  let top50TotalRaw = 0n;
  let top50LiquidRaw = 0n;
  let top50LpRaw = 0n;
  let lpProvider = 0;
  let lpMaxi = 0;
  let diamondHands = 0;
  let paperHands = 0;
  let accumulator = 0;
  let burned = 0;
  let previousTotalRaw = null;
  let previousLiquidRaw = null;
  let previousWallet = null;
  for (let index = 0; index < snapshot.entries.length; index += 1) {
    const entry = snapshot.entries[index];
    if (!validateEntry(entry, index + 1) || wallets.has(entry.wallet)) return false;
    const currentTotalRaw = BigInt(entry.totalExposureRaw);
    const currentLiquidRaw = BigInt(entry.liquidTreeRaw);
    if (previousTotalRaw !== null && previousLiquidRaw !== null && previousWallet !== null) {
      if (currentTotalRaw > previousTotalRaw || currentTotalRaw === previousTotalRaw && currentLiquidRaw > previousLiquidRaw || currentTotalRaw === previousTotalRaw && currentLiquidRaw === previousLiquidRaw && entry.wallet.localeCompare(previousWallet) < 0) return false;
    }
    previousTotalRaw = currentTotalRaw;
    previousLiquidRaw = currentLiquidRaw;
    previousWallet = entry.wallet;
    wallets.add(entry.wallet);
    top50TotalRaw += currentTotalRaw;
    top50LiquidRaw += currentLiquidRaw;
    top50LpRaw += BigInt(entry.lpTreeRaw);
    if (entry.badges.includes(LP_PROVIDER_BADGE)) lpProvider += 1;
    if (entry.badges.includes(LP_MAXI_BADGE)) lpMaxi += 1;
    if (entry.badges.includes(DIAMOND_HANDS_BADGE)) diamondHands += 1;
    if (entry.badges.includes(PAPER_HANDS_BADGE)) paperHands += 1;
    if (entry.badges.includes(ACCUMULATOR_BADGE)) accumulator += 1;
    if (entry.badges.includes(BURNED_BADGE)) burned += 1;
  }
  if (top50TotalRaw > TREE_TOTAL_SUPPLY_RAW) return false;
  const summary = record(snapshot.summary);
  const badgeCounts = record(summary.badgeCounts);
  return summary.top50TotalRaw === top50TotalRaw.toString() && summary.top50LiquidRaw === top50LiquidRaw.toString() && summary.top50LpRaw === top50LpRaw.toString() && summary.rank50CutoffRaw === snapshot.entries[49].totalExposureRaw && badgeCounts.lpProvider === lpProvider && badgeCounts.lpMaxi === lpMaxi && (badgeCounts.diamondHands === void 0 || badgeCounts.diamondHands === diamondHands) && (badgeCounts.paperHands === void 0 || badgeCounts.paperHands === paperHands) && (badgeCounts.accumulator === void 0 || badgeCounts.accumulator === accumulator) && (badgeCounts.burned === void 0 || badgeCounts.burned === burned) && validateSource(snapshot);
}
async function readCompleteExposureSnapshot(options = {}) {
  const value = await resolveStore(options).get(COMPLETE_EXPOSURE_SNAPSHOT_KEY, { type: "json" });
  return validateCompleteExposureSnapshot(value) ? value : null;
}
async function readExposureRefreshStatus(options = {}) {
  const value = await resolveStore(options).get(EXPOSURE_REFRESH_STATUS_KEY, { type: "json" });
  return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}

// netlify/lib/suins-name-resolver.ts
var DEFAULT_SUINS_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var MAX_SUINS_NAMES_PER_REQUEST = 50;
var MAX_SUINS_NAMES_PER_GRAPHQL_BATCH = 20;
var DEFAULT_SUINS_CONCURRENCY = 8;
function record2(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function safeName(value) {
  if (typeof value !== "string") return null;
  const name = value.trim();
  if (!name || name.length > 255 || /[\u0000-\u001f\u007f]/.test(name)) return null;
  return name;
}
function errorMessage(error) {
  return error instanceof Error ? error.message : String(error || "Unknown SuiNS resolution error");
}
function isExpectedMissingName(error) {
  const source = error && typeof error === "object" ? error : {};
  if (source.code === 5 || source.status === 5 || source.code === "NOT_FOUND" || source.status === "NOT_FOUND") return true;
  const rawMessage = errorMessage(error).toLowerCase();
  let message = rawMessage;
  try {
    message = decodeURIComponent(rawMessage.replace(/\+/g, " "));
  } catch {
  }
  return message.includes("not_found") || message.includes("not found") || message.includes("name has expired") || message.includes("name does not exist");
}
function withTimeout(promise, timeoutMs) {
  if (timeoutMs <= 0) return Promise.reject(new Error("SuiNS resolution timed out."));
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("SuiNS resolution timed out.")), timeoutMs);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}
function graphqlErrors(value) {
  if (!Array.isArray(value)) return [];
  return value.map((item) => {
    const message = record2(item).message;
    return typeof message === "string" && message ? message : "Unknown SuiNS GraphQL error";
  });
}
function buildDefaultSuinsQuery(addresses) {
  const definitions = addresses.map((_, index) => `$address${index}: SuiAddress!`).join(", ");
  const fields = addresses.map((_, index) => `name${index}: address(address: $address${index}) { defaultNameRecord { domain } }`).join("\n");
  return {
    query: `query ResolveDefaultSuinsNames(${definitions}) {
${fields}
}`,
    variables: Object.fromEntries(addresses.map((address, index) => [`address${index}`, address]))
  };
}
async function resolveWithGraphql(normalized, names, options) {
  const controller = new AbortController();
  const externalAbort = () => controller.abort();
  options.abortSignal?.addEventListener("abort", externalAbort, { once: true });
  if (options.abortSignal?.aborted) controller.abort();
  const timeout = setTimeout(() => controller.abort(), Math.max(1e3, options.timeoutMs ?? 15e3));
  let networkError = null;
  const errors = [];
  try {
    const batches = Array.from(
      { length: Math.ceil(normalized.length / MAX_SUINS_NAMES_PER_GRAPHQL_BATCH) },
      (_, index) => normalized.slice(
        index * MAX_SUINS_NAMES_PER_GRAPHQL_BATCH,
        (index + 1) * MAX_SUINS_NAMES_PER_GRAPHQL_BATCH
      )
    );
    const results = await Promise.all(batches.map(async (batch) => {
      const response = await (options.fetchImpl || fetch)(options.endpoint || DEFAULT_SUINS_GRAPHQL_URL, {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify(buildDefaultSuinsQuery(batch)),
        signal: controller.signal
      });
      if (!response.ok) return { errors: [], networkError: `SuiNS GraphQL returned HTTP ${response.status}` };
      const payload = record2(await response.json());
      const batchErrors = graphqlErrors(payload.errors);
      const data = record2(payload.data);
      batch.forEach((address, index) => {
        const nameRecord = record2(record2(data[`name${index}`]).defaultNameRecord);
        names[address] = safeName(nameRecord.domain);
      });
      return { errors: batchErrors, networkError: null };
    }));
    results.forEach((result) => {
      errors.push(...result.errors);
      networkError ||= result.networkError;
    });
  } catch (error) {
    networkError = controller.signal.aborted ? "SuiNS resolution timed out." : errorMessage(error);
  } finally {
    clearTimeout(timeout);
    options.abortSignal?.removeEventListener("abort", externalAbort);
  }
  return { errors, networkError };
}
async function resolveWithInjectedClient(normalized, names, options) {
  const now = options.now ?? Date.now;
  const client = options.client ?? options.clientFactory?.(options.endpoint || DEFAULT_SUINS_GRAPHQL_URL);
  if (!client) return { errors: ["SuiNS client is unavailable."], networkError: "SuiNS client is unavailable." };
  const deadline = now() + Math.max(1e3, options.timeoutMs ?? 15e3);
  const concurrency = Math.max(1, Math.min(16, Math.trunc(options.concurrency ?? DEFAULT_SUINS_CONCURRENCY)));
  const unexpectedErrors = [];
  let cursor = 0;
  async function worker() {
    while (cursor < normalized.length) {
      if (options.abortSignal?.aborted) {
        unexpectedErrors.push("SuiNS resolution aborted.");
        return;
      }
      const current = cursor;
      cursor += 1;
      const address = normalized[current];
      try {
        const response = await withTimeout(client.core.defaultNameServiceName({ address }), deadline - now());
        let name = safeName(response?.name);
        if (!name && client.nameService?.reverseLookupName) {
          const reverse = await withTimeout(client.nameService.reverseLookupName({ address }), deadline - now());
          name = safeName(reverse?.response?.record?.name);
        }
        names[address] = name;
      } catch (error) {
        if (isExpectedMissingName(error)) {
          names[address] = null;
          continue;
        }
        unexpectedErrors.push(errorMessage(error));
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, normalized.length) }, () => worker()));
  const errors = [...new Set(unexpectedErrors)].slice(0, 10);
  return { errors, networkError: errors[0] || null };
}
async function resolveDefaultSuinsNames(addresses, options = {}) {
  const normalized = [...new Set(addresses.map(normalizeSuiAddress).filter((value) => Boolean(value)))].slice(0, MAX_SUINS_NAMES_PER_REQUEST);
  const names = Object.fromEntries(normalized.map((address) => [address, null]));
  const now = options.now ?? Date.now;
  const generatedAt = new Date(now()).toISOString();
  if (!normalized.length) {
    return { names, requestedCount: 0, resolvedCount: 0, complete: true, graphqlErrors: [], networkError: null, generatedAt };
  }
  const result = options.client || options.clientFactory ? await resolveWithInjectedClient(normalized, names, options) : await resolveWithGraphql(normalized, names, options);
  const resolvedCount = Object.values(names).filter(Boolean).length;
  const errors = [...result.errors];
  if (normalized.length >= 10 && resolvedCount === 0 && errors.length === 0 && !result.networkError) {
    errors.push(`SuiNS reverse lookup returned zero names for ${normalized.length} addresses.`);
  }
  const uniqueErrors = [...new Set(errors)].slice(0, 10);
  const networkError = result.networkError || uniqueErrors[0] || null;
  return {
    names,
    requestedCount: normalized.length,
    resolvedCount,
    complete: !networkError && uniqueErrors.length === 0,
    graphqlErrors: uniqueErrors,
    networkError,
    generatedAt
  };
}

// netlify/lib/tree-exposure-snapshot-endpoint.ts
var DEFAULT_EXPOSURE_STALE_AFTER_MS = 6 * 60 * 60 * 1e3;
function productionEnabled(getEnv) {
  return (getEnv("TREE_EXPOSURE_PRODUCTION_ENABLED") || "").trim().toLowerCase() === "true";
}
function readStaleAfterMs(getEnv) {
  const value = getEnv("TREE_EXPOSURE_STALE_AFTER_MS");
  if (!value || !/^\d+$/.test(value.trim())) return DEFAULT_EXPOSURE_STALE_AFTER_MS;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= 6e4 && parsed <= 7 * 24 * 60 * 60 * 1e3 ? parsed : DEFAULT_EXPOSURE_STALE_AFTER_MS;
}
function publicRefreshStatus(status) {
  if (!status) return null;
  return {
    state: status.state,
    stage: status.stage,
    startedAt: status.startedAt,
    updatedAt: status.updatedAt,
    completedAt: status.completedAt,
    directPagesScanned: status.directPagesScanned,
    directObjectsScanned: status.directObjectsScanned,
    directUniqueOwners: status.directUniqueOwners,
    venueOutcomes: { ...status.venueOutcomes },
    totalExposureComplete: status.totalExposureComplete,
    displayedCount: status.displayedCount,
    message: status.message
  };
}
async function resolveExposureSnapshotPayload(dependencies = {}) {
  const now = dependencies.now ?? Date.now;
  const getEnv = dependencies.getEnv ?? ((name) => Netlify.env.get(name));
  const context = dependencies.context || "dev";
  if (context === "production" && !productionEnabled(getEnv)) {
    return {
      status: "disabled",
      provider: EXPOSURE_SNAPSHOT_PROVIDER,
      generatedAt: new Date(now()).toISOString(),
      methodologyVersion: TREE_EXPOSURE_METHODOLOGY_VERSION,
      message: "TREE exposure preview is not enabled in production."
    };
  }
  const readSnapshot = dependencies.readSnapshot ?? (() => readCompleteExposureSnapshot({ context }));
  const readStatus = dependencies.readRefreshStatus ?? (() => readExposureRefreshStatus({ context }));
  const [snapshot, storedStatus] = await Promise.all([readSnapshot(), readStatus()]);
  const refreshStatus = publicRefreshStatus(storedStatus);
  const refreshState = refreshStatus?.state ?? "idle";
  const responseGeneratedAt = new Date(now()).toISOString();
  if (!snapshot) {
    const refreshing = refreshState === "queued" || refreshState === "running";
    return {
      status: refreshing ? "refreshing" : "not-ready",
      provider: EXPOSURE_SNAPSHOT_PROVIDER,
      generatedAt: responseGeneratedAt,
      snapshotGeneratedAt: null,
      snapshotAgeMs: null,
      refreshState,
      refreshStatus,
      methodologyVersion: TREE_EXPOSURE_METHODOLOGY_VERSION,
      coinSymbol: "TREE",
      coinDecimals: 6,
      totalSupplyRaw: "1000000000000000",
      coverage: null,
      eligibleOwnerCount: null,
      displayedCount: 0,
      source: null,
      summary: null,
      entries: [],
      warnings: refreshState === "verification-incomplete" || refreshState === "error" ? ["The latest exposure refresh did not produce a complete verified snapshot."] : [],
      message: refreshing ? "Building the first complete verified Liquid TREE plus LP snapshot." : "A complete verified TREE exposure snapshot is not available yet."
    };
  }
  const snapshotAgeMs = Math.max(0, now() - Date.parse(snapshot.generatedAt));
  const stale = snapshotAgeMs > readStaleAfterMs(getEnv);
  let entries = snapshot.entries;
  let source = snapshot.source;
  const identityWarnings = [];
  const snapshotHasResolvedNames = entries.some((entry) => Boolean(entry.suinsName));
  if (!snapshotHasResolvedNames && entries.length) {
    try {
      const resolution = await (dependencies.resolveNames ?? resolveDefaultSuinsNames)(
        entries.map((entry) => entry.wallet)
      );
      entries = entries.map((entry) => ({
        ...entry,
        suinsName: resolution.names[entry.wallet] || null
      }));
      const warning = resolution.complete ? [] : ["Some current SuiNS names could not be resolved."];
      source = {
        ...snapshot.source,
        suins: {
          requestedCount: resolution.requestedCount,
          resolvedCount: resolution.resolvedCount,
          complete: resolution.complete,
          generatedAt: resolution.generatedAt,
          warnings: warning
        }
      };
      identityWarnings.push(...warning);
    } catch {
      identityWarnings.push("Current SuiNS identity enrichment was temporarily unavailable.");
    }
  }
  return {
    status: stale ? "stale" : "ok",
    provider: snapshot.provider,
    generatedAt: responseGeneratedAt,
    snapshotGeneratedAt: snapshot.generatedAt,
    snapshotAgeMs,
    refreshState,
    refreshStatus,
    methodologyVersion: snapshot.methodologyVersion,
    coinSymbol: snapshot.coinSymbol,
    coinDecimals: snapshot.coinDecimals,
    totalSupplyRaw: snapshot.totalSupplyRaw,
    coverage: snapshot.coverage,
    eligibleOwnerCount: snapshot.eligibleOwnerCount,
    displayedCount: snapshot.displayedCount,
    source,
    summary: snapshot.summary,
    entries,
    warnings: [
      ...snapshot.warnings,
      ...identityWarnings,
      ...stale ? [`Displayed exposure rows are from the last complete snapshot at ${snapshot.generatedAt}.`] : []
    ],
    message: stale ? "Showing the last complete verified TREE exposure snapshot." : "Showing the current complete verified TREE exposure snapshot."
  };
}
async function createExposureSnapshotResponse(request, dependencies = {}) {
  if (request.method !== "GET") {
    return Response.json(
      { error: "method-not-allowed" },
      { status: 405, headers: { Allow: "GET", "Cache-Control": "no-store" } }
    );
  }
  try {
    const payload = await resolveExposureSnapshotPayload(dependencies);
    if (payload.status === "disabled") {
      return Response.json(payload, { status: 404, headers: { "Cache-Control": "no-store" } });
    }
    const cacheable = payload.status === "ok" || payload.status === "stale";
    return Response.json(payload, {
      headers: {
        "Cache-Control": cacheable ? "public, max-age=15, s-maxage=30, stale-while-revalidate=60" : "no-store"
      }
    });
  } catch {
    return Response.json({
      status: "error",
      provider: EXPOSURE_SNAPSHOT_PROVIDER,
      generatedAt: new Date((dependencies.now ?? Date.now)()).toISOString(),
      snapshotGeneratedAt: null,
      snapshotAgeMs: null,
      refreshState: "error",
      refreshStatus: null,
      methodologyVersion: TREE_EXPOSURE_METHODOLOGY_VERSION,
      coinSymbol: "TREE",
      coinDecimals: 6,
      totalSupplyRaw: "1000000000000000",
      coverage: null,
      eligibleOwnerCount: null,
      displayedCount: 0,
      source: null,
      summary: null,
      entries: [],
      warnings: ["The verified TREE exposure snapshot is temporarily unavailable."],
      message: "TREE exposure preview unavailable."
    }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}

// netlify/functions/tree-exposure.ts
async function handleTreeExposureRequest(request, context, createResponse = createExposureSnapshotResponse) {
  return createResponse(request, {
    context: context?.deploy?.context || "dev"
  });
}
var tree_exposure_default = async (request, context) => handleTreeExposureRequest(request, context);
var config = { path: "/api/tree-exposure" };
export {
  config,
  tree_exposure_default as default,
  handleTreeExposureRequest
};
