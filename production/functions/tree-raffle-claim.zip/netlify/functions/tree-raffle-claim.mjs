
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/tree-raffle-core.ts
var TREE_RAFFLE_RULES_VERSION = "canopy-draw-proposal-v2";
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_RAFFLE_WBTC_TYPE = "0xaafb102dd0902f5055cadecd687fb5b71ca82ef0e0285d90afde828ec58ca96b::btc::BTC";
var TREE_RAFFLE_DAILY_PRIZE = Object.freeze({
  symbol: "TREE",
  coinType: TREE_COIN_TYPE,
  amountRaw: "50000000000",
  decimals: 6
});
var TREE_RAFFLE_DAILY_LUCKY_LEAF_PLAN = Object.freeze({
  symbol: "wBTC",
  coinType: TREE_RAFFLE_WBTC_TYPE,
  decimals: 8,
  mondayThroughSaturdayUsdCents: 250,
  sundayUsdCents: 1e3,
  weeklyBudgetUsdCents: 2500
});
var TREE_RAFFLE_STREAK_MULTIPLIERS_BASIS_POINTS = Object.freeze([
  1e4,
  11e3,
  12500,
  14e3,
  15e3,
  16e3,
  17500,
  18500,
  19500,
  2e4,
  21e3,
  22e3,
  23e3,
  24e3,
  25e3
]);
var TREE_RAFFLE_RULES = Object.freeze({
  version: TREE_RAFFLE_RULES_VERSION,
  status: "development",
  acceptingEntries: false,
  claimsEnabled: false,
  prizesFunded: false,
  dailyEnabled: true,
  dailyLuckyLeafEnabled: false,
  weeklyEnabled: false,
  minimumQualifyingUsdCents: 500,
  ticketExponent: 0.9457,
  ticketCoefficient: 0.288368,
  luckyLeafTicketsPerQualifyingTransaction: 1,
  maxStreakDays: 15,
  maxStreakMultiplierBasisPoints: 25e3,
  streakMultipliersBasisPoints: TREE_RAFFLE_STREAK_MULTIPLIERS_BASIS_POINTS,
  milestoneBonusUsdCents: Object.freeze({ 7: 5e3, 15: 2e4 }),
  schedule: Object.freeze({
    timezone: "America/New_York",
    daily: "10:00",
    weekly: "Sunday 10:05"
  }),
  prizes: Object.freeze({
    dailyMain: TREE_RAFFLE_DAILY_PRIZE,
    dailyLuckyLeafPlan: TREE_RAFFLE_DAILY_LUCKY_LEAF_PLAN,
    weeklyMain: null,
    weeklyLuckyLeaf: null
  }),
  eligibleTransaction: Object.freeze({
    network: "sui-mainnet",
    direction: "SUI_TO_TREE",
    requiresSuccessfulFinalizedTransaction: true,
    allowlistedRoutesRequired: true
  })
});
function parseBooleanEnv(value, fallback = false) {
  if (value === void 0 || value === null) return fallback;
  const normalized = String(value).trim().toLowerCase();
  return normalized === "1" || normalized === "true" || normalized === "yes" || normalized === "on";
}
function treeRaffleRulesForEnvironment(env = process.env) {
  return {
    ...TREE_RAFFLE_RULES,
    acceptingEntries: parseBooleanEnv(env.TREE_RAFFLE_ACCEPTING_ENTRIES, TREE_RAFFLE_RULES.acceptingEntries),
    claimsEnabled: parseBooleanEnv(env.TREE_RAFFLE_CLAIMS_ENABLED, TREE_RAFFLE_RULES.claimsEnabled),
    prizesFunded: parseBooleanEnv(env.TREE_RAFFLE_PRIZES_FUNDED, TREE_RAFFLE_RULES.prizesFunded),
    dailyEnabled: parseBooleanEnv(env.TREE_RAFFLE_DAILY_ENABLED, TREE_RAFFLE_RULES.dailyEnabled),
    dailyLuckyLeafEnabled: parseBooleanEnv(
      env.TREE_RAFFLE_DAILY_LUCKY_ENABLED,
      TREE_RAFFLE_RULES.dailyLuckyLeafEnabled
    ),
    weeklyEnabled: parseBooleanEnv(env.TREE_RAFFLE_WEEKLY_ENABLED, TREE_RAFFLE_RULES.weeklyEnabled)
  };
}
function raffleLaunchBlockers(rules = TREE_RAFFLE_RULES) {
  const blockers = [
    !rules.prizesFunded && "The prize pool must be funded and prizes reserved before rounds open.",
    !rules.claimsEnabled && "The prize claim path is disabled.",
    !rules.acceptingEntries && "Entry recording is disabled."
  ];
  return blockers.filter((value) => Boolean(value));
}
function raffleOperationalReadiness(env = process.env, rules = treeRaffleRulesForEnvironment(env)) {
  const transactionalLedgerConfigured = Boolean(
    (env.TREE_RAFFLE_SUPABASE_URL || "").trim() && (env.TREE_RAFFLE_SUPABASE_SECRET_KEY || "").trim()
  );
  const onchainPrizePoolConfigured = Boolean(
    (env.TREE_RAFFLE_PACKAGE_ID || "").trim() && (env.TREE_RAFFLE_PRIZE_POOL_ID || "").trim() && (env.TREE_RAFFLE_OPERATOR_CAP_ID || "").trim()
  );
  const drawExecutorConfigured = env.TREE_RAFFLE_DRAW_EXECUTOR_READY === "true" && onchainPrizePoolConfigured;
  const verifiedBuyIngestionEnabled = Boolean(
    env.TREE_RAFFLE_INGEST_ENABLED === "true" && (rules.dailyEnabled || rules.weeklyEnabled) && rules.acceptingEntries && rules.claimsEnabled && rules.prizesFunded && transactionalLedgerConfigured && drawExecutorConfigured
  );
  const infrastructureBlockers = [
    !transactionalLedgerConfigured && "The transactional raffle ledger is not connected.",
    !onchainPrizePoolConfigured && "The on-chain prize pool is not published and configured.",
    !drawExecutorConfigured && "The verifiable draw executor is not ready."
  ].filter((value) => Boolean(value));
  return {
    transactionalLedgerConfigured,
    onchainPrizePoolConfigured,
    drawExecutorConfigured,
    verifiedBuyIngestionEnabled,
    launchBlockers: [...raffleLaunchBlockers(rules), ...infrastructureBlockers]
  };
}

// netlify/lib/tree-raffle-draw-audit.ts
import { createHash } from "node:crypto";
var TREE_RAFFLE_SELECTION_SCHEME = "wallet-asc-cumulative-v1";
var TREE_RAFFLE_LEDGER_COMMITMENT_VERSION = "tree-raffle-ledger-v1";
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var DRAW_ID = /^[a-z0-9][a-z0-9:_-]{2,95}$/;
function unsigned(value, label) {
  if (!/^(0|[1-9][0-9]*)$/.test(value)) throw new Error(`Invalid TREE raffle ${label}.`);
  return BigInt(value);
}
function validateTreeRaffleTicketRanges(onchainDrawId, ranges) {
  if (!DRAW_ID.test(onchainDrawId)) throw new Error("Invalid TREE raffle on-chain draw ID.");
  if (!Array.isArray(ranges) || ranges.length === 0) throw new Error("TREE raffle ticket ranges are empty.");
  let cursor = 0n;
  let previousWallet = "";
  const seen = /* @__PURE__ */ new Set();
  for (const range of ranges) {
    if (!SUI_ADDRESS.test(range.wallet)) throw new Error("Invalid TREE raffle ticket wallet.");
    if (seen.has(range.wallet) || range.wallet <= previousWallet) {
      throw new Error("TREE raffle ticket wallets must be unique and sorted ascending.");
    }
    seen.add(range.wallet);
    previousWallet = range.wallet;
    const tickets = unsigned(range.tickets, "ticket count");
    const start = unsigned(range.start, "range start");
    const endExclusive = unsigned(range.endExclusive, "range end");
    if (tickets <= 0n || start !== cursor || endExclusive !== start + tickets) {
      throw new Error("TREE raffle ticket ranges must be positive and contiguous.");
    }
    cursor = endExclusive;
  }
  return cursor;
}
function canonicalTreeRaffleLedger(onchainDrawId, ranges) {
  validateTreeRaffleTicketRanges(onchainDrawId, ranges);
  const rows = ranges.map((range) => `${range.wallet}:${range.tickets}:${range.start}:${range.endExclusive}`);
  return `${TREE_RAFFLE_LEDGER_COMMITMENT_VERSION}
${onchainDrawId}
${rows.join("\n")}`;
}
function treeRaffleLedgerCommitment(onchainDrawId, ranges) {
  return createHash("sha256").update(canonicalTreeRaffleLedger(onchainDrawId, ranges), "utf8").digest("hex");
}

// netlify/lib/tree-raffle-sui-draw.ts
var SUI_ID = /^0x[0-9a-fA-F]{1,64}$/;
var SUI_ADDRESS2 = /^0x[0-9a-f]{64}$/;
var SUI_DIGEST = /^[1-9A-HJ-NP-Za-km-z]{40,64}$/;
var U64_MAX = 18446744073709551615n;
function suiId(value, label) {
  if (!SUI_ID.test(value)) throw new Error(`Invalid TREE raffle ${label}.`);
  return value.toLowerCase();
}
function u64(value, label) {
  if (!/^(0|[1-9][0-9]*)$/.test(value)) throw new Error(`Invalid TREE raffle ${label}.`);
  const parsed = BigInt(value);
  if (parsed > U64_MAX) throw new Error(`Invalid TREE raffle ${label}.`);
  return parsed;
}
function byteArray(value, label) {
  if (Array.isArray(value) && value.every((byte) => Number.isInteger(byte) && byte >= 0 && byte <= 255)) {
    return value;
  }
  if (typeof value === "string" && value.length > 0 && value.length % 4 === 0 && /^[A-Za-z0-9+/]*={0,2}$/.test(value)) {
    const decoded = Buffer.from(value, "base64");
    if (decoded.toString("base64") === value) return [...decoded];
  }
  throw new Error(`Sui returned an invalid TREE raffle ${label}.`);
}
function normalizedSuiId(value) {
  return `0x${value.slice(2).toLowerCase().replace(/^0+/, "") || "0"}`;
}
function verifyTreeRaffleClaimTransaction(input) {
  const tx = input.transaction;
  const digest = tx?.digest ?? tx?.transaction?.digest;
  const status = tx?.effects?.status?.status ?? tx?.effects?.status ?? tx?.transaction?.effects?.status?.status;
  if (!SUI_DIGEST.test(String(digest || "")) || status !== "success") {
    throw new Error("TREE raffle claim transaction did not finalize successfully.");
  }
  if (!SUI_ADDRESS2.test(input.wallet) || !input.tokenType.includes("::")) {
    throw new Error("Invalid TREE raffle expected claim values.");
  }
  const expectedAmount = u64(input.amountRaw, "prize amount");
  const packageId = normalizedSuiId(suiId(input.packageId, "package ID"));
  const events = Array.isArray(tx?.events) ? tx.events : [];
  const matches = events.filter((event2) => {
    const type = String(event2?.type || "");
    const separator = type.indexOf("::");
    if (separator < 0) return false;
    const eventPackage = type.slice(0, separator);
    return SUI_ID.test(eventPackage) && normalizedSuiId(eventPackage) === packageId && type.slice(separator) === `::prize_pool::PrizeClaimed<${input.tokenType}>`;
  });
  if (matches.length !== 1) throw new Error("Sui returned an invalid TREE raffle claim event count.");
  const event = matches[0].json ?? matches[0].parsedJson;
  if (!event || typeof event !== "object") throw new Error("Sui returned malformed TREE raffle claim data.");
  const drawId = new TextDecoder().decode(Uint8Array.from(byteArray(event.draw_id, "claim draw ID")));
  const amount = u64(String(event.amount), "claimed amount");
  if (drawId !== input.onchainDrawId || String(event.winner).toLowerCase() !== input.wallet || amount !== expectedAmount) {
    throw new Error("Sui TREE raffle claim event does not match the recorded prize.");
  }
  return { digest: String(digest), wallet: input.wallet, amountRaw: amount.toString() };
}

// netlify/lib/tree-raffle-supabase-ledger.ts
function requiredConfigValue(value, label) {
  const normalized = value?.trim();
  if (!normalized) throw new Error(`${label} is not configured.`);
  return normalized;
}
function treeRaffleSupabaseConfig(env = process.env) {
  const url = requiredConfigValue(env.TREE_RAFFLE_SUPABASE_URL, "TREE_RAFFLE_SUPABASE_URL");
  const secretKey = requiredConfigValue(
    env.TREE_RAFFLE_SUPABASE_SECRET_KEY,
    "TREE_RAFFLE_SUPABASE_SECRET_KEY"
  );
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error("TREE_RAFFLE_SUPABASE_URL must be a valid HTTPS URL.");
  }
  if (parsed.protocol !== "https:") {
    throw new Error("TREE_RAFFLE_SUPABASE_URL must use HTTPS.");
  }
  return {
    url: parsed.origin,
    secretKey,
    weeklyEnabled: env.TREE_RAFFLE_WEEKLY_ENABLED === "true"
  };
}

// netlify/lib/tree-raffle-supabase-draw.ts
var SUI_ADDRESS3 = /^0x[0-9a-f]{64}$/;
var SUI_DIGEST2 = /^[1-9A-HJ-NP-Za-km-z]{40,64}$/;
var UNSIGNED = /^(0|[1-9][0-9]*)$/;
function objectRow(value, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`Supabase returned an invalid TREE raffle ${label}.`);
  }
  return value;
}
function validOutcome(row) {
  return row.outcome === "recorded" || row.outcome === "duplicate";
}
function parseDrawSnapshot(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("Supabase returned an invalid TREE raffle draw snapshot.");
  }
  const row = value;
  if (typeof row.roundId !== "string" || row.prizeClass !== "main" && row.prizeClass !== "lucky" || typeof row.onchainDrawId !== "string" || row.selectionScheme !== TREE_RAFFLE_SELECTION_SCHEME || !Array.isArray(row.ticketRanges) || typeof row.ledgerCommitment !== "string" || !/^[0-9a-f]{64}$/.test(row.ledgerCommitment) || typeof row.totalTickets !== "string") {
    throw new Error("Supabase returned an invalid TREE raffle draw snapshot.");
  }
  const ticketRanges = row.ticketRanges;
  const totalTickets = validateTreeRaffleTicketRanges(row.onchainDrawId, ticketRanges);
  if (totalTickets.toString() !== row.totalTickets) {
    throw new Error("Supabase TREE raffle ticket ranges do not match the declared total.");
  }
  if (treeRaffleLedgerCommitment(row.onchainDrawId, ticketRanges) !== row.ledgerCommitment) {
    throw new Error("Supabase TREE raffle ledger commitment does not match its ticket ranges.");
  }
  return {
    roundId: row.roundId,
    prizeClass: row.prizeClass,
    onchainDrawId: row.onchainDrawId,
    selectionScheme: row.selectionScheme,
    ticketRanges,
    ledgerCommitment: row.ledgerCommitment,
    totalTickets: row.totalTickets
  };
}
var SupabaseTreeRaffleDrawStore = class {
  config;
  fetchImpl;
  constructor(config2, fetchImpl = fetch) {
    this.config = config2;
    this.fetchImpl = fetchImpl;
  }
  async lockDraw(roundId, prizeClass) {
    const response = await this.fetchImpl(
      `${this.config.url}/rest/v1/rpc/lock_tree_raffle_draw`,
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.config.secretKey}`,
          apikey: this.config.secretKey,
          "X-Client-Info": "tree-command-center-raffle-draw/1"
        },
        body: JSON.stringify({ p_round_id: roundId, p_prize_class: prizeClass }),
        signal: AbortSignal.timeout(1e4)
      }
    );
    const payload = await response.json().catch(() => null);
    if (!response.ok) throw new Error(`Supabase TREE raffle draw lock failed with HTTP ${response.status}.`);
    return parseDrawSnapshot(payload);
  }
  async rpc(functionName, body) {
    const response = await this.fetchImpl(`${this.config.url}/rest/v1/rpc/${functionName}`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.config.secretKey}`,
        apikey: this.config.secretKey,
        "X-Client-Info": "tree-command-center-raffle-draw/1"
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(1e4)
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok) throw new Error(`Supabase TREE raffle ${functionName} failed with HTTP ${response.status}.`);
    return payload;
  }
  async recordWinner(input) {
    const payload = await this.rpc("record_tree_raffle_winner", {
      p_round_id: input.roundId,
      p_prize_class: input.prizeClass,
      p_onchain_draw_id: input.onchainDrawId,
      p_ledger_commitment: input.ledgerCommitment,
      p_winning_ticket: input.winningTicket,
      p_wallet: input.wallet,
      p_draw_tx_digest: input.drawTxDigest,
      p_register_tx_digest: input.registerTxDigest
    });
    const row = objectRow(payload, "winner record");
    if (!validOutcome(row) || row.roundId !== input.roundId || row.prizeClass !== input.prizeClass || row.onchainDrawId !== input.onchainDrawId || row.ledgerCommitment !== input.ledgerCommitment || row.winningTicket !== input.winningTicket || row.totalTickets !== input.totalTickets || row.wallet !== input.wallet || row.token !== input.token || row.tokenType !== input.tokenType || row.amountRaw !== input.amountRaw || row.decimals !== input.decimals || row.drawTxDigest !== input.drawTxDigest || row.registerTxDigest !== input.registerTxDigest || !SUI_ADDRESS3.test(input.wallet) || !SUI_DIGEST2.test(input.drawTxDigest) || !SUI_DIGEST2.test(input.registerTxDigest) || !UNSIGNED.test(input.winningTicket) || !UNSIGNED.test(input.totalTickets) || !UNSIGNED.test(input.amountRaw)) {
      throw new Error("Supabase returned an invalid TREE raffle winner record.");
    }
    return { ...input, outcome: row.outcome };
  }
  async recordClaim(input) {
    const payload = await this.rpc("record_tree_raffle_claim", {
      p_round_id: input.roundId,
      p_prize_class: input.prizeClass,
      p_wallet: input.wallet,
      p_claim_tx_digest: input.claimTxDigest
    });
    const row = objectRow(payload, "claim record");
    if (!validOutcome(row) || row.roundId !== input.roundId || row.prizeClass !== input.prizeClass || row.wallet !== input.wallet || row.claimTxDigest !== input.claimTxDigest || typeof row.claimedAt !== "string" || !SUI_ADDRESS3.test(input.wallet) || !SUI_DIGEST2.test(input.claimTxDigest) || !Number.isFinite(Date.parse(row.claimedAt))) {
      throw new Error("Supabase returned an invalid TREE raffle claim record.");
    }
    return { ...input, claimedAt: row.claimedAt, outcome: row.outcome };
  }
};
function configuredSupabaseTreeRaffleDrawStore(env = process.env, fetchImpl = fetch) {
  return new SupabaseTreeRaffleDrawStore(treeRaffleSupabaseConfig(env), fetchImpl);
}

// netlify/lib/tree-raffle-supabase-read.ts
function validSnapshot(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const candidate = value;
  return Boolean(candidate.rounds && typeof candidate.rounds === "object" && !Array.isArray(candidate.rounds)) && Array.isArray(candidate.history) && (candidate.wallet === null || typeof candidate.wallet === "object" && !Array.isArray(candidate.wallet));
}
var SupabaseTreeRaffleReadModel = class {
  config;
  fetchImpl;
  constructor(config2, fetchImpl = fetch) {
    this.config = config2;
    this.fetchImpl = fetchImpl;
  }
  async snapshot(wallet) {
    const response = await this.fetchImpl(
      `${this.config.url}/rest/v1/rpc/read_tree_raffle_public_snapshot`,
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.config.secretKey}`,
          apikey: this.config.secretKey,
          "X-Client-Info": "tree-command-center-raffle-read/1"
        },
        body: JSON.stringify({ p_wallet: wallet }),
        signal: AbortSignal.timeout(5e3)
      }
    );
    if (!response.ok) throw new Error(`Supabase raffle snapshot request failed with HTTP ${response.status}.`);
    const payload = await response.json();
    if (!validSnapshot(payload)) throw new Error("Supabase returned an invalid raffle public snapshot.");
    return payload;
  }
};
function configuredSupabaseTreeRaffleReadModel(env = process.env, fetchImpl = fetch) {
  return new SupabaseTreeRaffleReadModel(treeRaffleSupabaseConfig(env), fetchImpl);
}

// netlify/lib/tree-raffle-claim.ts
var SUI_GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var SUI_ADDRESS4 = /^0x[0-9a-f]{64}$/;
var SUI_DIGEST3 = /^[1-9A-HJ-NP-Za-km-z]{40,64}$/;
var TREE_RAFFLE_CLAIM_QUERY = `query TreeRaffleClaim($digest: String!) {
  transaction(digest: $digest) {
    digest
    sender { address }
    effects {
      status
      events(first: 10) {
        pageInfo { hasNextPage }
        nodes { contents { type { repr } json } }
      }
    }
  }
}`;
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function json(body, status = 200) {
  return Response.json(body, {
    status,
    headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "X-Robots-Tag": "noindex" }
  });
}
function parsePrize(value, wallet) {
  const prize = record(value);
  if (typeof prize.roundId !== "string" || prize.prizeClass !== "main" && prize.prizeClass !== "lucky" || typeof prize.onchainDrawId !== "string" || typeof prize.tokenType !== "string" || !prize.tokenType.includes("::") || typeof prize.amountRaw !== "string" || !/^(?:0|[1-9][0-9]*)$/.test(prize.amountRaw)) return null;
  return { ...prize, wallet };
}
async function fetchFinalizedTreeRaffleClaim(digest, options = {}) {
  if (!SUI_DIGEST3.test(digest)) throw new Error("A valid Sui transaction digest is required.");
  const response = await (options.fetchImpl ?? fetch)(options.endpoint ?? SUI_GRAPHQL_URL, {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ query: TREE_RAFFLE_CLAIM_QUERY, variables: { digest } }),
    signal: AbortSignal.timeout(options.timeoutMs ?? 8e3)
  });
  if (!response.ok) throw new Error(`Sui claim verification returned ${response.status}.`);
  const payload = record(await response.json());
  if (Array.isArray(payload.errors) && payload.errors.length) throw new Error("Sui claim verification returned a GraphQL error.");
  const transaction = record(record(payload.data).transaction);
  const effects = record(transaction.effects);
  const events = record(effects.events);
  const sender = String(record(transaction.sender).address || "").toLowerCase();
  if (transaction.digest !== digest || !SUI_ADDRESS4.test(sender) || String(effects.status || "").toLowerCase() !== "success" || record(events.pageInfo).hasNextPage === true || !Array.isArray(events.nodes)) {
    throw new Error("The Sui raffle claim was not found, successful, or complete.");
  }
  const parsedEvents = events.nodes.map((node) => {
    const contents = record(record(node).contents);
    return { type: String(record(contents.type).repr || ""), json: record(contents.json) };
  });
  return { digest, sender, effects: { status: "success" }, events: parsedEvents };
}
function createTreeRaffleClaimHandler(dependencies = {}) {
  const env = dependencies.env ?? process.env;
  return async (request) => {
    if (request.method !== "POST") return json({ status: "error", error: "method-not-allowed" }, 405);
    const rules = treeRaffleRulesForEnvironment(env);
    const readiness = raffleOperationalReadiness(env, rules);
    const enabled = dependencies.allowClaims ?? (rules.claimsEnabled && rules.prizesFunded && readiness.onchainPrizePoolConfigured);
    if (!enabled) return json({ status: "disabled", error: "raffle-claims-disabled" }, 503);
    let digest = "";
    let wallet = "";
    let roundId = "";
    let prizeClass = "main";
    try {
      const body = await request.json();
      if (!body || typeof body !== "object" || Array.isArray(body) || Object.keys(body).length !== 4 || typeof body.digest !== "string" || typeof body.wallet !== "string" || typeof body.roundId !== "string" || body.prizeClass !== "main" && body.prizeClass !== "lucky") throw new Error("invalid");
      digest = body.digest.trim();
      wallet = body.wallet.trim().toLowerCase();
      roundId = body.roundId.trim();
      prizeClass = body.prizeClass;
      if (!SUI_DIGEST3.test(digest) || !SUI_ADDRESS4.test(wallet) || !roundId) throw new Error("invalid");
    } catch {
      return json({ status: "error", error: "invalid-request" }, 400);
    }
    try {
      const snapshot = await (dependencies.readWallet ? dependencies.readWallet(wallet) : configuredSupabaseTreeRaffleReadModel(env).snapshot(wallet));
      if (snapshot.wallet?.address !== wallet) throw new Error("The claim snapshot does not match the requested wallet.");
      const unclaimed = Array.isArray(snapshot.wallet?.unclaimedPrizes) ? snapshot.wallet.unclaimedPrizes.map((value) => parsePrize(value, wallet)).filter((value) => value !== null) : [];
      const prize = unclaimed.find((candidate) => candidate.roundId === roundId && candidate.prizeClass === prizeClass);
      if (!prize || prize.wallet !== wallet) return json({ status: "error", error: "prize-not-claimable" }, 404);
      const transaction = await (dependencies.fetchClaim ?? fetchFinalizedTreeRaffleClaim)(digest);
      if (transaction.sender !== wallet) throw new Error("The claim sender does not match the prize winner.");
      const verified = verifyTreeRaffleClaimTransaction({
        transaction,
        packageId: env.TREE_RAFFLE_PACKAGE_ID || "",
        onchainDrawId: prize.onchainDrawId,
        wallet,
        tokenType: prize.tokenType,
        amountRaw: prize.amountRaw
      });
      const recorded = await (dependencies.recordClaim ? dependencies.recordClaim({ roundId, prizeClass, wallet, claimTxDigest: verified.digest }) : configuredSupabaseTreeRaffleDrawStore(env).recordClaim({ roundId, prizeClass, wallet, claimTxDigest: verified.digest }));
      return json({ status: "ok", roundId, prizeClass, wallet, digest: verified.digest, ...recorded });
    } catch (error) {
      console.error("TREE raffle prize claim reconciliation failed", error);
      return json({ status: "error", error: "verification-failed", message: "The finalized raffle claim could not be independently verified and recorded." }, 422);
    }
  };
}

// netlify/functions/tree-raffle-claim.ts
var tree_raffle_claim_default = createTreeRaffleClaimHandler();
var config = { path: "/api/tree-raffle-claim" };
export {
  config,
  tree_raffle_claim_default as default
};
