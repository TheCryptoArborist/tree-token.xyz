
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/arcade-social.ts
import { createHash } from "node:crypto";

// netlify/lib/arcade-growth-games.ts
var ARCADE_ENABLED_GAME_IDS = ["garden-bot", "pvp", "arborist-trials"];
var MAX_RESPONSE_BYTES = 128 * 1024;

// netlify/lib/arcade-growth-core.ts
var ARCADE_GROWTH_CHALLENGE_MS = 5 * 6e4;
var ARCADE_GROWTH_SESSION_MS = 60 * 6e4;
var ARCADE_GROWTH_ORIGINS = ["https://tree-token.xyz", "https://www.tree-token.xyz"];
var GROWTH_ELIGIBLE_GAME_IDS = [...ARCADE_ENABLED_GAME_IDS, "treeforce89"];
var ArcadeGrowthError = class extends Error {
  code;
  status;
  constructor(code, message, status = 400) {
    super(message);
    this.name = "ArcadeGrowthError";
    this.code = code;
    this.status = status;
  }
};

// netlify/lib/arcade-growth-store.ts
function arcadeGrowthSupabaseConfig(env) {
  const prefixes = ["ARCADE_GROWTH", "TREE_RAFFLE", "TREE_KNOWLEDGE_TRIAL"];
  for (const prefix of prefixes) {
    const url = env[`${prefix}_SUPABASE_URL`];
    const secretKey = env[`${prefix}_SUPABASE_SECRET_KEY`];
    if (!url && !secretKey) continue;
    if (!url || !secretKey) throw new ArcadeGrowthError("service-unavailable", "Daily Growth storage is not configured.", 503);
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      throw new ArcadeGrowthError("service-unavailable", "Daily Growth storage is not configured.", 503);
    }
    if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.pathname !== "/" || parsed.search || parsed.hash) {
      throw new ArcadeGrowthError("service-unavailable", "Daily Growth storage is not configured.", 503);
    }
    return { url: parsed.origin, secretKey };
  }
  throw new ArcadeGrowthError("service-unavailable", "Daily Growth storage is not configured.", 503);
}

// netlify/functions/arcade-social.ts
function socialProof(mission, proof) {
  if (typeof proof !== "string" || proof.length > 1e3) throw new Error("invalid-proof");
  if (mission === "community-vote" && ["treeforce89", "garden-bot", "arborist-trials"].includes(proof)) return proof;
  if (!["share-score", "friend-challenge"].includes(String(mission))) throw new Error("invalid-proof");
  const url = new URL(proof.trim());
  if (url.protocol !== "https:" || url.username || url.password || url.port || !["x.com", "twitter.com", "www.x.com", "www.twitter.com"].includes(url.hostname)) throw new Error("invalid-proof");
  const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/status\/([0-9]{1,25})\/?$/);
  if (!match) throw new Error("invalid-proof");
  return `https://x.com/${match[1].toLowerCase()}/status/${match[2]}`;
}
function environment() {
  const runtime = globalThis.Netlify?.env;
  const keys = ["ARCADE_SOCIAL_ENABLED", ...["ARCADE_GROWTH", "TREE_RAFFLE", "TREE_KNOWLEDGE_TRIAL"].flatMap((p) => [`${p}_SUPABASE_URL`, `${p}_SUPABASE_SECRET_KEY`])];
  return Object.fromEntries(keys.map((k) => [k, runtime?.get(k) ?? process.env[k]]));
}
function createSocialHandler({ env, fetchImpl = fetch } = {}) {
  return async (request) => {
    const reply = (value, status = 200) => Response.json(value, { status, headers: { "Cache-Control": "no-store", "Netlify-CDN-Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
    const settings = env || environment();
    if ((settings.ARCADE_SOCIAL_ENABLED ?? "true") !== "true") return reply({ error: "missions-unavailable", message: "Community missions are being prepared. Daily tasks remain available." }, 503);
    if (!["GET", "POST"].includes(request.method)) return reply({ error: "method-not-allowed" }, 405);
    const origin = request.headers.get("origin") || new URL(request.url).origin;
    if (!ARCADE_GROWTH_ORIGINS.includes(origin)) return reply({ error: "origin-not-allowed" }, 403);
    const auth = request.headers.get("authorization") || "";
    if (!/^Bearer [A-Za-z0-9_-]{32,512}$/.test(auth)) return reply({ error: "authentication-required" }, 401);
    let mission = null, proof = null;
    if (request.method === "POST") {
      try {
        if (!(request.headers.get("content-type") || "").startsWith("application/json")) throw new Error();
        const reader = request.body?.getReader();
        let input = "", size = 0;
        const decoder = new TextDecoder();
        if (!reader) throw new Error();
        while (true) {
          const part = await reader.read();
          if (part.done) break;
          size += part.value.byteLength;
          if (size > 2048) {
            await reader.cancel();
            throw new Error();
          }
          input += decoder.decode(part.value, { stream: true });
        }
        input += decoder.decode();
        const data = JSON.parse(input);
        if (!data || typeof data !== "object" || Array.isArray(data) || Object.keys(data).some((k) => !["mission", "proof"].includes(k))) throw new Error();
        proof = socialProof(data.mission, data.proof);
        mission = data.mission;
      } catch {
        return reply({ error: "invalid-proof", message: "Choose a vote or paste a public X post link." }, 400);
      }
    }
    try {
      const connection = arcadeGrowthSupabaseConfig(settings);
      const response = await fetchImpl(`${connection.url}/rest/v1/rpc/arcade_social_v1`, {
        method: "POST",
        headers: { "Content-Type": "application/json", apikey: connection.secretKey, Authorization: `Bearer ${connection.secretKey}` },
        body: JSON.stringify({ p_token_sha256: createHash("sha256").update(auth.slice(7)).digest("hex"), p_origin: origin, p_mission: mission, p_proof: proof }),
        signal: AbortSignal.timeout(8e3)
      });
      const payload = await response.json();
      if (!response.ok) {
        if (payload.message === "arcade-growth-invalid-session") return reply({ error: "invalid-session", message: "Sign in again to load community missions." }, 401);
        if (payload.code === "23505") return reply({ error: "proof-already-used", message: "That post has already been submitted." }, 409);
        throw new Error();
      }
      if (!payload || !/^0x[0-9a-f]{64}$/.test(payload.wallet) || !Array.isArray(payload.entries) || !Number.isFinite(Date.parse(payload.resetsAt))) throw new Error();
      return reply({ status: "ok", ...payload });
    } catch {
      return reply({ error: "missions-unavailable", message: "Community missions are unavailable. Your daily progress is unchanged." }, 503);
    }
  };
}
var arcade_social_default = createSocialHandler();
var config = { path: "/api/arcade-social", method: ["GET", "POST"], rateLimit: { action: "rate_limit", aggregateBy: ["domain", "ip"], windowSize: 60, windowLimit: 30 } };
export {
  config,
  createSocialHandler,
  arcade_social_default as default,
  socialProof
};
