
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/netlify/challenge-functions/arcade-challenge-pilot.mjs
import { createHash as createHash4, randomBytes as randomBytes2 } from "node:crypto";

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/scripts/arcade-campaigns/core.mjs
import { createHash } from "node:crypto";
var plain = (value) => value !== null && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
var compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
function utcMillis(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/.test(value)) return NaN;
  const stamp = Date.parse(value);
  const expanded = value.includes(".") ? value : value.replace("Z", ".000Z");
  return Number.isFinite(stamp) && new Date(stamp).toISOString() === expanded ? stamp : NaN;
}
function canonicalJson(value) {
  if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number" && Number.isSafeInteger(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(canonicalJson).join(",") + "]";
  if (plain(value)) return "{" + Object.keys(value).sort(compare).map((key) => JSON.stringify(key) + ":" + canonicalJson(value[key])).join(",") + "}";
  throw Error("Only plain JSON with safe integer numbers is supported; token quantities must be decimal strings.");
}
var contentHash = (value) => createHash("sha256").update(canonicalJson(value)).digest("hex");

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/scripts/arcade-campaigns/trials-adapter.mjs
import { createHash as createHash2 } from "node:crypto";

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/vendor/arcade-trials-engine/provenance.json
var provenance_default = {
  schemaVersion: 1,
  repository: "https://github.com/TheCryptoArborist/gardenbattles",
  commit: "4a27b3ac73ec815c9e28c23a6b0d07f09ee73794",
  sources: [
    {
      path: "upstream/practiceBattle.ts",
      sourcePath: "apps/garden-battles/battle-gardenfrontend/src/lib/practiceBattle.ts",
      gitBlobSha1: "f6da78b4756abd8fe02482b7a2f198cf577bab07",
      sha256: "da64c32e69e47bbb09c861917491244f2b130526060375ce60d412ed175b8c82"
    },
    {
      path: "upstream/arboristTrials.ts",
      sourcePath: "apps/garden-battles/battle-gardenfrontend/src/lib/arboristTrials.ts",
      gitBlobSha1: "f3f79ec5b119b352b9d90f10e88a800d864b0271",
      sha256: "6c401a57d45415a2fac689d79fdad3c302cedc25044a0ef881db5affc8062e30"
    },
    {
      path: "upstream/trial-engine.ts",
      sourcePath: "apps/garden-battles/shared/trial-engine.ts",
      gitBlobSha1: "93f7e2d0a789b8f47166b1bd720bdf5ff7a728cb",
      sha256: "3fa495eb6d08e36869f555f7606bca953c4181fb6bd46079a18338ee809d27a9"
    },
    {
      path: "upstream/arborist-trials.ts",
      sourcePath: "apps/garden-battles/shared/arborist-trials.ts",
      gitBlobSha1: "ce05e6ba55cfac5a936c8a538432a3cf45bf75d5",
      sha256: "54bf14eb72b1a1a1a16db24532e2048cfa876e08f8a524e1ae2d7122be0d5f35"
    },
    {
      path: "upstream/sui-config.ts",
      sourcePath: "apps/garden-battles/battle-gardenfrontend/src/lib/sui-config.ts",
      gitBlobSha1: "207696c3827ceff1de0cc08eafebd1d628cdacb7",
      sha256: "74de482a3324b29d34e30f297fa0b42255454563a5224836f7eb35b3d3c61c3b"
    }
  ],
  transformations: [
    "Erase TypeScript types with Node 24 stripTypeScriptTypes(mode=strip).",
    "Remove whitespace-only padding lines left by type erasure; retain all original nonblank runtime lines.",
    "Redirect only runtime imports to local generated modules; type-only UI imports erase automatically.",
    "Extract MOVE_LABELS, MoveType, MoveMeta and MOVE_META from sui-config.ts, from its Short display label comment to before SELF_GROWTH_MOVE_IDS. Do not copy chain configuration into the runtime.",
    "Preserve all game calculations, seeded RNG consumption (including log-entry random draws), portable shuffle, bot policy and round rules. Date.now remains upstream log metadata only; the adapter excludes it from replay results.",
    "The adapter enforces portable-v1 and four standard cards, seeds every battle, and exposes no fifth-card, paid-advantage or debug option."
  ],
  runtime: [
    {
      path: "runtime/practice-battle.mjs",
      sha256: "5285d8898110e87e9f4d81da0f893dad7e6106f511db1be0ecae8ad866f7260f"
    },
    {
      path: "runtime/trial-game.mjs",
      sha256: "cda1cb3fbfb7268378f9571db13244c615b7cbc044dcb9974175fa126b367333"
    },
    {
      path: "runtime/trial-engine.mjs",
      sha256: "dcf6ac85a35a541e236bbaa99565daabb2fbbd98d604fd0704eabbb518980e04"
    },
    {
      path: "runtime/challenge-rules.mjs",
      sha256: "4d20cfafb98fd1eb178ecd16bf198832cb53d7c97cbb1cf14e47ba1c79222c25"
    },
    {
      path: "runtime/card-catalog.mjs",
      sha256: "1e133cf17ae3f440e1d8cee3a156c5582ef202999299a83ca25a39b71bc29d4b"
    }
  ],
  sourceHash: "9623279e03ddab211d51e26f89040afc0b8aee4ff86fc19af53243096215ca00",
  liveParityClaimed: false
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/vendor/arcade-trials-engine/runtime/trial-engine.mjs
var TRIAL_PORTABLE_START_DATE = "2026-09-03";
function shuffleTrialHand(cards, random, engine) {
  if (engine === "portable-v1") {
    for (let i = cards.length - 1; i > 0; i--) {
      const j = Math.floor(random() * (i + 1));
      [cards[i], cards[j]] = [cards[j], cards[i]];
    }
    return cards;
  }
  let start = 1;
  if (engine === "legacy-v8" && cards.length > 1) {
    const descending = random() < 0.5;
    start = 2;
    while (start < cards.length) {
      if (random() < 0.5 !== descending) break;
      start++;
    }
    if (descending) {
      const run = cards.slice(0, start).reverse();
      cards.splice(0, start, ...run);
    }
  }
  for (let i = start; i < cards.length; i++) {
    const value = cards[i];
    let left = 0, right = i;
    while (left < right) {
      const mid = left + right >>> 1;
      if (random() < 0.5) right = mid;
      else left = mid + 1;
    }
    cards.splice(i, 1);
    cards.splice(left, 0, value);
  }
  return cards;
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/vendor/arcade-trials-engine/runtime/challenge-rules.mjs
var ARBORIST_TRIAL_TARGET_GROWTH = 50;
var ARBORIST_TRIAL_VERSION = 2;
var ARBORIST_TRIAL_V2_START_DATE = "2026-09-02";
var LEGACY_TRIAL_VARIANTS = [
  {
    title: "Root Rush",
    subtitle: "Race the clock",
    description: "Both trees start even. Win efficiently and use a varied hand to maximize your daily score.",
    playerStartGrowth: 0,
    botStartGrowth: 0,
    rule: "standard",
    ruleDescription: "Win efficiently and use a varied hand to maximize your score."
  },
  {
    title: "Comeback Canopy",
    subtitle: "Overcome the head start",
    description: "Garden Bot begins ahead. Counter carefully, recover the gap, and take the canopy.",
    playerStartGrowth: 0,
    botStartGrowth: 8,
    rule: "standard",
    ruleDescription: "Erase the Garden Bot's 8-Growth head start and claim the canopy."
  },
  {
    title: "Crown Race",
    subtitle: "Every card matters",
    description: "Both trees begin established. The shorter runway rewards counters, timing, and card variety.",
    playerStartGrowth: 10,
    botStartGrowth: 10,
    rule: "standard",
    ruleDescription: "Both trees start established in a shorter race to 50 Growth."
  }
];
var SEVEN_DAY_TRIAL_ROTATION = [
  LEGACY_TRIAL_VARIANTS[0],
  {
    title: "Canopy Diagnosis",
    subtitle: "Read the threat",
    description: "The Garden Bot reveals its next card type. Choose the right response and earn a diagnosis bonus for every successful counter.",
    playerStartGrowth: 0,
    botStartGrowth: 0,
    rule: "canopy_diagnosis",
    ruleDescription: "Attack counters Growth, Growth counters Hybrid, and Hybrid counters Attack."
  },
  LEGACY_TRIAL_VARIANTS[1],
  {
    title: "Toolbelt Rotation",
    subtitle: "Use every tool",
    description: "Once a standard card is played, it locks until all four standard cards have been used. The bonus fifth move remains separate.",
    playerStartGrowth: 0,
    botStartGrowth: 0,
    rule: "toolbelt_rotation",
    ruleDescription: "Complete the four-card Toolbelt cycle to unlock the standard hand again."
  },
  LEGACY_TRIAL_VARIANTS[2],
  {
    title: "Storm Response",
    subtitle: "Recover under pressure",
    description: "A storm strips 4 Growth from both trees after every third completed round. Time your recovery and finishing move carefully.",
    playerStartGrowth: 0,
    botStartGrowth: 0,
    rule: "storm_response",
    ruleDescription: "Storm damage strikes after rounds 3, 6, 9, and every third round thereafter."
  },
  {
    title: "Integrated Pest Management",
    subtitle: "Control with restraint",
    description: "Win with two or fewer Attack cards to earn the full IPM specialty bonus. Additional attacks remain available but reduce the bonus.",
    playerStartGrowth: 0,
    botStartGrowth: 0,
    rule: "integrated_pest_management",
    ruleDescription: "Use Growth and Hybrid tools to limit Attack plays without sacrificing the win."
  }
];
function hashText(value) {
  let hash3 = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash3 ^= value.charCodeAt(index);
    hash3 = Math.imul(hash3, 16777619);
  }
  return hash3 >>> 0;
}
function getArboristTrialDate(now = /* @__PURE__ */ new Date()) {
  return now.toISOString().slice(0, 10);
}
function daysSince(date, startingDate) {
  return Math.floor(
    (Date.parse(`${date}T00:00:00.000Z`) - Date.parse(`${startingDate}T00:00:00.000Z`)) / 864e5
  );
}
function getArboristTrialChallenge(now = /* @__PURE__ */ new Date()) {
  const date = getArboristTrialDate(now);
  const version = date >= ARBORIST_TRIAL_V2_START_DATE ? ARBORIST_TRIAL_VERSION : 1;
  const seed = hashText(`garden-battles:arborist-trials:v${version}:${date}`);
  const variant = version === 1 ? LEGACY_TRIAL_VARIANTS[seed % LEGACY_TRIAL_VARIANTS.length] : SEVEN_DAY_TRIAL_ROTATION[daysSince(date, ARBORIST_TRIAL_V2_START_DATE) % SEVEN_DAY_TRIAL_ROTATION.length];
  const expiresAt = Date.parse(`${date}T00:00:00.000Z`) + 24 * 60 * 60 * 1e3;
  return {
    id: `arborist-trial-v${version}-${date}`,
    date,
    seed,
    targetGrowth: ARBORIST_TRIAL_TARGET_GROWTH,
    expiresAt,
    ...date >= TRIAL_PORTABLE_START_DATE ? { simulationVersion: 2 } : {},
    ...variant
  };
}
function calculateArboristTrialScore(result) {
  const rounds = Math.max(1, Math.min(100, Math.round(result.rounds)));
  const playerGrowth = Math.max(0, Math.min(100, Math.round(result.playerGrowth)));
  const botGrowth = Math.max(0, Math.min(100, Math.round(result.botGrowth)));
  const uniqueMoves = Math.max(0, Math.min(5, Math.round(result.uniqueMoves)));
  const victory = result.won ? 1e4 : 0;
  const efficiency = result.won ? Math.max(0, 30 - rounds) * 200 : 0;
  const margin = result.won ? Math.max(0, playerGrowth - botGrowth) * 25 : playerGrowth * 10;
  const variety = uniqueMoves * 100;
  const specialtyBonus = Math.max(0, Math.min(5e3, Math.round(result.specialtyBonus ?? 0)));
  return victory + efficiency + margin + variety + specialtyBonus;
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/vendor/arcade-trials-engine/runtime/card-catalog.mjs
var MOVE_LABELS = {
  1: "Wedgebreaker",
  2: "Skyreach Saw",
  3: "Chainsaw Cyclone",
  4: "Rootpiercer",
  5: "Limbfall Slam",
  6: "Acorn Barrage",
  7: "Log Swing Rampage",
  8: "Barklash Shield",
  9: "Root Siphon",
  10: "Beetle Blight",
  11: "Lightning Crown",
  12: "Air Spade Blast",
  13: "Fungal Doom",
  14: "Compost Cleanse",
  15: "Rootlink Surge",
  16: "Pruning Fury",
  17: "Mulch Fortress",
  18: "Graft Fusion",
  19: "Wildwood Gamble",
  20: "Root Revival",
  21: "Solar Bloom",
  22: "Rainmaker",
  23: "Myco Might",
  24: "Canopy Downpour",
  25: "Potassium Power",
  26: "Photosynthesis Overdrive",
  27: "Ironbark Armor",
  28: "Sap Surge",
  29: "Gale Guard",
  30: "Shadow Canopy",
  31: "Chainsaw Cataclysm",
  32: "Beetle Swarm Blitz",
  33: "Lightning Split",
  34: "Ancient Root Awakening",
  35: "Canopy Explosion",
  36: "Solar Crown Surge",
  37: "Ironwood Fortress",
  38: "Rootstorm Siphon",
  39: "Arborist Ascension"
};
var MOVE_META = {
  1: { type: "attack", emoji: "", effect: "Drains 11 Growth. Against a block, breaks it and still drains 7." },
  2: { type: "attack", emoji: "", effect: "Drains 8 Growth, or 12 when the opponent has at least 40 Growth." },
  3: { type: "attack", emoji: "", effect: "75% chance to drain 16 Growth." },
  4: { type: "attack", emoji: "", effect: "Pierces blocks and drains 11 Growth." },
  5: { type: "attack", emoji: "", effect: "Drains 12 after an opponent Growth card; otherwise drains 8." },
  6: { type: "attack", emoji: "", effect: "Fires two separate 6-Growth hits." },
  7: { type: "attack", emoji: "", effect: "Drains 13 while you are behind; otherwise drains 10." },
  8: { type: "hybrid", emoji: "", effect: "Gains 6 Growth and blocks the next hit; a fresh shield reflects 4." },
  9: { type: "hybrid", emoji: "", effect: "Drains 6 Growth and gains 4 Growth." },
  10: { type: "attack", emoji: "", effect: "Deals 4 poison damage for the opponent's next two turns; does not stack." },
  11: { type: "attack", emoji: "", effect: "75% chance to drain 17 Growth." },
  12: { type: "attack", emoji: "", effect: "Removes one block, then pierces for 10 Growth." },
  13: { type: "attack", emoji: "", effect: "Drains 7 now and 4 more on the opponent's next turn." },
  14: { type: "hybrid", emoji: "", effect: "Clears pending damage first; gains 14 when cleansing, otherwise 10." },
  15: { type: "growth", emoji: "", effect: "Gains 12 Growth while behind; otherwise gains 8." },
  16: { type: "attack", emoji: "", effect: "Spends 4 Growth to drain 16. Requires at least 4 Growth." },
  17: { type: "hybrid", emoji: "", effect: "With a block, gains 10; otherwise gains 7 and adds one block." },
  18: { type: "hybrid", emoji: "", effect: "Gains 5 Growth and drains 5 Growth." },
  19: { type: "growth", emoji: "", effect: "60% chance to gain 20 Growth; otherwise loses 4." },
  20: { type: "growth", emoji: "", effect: "Clears a pending one-turn penalty and gains 10 Growth." },
  21: { type: "growth", emoji: "", effect: "Gains a random 8 to 14 Growth." },
  22: { type: "growth", emoji: "", effect: "Gains 14 after an opponent Attack; otherwise gains 10." },
  23: { type: "growth", emoji: "", effect: "Gains 15 if the opponent is protected; otherwise gains 10." },
  24: { type: "growth", emoji: "", effect: "Gains 14 Growth while the opponent also gains 3." },
  25: { type: "growth", emoji: "", effect: "75% chance to gain 15 Growth; otherwise gains 3." },
  26: { type: "growth", emoji: "", effect: "Gains 13 after your Attack card; otherwise gains 11." },
  27: { type: "hybrid", emoji: "", effect: "Gains 7 Growth and halves the next direct hit." },
  28: { type: "growth", emoji: "", effect: "Gains 13 at 10 Growth or below; otherwise gains 10." },
  29: { type: "hybrid", emoji: "", effect: "Gains 8 Growth with a 50% chance to add one block." },
  30: { type: "growth", emoji: "", effect: "Gains 8 Growth and caps the next direct attack at 8." },
  31: { type: "attack", emoji: "", effect: "Gains 3 Growth and drains 8.", fifthExclusive: true, draftLane: "offense" },
  32: { type: "attack", emoji: "", effect: "Gains 4 Growth and deals 3 poison damage for two turns.", fifthExclusive: true, draftLane: "offense" },
  33: { type: "attack", emoji: "", effect: "Gains 3 Growth with a 75% chance to drain 10.", fifthExclusive: true, draftLane: "offense" },
  34: { type: "growth", emoji: "", effect: "Gains 11 Growth while behind; otherwise gains 10.", fifthExclusive: true, draftLane: "growth" },
  35: { type: "growth", emoji: "", effect: "Removes one opponent block and gains 10 Growth.", fifthExclusive: true, draftLane: "growth" },
  36: { type: "growth", emoji: "", effect: "Clears pending damage before it triggers and gains 9 Growth.", fifthExclusive: true, draftLane: "growth" },
  37: { type: "hybrid", emoji: "", effect: "Gains 7 Growth and adds one block.", fifthExclusive: true, draftLane: "defense" },
  38: { type: "hybrid", emoji: "", effect: "Gains 6 Growth and drains 6 Growth.", fifthExclusive: true, draftLane: "defense" },
  39: { type: "hybrid", emoji: "", effect: "Gains 8 Growth and caps the next direct attack at 8.", fifthExclusive: true, draftLane: "defense" }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/vendor/arcade-trials-engine/runtime/practice-battle.mjs
var PRACTICE_PLAYER_ADDRESS = "practice-player";
var PRACTICE_BOT_ADDRESS = "practice-garden-bot";
var PRACTICE_TARGET_GROWTH = 50;
var ATTACK_MOVES = [1, 2, 3, 4, 5, 6, 7, 10, 11, 12, 13, 16];
var GROWTH_MOVES = [15, 19, 20, 21, 22, 23, 24, 25, 26, 28, 30];
var HYBRID_MOVES = [8, 9, 14, 17, 18, 27, 29];
var ALL_MOVES = [...ATTACK_MOVES, ...GROWTH_MOVES, ...HYBRID_MOVES];
function emptyStatus() {
  return {
    blockTurns: 0,
    poisonTicks: 0,
    poisonDpt: 0,
    nextTurnPenalty: 0,
    reflectDamage: 0,
    armorHalf: false,
    attackCap: null
  };
}
function clampGrowth(value) {
  return Math.max(0, Math.min(PRACTICE_TARGET_GROWTH, Math.round(value)));
}
var seededRandomState = null;
function practiceRandom() {
  if (seededRandomState === null) return Math.random();
  seededRandomState = Math.imul(seededRandomState, 1664525) + 1013904223 >>> 0;
  return seededRandomState / 4294967296;
}
function randomItem(items) {
  return items[Math.floor(practiceRandom() * items.length)];
}
function drawUnique(pool, count, excluded = /* @__PURE__ */ new Set()) {
  const available = pool.filter((moveId) => !excluded.has(moveId));
  const picked = [];
  while (picked.length < count && available.length > 0) {
    const index = Math.floor(practiceRandom() * available.length);
    picked.push(available.splice(index, 1)[0]);
  }
  return picked;
}
function createPracticeBattleInternal(options) {
  const drawBalancedHand = () => {
    const cards = [
      ...drawUnique(ATTACK_MOVES, 1),
      ...drawUnique(GROWTH_MOVES, 1),
      ...drawUnique(HYBRID_MOVES, 1)
    ];
    cards.push(...drawUnique(ALL_MOVES, 1, new Set(cards)));
    return shuffleTrialHand(cards, practiceRandom, options.trialEngine ?? "portable-v1");
  };
  const playerMoves = drawBalancedHand();
  const botMoves = drawBalancedHand();
  if (options.bonusMoveId && !playerMoves.includes(options.bonusMoveId)) {
    playerMoves.push(options.bonusMoveId);
  }
  return {
    battleId: `${options.mode ?? "practice"}-${options.challengeId ?? Date.now()}-${Math.floor(practiceRandom() * 1e9).toString(16)}`,
    player1: PRACTICE_PLAYER_ADDRESS,
    player2: PRACTICE_BOT_ADDRESS,
    player1Moves: playerMoves,
    player2Moves: botMoves,
    player1Growth: options.playerStartGrowth ?? 0,
    player2Growth: options.botStartGrowth ?? 0,
    turn: 0,
    winner: null,
    finished: false,
    isBotBattle: true,
    lastMoveMs: Date.now(),
    mode: options.mode ?? "practice",
    botMoveHistory: [],
    allBotMoves: [],
    playerMoveHistory: [],
    allPlayerMoves: [],
    totalTurns: 0,
    playerStatus: emptyStatus(),
    botStatus: emptyStatus(),
    challengeId: options.challengeId,
    botMoveTypeSchedule: options.botMoveTypeSchedule,
    trialEngine: options.trialEngine
  };
}
function createPracticeBattle(options = {}) {
  if (options.seed === void 0) return createPracticeBattleInternal(options);
  const previousState = seededRandomState;
  seededRandomState = options.seed >>> 0;
  try {
    const battle = createPracticeBattleInternal(options);
    battle.randomState = seededRandomState;
    return battle;
  } finally {
    seededRandomState = previousState;
  }
}
function applyStartOfTurnStatus(growth, status, actorLabel, totalTurn) {
  const nextStatus = { ...status };
  const notes = [];
  const naturalGrowth = totalTurn >= 25 ? 3 : totalTurn >= 15 ? 2 : 1;
  let nextGrowth = clampGrowth(growth + naturalGrowth);
  notes.push(`${actorLabel} gained +${nextGrowth - growth} natural growth.`);
  if (nextStatus.nextTurnPenalty > 0) {
    const before = nextGrowth;
    nextGrowth = clampGrowth(nextGrowth - nextStatus.nextTurnPenalty);
    notes.push(`${actorLabel} lost ${before - nextGrowth} delayed growth.`);
    nextStatus.nextTurnPenalty = 0;
  }
  if (nextStatus.poisonTicks > 0) {
    const before = nextGrowth;
    nextGrowth = clampGrowth(nextGrowth - nextStatus.poisonDpt);
    notes.push(`${actorLabel} lost ${before - nextGrowth} poison growth.`);
    nextStatus.poisonTicks -= 1;
    if (nextStatus.poisonTicks === 0) nextStatus.poisonDpt = 0;
  }
  return { growth: nextGrowth, status: nextStatus, notes };
}
function applyDamage(damage, opponentGrowth, opponentStatus, targetLabel, piercing = false) {
  const nextStatus = { ...opponentStatus };
  if (!piercing && nextStatus.blockTurns > 0) {
    nextStatus.blockTurns -= 1;
    const reflected = nextStatus.reflectDamage;
    nextStatus.reflectDamage = 0;
    return {
      growth: opponentGrowth,
      status: nextStatus,
      notes: [`${targetLabel} blocked the hit.`, ...reflected > 0 ? [`The shield reflected ${reflected} Growth.`] : []],
      applied: 0,
      reflected
    };
  }
  let resolvedDamage = damage;
  if (nextStatus.attackCap !== null) {
    resolvedDamage = Math.min(resolvedDamage, nextStatus.attackCap);
    nextStatus.attackCap = null;
  }
  if (nextStatus.armorHalf) {
    resolvedDamage = Math.ceil(resolvedDamage / 2);
    nextStatus.armorHalf = false;
  }
  const nextGrowth = clampGrowth(opponentGrowth - resolvedDamage);
  const applied = opponentGrowth - nextGrowth;
  return {
    growth: nextGrowth,
    status: nextStatus,
    notes: applied > 0 ? [`${targetLabel} growth was reduced by ${applied}.`] : [`${targetLabel} had no growth to reduce.`],
    applied,
    reflected: 0
  };
}
function growSelf(amount, selfGrowth, actorLabel) {
  const nextGrowth = clampGrowth(selfGrowth + amount);
  const applied = nextGrowth - selfGrowth;
  return {
    growth: nextGrowth,
    notes: applied > 0 ? [`${actorLabel} gained +${applied} growth.`] : [`${actorLabel} could not gain more growth.`],
    applied
  };
}
function resolveMove(moveId, selfGrowth, opponentGrowth, selfStatus, opponentStatus, actorLabel, opponentLabel, selfLastMove, opponentLastMove, totalTurn) {
  const hadPendingDamage = selfStatus.poisonTicks > 0 || selfStatus.nextTurnPenalty > 0;
  const statusBeforeTurn = { ...selfStatus };
  if (moveId === 14) {
    statusBeforeTurn.poisonTicks = 0;
    statusBeforeTurn.poisonDpt = 0;
    statusBeforeTurn.nextTurnPenalty = 0;
  } else if (moveId === 20) {
    statusBeforeTurn.nextTurnPenalty = 0;
  }
  const started = applyStartOfTurnStatus(selfGrowth, statusBeforeTurn, actorLabel, totalTurn);
  let nextSelfGrowth = started.growth;
  let nextOpponentGrowth = opponentGrowth;
  let nextSelfStatus = started.status;
  let nextOpponentStatus = { ...opponentStatus };
  const notes = [...started.notes];
  const addGrow = (amount) => {
    const result = growSelf(amount, nextSelfGrowth, actorLabel);
    nextSelfGrowth = result.growth;
    notes.push(...result.notes);
  };
  const addDamage = (amount, piercing = false) => {
    const result = applyDamage(amount, nextOpponentGrowth, nextOpponentStatus, opponentLabel, piercing);
    nextOpponentGrowth = result.growth;
    nextOpponentStatus = result.status;
    if (result.reflected > 0) nextSelfGrowth = clampGrowth(nextSelfGrowth - result.reflected);
    notes.push(...result.notes);
  };
  const addBlock = () => {
    nextSelfStatus = { ...nextSelfStatus, blockTurns: Math.max(nextSelfStatus.blockTurns, 1) };
    notes.push(`${actorLabel} prepared a block.`);
  };
  const opponentLastType = opponentLastMove ? MOVE_META[opponentLastMove]?.type : void 0;
  const selfLastType = selfLastMove ? MOVE_META[selfLastMove]?.type : void 0;
  if (ATTACK_MOVES.includes(moveId) && nextOpponentGrowth === 0) {
    addGrow(4);
    notes.push(`${actorLabel} earned the +4 Mulch Bonus.`);
  }
  switch (moveId) {
    case 1:
      if (nextOpponentStatus.blockTurns > 0) {
        nextOpponentStatus.blockTurns -= 1;
        nextOpponentStatus.reflectDamage = 0;
        addDamage(7, true);
      } else addDamage(11);
      break;
    case 2:
      addDamage(nextOpponentGrowth >= 40 ? 12 : 8);
      break;
    case 3:
      if (practiceRandom() < 0.75) addDamage(16);
      else notes.push(`${actorLabel}'s cyclone missed.`);
      break;
    case 4:
      addDamage(11, true);
      break;
    case 5:
      addDamage(opponentLastType === "growth" ? 12 : 8);
      break;
    case 6:
      addDamage(6);
      addDamage(6);
      break;
    case 7:
      addDamage(nextSelfGrowth < nextOpponentGrowth ? 13 : 10);
      break;
    case 8:
      addGrow(6);
      if (nextSelfStatus.blockTurns === 0) {
        addBlock();
        nextSelfStatus.reflectDamage = 4;
      }
      break;
    case 9:
      addDamage(6);
      addGrow(4);
      break;
    case 10:
      if (nextOpponentStatus.poisonTicks === 0) {
        nextOpponentStatus = { ...nextOpponentStatus, poisonTicks: 2, poisonDpt: 4 };
        notes.push(`${opponentLabel} was poisoned for two turns.`);
      } else notes.push(`${opponentLabel} is already poisoned.`);
      break;
    case 11:
      if (practiceRandom() < 0.75) addDamage(17);
      else notes.push(`${actorLabel}'s lightning missed.`);
      break;
    case 12:
      if (nextOpponentStatus.blockTurns > 0) nextOpponentStatus.blockTurns -= 1;
      nextOpponentStatus.reflectDamage = 0;
      addDamage(10, true);
      break;
    case 13:
      addDamage(7);
      nextOpponentStatus = { ...nextOpponentStatus, nextTurnPenalty: nextOpponentStatus.nextTurnPenalty + 4 };
      notes.push(`${opponentLabel} will lose 4 growth next turn.`);
      break;
    case 14:
      addGrow(hadPendingDamage ? 14 : 10);
      if (hadPendingDamage) notes.push(`${actorLabel} cleansed lingering damage before it resolved.`);
      break;
    case 15:
      addGrow(nextSelfGrowth < nextOpponentGrowth ? 12 : 8);
      break;
    case 16:
      if (nextSelfGrowth >= 4) {
        nextSelfGrowth = clampGrowth(nextSelfGrowth - 4);
        notes.push(`${actorLabel} spent 4 growth.`);
        addDamage(16);
      } else {
        notes.push(`${actorLabel} needs at least 4 growth to use Pruning Fury.`);
      }
      break;
    case 17:
      if (nextSelfStatus.blockTurns > 0) addGrow(10);
      else {
        addGrow(7);
        addBlock();
      }
      break;
    case 18:
      addGrow(5);
      addDamage(5);
      break;
    case 19:
      if (practiceRandom() < 0.6) addGrow(20);
      else {
        const lost = Math.min(4, nextSelfGrowth);
        nextSelfGrowth = clampGrowth(nextSelfGrowth - 4);
        notes.push(`${actorLabel} lost ${lost} growth to overgrowth.`);
      }
      break;
    case 20:
      addGrow(10);
      break;
    case 21:
      addGrow(8 + Math.floor(practiceRandom() * 7));
      break;
    case 22:
      addGrow(opponentLastType === "attack" ? 14 : 10);
      break;
    case 23:
      addGrow(nextOpponentStatus.blockTurns > 0 ? 15 : 10);
      break;
    case 24:
      addGrow(14);
      nextOpponentGrowth = clampGrowth(nextOpponentGrowth + 3);
      break;
    case 25:
      addGrow(practiceRandom() < 0.75 ? 15 : 3);
      break;
    case 26:
      addGrow(selfLastType === "attack" ? 13 : 11);
      break;
    case 27:
      addGrow(7);
      nextSelfStatus.armorHalf = true;
      break;
    case 28:
      addGrow(nextSelfGrowth <= 10 ? 13 : 10);
      break;
    case 29:
      addGrow(8);
      if (practiceRandom() < 0.5 && nextSelfStatus.blockTurns === 0) addBlock();
      break;
    case 30:
      addGrow(8);
      nextSelfStatus.attackCap = 8;
      break;
    default:
      notes.push(`${actorLabel} used an unknown move.`);
      break;
  }
  return {
    selfGrowth: nextSelfGrowth,
    opponentGrowth: nextOpponentGrowth,
    selfStatus: nextSelfStatus,
    opponentStatus: nextOpponentStatus,
    outcome: {
      selfGrowthDelta: nextSelfGrowth - selfGrowth,
      opponentGrowthDelta: nextOpponentGrowth - opponentGrowth,
      notes
    }
  };
}
function expectedGrowth(moveId) {
  if (moveId === 9) return 4;
  if (moveId === 14) return 10;
  if (moveId === 15) return 10;
  if (moveId === 17) return 7;
  if (moveId === 18) return 5;
  if (moveId === 19 || moveId === 20 || moveId === 22 || moveId === 23) return 10;
  if (moveId === 21 || moveId === 29 || moveId === 30) return 8;
  if (moveId === 24) return 14;
  if (moveId === 25) return 12;
  if (moveId === 26) return 11;
  if (moveId === 27) return 7;
  if (moveId === 28) return 10;
  return 0;
}
function expectedDamage(moveId) {
  if (moveId === 1) return 11;
  if (moveId === 2) return 8;
  if (moveId === 3) return 12;
  if (moveId === 4) return 11;
  if (moveId === 5) return 8;
  if (moveId === 6) return 12;
  if (moveId === 7) return 10;
  if (moveId === 9) return 6;
  if (moveId === 11) return 13;
  if (moveId === 12) return 10;
  if (moveId === 13) return 7;
  if (moveId === 16) return 16;
  if (moveId === 18) return 5;
  return 0;
}
function addsBlock(moveId) {
  return moveId === 8 || moveId === 17 || moveId === 29;
}
function scoreBotMove(moveId, battle) {
  let score = 0;
  const botBehind = battle.player2Growth < battle.player1Growth;
  const playerNearTarget = battle.player1Growth >= 35;
  const growth = expectedGrowth(moveId);
  const damage = expectedDamage(moveId);
  if (growth > 0 && battle.player2Growth < PRACTICE_TARGET_GROWTH) {
    const usefulGrowth = Math.min(growth, PRACTICE_TARGET_GROWTH - battle.player2Growth);
    score += (botBehind ? 120 : 80) + usefulGrowth;
  }
  if (damage > 0 && battle.player1Growth > 0) {
    const usefulDamage = Math.min(damage, battle.player1Growth);
    score += (playerNearTarget ? 95 : 45) + usefulDamage;
  }
  if (addsBlock(moveId)) {
    score += battle.botStatus.blockTurns > 0 ? 3 : playerNearTarget ? 26 : 12;
  }
  if (moveId === 10 && battle.player1Growth > 0 && battle.playerStatus.poisonTicks === 0) {
    score += playerNearTarget ? 55 : 35;
  }
  const history = battle.botMoveHistory.slice(-4);
  const lastMove = history[history.length - 1];
  const usesInLastFour = history.filter((id) => id === moveId).length;
  if (moveId === lastMove) score -= 90;
  if (usesInLastFour >= 2) score -= 60;
  return Math.max(1, score);
}
function choosePracticeBotMove(battle) {
  const scheduledType = battle.botMoveTypeSchedule?.length ? battle.botMoveTypeSchedule[(battle.trialEngine === "portable-v1" ? battle.allBotMoves.length : battle.botMoveHistory.length) % battle.botMoveTypeSchedule.length] : null;
  const scheduledMoves = scheduledType ? battle.player2Moves.filter((moveId) => MOVE_META[moveId]?.type === scheduledType) : battle.player2Moves;
  const availableMoves = scheduledMoves.length > 0 ? scheduledMoves : battle.player2Moves;
  const scored = availableMoves.map((moveId) => ({
    moveId,
    score: scoreBotMove(moveId, battle)
  }));
  const maxScore = Math.max(...scored.map((item) => item.score));
  let candidates = scored.filter((item) => item.score >= Math.max(1, maxScore - 25));
  if (candidates.length > 1) {
    const lastMove = battle.botMoveHistory[battle.botMoveHistory.length - 1];
    const withoutRepeat = candidates.filter((item) => item.moveId !== lastMove);
    if (withoutRepeat.length > 0) candidates = withoutRepeat;
  }
  if (candidates.length > 1) {
    const recent = battle.botMoveHistory.slice(-4);
    const underLimit = candidates.filter(
      (item) => recent.filter((moveId) => moveId === item.moveId).length < 2
    );
    if (underLimit.length > 0) candidates = underLimit;
  }
  return randomItem(candidates).moveId;
}
function formatActorMove(moveId, actorLabel) {
  const effect = MOVE_META[moveId]?.effect;
  if (!effect) return `${actorLabel} used ${MOVE_LABELS[moveId] ?? `Move ${moveId}`}.`;
  return effect.replace(/\bYOUR\b/g, actorLabel === "You" ? "your" : "Garden Bot's").replace(/opponent/gi, actorLabel === "You" ? "Garden Bot" : "your tree");
}
function makeEntry(actor, moveId, prevPlayerGrowth, nextPlayerGrowth, prevOpponentGrowth, nextOpponentGrowth, details, label) {
  return {
    id: `${Date.now()}-${actor}-${moveId}-${Math.floor(practiceRandom() * 1e9).toString(16)}`,
    timestamp: Date.now(),
    actor,
    moveId,
    prevPlayerGrowth,
    nextPlayerGrowth,
    prevOpponentGrowth,
    nextOpponentGrowth,
    details,
    label
  };
}
function formatDelta(delta) {
  if (delta === 0) return "no change";
  return delta > 0 ? `+${delta}` : `${delta}`;
}
function playPracticeRoundInternal(battle, playerMoveId) {
  if (battle.finished || battle.winner) {
    return { battle, entries: [] };
  }
  if (!battle.player1Moves.includes(playerMoveId)) {
    throw new Error("That move is not in your Practice Mode hand.");
  }
  if (battle.playerMoveHistory[battle.playerMoveHistory.length - 1] === playerMoveId) {
    throw new Error("Choose a different move. The same card cannot be played twice in a row.");
  }
  const roundStartPlayerGrowth = battle.player1Growth;
  const roundStartBotGrowth = battle.player2Growth;
  const playerResolved = resolveMove(
    playerMoveId,
    battle.player1Growth,
    battle.player2Growth,
    battle.playerStatus,
    battle.botStatus,
    "You",
    "Garden Bot",
    battle.playerMoveHistory[battle.playerMoveHistory.length - 1],
    battle.botMoveHistory[battle.botMoveHistory.length - 1],
    battle.totalTurns
  );
  let nextBattle = {
    ...battle,
    player1Growth: playerResolved.selfGrowth,
    player2Growth: playerResolved.opponentGrowth,
    playerStatus: playerResolved.selfStatus,
    botStatus: playerResolved.opponentStatus,
    playerMoveHistory: [...battle.playerMoveHistory, playerMoveId].slice(-8),
    allPlayerMoves: [...battle.allPlayerMoves, playerMoveId],
    totalTurns: battle.totalTurns + 1,
    lastMoveMs: Date.now()
  };
  const playerWon = nextBattle.player1Growth >= PRACTICE_TARGET_GROWTH;
  let botMoveId = 0;
  let botResolved = null;
  if (!playerWon) {
    botMoveId = choosePracticeBotMove(nextBattle);
    botResolved = resolveMove(
      botMoveId,
      nextBattle.player2Growth,
      nextBattle.player1Growth,
      nextBattle.botStatus,
      nextBattle.playerStatus,
      "Garden Bot",
      "Your tree",
      nextBattle.botMoveHistory[nextBattle.botMoveHistory.length - 1],
      nextBattle.playerMoveHistory[nextBattle.playerMoveHistory.length - 1],
      nextBattle.totalTurns
    );
    nextBattle = {
      ...nextBattle,
      player1Growth: botResolved.opponentGrowth,
      player2Growth: botResolved.selfGrowth,
      playerStatus: botResolved.opponentStatus,
      botStatus: botResolved.selfStatus,
      botMoveHistory: [...nextBattle.botMoveHistory, botMoveId].slice(-8),
      allBotMoves: [...nextBattle.allBotMoves, botMoveId],
      totalTurns: nextBattle.totalTurns + 1,
      lastMoveMs: Date.now()
    };
  }
  const winner = nextBattle.player1Growth >= PRACTICE_TARGET_GROWTH ? PRACTICE_PLAYER_ADDRESS : nextBattle.player2Growth >= PRACTICE_TARGET_GROWTH ? PRACTICE_BOT_ADDRESS : null;
  nextBattle = {
    ...nextBattle,
    finished: !!winner,
    winner
  };
  const playerDelta = nextBattle.player1Growth - roundStartPlayerGrowth;
  const botDelta = nextBattle.player2Growth - roundStartBotGrowth;
  const entries = [
    makeEntry(
      "you",
      playerMoveId,
      roundStartPlayerGrowth,
      playerResolved.selfGrowth,
      roundStartBotGrowth,
      playerResolved.opponentGrowth,
      [formatActorMove(playerMoveId, "You"), ...playerResolved.outcome.notes]
    )
  ];
  if (botResolved && botMoveId) {
    entries.push(
      makeEntry(
        "opponent",
        botMoveId,
        playerResolved.selfGrowth,
        nextBattle.player1Growth,
        playerResolved.opponentGrowth,
        nextBattle.player2Growth,
        [formatActorMove(botMoveId, "Garden Bot"), ...botResolved.outcome.notes],
        MOVE_LABELS[botMoveId] ?? `Garden Bot Move #${botMoveId}`
      )
    );
  }
  entries.push(
    makeEntry(
      "round",
      0,
      roundStartPlayerGrowth,
      nextBattle.player1Growth,
      roundStartBotGrowth,
      nextBattle.player2Growth,
      [
        `Round result: You ${nextBattle.player1Growth} / ${PRACTICE_TARGET_GROWTH} - Garden Bot ${nextBattle.player2Growth} / ${PRACTICE_TARGET_GROWTH}`,
        `Your tree: ${roundStartPlayerGrowth} -> ${nextBattle.player1Growth} (${formatDelta(playerDelta)})`,
        `Garden Bot: ${roundStartBotGrowth} -> ${nextBattle.player2Growth} (${formatDelta(botDelta)})`,
        ...winner ? [
          winner === PRACTICE_PLAYER_ADDRESS ? "You reached the Practice Mode target first." : "Garden Bot reached the Practice Mode target first."
        ] : []
      ],
      "Round Result"
    )
  );
  return { battle: nextBattle, entries };
}
function playPracticeRound(battle, playerMoveId) {
  if (battle.randomState === void 0) {
    return playPracticeRoundInternal(battle, playerMoveId);
  }
  const previousState = seededRandomState;
  seededRandomState = battle.randomState >>> 0;
  try {
    const result = playPracticeRoundInternal(battle, playerMoveId);
    result.battle.randomState = seededRandomState;
    return result;
  } finally {
    seededRandomState = previousState;
  }
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/vendor/arcade-trials-engine/runtime/trial-game.mjs
var FIFTH_MOVE_IDS = [31, 32, 33, 34, 35, 36, 37, 38, 39];
var DIAGNOSIS_TYPES = ["attack", "growth", "hybrid"];
var DIAGNOSIS_COUNTER = {
  attack: "hybrid",
  growth: "attack",
  hybrid: "growth"
};
function getDiagnosisSchedule(seed) {
  const offset = seed % DIAGNOSIS_TYPES.length;
  return DIAGNOSIS_TYPES.map(
    (_, index) => DIAGNOSIS_TYPES[(index + offset) % DIAGNOSIS_TYPES.length]
  );
}
function getDailyTrialFifthMoveId(challenge) {
  return FIFTH_MOVE_IDS[challenge.seed % FIFTH_MOVE_IDS.length];
}
function createArboristTrialBattle(challenge, fifthMoveUnlocked, engine = challenge.simulationVersion === 2 ? "portable-v1" : "legacy-v8") {
  return createPracticeBattle({
    trialEngine: engine,
    seed: challenge.seed,
    mode: "arborist-trial",
    challengeId: challenge.id,
    playerStartGrowth: challenge.playerStartGrowth,
    botStartGrowth: challenge.botStartGrowth,
    bonusMoveId: fifthMoveUnlocked ? getDailyTrialFifthMoveId(challenge) : null,
    botMoveTypeSchedule: challenge.rule === "canopy_diagnosis" ? getDiagnosisSchedule(challenge.seed) : void 0
  });
}
function getCanopyDiagnosisForecast(battle, challenge) {
  if (challenge.rule !== "canopy_diagnosis") return null;
  const schedule = battle.botMoveTypeSchedule ?? getDiagnosisSchedule(challenge.seed);
  return schedule[battle.allBotMoves.length % schedule.length];
}
function getToolbeltLockedMoveIds(battle, challenge) {
  if (challenge.rule !== "toolbelt_rotation") return /* @__PURE__ */ new Set();
  const standardMoves = new Set(battle.player1Moves.slice(0, 4));
  const usedThisCycle = /* @__PURE__ */ new Set();
  for (const moveId of battle.allPlayerMoves) {
    if (!standardMoves.has(moveId)) continue;
    usedThisCycle.add(moveId);
    if (usedThisCycle.size === standardMoves.size) usedThisCycle.clear();
  }
  return usedThisCycle;
}
function isArboristTrialMoveDisabled(battle, challenge, moveId) {
  if (battle.playerMoveHistory.at(-1) === moveId) return true;
  return getToolbeltLockedMoveIds(battle, challenge).has(moveId);
}
function playArboristTrialRound(battle, challenge, moveId) {
  if (isArboristTrialMoveDisabled(battle, challenge, moveId)) {
    throw new Error(
      challenge.rule === "toolbelt_rotation" ? "That tool is locked until the other standard cards have been used." : "Choose a different move. The same card cannot be played twice in a row."
    );
  }
  const result = playPracticeRound(battle, moveId);
  if (challenge.rule !== "storm_response" || result.battle.finished || result.battle.totalTurns % 2 !== 0) {
    return result;
  }
  const completedRound = result.battle.totalTurns / 2;
  if (completedRound % 3 !== 0) return result;
  const beforePlayer = result.battle.player1Growth;
  const beforeBot = result.battle.player2Growth;
  const nextBattle = {
    ...result.battle,
    player1Growth: Math.max(0, beforePlayer - 4),
    player2Growth: Math.max(0, beforeBot - 4)
  };
  const stormEntry = {
    id: `${nextBattle.battleId}-storm-${completedRound}`,
    timestamp: Date.now(),
    actor: "round",
    moveId: 0,
    prevPlayerGrowth: beforePlayer,
    nextPlayerGrowth: nextBattle.player1Growth,
    prevOpponentGrowth: beforeBot,
    nextOpponentGrowth: nextBattle.player2Growth,
    label: "Storm Front",
    details: [
      `Round ${completedRound}: storm damage stripped ${beforePlayer - nextBattle.player1Growth} Growth from your tree.`,
      `Storm damage stripped ${beforeBot - nextBattle.player2Growth} Growth from Garden Bot.`
    ]
  };
  return { battle: nextBattle, entries: [...result.entries, stormEntry] };
}
function getSpecialtyResult(battle, challenge) {
  const won = battle.winner === PRACTICE_PLAYER_ADDRESS;
  if (challenge.rule === "canopy_diagnosis") {
    const correctCounters = battle.allBotMoves.reduce((total, botMoveId, index) => {
      const botType = MOVE_META[botMoveId]?.type;
      const playerType = MOVE_META[battle.allPlayerMoves[index]]?.type;
      return total + (botType && playerType === DIAGNOSIS_COUNTER[botType] ? 1 : 0);
    }, 0);
    return {
      specialtyBonus: correctCounters * 300,
      specialtySummary: `${correctCounters} diagnosed threat${correctCounters === 1 ? "" : "s"} countered`
    };
  }
  if (challenge.rule === "toolbelt_rotation") {
    const standardMoves = new Set(battle.player1Moves.slice(0, 4));
    const standardPlays = battle.allPlayerMoves.filter((moveId) => standardMoves.has(moveId)).length;
    const cycles = Math.floor(standardPlays / Math.max(1, standardMoves.size));
    return {
      specialtyBonus: cycles * 600,
      specialtySummary: `${cycles} complete Toolbelt cycle${cycles === 1 ? "" : "s"}`
    };
  }
  if (challenge.rule === "storm_response") {
    const stormsWeathered = Math.floor(Math.max(1, Math.ceil(battle.totalTurns / 2)) / 3);
    return {
      specialtyBonus: won ? 1e3 : 0,
      specialtySummary: `${stormsWeathered} storm front${stormsWeathered === 1 ? "" : "s"} weathered`
    };
  }
  if (challenge.rule === "integrated_pest_management") {
    const attackPlays = battle.allPlayerMoves.filter(
      (moveId) => MOVE_META[moveId]?.type === "attack"
    ).length;
    const specialtyBonus = won ? attackPlays <= 2 ? 1500 : attackPlays === 3 ? 1e3 : attackPlays === 4 ? 500 : 0 : 0;
    return {
      specialtyBonus,
      specialtySummary: `${attackPlays} Attack card${attackPlays === 1 ? "" : "s"} used`
    };
  }
  return { specialtyBonus: 0, specialtySummary: null };
}
function getArboristTrialResult(battle, challenge) {
  const specialty = challenge ? getSpecialtyResult(battle, challenge) : { specialtyBonus: 0, specialtySummary: null };
  return {
    won: battle.winner === PRACTICE_PLAYER_ADDRESS,
    rounds: Math.max(1, Math.ceil(battle.totalTurns / 2)),
    playerGrowth: battle.player1Growth,
    botGrowth: battle.player2Growth,
    uniqueMoves: new Set(battle.allPlayerMoves).size,
    ...specialty
  };
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/scripts/arcade-campaigns/trials-adapter.mjs
var ADAPTER = Object.freeze({
  id: "arborist-trials-portable-four-card",
  version: "1.0.0",
  gameId: "arborist-trials",
  gameVersion: "campaign-pilot-4a27b3ac-v1",
  gameRuleset: "portable-v1-four-card",
  sourceHash: provenance_default.sourceHash
});
var MAX_MOVES = 100;
var ENGINE = "portable-v1";
var sha = (text) => createHash2("sha256").update(text).digest("hex");
function freeze(value) {
  if (value && typeof value === "object") {
    Object.values(value).forEach(freeze);
    Object.freeze(value);
  }
  return value;
}
var TrialReplayError = class extends Error {
  constructor(code, message) {
    super(message);
    this.name = "TrialReplayError";
    this.code = code;
  }
};
var fail = (code, message) => {
  throw new TrialReplayError(code, message);
};
function createChallenge(seedHex, dateKey) {
  if (typeof seedHex !== "string" || !/^[a-f0-9]{64}$/.test(seedHex)) fail("invalid-seed", "Use 32 bytes of server entropy encoded as lowercase hex.");
  if (typeof dateKey !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) fail("invalid-date", "Use a valid UTC calendar date.");
  const date = /* @__PURE__ */ new Date(dateKey + "T00:00:00.000Z");
  if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== dateKey || dateKey < "2026-09-03") fail("invalid-date", "This pilot supports portable trial dates from September 3, 2026.");
  const seedDigest = sha("tree-arcade:arborist-trials:four-card:v1\n" + seedHex + "\n" + dateKey);
  const trial = getArboristTrialChallenge(date);
  return freeze({
    schemaVersion: 1,
    kind: "nonpaying-arborist-trial-challenge",
    adapterId: ADAPTER.id,
    adapterVersion: ADAPTER.version,
    sourceHash: ADAPTER.sourceHash,
    seedHex,
    dateKey,
    engine: ENGINE,
    fifthMoveUnlocked: false,
    maxMoves: MAX_MOVES,
    trial: { ...trial, id: "campaign-trial-" + dateKey + "-" + seedDigest.slice(0, 24), seed: Number.parseInt(seedDigest.slice(0, 8), 16), simulationVersion: 2 }
  });
}
function verifiedChallenge(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) fail("invalid-challenge", "Use a server-issued pilot challenge.");
  let expected;
  try {
    expected = createChallenge(input.seedHex, input.dateKey);
    if (canonicalJson(input) !== canonicalJson(expected)) fail("invalid-challenge", "The challenge does not match the pinned engine and fixed rules.");
  } catch (error) {
    if (error instanceof TrialReplayError && error.code === "invalid-challenge") throw error;
    fail("invalid-challenge", "The challenge does not match the pinned engine and fixed rules.");
  }
  return expected;
}
function visibleStatus(status) {
  return {
    blockTurns: status.blockTurns,
    poisonTicks: status.poisonTicks,
    poisonGrowthPerTurn: status.poisonDpt,
    delayedGrowthLoss: status.nextTurnPenalty,
    reflectedGrowth: status.reflectDamage,
    armorHalvesNextHit: status.armorHalf,
    nextAttackCap: status.attackCap
  };
}
function inspectReplay(challengeInput, moves) {
  const challenge = verifiedChallenge(challengeInput);
  if (!Array.isArray(moves) || moves.length > MAX_MOVES || Object.keys(moves).length !== moves.length || moves.some((move) => !Number.isSafeInteger(move) || move < 1 || move > 30)) fail("invalid-moves", "Use a dense list of at most 100 integer standard-card IDs.");
  let battle = createArboristTrialBattle(challenge.trial, false, ENGINE);
  let entries = [];
  for (const move of moves) {
    if (battle.finished) fail("moves-after-finish", "A finished game cannot accept additional moves.");
    try {
      const round = playArboristTrialRound(battle, challenge.trial, move);
      battle = round.battle;
      entries = round.entries;
    } catch {
      fail("illegal-move", "The move is outside the dealt hand, repeats the previous card or violates the current trial rule.");
    }
  }
  const result = getArboristTrialResult(battle, challenge.trial);
  const atLimit = moves.length === MAX_MOVES && !battle.finished;
  const legalMoveIds = battle.finished || atLimit ? [] : battle.player1Moves.filter((id) => !isArboristTrialMoveDisabled(battle, challenge.trial, id));
  const cards = battle.player1Moves.map((id) => ({
    id,
    name: MOVE_LABELS[id],
    type: MOVE_META[id].type,
    description: MOVE_META[id].effect,
    playable: legalMoveIds.includes(id)
  }));
  const rounds = moves.length ? result.rounds : 0;
  return freeze({
    completed: battle.finished,
    won: result.won,
    score: calculateArboristTrialScore(result),
    rounds,
    turns: battle.totalTurns,
    playerGrowth: result.playerGrowth,
    botGrowth: result.botGrowth,
    uniqueMoves: result.uniqueMoves,
    specialtyBonus: result.specialtyBonus,
    moveCount: moves.length,
    view: {
      phase: battle.finished ? result.won ? "won" : "lost" : atLimit ? "move-limit" : "playing",
      round: battle.finished || atLimit ? rounds : rounds + 1,
      playerGrowth: result.playerGrowth,
      botGrowth: result.botGrowth,
      targetGrowth: challenge.trial.targetGrowth,
      moveCount: moves.length,
      maxMoves: MAX_MOVES,
      remainingMoves: MAX_MOVES - moves.length,
      cards,
      legalMoveIds,
      playerStatus: visibleStatus(battle.playerStatus),
      botStatus: visibleStatus(battle.botStatus),
      forecast: battle.finished || atLimit ? null : getCanopyDiagnosisForecast(battle, challenge.trial),
      lastRound: entries.map(({ actor, moveId, prevPlayerGrowth, nextPlayerGrowth, prevOpponentGrowth, nextOpponentGrowth, details, label }) => ({
        actor,
        moveId,
        prevPlayerGrowth,
        nextPlayerGrowth,
        prevOpponentGrowth,
        nextOpponentGrowth,
        details: [...details],
        label: label ?? null
      }))
    }
  });
}
function publicChallenge(input) {
  const challenge = verifiedChallenge(input);
  return freeze({
    schemaVersion: 1,
    kind: "arborist-trial-no-prize-pilot",
    adapter: { ...ADAPTER },
    dateKey: challenge.dateKey,
    title: challenge.trial.title,
    subtitle: challenge.trial.subtitle,
    description: challenge.trial.description,
    rule: challenge.trial.rule,
    ruleDescription: challenge.trial.ruleDescription,
    targetGrowth: challenge.trial.targetGrowth,
    fifthCardEnabled: false,
    maxMoves: MAX_MOVES,
    view: inspectReplay(challenge, []).view
  });
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/scripts/arcade-campaigns/pilot-rules.mjs
var ID = /^[a-z0-9][a-z0-9-]{5,79}$/;
var plain2 = (value) => value !== null && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
var exact = (value, keys) => plain2(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key));
function makePilotRules({ pilotId, challengeDate, startsAt, endsAt, maxAttemptSeconds = 900 }) {
  if (typeof pilotId !== "string" || !ID.test(pilotId)) throw Error("Choose a pilot ID of 6\u201380 lowercase letters, digits or hyphens.");
  if (!Number.isFinite(utcMillis(startsAt)) || !Number.isFinite(utcMillis(endsAt)) || utcMillis(endsAt) <= utcMillis(startsAt)) throw Error("Choose an explicit inclusive start and exclusive end in UTC.");
  if (!Number.isSafeInteger(maxAttemptSeconds) || maxAttemptSeconds < 60 || maxAttemptSeconds > 3600) throw Error("Choose an attempt duration from 60 to 3600 seconds.");
  createChallenge("0".repeat(64), challengeDate);
  return {
    schemaVersion: 1,
    mode: "nonpaying-pilot",
    pilotId,
    game: { id: ADAPTER.gameId, version: ADAPTER.gameVersion, ruleset: ADAPTER.gameRuleset, sourceHash: ADAPTER.sourceHash },
    adapter: { id: ADAPTER.id, version: ADAPTER.version },
    challengeDate,
    window: { startsAt, endsAt },
    maxAttemptSeconds,
    objective: { metric: "wins", operator: "eq", targetUnits: "1" },
    access: { entry: "free", purchaseRequired: false, standardCards: 4, paidAdvantages: "forbidden" },
    identityScope: "wallet-session-only",
    payable: false,
    prizeEligible: false,
    awardsEnabled: false
  };
}
function verifyPilotRules(input) {
  if (!exact(input, ["schemaVersion", "mode", "pilotId", "game", "adapter", "challengeDate", "window", "maxAttemptSeconds", "objective", "access", "identityScope", "payable", "prizeEligible", "awardsEnabled"]) || !exact(input.window, ["startsAt", "endsAt"])) throw Error("Unsupported pilot rules.");
  const expected = makePilotRules({ pilotId: input.pilotId, challengeDate: input.challengeDate, startsAt: input.window.startsAt, endsAt: input.window.endsAt, maxAttemptSeconds: input.maxAttemptSeconds });
  if (canonicalJson(input) !== canonicalJson(expected)) throw Error("The pilot does not match the pinned four-card, no-prize rules.");
  return { rules: expected, rulesHash: contentHash(expected) };
}
function verifyPilotRecord(record) {
  if (!plain2(record)) throw Error("Pilot configuration is unavailable.");
  const frozen = verifyPilotRules(record.config);
  if (record.pilotId !== frozen.rules.pilotId || record.rulesHash !== frozen.rulesHash || record.adapterId !== ADAPTER.id || record.adapterVersion !== ADAPTER.version || record.sourceHash !== ADAPTER.sourceHash || Date.parse(record.startsAt) !== utcMillis(frozen.rules.window.startsAt) || Date.parse(record.endsAt) !== utcMillis(frozen.rules.window.endsAt) || record.maxAttemptSeconds !== frozen.rules.maxAttemptSeconds || !["draft", "enabled", "disabled"].includes(record.status) || record.enabled !== (record.status === "enabled") || record.mode !== "nonpaying-pilot" || record.payable !== false || record.prizeEligible !== false || record.awardsEnabled !== false || !Number.isFinite(Date.parse(record.serverNow))) throw Error("Pilot configuration binding is invalid.");
  return frozen;
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/scripts/arcade-campaigns/pilot-errors.mjs
var PilotError = class extends Error {
  constructor(code, message, status = 400) {
    super(message);
    this.name = "PilotError";
    this.code = code;
    this.status = status;
  }
};
function pilotDatabaseError(message) {
  const errors = [
    ["challenge-auth-invalid-input", "invalid-request", "Provide a valid pilot sign-in request.", 400],
    ["challenge-auth-rate-limit", "rate-limited", "Too many pilot sign-in requests. Please wait and try again.", 429],
    ["challenge-auth-invalid-challenge", "invalid-challenge", "Request a fresh pilot sign-in message.", 403],
    ["invalid-session", "invalid-session", "Sign in to the Arcade again.", 401],
    ["challenge-not-found", "pilot-not-found", "This pilot is unavailable.", 404],
    ["challenge-not-open", "pilot-not-open", "This pilot is not open for play.", 409],
    ["challenge-rules-conflict", "rules-changed", "Reload the pilot rules before starting.", 409],
    ["challenge-attempt-not-found", "attempt-not-found", "This attempt is unavailable for this session.", 404],
    ["challenge-attempt-expired", "attempt-expired", "This attempt has expired.", 409],
    ["challenge-attempt-completed", "attempt-finished", "This attempt has already finished.", 409],
    ["challenge-version-conflict", "version-conflict", "Reload the attempt before making another move.", 409],
    ["challenge-request-conflict", "request-conflict", "This request identifier was already used for a different move.", 409],
    ["challenge-attempt-limit", "attempt-limit", "Too many active attempts. Finish a current attempt or wait for it to expire.", 429]
  ];
  const found = errors.find(([marker]) => typeof message === "string" && message.includes(marker));
  return found ? new PilotError(found[1], found[2], found[3]) : new PilotError("service-unavailable", "Challenge verification is temporarily unavailable.", 503);
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/scripts/arcade-campaigns/pilot-rpc.mjs
var RPCS = /* @__PURE__ */ new Set(["arcade_challenge_pilot_read_session_v1", "arcade_challenge_pilot_auth_create_challenge_v1", "arcade_challenge_pilot_auth_read_challenge_v1", "arcade_challenge_pilot_auth_create_session_v1", "arcade_challenge_pilot_auth_revoke_session_v1", "arcade_challenge_pilot_load_config_v1", "arcade_challenge_pilot_start_v1", "arcade_challenge_pilot_load_attempt_v1", "arcade_challenge_pilot_commit_move_v1"]);
var env = (key) => globalThis.Netlify?.env?.get(key) ?? process.env[key];
function createPilotRpc({ getEnv = env, fetchImpl = fetch } = {}) {
  let url, secret;
  for (const prefix of ["ARCADE_GROWTH", "TREE_RAFFLE", "TREE_KNOWLEDGE_TRIAL"]) {
    url = getEnv(prefix + "_SUPABASE_URL");
    secret = getEnv(prefix + "_SUPABASE_SECRET_KEY");
    if (url || secret) break;
  }
  if (!url || !secret || !/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/.test(url)) throw new PilotError("service-unavailable", "Challenge verification is temporarily unavailable.", 503);
  return async (name, args) => {
    if (!RPCS.has(name)) throw new PilotError("service-unavailable", "Challenge verification is temporarily unavailable.", 503);
    let response, data;
    try {
      response = await fetchImpl(url.replace(/\/$/, "") + "/rest/v1/rpc/" + name, {
        method: "POST",
        headers: { apikey: secret, Authorization: "Bearer " + secret, "Content-Type": "application/json" },
        body: JSON.stringify(args),
        signal: AbortSignal.timeout(12e3)
      });
      data = await response.json();
    } catch {
      throw new PilotError("service-unavailable", "Challenge verification is temporarily unavailable.", 503);
    }
    if (!response.ok) throw pilotDatabaseError(data?.message);
    return data;
  };
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/scripts/arcade-campaigns/pilot-auth.mjs
import { createHash as createHash3, randomBytes, randomUUID } from "node:crypto";

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/cryptography/signature-scheme.mjs
var SIGNATURE_SCHEME_TO_FLAG = {
  ED25519: 0,
  Secp256k1: 1,
  Secp256r1: 2,
  MultiSig: 3,
  ZkLogin: 5,
  Passkey: 6
};
var SIGNATURE_SCHEME_TO_SIZE = {
  ED25519: 32,
  Secp256k1: 33,
  Secp256r1: 33,
  Passkey: 33
};
var SIGNATURE_FLAG_TO_SCHEME = {
  0: "ED25519",
  1: "Secp256k1",
  2: "Secp256r1",
  3: "MultiSig",
  5: "ZkLogin",
  6: "Passkey"
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/utils/suins.mjs
var SUI_NS_NAME_REGEX = /^(?!.*(^(?!@)|[-.@])($|[-.@]))(?:[a-z0-9-]{0,63}(?:\.[a-z0-9-]{0,63})*)?@[a-z0-9-]{0,63}$/i;
var SUI_NS_DOMAIN_REGEX = /^(?!.*(^|[-.])($|[-.]))(?:[a-z0-9-]{0,63}\.)+sui$/i;
var MAX_SUI_NS_NAME_LENGTH = 235;
function isValidSuiNSName(name) {
  if (name.length > MAX_SUI_NS_NAME_LENGTH) return false;
  if (name.includes("@")) return SUI_NS_NAME_REGEX.test(name);
  return SUI_NS_DOMAIN_REGEX.test(name);
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/utils/move-registry.mjs
var NAME_PATTERN = /^([a-z0-9]+(?:-[a-z0-9]+)*)$/;
var VERSION_REGEX = /^\d+$/;
var MAX_APP_SIZE = 64;
var NAME_SEPARATOR = "/";
var isValidNamedPackage = (name) => {
  const parts = name.split(NAME_SEPARATOR);
  if (parts.length < 2 || parts.length > 3) return false;
  const [org, app, version] = parts;
  if (version !== void 0 && !VERSION_REGEX.test(version)) return false;
  if (!isValidSuiNSName(org)) return false;
  return NAME_PATTERN.test(app) && app.length < MAX_APP_SIZE;
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/utils/sui-types.mjs
import { fromBase58, splitGenericParameters } from "@mysten/bcs";
var SUI_ADDRESS_LENGTH = 32;
function isValidSuiAddress(value) {
  return isHex(value) && getHexByteLength(value) === SUI_ADDRESS_LENGTH;
}
function parseTypeTag(type) {
  if (type.startsWith("vector<")) {
    if (!type.endsWith(">")) throw new Error(`Invalid type tag: ${type}`);
    const inner = type.slice(7, -1);
    if (!inner) throw new Error(`Invalid type tag: ${type}`);
    const parsed = parseTypeTag(inner);
    if (typeof parsed === "string") return `vector<${parsed}>`;
    return `vector<${normalizeStructTag(parsed)}>`;
  }
  if (!type.includes("::")) return type;
  return parseStructTag(type);
}
function parseStructTag(type) {
  const parts = type.split("::");
  if (parts.length < 3) throw new Error(`Invalid struct tag: ${type}`);
  const [address, module] = parts;
  if (!address || !module) throw new Error(`Invalid struct tag: ${type}`);
  const isMvrPackage = isValidNamedPackage(address);
  const rest = type.slice(address.length + module.length + 4);
  const name = rest.includes("<") ? rest.slice(0, rest.indexOf("<")) : rest;
  if (!name || rest.includes("<") && !rest.endsWith(">")) throw new Error(`Invalid struct tag: ${type}`);
  const typeParams = rest.includes("<") ? splitGenericParameters(rest.slice(rest.indexOf("<") + 1, rest.lastIndexOf(">"))).map((typeParam) => parseTypeTag(typeParam.trim())) : [];
  return {
    address: isMvrPackage ? address : normalizeSuiAddress(address),
    module,
    name,
    typeParams
  };
}
function normalizeStructTag(type) {
  if (typeof type === "string" && type.startsWith("vector<")) throw new Error("normalizeStructTag does not support vector types. Use normalizeTypeTag instead.");
  const { address, module, name, typeParams } = typeof type === "string" ? parseStructTag(type) : type;
  return `${address}::${module}::${name}${typeParams?.length > 0 ? `<${typeParams.map((typeParam) => typeof typeParam === "string" ? typeParam : normalizeStructTag(typeParam)).join(",")}>` : ""}`;
}
function normalizeSuiAddress(value, forceAdd0x = false) {
  let address = value.toLowerCase();
  if (!forceAdd0x && address.startsWith("0x")) address = address.slice(2);
  return `0x${address.padStart(SUI_ADDRESS_LENGTH * 2, "0")}`;
}
function isHex(value) {
  return /^(0x|0X)?[a-fA-F0-9]+$/.test(value) && value.length % 2 === 0;
}
function getHexByteLength(value) {
  return /^(0x|0X)/.test(value) ? (value.length - 2) / 2 : value.length / 2;
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/bcs/type-tag-serializer.mjs
import { splitGenericParameters as splitGenericParameters2 } from "@mysten/bcs";
var VECTOR_REGEX = /^vector<(.+)>$/;
var STRUCT_REGEX = /^([^:]+)::([^:]+)::([^<]+)(<(.+)>)?/;
var TypeTagSerializer = class TypeTagSerializer2 {
  static parseFromStr(str, normalizeAddress = false) {
    if (str === "address") return { address: null };
    else if (str === "bool") return { bool: null };
    else if (str === "u8") return { u8: null };
    else if (str === "u16") return { u16: null };
    else if (str === "u32") return { u32: null };
    else if (str === "u64") return { u64: null };
    else if (str === "u128") return { u128: null };
    else if (str === "u256") return { u256: null };
    else if (str === "signer") return { signer: null };
    const vectorMatch = str.match(VECTOR_REGEX);
    if (vectorMatch) return { vector: TypeTagSerializer2.parseFromStr(vectorMatch[1], normalizeAddress) };
    const structMatch = str.match(STRUCT_REGEX);
    if (structMatch) return { struct: {
      address: normalizeAddress ? normalizeSuiAddress(structMatch[1]) : structMatch[1],
      module: structMatch[2],
      name: structMatch[3],
      typeParams: structMatch[5] === void 0 ? [] : TypeTagSerializer2.parseStructTypeArgs(structMatch[5], normalizeAddress)
    } };
    throw new Error(`Encountered unexpected token when parsing type args for ${str}`);
  }
  static parseStructTypeArgs(str, normalizeAddress = false) {
    return splitGenericParameters2(str).map((tok) => TypeTagSerializer2.parseFromStr(tok, normalizeAddress));
  }
  static tagToString(tag) {
    if ("bool" in tag) return "bool";
    if ("u8" in tag) return "u8";
    if ("u16" in tag) return "u16";
    if ("u32" in tag) return "u32";
    if ("u64" in tag) return "u64";
    if ("u128" in tag) return "u128";
    if ("u256" in tag) return "u256";
    if ("address" in tag) return "address";
    if ("signer" in tag) return "signer";
    if ("vector" in tag) return `vector<${TypeTagSerializer2.tagToString(tag.vector)}>`;
    if ("struct" in tag) {
      const struct = tag.struct;
      const typeParams = struct.typeParams.map(TypeTagSerializer2.tagToString).join(", ");
      return `${struct.address}::${struct.module}::${struct.name}${typeParams ? `<${typeParams}>` : ""}`;
    }
    throw new Error("Invalid TypeTag");
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/bcs/bcs.mjs
import { bcs, fromBase58 as fromBase582, fromBase64, fromHex, toBase58, toBase64, toHex } from "@mysten/bcs";
function unsafe_u64(options) {
  return bcs.u64({
    name: "unsafe_u64",
    ...options
  }).transform({
    input: (val) => val,
    output: (val) => Number(val)
  });
}
function optionEnum(type) {
  return bcs.enum("Option", {
    None: null,
    Some: type
  });
}
var Address = bcs.bytes(SUI_ADDRESS_LENGTH).transform({
  validate: (val) => {
    const address = typeof val === "string" ? val : toHex(val);
    if (!address || !isValidSuiAddress(normalizeSuiAddress(address))) throw new Error(`Invalid Sui address ${address}`);
  },
  input: (val) => typeof val === "string" ? fromHex(normalizeSuiAddress(val)) : val,
  output: (val) => normalizeSuiAddress(toHex(val))
});
var ObjectDigest = bcs.byteVector().transform({
  name: "ObjectDigest",
  input: (value) => fromBase582(value),
  output: (value) => toBase58(new Uint8Array(value)),
  validate: (value) => {
    if (fromBase582(value).length !== 32) throw new Error("ObjectDigest must be 32 bytes");
  }
});
var SuiObjectRef = bcs.struct("SuiObjectRef", {
  objectId: Address,
  version: bcs.u64(),
  digest: ObjectDigest
});
var SharedObjectRef = bcs.struct("SharedObjectRef", {
  objectId: Address,
  initialSharedVersion: bcs.u64(),
  mutable: bcs.bool()
});
var ObjectArg = bcs.enum("ObjectArg", {
  ImmOrOwnedObject: SuiObjectRef,
  SharedObject: SharedObjectRef,
  Receiving: SuiObjectRef
});
var Owner = bcs.enum("Owner", {
  AddressOwner: Address,
  ObjectOwner: Address,
  Shared: bcs.struct("Shared", { initialSharedVersion: bcs.u64() }),
  Immutable: null,
  ConsensusAddressOwner: bcs.struct("ConsensusAddressOwner", {
    startVersion: bcs.u64(),
    owner: Address
  })
});
var Reservation = bcs.enum("Reservation", { MaxAmountU64: bcs.u64() });
var WithdrawalType = bcs.enum("WithdrawalType", { Balance: bcs.lazy(() => TypeTag) });
var WithdrawFrom = bcs.enum("WithdrawFrom", {
  Sender: null,
  Sponsor: null
});
var FundsWithdrawal = bcs.struct("FundsWithdrawal", {
  reservation: Reservation,
  typeArg: WithdrawalType,
  withdrawFrom: WithdrawFrom
});
var CallArg = bcs.enum("CallArg", {
  Pure: bcs.struct("Pure", { bytes: bcs.byteVector().transform({
    input: (val) => typeof val === "string" ? fromBase64(val) : val,
    output: (val) => toBase64(new Uint8Array(val))
  }) }),
  Object: ObjectArg,
  FundsWithdrawal
});
var InnerTypeTag = bcs.enum("TypeTag", {
  bool: null,
  u8: null,
  u64: null,
  u128: null,
  address: null,
  signer: null,
  vector: bcs.lazy(() => InnerTypeTag),
  struct: bcs.lazy(() => StructTag),
  u16: null,
  u32: null,
  u256: null
});
var TypeTag = InnerTypeTag.transform({
  input: (typeTag) => typeof typeTag === "string" ? TypeTagSerializer.parseFromStr(typeTag, true) : typeTag,
  output: (typeTag) => TypeTagSerializer.tagToString(typeTag)
});
var Argument = bcs.enum("Argument", {
  GasCoin: null,
  Input: bcs.u16(),
  Result: bcs.u16(),
  NestedResult: bcs.tuple([bcs.u16(), bcs.u16()])
});
var ProgrammableMoveCall = bcs.struct("ProgrammableMoveCall", {
  package: Address,
  module: bcs.string(),
  function: bcs.string(),
  typeArguments: bcs.vector(TypeTag),
  arguments: bcs.vector(Argument)
});
var Command = bcs.enum("Command", {
  MoveCall: ProgrammableMoveCall,
  TransferObjects: bcs.struct("TransferObjects", {
    objects: bcs.vector(Argument),
    address: Argument
  }),
  SplitCoins: bcs.struct("SplitCoins", {
    coin: Argument,
    amounts: bcs.vector(Argument)
  }),
  MergeCoins: bcs.struct("MergeCoins", {
    destination: Argument,
    sources: bcs.vector(Argument)
  }),
  Publish: bcs.struct("Publish", {
    modules: bcs.vector(bcs.byteVector().transform({
      input: (val) => typeof val === "string" ? fromBase64(val) : val,
      output: (val) => toBase64(new Uint8Array(val))
    })),
    dependencies: bcs.vector(Address)
  }),
  MakeMoveVec: bcs.struct("MakeMoveVec", {
    type: optionEnum(TypeTag).transform({
      input: (val) => val === null ? { None: true } : { Some: val },
      output: (val) => val.Some ?? null
    }),
    elements: bcs.vector(Argument)
  }),
  Upgrade: bcs.struct("Upgrade", {
    modules: bcs.vector(bcs.byteVector().transform({
      input: (val) => typeof val === "string" ? fromBase64(val) : val,
      output: (val) => toBase64(new Uint8Array(val))
    })),
    dependencies: bcs.vector(Address),
    package: Address,
    ticket: Argument
  })
});
var ProgrammableTransaction = bcs.struct("ProgrammableTransaction", {
  inputs: bcs.vector(CallArg),
  commands: bcs.vector(Command)
});
var ValidDuring = bcs.struct("ValidDuring", {
  minEpoch: bcs.option(bcs.u64()),
  maxEpoch: bcs.option(bcs.u64()),
  minTimestamp: bcs.option(bcs.u64()),
  maxTimestamp: bcs.option(bcs.u64()),
  chain: ObjectDigest,
  nonce: bcs.u32()
});
var TransactionExpiration = bcs.enum("TransactionExpiration", {
  None: null,
  Epoch: unsafe_u64(),
  ValidDuring
});
var StructTag = bcs.struct("StructTag", {
  address: Address,
  module: bcs.string(),
  name: bcs.string(),
  typeParams: bcs.vector(InnerTypeTag)
});
var GasData = bcs.struct("GasData", {
  payment: bcs.vector(SuiObjectRef),
  owner: Address,
  price: bcs.u64(),
  budget: bcs.u64()
});
var IntentScope = bcs.enum("IntentScope", {
  TransactionData: null,
  TransactionEffects: null,
  CheckpointSummary: null,
  PersonalMessage: null
});
var IntentVersion = bcs.enum("IntentVersion", { V0: null });
var AppId = bcs.enum("AppId", { Sui: null });
var Intent = bcs.struct("Intent", {
  scope: IntentScope,
  version: IntentVersion,
  appId: AppId
});
function IntentMessage(T) {
  return bcs.struct(`IntentMessage<${T.name}>`, {
    intent: Intent,
    value: T
  });
}
var CompressedSignature = bcs.enum("CompressedSignature", {
  ED25519: bcs.bytes(64),
  Secp256k1: bcs.bytes(64),
  Secp256r1: bcs.bytes(64),
  ZkLogin: bcs.byteVector(),
  Passkey: bcs.byteVector()
});
var PublicKey = bcs.enum("PublicKey", {
  ED25519: bcs.bytes(32),
  Secp256k1: bcs.bytes(33),
  Secp256r1: bcs.bytes(33),
  ZkLogin: bcs.byteVector(),
  Passkey: bcs.bytes(33)
});
var MultiSigPkMap = bcs.struct("MultiSigPkMap", {
  pubKey: PublicKey,
  weight: bcs.u8()
});
var MultiSigPublicKey = bcs.struct("MultiSigPublicKey", {
  pk_map: bcs.vector(MultiSigPkMap),
  threshold: bcs.u16()
});
var MultiSig = bcs.struct("MultiSig", {
  sigs: bcs.vector(CompressedSignature),
  bitmap: bcs.u16(),
  multisig_pk: MultiSigPublicKey
});
var base64String = bcs.byteVector().transform({
  input: (val) => typeof val === "string" ? fromBase64(val) : val,
  output: (val) => toBase64(new Uint8Array(val))
});
var PasskeyAuthenticator = bcs.struct("PasskeyAuthenticator", {
  authenticatorData: bcs.byteVector(),
  clientDataJson: bcs.string(),
  userSignature: bcs.byteVector()
});
var MoveObjectType = bcs.enum("MoveObjectType", {
  Other: StructTag,
  GasCoin: null,
  StakedSui: null,
  Coin: TypeTag,
  AccumulatorBalanceWrapper: null
});
var TypeOrigin = bcs.struct("TypeOrigin", {
  moduleName: bcs.string(),
  datatypeName: bcs.string(),
  package: Address
});
var UpgradeInfo = bcs.struct("UpgradeInfo", {
  upgradedId: Address,
  upgradedVersion: bcs.u64()
});
var MovePackage = bcs.struct("MovePackage", {
  id: Address,
  version: bcs.u64(),
  moduleMap: bcs.map(bcs.string(), bcs.byteVector()),
  typeOriginTable: bcs.vector(TypeOrigin),
  linkageTable: bcs.map(Address, UpgradeInfo)
});
var MoveObject = bcs.struct("MoveObject", {
  type: MoveObjectType,
  hasPublicTransfer: bcs.bool(),
  version: bcs.u64(),
  contents: bcs.byteVector()
});
var Data = bcs.enum("Data", {
  Move: MoveObject,
  Package: MovePackage
});
var ObjectInner = bcs.struct("ObjectInner", {
  data: Data,
  owner: Owner,
  previousTransaction: ObjectDigest,
  storageRebate: bcs.u64()
});

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/bcs/transactions.mjs
import { bcs as bcs2 } from "@mysten/bcs";
var ChangeEpoch = bcs2.struct("ChangeEpoch", {
  epoch: bcs2.u64(),
  protocolVersion: bcs2.u64(),
  storageCharge: bcs2.u64(),
  computationCharge: bcs2.u64(),
  storageRebate: bcs2.u64(),
  nonRefundableStorageFee: bcs2.u64(),
  epochStartTimestampMs: bcs2.u64(),
  systemPackages: bcs2.vector(bcs2.tuple([
    bcs2.u64(),
    bcs2.vector(bcs2.byteVector()),
    bcs2.vector(Address)
  ]))
});
var GenesisObject = bcs2.enum("GenesisObject", { RawObject: bcs2.struct("RawObject", {
  data: Data,
  owner: Owner
}) });
var GenesisTransaction = bcs2.struct("GenesisTransaction", { objects: bcs2.vector(GenesisObject) });
var ConsensusCommitPrologue = bcs2.struct("ConsensusCommitPrologue", {
  epoch: bcs2.u64(),
  round: bcs2.u64(),
  commitTimestampMs: bcs2.u64()
});
var ConsensusCommitPrologueV2 = bcs2.struct("ConsensusCommitPrologueV2", {
  epoch: bcs2.u64(),
  round: bcs2.u64(),
  commitTimestampMs: bcs2.u64(),
  consensusCommitDigest: ObjectDigest
});
var ConsensusDeterminedVersionAssignments = bcs2.enum("ConsensusDeterminedVersionAssignments", {
  CancelledTransactions: bcs2.vector(bcs2.tuple([ObjectDigest, bcs2.vector(bcs2.tuple([Address, bcs2.u64()]))])),
  CancelledTransactionsV2: bcs2.vector(bcs2.tuple([ObjectDigest, bcs2.vector(bcs2.tuple([bcs2.tuple([Address, bcs2.u64()]), bcs2.u64()]))]))
});
var ConsensusCommitPrologueV3 = bcs2.struct("ConsensusCommitPrologueV3", {
  epoch: bcs2.u64(),
  round: bcs2.u64(),
  subDagIndex: bcs2.option(bcs2.u64()),
  commitTimestampMs: bcs2.u64(),
  consensusCommitDigest: ObjectDigest,
  consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments
});
var ConsensusCommitPrologueV4 = bcs2.struct("ConsensusCommitPrologueV4", {
  epoch: bcs2.u64(),
  round: bcs2.u64(),
  subDagIndex: bcs2.option(bcs2.u64()),
  commitTimestampMs: bcs2.u64(),
  consensusCommitDigest: ObjectDigest,
  consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments,
  additionalStateDigest: ObjectDigest
});
var ActiveJwk = bcs2.struct("ActiveJwk", {
  jwkId: bcs2.struct("JwkId", {
    iss: bcs2.string(),
    kid: bcs2.string()
  }),
  jwk: bcs2.struct("JWK", {
    kty: bcs2.string(),
    e: bcs2.string(),
    n: bcs2.string(),
    alg: bcs2.string()
  }),
  epoch: bcs2.u64()
});
var AuthenticatorStateUpdate = bcs2.struct("AuthenticatorStateUpdate", {
  epoch: bcs2.u64(),
  round: bcs2.u64(),
  newActiveJwks: bcs2.vector(ActiveJwk),
  authenticatorObjInitialSharedVersion: bcs2.u64()
});
var RandomnessStateUpdate = bcs2.struct("RandomnessStateUpdate", {
  epoch: bcs2.u64(),
  randomnessRound: bcs2.u64(),
  randomBytes: bcs2.byteVector(),
  randomnessObjInitialSharedVersion: bcs2.u64()
});
var AuthenticatorStateExpire = bcs2.struct("AuthenticatorStateExpire", {
  minEpoch: bcs2.u64(),
  authenticatorObjInitialSharedVersion: bcs2.u64()
});
var ExecutionTimeObservationKey = bcs2.enum("ExecutionTimeObservationKey", {
  MoveEntryPoint: bcs2.struct("MoveEntryPoint", {
    package: Address,
    module: bcs2.string(),
    function: bcs2.string(),
    typeArguments: bcs2.vector(TypeTag)
  }),
  TransferObjects: null,
  SplitCoins: null,
  MergeCoins: null,
  Publish: null,
  MakeMoveVec: null,
  Upgrade: null
});
var StoredExecutionTimeObservations = bcs2.enum("StoredExecutionTimeObservations", { V1: bcs2.vector(bcs2.tuple([ExecutionTimeObservationKey, bcs2.vector(bcs2.tuple([bcs2.byteVector(), bcs2.struct("Duration", {
  secs: bcs2.u64(),
  nanos: bcs2.u32()
})]))])) });
var WriteAccumulatorStorageCost = bcs2.struct("WriteAccumulatorStorageCost", { storageCost: bcs2.u64() });
var EndOfEpochTransactionKind = bcs2.enum("EndOfEpochTransactionKind", {
  ChangeEpoch,
  AuthenticatorStateCreate: null,
  AuthenticatorStateExpire,
  RandomnessStateCreate: null,
  DenyListStateCreate: null,
  BridgeStateCreate: ObjectDigest,
  BridgeCommitteeInit: bcs2.u64(),
  StoreExecutionTimeObservations: StoredExecutionTimeObservations,
  AccumulatorRootCreate: null,
  CoinRegistryCreate: null,
  DisplayRegistryCreate: null,
  AddressAliasStateCreate: null,
  WriteAccumulatorStorageCost
});
var TransactionKind = bcs2.enum("TransactionKind", {
  ProgrammableTransaction,
  ChangeEpoch,
  Genesis: GenesisTransaction,
  ConsensusCommitPrologue,
  AuthenticatorStateUpdate,
  EndOfEpochTransaction: bcs2.vector(EndOfEpochTransactionKind),
  RandomnessStateUpdate,
  ConsensusCommitPrologueV2,
  ConsensusCommitPrologueV3,
  ConsensusCommitPrologueV4,
  ProgrammableSystemTransaction: ProgrammableTransaction
});
var TransactionDataV1 = bcs2.struct("TransactionDataV1", {
  kind: TransactionKind,
  sender: Address,
  gasData: GasData,
  expiration: TransactionExpiration
});
var TransactionData = bcs2.enum("TransactionData", { V1: TransactionDataV1 });
var SenderSignedTransaction = bcs2.struct("SenderSignedTransaction", {
  intentMessage: IntentMessage(TransactionData),
  txSignatures: bcs2.vector(base64String)
});
var SenderSignedData = bcs2.vector(SenderSignedTransaction, { name: "SenderSignedData" });

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/bcs/effects.mjs
import { bcs as bcs3 } from "@mysten/bcs";
var PackageUpgradeError = bcs3.enum("PackageUpgradeError", {
  UnableToFetchPackage: bcs3.struct("UnableToFetchPackage", { packageId: Address }),
  NotAPackage: bcs3.struct("NotAPackage", { objectId: Address }),
  IncompatibleUpgrade: null,
  DigestDoesNotMatch: bcs3.struct("DigestDoesNotMatch", { digest: bcs3.byteVector() }),
  UnknownUpgradePolicy: bcs3.struct("UnknownUpgradePolicy", { policy: bcs3.u8() }),
  PackageIDDoesNotMatch: bcs3.struct("PackageIDDoesNotMatch", {
    packageId: Address,
    ticketId: Address
  })
});
var ModuleId = bcs3.struct("ModuleId", {
  address: Address,
  name: bcs3.string()
});
var MoveLocation = bcs3.struct("MoveLocation", {
  module: ModuleId,
  function: bcs3.u16(),
  instruction: bcs3.u16(),
  functionName: bcs3.option(bcs3.string())
});
var CommandArgumentError = bcs3.enum("CommandArgumentError", {
  TypeMismatch: null,
  InvalidBCSBytes: null,
  InvalidUsageOfPureArg: null,
  InvalidArgumentToPrivateEntryFunction: null,
  IndexOutOfBounds: bcs3.struct("IndexOutOfBounds", { idx: bcs3.u16() }),
  SecondaryIndexOutOfBounds: bcs3.struct("SecondaryIndexOutOfBounds", {
    resultIdx: bcs3.u16(),
    secondaryIdx: bcs3.u16()
  }),
  InvalidResultArity: bcs3.struct("InvalidResultArity", { resultIdx: bcs3.u16() }),
  InvalidGasCoinUsage: null,
  InvalidValueUsage: null,
  InvalidObjectByValue: null,
  InvalidObjectByMutRef: null,
  SharedObjectOperationNotAllowed: null,
  InvalidArgumentArity: null,
  InvalidTransferObject: null,
  InvalidMakeMoveVecNonObjectArgument: null,
  ArgumentWithoutValue: null,
  CannotMoveBorrowedValue: null,
  CannotWriteToExtendedReference: null,
  InvalidReferenceArgument: null
});
var TypeArgumentError = bcs3.enum("TypeArgumentError", {
  TypeNotFound: null,
  ConstraintNotSatisfied: null
});
var ExecutionFailureStatus = bcs3.enum("ExecutionFailureStatus", {
  InsufficientGas: null,
  InvalidGasObject: null,
  InvariantViolation: null,
  FeatureNotYetSupported: null,
  MoveObjectTooBig: bcs3.struct("MoveObjectTooBig", {
    objectSize: bcs3.u64(),
    maxObjectSize: bcs3.u64()
  }),
  MovePackageTooBig: bcs3.struct("MovePackageTooBig", {
    objectSize: bcs3.u64(),
    maxObjectSize: bcs3.u64()
  }),
  CircularObjectOwnership: bcs3.struct("CircularObjectOwnership", { object: Address }),
  InsufficientCoinBalance: null,
  CoinBalanceOverflow: null,
  PublishErrorNonZeroAddress: null,
  SuiMoveVerificationError: null,
  MovePrimitiveRuntimeError: bcs3.option(MoveLocation),
  MoveAbort: bcs3.tuple([MoveLocation, bcs3.u64()]),
  VMVerificationOrDeserializationError: null,
  VMInvariantViolation: null,
  FunctionNotFound: null,
  ArityMismatch: null,
  TypeArityMismatch: null,
  NonEntryFunctionInvoked: null,
  CommandArgumentError: bcs3.struct("CommandArgumentError", {
    argIdx: bcs3.u16(),
    kind: CommandArgumentError
  }),
  TypeArgumentError: bcs3.struct("TypeArgumentError", {
    argumentIdx: bcs3.u16(),
    kind: TypeArgumentError
  }),
  UnusedValueWithoutDrop: bcs3.struct("UnusedValueWithoutDrop", {
    resultIdx: bcs3.u16(),
    secondaryIdx: bcs3.u16()
  }),
  InvalidPublicFunctionReturnType: bcs3.struct("InvalidPublicFunctionReturnType", { idx: bcs3.u16() }),
  InvalidTransferObject: null,
  EffectsTooLarge: bcs3.struct("EffectsTooLarge", {
    currentSize: bcs3.u64(),
    maxSize: bcs3.u64()
  }),
  PublishUpgradeMissingDependency: null,
  PublishUpgradeDependencyDowngrade: null,
  PackageUpgradeError: bcs3.struct("PackageUpgradeError", { upgradeError: PackageUpgradeError }),
  WrittenObjectsTooLarge: bcs3.struct("WrittenObjectsTooLarge", {
    currentSize: bcs3.u64(),
    maxSize: bcs3.u64()
  }),
  CertificateDenied: null,
  SuiMoveVerificationTimedout: null,
  SharedObjectOperationNotAllowed: null,
  InputObjectDeleted: null,
  ExecutionCancelledDueToSharedObjectCongestion: bcs3.struct("ExecutionCancelledDueToSharedObjectCongestion", { congested_objects: bcs3.vector(Address) }),
  AddressDeniedForCoin: bcs3.struct("AddressDeniedForCoin", {
    address: Address,
    coinType: bcs3.string()
  }),
  CoinTypeGlobalPause: bcs3.struct("CoinTypeGlobalPause", { coinType: bcs3.string() }),
  ExecutionCancelledDueToRandomnessUnavailable: null,
  MoveVectorElemTooBig: bcs3.struct("MoveVectorElemTooBig", {
    valueSize: bcs3.u64(),
    maxScaledSize: bcs3.u64()
  }),
  MoveRawValueTooBig: bcs3.struct("MoveRawValueTooBig", {
    valueSize: bcs3.u64(),
    maxScaledSize: bcs3.u64()
  }),
  InvalidLinkage: null,
  InsufficientBalanceForWithdraw: null,
  NonExclusiveWriteInputObjectModified: bcs3.struct("NonExclusiveWriteInputObjectModified", { id: Address })
});
var ExecutionStatus = bcs3.enum("ExecutionStatus", {
  Success: null,
  Failure: bcs3.struct("Failure", {
    error: ExecutionFailureStatus,
    command: bcs3.option(bcs3.u64())
  })
});
var GasCostSummary = bcs3.struct("GasCostSummary", {
  computationCost: bcs3.u64(),
  storageCost: bcs3.u64(),
  storageRebate: bcs3.u64(),
  nonRefundableStorageFee: bcs3.u64()
});
var TransactionEffectsV1 = bcs3.struct("TransactionEffectsV1", {
  status: ExecutionStatus,
  executedEpoch: bcs3.u64(),
  gasUsed: GasCostSummary,
  modifiedAtVersions: bcs3.vector(bcs3.tuple([Address, bcs3.u64()])),
  sharedObjects: bcs3.vector(SuiObjectRef),
  transactionDigest: ObjectDigest,
  created: bcs3.vector(bcs3.tuple([SuiObjectRef, Owner])),
  mutated: bcs3.vector(bcs3.tuple([SuiObjectRef, Owner])),
  unwrapped: bcs3.vector(bcs3.tuple([SuiObjectRef, Owner])),
  deleted: bcs3.vector(SuiObjectRef),
  unwrappedThenDeleted: bcs3.vector(SuiObjectRef),
  wrapped: bcs3.vector(SuiObjectRef),
  gasObject: bcs3.tuple([SuiObjectRef, Owner]),
  eventsDigest: bcs3.option(ObjectDigest),
  dependencies: bcs3.vector(ObjectDigest)
});
var VersionDigest = bcs3.tuple([bcs3.u64(), ObjectDigest]);
var ObjectIn = bcs3.enum("ObjectIn", {
  NotExist: null,
  Exist: bcs3.tuple([VersionDigest, Owner])
});
var AccumulatorAddress = bcs3.struct("AccumulatorAddress", {
  address: Address,
  ty: TypeTag
});
var AccumulatorOperation = bcs3.enum("AccumulatorOperation", {
  Merge: null,
  Split: null
});
var AccumulatorValue = bcs3.enum("AccumulatorValue", {
  Integer: bcs3.u64(),
  IntegerTuple: bcs3.tuple([bcs3.u64(), bcs3.u64()]),
  EventDigest: bcs3.vector(bcs3.tuple([bcs3.u64(), ObjectDigest]))
});
var AccumulatorWriteV1 = bcs3.struct("AccumulatorWriteV1", {
  address: AccumulatorAddress,
  operation: AccumulatorOperation,
  value: AccumulatorValue
});
var ObjectOut = bcs3.enum("ObjectOut", {
  NotExist: null,
  ObjectWrite: bcs3.tuple([ObjectDigest, Owner]),
  PackageWrite: VersionDigest,
  AccumulatorWriteV1
});
var IDOperation = bcs3.enum("IDOperation", {
  None: null,
  Created: null,
  Deleted: null
});
var EffectsObjectChange = bcs3.struct("EffectsObjectChange", {
  inputState: ObjectIn,
  outputState: ObjectOut,
  idOperation: IDOperation
});
var UnchangedConsensusKind = bcs3.enum("UnchangedConsensusKind", {
  ReadOnlyRoot: VersionDigest,
  MutateConsensusStreamEnded: bcs3.u64(),
  ReadConsensusStreamEnded: bcs3.u64(),
  Cancelled: bcs3.u64(),
  PerEpochConfig: null
});
var TransactionEffectsV2 = bcs3.struct("TransactionEffectsV2", {
  status: ExecutionStatus,
  executedEpoch: bcs3.u64(),
  gasUsed: GasCostSummary,
  transactionDigest: ObjectDigest,
  gasObjectIndex: bcs3.option(bcs3.u32()),
  eventsDigest: bcs3.option(ObjectDigest),
  dependencies: bcs3.vector(ObjectDigest),
  lamportVersion: bcs3.u64(),
  changedObjects: bcs3.vector(bcs3.tuple([Address, EffectsObjectChange])),
  unchangedConsensusObjects: bcs3.vector(bcs3.tuple([Address, UnchangedConsensusKind])),
  auxDataDigest: bcs3.option(ObjectDigest)
});
var TransactionEffects = bcs3.enum("TransactionEffects", {
  V1: TransactionEffectsV1,
  V2: TransactionEffectsV2
});

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/bcs/index.mjs
import { BcsEnum, BcsStruct, BcsTuple, BcsType, bcs as bcs4, compareBcsBytes } from "@mysten/bcs";
var suiBcs = {
  ...bcs4,
  U8: bcs4.u8(),
  U16: bcs4.u16(),
  U32: bcs4.u32(),
  U64: bcs4.u64(),
  U128: bcs4.u128(),
  U256: bcs4.u256(),
  ULEB128: bcs4.uleb128(),
  Bool: bcs4.bool(),
  String: bcs4.string(),
  Address,
  AppId,
  Argument,
  CallArg,
  Command,
  CompressedSignature,
  Data,
  GasData,
  Intent,
  IntentMessage,
  IntentScope,
  IntentVersion,
  MoveObject,
  MoveObjectType,
  MovePackage,
  MultiSig,
  MultiSigPkMap,
  MultiSigPublicKey,
  Object: ObjectInner,
  ObjectArg,
  ObjectDigest,
  Owner,
  PasskeyAuthenticator,
  ProgrammableMoveCall,
  ProgrammableTransaction,
  PublicKey,
  SenderSignedData,
  SenderSignedTransaction,
  SharedObjectRef,
  StructTag,
  SuiObjectRef,
  TransactionData,
  TransactionDataV1,
  TransactionEffects,
  TransactionExpiration,
  TransactionKind,
  TypeOrigin,
  TypeTag,
  UpgradeInfo
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/cryptography/intent.mjs
function messageWithIntent(scope, message) {
  return suiBcs.IntentMessage(suiBcs.bytes(message.length)).serialize({
    intent: {
      scope: { [scope]: true },
      version: { V0: true },
      appId: { Sui: true }
    },
    value: message
  }).toBytes();
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/cryptography/publickey.mjs
import { fromBase64 as fromBase642, toBase64 as toBase642 } from "@mysten/bcs";
import { blake2b } from "@noble/hashes/blake2.js";
import { bytesToHex } from "@noble/hashes/utils.js";
function bytesEqual(a, b) {
  if (a === b) return true;
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}
var PublicKey2 = class {
  /**
  * Checks if two public keys are equal
  */
  equals(publicKey) {
    return bytesEqual(this.toRawBytes(), publicKey.toRawBytes());
  }
  /**
  * Return the base-64 representation of the public key
  */
  toBase64() {
    return toBase642(this.toRawBytes());
  }
  toString() {
    throw new Error("`toString` is not implemented on public keys. Use `toBase64()` or `toRawBytes()` instead.");
  }
  /**
  * Return the Sui representation of the public key encoded in
  * base-64. A Sui public key is formed by the concatenation
  * of the scheme flag with the raw bytes of the public key
  */
  toSuiPublicKey() {
    return toBase642(this.toSuiBytes());
  }
  verifyWithIntent(bytes, signature, intent) {
    const digest = blake2b(messageWithIntent(intent, bytes), { dkLen: 32 });
    return this.verify(digest, signature);
  }
  /**
  * Verifies that the signature is valid for for the provided PersonalMessage
  */
  verifyPersonalMessage(message, signature) {
    return this.verifyWithIntent(suiBcs.byteVector().serialize(message).toBytes(), signature, "PersonalMessage");
  }
  /**
  * Verifies that the signature is valid for for the provided Transaction
  */
  verifyTransaction(transaction, signature) {
    return this.verifyWithIntent(transaction, signature, "TransactionData");
  }
  /**
  * Verifies that the public key is associated with the provided address
  */
  verifyAddress(address) {
    return this.toSuiAddress() === address;
  }
  /**
  * Returns the bytes representation of the public key
  * prefixed with the signature scheme flag
  */
  toSuiBytes() {
    const rawBytes = this.toRawBytes();
    const suiBytes = new Uint8Array(rawBytes.length + 1);
    suiBytes.set([this.flag()]);
    suiBytes.set(rawBytes, 1);
    return suiBytes;
  }
  /**
  * Return the Sui address associated with this Ed25519 public key
  */
  toSuiAddress() {
    return normalizeSuiAddress(bytesToHex(blake2b(this.toSuiBytes(), { dkLen: 32 })).slice(0, SUI_ADDRESS_LENGTH * 2));
  }
};
function parseSerializedKeypairSignature(serializedSignature) {
  const bytes = fromBase642(serializedSignature);
  const signatureScheme = SIGNATURE_FLAG_TO_SCHEME[bytes[0]];
  switch (signatureScheme) {
    case "ED25519":
    case "Secp256k1":
    case "Secp256r1":
      const size = SIGNATURE_SCHEME_TO_SIZE[signatureScheme];
      const signature = bytes.slice(1, bytes.length - size);
      return {
        serializedSignature,
        signatureScheme,
        signature,
        publicKey: bytes.slice(1 + signature.length),
        bytes
      };
    default:
      throw new Error("Unsupported signature scheme");
  }
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/keypairs/passkey/publickey.mjs
import { fromBase64 as fromBase643, toBase64 as toBase643 } from "@mysten/bcs";
import { p256 } from "@noble/curves/nist.js";
import { sha256 } from "@noble/hashes/sha2.js";
var PASSKEY_PUBLIC_KEY_SIZE = 33;
var PASSKEY_SIGNATURE_SIZE = 64;
var SECP256R1_SPKI_HEADER = new Uint8Array([
  48,
  89,
  48,
  19,
  6,
  7,
  42,
  134,
  72,
  206,
  61,
  2,
  1,
  6,
  8,
  42,
  134,
  72,
  206,
  61,
  3,
  1,
  7,
  3,
  66,
  0
]);
var PasskeyPublicKey = class extends PublicKey2 {
  static {
    this.SIZE = PASSKEY_PUBLIC_KEY_SIZE;
  }
  /**
  * Create a new PasskeyPublicKey object
  * @param value passkey public key as buffer or base-64 encoded string
  */
  constructor(value) {
    super();
    if (typeof value === "string") this.data = fromBase643(value);
    else if (value instanceof Uint8Array) this.data = value;
    else this.data = Uint8Array.from(value);
    if (this.data.length !== PASSKEY_PUBLIC_KEY_SIZE) throw new Error(`Invalid public key input. Expected ${PASSKEY_PUBLIC_KEY_SIZE} bytes, got ${this.data.length}`);
  }
  /**
  * Checks if two passkey public keys are equal
  */
  equals(publicKey) {
    return super.equals(publicKey);
  }
  /**
  * Return the byte array representation of the Secp256r1 public key
  */
  toRawBytes() {
    return this.data;
  }
  /**
  * Return the Sui address associated with this Secp256r1 public key
  */
  flag() {
    return SIGNATURE_SCHEME_TO_FLAG["Passkey"];
  }
  /**
  * Verifies that the signature is valid for for the provided message
  */
  async verify(message, signature) {
    const parsed = parseSerializedPasskeySignature(signature);
    const clientDataJSON = JSON.parse(parsed.clientDataJson);
    if (clientDataJSON.type !== "webauthn.get") return false;
    if (!bytesEqual(message, fromBase643(clientDataJSON.challenge.replace(/-/g, "+").replace(/_/g, "/")))) return false;
    const pk = parsed.userSignature.slice(1 + PASSKEY_SIGNATURE_SIZE);
    if (!bytesEqual(this.toRawBytes(), pk)) return false;
    const payload = new Uint8Array([...parsed.authenticatorData, ...sha256(new TextEncoder().encode(parsed.clientDataJson))]);
    const sig = parsed.userSignature.slice(1, PASSKEY_SIGNATURE_SIZE + 1);
    return p256.verify(sig, payload, pk);
  }
};
function parseSerializedPasskeySignature(signature) {
  const bytes = typeof signature === "string" ? fromBase643(signature) : signature;
  if (bytes[0] !== SIGNATURE_SCHEME_TO_FLAG.Passkey) throw new Error("Invalid signature scheme");
  const dec = PasskeyAuthenticator.parse(bytes.slice(1));
  return {
    signatureScheme: "Passkey",
    serializedSignature: toBase643(bytes),
    signature: bytes,
    authenticatorData: dec.authenticatorData,
    clientDataJson: dec.clientDataJson,
    userSignature: new Uint8Array(dec.userSignature),
    publicKey: new Uint8Array(dec.userSignature.slice(1 + PASSKEY_SIGNATURE_SIZE))
  };
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/zklogin/utils.mjs
import { hexToBytes } from "@noble/hashes/utils.js";
function findFirstNonZeroIndex(bytes) {
  for (let i = 0; i < bytes.length; i++) if (bytes[i] !== 0) return i;
  return -1;
}
function toPaddedBigEndianBytes(num, width) {
  return hexToBytes(num.toString(16).padStart(width * 2, "0").slice(-width * 2));
}
function toBigEndianBytes(num, width) {
  const bytes = toPaddedBigEndianBytes(num, width);
  const firstNonZeroIndex = findFirstNonZeroIndex(bytes);
  if (firstNonZeroIndex === -1) return new Uint8Array([0]);
  return bytes.slice(firstNonZeroIndex);
}
function normalizeZkLoginIssuer(iss) {
  if (iss === "accounts.google.com") return "https://accounts.google.com";
  return iss;
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/zklogin/jwt-utils.mjs
function base64UrlCharTo6Bits(base64UrlChar) {
  if (base64UrlChar.length !== 1) throw new Error("Invalid base64Url character: " + base64UrlChar);
  const index = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".indexOf(base64UrlChar);
  if (index === -1) throw new Error("Invalid base64Url character: " + base64UrlChar);
  const binaryString = index.toString(2).padStart(6, "0");
  return Array.from(binaryString).map(Number);
}
function base64UrlStringToBitVector(base64UrlString) {
  let bitVector = [];
  for (let i = 0; i < base64UrlString.length; i++) {
    const bits = base64UrlCharTo6Bits(base64UrlString.charAt(i));
    bitVector = bitVector.concat(bits);
  }
  return bitVector;
}
function decodeBase64URL(s, i) {
  if (s.length < 2) throw new Error(`Input (s = ${s}) is not tightly packed because s.length < 2`);
  let bits = base64UrlStringToBitVector(s);
  const firstCharOffset = i % 4;
  if (firstCharOffset === 0) {
  } else if (firstCharOffset === 1) bits = bits.slice(2);
  else if (firstCharOffset === 2) bits = bits.slice(4);
  else throw new Error(`Input (s = ${s}) is not tightly packed because i%4 = 3 (i = ${i}))`);
  const lastCharOffset = (i + s.length - 1) % 4;
  if (lastCharOffset === 3) {
  } else if (lastCharOffset === 2) bits = bits.slice(0, bits.length - 2);
  else if (lastCharOffset === 1) bits = bits.slice(0, bits.length - 4);
  else throw new Error(`Input (s = ${s}) is not tightly packed because (i + s.length - 1)%4 = 0 (i = ${i}))`);
  if (bits.length % 8 !== 0) throw new Error(`We should never reach here...`);
  const bytes = new Uint8Array(Math.floor(bits.length / 8));
  let currentByteIndex = 0;
  for (let i$1 = 0; i$1 < bits.length; i$1 += 8) {
    const bitChunk = bits.slice(i$1, i$1 + 8);
    const byte = parseInt(bitChunk.join(""), 2);
    bytes[currentByteIndex++] = byte;
  }
  return new TextDecoder().decode(bytes);
}
function verifyExtendedClaim(claim) {
  if (!(claim.slice(-1) === "}" || claim.slice(-1) === ",")) throw new Error("Invalid claim");
  const json2 = JSON.parse("{" + claim.slice(0, -1) + "}");
  if (Object.keys(json2).length !== 1) throw new Error("Invalid claim");
  const key = Object.keys(json2)[0];
  return [key, json2[key]];
}
function extractClaimValue(claim, claimName) {
  const [name, value] = verifyExtendedClaim(decodeBase64URL(claim.value, claim.indexMod4));
  if (name !== claimName) throw new Error(`Invalid field name: found ${name} expected ${claimName}`);
  return value;
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/zklogin/bcs.mjs
import { bcs as bcs5 } from "@mysten/bcs";
var zkLoginSignature = bcs5.struct("ZkLoginSignature", {
  inputs: bcs5.struct("ZkLoginSignatureInputs", {
    proofPoints: bcs5.struct("ZkLoginSignatureInputsProofPoints", {
      a: bcs5.vector(bcs5.string()),
      b: bcs5.vector(bcs5.vector(bcs5.string())),
      c: bcs5.vector(bcs5.string())
    }),
    issBase64Details: bcs5.struct("ZkLoginSignatureInputsClaim", {
      value: bcs5.string(),
      indexMod4: bcs5.u8()
    }),
    headerBase64: bcs5.string(),
    addressSeed: bcs5.string()
  }),
  maxEpoch: bcs5.u64(),
  userSignature: bcs5.byteVector()
});

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/zklogin/signature.mjs
import { fromBase64 as fromBase644, toBase64 as toBase644 } from "@mysten/bcs";
function parseZkLoginSignature(signature) {
  return zkLoginSignature.parse(typeof signature === "string" ? fromBase644(signature) : signature);
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/zklogin/publickey.mjs
import { fromBase64 as fromBase645, toBase64 as toBase645, toHex as toHex2 } from "@mysten/bcs";
import { blake2b as blake2b2 } from "@noble/hashes/blake2.js";
import { bytesToHex as bytesToHex2 } from "@noble/hashes/utils.js";
var ZkLoginPublicIdentifier = class ZkLoginPublicIdentifier2 extends PublicKey2 {
  #data;
  #client;
  #legacyAddress;
  /**
  * Create a new ZkLoginPublicIdentifier object
  * @param value zkLogin public identifier as buffer or base-64 encoded string
  */
  constructor(value, { client } = {}) {
    super();
    this.#client = client;
    if (typeof value === "string") this.#data = fromBase645(value);
    else if (value instanceof Uint8Array) this.#data = value;
    else this.#data = Uint8Array.from(value);
    this.#legacyAddress = this.#data.length !== this.#data[0] + 1 + 32;
    if (this.#legacyAddress) this.#data = normalizeZkLoginPublicKeyBytes(this.#data, false);
  }
  /**
  * Whether this identifier resolves to the deprecated legacy address derivation.
  */
  get legacyAddress() {
    return this.#legacyAddress;
  }
  static fromBytes(bytes, { client, address, legacyAddress } = {}) {
    let publicKey;
    if (legacyAddress === true) publicKey = new ZkLoginPublicIdentifier2(normalizeZkLoginPublicKeyBytes(bytes, true), { client });
    else if (legacyAddress === false) publicKey = new ZkLoginPublicIdentifier2(normalizeZkLoginPublicKeyBytes(bytes, false), { client });
    else if (address) {
      publicKey = new ZkLoginPublicIdentifier2(normalizeZkLoginPublicKeyBytes(bytes, false), { client });
      if (publicKey.toSuiAddress() !== address) publicKey = new ZkLoginPublicIdentifier2(normalizeZkLoginPublicKeyBytes(bytes, true), { client });
    } else publicKey = new ZkLoginPublicIdentifier2(bytes, { client });
    if (address && publicKey.toSuiAddress() !== address) throw new Error("Public key bytes do not match the provided address");
    return publicKey;
  }
  static fromProof(address, proof) {
    const { issBase64Details, addressSeed } = proof;
    const iss = extractClaimValue(issBase64Details, "iss");
    const legacyPublicKey = toZkLoginPublicIdentifier(BigInt(addressSeed), iss, { legacyAddress: true });
    if (legacyPublicKey.toSuiAddress() === address) return legacyPublicKey;
    const publicKey = toZkLoginPublicIdentifier(BigInt(addressSeed), iss, { legacyAddress: false });
    if (publicKey.toSuiAddress() !== address) throw new Error("Proof does not match address");
    return publicKey;
  }
  /**
  * Checks if two zkLogin public identifiers are equal
  */
  equals(publicKey) {
    return super.equals(publicKey);
  }
  toSuiAddress() {
    if (this.#legacyAddress) return this.#toLegacyAddress();
    return super.toSuiAddress();
  }
  #toLegacyAddress() {
    const legacyBytes = normalizeZkLoginPublicKeyBytes(this.#data, true);
    const addressBytes = new Uint8Array(legacyBytes.length + 1);
    addressBytes[0] = this.flag();
    addressBytes.set(legacyBytes, 1);
    return normalizeSuiAddress(bytesToHex2(blake2b2(addressBytes, { dkLen: 32 })).slice(0, SUI_ADDRESS_LENGTH * 2));
  }
  /**
  * Return the byte array representation of the zkLogin public identifier
  */
  toRawBytes() {
    return this.#data;
  }
  /**
  * Return the Sui address associated with this ZkLogin public identifier
  */
  flag() {
    return SIGNATURE_SCHEME_TO_FLAG["ZkLogin"];
  }
  /**
  * Verifies that the signature is valid for for the provided message
  */
  async verify(_message, _signature) {
    throw Error("does not support");
  }
  /**
  * Verifies that the signature is valid for for the provided PersonalMessage
  */
  verifyPersonalMessage(message, signature) {
    const parsedSignature = parseSerializedZkLoginSignature(signature);
    return graphqlVerifyZkLoginSignature({
      address: new ZkLoginPublicIdentifier2(parsedSignature.publicKey).toSuiAddress(),
      bytes: toBase645(message),
      signature: parsedSignature.serializedSignature,
      intentScope: "PersonalMessage",
      client: this.#client
    });
  }
  /**
  * Verifies that the signature is valid for for the provided Transaction
  */
  verifyTransaction(transaction, signature) {
    const parsedSignature = parseSerializedZkLoginSignature(signature);
    return graphqlVerifyZkLoginSignature({
      address: new ZkLoginPublicIdentifier2(parsedSignature.publicKey).toSuiAddress(),
      bytes: toBase645(transaction),
      signature: parsedSignature.serializedSignature,
      intentScope: "TransactionData",
      client: this.#client
    });
  }
  /**
  * Verifies that the public key is associated with the provided address
  */
  verifyAddress(address) {
    return address === super.toSuiAddress() || address === this.#toLegacyAddress();
  }
};
function toZkLoginPublicIdentifier(addressSeed, iss, options) {
  if (options.legacyAddress === void 0) throw new Error("legacyAddress parameter must be specified");
  const addressSeedBytesBigEndian = options.legacyAddress ? toBigEndianBytes(addressSeed, 32) : toPaddedBigEndianBytes(addressSeed, 32);
  const issBytes = new TextEncoder().encode(normalizeZkLoginIssuer(iss));
  const tmp = new Uint8Array(1 + issBytes.length + addressSeedBytesBigEndian.length);
  tmp.set([issBytes.length], 0);
  tmp.set(issBytes, 1);
  tmp.set(addressSeedBytesBigEndian, 1 + issBytes.length);
  return new ZkLoginPublicIdentifier(tmp, options);
}
function normalizeZkLoginPublicKeyBytes(bytes, legacyAddress) {
  const issByteLength = bytes[0] + 1;
  const addressSeed = BigInt(`0x${toHex2(bytes.slice(issByteLength))}`);
  const seedBytes = legacyAddress ? toBigEndianBytes(addressSeed, 32) : toPaddedBigEndianBytes(addressSeed, 32);
  const data = new Uint8Array(issByteLength + seedBytes.length);
  data.set(bytes.slice(0, issByteLength), 0);
  data.set(seedBytes, issByteLength);
  return data;
}
async function graphqlVerifyZkLoginSignature({ address, bytes, signature, intentScope, client }) {
  if (!client) throw new Error("A Sui Client (GRPC, GraphQL, or JSON RPC) is required to verify zkLogin signatures");
  const resp = await client.core.verifyZkLoginSignature({
    bytes,
    signature,
    intentScope,
    address
  });
  return resp.success === true && resp.errors.length === 0;
}
function parseSerializedZkLoginSignature(signature) {
  const bytes = typeof signature === "string" ? fromBase645(signature) : signature;
  if (bytes[0] !== SIGNATURE_SCHEME_TO_FLAG.ZkLogin) throw new Error("Invalid signature scheme");
  const { inputs, maxEpoch, userSignature } = parseZkLoginSignature(bytes.slice(1));
  const { issBase64Details, addressSeed } = inputs;
  const iss = extractClaimValue(issBase64Details, "iss");
  const publicIdentifier = toZkLoginPublicIdentifier(BigInt(addressSeed), iss, { legacyAddress: false });
  return {
    serializedSignature: toBase645(bytes),
    signatureScheme: "ZkLogin",
    zkLogin: {
      inputs,
      maxEpoch,
      userSignature,
      iss,
      addressSeed: BigInt(addressSeed)
    },
    signature: bytes,
    publicKey: publicIdentifier.toRawBytes()
  };
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/cryptography/signature.mjs
import { fromBase64 as fromBase646, toBase64 as toBase646 } from "@mysten/bcs";
function toSerializedSignature({ signature, signatureScheme, publicKey }) {
  if (!publicKey) throw new Error("`publicKey` is required");
  const pubKeyBytes = publicKey.toRawBytes();
  const serializedSignature = new Uint8Array(1 + signature.length + pubKeyBytes.length);
  serializedSignature.set([SIGNATURE_SCHEME_TO_FLAG[signatureScheme]]);
  serializedSignature.set(signature, 1);
  serializedSignature.set(pubKeyBytes, 1 + signature.length);
  return toBase646(serializedSignature);
}
function parseSerializedSignature(serializedSignature) {
  const bytes = fromBase646(serializedSignature);
  const signatureScheme = SIGNATURE_FLAG_TO_SCHEME[bytes[0]];
  switch (signatureScheme) {
    case "Passkey":
      return parseSerializedPasskeySignature(serializedSignature);
    case "MultiSig":
      return {
        serializedSignature,
        signatureScheme,
        multisig: suiBcs.MultiSig.parse(bytes.slice(1)),
        bytes,
        signature: void 0
      };
    case "ZkLogin":
      return parseSerializedZkLoginSignature(serializedSignature);
    case "ED25519":
    case "Secp256k1":
    case "Secp256r1":
      return parseSerializedKeypairSignature(serializedSignature);
    default:
      throw new Error("Unsupported signature scheme");
  }
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/keypairs/ed25519/publickey.mjs
import { fromBase64 as fromBase647 } from "@mysten/bcs";
import { ed25519 } from "@noble/curves/ed25519.js";
var PUBLIC_KEY_SIZE = 32;
var Ed25519PublicKey = class extends PublicKey2 {
  static {
    this.SIZE = PUBLIC_KEY_SIZE;
  }
  /**
  * Create a new Ed25519PublicKey object
  * @param value ed25519 public key as buffer or base-64 encoded string
  */
  constructor(value) {
    super();
    if (typeof value === "string") this.data = fromBase647(value);
    else if (value instanceof Uint8Array) this.data = value;
    else this.data = Uint8Array.from(value);
    if (this.data.length !== PUBLIC_KEY_SIZE) throw new Error(`Invalid public key input. Expected ${PUBLIC_KEY_SIZE} bytes, got ${this.data.length}`);
  }
  /**
  * Checks if two Ed25519 public keys are equal
  */
  equals(publicKey) {
    return super.equals(publicKey);
  }
  /**
  * Return the byte array representation of the Ed25519 public key
  */
  toRawBytes() {
    return this.data;
  }
  /**
  * Return the Sui address associated with this Ed25519 public key
  */
  flag() {
    return SIGNATURE_SCHEME_TO_FLAG["ED25519"];
  }
  /**
  * Verifies that the signature is valid for for the provided message
  */
  async verify(message, signature) {
    let bytes;
    if (typeof signature === "string") {
      const parsed = parseSerializedKeypairSignature(signature);
      if (parsed.signatureScheme !== "ED25519") throw new Error("Invalid signature scheme");
      if (!bytesEqual(this.toRawBytes(), parsed.publicKey)) throw new Error("Signature does not match public key");
      bytes = parsed.signature;
    } else bytes = signature;
    return ed25519.verify(bytes, message, this.toRawBytes());
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/keypairs/secp256k1/publickey.mjs
import { fromBase64 as fromBase648 } from "@mysten/bcs";
import { secp256k1 } from "@noble/curves/secp256k1.js";
var SECP256K1_PUBLIC_KEY_SIZE = 33;
var Secp256k1PublicKey = class extends PublicKey2 {
  static {
    this.SIZE = SECP256K1_PUBLIC_KEY_SIZE;
  }
  /**
  * Create a new Secp256k1PublicKey object
  * @param value secp256k1 public key as buffer or base-64 encoded string
  */
  constructor(value) {
    super();
    if (typeof value === "string") this.data = fromBase648(value);
    else if (value instanceof Uint8Array) this.data = value;
    else this.data = Uint8Array.from(value);
    if (this.data.length !== SECP256K1_PUBLIC_KEY_SIZE) throw new Error(`Invalid public key input. Expected ${SECP256K1_PUBLIC_KEY_SIZE} bytes, got ${this.data.length}`);
  }
  /**
  * Checks if two Secp256k1 public keys are equal
  */
  equals(publicKey) {
    return super.equals(publicKey);
  }
  /**
  * Return the byte array representation of the Secp256k1 public key
  */
  toRawBytes() {
    return this.data;
  }
  /**
  * Return the Sui address associated with this Secp256k1 public key
  */
  flag() {
    return SIGNATURE_SCHEME_TO_FLAG["Secp256k1"];
  }
  /**
  * Verifies that the signature is valid for for the provided message
  */
  async verify(message, signature) {
    let bytes;
    if (typeof signature === "string") {
      const parsed = parseSerializedKeypairSignature(signature);
      if (parsed.signatureScheme !== "Secp256k1") throw new Error("Invalid signature scheme");
      if (!bytesEqual(this.toRawBytes(), parsed.publicKey)) throw new Error("Signature does not match public key");
      bytes = parsed.signature;
    } else bytes = signature;
    return secp256k1.verify(bytes, message, this.toRawBytes());
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/keypairs/secp256r1/publickey.mjs
import { fromBase64 as fromBase649 } from "@mysten/bcs";
import { p256 as p2562 } from "@noble/curves/nist.js";
var SECP256R1_PUBLIC_KEY_SIZE = 33;
var Secp256r1PublicKey = class extends PublicKey2 {
  static {
    this.SIZE = SECP256R1_PUBLIC_KEY_SIZE;
  }
  /**
  * Create a new Secp256r1PublicKey object
  * @param value secp256r1 public key as buffer or base-64 encoded string
  */
  constructor(value) {
    super();
    if (typeof value === "string") this.data = fromBase649(value);
    else if (value instanceof Uint8Array) this.data = value;
    else this.data = Uint8Array.from(value);
    if (this.data.length !== SECP256R1_PUBLIC_KEY_SIZE) throw new Error(`Invalid public key input. Expected ${SECP256R1_PUBLIC_KEY_SIZE} bytes, got ${this.data.length}`);
  }
  /**
  * Checks if two Secp256r1 public keys are equal
  */
  equals(publicKey) {
    return super.equals(publicKey);
  }
  /**
  * Return the byte array representation of the Secp256r1 public key
  */
  toRawBytes() {
    return this.data;
  }
  /**
  * Return the Sui address associated with this Secp256r1 public key
  */
  flag() {
    return SIGNATURE_SCHEME_TO_FLAG["Secp256r1"];
  }
  /**
  * Verifies that the signature is valid for for the provided message
  */
  async verify(message, signature) {
    let bytes;
    if (typeof signature === "string") {
      const parsed = parseSerializedSignature(signature);
      if (parsed.signatureScheme !== "Secp256r1") throw new Error("Invalid signature scheme");
      if (!bytesEqual(this.toRawBytes(), parsed.publicKey)) throw new Error("Signature does not match public key");
      bytes = parsed.signature;
    } else bytes = signature;
    return p2562.verify(bytes, message, this.toRawBytes());
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/cryptography/keypair.mjs
import { bcs as bcs6, toBase64 as toBase647 } from "@mysten/bcs";
import { blake2b as blake2b3 } from "@noble/hashes/blake2.js";
import { bech32 } from "@scure/base";
var Signer = class {
  /**
  * Sign messages with a specific intent. By combining the message bytes with the intent before hashing and signing,
  * it ensures that a signed message is tied to a specific purpose and domain separator is provided
  */
  async signWithIntent(bytes, intent) {
    const digest = blake2b3(messageWithIntent(intent, bytes), { dkLen: 32 });
    return {
      signature: toSerializedSignature({
        signature: await this.sign(digest),
        signatureScheme: this.getKeyScheme(),
        publicKey: this.getPublicKey()
      }),
      bytes: toBase647(bytes)
    };
  }
  /**
  * Signs provided transaction by calling `signWithIntent()` with a `TransactionData` provided as intent scope
  */
  async signTransaction(bytes) {
    return this.signWithIntent(bytes, "TransactionData");
  }
  /**
  * Signs provided personal message by calling `signWithIntent()` with a `PersonalMessage` provided as intent scope
  */
  async signPersonalMessage(bytes) {
    const { signature } = await this.signWithIntent(bcs6.byteVector().serialize(bytes).toBytes(), "PersonalMessage");
    return {
      bytes: toBase647(bytes),
      signature
    };
  }
  async signAndExecuteTransaction({ transaction, client }) {
    transaction.setSenderIfNotSet(this.toSuiAddress());
    const bytes = await transaction.build({ client });
    const { signature } = await this.signTransaction(bytes);
    return client.core.executeTransaction({
      transaction: bytes,
      signatures: [signature],
      include: {
        transaction: true,
        effects: true
      }
    });
  }
  toSuiAddress() {
    return this.getPublicKey().toSuiAddress();
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/multisig/signer.mjs
import { toBase64 as toBase648 } from "@mysten/bcs";
var MultiSigSigner = class extends Signer {
  #pubkey;
  #signers;
  constructor(pubkey, signers = []) {
    super();
    this.#pubkey = pubkey;
    this.#signers = signers;
    const uniqueKeys = /* @__PURE__ */ new Set();
    let combinedWeight = 0;
    const weights = pubkey.getPublicKeys().map(({ weight, publicKey }) => ({
      weight,
      address: publicKey.toSuiAddress()
    }));
    for (const signer of signers) {
      const address = signer.toSuiAddress();
      if (uniqueKeys.has(address)) throw new Error(`Can't create MultiSigSigner with duplicate signers`);
      uniqueKeys.add(address);
      const weight = weights.find((w) => w.address === address)?.weight;
      if (!weight) throw new Error(`Signer ${address} is not part of the MultiSig public key`);
      combinedWeight += weight;
    }
    if (combinedWeight < pubkey.getThreshold()) throw new Error(`Combined weight of signers is less than threshold`);
  }
  getKeyScheme() {
    return "MultiSig";
  }
  getPublicKey() {
    return this.#pubkey;
  }
  sign(_data) {
    throw new Error("MultiSigSigner does not support signing directly. Use signTransaction or signPersonalMessage instead");
  }
  async signTransaction(bytes) {
    return {
      signature: this.#pubkey.combinePartialSignatures(await Promise.all(this.#signers.map(async (signer) => (await signer.signTransaction(bytes)).signature))),
      bytes: toBase648(bytes)
    };
  }
  async signPersonalMessage(bytes) {
    return {
      signature: this.#pubkey.combinePartialSignatures(await Promise.all(this.#signers.map(async (signer) => (await signer.signPersonalMessage(bytes)).signature))),
      bytes: toBase648(bytes)
    };
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/multisig/publickey.mjs
import { fromBase64 as fromBase6410, toBase64 as toBase649 } from "@mysten/bcs";
import { blake2b as blake2b4 } from "@noble/hashes/blake2.js";
import { bytesToHex as bytesToHex3 } from "@noble/hashes/utils.js";
var MAX_SIGNER_IN_MULTISIG = 10;
var MIN_SIGNER_IN_MULTISIG = 1;
var MultiSigPublicKey2 = class MultiSigPublicKey3 extends PublicKey2 {
  /**
  * Create a new MultiSigPublicKey object
  */
  constructor(value, options = {}) {
    super();
    if (typeof value === "string") {
      this.rawBytes = fromBase6410(value);
      this.multisigPublicKey = suiBcs.MultiSigPublicKey.parse(this.rawBytes);
    } else if (value instanceof Uint8Array) {
      this.rawBytes = value;
      this.multisigPublicKey = suiBcs.MultiSigPublicKey.parse(this.rawBytes);
    } else {
      this.multisigPublicKey = value;
      this.rawBytes = suiBcs.MultiSigPublicKey.serialize(value).toBytes();
    }
    if (this.multisigPublicKey.threshold < 1) throw new Error("Invalid threshold");
    const seenPublicKeys = /* @__PURE__ */ new Set();
    this.publicKeys = this.multisigPublicKey.pk_map.map(({ pubKey, weight }) => {
      const [scheme, bytes] = Object.entries(pubKey).filter(([name]) => name !== "$kind")[0];
      const publicKeyStr = Uint8Array.from(bytes).toString();
      if (seenPublicKeys.has(publicKeyStr)) throw new Error(`Multisig does not support duplicate public keys`);
      seenPublicKeys.add(publicKeyStr);
      if (weight < 1) throw new Error(`Invalid weight`);
      return {
        publicKey: publicKeyFromRawBytes(scheme, Uint8Array.from(bytes), options),
        weight
      };
    });
    const totalWeight = this.publicKeys.reduce((sum, { weight }) => sum + weight, 0);
    if (this.multisigPublicKey.threshold > totalWeight) throw new Error(`Unreachable threshold`);
    if (this.publicKeys.length > MAX_SIGNER_IN_MULTISIG) throw new Error(`Max number of signers in a multisig is ${MAX_SIGNER_IN_MULTISIG}`);
    if (this.publicKeys.length < MIN_SIGNER_IN_MULTISIG) throw new Error(`Min number of signers in a multisig is ${MIN_SIGNER_IN_MULTISIG}`);
  }
  /**
  * 	A static method to create a new MultiSig publickey instance from a set of public keys and their associated weights pairs and threshold.
  */
  static fromPublicKeys({ threshold, publicKeys }) {
    return new MultiSigPublicKey3({
      pk_map: publicKeys.map(({ publicKey, weight }) => {
        return {
          pubKey: { [SIGNATURE_FLAG_TO_SCHEME[publicKey.flag()]]: publicKey.toRawBytes() },
          weight
        };
      }),
      threshold
    });
  }
  /**
  * Checks if two MultiSig public keys are equal
  */
  equals(publicKey) {
    return super.equals(publicKey);
  }
  /**
  * Return the byte array representation of the MultiSig public key
  */
  toRawBytes() {
    return this.rawBytes;
  }
  getPublicKeys() {
    return this.publicKeys;
  }
  getThreshold() {
    return this.multisigPublicKey.threshold;
  }
  getSigner(...signers) {
    return new MultiSigSigner(this, signers);
  }
  /**
  * Return the Sui address associated with this MultiSig public key
  */
  toSuiAddress() {
    const maxLength = 1 + 65 * MAX_SIGNER_IN_MULTISIG + 2;
    const tmp = new Uint8Array(maxLength);
    tmp.set([SIGNATURE_SCHEME_TO_FLAG["MultiSig"]]);
    tmp.set(suiBcs.u16().serialize(this.multisigPublicKey.threshold).toBytes(), 1);
    let i = 3;
    for (const { publicKey, weight } of this.publicKeys) {
      const bytes = publicKey.toSuiBytes();
      tmp.set(bytes, i);
      i += bytes.length;
      tmp.set([weight], i++);
    }
    return normalizeSuiAddress(bytesToHex3(blake2b4(tmp.slice(0, i), { dkLen: 32 })));
  }
  /**
  * Return the Sui address associated with this MultiSig public key
  */
  flag() {
    return SIGNATURE_SCHEME_TO_FLAG["MultiSig"];
  }
  /**
  * Verifies that the signature is valid for for the provided message
  */
  async verify(message, multisigSignature) {
    const parsed = parseSerializedSignature(multisigSignature);
    if (parsed.signatureScheme !== "MultiSig") throw new Error("Invalid signature scheme");
    const { multisig } = parsed;
    let signatureWeight = 0;
    if (!bytesEqual(suiBcs.MultiSigPublicKey.serialize(this.multisigPublicKey).toBytes(), suiBcs.MultiSigPublicKey.serialize(multisig.multisig_pk).toBytes())) return false;
    for (const { publicKey, weight, signature } of parsePartialSignatures(multisig)) {
      if (!await publicKey.verify(message, signature)) return false;
      signatureWeight += weight;
    }
    return signatureWeight >= this.multisigPublicKey.threshold;
  }
  /**
  * Combines multiple partial signatures into a single multisig, ensuring that each public key signs only once
  * and that all the public keys involved are known and valid, and then serializes multisig into the standard format
  */
  combinePartialSignatures(signatures) {
    if (signatures.length > MAX_SIGNER_IN_MULTISIG) throw new Error(`Max number of signatures in a multisig is ${MAX_SIGNER_IN_MULTISIG}`);
    let bitmap = 0;
    const compressedSignatures = new Array(signatures.length);
    for (let i = 0; i < signatures.length; i++) {
      const parsed = parseSerializedSignature(signatures[i]);
      if (parsed.signatureScheme === "MultiSig") throw new Error("MultiSig is not supported inside MultiSig");
      let publicKey;
      if (parsed.signatureScheme === "ZkLogin") publicKey = toZkLoginPublicIdentifier(parsed.zkLogin?.addressSeed, parsed.zkLogin?.iss, { legacyAddress: false }).toRawBytes();
      else publicKey = parsed.publicKey;
      compressedSignatures[i] = { [parsed.signatureScheme]: parsed.signature };
      let publicKeyIndex;
      for (let j = 0; j < this.publicKeys.length; j++) if (bytesEqual(publicKey, this.publicKeys[j].publicKey.toRawBytes())) {
        if (bitmap & 1 << j) throw new Error("Received multiple signatures from the same public key");
        publicKeyIndex = j;
        break;
      }
      if (publicKeyIndex === void 0) throw new Error("Received signature from unknown public key");
      bitmap |= 1 << publicKeyIndex;
    }
    const multisig = {
      sigs: compressedSignatures,
      bitmap,
      multisig_pk: this.multisigPublicKey
    };
    const bytes = suiBcs.MultiSig.serialize(multisig, { maxSize: 8192 }).toBytes();
    const tmp = new Uint8Array(bytes.length + 1);
    tmp.set([SIGNATURE_SCHEME_TO_FLAG["MultiSig"]]);
    tmp.set(bytes, 1);
    return toBase649(tmp);
  }
};
function parsePartialSignatures(multisig, options = {}) {
  const res = new Array(multisig.sigs.length);
  for (let i = 0; i < multisig.sigs.length; i++) {
    const [signatureScheme, signature] = Object.entries(multisig.sigs[i]).filter(([name]) => name !== "$kind")[0];
    const pkIndex = asIndices(multisig.bitmap).at(i);
    const pair = multisig.multisig_pk.pk_map[pkIndex];
    const pkBytes = Uint8Array.from(Object.values(pair.pubKey)[0]);
    if (signatureScheme === "MultiSig") throw new Error("MultiSig is not supported inside MultiSig");
    const publicKey = publicKeyFromRawBytes(signatureScheme, pkBytes, options);
    res[i] = {
      signatureScheme,
      signature: Uint8Array.from(signature),
      publicKey,
      weight: pair.weight
    };
  }
  return res;
}
function asIndices(bitmap) {
  if (bitmap < 0 || bitmap > 1024) throw new Error("Invalid bitmap");
  const res = [];
  for (let i = 0; i < 10; i++) if ((bitmap & 1 << i) !== 0) res.push(i);
  return Uint8Array.from(res);
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/verify/verify.mjs
import { fromBase64 as fromBase6411 } from "@mysten/bcs";
async function isValidPersonalMessageSignature(message, signature, options = {}) {
  const parsed = tryParseSignature(signature, { client: options.client });
  if (!parsed) return false;
  if (!await parsed.publicKey.verifyPersonalMessage(message, parsed.serializedSignature)) return false;
  return options.address ? parsed.publicKey.verifyAddress(options.address) : true;
}
function parseSignature(signature, options = {}) {
  const parsedSignature = parseSerializedSignature(signature);
  if (parsedSignature.signatureScheme === "MultiSig") return {
    ...parsedSignature,
    publicKey: new MultiSigPublicKey2(parsedSignature.multisig.multisig_pk)
  };
  const publicKey = publicKeyFromRawBytes(parsedSignature.signatureScheme, parsedSignature.publicKey, options);
  return {
    ...parsedSignature,
    publicKey
  };
}
function tryParseSignature(signature, options = {}) {
  try {
    return parseSignature(signature, options);
  } catch {
    return null;
  }
}
function publicKeyFromRawBytes(signatureScheme, bytes, options = {}) {
  let publicKey;
  switch (signatureScheme) {
    case "ED25519":
      publicKey = new Ed25519PublicKey(bytes);
      break;
    case "Secp256k1":
      publicKey = new Secp256k1PublicKey(bytes);
      break;
    case "Secp256r1":
      publicKey = new Secp256r1PublicKey(bytes);
      break;
    case "MultiSig":
      publicKey = new MultiSigPublicKey2(bytes);
      break;
    case "ZkLogin":
      publicKey = ZkLoginPublicIdentifier.fromBytes(bytes, options);
      break;
    case "Passkey":
      publicKey = new PasskeyPublicKey(bytes);
      break;
    default:
      throw new Error(`Unsupported signature scheme ${signatureScheme}`);
  }
  if (options.address && publicKey.toSuiAddress() !== options.address) throw new Error(`Public key bytes do not match the provided address`);
  return publicKey;
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/version.mjs
var PACKAGE_VERSION = "2.26.1";

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/client/mvr.mjs
import { DataLoader, chunk } from "@mysten/utils";
var NAME_SEPARATOR2 = "/";
var MVR_API_HEADER = { "Mvr-Source": `@mysten/sui@${PACKAGE_VERSION}` };
var MvrClient = class {
  #cache;
  #url;
  #pageSize;
  #overrides;
  constructor({ cache, url, pageSize = 50, overrides }) {
    this.#cache = cache;
    this.#url = url;
    this.#pageSize = pageSize;
    this.#overrides = {
      packages: overrides?.packages,
      types: overrides?.types
    };
    validateOverrides(this.#overrides);
  }
  get #mvrPackageDataLoader() {
    return this.#cache.readSync(["#mvrPackageDataLoader", this.#url ?? ""], () => {
      const loader = new DataLoader(async (packages) => {
        if (!this.#url) throw new Error(`MVR Api URL is not set for the current client (resolving ${packages.join(", ")})`);
        const resolved = await this.#resolvePackages(packages);
        return packages.map((pkg) => resolved[pkg] ?? /* @__PURE__ */ new Error(`Failed to resolve package: ${pkg}`));
      });
      const overrides = this.#overrides?.packages;
      if (overrides) for (const [pkg, id] of Object.entries(overrides)) loader.prime(pkg, id);
      return loader;
    });
  }
  get #mvrTypeDataLoader() {
    return this.#cache.readSync(["#mvrTypeDataLoader", this.#url ?? ""], () => {
      const loader = new DataLoader(async (types) => {
        if (!this.#url) throw new Error(`MVR Api URL is not set for the current client (resolving ${types.join(", ")})`);
        const resolved = await this.#resolveTypes(types);
        return types.map((type) => resolved[type] ?? /* @__PURE__ */ new Error(`Failed to resolve type: ${type}`));
      });
      const overrides = this.#overrides?.types;
      if (overrides) for (const [type, id] of Object.entries(overrides)) loader.prime(type, id);
      return loader;
    });
  }
  async #resolvePackages(packages) {
    if (packages.length === 0) return {};
    const batches = chunk(packages, this.#pageSize);
    const results = {};
    await Promise.all(batches.map(async (batch) => {
      const data = await this.#fetch("/v1/resolution/bulk", { names: batch });
      if (!data?.resolution) return;
      for (const pkg of Object.keys(data?.resolution)) {
        const pkgData = data.resolution[pkg]?.package_id;
        if (!pkgData) continue;
        results[pkg] = pkgData;
      }
    }));
    return results;
  }
  async #resolveTypes(types) {
    if (types.length === 0) return {};
    const batches = chunk(types, this.#pageSize);
    const results = {};
    await Promise.all(batches.map(async (batch) => {
      const data = await this.#fetch("/v1/struct-definition/bulk", { types: batch });
      if (!data?.resolution) return;
      for (const type of Object.keys(data?.resolution)) {
        const typeData = data.resolution[type]?.type_tag;
        if (!typeData) continue;
        results[type] = typeData;
      }
    }));
    return results;
  }
  async #fetch(url, body) {
    if (!this.#url) throw new Error("MVR Api URL is not set for the current client");
    const response = await fetch(`${this.#url}${url}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...MVR_API_HEADER
      },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}));
      throw new Error(`Failed to resolve types: ${errorBody?.message}`);
    }
    return response.json();
  }
  async resolvePackage({ package: name, signal }) {
    signal?.throwIfAborted();
    if (!hasMvrName(name)) return { package: name };
    return { package: await raceSignal(this.#mvrPackageDataLoader.load(name), signal) };
  }
  async resolveType({ type, signal }) {
    signal?.throwIfAborted();
    if (!hasMvrName(type)) return { type };
    const mvrTypes = [...extractMvrTypes(type)];
    const resolvedTypes = await raceSignal(this.#mvrTypeDataLoader.loadMany(mvrTypes), signal);
    const typeMap = {};
    for (let i = 0; i < mvrTypes.length; i++) {
      const resolvedType = resolvedTypes[i];
      if (resolvedType instanceof Error) throw resolvedType;
      typeMap[mvrTypes[i]] = resolvedType;
    }
    return { type: replaceMvrNames(type, typeMap) };
  }
  async resolve({ types = [], packages = [], signal }) {
    signal?.throwIfAborted();
    const mvrTypes = /* @__PURE__ */ new Set();
    for (const type of types ?? []) extractMvrTypes(type, mvrTypes);
    const typesArray = [...mvrTypes];
    const [resolvedTypes, resolvedPackages] = await raceSignal(Promise.all([typesArray.length > 0 ? this.#mvrTypeDataLoader.loadMany(typesArray) : [], packages.length > 0 ? this.#mvrPackageDataLoader.loadMany(packages) : []]), signal);
    const typeMap = { ...this.#overrides?.types };
    for (const [i, type] of typesArray.entries()) {
      const resolvedType = resolvedTypes[i];
      if (resolvedType instanceof Error) throw resolvedType;
      typeMap[type] = resolvedType;
    }
    const replacedTypes = {};
    for (const type of types ?? []) replacedTypes[type] = { type: replaceMvrNames(type, typeMap) };
    const replacedPackages = {};
    for (const [i, pkg] of (packages ?? []).entries()) {
      const resolvedPkg = this.#overrides?.packages?.[pkg] ?? resolvedPackages[i];
      if (resolvedPkg instanceof Error) throw resolvedPkg;
      replacedPackages[pkg] = { package: resolvedPkg };
    }
    return {
      types: replacedTypes,
      packages: replacedPackages
    };
  }
};
function validateOverrides(overrides) {
  if (overrides?.packages) for (const [pkg, id] of Object.entries(overrides.packages)) {
    if (!isValidNamedPackage(pkg)) throw new Error(`Invalid package name: ${pkg}`);
    if (!isValidSuiAddress(normalizeSuiAddress(id))) throw new Error(`Invalid package ID: ${id}`);
  }
  if (overrides?.types) for (const [type, val] of Object.entries(overrides.types)) {
    if (parseStructTag(type).typeParams.length > 0) throw new Error("Type overrides must be first-level only. If you want to supply generic types, just pass each type individually.");
    if (!isValidSuiAddress(parseStructTag(val).address)) throw new Error(`Invalid type: ${val}`);
  }
}
function extractMvrTypes(type, types = /* @__PURE__ */ new Set()) {
  if (typeof type === "string" && !hasMvrName(type)) return types;
  if (typeof type === "string" && type.startsWith("vector<") && type.endsWith(">")) return extractMvrTypes(type.slice(7, -1), types);
  const tag = isStructTag(type) ? type : parseStructTag(type);
  if (hasMvrName(tag.address)) types.add(`${tag.address}::${tag.module}::${tag.name}`);
  for (const param of tag.typeParams) extractMvrTypes(param, types);
  return types;
}
function replaceMvrNames(tag, typeCache) {
  if (typeof tag === "string" && !tag.includes("::")) return tag;
  if (typeof tag === "string" && tag.startsWith("vector<") && tag.endsWith(">")) return `vector<${replaceMvrNames(tag.slice(7, -1), typeCache)}>`;
  const type = isStructTag(tag) ? tag : parseStructTag(tag);
  const cacheHit = typeCache[`${type.address}::${type.module}::${type.name}`];
  return normalizeStructTag({
    ...type,
    address: cacheHit ? cacheHit.split("::")[0] : type.address,
    typeParams: type.typeParams.map((param) => replaceMvrNames(param, typeCache))
  });
}
function hasMvrName(nameOrType) {
  return nameOrType.includes(NAME_SEPARATOR2) || nameOrType.includes("@") || nameOrType.includes(".sui");
}
function raceSignal(promise, signal) {
  if (!signal) return promise;
  if (signal.aborted) return Promise.reject(signal.reason);
  return new Promise((resolve, reject) => {
    const onAbort = () => reject(signal.reason);
    signal.addEventListener("abort", onAbort, { once: true });
    promise.then(resolve, reject).finally(() => {
      signal.removeEventListener("abort", onAbort);
    });
  });
}
function isStructTag(type) {
  return typeof type === "object" && "address" in type && "module" in type && "name" in type && "typeParams" in type;
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/client/cache.mjs
var ClientCache = class ClientCache2 {
  #prefix;
  #cache;
  constructor({ prefix, cache } = {}) {
    this.#prefix = prefix ?? [];
    this.#cache = cache ?? /* @__PURE__ */ new Map();
  }
  read(key, load) {
    const cacheKey = [this.#prefix, ...key].join(":");
    if (this.#cache.has(cacheKey)) return this.#cache.get(cacheKey);
    const result = load();
    this.#cache.set(cacheKey, result);
    if (typeof result === "object" && result !== null && "then" in result) return Promise.resolve(result).then((v) => {
      this.#cache.set(cacheKey, v);
      return v;
    }).catch((err) => {
      this.#cache.delete(cacheKey);
      throw err;
    });
    return result;
  }
  readSync(key, load) {
    const cacheKey = [this.#prefix, ...key].join(":");
    if (this.#cache.has(cacheKey)) return this.#cache.get(cacheKey);
    const result = load();
    this.#cache.set(cacheKey, result);
    return result;
  }
  clear(prefix) {
    const prefixKey = [...this.#prefix, ...prefix ?? []].join(":");
    if (!prefixKey) {
      this.#cache.clear();
      return;
    }
    for (const key of this.#cache.keys()) if (key.startsWith(prefixKey)) this.#cache.delete(key);
  }
  scope(prefix) {
    return new ClientCache2({
      prefix: [...this.#prefix, ...Array.isArray(prefix) ? prefix : [prefix]],
      cache: this.#cache
    });
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/client/client.mjs
var BaseClient = class {
  constructor({ network, base, cache = base?.cache ?? new ClientCache() }) {
    this.network = network;
    this.base = base ?? this;
    this.cache = cache;
  }
  $extend(...registrations) {
    const extensions = Object.fromEntries(registrations.map((registration) => {
      return [registration.name, registration.register(this)];
    }));
    const methodCache = /* @__PURE__ */ new Map();
    return new Proxy(this, { get(target, prop, receiver) {
      if (typeof prop === "string" && prop in extensions) return extensions[prop];
      const value = Reflect.get(target, prop, receiver);
      if (typeof value === "function") {
        if (prop === "$extend") return value.bind(receiver);
        if (!methodCache.has(prop)) methodCache.set(prop, value.bind(target));
        return methodCache.get(prop);
      }
      return value;
    } });
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/utils/dynamic-fields.mjs
import { toHex as toHex3 } from "@mysten/bcs";
import { blake2b as blake2b5 } from "@noble/hashes/blake2.js";
function deriveDynamicFieldID(parentId, typeTag, key) {
  const address = suiBcs.Address.serialize(parentId).toBytes();
  const tag = suiBcs.TypeTag.serialize(typeTag).toBytes();
  const keyLength = suiBcs.u64().serialize(key.length).toBytes();
  const hash3 = blake2b5.create({ dkLen: 32 });
  hash3.update(new Uint8Array([240]));
  hash3.update(address);
  hash3.update(keyLength);
  hash3.update(key);
  hash3.update(tag);
  return `0x${toHex3(hash3.digest().slice(0, 32))}`;
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/client/core.mjs
var DEFAULT_MVR_URLS = {
  mainnet: "https://mainnet.mvr.mystenlabs.com",
  testnet: "https://testnet.mvr.mystenlabs.com"
};
var CoreClient = class extends BaseClient {
  constructor(options) {
    super(options);
    this.core = this;
    this.mvr = new MvrClient({
      cache: this.cache.scope("core.mvr"),
      url: options.mvr?.url ?? DEFAULT_MVR_URLS[this.network],
      pageSize: options.mvr?.pageSize,
      overrides: options.mvr?.overrides
    });
  }
  async getObject(options) {
    const { objectId } = options;
    const { objects: [result] } = await this.getObjects({
      objectIds: [objectId],
      signal: options.signal,
      include: options.include
    });
    if (result instanceof Error) throw result;
    return { object: result };
  }
  async getDynamicField(options) {
    const normalizedNameType = TypeTagSerializer.parseFromStr((await this.core.mvr.resolveType({
      type: options.name.type,
      signal: options.signal
    })).type);
    const fieldId = deriveDynamicFieldID(options.parentId, normalizedNameType, options.name.bcs);
    const { objects: [fieldObject] } = await this.getObjects({
      objectIds: [fieldId],
      signal: options.signal,
      include: {
        previousTransaction: true,
        content: true
      }
    });
    if (fieldObject instanceof Error) throw fieldObject;
    const fieldType = parseStructTag(fieldObject.type);
    const content = await fieldObject.content;
    const nameTypeParam = fieldType.typeParams[0];
    const isDynamicObject = typeof nameTypeParam !== "string" && nameTypeParam.module === "dynamic_object_field" && nameTypeParam.name === "Wrapper";
    const valueBcs = content.slice(SUI_ADDRESS_LENGTH + options.name.bcs.length);
    const valueType = typeof fieldType.typeParams[1] === "string" ? fieldType.typeParams[1] : normalizeStructTag(fieldType.typeParams[1]);
    return { dynamicField: {
      $kind: isDynamicObject ? "DynamicObject" : "DynamicField",
      fieldId: fieldObject.objectId,
      digest: fieldObject.digest,
      version: fieldObject.version,
      type: fieldObject.type,
      previousTransaction: fieldObject.previousTransaction,
      name: {
        type: typeof nameTypeParam === "string" ? nameTypeParam : normalizeStructTag(nameTypeParam),
        bcs: options.name.bcs
      },
      value: {
        type: valueType,
        bcs: valueBcs
      },
      childId: isDynamicObject ? suiBcs.Address.parse(valueBcs) : void 0
    } };
  }
  async getDynamicObjectField(options) {
    const wrappedType = `0x2::dynamic_object_field::Wrapper<${(await this.core.mvr.resolveType({
      type: options.name.type,
      signal: options.signal
    })).type}>`;
    const { dynamicField } = await this.getDynamicField({
      parentId: options.parentId,
      name: {
        type: wrappedType,
        bcs: options.name.bcs
      },
      signal: options.signal
    });
    const { object } = await this.getObject({
      objectId: dynamicField.childId,
      signal: options.signal,
      include: options.include
    });
    return { object };
  }
  async waitForTransaction(options) {
    const { signal, timeout = 60 * 1e3, pollSchedule, include } = options;
    const digest = "result" in options && options.result ? (options.result.Transaction ?? options.result.FailedTransaction).digest : options.digest;
    const abortSignal = signal ? AbortSignal.any([AbortSignal.timeout(timeout), signal]) : AbortSignal.timeout(timeout);
    const abortPromise = new Promise((_, reject) => {
      abortSignal.addEventListener("abort", () => reject(abortSignal.reason));
    });
    abortPromise.catch(() => {
    });
    const schedule = pollSchedule ?? [
      0,
      300,
      600,
      1500,
      3500
    ];
    const t0 = Date.now();
    let scheduleIndex = 0;
    const lastInterval = schedule.length > 0 ? schedule[schedule.length - 1] - (schedule[schedule.length - 2] ?? 0) : 2e3;
    while (true) {
      if (scheduleIndex < schedule.length) {
        const remaining = t0 + schedule[scheduleIndex] - Date.now();
        scheduleIndex++;
        if (remaining > 0) await Promise.race([new Promise((resolve) => setTimeout(resolve, remaining)), abortPromise]);
      } else await Promise.race([new Promise((resolve) => setTimeout(resolve, lastInterval)), abortPromise]);
      abortSignal.throwIfAborted();
      try {
        return await this.getTransaction({
          digest,
          include,
          signal: abortSignal
        });
      } catch {
      }
    }
  }
  async signAndExecuteTransaction({ transaction, signer, additionalSignatures = [], ...input }) {
    let transactionBytes;
    if (transaction instanceof Uint8Array) transactionBytes = transaction;
    else {
      transaction.setSenderIfNotSet(signer.toSuiAddress());
      transactionBytes = await transaction.build({ client: this });
    }
    const { signature } = await signer.signTransaction(transactionBytes);
    return this.executeTransaction({
      transaction: transactionBytes,
      signatures: [signature, ...additionalSignatures],
      ...input
    });
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/client/utils.mjs
import { toBase64 as toBase6410 } from "@mysten/utils";
var ordinalRules = new Intl.PluralRules("en-US", { type: "ordinal" });
var ordinalSuffixes = /* @__PURE__ */ new Map([
  ["one", "st"],
  ["two", "nd"],
  ["few", "rd"],
  ["other", "th"]
]);
function formatOrdinal(n) {
  return `${n}${ordinalSuffixes.get(ordinalRules.select(n))}`;
}
function formatMoveAbortMessage(options) {
  const { command, location, abortCode, cleverError } = options;
  const parts = [];
  if (command != null) parts.push(`MoveAbort in ${formatOrdinal(command + 1)} command`);
  else parts.push("MoveAbort");
  if (cleverError?.constantName) {
    const errorStr = cleverError.value ? `'${cleverError.constantName}': ${cleverError.value}` : `'${cleverError.constantName}'`;
    parts.push(errorStr);
  } else parts.push(`abort code: ${abortCode}`);
  if (location?.package && location?.module) {
    const locationStr = [`in '${[
      location.package.startsWith("0x") ? location.package : `0x${location.package}`,
      location.module,
      location.functionName
    ].filter(Boolean).join("::")}'`];
    if (cleverError?.lineNumber != null) locationStr.push(`(line ${cleverError.lineNumber})`);
    else if (location.instruction != null) locationStr.push(`(instruction ${location.instruction})`);
    parts.push(locationStr.join(" "));
  }
  return parts.join(", ");
}
var MinimalEffectsWithError = suiBcs.struct("MinimalEffectsWithError", { status: ExecutionStatus });
var MinimalTransactionEffectsWithError = suiBcs.enum("MinimalTransactionEffectsWithError", {
  V1: MinimalEffectsWithError,
  V2: MinimalEffectsWithError
});
var MinimalExecutionStatusNoError = suiBcs.enum("MinimalExecutionStatusNoError", {
  Success: null,
  Failed: null
});
var MinimalEffectsNoError = suiBcs.struct("MinimalEffectsNoError", { status: MinimalExecutionStatusNoError });
var MinimalTransactionEffectsNoError = suiBcs.enum("MinimalTransactionEffectsNoError", {
  V1: MinimalEffectsNoError,
  V2: MinimalEffectsNoError
});
function transactionBytesHaveEmptyGasPayment(bytes) {
  try {
    return suiBcs.TransactionData.parse(bytes).V1?.gasData.payment?.length === 0;
  } catch {
    return false;
  }
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/client/errors.mjs
var SuiClientError = class extends Error {
};
var SimulationError = class extends SuiClientError {
  constructor(message, options) {
    super(message, { cause: options?.cause });
    this.executionError = options?.executionError;
  }
};
var ObjectError = class extends SuiClientError {
  constructor(code, message, options) {
    super(message, { cause: options?.cause });
    this.code = code;
    this.reason = options?.reason ?? "unknown";
    this.objectId = options?.objectId;
  }
};
var TRANSACTION_ERROR_MESSAGES = { notFound: (digest) => `Transaction ${digest} not found` };
var TransactionError = class extends SuiClientError {
  constructor(reason, digest, options) {
    super(TRANSACTION_ERROR_MESSAGES[reason](digest), options);
    this.reason = reason;
    this.digest = digest;
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/utils/constants.mjs
var MIST_PER_SUI = BigInt(1e9);
var SUI_FRAMEWORK_ADDRESS = "0x0000000000000000000000000000000000000000000000000000000000000002";
var SUI_TYPE_ARG = `${SUI_FRAMEWORK_ADDRESS}::sui::SUI`;

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/struct.mjs
import { MessageType, isJsonObject, typeofJsonValue } from "@protobuf-ts/runtime";
var NullValue = /* @__PURE__ */ (function(NullValue$1) {
  NullValue$1[NullValue$1["NULL_VALUE"] = 0] = "NULL_VALUE";
  return NullValue$1;
})({});
var Struct$Type = class extends MessageType {
  constructor() {
    super("google.protobuf.Struct", [{
      no: 1,
      name: "fields",
      kind: "map",
      K: 9,
      V: {
        kind: "message",
        T: () => Value
      }
    }]);
  }
  /**
  * Encode `Struct` to JSON object.
  */
  internalJsonWrite(message, options) {
    let json2 = {};
    for (let [k, v] of Object.entries(message.fields)) json2[k] = Value.toJson(v);
    return json2;
  }
  /**
  * Decode `Struct` from JSON object.
  */
  internalJsonRead(json2, options, target) {
    if (!isJsonObject(json2)) throw new globalThis.Error("Unable to parse message " + this.typeName + " from JSON " + typeofJsonValue(json2) + ".");
    if (!target) target = this.create();
    for (let [k, v] of globalThis.Object.entries(json2)) target.fields[k] = Value.fromJson(v);
    return target;
  }
};
var Struct = new Struct$Type();
var Value$Type = class extends MessageType {
  constructor() {
    super("google.protobuf.Value", [
      {
        no: 1,
        name: "null_value",
        kind: "enum",
        oneof: "kind",
        T: () => ["google.protobuf.NullValue", NullValue]
      },
      {
        no: 2,
        name: "number_value",
        kind: "scalar",
        oneof: "kind",
        T: 1
      },
      {
        no: 3,
        name: "string_value",
        kind: "scalar",
        oneof: "kind",
        T: 9
      },
      {
        no: 4,
        name: "bool_value",
        kind: "scalar",
        oneof: "kind",
        T: 8
      },
      {
        no: 5,
        name: "struct_value",
        kind: "message",
        oneof: "kind",
        T: () => Struct
      },
      {
        no: 6,
        name: "list_value",
        kind: "message",
        oneof: "kind",
        T: () => ListValue
      }
    ]);
  }
  /**
  * Encode `Value` to JSON value.
  */
  internalJsonWrite(message, options) {
    if (message.kind.oneofKind === void 0) throw new globalThis.Error();
    switch (message.kind.oneofKind) {
      case void 0:
        throw new globalThis.Error();
      case "boolValue":
        return message.kind.boolValue;
      case "nullValue":
        return null;
      case "numberValue":
        let numberValue = message.kind.numberValue;
        if (typeof numberValue == "number" && !Number.isFinite(numberValue)) throw new globalThis.Error();
        return numberValue;
      case "stringValue":
        return message.kind.stringValue;
      case "listValue":
        let listValueField = this.fields.find((f) => f.no === 6);
        if (listValueField?.kind !== "message") throw new globalThis.Error();
        return listValueField.T().toJson(message.kind.listValue);
      case "structValue":
        let structValueField = this.fields.find((f) => f.no === 5);
        if (structValueField?.kind !== "message") throw new globalThis.Error();
        return structValueField.T().toJson(message.kind.structValue);
    }
  }
  /**
  * Decode `Value` from JSON value.
  */
  internalJsonRead(json2, options, target) {
    if (!target) target = this.create();
    switch (typeof json2) {
      case "number":
        target.kind = {
          oneofKind: "numberValue",
          numberValue: json2
        };
        break;
      case "string":
        target.kind = {
          oneofKind: "stringValue",
          stringValue: json2
        };
        break;
      case "boolean":
        target.kind = {
          oneofKind: "boolValue",
          boolValue: json2
        };
        break;
      case "object":
        if (json2 === null) target.kind = {
          oneofKind: "nullValue",
          nullValue: NullValue.NULL_VALUE
        };
        else if (globalThis.Array.isArray(json2)) target.kind = {
          oneofKind: "listValue",
          listValue: ListValue.fromJson(json2)
        };
        else target.kind = {
          oneofKind: "structValue",
          structValue: Struct.fromJson(json2)
        };
        break;
      default:
        throw new globalThis.Error("Unable to parse " + this.typeName + " from JSON " + typeofJsonValue(json2));
    }
    return target;
  }
};
var Value = new Value$Type();
var ListValue$Type = class extends MessageType {
  constructor() {
    super("google.protobuf.ListValue", [{
      no: 1,
      name: "values",
      kind: "message",
      repeat: 2,
      T: () => Value
    }]);
  }
  /**
  * Encode `ListValue` to JSON array.
  */
  internalJsonWrite(message, options) {
    return message.values.map((v) => Value.toJson(v));
  }
  /**
  * Decode `ListValue` from JSON array.
  */
  internalJsonRead(json2, options, target) {
    if (!globalThis.Array.isArray(json2)) throw new globalThis.Error("Unable to parse " + this.typeName + " from JSON " + typeofJsonValue(json2));
    if (!target) target = this.create();
    let values = json2.map((v) => Value.fromJson(v));
    target.values.push(...values);
    return target;
  }
};
var ListValue = new ListValue$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/move_package.mjs
import { MessageType as MessageType2 } from "@protobuf-ts/runtime";
var DatatypeDescriptor_DatatypeKind = /* @__PURE__ */ (function(DatatypeDescriptor_DatatypeKind$1) {
  DatatypeDescriptor_DatatypeKind$1[DatatypeDescriptor_DatatypeKind$1["DATATYPE_KIND_UNKNOWN"] = 0] = "DATATYPE_KIND_UNKNOWN";
  DatatypeDescriptor_DatatypeKind$1[DatatypeDescriptor_DatatypeKind$1["STRUCT"] = 1] = "STRUCT";
  DatatypeDescriptor_DatatypeKind$1[DatatypeDescriptor_DatatypeKind$1["ENUM"] = 2] = "ENUM";
  return DatatypeDescriptor_DatatypeKind$1;
})({});
var OpenSignatureBody_Type = /* @__PURE__ */ (function(OpenSignatureBody_Type$1) {
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["TYPE_UNKNOWN"] = 0] = "TYPE_UNKNOWN";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["ADDRESS"] = 1] = "ADDRESS";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["BOOL"] = 2] = "BOOL";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U8"] = 3] = "U8";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U16"] = 4] = "U16";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U32"] = 5] = "U32";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U64"] = 6] = "U64";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U128"] = 7] = "U128";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U256"] = 8] = "U256";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["VECTOR"] = 9] = "VECTOR";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["DATATYPE"] = 10] = "DATATYPE";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["TYPE_PARAMETER"] = 11] = "TYPE_PARAMETER";
  return OpenSignatureBody_Type$1;
})({});
var FunctionDescriptor_Visibility = /* @__PURE__ */ (function(FunctionDescriptor_Visibility$1) {
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["VISIBILITY_UNKNOWN"] = 0] = "VISIBILITY_UNKNOWN";
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["PRIVATE"] = 1] = "PRIVATE";
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["PUBLIC"] = 2] = "PUBLIC";
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["FRIEND"] = 3] = "FRIEND";
  return FunctionDescriptor_Visibility$1;
})({});
var OpenSignature_Reference = /* @__PURE__ */ (function(OpenSignature_Reference$1) {
  OpenSignature_Reference$1[OpenSignature_Reference$1["REFERENCE_UNKNOWN"] = 0] = "REFERENCE_UNKNOWN";
  OpenSignature_Reference$1[OpenSignature_Reference$1["IMMUTABLE"] = 1] = "IMMUTABLE";
  OpenSignature_Reference$1[OpenSignature_Reference$1["MUTABLE"] = 2] = "MUTABLE";
  return OpenSignature_Reference$1;
})({});
var Ability = /* @__PURE__ */ (function(Ability$1) {
  Ability$1[Ability$1["ABILITY_UNKNOWN"] = 0] = "ABILITY_UNKNOWN";
  Ability$1[Ability$1["COPY"] = 1] = "COPY";
  Ability$1[Ability$1["DROP"] = 2] = "DROP";
  Ability$1[Ability$1["STORE"] = 3] = "STORE";
  Ability$1[Ability$1["KEY"] = 4] = "KEY";
  return Ability$1;
})({});
var Package$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.Package", [
      {
        no: 1,
        name: "storage_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "original_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "modules",
        kind: "message",
        repeat: 2,
        T: () => Module
      },
      {
        no: 5,
        name: "type_origins",
        kind: "message",
        repeat: 2,
        T: () => TypeOrigin2
      },
      {
        no: 6,
        name: "linkage",
        kind: "message",
        repeat: 2,
        T: () => Linkage
      }
    ]);
  }
};
var Package = new Package$Type();
var Module$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.Module", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "contents",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "datatypes",
        kind: "message",
        repeat: 2,
        T: () => DatatypeDescriptor
      },
      {
        no: 4,
        name: "functions",
        kind: "message",
        repeat: 2,
        T: () => FunctionDescriptor
      }
    ]);
  }
};
var Module = new Module$Type();
var DatatypeDescriptor$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.DatatypeDescriptor", [
      {
        no: 1,
        name: "type_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "defining_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "abilities",
        kind: "enum",
        repeat: 1,
        T: () => ["sui.rpc.v2.Ability", Ability]
      },
      {
        no: 6,
        name: "type_parameters",
        kind: "message",
        repeat: 2,
        T: () => TypeParameter
      },
      {
        no: 7,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.DatatypeDescriptor.DatatypeKind", DatatypeDescriptor_DatatypeKind]
      },
      {
        no: 8,
        name: "fields",
        kind: "message",
        repeat: 2,
        T: () => FieldDescriptor
      },
      {
        no: 9,
        name: "variants",
        kind: "message",
        repeat: 2,
        T: () => VariantDescriptor
      }
    ]);
  }
};
var DatatypeDescriptor = new DatatypeDescriptor$Type();
var TypeParameter$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.TypeParameter", [{
      no: 1,
      name: "constraints",
      kind: "enum",
      repeat: 1,
      T: () => ["sui.rpc.v2.Ability", Ability]
    }, {
      no: 2,
      name: "is_phantom",
      kind: "scalar",
      opt: true,
      T: 8
    }]);
  }
};
var TypeParameter = new TypeParameter$Type();
var FieldDescriptor$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.FieldDescriptor", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "position",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "type",
        kind: "message",
        T: () => OpenSignatureBody
      }
    ]);
  }
};
var FieldDescriptor = new FieldDescriptor$Type();
var VariantDescriptor$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.VariantDescriptor", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "position",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "fields",
        kind: "message",
        repeat: 2,
        T: () => FieldDescriptor
      }
    ]);
  }
};
var VariantDescriptor = new VariantDescriptor$Type();
var OpenSignatureBody$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.OpenSignatureBody", [
      {
        no: 1,
        name: "type",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.OpenSignatureBody.Type", OpenSignatureBody_Type]
      },
      {
        no: 2,
        name: "type_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "type_parameter_instantiation",
        kind: "message",
        repeat: 2,
        T: () => OpenSignatureBody
      },
      {
        no: 4,
        name: "type_parameter",
        kind: "scalar",
        opt: true,
        T: 13
      }
    ]);
  }
};
var OpenSignatureBody = new OpenSignatureBody$Type();
var FunctionDescriptor$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.FunctionDescriptor", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "visibility",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.FunctionDescriptor.Visibility", FunctionDescriptor_Visibility]
      },
      {
        no: 6,
        name: "is_entry",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 7,
        name: "type_parameters",
        kind: "message",
        repeat: 2,
        T: () => TypeParameter
      },
      {
        no: 8,
        name: "parameters",
        kind: "message",
        repeat: 2,
        T: () => OpenSignature
      },
      {
        no: 9,
        name: "returns",
        kind: "message",
        repeat: 2,
        T: () => OpenSignature
      }
    ]);
  }
};
var FunctionDescriptor = new FunctionDescriptor$Type();
var OpenSignature$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.OpenSignature", [{
      no: 1,
      name: "reference",
      kind: "enum",
      opt: true,
      T: () => ["sui.rpc.v2.OpenSignature.Reference", OpenSignature_Reference]
    }, {
      no: 2,
      name: "body",
      kind: "message",
      T: () => OpenSignatureBody
    }]);
  }
};
var OpenSignature = new OpenSignature$Type();
var TypeOrigin$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.TypeOrigin", [
      {
        no: 1,
        name: "module_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "datatype_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var TypeOrigin2 = new TypeOrigin$Type();
var Linkage$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.Linkage", [
      {
        no: 1,
        name: "original_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "upgraded_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "upgraded_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var Linkage = new Linkage$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/owner.mjs
import { MessageType as MessageType3 } from "@protobuf-ts/runtime";
var Owner_OwnerKind = /* @__PURE__ */ (function(Owner_OwnerKind$1) {
  Owner_OwnerKind$1[Owner_OwnerKind$1["OWNER_KIND_UNKNOWN"] = 0] = "OWNER_KIND_UNKNOWN";
  Owner_OwnerKind$1[Owner_OwnerKind$1["ADDRESS"] = 1] = "ADDRESS";
  Owner_OwnerKind$1[Owner_OwnerKind$1["OBJECT"] = 2] = "OBJECT";
  Owner_OwnerKind$1[Owner_OwnerKind$1["SHARED"] = 3] = "SHARED";
  Owner_OwnerKind$1[Owner_OwnerKind$1["IMMUTABLE"] = 4] = "IMMUTABLE";
  Owner_OwnerKind$1[Owner_OwnerKind$1["CONSENSUS_ADDRESS"] = 5] = "CONSENSUS_ADDRESS";
  return Owner_OwnerKind$1;
})({});
var Owner$Type = class extends MessageType3 {
  constructor() {
    super("sui.rpc.v2.Owner", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Owner.OwnerKind", Owner_OwnerKind]
      },
      {
        no: 2,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var Owner2 = new Owner$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/argument.mjs
import { MessageType as MessageType4 } from "@protobuf-ts/runtime";
var Argument_ArgumentKind = /* @__PURE__ */ (function(Argument_ArgumentKind$1) {
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["ARGUMENT_KIND_UNKNOWN"] = 0] = "ARGUMENT_KIND_UNKNOWN";
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["GAS"] = 1] = "GAS";
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["INPUT"] = 2] = "INPUT";
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["RESULT"] = 3] = "RESULT";
  return Argument_ArgumentKind$1;
})({});
var Argument$Type = class extends MessageType4 {
  constructor() {
    super("sui.rpc.v2.Argument", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Argument.ArgumentKind", Argument_ArgumentKind]
      },
      {
        no: 2,
        name: "input",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "result",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 4,
        name: "subresult",
        kind: "scalar",
        opt: true,
        T: 13
      }
    ]);
  }
};
var Argument2 = new Argument$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/input.mjs
import { MessageType as MessageType5 } from "@protobuf-ts/runtime";
var Input_InputKind = /* @__PURE__ */ (function(Input_InputKind$1) {
  Input_InputKind$1[Input_InputKind$1["INPUT_KIND_UNKNOWN"] = 0] = "INPUT_KIND_UNKNOWN";
  Input_InputKind$1[Input_InputKind$1["PURE"] = 1] = "PURE";
  Input_InputKind$1[Input_InputKind$1["IMMUTABLE_OR_OWNED"] = 2] = "IMMUTABLE_OR_OWNED";
  Input_InputKind$1[Input_InputKind$1["SHARED"] = 3] = "SHARED";
  Input_InputKind$1[Input_InputKind$1["RECEIVING"] = 4] = "RECEIVING";
  Input_InputKind$1[Input_InputKind$1["FUNDS_WITHDRAWAL"] = 5] = "FUNDS_WITHDRAWAL";
  return Input_InputKind$1;
})({});
var Input_Mutability = /* @__PURE__ */ (function(Input_Mutability$1) {
  Input_Mutability$1[Input_Mutability$1["MUTABILITY_UNKNOWN"] = 0] = "MUTABILITY_UNKNOWN";
  Input_Mutability$1[Input_Mutability$1["IMMUTABLE"] = 1] = "IMMUTABLE";
  Input_Mutability$1[Input_Mutability$1["MUTABLE"] = 2] = "MUTABLE";
  Input_Mutability$1[Input_Mutability$1["NON_EXCLUSIVE_WRITE"] = 3] = "NON_EXCLUSIVE_WRITE";
  return Input_Mutability$1;
})({});
var FundsWithdrawal_Source = /* @__PURE__ */ (function(FundsWithdrawal_Source$1) {
  FundsWithdrawal_Source$1[FundsWithdrawal_Source$1["SOURCE_UNKNOWN"] = 0] = "SOURCE_UNKNOWN";
  FundsWithdrawal_Source$1[FundsWithdrawal_Source$1["SENDER"] = 1] = "SENDER";
  FundsWithdrawal_Source$1[FundsWithdrawal_Source$1["SPONSOR"] = 2] = "SPONSOR";
  return FundsWithdrawal_Source$1;
})({});
var Input$Type = class extends MessageType5 {
  constructor() {
    super("sui.rpc.v2.Input", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Input.InputKind", Input_InputKind]
      },
      {
        no: 2,
        name: "pure",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "mutable",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 7,
        name: "mutability",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Input.Mutability", Input_Mutability]
      },
      {
        no: 8,
        name: "funds_withdrawal",
        kind: "message",
        T: () => FundsWithdrawal2
      },
      {
        no: 1e3,
        name: "literal",
        kind: "message",
        T: () => Value
      }
    ]);
  }
};
var Input = new Input$Type();
var FundsWithdrawal$Type = class extends MessageType5 {
  constructor() {
    super("sui.rpc.v2.FundsWithdrawal", [
      {
        no: 1,
        name: "amount",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "source",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.FundsWithdrawal.Source", FundsWithdrawal_Source]
      }
    ]);
  }
};
var FundsWithdrawal2 = new FundsWithdrawal$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/duration.mjs
import { MessageType as MessageType6, PbLong, typeofJsonValue as typeofJsonValue2 } from "@protobuf-ts/runtime";
var Duration$Type = class extends MessageType6 {
  constructor() {
    super("google.protobuf.Duration", [{
      no: 1,
      name: "seconds",
      kind: "scalar",
      T: 3,
      L: 0
    }, {
      no: 2,
      name: "nanos",
      kind: "scalar",
      T: 5
    }]);
  }
  /**
  * Encode `Duration` to JSON string like "3.000001s".
  */
  internalJsonWrite(message, options) {
    let s = PbLong.from(message.seconds).toNumber();
    if (s > 315576e6 || s < -315576e6) throw new Error("Duration value out of range.");
    let text = message.seconds.toString();
    if (s === 0 && message.nanos < 0) text = "-" + text;
    if (message.nanos !== 0) {
      let nanosStr = Math.abs(message.nanos).toString();
      nanosStr = "0".repeat(9 - nanosStr.length) + nanosStr;
      if (nanosStr.substring(3) === "000000") nanosStr = nanosStr.substring(0, 3);
      else if (nanosStr.substring(6) === "000") nanosStr = nanosStr.substring(0, 6);
      text += "." + nanosStr;
    }
    return text + "s";
  }
  /**
  * Decode `Duration` from JSON string like "3.000001s"
  */
  internalJsonRead(json2, options, target) {
    if (typeof json2 !== "string") throw new Error("Unable to parse Duration from JSON " + typeofJsonValue2(json2) + ". Expected string.");
    let match = json2.match(/^(-?)([0-9]+)(?:\.([0-9]+))?s/);
    if (match === null) throw new Error("Unable to parse Duration from JSON string. Invalid format.");
    if (!target) target = this.create();
    let [, sign, secs, nanos] = match;
    let longSeconds = PbLong.from(sign + secs);
    if (longSeconds.toNumber() > 315576e6 || longSeconds.toNumber() < -315576e6) throw new Error("Unable to parse Duration from JSON string. Value out of range.");
    target.seconds = longSeconds.toBigInt();
    if (typeof nanos == "string") {
      let nanosStr = sign + nanos + "0".repeat(9 - nanos.length);
      target.nanos = parseInt(nanosStr);
    }
    return target;
  }
};
var Duration = new Duration$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/jwk.mjs
import { MessageType as MessageType7 } from "@protobuf-ts/runtime";
var JwkId$Type = class extends MessageType7 {
  constructor() {
    super("sui.rpc.v2.JwkId", [{
      no: 1,
      name: "iss",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "kid",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var JwkId = new JwkId$Type();
var Jwk$Type = class extends MessageType7 {
  constructor() {
    super("sui.rpc.v2.Jwk", [
      {
        no: 1,
        name: "kty",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "e",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "n",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "alg",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var Jwk = new Jwk$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/bcs.mjs
import { MessageType as MessageType8 } from "@protobuf-ts/runtime";
var Bcs$Type = class extends MessageType8 {
  constructor() {
    super("sui.rpc.v2.Bcs", [{
      no: 1,
      name: "name",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "value",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var Bcs = new Bcs$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/object.mjs
import { MessageType as MessageType9 } from "@protobuf-ts/runtime";
var Object$Type = class extends MessageType9 {
  constructor() {
    super("sui.rpc.v2.Object", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "owner",
        kind: "message",
        T: () => Owner2
      },
      {
        no: 6,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "has_public_transfer",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 8,
        name: "contents",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 9,
        name: "package",
        kind: "message",
        T: () => Package
      },
      {
        no: 10,
        name: "previous_transaction",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 11,
        name: "storage_rebate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 100,
        name: "json",
        kind: "message",
        T: () => Value
      },
      {
        no: 101,
        name: "balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 102,
        name: "display",
        kind: "message",
        T: () => Display
      }
    ]);
  }
};
var Object$1 = new Object$Type();
var ObjectSet$Type = class extends MessageType9 {
  constructor() {
    super("sui.rpc.v2.ObjectSet", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Object$1
    }]);
  }
};
var ObjectSet = new ObjectSet$Type();
var Display$Type = class extends MessageType9 {
  constructor() {
    super("sui.rpc.v2.Display", [{
      no: 1,
      name: "output",
      kind: "message",
      T: () => Value
    }, {
      no: 2,
      name: "errors",
      kind: "message",
      T: () => Value
    }]);
  }
};
var Display = new Display$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/timestamp.mjs
import { MessageType as MessageType10, PbLong as PbLong2, typeofJsonValue as typeofJsonValue3 } from "@protobuf-ts/runtime";
var Timestamp$Type = class extends MessageType10 {
  constructor() {
    super("google.protobuf.Timestamp", [{
      no: 1,
      name: "seconds",
      kind: "scalar",
      T: 3,
      L: 0
    }, {
      no: 2,
      name: "nanos",
      kind: "scalar",
      T: 5
    }]);
  }
  /**
  * Creates a new `Timestamp` for the current time.
  */
  now() {
    const msg = this.create();
    const ms = Date.now();
    msg.seconds = PbLong2.from(Math.floor(ms / 1e3)).toBigInt();
    msg.nanos = ms % 1e3 * 1e6;
    return msg;
  }
  /**
  * Converts a `Timestamp` to a JavaScript Date.
  */
  toDate(message) {
    return new Date(PbLong2.from(message.seconds).toNumber() * 1e3 + Math.ceil(message.nanos / 1e6));
  }
  /**
  * Converts a JavaScript Date to a `Timestamp`.
  */
  fromDate(date) {
    const msg = this.create();
    const ms = date.getTime();
    msg.seconds = PbLong2.from(Math.floor(ms / 1e3)).toBigInt();
    msg.nanos = (ms % 1e3 + (ms < 0 && ms % 1e3 !== 0 ? 1e3 : 0)) * 1e6;
    return msg;
  }
  /**
  * In JSON format, the `Timestamp` type is encoded as a string
  * in the RFC 3339 format.
  */
  internalJsonWrite(message, options) {
    let ms = PbLong2.from(message.seconds).toNumber() * 1e3;
    if (ms < Date.parse("0001-01-01T00:00:00Z") || ms > Date.parse("9999-12-31T23:59:59Z")) throw new Error("Unable to encode Timestamp to JSON. Must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive.");
    if (message.nanos < 0) throw new Error("Unable to encode invalid Timestamp to JSON. Nanos must not be negative.");
    let z = "Z";
    if (message.nanos > 0) {
      let nanosStr = (message.nanos + 1e9).toString().substring(1);
      if (nanosStr.substring(3) === "000000") z = "." + nanosStr.substring(0, 3) + "Z";
      else if (nanosStr.substring(6) === "000") z = "." + nanosStr.substring(0, 6) + "Z";
      else z = "." + nanosStr + "Z";
    }
    return new Date(ms).toISOString().replace(".000Z", z);
  }
  /**
  * In JSON format, the `Timestamp` type is encoded as a string
  * in the RFC 3339 format.
  */
  internalJsonRead(json2, options, target) {
    if (typeof json2 !== "string") throw new Error("Unable to parse Timestamp from JSON " + typeofJsonValue3(json2) + ".");
    let matches = json2.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(?:Z|\.([0-9]{3,9})Z|([+-][0-9][0-9]:[0-9][0-9]))$/);
    if (!matches) throw new Error("Unable to parse Timestamp from JSON. Invalid format.");
    let ms = Date.parse(matches[1] + "-" + matches[2] + "-" + matches[3] + "T" + matches[4] + ":" + matches[5] + ":" + matches[6] + (matches[8] ? matches[8] : "Z"));
    if (Number.isNaN(ms)) throw new Error("Unable to parse Timestamp from JSON. Invalid value.");
    if (ms < Date.parse("0001-01-01T00:00:00Z") || ms > Date.parse("9999-12-31T23:59:59Z")) throw new globalThis.Error("Unable to parse Timestamp from JSON. Must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive.");
    if (!target) target = this.create();
    target.seconds = PbLong2.from(ms / 1e3).toBigInt();
    target.nanos = 0;
    if (matches[7]) target.nanos = parseInt("1" + matches[7] + "0".repeat(9 - matches[7].length)) - 1e9;
    return target;
  }
};
var Timestamp = new Timestamp$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/object_reference.mjs
import { MessageType as MessageType11 } from "@protobuf-ts/runtime";
var ObjectReference$Type = class extends MessageType11 {
  constructor() {
    super("sui.rpc.v2.ObjectReference", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ObjectReference = new ObjectReference$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/transaction.mjs
import { MessageType as MessageType12 } from "@protobuf-ts/runtime";
var TransactionExpiration_TransactionExpirationKind = /* @__PURE__ */ (function(TransactionExpiration_TransactionExpirationKind$1) {
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["TRANSACTION_EXPIRATION_KIND_UNKNOWN"] = 0] = "TRANSACTION_EXPIRATION_KIND_UNKNOWN";
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["NONE"] = 1] = "NONE";
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["EPOCH"] = 2] = "EPOCH";
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["VALID_DURING"] = 3] = "VALID_DURING";
  return TransactionExpiration_TransactionExpirationKind$1;
})({});
var TransactionKind_Kind = /* @__PURE__ */ (function(TransactionKind_Kind$1) {
  TransactionKind_Kind$1[TransactionKind_Kind$1["KIND_UNKNOWN"] = 0] = "KIND_UNKNOWN";
  TransactionKind_Kind$1[TransactionKind_Kind$1["PROGRAMMABLE_TRANSACTION"] = 1] = "PROGRAMMABLE_TRANSACTION";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CHANGE_EPOCH"] = 2] = "CHANGE_EPOCH";
  TransactionKind_Kind$1[TransactionKind_Kind$1["GENESIS"] = 3] = "GENESIS";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V1"] = 4] = "CONSENSUS_COMMIT_PROLOGUE_V1";
  TransactionKind_Kind$1[TransactionKind_Kind$1["AUTHENTICATOR_STATE_UPDATE"] = 5] = "AUTHENTICATOR_STATE_UPDATE";
  TransactionKind_Kind$1[TransactionKind_Kind$1["END_OF_EPOCH"] = 6] = "END_OF_EPOCH";
  TransactionKind_Kind$1[TransactionKind_Kind$1["RANDOMNESS_STATE_UPDATE"] = 7] = "RANDOMNESS_STATE_UPDATE";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V2"] = 8] = "CONSENSUS_COMMIT_PROLOGUE_V2";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V3"] = 9] = "CONSENSUS_COMMIT_PROLOGUE_V3";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V4"] = 10] = "CONSENSUS_COMMIT_PROLOGUE_V4";
  TransactionKind_Kind$1[TransactionKind_Kind$1["PROGRAMMABLE_SYSTEM_TRANSACTION"] = 11] = "PROGRAMMABLE_SYSTEM_TRANSACTION";
  return TransactionKind_Kind$1;
})({});
var EndOfEpochTransactionKind_Kind = /* @__PURE__ */ (function(EndOfEpochTransactionKind_Kind$1) {
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["KIND_UNKNOWN"] = 0] = "KIND_UNKNOWN";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["CHANGE_EPOCH"] = 1] = "CHANGE_EPOCH";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["AUTHENTICATOR_STATE_CREATE"] = 2] = "AUTHENTICATOR_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["AUTHENTICATOR_STATE_EXPIRE"] = 3] = "AUTHENTICATOR_STATE_EXPIRE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["RANDOMNESS_STATE_CREATE"] = 4] = "RANDOMNESS_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["DENY_LIST_STATE_CREATE"] = 5] = "DENY_LIST_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["BRIDGE_STATE_CREATE"] = 6] = "BRIDGE_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["BRIDGE_COMMITTEE_INIT"] = 7] = "BRIDGE_COMMITTEE_INIT";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["STORE_EXECUTION_TIME_OBSERVATIONS"] = 8] = "STORE_EXECUTION_TIME_OBSERVATIONS";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["ACCUMULATOR_ROOT_CREATE"] = 9] = "ACCUMULATOR_ROOT_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["COIN_REGISTRY_CREATE"] = 10] = "COIN_REGISTRY_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["DISPLAY_REGISTRY_CREATE"] = 11] = "DISPLAY_REGISTRY_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["ADDRESS_ALIAS_STATE_CREATE"] = 12] = "ADDRESS_ALIAS_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["WRITE_ACCUMULATOR_STORAGE_COST"] = 13] = "WRITE_ACCUMULATOR_STORAGE_COST";
  return EndOfEpochTransactionKind_Kind$1;
})({});
var ExecutionTimeObservation_ExecutionTimeObservationKind = /* @__PURE__ */ (function(ExecutionTimeObservation_ExecutionTimeObservationKind$1) {
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["EXECUTION_TIME_OBSERVATION_KIND_UNKNOWN"] = 0] = "EXECUTION_TIME_OBSERVATION_KIND_UNKNOWN";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["MOVE_ENTRY_POINT"] = 1] = "MOVE_ENTRY_POINT";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["TRANSFER_OBJECTS"] = 2] = "TRANSFER_OBJECTS";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["SPLIT_COINS"] = 3] = "SPLIT_COINS";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["MERGE_COINS"] = 4] = "MERGE_COINS";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["PUBLISH"] = 5] = "PUBLISH";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["MAKE_MOVE_VECTOR"] = 6] = "MAKE_MOVE_VECTOR";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["UPGRADE"] = 7] = "UPGRADE";
  return ExecutionTimeObservation_ExecutionTimeObservationKind$1;
})({});
var Transaction$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.Transaction", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 5
      },
      {
        no: 4,
        name: "kind",
        kind: "message",
        T: () => TransactionKind2
      },
      {
        no: 5,
        name: "sender",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "gas_payment",
        kind: "message",
        T: () => GasPayment
      },
      {
        no: 7,
        name: "expiration",
        kind: "message",
        T: () => TransactionExpiration2
      }
    ]);
  }
};
var Transaction = new Transaction$Type();
var GasPayment$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.GasPayment", [
      {
        no: 1,
        name: "objects",
        kind: "message",
        repeat: 2,
        T: () => ObjectReference
      },
      {
        no: 2,
        name: "owner",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "budget",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var GasPayment = new GasPayment$Type();
var TransactionExpiration$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.TransactionExpiration", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.TransactionExpiration.TransactionExpirationKind", TransactionExpiration_TransactionExpirationKind]
      },
      {
        no: 2,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "min_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "min_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 5,
        name: "max_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 6,
        name: "chain",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "nonce",
        kind: "scalar",
        opt: true,
        T: 13
      }
    ]);
  }
};
var TransactionExpiration2 = new TransactionExpiration$Type();
var TransactionKind$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.TransactionKind", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.TransactionKind.Kind", TransactionKind_Kind]
      },
      {
        no: 2,
        name: "programmable_transaction",
        kind: "message",
        oneof: "data",
        T: () => ProgrammableTransaction2
      },
      {
        no: 3,
        name: "change_epoch",
        kind: "message",
        oneof: "data",
        T: () => ChangeEpoch2
      },
      {
        no: 4,
        name: "genesis",
        kind: "message",
        oneof: "data",
        T: () => GenesisTransaction2
      },
      {
        no: 5,
        name: "consensus_commit_prologue",
        kind: "message",
        oneof: "data",
        T: () => ConsensusCommitPrologue2
      },
      {
        no: 6,
        name: "authenticator_state_update",
        kind: "message",
        oneof: "data",
        T: () => AuthenticatorStateUpdate2
      },
      {
        no: 7,
        name: "end_of_epoch",
        kind: "message",
        oneof: "data",
        T: () => EndOfEpochTransaction
      },
      {
        no: 8,
        name: "randomness_state_update",
        kind: "message",
        oneof: "data",
        T: () => RandomnessStateUpdate2
      }
    ]);
  }
};
var TransactionKind2 = new TransactionKind$Type();
var ProgrammableTransaction$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ProgrammableTransaction", [{
      no: 1,
      name: "inputs",
      kind: "message",
      repeat: 2,
      T: () => Input
    }, {
      no: 2,
      name: "commands",
      kind: "message",
      repeat: 2,
      T: () => Command2
    }]);
  }
};
var ProgrammableTransaction2 = new ProgrammableTransaction$Type();
var Command$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.Command", [
      {
        no: 1,
        name: "move_call",
        kind: "message",
        oneof: "command",
        T: () => MoveCall
      },
      {
        no: 2,
        name: "transfer_objects",
        kind: "message",
        oneof: "command",
        T: () => TransferObjects
      },
      {
        no: 3,
        name: "split_coins",
        kind: "message",
        oneof: "command",
        T: () => SplitCoins
      },
      {
        no: 4,
        name: "merge_coins",
        kind: "message",
        oneof: "command",
        T: () => MergeCoins
      },
      {
        no: 5,
        name: "publish",
        kind: "message",
        oneof: "command",
        T: () => Publish
      },
      {
        no: 6,
        name: "make_move_vector",
        kind: "message",
        oneof: "command",
        T: () => MakeMoveVector
      },
      {
        no: 7,
        name: "upgrade",
        kind: "message",
        oneof: "command",
        T: () => Upgrade
      }
    ]);
  }
};
var Command2 = new Command$Type();
var MoveCall$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.MoveCall", [
      {
        no: 1,
        name: "package",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "function",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "type_arguments",
        kind: "scalar",
        repeat: 2,
        T: 9
      },
      {
        no: 5,
        name: "arguments",
        kind: "message",
        repeat: 2,
        T: () => Argument2
      }
    ]);
  }
};
var MoveCall = new MoveCall$Type();
var TransferObjects$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.TransferObjects", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }, {
      no: 2,
      name: "address",
      kind: "message",
      T: () => Argument2
    }]);
  }
};
var TransferObjects = new TransferObjects$Type();
var SplitCoins$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.SplitCoins", [{
      no: 1,
      name: "coin",
      kind: "message",
      T: () => Argument2
    }, {
      no: 2,
      name: "amounts",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }]);
  }
};
var SplitCoins = new SplitCoins$Type();
var MergeCoins$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.MergeCoins", [{
      no: 1,
      name: "coin",
      kind: "message",
      T: () => Argument2
    }, {
      no: 2,
      name: "coins_to_merge",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }]);
  }
};
var MergeCoins = new MergeCoins$Type();
var Publish$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.Publish", [{
      no: 1,
      name: "modules",
      kind: "scalar",
      repeat: 2,
      T: 12
    }, {
      no: 2,
      name: "dependencies",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
};
var Publish = new Publish$Type();
var MakeMoveVector$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.MakeMoveVector", [{
      no: 1,
      name: "element_type",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "elements",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }]);
  }
};
var MakeMoveVector = new MakeMoveVector$Type();
var Upgrade$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.Upgrade", [
      {
        no: 1,
        name: "modules",
        kind: "scalar",
        repeat: 2,
        T: 12
      },
      {
        no: 2,
        name: "dependencies",
        kind: "scalar",
        repeat: 2,
        T: 9
      },
      {
        no: 3,
        name: "package",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "ticket",
        kind: "message",
        T: () => Argument2
      }
    ]);
  }
};
var Upgrade = new Upgrade$Type();
var RandomnessStateUpdate$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.RandomnessStateUpdate", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "randomness_round",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "random_bytes",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "randomness_object_initial_shared_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var RandomnessStateUpdate2 = new RandomnessStateUpdate$Type();
var ChangeEpoch$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ChangeEpoch", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "storage_charge",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "computation_charge",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "storage_rebate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "non_refundable_storage_fee",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "epoch_start_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 8,
        name: "system_packages",
        kind: "message",
        repeat: 2,
        T: () => SystemPackage
      }
    ]);
  }
};
var ChangeEpoch2 = new ChangeEpoch$Type();
var SystemPackage$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.SystemPackage", [
      {
        no: 1,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "modules",
        kind: "scalar",
        repeat: 2,
        T: 12
      },
      {
        no: 3,
        name: "dependencies",
        kind: "scalar",
        repeat: 2,
        T: 9
      }
    ]);
  }
};
var SystemPackage = new SystemPackage$Type();
var GenesisTransaction$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.GenesisTransaction", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Object$1
    }]);
  }
};
var GenesisTransaction2 = new GenesisTransaction$Type();
var ConsensusCommitPrologue$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ConsensusCommitPrologue", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "round",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "commit_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 4,
        name: "consensus_commit_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "sub_dag_index",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "consensus_determined_version_assignments",
        kind: "message",
        T: () => ConsensusDeterminedVersionAssignments2
      },
      {
        no: 7,
        name: "additional_state_digest",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ConsensusCommitPrologue2 = new ConsensusCommitPrologue$Type();
var VersionAssignment$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.VersionAssignment", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "start_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var VersionAssignment = new VersionAssignment$Type();
var CanceledTransaction$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.CanceledTransaction", [{
      no: 1,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "version_assignments",
      kind: "message",
      repeat: 2,
      T: () => VersionAssignment
    }]);
  }
};
var CanceledTransaction = new CanceledTransaction$Type();
var ConsensusDeterminedVersionAssignments$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ConsensusDeterminedVersionAssignments", [{
      no: 1,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 5
    }, {
      no: 3,
      name: "canceled_transactions",
      kind: "message",
      repeat: 2,
      T: () => CanceledTransaction
    }]);
  }
};
var ConsensusDeterminedVersionAssignments2 = new ConsensusDeterminedVersionAssignments$Type();
var AuthenticatorStateUpdate$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.AuthenticatorStateUpdate", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "round",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "new_active_jwks",
        kind: "message",
        repeat: 2,
        T: () => ActiveJwk2
      },
      {
        no: 4,
        name: "authenticator_object_initial_shared_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var AuthenticatorStateUpdate2 = new AuthenticatorStateUpdate$Type();
var ActiveJwk$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ActiveJwk", [
      {
        no: 1,
        name: "id",
        kind: "message",
        T: () => JwkId
      },
      {
        no: 2,
        name: "jwk",
        kind: "message",
        T: () => Jwk
      },
      {
        no: 3,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var ActiveJwk2 = new ActiveJwk$Type();
var EndOfEpochTransaction$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.EndOfEpochTransaction", [{
      no: 1,
      name: "transactions",
      kind: "message",
      repeat: 2,
      T: () => EndOfEpochTransactionKind2
    }]);
  }
};
var EndOfEpochTransaction = new EndOfEpochTransaction$Type();
var EndOfEpochTransactionKind$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.EndOfEpochTransactionKind", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.EndOfEpochTransactionKind.Kind", EndOfEpochTransactionKind_Kind]
      },
      {
        no: 2,
        name: "change_epoch",
        kind: "message",
        oneof: "data",
        T: () => ChangeEpoch2
      },
      {
        no: 3,
        name: "authenticator_state_expire",
        kind: "message",
        oneof: "data",
        T: () => AuthenticatorStateExpire2
      },
      {
        no: 4,
        name: "execution_time_observations",
        kind: "message",
        oneof: "data",
        T: () => ExecutionTimeObservations
      },
      {
        no: 5,
        name: "bridge_chain_id",
        kind: "scalar",
        oneof: "data",
        T: 9
      },
      {
        no: 6,
        name: "bridge_object_version",
        kind: "scalar",
        oneof: "data",
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "storage_cost",
        kind: "scalar",
        oneof: "data",
        T: 4,
        L: 0
      }
    ]);
  }
};
var EndOfEpochTransactionKind2 = new EndOfEpochTransactionKind$Type();
var AuthenticatorStateExpire$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.AuthenticatorStateExpire", [{
      no: 1,
      name: "min_epoch",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "authenticator_object_initial_shared_version",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var AuthenticatorStateExpire2 = new AuthenticatorStateExpire$Type();
var ExecutionTimeObservations$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ExecutionTimeObservations", [{
      no: 1,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 5
    }, {
      no: 2,
      name: "observations",
      kind: "message",
      repeat: 2,
      T: () => ExecutionTimeObservation
    }]);
  }
};
var ExecutionTimeObservations = new ExecutionTimeObservations$Type();
var ExecutionTimeObservation$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ExecutionTimeObservation", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.ExecutionTimeObservation.ExecutionTimeObservationKind", ExecutionTimeObservation_ExecutionTimeObservationKind]
      },
      {
        no: 2,
        name: "move_entry_point",
        kind: "message",
        T: () => MoveCall
      },
      {
        no: 3,
        name: "validator_observations",
        kind: "message",
        repeat: 2,
        T: () => ValidatorExecutionTimeObservation
      }
    ]);
  }
};
var ExecutionTimeObservation = new ExecutionTimeObservation$Type();
var ValidatorExecutionTimeObservation$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ValidatorExecutionTimeObservation", [{
      no: 1,
      name: "validator",
      kind: "scalar",
      opt: true,
      T: 12
    }, {
      no: 2,
      name: "duration",
      kind: "message",
      T: () => Duration
    }]);
  }
};
var ValidatorExecutionTimeObservation = new ValidatorExecutionTimeObservation$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/client/transaction-resolver.mjs
import { fromBase64 as fromBase6412, toBase64 as toBase6411 } from "@mysten/bcs";
function callArgToGrpcInput(arg) {
  switch (arg.$kind) {
    case "Pure":
      return {
        kind: Input_InputKind.PURE,
        pure: fromBase6412(arg.Pure.bytes)
      };
    case "Object":
      if (arg.Object.$kind === "ImmOrOwnedObject") return {
        kind: Input_InputKind.IMMUTABLE_OR_OWNED,
        objectId: arg.Object.ImmOrOwnedObject.objectId,
        version: BigInt(arg.Object.ImmOrOwnedObject.version),
        digest: arg.Object.ImmOrOwnedObject.digest
      };
      else if (arg.Object.$kind === "SharedObject") return {
        kind: Input_InputKind.SHARED,
        objectId: arg.Object.SharedObject.objectId,
        version: BigInt(arg.Object.SharedObject.initialSharedVersion),
        mutable: arg.Object.SharedObject.mutable
      };
      else if (arg.Object.$kind === "Receiving") return {
        kind: Input_InputKind.RECEIVING,
        objectId: arg.Object.Receiving.objectId,
        version: BigInt(arg.Object.Receiving.version),
        digest: arg.Object.Receiving.digest
      };
      throw new Error(`Unknown Object kind: ${JSON.stringify(arg.Object)}`);
    case "UnresolvedObject":
      const unresolved = arg.UnresolvedObject;
      return {
        objectId: unresolved.objectId,
        version: unresolved.version ? BigInt(unresolved.version) : unresolved.initialSharedVersion ? BigInt(unresolved.initialSharedVersion) : void 0,
        digest: unresolved.digest ?? void 0,
        mutable: unresolved.mutable ?? void 0
      };
    case "UnresolvedPure":
      throw new Error("UnresolvedPure arguments must be resolved before converting to gRPC format");
    case "FundsWithdrawal": {
      const withdrawal = arg.FundsWithdrawal;
      return {
        kind: Input_InputKind.FUNDS_WITHDRAWAL,
        fundsWithdrawal: {
          amount: withdrawal.reservation.$kind === "MaxAmountU64" ? BigInt(withdrawal.reservation.MaxAmountU64) : void 0,
          coinType: withdrawal.typeArg.$kind === "Balance" ? withdrawal.typeArg.Balance : void 0,
          source: withdrawal.withdrawFrom.$kind === "Sponsor" ? FundsWithdrawal_Source.SPONSOR : FundsWithdrawal_Source.SENDER
        }
      };
    }
    default:
      throw new Error(`Unknown CallArg kind: ${JSON.stringify(arg)}`);
  }
}
function tsArgumentToGrpcArgument(arg) {
  if ("GasCoin" in arg) return { kind: Argument_ArgumentKind.GAS };
  else if ("Input" in arg) return {
    kind: Argument_ArgumentKind.INPUT,
    input: arg.Input
  };
  else if ("Result" in arg) return {
    kind: Argument_ArgumentKind.RESULT,
    result: arg.Result
  };
  else if ("NestedResult" in arg) return {
    kind: Argument_ArgumentKind.RESULT,
    result: arg.NestedResult[0],
    subresult: arg.NestedResult[1]
  };
  throw new Error(`Unknown Argument: ${JSON.stringify(arg)}`);
}
function tsCommandToGrpcCommand(cmd) {
  switch (cmd.$kind) {
    case "MoveCall":
      return { command: {
        oneofKind: "moveCall",
        moveCall: {
          package: cmd.MoveCall.package,
          module: cmd.MoveCall.module,
          function: cmd.MoveCall.function,
          typeArguments: cmd.MoveCall.typeArguments,
          arguments: cmd.MoveCall.arguments.map(tsArgumentToGrpcArgument)
        }
      } };
    case "TransferObjects":
      return { command: {
        oneofKind: "transferObjects",
        transferObjects: {
          objects: cmd.TransferObjects.objects.map(tsArgumentToGrpcArgument),
          address: tsArgumentToGrpcArgument(cmd.TransferObjects.address)
        }
      } };
    case "SplitCoins":
      return { command: {
        oneofKind: "splitCoins",
        splitCoins: {
          coin: tsArgumentToGrpcArgument(cmd.SplitCoins.coin),
          amounts: cmd.SplitCoins.amounts.map(tsArgumentToGrpcArgument)
        }
      } };
    case "MergeCoins":
      return { command: {
        oneofKind: "mergeCoins",
        mergeCoins: {
          coin: tsArgumentToGrpcArgument(cmd.MergeCoins.destination),
          coinsToMerge: cmd.MergeCoins.sources.map(tsArgumentToGrpcArgument)
        }
      } };
    case "Publish":
      return { command: {
        oneofKind: "publish",
        publish: {
          modules: cmd.Publish.modules.map((m) => fromBase6412(m)),
          dependencies: cmd.Publish.dependencies
        }
      } };
    case "MakeMoveVec":
      return { command: {
        oneofKind: "makeMoveVector",
        makeMoveVector: {
          elementType: cmd.MakeMoveVec.type ?? void 0,
          elements: cmd.MakeMoveVec.elements.map(tsArgumentToGrpcArgument)
        }
      } };
    case "Upgrade":
      return { command: {
        oneofKind: "upgrade",
        upgrade: {
          modules: cmd.Upgrade.modules.map((m) => fromBase6412(m)),
          dependencies: cmd.Upgrade.dependencies,
          package: cmd.Upgrade.package,
          ticket: tsArgumentToGrpcArgument(cmd.Upgrade.ticket)
        }
      } };
    default:
      throw new Error(`Unknown Command kind: ${JSON.stringify(cmd)}`);
  }
}
function transactionDataToGrpcTransaction(data) {
  const transaction = {
    version: 1,
    kind: { data: {
      oneofKind: "programmableTransaction",
      programmableTransaction: {
        inputs: data.inputs.map(callArgToGrpcInput),
        commands: data.commands.map(tsCommandToGrpcCommand)
      }
    } }
  };
  if (data.sender) transaction.sender = data.sender;
  const gasOwner = data.gasData.owner ?? data.sender;
  transaction.gasPayment = {
    objects: data.gasData.payment ? data.gasData.payment.map((ref) => ({
      objectId: ref.objectId,
      version: BigInt(ref.version),
      digest: ref.digest
    })) : [],
    price: data.gasData.price ? BigInt(data.gasData.price) : void 0,
    budget: data.gasData.budget ? BigInt(data.gasData.budget) : void 0
  };
  if (gasOwner) transaction.gasPayment.owner = gasOwner;
  if (data.expiration) {
    if ("None" in data.expiration) transaction.expiration = { kind: TransactionExpiration_TransactionExpirationKind.NONE };
    else if (data.expiration.$kind === "Epoch") transaction.expiration = {
      kind: TransactionExpiration_TransactionExpirationKind.EPOCH,
      epoch: BigInt(data.expiration.Epoch)
    };
    else if (data.expiration.$kind === "ValidDuring") {
      const validDuring = data.expiration.ValidDuring;
      transaction.expiration = {
        kind: TransactionExpiration_TransactionExpirationKind.VALID_DURING,
        minEpoch: validDuring.minEpoch != null ? BigInt(validDuring.minEpoch) : void 0,
        epoch: validDuring.maxEpoch != null ? BigInt(validDuring.maxEpoch) : void 0,
        chain: validDuring.chain,
        nonce: validDuring.nonce
      };
    }
  }
  return transaction;
}
function applyGrpcResolvedTransaction(transactionData, resolvedTransaction, options) {
  const resolved = grpcTransactionToTransactionData(resolvedTransaction);
  if (options?.onlyTransactionKind) transactionData.applyResolvedData({
    ...resolved,
    sender: null,
    gasData: {
      budget: null,
      owner: null,
      payment: null,
      price: null
    },
    expiration: null
  });
  else transactionData.applyResolvedData(resolved);
}
function transactionToGrpcTransaction(transaction) {
  const snapshot = transaction.getData();
  if (!snapshot.sender) snapshot.sender = "0x0000000000000000000000000000000000000000000000000000000000000000";
  return transactionDataToGrpcTransaction(snapshot);
}
function grpcInputToCallArg(input) {
  switch (input.kind) {
    case Input_InputKind.PURE:
      return {
        $kind: "Pure",
        Pure: { bytes: toBase6411(input.pure) }
      };
    case Input_InputKind.IMMUTABLE_OR_OWNED:
      return {
        $kind: "Object",
        Object: {
          $kind: "ImmOrOwnedObject",
          ImmOrOwnedObject: {
            objectId: input.objectId,
            version: input.version.toString(),
            digest: input.digest
          }
        }
      };
    case Input_InputKind.SHARED:
      return {
        $kind: "Object",
        Object: {
          $kind: "SharedObject",
          SharedObject: {
            objectId: input.objectId,
            initialSharedVersion: input.version.toString(),
            mutable: input.mutable ?? false
          }
        }
      };
    case Input_InputKind.RECEIVING:
      return {
        $kind: "Object",
        Object: {
          $kind: "Receiving",
          Receiving: {
            objectId: input.objectId,
            version: input.version.toString(),
            digest: input.digest
          }
        }
      };
    case Input_InputKind.FUNDS_WITHDRAWAL:
      return {
        $kind: "FundsWithdrawal",
        FundsWithdrawal: {
          reservation: {
            $kind: "MaxAmountU64",
            MaxAmountU64: input.fundsWithdrawal?.amount?.toString() ?? "0"
          },
          typeArg: {
            $kind: "Balance",
            Balance: input.fundsWithdrawal?.coinType ?? "0x2::sui::SUI"
          },
          withdrawFrom: input.fundsWithdrawal?.source === FundsWithdrawal_Source.SPONSOR ? {
            $kind: "Sponsor",
            Sponsor: true
          } : {
            $kind: "Sender",
            Sender: true
          }
        }
      };
    default:
      throw new Error(`Unknown Input kind: ${JSON.stringify(input)}`);
  }
}
function grpcArgumentToTsArgument(arg) {
  switch (arg.kind) {
    case Argument_ArgumentKind.GAS:
      return {
        $kind: "GasCoin",
        GasCoin: true
      };
    case Argument_ArgumentKind.INPUT:
      return {
        $kind: "Input",
        Input: arg.input
      };
    case Argument_ArgumentKind.RESULT:
      if (arg.subresult != null) return {
        $kind: "NestedResult",
        NestedResult: [arg.result, arg.subresult]
      };
      return {
        $kind: "Result",
        Result: arg.result
      };
    default:
      throw new Error(`Unknown Argument kind: ${JSON.stringify(arg)}`);
  }
}
function grpcCommandToTsCommand(cmd) {
  const command = cmd.command;
  if (!command) throw new Error("Command is missing");
  switch (command.oneofKind) {
    case "moveCall":
      return {
        $kind: "MoveCall",
        MoveCall: {
          package: command.moveCall.package,
          module: command.moveCall.module,
          function: command.moveCall.function,
          typeArguments: command.moveCall.typeArguments ?? [],
          arguments: command.moveCall.arguments.map(grpcArgumentToTsArgument)
        }
      };
    case "transferObjects":
      return {
        $kind: "TransferObjects",
        TransferObjects: {
          objects: command.transferObjects.objects.map(grpcArgumentToTsArgument),
          address: grpcArgumentToTsArgument(command.transferObjects.address)
        }
      };
    case "splitCoins":
      return {
        $kind: "SplitCoins",
        SplitCoins: {
          coin: grpcArgumentToTsArgument(command.splitCoins.coin),
          amounts: command.splitCoins.amounts.map(grpcArgumentToTsArgument)
        }
      };
    case "mergeCoins":
      return {
        $kind: "MergeCoins",
        MergeCoins: {
          destination: grpcArgumentToTsArgument(command.mergeCoins.coin),
          sources: command.mergeCoins.coinsToMerge.map(grpcArgumentToTsArgument)
        }
      };
    case "publish":
      return {
        $kind: "Publish",
        Publish: {
          modules: command.publish.modules.map((m) => toBase6411(m)),
          dependencies: command.publish.dependencies ?? []
        }
      };
    case "makeMoveVector":
      return {
        $kind: "MakeMoveVec",
        MakeMoveVec: {
          type: command.makeMoveVector.elementType ?? null,
          elements: command.makeMoveVector.elements.map(grpcArgumentToTsArgument)
        }
      };
    case "upgrade":
      return {
        $kind: "Upgrade",
        Upgrade: {
          modules: command.upgrade.modules.map((m) => toBase6411(m)),
          dependencies: command.upgrade.dependencies ?? [],
          package: command.upgrade.package,
          ticket: grpcArgumentToTsArgument(command.upgrade.ticket)
        }
      };
    default:
      throw new Error(`Unknown Command kind: ${JSON.stringify(command)}`);
  }
}
function grpcTransactionToTransactionData(grpcTx) {
  const programmableTx = grpcTx.kind?.data;
  if (programmableTx?.oneofKind !== "programmableTransaction") throw new Error("Only programmable transactions are supported");
  const inputs = programmableTx.programmableTransaction.inputs.map(grpcInputToCallArg);
  const commands = programmableTx.programmableTransaction.commands.map(grpcCommandToTsCommand);
  let expiration = null;
  if (grpcTx.expiration) switch (grpcTx.expiration.kind) {
    case TransactionExpiration_TransactionExpirationKind.NONE:
      expiration = {
        $kind: "None",
        None: true
      };
      break;
    case TransactionExpiration_TransactionExpirationKind.EPOCH:
      expiration = {
        $kind: "Epoch",
        Epoch: grpcTx.expiration.epoch.toString()
      };
      break;
    case TransactionExpiration_TransactionExpirationKind.VALID_DURING:
      expiration = {
        $kind: "ValidDuring",
        ValidDuring: {
          minEpoch: grpcTx.expiration.minEpoch?.toString() ?? null,
          maxEpoch: grpcTx.expiration.epoch?.toString() ?? null,
          minTimestamp: null,
          maxTimestamp: null,
          chain: grpcTx.expiration.chain ?? "",
          nonce: grpcTx.expiration.nonce ?? 0
        }
      };
      break;
  }
  return {
    version: 2,
    sender: grpcTx.sender ?? null,
    expiration,
    gasData: {
      budget: grpcTx.gasPayment?.budget?.toString() ?? null,
      owner: grpcTx.gasPayment?.owner ?? null,
      payment: grpcTx.gasPayment?.objects?.map((obj) => ({
        objectId: obj.objectId,
        version: obj.version.toString(),
        digest: obj.digest
      })) ?? null,
      price: grpcTx.gasPayment?.price?.toString() ?? null
    },
    inputs,
    commands
  };
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/client/address-balance-transaction-expiration.mjs
async function setAddressBalanceTransactionExpirationFromSimulatedEpoch({ transactionData, client, epoch, originalTransactionData, isTransactionKindOnly, doGasSelection }) {
  if (isTransactionKindOnly || doGasSelection || originalTransactionData.expiration || originalTransactionData.gasData.payment?.length !== 0) return;
  if (transactionData.expiration && transactionData.expiration.$kind !== "None") return;
  const [{ chainIdentifier }, systemStateResult] = await Promise.all([client.core.getChainIdentifier(), epoch == null ? client.core.getCurrentSystemState() : null]);
  const currentEpoch = BigInt(epoch ?? systemStateResult.systemState.epoch);
  transactionData.expiration = {
    $kind: "ValidDuring",
    ValidDuring: {
      minEpoch: String(currentEpoch),
      maxEpoch: String(currentEpoch + 1n),
      minTimestamp: null,
      maxTimestamp: null,
      chain: chainIdentifier,
      nonce: Math.random() * 4294967296 >>> 0
    }
  };
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/execution_status.mjs
import { MessageType as MessageType13 } from "@protobuf-ts/runtime";
var ExecutionError_ExecutionErrorKind = /* @__PURE__ */ (function(ExecutionError_ExecutionErrorKind$1) {
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EXECUTION_ERROR_KIND_UNKNOWN"] = 0] = "EXECUTION_ERROR_KIND_UNKNOWN";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INSUFFICIENT_GAS"] = 1] = "INSUFFICIENT_GAS";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_GAS_OBJECT"] = 2] = "INVALID_GAS_OBJECT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVARIANT_VIOLATION"] = 3] = "INVARIANT_VIOLATION";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["FEATURE_NOT_YET_SUPPORTED"] = 4] = "FEATURE_NOT_YET_SUPPORTED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["OBJECT_TOO_BIG"] = 5] = "OBJECT_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PACKAGE_TOO_BIG"] = 6] = "PACKAGE_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["CIRCULAR_OBJECT_OWNERSHIP"] = 7] = "CIRCULAR_OBJECT_OWNERSHIP";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INSUFFICIENT_COIN_BALANCE"] = 8] = "INSUFFICIENT_COIN_BALANCE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["COIN_BALANCE_OVERFLOW"] = 9] = "COIN_BALANCE_OVERFLOW";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PUBLISH_ERROR_NON_ZERO_ADDRESS"] = 10] = "PUBLISH_ERROR_NON_ZERO_ADDRESS";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["SUI_MOVE_VERIFICATION_ERROR"] = 11] = "SUI_MOVE_VERIFICATION_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_PRIMITIVE_RUNTIME_ERROR"] = 12] = "MOVE_PRIMITIVE_RUNTIME_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_ABORT"] = 13] = "MOVE_ABORT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["VM_VERIFICATION_OR_DESERIALIZATION_ERROR"] = 14] = "VM_VERIFICATION_OR_DESERIALIZATION_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["VM_INVARIANT_VIOLATION"] = 15] = "VM_INVARIANT_VIOLATION";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["FUNCTION_NOT_FOUND"] = 16] = "FUNCTION_NOT_FOUND";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["ARITY_MISMATCH"] = 17] = "ARITY_MISMATCH";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["TYPE_ARITY_MISMATCH"] = 18] = "TYPE_ARITY_MISMATCH";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["NON_ENTRY_FUNCTION_INVOKED"] = 19] = "NON_ENTRY_FUNCTION_INVOKED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["COMMAND_ARGUMENT_ERROR"] = 20] = "COMMAND_ARGUMENT_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["TYPE_ARGUMENT_ERROR"] = 21] = "TYPE_ARGUMENT_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["UNUSED_VALUE_WITHOUT_DROP"] = 22] = "UNUSED_VALUE_WITHOUT_DROP";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_PUBLIC_FUNCTION_RETURN_TYPE"] = 23] = "INVALID_PUBLIC_FUNCTION_RETURN_TYPE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_TRANSFER_OBJECT"] = 24] = "INVALID_TRANSFER_OBJECT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EFFECTS_TOO_LARGE"] = 25] = "EFFECTS_TOO_LARGE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PUBLISH_UPGRADE_MISSING_DEPENDENCY"] = 26] = "PUBLISH_UPGRADE_MISSING_DEPENDENCY";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PUBLISH_UPGRADE_DEPENDENCY_DOWNGRADE"] = 27] = "PUBLISH_UPGRADE_DEPENDENCY_DOWNGRADE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PACKAGE_UPGRADE_ERROR"] = 28] = "PACKAGE_UPGRADE_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["WRITTEN_OBJECTS_TOO_LARGE"] = 29] = "WRITTEN_OBJECTS_TOO_LARGE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["CERTIFICATE_DENIED"] = 30] = "CERTIFICATE_DENIED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["SUI_MOVE_VERIFICATION_TIMEDOUT"] = 31] = "SUI_MOVE_VERIFICATION_TIMEDOUT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED"] = 32] = "CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INPUT_OBJECT_DELETED"] = 33] = "INPUT_OBJECT_DELETED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EXECUTION_CANCELED_DUE_TO_CONSENSUS_OBJECT_CONGESTION"] = 34] = "EXECUTION_CANCELED_DUE_TO_CONSENSUS_OBJECT_CONGESTION";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["ADDRESS_DENIED_FOR_COIN"] = 35] = "ADDRESS_DENIED_FOR_COIN";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["COIN_TYPE_GLOBAL_PAUSE"] = 36] = "COIN_TYPE_GLOBAL_PAUSE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EXECUTION_CANCELED_DUE_TO_RANDOMNESS_UNAVAILABLE"] = 37] = "EXECUTION_CANCELED_DUE_TO_RANDOMNESS_UNAVAILABLE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_VECTOR_ELEM_TOO_BIG"] = 38] = "MOVE_VECTOR_ELEM_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_RAW_VALUE_TOO_BIG"] = 39] = "MOVE_RAW_VALUE_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_LINKAGE"] = 40] = "INVALID_LINKAGE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INSUFFICIENT_FUNDS_FOR_WITHDRAW"] = 41] = "INSUFFICIENT_FUNDS_FOR_WITHDRAW";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["NON_EXCLUSIVE_WRITE_INPUT_OBJECT_MODIFIED"] = 42] = "NON_EXCLUSIVE_WRITE_INPUT_OBJECT_MODIFIED";
  return ExecutionError_ExecutionErrorKind$1;
})({});
var CommandArgumentError_CommandArgumentErrorKind = /* @__PURE__ */ (function(CommandArgumentError_CommandArgumentErrorKind$1) {
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["COMMAND_ARGUMENT_ERROR_KIND_UNKNOWN"] = 0] = "COMMAND_ARGUMENT_ERROR_KIND_UNKNOWN";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["TYPE_MISMATCH"] = 1] = "TYPE_MISMATCH";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_BCS_BYTES"] = 2] = "INVALID_BCS_BYTES";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_USAGE_OF_PURE_ARGUMENT"] = 3] = "INVALID_USAGE_OF_PURE_ARGUMENT";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_ARGUMENT_TO_PRIVATE_ENTRY_FUNCTION"] = 4] = "INVALID_ARGUMENT_TO_PRIVATE_ENTRY_FUNCTION";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INDEX_OUT_OF_BOUNDS"] = 5] = "INDEX_OUT_OF_BOUNDS";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["SECONDARY_INDEX_OUT_OF_BOUNDS"] = 6] = "SECONDARY_INDEX_OUT_OF_BOUNDS";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_RESULT_ARITY"] = 7] = "INVALID_RESULT_ARITY";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_GAS_COIN_USAGE"] = 8] = "INVALID_GAS_COIN_USAGE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_VALUE_USAGE"] = 9] = "INVALID_VALUE_USAGE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_OBJECT_BY_VALUE"] = 10] = "INVALID_OBJECT_BY_VALUE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_OBJECT_BY_MUT_REF"] = 11] = "INVALID_OBJECT_BY_MUT_REF";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED"] = 12] = "CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_ARGUMENT_ARITY"] = 13] = "INVALID_ARGUMENT_ARITY";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_TRANSFER_OBJECT"] = 14] = "INVALID_TRANSFER_OBJECT";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_MAKE_MOVE_VEC_NON_OBJECT_ARGUMENT"] = 15] = "INVALID_MAKE_MOVE_VEC_NON_OBJECT_ARGUMENT";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["ARGUMENT_WITHOUT_VALUE"] = 16] = "ARGUMENT_WITHOUT_VALUE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["CANNOT_MOVE_BORROWED_VALUE"] = 17] = "CANNOT_MOVE_BORROWED_VALUE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["CANNOT_WRITE_TO_EXTENDED_REFERENCE"] = 18] = "CANNOT_WRITE_TO_EXTENDED_REFERENCE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_REFERENCE_ARGUMENT"] = 19] = "INVALID_REFERENCE_ARGUMENT";
  return CommandArgumentError_CommandArgumentErrorKind$1;
})({});
var PackageUpgradeError_PackageUpgradeErrorKind = /* @__PURE__ */ (function(PackageUpgradeError_PackageUpgradeErrorKind$1) {
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["PACKAGE_UPGRADE_ERROR_KIND_UNKNOWN"] = 0] = "PACKAGE_UPGRADE_ERROR_KIND_UNKNOWN";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["UNABLE_TO_FETCH_PACKAGE"] = 1] = "UNABLE_TO_FETCH_PACKAGE";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["NOT_A_PACKAGE"] = 2] = "NOT_A_PACKAGE";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["INCOMPATIBLE_UPGRADE"] = 3] = "INCOMPATIBLE_UPGRADE";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["DIGEST_DOES_NOT_MATCH"] = 4] = "DIGEST_DOES_NOT_MATCH";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["UNKNOWN_UPGRADE_POLICY"] = 5] = "UNKNOWN_UPGRADE_POLICY";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["PACKAGE_ID_DOES_NOT_MATCH"] = 6] = "PACKAGE_ID_DOES_NOT_MATCH";
  return PackageUpgradeError_PackageUpgradeErrorKind$1;
})({});
var TypeArgumentError_TypeArgumentErrorKind = /* @__PURE__ */ (function(TypeArgumentError_TypeArgumentErrorKind$1) {
  TypeArgumentError_TypeArgumentErrorKind$1[TypeArgumentError_TypeArgumentErrorKind$1["TYPE_ARGUMENT_ERROR_KIND_UNKNOWN"] = 0] = "TYPE_ARGUMENT_ERROR_KIND_UNKNOWN";
  TypeArgumentError_TypeArgumentErrorKind$1[TypeArgumentError_TypeArgumentErrorKind$1["TYPE_NOT_FOUND"] = 1] = "TYPE_NOT_FOUND";
  TypeArgumentError_TypeArgumentErrorKind$1[TypeArgumentError_TypeArgumentErrorKind$1["CONSTRAINT_NOT_SATISFIED"] = 2] = "CONSTRAINT_NOT_SATISFIED";
  return TypeArgumentError_TypeArgumentErrorKind$1;
})({});
var ExecutionStatus$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.ExecutionStatus", [{
      no: 1,
      name: "success",
      kind: "scalar",
      opt: true,
      T: 8
    }, {
      no: 2,
      name: "error",
      kind: "message",
      T: () => ExecutionError
    }]);
  }
};
var ExecutionStatus2 = new ExecutionStatus$Type();
var ExecutionError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.ExecutionError", [
      {
        no: 1,
        name: "description",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "command",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.ExecutionError.ExecutionErrorKind", ExecutionError_ExecutionErrorKind]
      },
      {
        no: 4,
        name: "abort",
        kind: "message",
        oneof: "errorDetails",
        T: () => MoveAbort
      },
      {
        no: 5,
        name: "size_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => SizeError
      },
      {
        no: 6,
        name: "command_argument_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => CommandArgumentError2
      },
      {
        no: 7,
        name: "type_argument_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => TypeArgumentError2
      },
      {
        no: 8,
        name: "package_upgrade_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => PackageUpgradeError2
      },
      {
        no: 9,
        name: "index_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => IndexError
      },
      {
        no: 10,
        name: "object_id",
        kind: "scalar",
        oneof: "errorDetails",
        T: 9
      },
      {
        no: 11,
        name: "coin_deny_list_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => CoinDenyListError
      },
      {
        no: 12,
        name: "congested_objects",
        kind: "message",
        oneof: "errorDetails",
        T: () => CongestedObjects
      }
    ]);
  }
};
var ExecutionError = new ExecutionError$Type();
var MoveAbort$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.MoveAbort", [
      {
        no: 1,
        name: "abort_code",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "location",
        kind: "message",
        T: () => MoveLocation2
      },
      {
        no: 3,
        name: "clever_error",
        kind: "message",
        T: () => CleverError
      }
    ]);
  }
};
var MoveAbort = new MoveAbort$Type();
var MoveLocation$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.MoveLocation", [
      {
        no: 1,
        name: "package",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "function",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 4,
        name: "instruction",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 5,
        name: "function_name",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var MoveLocation2 = new MoveLocation$Type();
var CleverError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.CleverError", [
      {
        no: 1,
        name: "error_code",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "line_number",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "constant_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "constant_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "rendered",
        kind: "scalar",
        oneof: "value",
        T: 9
      },
      {
        no: 6,
        name: "raw",
        kind: "scalar",
        oneof: "value",
        T: 12
      }
    ]);
  }
};
var CleverError = new CleverError$Type();
var SizeError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.SizeError", [{
      no: 1,
      name: "size",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "max_size",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var SizeError = new SizeError$Type();
var IndexError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.IndexError", [{
      no: 1,
      name: "index",
      kind: "scalar",
      opt: true,
      T: 13
    }, {
      no: 2,
      name: "subresult",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var IndexError = new IndexError$Type();
var CoinDenyListError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.CoinDenyListError", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "coin_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var CoinDenyListError = new CoinDenyListError$Type();
var CongestedObjects$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.CongestedObjects", [{
      no: 1,
      name: "objects",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
};
var CongestedObjects = new CongestedObjects$Type();
var CommandArgumentError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.CommandArgumentError", [
      {
        no: 1,
        name: "argument",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 2,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.CommandArgumentError.CommandArgumentErrorKind", CommandArgumentError_CommandArgumentErrorKind]
      },
      {
        no: 3,
        name: "index_error",
        kind: "message",
        T: () => IndexError
      }
    ]);
  }
};
var CommandArgumentError2 = new CommandArgumentError$Type();
var PackageUpgradeError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.PackageUpgradeError", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.PackageUpgradeError.PackageUpgradeErrorKind", PackageUpgradeError_PackageUpgradeErrorKind]
      },
      {
        no: 2,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "policy",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 5,
        name: "ticket_id",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var PackageUpgradeError2 = new PackageUpgradeError$Type();
var TypeArgumentError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.TypeArgumentError", [{
      no: 1,
      name: "type_argument",
      kind: "scalar",
      opt: true,
      T: 13
    }, {
      no: 2,
      name: "kind",
      kind: "enum",
      opt: true,
      T: () => ["sui.rpc.v2.TypeArgumentError.TypeArgumentErrorKind", TypeArgumentError_TypeArgumentErrorKind]
    }]);
  }
};
var TypeArgumentError2 = new TypeArgumentError$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/gas_cost_summary.mjs
import { MessageType as MessageType14 } from "@protobuf-ts/runtime";
var GasCostSummary$Type = class extends MessageType14 {
  constructor() {
    super("sui.rpc.v2.GasCostSummary", [
      {
        no: 1,
        name: "computation_cost",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "storage_cost",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "storage_rebate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "non_refundable_storage_fee",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var GasCostSummary2 = new GasCostSummary$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/effects.mjs
import { MessageType as MessageType15 } from "@protobuf-ts/runtime";
var ChangedObject_InputObjectState = /* @__PURE__ */ (function(ChangedObject_InputObjectState$1) {
  ChangedObject_InputObjectState$1[ChangedObject_InputObjectState$1["UNKNOWN"] = 0] = "UNKNOWN";
  ChangedObject_InputObjectState$1[ChangedObject_InputObjectState$1["DOES_NOT_EXIST"] = 1] = "DOES_NOT_EXIST";
  ChangedObject_InputObjectState$1[ChangedObject_InputObjectState$1["EXISTS"] = 2] = "EXISTS";
  return ChangedObject_InputObjectState$1;
})({});
var ChangedObject_OutputObjectState = /* @__PURE__ */ (function(ChangedObject_OutputObjectState$1) {
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["UNKNOWN"] = 0] = "UNKNOWN";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["DOES_NOT_EXIST"] = 1] = "DOES_NOT_EXIST";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["OBJECT_WRITE"] = 2] = "OBJECT_WRITE";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["PACKAGE_WRITE"] = 3] = "PACKAGE_WRITE";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["ACCUMULATOR_WRITE"] = 4] = "ACCUMULATOR_WRITE";
  return ChangedObject_OutputObjectState$1;
})({});
var ChangedObject_IdOperation = /* @__PURE__ */ (function(ChangedObject_IdOperation$1) {
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["ID_OPERATION_UNKNOWN"] = 0] = "ID_OPERATION_UNKNOWN";
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["NONE"] = 1] = "NONE";
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["CREATED"] = 2] = "CREATED";
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["DELETED"] = 3] = "DELETED";
  return ChangedObject_IdOperation$1;
})({});
var AccumulatorWrite_AccumulatorOperation = /* @__PURE__ */ (function(AccumulatorWrite_AccumulatorOperation$1) {
  AccumulatorWrite_AccumulatorOperation$1[AccumulatorWrite_AccumulatorOperation$1["ACCUMULATOR_OPERATION_UNKNOWN"] = 0] = "ACCUMULATOR_OPERATION_UNKNOWN";
  AccumulatorWrite_AccumulatorOperation$1[AccumulatorWrite_AccumulatorOperation$1["MERGE"] = 1] = "MERGE";
  AccumulatorWrite_AccumulatorOperation$1[AccumulatorWrite_AccumulatorOperation$1["SPLIT"] = 2] = "SPLIT";
  return AccumulatorWrite_AccumulatorOperation$1;
})({});
var AccumulatorWrite_AccumulatorValue = /* @__PURE__ */ (function(AccumulatorWrite_AccumulatorValue$1) {
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["ACCUMULATOR_VALUE_UNKNOWN"] = 0] = "ACCUMULATOR_VALUE_UNKNOWN";
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["INTEGER"] = 1] = "INTEGER";
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["INTEGER_TUPLE"] = 2] = "INTEGER_TUPLE";
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["EVENT_DIGEST"] = 3] = "EVENT_DIGEST";
  return AccumulatorWrite_AccumulatorValue$1;
})({});
var UnchangedConsensusObject_UnchangedConsensusObjectKind = /* @__PURE__ */ (function(UnchangedConsensusObject_UnchangedConsensusObjectKind$1) {
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["UNCHANGED_CONSENSUS_OBJECT_KIND_UNKNOWN"] = 0] = "UNCHANGED_CONSENSUS_OBJECT_KIND_UNKNOWN";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["READ_ONLY_ROOT"] = 1] = "READ_ONLY_ROOT";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["MUTATE_CONSENSUS_STREAM_ENDED"] = 2] = "MUTATE_CONSENSUS_STREAM_ENDED";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["READ_CONSENSUS_STREAM_ENDED"] = 3] = "READ_CONSENSUS_STREAM_ENDED";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["CANCELED"] = 4] = "CANCELED";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["PER_EPOCH_CONFIG"] = 5] = "PER_EPOCH_CONFIG";
  return UnchangedConsensusObject_UnchangedConsensusObjectKind$1;
})({});
var TransactionEffects$Type = class extends MessageType15 {
  constructor() {
    super("sui.rpc.v2.TransactionEffects", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 5
      },
      {
        no: 4,
        name: "status",
        kind: "message",
        T: () => ExecutionStatus2
      },
      {
        no: 5,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "gas_used",
        kind: "message",
        T: () => GasCostSummary2
      },
      {
        no: 7,
        name: "transaction_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "gas_object",
        kind: "message",
        T: () => ChangedObject
      },
      {
        no: 9,
        name: "events_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 10,
        name: "dependencies",
        kind: "scalar",
        repeat: 2,
        T: 9
      },
      {
        no: 11,
        name: "lamport_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 12,
        name: "changed_objects",
        kind: "message",
        repeat: 2,
        T: () => ChangedObject
      },
      {
        no: 13,
        name: "unchanged_consensus_objects",
        kind: "message",
        repeat: 2,
        T: () => UnchangedConsensusObject
      },
      {
        no: 14,
        name: "auxiliary_data_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 15,
        name: "unchanged_loaded_runtime_objects",
        kind: "message",
        repeat: 2,
        T: () => ObjectReference
      }
    ]);
  }
};
var TransactionEffects2 = new TransactionEffects$Type();
var ChangedObject$Type = class extends MessageType15 {
  constructor() {
    super("sui.rpc.v2.ChangedObject", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "input_state",
        kind: "enum",
        opt: true,
        T: () => [
          "sui.rpc.v2.ChangedObject.InputObjectState",
          ChangedObject_InputObjectState,
          "INPUT_OBJECT_STATE_"
        ]
      },
      {
        no: 3,
        name: "input_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "input_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "input_owner",
        kind: "message",
        T: () => Owner2
      },
      {
        no: 6,
        name: "output_state",
        kind: "enum",
        opt: true,
        T: () => [
          "sui.rpc.v2.ChangedObject.OutputObjectState",
          ChangedObject_OutputObjectState,
          "OUTPUT_OBJECT_STATE_"
        ]
      },
      {
        no: 7,
        name: "output_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "output_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 9,
        name: "output_owner",
        kind: "message",
        T: () => Owner2
      },
      {
        no: 12,
        name: "accumulator_write",
        kind: "message",
        T: () => AccumulatorWrite
      },
      {
        no: 10,
        name: "id_operation",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.ChangedObject.IdOperation", ChangedObject_IdOperation]
      },
      {
        no: 11,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ChangedObject = new ChangedObject$Type();
var EventDigestEntry$Type = class extends MessageType15 {
  constructor() {
    super("sui.rpc.v2.EventDigestEntry", [{
      no: 1,
      name: "event_index",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EventDigestEntry = new EventDigestEntry$Type();
var AccumulatorWrite$Type = class extends MessageType15 {
  constructor() {
    super("sui.rpc.v2.AccumulatorWrite", [
      {
        no: 1,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "accumulator_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "operation",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.AccumulatorWrite.AccumulatorOperation", AccumulatorWrite_AccumulatorOperation]
      },
      {
        no: 4,
        name: "value_kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.AccumulatorWrite.AccumulatorValue", AccumulatorWrite_AccumulatorValue]
      },
      {
        no: 5,
        name: "integer_value",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "integer_tuple",
        kind: "scalar",
        repeat: 1,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "event_digest_value",
        kind: "message",
        repeat: 2,
        T: () => EventDigestEntry
      }
    ]);
  }
};
var AccumulatorWrite = new AccumulatorWrite$Type();
var UnchangedConsensusObject$Type = class extends MessageType15 {
  constructor() {
    super("sui.rpc.v2.UnchangedConsensusObject", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.UnchangedConsensusObject.UnchangedConsensusObjectKind", UnchangedConsensusObject_UnchangedConsensusObjectKind]
      },
      {
        no: 2,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var UnchangedConsensusObject = new UnchangedConsensusObject$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/client/query-filters.mjs
var DEFAULT_PAGE_SIZE = 50;
function resolvePagination(options) {
  if (options.after != null && options.before != null) throw new Error("Only one of `after` or `before` may be provided");
  const descending = options.order ? options.order === "descending" : options.before != null;
  if (options.after != null && descending) throw new Error("`after` can not be combined with descending queries");
  if (options.before != null && !descending) throw new Error("`before` can not be combined with ascending queries");
  return {
    descending,
    after: options.after ?? void 0,
    before: options.before ?? void 0,
    limit: options.limit ?? DEFAULT_PAGE_SIZE
  };
}
function validateTransactionQuery(filter, pagination) {
  if (filter?.$kind === "function" && (pagination.after != null || pagination.before != null) && (!filter.module || !filter.function)) throw new Error("Paginating transactions filtered by function requires a fully qualified `package::module::function`");
}
async function resolveTransactionFilter(mvr, filter, signal) {
  assertSinglePredicate(filter, ["sender", "function"], "transaction");
  if (filter.sender != null) return {
    $kind: "sender",
    sender: normalizeSuiAddress(filter.sender)
  };
  const [pkg, module, fn, ...rest] = filter.function.split("::");
  if (!pkg || rest.length > 0 || module === "" || fn === "") throw new Error(`Invalid function filter "${filter.function}": expected "package", "package::module", or "package::module::function"`);
  return {
    $kind: "function",
    package: normalizeSuiAddress((await mvr.resolvePackage({
      package: pkg,
      signal
    })).package),
    module,
    function: fn
  };
}
async function resolveEventFilter(mvr, filter, signal) {
  assertSinglePredicate(filter, [
    "sender",
    "emitModule",
    "eventType"
  ], "event");
  if (filter.sender != null) return {
    $kind: "sender",
    sender: normalizeSuiAddress(filter.sender)
  };
  if (filter.emitModule != null) {
    const [pkg, module, ...rest] = filter.emitModule.split("::");
    if (!pkg || !module || rest.length > 0) throw new Error(`Invalid emitModule filter "${filter.emitModule}": expected "package::module"`);
    return {
      $kind: "emitModule",
      package: normalizeSuiAddress((await mvr.resolvePackage({
        package: pkg,
        signal
      })).package),
      module
    };
  }
  const eventType = filter.eventType;
  const segments = eventType.split("::");
  if (segments.length === 2 && segments.every((segment) => segment !== "")) return {
    $kind: "eventTypeModule",
    package: normalizeSuiAddress((await mvr.resolvePackage({
      package: segments[0],
      signal
    })).package),
    module: segments[1]
  };
  if (segments.length < 3 || segments.some((segment) => segment === "")) throw new Error(`Invalid eventType filter "${eventType}": expected "package::module" or a fully qualified type name`);
  return {
    $kind: "eventType",
    eventType: (await mvr.resolveType({
      type: eventType,
      signal
    })).type
  };
}
function assertSinglePredicate(filter, predicates, kind) {
  const present = predicates.filter((predicate) => filter[predicate] != null);
  if (present.length !== 1) throw new Error(`A ${kind} filter must specify exactly one of ${predicates.join(", ")}${present.length ? ` (got ${present.join(", ")})` : ""}`);
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/balance_change.mjs
import { MessageType as MessageType16 } from "@protobuf-ts/runtime";
var BalanceChange$Type = class extends MessageType16 {
  constructor() {
    super("sui.rpc.v2.BalanceChange", [
      {
        no: 1,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "amount",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var BalanceChange = new BalanceChange$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/event.mjs
import { MessageType as MessageType17 } from "@protobuf-ts/runtime";
var TransactionEvents$Type = class extends MessageType17 {
  constructor() {
    super("sui.rpc.v2.TransactionEvents", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "events",
        kind: "message",
        repeat: 2,
        T: () => Event
      }
    ]);
  }
};
var TransactionEvents = new TransactionEvents$Type();
var Event$Type = class extends MessageType17 {
  constructor() {
    super("sui.rpc.v2.Event", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "sender",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "event_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "contents",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 6,
        name: "json",
        kind: "message",
        T: () => Value
      },
      {
        no: 7,
        name: "checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "transaction_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 9,
        name: "transaction_index",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 10,
        name: "event_index",
        kind: "scalar",
        opt: true,
        T: 13
      }
    ]);
  }
};
var Event = new Event$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature_scheme.mjs
var SignatureScheme = /* @__PURE__ */ (function(SignatureScheme$1) {
  SignatureScheme$1[SignatureScheme$1["ED25519"] = 0] = "ED25519";
  SignatureScheme$1[SignatureScheme$1["SECP256K1"] = 1] = "SECP256K1";
  SignatureScheme$1[SignatureScheme$1["SECP256R1"] = 2] = "SECP256R1";
  SignatureScheme$1[SignatureScheme$1["MULTISIG"] = 3] = "MULTISIG";
  SignatureScheme$1[SignatureScheme$1["BLS12381"] = 4] = "BLS12381";
  SignatureScheme$1[SignatureScheme$1["ZKLOGIN"] = 5] = "ZKLOGIN";
  SignatureScheme$1[SignatureScheme$1["PASSKEY"] = 6] = "PASSKEY";
  return SignatureScheme$1;
})({});

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature.mjs
import { MessageType as MessageType18 } from "@protobuf-ts/runtime";
var UserSignature$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.UserSignature", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 3,
        name: "simple",
        kind: "message",
        oneof: "signature",
        T: () => SimpleSignature
      },
      {
        no: 4,
        name: "multisig",
        kind: "message",
        oneof: "signature",
        T: () => MultisigAggregatedSignature
      },
      {
        no: 5,
        name: "zklogin",
        kind: "message",
        oneof: "signature",
        T: () => ZkLoginAuthenticator
      },
      {
        no: 6,
        name: "passkey",
        kind: "message",
        oneof: "signature",
        T: () => PasskeyAuthenticator2
      }
    ]);
  }
};
var UserSignature = new UserSignature$Type();
var SimpleSignature$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.SimpleSignature", [
      {
        no: 1,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 2,
        name: "signature",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "public_key",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var SimpleSignature = new SimpleSignature$Type();
var ZkLoginPublicIdentifier$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ZkLoginPublicIdentifier", [{
      no: 1,
      name: "iss",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "address_seed",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var ZkLoginPublicIdentifier3 = new ZkLoginPublicIdentifier$Type();
var MultisigMemberPublicKey$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.MultisigMemberPublicKey", [
      {
        no: 1,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 2,
        name: "public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "zklogin",
        kind: "message",
        T: () => ZkLoginPublicIdentifier3
      }
    ]);
  }
};
var MultisigMemberPublicKey = new MultisigMemberPublicKey$Type();
var MultisigMember$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.MultisigMember", [{
      no: 1,
      name: "public_key",
      kind: "message",
      T: () => MultisigMemberPublicKey
    }, {
      no: 2,
      name: "weight",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var MultisigMember = new MultisigMember$Type();
var MultisigCommittee$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.MultisigCommittee", [{
      no: 1,
      name: "members",
      kind: "message",
      repeat: 2,
      T: () => MultisigMember
    }, {
      no: 2,
      name: "threshold",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var MultisigCommittee = new MultisigCommittee$Type();
var MultisigAggregatedSignature$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.MultisigAggregatedSignature", [
      {
        no: 1,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => MultisigMemberSignature
      },
      {
        no: 2,
        name: "bitmap",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "legacy_bitmap",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "committee",
        kind: "message",
        T: () => MultisigCommittee
      }
    ]);
  }
};
var MultisigAggregatedSignature = new MultisigAggregatedSignature$Type();
var MultisigMemberSignature$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.MultisigMemberSignature", [
      {
        no: 1,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 2,
        name: "signature",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "zklogin",
        kind: "message",
        T: () => ZkLoginAuthenticator
      },
      {
        no: 4,
        name: "passkey",
        kind: "message",
        T: () => PasskeyAuthenticator2
      }
    ]);
  }
};
var MultisigMemberSignature = new MultisigMemberSignature$Type();
var ZkLoginAuthenticator$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ZkLoginAuthenticator", [
      {
        no: 1,
        name: "inputs",
        kind: "message",
        T: () => ZkLoginInputs
      },
      {
        no: 2,
        name: "max_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "signature",
        kind: "message",
        T: () => SimpleSignature
      },
      {
        no: 4,
        name: "public_identifier",
        kind: "message",
        T: () => ZkLoginPublicIdentifier3
      },
      {
        no: 5,
        name: "jwk_id",
        kind: "message",
        T: () => JwkId
      }
    ]);
  }
};
var ZkLoginAuthenticator = new ZkLoginAuthenticator$Type();
var ZkLoginInputs$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ZkLoginInputs", [
      {
        no: 1,
        name: "proof_points",
        kind: "message",
        T: () => ZkLoginProof
      },
      {
        no: 2,
        name: "iss_base64_details",
        kind: "message",
        T: () => ZkLoginClaim
      },
      {
        no: 3,
        name: "header_base64",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "address_seed",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ZkLoginInputs = new ZkLoginInputs$Type();
var ZkLoginProof$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ZkLoginProof", [
      {
        no: 1,
        name: "a",
        kind: "message",
        T: () => CircomG1
      },
      {
        no: 2,
        name: "b",
        kind: "message",
        T: () => CircomG2
      },
      {
        no: 3,
        name: "c",
        kind: "message",
        T: () => CircomG1
      }
    ]);
  }
};
var ZkLoginProof = new ZkLoginProof$Type();
var ZkLoginClaim$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ZkLoginClaim", [{
      no: 1,
      name: "value",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "index_mod_4",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var ZkLoginClaim = new ZkLoginClaim$Type();
var CircomG1$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.CircomG1", [
      {
        no: 1,
        name: "e0",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "e1",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "e2",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var CircomG1 = new CircomG1$Type();
var CircomG2$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.CircomG2", [
      {
        no: 1,
        name: "e00",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "e01",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "e10",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "e11",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "e20",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "e21",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var CircomG2 = new CircomG2$Type();
var PasskeyAuthenticator$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.PasskeyAuthenticator", [
      {
        no: 1,
        name: "authenticator_data",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 2,
        name: "client_data_json",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "signature",
        kind: "message",
        T: () => SimpleSignature
      }
    ]);
  }
};
var PasskeyAuthenticator2 = new PasskeyAuthenticator$Type();
var ValidatorCommittee$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ValidatorCommittee", [{
      no: 1,
      name: "epoch",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "members",
      kind: "message",
      repeat: 2,
      T: () => ValidatorCommitteeMember
    }]);
  }
};
var ValidatorCommittee = new ValidatorCommittee$Type();
var ValidatorCommitteeMember$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ValidatorCommitteeMember", [{
      no: 1,
      name: "public_key",
      kind: "scalar",
      opt: true,
      T: 12
    }, {
      no: 2,
      name: "weight",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var ValidatorCommitteeMember = new ValidatorCommitteeMember$Type();
var ValidatorAggregatedSignature$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ValidatorAggregatedSignature", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "signature",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "bitmap",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var ValidatorAggregatedSignature = new ValidatorAggregatedSignature$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/executed_transaction.mjs
import { MessageType as MessageType19 } from "@protobuf-ts/runtime";
var ExecutedTransaction$Type = class extends MessageType19 {
  constructor() {
    super("sui.rpc.v2.ExecutedTransaction", [
      {
        no: 1,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "transaction",
        kind: "message",
        T: () => Transaction
      },
      {
        no: 3,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => UserSignature
      },
      {
        no: 4,
        name: "effects",
        kind: "message",
        T: () => TransactionEffects2
      },
      {
        no: 5,
        name: "events",
        kind: "message",
        T: () => TransactionEvents
      },
      {
        no: 6,
        name: "checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 8,
        name: "balance_changes",
        kind: "message",
        repeat: 2,
        T: () => BalanceChange
      },
      {
        no: 9,
        name: "objects",
        kind: "message",
        T: () => ObjectSet
      },
      {
        no: 10,
        name: "transaction_index",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var ExecutedTransaction = new ExecutedTransaction$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/field_mask.mjs
import { MessageType as MessageType20, lowerCamelCase, typeofJsonValue as typeofJsonValue4 } from "@protobuf-ts/runtime";
var FieldMask$Type = class extends MessageType20 {
  constructor() {
    super("google.protobuf.FieldMask", [{
      no: 1,
      name: "paths",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
  /**
  * Encode `FieldMask` to JSON object.
  */
  internalJsonWrite(message, options) {
    const invalidFieldMaskJsonRegex = /[A-Z]|(_([.0-9_]|$))/g;
    return message.paths.map((p) => {
      if (invalidFieldMaskJsonRegex.test(p)) throw new Error('Unable to encode FieldMask to JSON. lowerCamelCase of path name "' + p + '" is irreversible.');
      return lowerCamelCase(p);
    }).join(",");
  }
  /**
  * Decode `FieldMask` from JSON object.
  */
  internalJsonRead(json2, options, target) {
    if (typeof json2 !== "string") throw new Error("Unable to parse FieldMask from JSON " + typeofJsonValue4(json2) + ". Expected string.");
    if (!target) target = this.create();
    if (json2 === "") return target;
    let camelToSnake = (str) => {
      if (str.includes("_")) throw new Error("Unable to parse FieldMask from JSON. Path names must be lowerCamelCase.");
      return str.replace(/[A-Z]/g, (letter) => "_" + letter.toLowerCase());
    };
    target.paths = json2.split(",").map(camelToSnake);
    return target;
  }
};
var FieldMask = new FieldMask$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/transaction_execution_service.mjs
import { MessageType as MessageType21 } from "@protobuf-ts/runtime";
import { ServiceType } from "@protobuf-ts/runtime-rpc";
var SimulateTransactionRequest_TransactionChecks = /* @__PURE__ */ (function(SimulateTransactionRequest_TransactionChecks$1) {
  SimulateTransactionRequest_TransactionChecks$1[SimulateTransactionRequest_TransactionChecks$1["ENABLED"] = 0] = "ENABLED";
  SimulateTransactionRequest_TransactionChecks$1[SimulateTransactionRequest_TransactionChecks$1["DISABLED"] = 1] = "DISABLED";
  return SimulateTransactionRequest_TransactionChecks$1;
})({});
var ExecuteTransactionRequest$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.ExecuteTransactionRequest", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => Transaction
      },
      {
        no: 2,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => UserSignature
      },
      {
        no: 3,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var ExecuteTransactionRequest = new ExecuteTransactionRequest$Type();
var ExecuteTransactionResponse$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.ExecuteTransactionResponse", [{
      no: 1,
      name: "transaction",
      kind: "message",
      T: () => ExecutedTransaction
    }]);
  }
};
var ExecuteTransactionResponse = new ExecuteTransactionResponse$Type();
var SimulateTransactionRequest$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.SimulateTransactionRequest", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => Transaction
      },
      {
        no: 2,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 3,
        name: "checks",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SimulateTransactionRequest.TransactionChecks", SimulateTransactionRequest_TransactionChecks]
      },
      {
        no: 4,
        name: "do_gas_selection",
        kind: "scalar",
        opt: true,
        T: 8
      }
    ]);
  }
};
var SimulateTransactionRequest = new SimulateTransactionRequest$Type();
var SimulateTransactionResponse$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.SimulateTransactionResponse", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => ExecutedTransaction
      },
      {
        no: 2,
        name: "command_outputs",
        kind: "message",
        repeat: 2,
        T: () => CommandResult
      },
      {
        no: 3,
        name: "suggested_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var SimulateTransactionResponse = new SimulateTransactionResponse$Type();
var CommandResult$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.CommandResult", [{
      no: 1,
      name: "return_values",
      kind: "message",
      repeat: 2,
      T: () => CommandOutput
    }, {
      no: 2,
      name: "mutated_by_ref",
      kind: "message",
      repeat: 2,
      T: () => CommandOutput
    }]);
  }
};
var CommandResult = new CommandResult$Type();
var CommandOutput$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.CommandOutput", [
      {
        no: 1,
        name: "argument",
        kind: "message",
        T: () => Argument2
      },
      {
        no: 2,
        name: "value",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 3,
        name: "json",
        kind: "message",
        T: () => Value
      }
    ]);
  }
};
var CommandOutput = new CommandOutput$Type();
var TransactionExecutionService = new ServiceType("sui.rpc.v2.TransactionExecutionService", [{
  name: "ExecuteTransaction",
  options: {},
  I: ExecuteTransactionRequest,
  O: ExecuteTransactionResponse
}, {
  name: "SimulateTransaction",
  options: {},
  I: SimulateTransactionRequest,
  O: SimulateTransactionResponse
}]);

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/query_options.mjs
import { MessageType as MessageType22 } from "@protobuf-ts/runtime";
var Ordering = /* @__PURE__ */ (function(Ordering$1) {
  Ordering$1[Ordering$1["ASCENDING"] = 0] = "ASCENDING";
  Ordering$1[Ordering$1["DESCENDING"] = 1] = "DESCENDING";
  return Ordering$1;
})({});
var QueryEndReason = /* @__PURE__ */ (function(QueryEndReason$1) {
  QueryEndReason$1[QueryEndReason$1["UNKNOWN"] = 0] = "UNKNOWN";
  QueryEndReason$1[QueryEndReason$1["ITEM_LIMIT"] = 1] = "ITEM_LIMIT";
  QueryEndReason$1[QueryEndReason$1["SCAN_LIMIT"] = 2] = "SCAN_LIMIT";
  QueryEndReason$1[QueryEndReason$1["CHECKPOINT_BOUND"] = 3] = "CHECKPOINT_BOUND";
  QueryEndReason$1[QueryEndReason$1["CURSOR_BOUND"] = 4] = "CURSOR_BOUND";
  QueryEndReason$1[QueryEndReason$1["LEDGER_TIP"] = 5] = "LEDGER_TIP";
  return QueryEndReason$1;
})({});
var QueryOptions$Type = class extends MessageType22 {
  constructor() {
    super("sui.rpc.v2.QueryOptions", [
      {
        no: 1,
        name: "limit",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 2,
        name: "after",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "before",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "ordering",
        kind: "enum",
        opt: true,
        T: () => [
          "sui.rpc.v2.Ordering",
          Ordering,
          "ORDERING_"
        ]
      }
    ]);
  }
};
var QueryOptions = new QueryOptions$Type();
var Watermark$Type = class extends MessageType22 {
  constructor() {
    super("sui.rpc.v2.Watermark", [{
      no: 1,
      name: "cursor",
      kind: "scalar",
      opt: true,
      T: 12
    }, {
      no: 2,
      name: "checkpoint",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var Watermark = new Watermark$Type();
var QueryEnd$Type = class extends MessageType22 {
  constructor() {
    super("sui.rpc.v2.QueryEnd", [{
      no: 1,
      name: "reason",
      kind: "enum",
      opt: true,
      T: () => [
        "sui.rpc.v2.QueryEndReason",
        QueryEndReason,
        "QUERY_END_REASON_"
      ]
    }]);
  }
};
var QueryEnd = new QueryEnd$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/filters.mjs
function toGrpcTransactionFilter(filter) {
  return { terms: [{ literals: [filter.$kind === "sender" ? {
    negated: false,
    predicate: {
      oneofKind: "sender",
      sender: { address: filter.sender }
    }
  } : {
    negated: false,
    predicate: {
      oneofKind: "moveCall",
      moveCall: { function: [
        filter.package,
        filter.module,
        filter.function
      ].filter(Boolean).join("::") }
    }
  }] }] };
}
function toGrpcEventFilter(filter) {
  return { terms: [{ literals: [filter.$kind === "sender" ? {
    negated: false,
    predicate: {
      oneofKind: "sender",
      sender: { address: filter.sender }
    }
  } : filter.$kind === "emitModule" ? {
    negated: false,
    predicate: {
      oneofKind: "emitModule",
      emitModule: { module: `${filter.package}::${filter.module}` }
    }
  } : {
    negated: false,
    predicate: {
      oneofKind: "eventType",
      eventType: { eventType: filter.$kind === "eventTypeModule" ? `${filter.package}::${filter.module}` : filter.eventType }
    }
  }] }] };
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/core.mjs
import { chunk as chunk2, fromBase64 as fromBase6413, toBase64 as toBase6412 } from "@mysten/utils";
import { GrpcStatusCode } from "@protobuf-ts/grpcweb-transport";
import { RpcError } from "@protobuf-ts/runtime-rpc";
function isNameServiceResolutionMiss(error) {
  if (!(error instanceof RpcError)) return false;
  if (error.code === GrpcStatusCode[GrpcStatusCode.NOT_FOUND]) return true;
  if (error.code !== GrpcStatusCode[GrpcStatusCode.RESOURCE_EXHAUSTED]) return false;
  try {
    return decodeURIComponent(error.message) === "name has expired";
  } catch {
    return false;
  }
}
var GrpcCoreClient = class extends CoreClient {
  #client;
  constructor({ client, ...options }) {
    super(options);
    this.#client = client;
  }
  async getObjects(options) {
    const batches = chunk2(options.objectIds, 50);
    const results = [];
    const paths = [
      "owner",
      "object_type",
      "digest",
      "version",
      "object_id"
    ];
    if (options.include?.content) paths.push("contents");
    if (options.include?.previousTransaction) paths.push("previous_transaction");
    if (options.include?.objectBcs) paths.push("bcs");
    if (options.include?.json) paths.push("json");
    if (options.include?.display) paths.push("display");
    for (const batch of batches) {
      const response = await this.#client.ledgerService.batchGetObjects({
        requests: batch.map((id) => ({ objectId: id })),
        readMask: { paths }
      }, { abort: options.signal });
      results.push(...response.response.objects.map((object, index) => {
        if (object.result.oneofKind === "error") {
          const error = object.result.error;
          if (error.code === GrpcStatusCode.NOT_FOUND) return new ObjectError("notExists", error.message, {
            cause: error,
            reason: "notFound",
            objectId: batch[index]
          });
          return new ObjectError(GrpcStatusCode[error.code] ?? "unknown", error.message, {
            cause: error,
            reason: "unknown",
            objectId: batch[index]
          });
        }
        if (object.result.oneofKind !== "object") return new ObjectError("unknown", "Unexpected result type", {
          reason: "unknown",
          objectId: batch[index]
        });
        const bcsContent = object.result.object.contents?.value ?? void 0;
        const objectBcs = object.result.object.bcs?.value ?? void 0;
        const objectType = object.result.object.objectType;
        const type = objectType && objectType.includes("::") ? normalizeStructTag(objectType) : objectType ?? "";
        const jsonContent = options.include?.json ? object.result.object.json ? Value.toJson(object.result.object.json) : null : void 0;
        const displayData = mapDisplayProto(options.include?.display, object.result.object.display);
        return {
          objectId: object.result.object.objectId,
          version: object.result.object.version?.toString(),
          digest: object.result.object.digest,
          content: bcsContent,
          owner: mapOwner(object.result.object.owner),
          type,
          previousTransaction: object.result.object.previousTransaction ?? void 0,
          objectBcs,
          json: jsonContent,
          display: displayData
        };
      }));
    }
    return { objects: results };
  }
  async listOwnedObjects(options) {
    const paths = [
      "owner",
      "object_type",
      "digest",
      "version",
      "object_id"
    ];
    if (options.include?.content) paths.push("contents");
    if (options.include?.previousTransaction) paths.push("previous_transaction");
    if (options.include?.objectBcs) paths.push("bcs");
    if (options.include?.json) paths.push("json");
    if (options.include?.display) paths.push("display");
    const response = await this.#client.stateService.listOwnedObjects({
      owner: options.owner,
      objectType: options.type ? (await this.mvr.resolveType({
        type: options.type,
        signal: options.signal
      })).type : void 0,
      pageToken: options.cursor ? fromBase6413(options.cursor) : void 0,
      pageSize: options.limit,
      readMask: { paths }
    }, { abort: options.signal });
    return {
      objects: response.response.objects.map((object) => ({
        objectId: object.objectId,
        version: object.version?.toString(),
        digest: object.digest,
        content: object.contents?.value,
        owner: mapOwner(object.owner),
        type: object.objectType,
        previousTransaction: object.previousTransaction ?? void 0,
        objectBcs: object.bcs?.value,
        json: options.include?.json ? object.json ? Value.toJson(object.json) : null : void 0,
        display: mapDisplayProto(options.include?.display, object.display)
      })),
      cursor: response.response.nextPageToken ? toBase6412(response.response.nextPageToken) : null,
      hasNextPage: response.response.nextPageToken !== void 0
    };
  }
  async listCoins(options) {
    const paths = [
      "owner",
      "object_type",
      "digest",
      "version",
      "object_id",
      "balance"
    ];
    const coinType = options.coinType ?? SUI_TYPE_ARG;
    const response = await this.#client.stateService.listOwnedObjects({
      owner: options.owner,
      objectType: `0x2::coin::Coin<${(await this.mvr.resolveType({
        type: coinType,
        signal: options.signal
      })).type}>`,
      pageToken: options.cursor ? fromBase6413(options.cursor) : void 0,
      pageSize: options.limit,
      readMask: { paths }
    }, { abort: options.signal });
    return {
      objects: response.response.objects.map((object) => ({
        objectId: object.objectId,
        version: object.version?.toString(),
        digest: object.digest,
        owner: mapOwner(object.owner),
        type: object.objectType,
        balance: object.balance?.toString()
      })),
      cursor: response.response.nextPageToken ? toBase6412(response.response.nextPageToken) : null,
      hasNextPage: response.response.nextPageToken !== void 0
    };
  }
  async getBalance(options) {
    const coinType = options.coinType ?? SUI_TYPE_ARG;
    const result = await this.#client.stateService.getBalance({
      owner: options.owner,
      coinType: (await this.mvr.resolveType({
        type: coinType,
        signal: options.signal
      })).type
    }, { abort: options.signal });
    return { balance: {
      balance: result.response.balance?.balance?.toString() ?? "0",
      coinType: result.response.balance?.coinType ?? coinType,
      coinBalance: result.response.balance?.coinBalance?.toString() ?? "0",
      addressBalance: result.response.balance?.addressBalance?.toString() ?? "0"
    } };
  }
  async getCoinMetadata(options) {
    const coinType = (await this.mvr.resolveType({
      type: options.coinType,
      signal: options.signal
    })).type;
    let response;
    try {
      ({ response } = await this.#client.stateService.getCoinInfo({ coinType }, { abort: options.signal }));
    } catch (error) {
      if (options.signal?.aborted) throw error;
      return { coinMetadata: null };
    }
    if (!response.metadata) return { coinMetadata: null };
    return { coinMetadata: {
      id: response.metadata.id ?? null,
      decimals: response.metadata.decimals ?? 0,
      name: response.metadata.name ?? "",
      symbol: response.metadata.symbol ?? "",
      description: response.metadata.description ?? "",
      iconUrl: response.metadata.iconUrl ?? null
    } };
  }
  async listBalances(options) {
    const result = await this.#client.stateService.listBalances({
      owner: options.owner,
      pageToken: options.cursor ? fromBase6413(options.cursor) : void 0,
      pageSize: options.limit
    }, { abort: options.signal });
    return {
      hasNextPage: !!result.response.nextPageToken,
      cursor: result.response.nextPageToken ? toBase6412(result.response.nextPageToken) : null,
      balances: result.response.balances.map((balance) => ({
        balance: balance.balance?.toString() ?? "0",
        coinType: balance.coinType,
        coinBalance: balance.coinBalance?.toString() ?? "0",
        addressBalance: balance.addressBalance?.toString() ?? "0"
      }))
    };
  }
  async getTransaction(options) {
    try {
      const { response } = await this.#client.ledgerService.getTransaction({
        digest: options.digest,
        readMask: { paths: transactionReadMaskPaths(options.include) }
      }, { abort: options.signal });
      if (!response.transaction) throw new TransactionError("notFound", options.digest);
      return withProtoJson(parseGrpcTransactionResponse(response.transaction, { include: options.include }), options.include, () => ExecutedTransaction.toJson(response.transaction));
    } catch (error) {
      if (error instanceof RpcError && error.code === GrpcStatusCode[GrpcStatusCode.NOT_FOUND]) throw new TransactionError("notFound", options.digest, { cause: error });
      throw error;
    }
  }
  async executeTransaction(options) {
    const { response } = await this.#client.transactionExecutionService.executeTransaction({
      transaction: { bcs: { value: options.transaction } },
      signatures: options.signatures.map((signature) => ({
        bcs: { value: fromBase6413(signature) },
        signature: { oneofKind: void 0 }
      })),
      readMask: { paths: transactionReadMaskPaths(options.include) }
    }, { abort: options.signal });
    return withProtoJson(parseGrpcTransactionResponse(response.transaction, { include: options.include }), options.include, () => ExecutedTransaction.toJson(response.transaction));
  }
  async simulateTransaction(options) {
    const paths = transactionReadMaskPaths(options.include, "transaction.");
    if (options.include?.commandResults) paths.push("command_outputs");
    if (!(options.transaction instanceof Uint8Array)) await options.transaction.prepareForSerialization({ client: this });
    const doGasSelection = options.doGasSelection ?? (options.transaction instanceof Uint8Array ? transactionBytesHaveEmptyGasPayment(options.transaction) : options.transaction.getData().gasData.payment?.length === 0);
    const { response } = await this.#client.transactionExecutionService.simulateTransaction({
      transaction: options.transaction instanceof Uint8Array ? { bcs: { value: options.transaction } } : transactionToGrpcTransaction(options.transaction),
      readMask: { paths },
      doGasSelection,
      checks: options.checksEnabled === false ? SimulateTransactionRequest_TransactionChecks.DISABLED : SimulateTransactionRequest_TransactionChecks.ENABLED
    }, { abort: options.signal });
    return withProtoJson(parseGrpcSimulateTransactionResponse(response, { include: options.include }), options.include, () => SimulateTransactionResponse.toJson(response));
  }
  async getReferenceGasPrice(options) {
    return { referenceGasPrice: (await this.#client.ledgerService.getEpoch({ readMask: { paths: ["reference_gas_price"] } }, { abort: options?.signal })).response.epoch?.referenceGasPrice?.toString() ?? "" };
  }
  async getProtocolConfig(options) {
    const protocolConfig = (await this.#client.ledgerService.getEpoch({ readMask: { paths: ["protocol_config"] } }, { abort: options?.signal })).response.epoch?.protocolConfig;
    if (!protocolConfig) throw new Error("Protocol config not found in response");
    const featureFlags = { ...protocolConfig.featureFlags };
    const attributes = {};
    if (protocolConfig.attributes) for (const [key, value] of Object.entries(protocolConfig.attributes)) attributes[key] = value ?? null;
    return { protocolConfig: {
      protocolVersion: protocolConfig.protocolVersion?.toString() ?? null,
      featureFlags,
      attributes
    } };
  }
  async getCurrentSystemState(options) {
    const epoch = (await this.#client.ledgerService.getEpoch({ readMask: { paths: [
      "system_state.version",
      "system_state.epoch",
      "system_state.protocol_version",
      "system_state.reference_gas_price",
      "system_state.epoch_start_timestamp_ms",
      "system_state.safe_mode",
      "system_state.safe_mode_storage_rewards",
      "system_state.safe_mode_computation_rewards",
      "system_state.safe_mode_storage_rebates",
      "system_state.safe_mode_non_refundable_storage_fee",
      "system_state.parameters",
      "system_state.storage_fund",
      "system_state.stake_subsidy"
    ] } }, { abort: options?.signal })).response.epoch;
    const systemState = epoch?.systemState;
    if (!systemState) throw new Error("System state not found in response");
    const startMs = epoch?.start?.seconds ? Number(epoch.start.seconds) * 1e3 + Math.floor((epoch.start.nanos || 0) / 1e6) : systemState.epochStartTimestampMs ? Number(systemState.epochStartTimestampMs) : null;
    return { systemState: {
      systemStateVersion: systemState.version?.toString() ?? null,
      epoch: systemState.epoch?.toString() ?? null,
      protocolVersion: systemState.protocolVersion?.toString() ?? null,
      referenceGasPrice: systemState.referenceGasPrice?.toString() ?? null,
      epochStartTimestampMs: startMs.toString(),
      safeMode: systemState.safeMode ?? false,
      safeModeStorageRewards: systemState.safeModeStorageRewards?.toString() ?? null,
      safeModeComputationRewards: systemState.safeModeComputationRewards?.toString() ?? null,
      safeModeStorageRebates: systemState.safeModeStorageRebates?.toString() ?? null,
      safeModeNonRefundableStorageFee: systemState.safeModeNonRefundableStorageFee?.toString() ?? null,
      parameters: {
        epochDurationMs: systemState.parameters?.epochDurationMs?.toString() ?? null,
        stakeSubsidyStartEpoch: systemState.parameters?.stakeSubsidyStartEpoch?.toString() ?? null,
        maxValidatorCount: systemState.parameters?.maxValidatorCount?.toString() ?? null,
        minValidatorJoiningStake: systemState.parameters?.minValidatorJoiningStake?.toString() ?? null,
        validatorLowStakeThreshold: systemState.parameters?.validatorLowStakeThreshold?.toString() ?? null,
        validatorLowStakeGracePeriod: systemState.parameters?.validatorLowStakeGracePeriod?.toString() ?? null
      },
      storageFund: {
        totalObjectStorageRebates: systemState.storageFund?.totalObjectStorageRebates?.toString() ?? null,
        nonRefundableBalance: systemState.storageFund?.nonRefundableBalance?.toString() ?? null
      },
      stakeSubsidy: {
        balance: systemState.stakeSubsidy?.balance?.toString() ?? null,
        distributionCounter: systemState.stakeSubsidy?.distributionCounter?.toString() ?? null,
        currentDistributionAmount: systemState.stakeSubsidy?.currentDistributionAmount?.toString() ?? null,
        stakeSubsidyPeriodLength: systemState.stakeSubsidy?.stakeSubsidyPeriodLength?.toString() ?? null,
        stakeSubsidyDecreaseRate: systemState.stakeSubsidy?.stakeSubsidyDecreaseRate ?? null
      }
    } };
  }
  async listDynamicFields(options) {
    return this.#client.listDynamicFields(options);
  }
  async listTransactions(options) {
    const paths = transactionReadMaskPaths(options.include);
    const filter = options.filter ? await resolveTransactionFilter(this.mvr, options.filter, options.signal) : void 0;
    const pagination = resolvePagination(options);
    validateTransactionQuery(filter, pagination);
    const call = this.#client.ledgerService.listTransactions({
      readMask: { paths },
      filter: filter && toGrpcTransactionFilter(filter),
      options: toGrpcQueryOptions(pagination, pagination.limit + 1)
    }, { abort: options.signal });
    const transactions = [];
    let startCursor = null;
    let endCursor = null;
    let frontier = null;
    let end;
    let sawLookaheadItem = false;
    for await (const frame of call.responses) {
      if (frame.watermark?.cursor) frontier = toBase6412(frame.watermark.cursor);
      if (frame.transaction) if (transactions.length >= pagination.limit) sawLookaheadItem = true;
      else {
        startCursor ??= frontier;
        endCursor = frontier;
        transactions.push(parseGrpcTransactionResponse(frame.transaction, { include: options.include }));
      }
      if (frame.end) end = frame.end;
    }
    const hasNextPage = sawLookaheadItem || end?.reason === QueryEndReason.SCAN_LIMIT || end?.reason === QueryEndReason.ITEM_LIMIT;
    return {
      transactions,
      hasNextPage,
      startCursor,
      endCursor: sawLookaheadItem ? endCursor : hasNextPage ? frontier ?? endCursor : endCursor
    };
  }
  async listEvents(options) {
    const pagination = resolvePagination(options);
    const call = this.#client.ledgerService.listEvents({
      readMask: { paths: [
        "package_id",
        "module",
        "sender",
        "event_type",
        "contents",
        "json",
        "checkpoint",
        "transaction_digest",
        "event_index"
      ] },
      filter: options.filter ? toGrpcEventFilter(await resolveEventFilter(this.mvr, options.filter, options.signal)) : void 0,
      options: toGrpcQueryOptions(pagination, pagination.limit + 1)
    }, { abort: options.signal });
    const events = [];
    let startCursor = null;
    let endCursor = null;
    let frontier = null;
    let end;
    let sawLookaheadItem = false;
    for await (const frame of call.responses) {
      if (frame.watermark?.cursor) frontier = toBase6412(frame.watermark.cursor);
      if (frame.event) if (events.length >= pagination.limit) sawLookaheadItem = true;
      else {
        startCursor ??= frontier;
        endCursor = frontier;
        const event = frame.event;
        events.push({
          packageId: normalizeSuiAddress(event.packageId),
          module: event.module,
          sender: normalizeSuiAddress(event.sender),
          eventType: normalizeStructTag(event.eventType),
          bcs: event.contents?.value ?? new Uint8Array(),
          json: event.json ? Value.toJson(event.json) : null,
          checkpoint: event.checkpoint?.toString() ?? null,
          transactionDigest: event.transactionDigest,
          eventIndex: event.eventIndex
        });
      }
      if (frame.end) end = frame.end;
    }
    const hasNextPage = sawLookaheadItem || end?.reason === QueryEndReason.SCAN_LIMIT || end?.reason === QueryEndReason.ITEM_LIMIT;
    return {
      events,
      hasNextPage,
      startCursor,
      endCursor: sawLookaheadItem ? endCursor : hasNextPage ? frontier ?? endCursor : endCursor
    };
  }
  async verifyZkLoginSignature(options) {
    const messageBytes = fromBase6413(options.bytes);
    const messageValue = options.intentScope === "PersonalMessage" ? suiBcs.byteVector().serialize(messageBytes).toBytes() : messageBytes;
    const { response } = await this.#client.signatureVerificationService.verifySignature({
      message: {
        name: options.intentScope,
        value: messageValue
      },
      signature: {
        bcs: { value: fromBase6413(options.signature) },
        signature: { oneofKind: void 0 }
      },
      address: options.address,
      jwks: []
    }, { abort: options.signal });
    return {
      success: response.isValid ?? false,
      errors: response.reason ? [response.reason] : []
    };
  }
  async defaultNameServiceName(options) {
    return { data: { name: (await this.#client.nameService.reverseLookupName({ address: options.address }, { abort: options.signal })).response.record?.name ?? null } };
  }
  async resolveNameServiceAddress(options) {
    try {
      const { response } = await this.#client.nameService.lookupName({ name: options.name }, { abort: options.signal });
      return { address: response.record?.targetAddress ?? null };
    } catch (error) {
      if (isNameServiceResolutionMiss(error)) return { address: null };
      throw error;
    }
  }
  async getMoveFunction(options) {
    const resolvedPackageId = (await this.mvr.resolvePackage({
      package: options.packageId,
      signal: options.signal
    })).package;
    const { response } = await this.#client.movePackageService.getFunction({
      packageId: resolvedPackageId,
      moduleName: options.moduleName,
      name: options.name
    }, { abort: options.signal });
    let visibility = "unknown";
    switch (response.function?.visibility) {
      case FunctionDescriptor_Visibility.PUBLIC:
        visibility = "public";
        break;
      case FunctionDescriptor_Visibility.PRIVATE:
        visibility = "private";
        break;
      case FunctionDescriptor_Visibility.FRIEND:
        visibility = "friend";
        break;
    }
    return { function: {
      packageId: normalizeSuiAddress(resolvedPackageId),
      moduleName: options.moduleName,
      name: response.function?.name,
      visibility,
      isEntry: response.function?.isEntry ?? false,
      typeParameters: response.function?.typeParameters?.map(({ constraints }) => ({
        isPhantom: false,
        constraints: constraints.map((constraint) => {
          switch (constraint) {
            case Ability.COPY:
              return "copy";
            case Ability.DROP:
              return "drop";
            case Ability.STORE:
              return "store";
            case Ability.KEY:
              return "key";
            default:
              return "unknown";
          }
        }) ?? []
      })) ?? [],
      parameters: response.function?.parameters?.map((param) => parseNormalizedSuiMoveType(param)) ?? [],
      returns: response.function?.returns?.map((ret) => parseNormalizedSuiMoveType(ret)) ?? []
    } };
  }
  async getChainIdentifier(options) {
    return raceSignal(Promise.resolve(this.cache.read(["chainIdentifier"], async () => {
      const { response } = await this.#client.ledgerService.getServiceInfo({});
      if (!response.chainId) throw new Error("Chain identifier not found in service info");
      return { chainIdentifier: response.chainId };
    })), options?.signal);
  }
  resolveTransactionPlugin() {
    const client = this.#client;
    return async function resolveTransactionData(transactionData, options, next) {
      const snapshot = transactionData.snapshot();
      if (!snapshot.sender) snapshot.sender = "0x0000000000000000000000000000000000000000000000000000000000000000";
      const grpcTransaction = transactionDataToGrpcTransaction(snapshot);
      const doGasSelection = !options.onlyTransactionKind && (snapshot.gasData.budget == null || snapshot.gasData.payment == null);
      let response;
      try {
        response = (await client.transactionExecutionService.simulateTransaction({
          transaction: grpcTransaction,
          doGasSelection,
          checks: options.onlyTransactionKind ? SimulateTransactionRequest_TransactionChecks.DISABLED : SimulateTransactionRequest_TransactionChecks.ENABLED,
          readMask: { paths: [
            "transaction.transaction.sender",
            "transaction.transaction.gas_payment",
            "transaction.transaction.expiration",
            "transaction.transaction.kind",
            "transaction.effects.status",
            "transaction.effects.epoch"
          ] }
        })).response;
      } catch (error) {
        if (error instanceof Error && error.message) throw new SimulationError(decodeURIComponent(error.message), { cause: error });
        throw error;
      }
      if (!options.onlyTransactionKind && response.transaction?.effects?.status && !response.transaction.effects.status.success) {
        const executionError = response.transaction.effects.status.error ? parseGrpcExecutionError(response.transaction.effects.status.error) : void 0;
        throw new SimulationError(`Transaction resolution failed: ${executionError?.message ?? "Transaction failed"}`, { executionError });
      }
      if (!response.transaction?.transaction) throw new Error("simulateTransaction did not return resolved transaction data");
      applyGrpcResolvedTransaction(transactionData, response.transaction.transaction, options);
      await setAddressBalanceTransactionExpirationFromSimulatedEpoch({
        transactionData,
        client,
        epoch: response.transaction.effects?.epoch,
        originalTransactionData: snapshot,
        isTransactionKindOnly: !!options.onlyTransactionKind,
        doGasSelection
      });
      return await next();
    };
  }
};
function toGrpcQueryOptions(pagination, limit) {
  return {
    limit,
    ordering: pagination.descending ? Ordering.DESCENDING : Ordering.ASCENDING,
    after: pagination.after ? fromBase6413(pagination.after) : void 0,
    before: pagination.before ? fromBase6413(pagination.before) : void 0
  };
}
function transactionReadMaskPaths(include, prefix = "") {
  const paths = [
    "digest",
    "transaction.digest",
    "signatures",
    "effects.status"
  ];
  if (include?.transaction) paths.push("transaction.sender", "transaction.gas_payment", "transaction.expiration", "transaction.kind");
  if (include?.bcs) paths.push("transaction.bcs");
  if (include?.balanceChanges) paths.push("balance_changes");
  if (include?.effects) paths.push("effects");
  if (include?.events) paths.push("events");
  if (include?.objectTypes) {
    paths.push("effects.changed_objects.object_type");
    paths.push("effects.changed_objects.object_id");
  }
  return prefix ? paths.map((path) => prefix + path) : paths;
}
function withProtoJson(result, include, getProtoJson) {
  if (!include?.protoJson) return result;
  return {
    ...result,
    protoJson: getProtoJson()
  };
}
function mapDisplayProto(include, display) {
  if (!include) return void 0;
  if (display === void 0) return null;
  return {
    output: display.output !== void 0 ? Value.toJson(display.output) : null,
    errors: display.errors !== void 0 ? Value.toJson(display.errors) : null
  };
}
function mapOwner(owner) {
  if (!owner) return null;
  if (owner.kind === Owner_OwnerKind.IMMUTABLE) return {
    $kind: "Immutable",
    Immutable: true
  };
  if (owner.kind === Owner_OwnerKind.ADDRESS) return {
    AddressOwner: owner.address,
    $kind: "AddressOwner"
  };
  if (owner.kind === Owner_OwnerKind.OBJECT) return {
    $kind: "ObjectOwner",
    ObjectOwner: owner.address
  };
  if (owner.kind === Owner_OwnerKind.SHARED) return {
    $kind: "Shared",
    Shared: { initialSharedVersion: owner.version?.toString() }
  };
  if (owner.kind === Owner_OwnerKind.CONSENSUS_ADDRESS) return {
    $kind: "ConsensusAddressOwner",
    ConsensusAddressOwner: {
      startVersion: owner.version?.toString(),
      owner: owner.address
    }
  };
  throw new Error(`Unknown owner kind ${JSON.stringify(owner, (_k, v) => typeof v === "bigint" ? v.toString() : v)}`);
}
function parseGrpcExecutionError(error) {
  const message = error.description ?? "Unknown error";
  const command = error.command != null ? Number(error.command) : void 0;
  const details = error.errorDetails;
  switch (details?.oneofKind) {
    case "abort": {
      const abort = details.abort;
      const cleverError = abort.cleverError;
      return {
        $kind: "MoveAbort",
        message: formatMoveAbortMessage({
          command,
          location: abort.location,
          abortCode: String(abort.abortCode ?? 0n),
          cleverError: cleverError ? {
            lineNumber: cleverError.lineNumber != null ? Number(cleverError.lineNumber) : void 0,
            constantName: cleverError.constantName,
            value: cleverError.value?.oneofKind === "rendered" ? cleverError.value.rendered : void 0
          } : void 0
        }),
        command,
        MoveAbort: parseMoveAbort(abort)
      };
    }
    case "sizeError":
      return {
        $kind: "SizeError",
        message,
        command,
        SizeError: {
          name: mapErrorName(error.kind),
          size: Number(details.sizeError.size ?? 0n),
          maxSize: Number(details.sizeError.maxSize ?? 0n)
        }
      };
    case "commandArgumentError":
      return {
        $kind: "CommandArgumentError",
        message,
        command,
        CommandArgumentError: {
          argument: details.commandArgumentError.argument ?? 0,
          name: mapErrorName(details.commandArgumentError.kind)
        }
      };
    case "typeArgumentError":
      return {
        $kind: "TypeArgumentError",
        message,
        command,
        TypeArgumentError: {
          typeArgument: details.typeArgumentError.typeArgument ?? 0,
          name: mapErrorName(details.typeArgumentError.kind)
        }
      };
    case "packageUpgradeError":
      return {
        $kind: "PackageUpgradeError",
        message,
        command,
        PackageUpgradeError: {
          name: mapErrorName(details.packageUpgradeError.kind),
          packageId: details.packageUpgradeError.packageId,
          digest: details.packageUpgradeError.digest
        }
      };
    case "indexError":
      return {
        $kind: "IndexError",
        message,
        command,
        IndexError: {
          index: details.indexError.index,
          subresult: details.indexError.subresult
        }
      };
    case "coinDenyListError":
      return {
        $kind: "CoinDenyListError",
        message,
        command,
        CoinDenyListError: {
          name: mapErrorName(error.kind),
          coinType: details.coinDenyListError.coinType,
          address: details.coinDenyListError.address
        }
      };
    case "congestedObjects":
      return {
        $kind: "CongestedObjects",
        message,
        command,
        CongestedObjects: {
          name: mapErrorName(error.kind),
          objects: details.congestedObjects.objects
        }
      };
    case "objectId":
      return {
        $kind: "ObjectIdError",
        message,
        command,
        ObjectIdError: {
          name: mapErrorName(error.kind),
          objectId: details.objectId
        }
      };
    default:
      return {
        $kind: "Unknown",
        message,
        command,
        Unknown: null
      };
  }
}
function parseMoveAbort(abort) {
  return {
    abortCode: String(abort.abortCode ?? 0n),
    location: { ...abort.location },
    cleverError: abort.cleverError ? {
      errorCode: abort.cleverError.errorCode != null ? Number(abort.cleverError.errorCode) : void 0,
      lineNumber: abort.cleverError.lineNumber != null ? Number(abort.cleverError.lineNumber) : void 0,
      constantName: abort.cleverError.constantName,
      constantType: abort.cleverError.constantType,
      value: abort.cleverError.value?.oneofKind === "rendered" ? abort.cleverError.value.rendered : abort.cleverError.value?.oneofKind === "raw" ? toBase6412(abort.cleverError.value.raw) : void 0
    } : void 0
  };
}
function mapErrorName(kind) {
  if (kind == null) return "Unknown";
  const name = CommandArgumentError_CommandArgumentErrorKind[kind];
  if (!name || name.endsWith("_UNKNOWN")) return "Unknown";
  return name.split("_").map((word) => word.charAt(0) + word.slice(1).toLowerCase()).join("");
}
function mapIdOperation(operation) {
  if (operation == null) return null;
  switch (operation) {
    case ChangedObject_IdOperation.CREATED:
      return "Created";
    case ChangedObject_IdOperation.DELETED:
      return "Deleted";
    case ChangedObject_IdOperation.NONE:
    case ChangedObject_IdOperation.ID_OPERATION_UNKNOWN:
      return "None";
    default:
      return "Unknown";
  }
}
function mapInputObjectState(state) {
  if (state == null) return null;
  switch (state) {
    case ChangedObject_InputObjectState.EXISTS:
      return "Exists";
    case ChangedObject_InputObjectState.DOES_NOT_EXIST:
      return "DoesNotExist";
    case ChangedObject_InputObjectState.UNKNOWN:
      return "Unknown";
    default:
      return "Unknown";
  }
}
function mapOutputObjectState(state) {
  if (state == null) return null;
  switch (state) {
    case ChangedObject_OutputObjectState.OBJECT_WRITE:
      return "ObjectWrite";
    case ChangedObject_OutputObjectState.PACKAGE_WRITE:
      return "PackageWrite";
    case ChangedObject_OutputObjectState.DOES_NOT_EXIST:
      return "DoesNotExist";
    case ChangedObject_OutputObjectState.ACCUMULATOR_WRITE:
      return "AccumulatorWriteV1";
    case ChangedObject_OutputObjectState.UNKNOWN:
      return "Unknown";
    default:
      return "Unknown";
  }
}
function mapUnchangedConsensusObjectKind(kind) {
  if (kind == null) return null;
  switch (kind) {
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.UNCHANGED_CONSENSUS_OBJECT_KIND_UNKNOWN:
      return "Unknown";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.READ_ONLY_ROOT:
      return "ReadOnlyRoot";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.MUTATE_CONSENSUS_STREAM_ENDED:
      return "MutateConsensusStreamEnded";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.READ_CONSENSUS_STREAM_ENDED:
      return "ReadConsensusStreamEnded";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.CANCELED:
      return "Cancelled";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.PER_EPOCH_CONFIG:
      return "PerEpochConfig";
    default:
      return "Unknown";
  }
}
function parseTransactionEffects({ effects }) {
  if (!effects) return null;
  const changedObjects = effects.changedObjects.map((change) => {
    return {
      objectId: change.objectId,
      inputState: mapInputObjectState(change.inputState),
      inputVersion: change.inputVersion?.toString() ?? null,
      inputDigest: change.inputDigest ?? null,
      inputOwner: mapOwner(change.inputOwner),
      outputState: mapOutputObjectState(change.outputState),
      outputVersion: change.outputVersion?.toString() ?? null,
      outputDigest: change.outputDigest ?? null,
      outputOwner: mapOwner(change.outputOwner),
      idOperation: mapIdOperation(change.idOperation)
    };
  });
  return {
    bcs: effects.bcs?.value,
    version: 2,
    status: effects.status?.success ? {
      success: true,
      error: null
    } : {
      success: false,
      error: parseGrpcExecutionError(effects.status.error)
    },
    gasUsed: {
      computationCost: effects.gasUsed?.computationCost?.toString(),
      storageCost: effects.gasUsed?.storageCost?.toString(),
      storageRebate: effects.gasUsed?.storageRebate?.toString(),
      nonRefundableStorageFee: effects.gasUsed?.nonRefundableStorageFee?.toString()
    },
    transactionDigest: effects.transactionDigest,
    gasObject: effects.gasObject ? {
      objectId: effects.gasObject.objectId,
      inputState: mapInputObjectState(effects.gasObject.inputState),
      inputVersion: effects.gasObject.inputVersion?.toString() ?? null,
      inputDigest: effects.gasObject.inputDigest ?? null,
      inputOwner: mapOwner(effects.gasObject.inputOwner),
      outputState: mapOutputObjectState(effects.gasObject.outputState),
      outputVersion: effects.gasObject.outputVersion?.toString() ?? null,
      outputDigest: effects.gasObject.outputDigest ?? null,
      outputOwner: mapOwner(effects.gasObject.outputOwner),
      idOperation: mapIdOperation(effects.gasObject.idOperation)
    } : null,
    eventsDigest: effects.eventsDigest ?? null,
    dependencies: effects.dependencies,
    lamportVersion: effects.lamportVersion?.toString() ?? null,
    changedObjects,
    unchangedConsensusObjects: effects.unchangedConsensusObjects.map((object) => {
      return {
        kind: mapUnchangedConsensusObjectKind(object.kind),
        objectId: object.objectId,
        version: object.version?.toString() ?? null,
        digest: object.digest ?? null
      };
    }),
    auxiliaryDataDigest: effects.auxiliaryDataDigest ?? null
  };
}
function parseGrpcTransactionResponse(transaction, options) {
  const include = options?.include;
  const objectTypes = {};
  if (include?.objectTypes) transaction.effects?.changedObjects?.forEach((change) => {
    if (change.objectId && change.objectType) objectTypes[change.objectId] = change.objectType;
  });
  let transactionData;
  if (include?.transaction) {
    const tx = transaction.transaction;
    if (!tx) throw new Error("Transaction data is required but missing from gRPC response");
    const resolved = grpcTransactionToTransactionData(tx);
    transactionData = {
      gasData: resolved.gasData,
      sender: resolved.sender,
      expiration: resolved.expiration,
      commands: resolved.commands,
      inputs: resolved.inputs,
      version: resolved.version
    };
  }
  const bcsBytes = include?.bcs ? transaction.transaction?.bcs?.value : void 0;
  const effects = include?.effects ? parseTransactionEffects({ effects: transaction.effects }) : void 0;
  const status = transaction.effects?.status?.success ? {
    success: true,
    error: null
  } : {
    success: false,
    error: transaction.effects?.status?.error ? parseGrpcExecutionError(transaction.effects.status.error) : {
      $kind: "Unknown",
      message: "Transaction failed",
      Unknown: null
    }
  };
  const result = {
    digest: transaction.digest,
    epoch: transaction.effects?.epoch?.toString() ?? null,
    status,
    effects,
    objectTypes: include?.objectTypes ? objectTypes : void 0,
    transaction: transactionData,
    bcs: bcsBytes,
    signatures: transaction.signatures?.map((sig) => toBase6412(sig.bcs?.value)) ?? [],
    balanceChanges: include?.balanceChanges ? transaction.balanceChanges?.map((change) => ({
      coinType: change.coinType,
      address: change.address,
      amount: change.amount
    })) ?? [] : void 0,
    events: include?.events ? transaction.events?.events.map((event) => ({
      packageId: normalizeSuiAddress(event.packageId),
      module: event.module,
      sender: normalizeSuiAddress(event.sender),
      eventType: event.eventType,
      bcs: event.contents?.value ?? new Uint8Array(),
      json: event.json ? Value.toJson(event.json) : null
    })) ?? [] : void 0
  };
  return status.success ? {
    $kind: "Transaction",
    Transaction: result
  } : {
    $kind: "FailedTransaction",
    FailedTransaction: result
  };
}
function parseGrpcSimulateTransactionResponse(response, options) {
  const include = options?.include;
  const transactionResult = parseGrpcTransactionResponse(response.transaction, { include });
  const commandResults = include?.commandResults && response.commandOutputs ? response.commandOutputs.map((output) => ({
    returnValues: (output.returnValues ?? []).map((rv) => ({ bcs: rv.value?.value ?? null })),
    mutatedReferences: (output.mutatedByRef ?? []).map((mr) => ({ bcs: mr.value?.value ?? null }))
  })) : void 0;
  if (transactionResult.$kind === "Transaction") return {
    $kind: "Transaction",
    Transaction: transactionResult.Transaction,
    commandResults
  };
  return {
    $kind: "FailedTransaction",
    FailedTransaction: transactionResult.FailedTransaction,
    commandResults
  };
}
function parseNormalizedSuiMoveType(type) {
  let reference = null;
  if (type.reference === OpenSignature_Reference.IMMUTABLE) reference = "immutable";
  else if (type.reference === OpenSignature_Reference.MUTABLE) reference = "mutable";
  return {
    reference,
    body: parseNormalizedSuiMoveTypeBody(type.body)
  };
}
function parseNormalizedSuiMoveTypeBody(type) {
  switch (type.type) {
    case OpenSignatureBody_Type.TYPE_UNKNOWN:
      return { $kind: "unknown" };
    case OpenSignatureBody_Type.ADDRESS:
      return { $kind: "address" };
    case OpenSignatureBody_Type.BOOL:
      return { $kind: "bool" };
    case OpenSignatureBody_Type.U8:
      return { $kind: "u8" };
    case OpenSignatureBody_Type.U16:
      return { $kind: "u16" };
    case OpenSignatureBody_Type.U32:
      return { $kind: "u32" };
    case OpenSignatureBody_Type.U64:
      return { $kind: "u64" };
    case OpenSignatureBody_Type.U128:
      return { $kind: "u128" };
    case OpenSignatureBody_Type.U256:
      return { $kind: "u256" };
    case OpenSignatureBody_Type.VECTOR:
      return {
        $kind: "vector",
        vector: parseNormalizedSuiMoveTypeBody(type.typeParameterInstantiation[0])
      };
    case OpenSignatureBody_Type.DATATYPE:
      return {
        $kind: "datatype",
        datatype: {
          typeName: type.typeName,
          typeParameters: type.typeParameterInstantiation.map((t) => parseNormalizedSuiMoveTypeBody(t))
        }
      };
    case OpenSignatureBody_Type.TYPE_PARAMETER:
      return {
        $kind: "typeParameter",
        index: type.typeParameter
      };
    default:
      return { $kind: "unknown" };
  }
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/transaction_execution_service.client.mjs
import { stackIntercept } from "@protobuf-ts/runtime-rpc";
var TransactionExecutionServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = TransactionExecutionService.typeName;
    this.methods = TransactionExecutionService.methods;
    this.options = TransactionExecutionService.options;
  }
  /**
  * @generated from protobuf rpc: ExecuteTransaction(sui.rpc.v2.ExecuteTransactionRequest) returns (sui.rpc.v2.ExecuteTransactionResponse);
  */
  executeTransaction(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: SimulateTransaction(sui.rpc.v2.SimulateTransactionRequest) returns (sui.rpc.v2.SimulateTransactionResponse);
  */
  simulateTransaction(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept("unary", this._transport, method, opt, input);
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/filter.mjs
import { MessageType as MessageType23 } from "@protobuf-ts/runtime";
var TransactionFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.TransactionFilter", [{
      no: 1,
      name: "terms",
      kind: "message",
      repeat: 2,
      T: () => TransactionTerm
    }]);
  }
};
var TransactionFilter = new TransactionFilter$Type();
var TransactionTerm$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.TransactionTerm", [{
      no: 1,
      name: "literals",
      kind: "message",
      repeat: 2,
      T: () => TransactionLiteral
    }]);
  }
};
var TransactionTerm = new TransactionTerm$Type();
var TransactionLiteral$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.TransactionLiteral", [
      {
        no: 1,
        name: "negated",
        kind: "scalar",
        T: 8
      },
      {
        no: 2,
        name: "sender",
        kind: "message",
        oneof: "predicate",
        T: () => SenderFilter
      },
      {
        no: 3,
        name: "affected_address",
        kind: "message",
        oneof: "predicate",
        T: () => AffectedAddressFilter
      },
      {
        no: 4,
        name: "affected_object",
        kind: "message",
        oneof: "predicate",
        T: () => AffectedObjectFilter
      },
      {
        no: 5,
        name: "move_call",
        kind: "message",
        oneof: "predicate",
        T: () => MoveCallFilter
      },
      {
        no: 6,
        name: "emit_module",
        kind: "message",
        oneof: "predicate",
        T: () => EmitModuleFilter
      },
      {
        no: 7,
        name: "event_type",
        kind: "message",
        oneof: "predicate",
        T: () => EventTypeFilter
      },
      {
        no: 8,
        name: "event_stream_head",
        kind: "message",
        oneof: "predicate",
        T: () => EventStreamHeadFilter
      },
      {
        no: 9,
        name: "package_write",
        kind: "message",
        oneof: "predicate",
        T: () => PackageWriteFilter
      }
    ]);
  }
};
var TransactionLiteral = new TransactionLiteral$Type();
var EventFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EventFilter", [{
      no: 1,
      name: "terms",
      kind: "message",
      repeat: 2,
      T: () => EventTerm
    }]);
  }
};
var EventFilter = new EventFilter$Type();
var EventTerm$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EventTerm", [{
      no: 1,
      name: "literals",
      kind: "message",
      repeat: 2,
      T: () => EventLiteral
    }]);
  }
};
var EventTerm = new EventTerm$Type();
var EventLiteral$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EventLiteral", [
      {
        no: 1,
        name: "negated",
        kind: "scalar",
        T: 8
      },
      {
        no: 2,
        name: "sender",
        kind: "message",
        oneof: "predicate",
        T: () => SenderFilter
      },
      {
        no: 3,
        name: "emit_module",
        kind: "message",
        oneof: "predicate",
        T: () => EmitModuleFilter
      },
      {
        no: 4,
        name: "event_type",
        kind: "message",
        oneof: "predicate",
        T: () => EventTypeFilter
      },
      {
        no: 5,
        name: "event_stream_head",
        kind: "message",
        oneof: "predicate",
        T: () => EventStreamHeadFilter
      }
    ]);
  }
};
var EventLiteral = new EventLiteral$Type();
var SenderFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.SenderFilter", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var SenderFilter = new SenderFilter$Type();
var AffectedAddressFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.AffectedAddressFilter", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var AffectedAddressFilter = new AffectedAddressFilter$Type();
var AffectedObjectFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.AffectedObjectFilter", [{
      no: 1,
      name: "object_id",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var AffectedObjectFilter = new AffectedObjectFilter$Type();
var MoveCallFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.MoveCallFilter", [{
      no: 1,
      name: "function",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var MoveCallFilter = new MoveCallFilter$Type();
var EmitModuleFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EmitModuleFilter", [{
      no: 1,
      name: "module",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EmitModuleFilter = new EmitModuleFilter$Type();
var EventTypeFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EventTypeFilter", [{
      no: 1,
      name: "event_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EventTypeFilter = new EventTypeFilter$Type();
var EventStreamHeadFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EventStreamHeadFilter", [{
      no: 1,
      name: "stream_id",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EventStreamHeadFilter = new EventStreamHeadFilter$Type();
var PackageWriteFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.PackageWriteFilter", []);
  }
};
var PackageWriteFilter = new PackageWriteFilter$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/protocol_config.mjs
import { MessageType as MessageType24 } from "@protobuf-ts/runtime";
var ProtocolConfig$Type = class extends MessageType24 {
  constructor() {
    super("sui.rpc.v2.ProtocolConfig", [
      {
        no: 1,
        name: "protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "feature_flags",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 8
        }
      },
      {
        no: 3,
        name: "attributes",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 9
        }
      },
      {
        no: 4,
        name: "configs",
        kind: "map",
        K: 9,
        V: {
          kind: "message",
          T: () => Value
        }
      }
    ]);
  }
};
var ProtocolConfig = new ProtocolConfig$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/system_state.mjs
import { MessageType as MessageType25 } from "@protobuf-ts/runtime";
var SystemState$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.SystemState", [
      {
        no: 1,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "validators",
        kind: "message",
        T: () => ValidatorSet
      },
      {
        no: 5,
        name: "storage_fund",
        kind: "message",
        T: () => StorageFund
      },
      {
        no: 6,
        name: "parameters",
        kind: "message",
        T: () => SystemParameters
      },
      {
        no: 7,
        name: "reference_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "validator_report_records",
        kind: "message",
        repeat: 2,
        T: () => ValidatorReportRecord
      },
      {
        no: 9,
        name: "stake_subsidy",
        kind: "message",
        T: () => StakeSubsidy
      },
      {
        no: 10,
        name: "safe_mode",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 11,
        name: "safe_mode_storage_rewards",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 12,
        name: "safe_mode_computation_rewards",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 13,
        name: "safe_mode_storage_rebates",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 14,
        name: "safe_mode_non_refundable_storage_fee",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 15,
        name: "epoch_start_timestamp_ms",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 16,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var SystemState = new SystemState$Type();
var ValidatorReportRecord$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.ValidatorReportRecord", [{
      no: 1,
      name: "reported",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "reporters",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
};
var ValidatorReportRecord = new ValidatorReportRecord$Type();
var SystemParameters$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.SystemParameters", [
      {
        no: 1,
        name: "epoch_duration_ms",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "stake_subsidy_start_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "min_validator_count",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "max_validator_count",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "min_validator_joining_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "validator_low_stake_threshold",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "validator_very_low_stake_threshold",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "validator_low_stake_grace_period",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 9,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var SystemParameters = new SystemParameters$Type();
var MoveTable$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.MoveTable", [{
      no: 1,
      name: "id",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "size",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var MoveTable = new MoveTable$Type();
var StakeSubsidy$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.StakeSubsidy", [
      {
        no: 1,
        name: "balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "distribution_counter",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "current_distribution_amount",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "stake_subsidy_period_length",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "stake_subsidy_decrease_rate",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 6,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var StakeSubsidy = new StakeSubsidy$Type();
var StorageFund$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.StorageFund", [{
      no: 1,
      name: "total_object_storage_rebates",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "non_refundable_balance",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var StorageFund = new StorageFund$Type();
var ValidatorSet$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.ValidatorSet", [
      {
        no: 1,
        name: "total_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "active_validators",
        kind: "message",
        repeat: 2,
        T: () => Validator
      },
      {
        no: 3,
        name: "pending_active_validators",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 4,
        name: "pending_removals",
        kind: "scalar",
        repeat: 1,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "staking_pool_mappings",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 6,
        name: "inactive_validators",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 7,
        name: "validator_candidates",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 8,
        name: "at_risk_validators",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 4,
          L: 0
        }
      },
      {
        no: 9,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var ValidatorSet = new ValidatorSet$Type();
var Validator$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.Validator", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "description",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "image_url",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "project_url",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "protocol_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 8,
        name: "proof_of_possession",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 10,
        name: "network_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 12,
        name: "worker_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 13,
        name: "network_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 14,
        name: "p2p_address",
        kind: "scalar",
        jsonName: "p2pAddress",
        opt: true,
        T: 9
      },
      {
        no: 15,
        name: "primary_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 16,
        name: "worker_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 18,
        name: "next_epoch_protocol_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 19,
        name: "next_epoch_proof_of_possession",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 21,
        name: "next_epoch_network_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 23,
        name: "next_epoch_worker_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 24,
        name: "next_epoch_network_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 25,
        name: "next_epoch_p2p_address",
        kind: "scalar",
        jsonName: "nextEpochP2pAddress",
        opt: true,
        T: 9
      },
      {
        no: 26,
        name: "next_epoch_primary_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 27,
        name: "next_epoch_worker_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 28,
        name: "metadata_extra_fields",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 29,
        name: "voting_power",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 30,
        name: "operation_cap_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 31,
        name: "gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 32,
        name: "staking_pool",
        kind: "message",
        T: () => StakingPool
      },
      {
        no: 33,
        name: "commission_rate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 34,
        name: "next_epoch_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 35,
        name: "next_epoch_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 36,
        name: "next_epoch_commission_rate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 37,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var Validator = new Validator$Type();
var StakingPool$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.StakingPool", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "activation_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "deactivation_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "sui_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "rewards_pool",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "pool_token_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "exchange_rates",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 8,
        name: "pending_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 9,
        name: "pending_total_sui_withdraw",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 10,
        name: "pending_pool_token_withdraw",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 11,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var StakingPool = new StakingPool$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/epoch.mjs
import { MessageType as MessageType26 } from "@protobuf-ts/runtime";
var Epoch$Type = class extends MessageType26 {
  constructor() {
    super("sui.rpc.v2.Epoch", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "committee",
        kind: "message",
        T: () => ValidatorCommittee
      },
      {
        no: 3,
        name: "system_state",
        kind: "message",
        T: () => SystemState
      },
      {
        no: 4,
        name: "first_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "last_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "start",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 7,
        name: "end",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 8,
        name: "reference_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 9,
        name: "protocol_config",
        kind: "message",
        T: () => ProtocolConfig
      }
    ]);
  }
};
var Epoch = new Epoch$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/checkpoint_contents.mjs
import { MessageType as MessageType27 } from "@protobuf-ts/runtime";
var CheckpointContents$Type = class extends MessageType27 {
  constructor() {
    super("sui.rpc.v2.CheckpointContents", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 5
      },
      {
        no: 4,
        name: "transactions",
        kind: "message",
        repeat: 2,
        T: () => CheckpointedTransactionInfo
      }
    ]);
  }
};
var CheckpointContents = new CheckpointContents$Type();
var CheckpointedTransactionInfo$Type = class extends MessageType27 {
  constructor() {
    super("sui.rpc.v2.CheckpointedTransactionInfo", [
      {
        no: 1,
        name: "transaction",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "effects",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => UserSignature
      },
      {
        no: 4,
        name: "address_aliases_versions",
        kind: "message",
        repeat: 2,
        T: () => AddressAliasesVersion
      }
    ]);
  }
};
var CheckpointedTransactionInfo = new CheckpointedTransactionInfo$Type();
var AddressAliasesVersion$Type = class extends MessageType27 {
  constructor() {
    super("sui.rpc.v2.AddressAliasesVersion", [{
      no: 1,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var AddressAliasesVersion = new AddressAliasesVersion$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/checkpoint_summary.mjs
import { MessageType as MessageType28 } from "@protobuf-ts/runtime";
var CheckpointCommitment_CheckpointCommitmentKind = /* @__PURE__ */ (function(CheckpointCommitment_CheckpointCommitmentKind$1) {
  CheckpointCommitment_CheckpointCommitmentKind$1[CheckpointCommitment_CheckpointCommitmentKind$1["CHECKPOINT_COMMITMENT_KIND_UNKNOWN"] = 0] = "CHECKPOINT_COMMITMENT_KIND_UNKNOWN";
  CheckpointCommitment_CheckpointCommitmentKind$1[CheckpointCommitment_CheckpointCommitmentKind$1["ECMH_LIVE_OBJECT_SET"] = 1] = "ECMH_LIVE_OBJECT_SET";
  CheckpointCommitment_CheckpointCommitmentKind$1[CheckpointCommitment_CheckpointCommitmentKind$1["CHECKPOINT_ARTIFACTS"] = 2] = "CHECKPOINT_ARTIFACTS";
  return CheckpointCommitment_CheckpointCommitmentKind$1;
})({});
var CheckpointSummary$Type = class extends MessageType28 {
  constructor() {
    super("sui.rpc.v2.CheckpointSummary", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "sequence_number",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "total_network_transactions",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "content_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "previous_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "epoch_rolling_gas_cost_summary",
        kind: "message",
        T: () => GasCostSummary2
      },
      {
        no: 9,
        name: "timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 10,
        name: "commitments",
        kind: "message",
        repeat: 2,
        T: () => CheckpointCommitment
      },
      {
        no: 11,
        name: "end_of_epoch_data",
        kind: "message",
        T: () => EndOfEpochData
      },
      {
        no: 12,
        name: "version_specific_data",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var CheckpointSummary = new CheckpointSummary$Type();
var EndOfEpochData$Type = class extends MessageType28 {
  constructor() {
    super("sui.rpc.v2.EndOfEpochData", [
      {
        no: 1,
        name: "next_epoch_committee",
        kind: "message",
        repeat: 2,
        T: () => ValidatorCommitteeMember
      },
      {
        no: 2,
        name: "next_epoch_protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "epoch_commitments",
        kind: "message",
        repeat: 2,
        T: () => CheckpointCommitment
      }
    ]);
  }
};
var EndOfEpochData = new EndOfEpochData$Type();
var CheckpointCommitment$Type = class extends MessageType28 {
  constructor() {
    super("sui.rpc.v2.CheckpointCommitment", [{
      no: 1,
      name: "kind",
      kind: "enum",
      opt: true,
      T: () => ["sui.rpc.v2.CheckpointCommitment.CheckpointCommitmentKind", CheckpointCommitment_CheckpointCommitmentKind]
    }, {
      no: 2,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var CheckpointCommitment = new CheckpointCommitment$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/checkpoint.mjs
import { MessageType as MessageType29 } from "@protobuf-ts/runtime";
var Checkpoint$Type = class extends MessageType29 {
  constructor() {
    super("sui.rpc.v2.Checkpoint", [
      {
        no: 1,
        name: "sequence_number",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "summary",
        kind: "message",
        T: () => CheckpointSummary
      },
      {
        no: 4,
        name: "signature",
        kind: "message",
        T: () => ValidatorAggregatedSignature
      },
      {
        no: 5,
        name: "contents",
        kind: "message",
        T: () => CheckpointContents
      },
      {
        no: 6,
        name: "transactions",
        kind: "message",
        repeat: 2,
        T: () => ExecutedTransaction
      },
      {
        no: 7,
        name: "objects",
        kind: "message",
        T: () => ObjectSet
      }
    ]);
  }
};
var Checkpoint = new Checkpoint$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/any.mjs
import { MessageType as MessageType30, isJsonObject as isJsonObject2, jsonWriteOptions, typeofJsonValue as typeofJsonValue5 } from "@protobuf-ts/runtime";
var Any$Type = class extends MessageType30 {
  constructor() {
    super("google.protobuf.Any", [{
      no: 1,
      name: "type_url",
      kind: "scalar",
      T: 9
    }, {
      no: 2,
      name: "value",
      kind: "scalar",
      T: 12
    }]);
  }
  /**
  * Pack the message into a new `Any`.
  *
  * Uses 'type.googleapis.com/full.type.name' as the type URL.
  */
  pack(message, type) {
    return {
      typeUrl: this.typeNameToUrl(type.typeName),
      value: type.toBinary(message)
    };
  }
  /**
  * Unpack the message from the `Any`.
  */
  unpack(any, type, options) {
    if (!this.contains(any, type)) throw new Error("Cannot unpack google.protobuf.Any with typeUrl '" + any.typeUrl + "' as " + type.typeName + ".");
    return type.fromBinary(any.value, options);
  }
  /**
  * Does the given `Any` contain a packed message of the given type?
  */
  contains(any, type) {
    if (!any.typeUrl.length) return false;
    return (typeof type == "string" ? type : type.typeName) === this.typeUrlToName(any.typeUrl);
  }
  /**
  * Convert the message to canonical JSON value.
  *
  * You have to provide the `typeRegistry` option so that the
  * packed message can be converted to JSON.
  *
  * The `typeRegistry` option is also required to read
  * `google.protobuf.Any` from JSON format.
  */
  internalJsonWrite(any, options) {
    if (any.typeUrl === "") return {};
    let typeName = this.typeUrlToName(any.typeUrl);
    let opt = jsonWriteOptions(options);
    let type = opt.typeRegistry?.find((t) => t.typeName === typeName);
    if (!type) throw new globalThis.Error("Unable to convert google.protobuf.Any with typeUrl '" + any.typeUrl + "' to JSON. The specified type " + typeName + " is not available in the type registry.");
    let value = type.fromBinary(any.value, { readUnknownField: false });
    let json2 = type.internalJsonWrite(value, opt);
    if (typeName.startsWith("google.protobuf.") || !isJsonObject2(json2)) json2 = { value: json2 };
    json2["@type"] = any.typeUrl;
    return json2;
  }
  internalJsonRead(json2, options, target) {
    if (!isJsonObject2(json2)) throw new globalThis.Error("Unable to parse google.protobuf.Any from JSON " + typeofJsonValue5(json2) + ".");
    if (typeof json2["@type"] != "string" || json2["@type"] == "") return this.create();
    let typeName = this.typeUrlToName(json2["@type"]);
    let type = options?.typeRegistry?.find((t) => t.typeName == typeName);
    if (!type) throw new globalThis.Error("Unable to parse google.protobuf.Any from JSON. The specified type " + typeName + " is not available in the type registry.");
    let value;
    if (typeName.startsWith("google.protobuf.") && json2.hasOwnProperty("value")) value = type.fromJson(json2["value"], options);
    else {
      let copy = Object.assign({}, json2);
      delete copy["@type"];
      value = type.fromJson(copy, options);
    }
    if (target === void 0) target = this.create();
    target.typeUrl = json2["@type"];
    target.value = type.toBinary(value);
    return target;
  }
  typeNameToUrl(name) {
    if (!name.length) throw new Error("invalid type name: " + name);
    return "type.googleapis.com/" + name;
  }
  typeUrlToName(url) {
    if (!url.length) throw new Error("invalid type url: " + url);
    let slash = url.lastIndexOf("/");
    let name = slash > 0 ? url.substring(slash + 1) : url;
    if (!name.length) throw new Error("invalid type url: " + url);
    return name;
  }
};
var Any = new Any$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/google/rpc/status.mjs
import { MessageType as MessageType31 } from "@protobuf-ts/runtime";
var Status$Type = class extends MessageType31 {
  constructor() {
    super("google.rpc.Status", [
      {
        no: 1,
        name: "code",
        kind: "scalar",
        T: 5
      },
      {
        no: 2,
        name: "message",
        kind: "scalar",
        T: 9
      },
      {
        no: 3,
        name: "details",
        kind: "message",
        repeat: 2,
        T: () => Any
      }
    ]);
  }
};
var Status = new Status$Type();

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/ledger_service.mjs
import { MessageType as MessageType32 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType2 } from "@protobuf-ts/runtime-rpc";
var GetServiceInfoRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetServiceInfoRequest", []);
  }
};
var GetServiceInfoRequest = new GetServiceInfoRequest$Type();
var GetServiceInfoResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetServiceInfoResponse", [
      {
        no: 1,
        name: "chain_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "chain",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "checkpoint_height",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 6,
        name: "lowest_available_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "lowest_available_checkpoint_objects",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "server",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var GetServiceInfoResponse = new GetServiceInfoResponse$Type();
var GetObjectRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetObjectRequest", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var GetObjectRequest = new GetObjectRequest$Type();
var GetObjectResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetObjectResponse", [{
      no: 1,
      name: "object",
      kind: "message",
      T: () => Object$1
    }]);
  }
};
var GetObjectResponse = new GetObjectResponse$Type();
var BatchGetObjectsRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.BatchGetObjectsRequest", [{
      no: 1,
      name: "requests",
      kind: "message",
      repeat: 2,
      T: () => GetObjectRequest
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var BatchGetObjectsRequest = new BatchGetObjectsRequest$Type();
var BatchGetObjectsResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.BatchGetObjectsResponse", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => GetObjectResult
    }]);
  }
};
var BatchGetObjectsResponse = new BatchGetObjectsResponse$Type();
var GetObjectResult$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetObjectResult", [{
      no: 1,
      name: "object",
      kind: "message",
      oneof: "result",
      T: () => Object$1
    }, {
      no: 2,
      name: "error",
      kind: "message",
      oneof: "result",
      T: () => Status
    }]);
  }
};
var GetObjectResult = new GetObjectResult$Type();
var GetTransactionRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetTransactionRequest", [{
      no: 1,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var GetTransactionRequest = new GetTransactionRequest$Type();
var GetTransactionResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetTransactionResponse", [{
      no: 1,
      name: "transaction",
      kind: "message",
      T: () => ExecutedTransaction
    }]);
  }
};
var GetTransactionResponse = new GetTransactionResponse$Type();
var BatchGetTransactionsRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.BatchGetTransactionsRequest", [{
      no: 1,
      name: "digests",
      kind: "scalar",
      repeat: 2,
      T: 9
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var BatchGetTransactionsRequest = new BatchGetTransactionsRequest$Type();
var BatchGetTransactionsResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.BatchGetTransactionsResponse", [{
      no: 1,
      name: "transactions",
      kind: "message",
      repeat: 2,
      T: () => GetTransactionResult
    }]);
  }
};
var BatchGetTransactionsResponse = new BatchGetTransactionsResponse$Type();
var GetTransactionResult$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetTransactionResult", [{
      no: 1,
      name: "transaction",
      kind: "message",
      oneof: "result",
      T: () => ExecutedTransaction
    }, {
      no: 2,
      name: "error",
      kind: "message",
      oneof: "result",
      T: () => Status
    }]);
  }
};
var GetTransactionResult = new GetTransactionResult$Type();
var GetCheckpointRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetCheckpointRequest", [
      {
        no: 1,
        name: "sequence_number",
        kind: "scalar",
        oneof: "checkpointId",
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        oneof: "checkpointId",
        T: 9
      },
      {
        no: 3,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var GetCheckpointRequest = new GetCheckpointRequest$Type();
var GetCheckpointResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetCheckpointResponse", [{
      no: 1,
      name: "checkpoint",
      kind: "message",
      T: () => Checkpoint
    }]);
  }
};
var GetCheckpointResponse = new GetCheckpointResponse$Type();
var GetEpochRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetEpochRequest", [{
      no: 1,
      name: "epoch",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var GetEpochRequest = new GetEpochRequest$Type();
var GetEpochResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetEpochResponse", [{
      no: 1,
      name: "epoch",
      kind: "message",
      T: () => Epoch
    }]);
  }
};
var GetEpochResponse = new GetEpochResponse$Type();
var ListCheckpointsRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListCheckpointsRequest", [
      {
        no: 1,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 2,
        name: "start_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "end_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "filter",
        kind: "message",
        T: () => TransactionFilter
      },
      {
        no: 5,
        name: "options",
        kind: "message",
        T: () => QueryOptions
      }
    ]);
  }
};
var ListCheckpointsRequest = new ListCheckpointsRequest$Type();
var ListCheckpointsResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListCheckpointsResponse", [
      {
        no: 1,
        name: "checkpoint",
        kind: "message",
        T: () => Checkpoint
      },
      {
        no: 2,
        name: "watermark",
        kind: "message",
        T: () => Watermark
      },
      {
        no: 3,
        name: "end",
        kind: "message",
        T: () => QueryEnd
      }
    ]);
  }
};
var ListCheckpointsResponse = new ListCheckpointsResponse$Type();
var ListTransactionsRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListTransactionsRequest", [
      {
        no: 1,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 2,
        name: "start_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "end_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "filter",
        kind: "message",
        T: () => TransactionFilter
      },
      {
        no: 5,
        name: "options",
        kind: "message",
        T: () => QueryOptions
      }
    ]);
  }
};
var ListTransactionsRequest = new ListTransactionsRequest$Type();
var ListTransactionsResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListTransactionsResponse", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => ExecutedTransaction
      },
      {
        no: 2,
        name: "watermark",
        kind: "message",
        T: () => Watermark
      },
      {
        no: 3,
        name: "end",
        kind: "message",
        T: () => QueryEnd
      }
    ]);
  }
};
var ListTransactionsResponse = new ListTransactionsResponse$Type();
var ListEventsRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListEventsRequest", [
      {
        no: 1,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 2,
        name: "start_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "end_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "filter",
        kind: "message",
        T: () => EventFilter
      },
      {
        no: 5,
        name: "options",
        kind: "message",
        T: () => QueryOptions
      }
    ]);
  }
};
var ListEventsRequest = new ListEventsRequest$Type();
var ListEventsResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListEventsResponse", [
      {
        no: 1,
        name: "event",
        kind: "message",
        T: () => Event
      },
      {
        no: 2,
        name: "watermark",
        kind: "message",
        T: () => Watermark
      },
      {
        no: 3,
        name: "end",
        kind: "message",
        T: () => QueryEnd
      }
    ]);
  }
};
var ListEventsResponse = new ListEventsResponse$Type();
var LedgerService = new ServiceType2("sui.rpc.v2.LedgerService", [
  {
    name: "GetServiceInfo",
    options: {},
    I: GetServiceInfoRequest,
    O: GetServiceInfoResponse
  },
  {
    name: "GetObject",
    options: {},
    I: GetObjectRequest,
    O: GetObjectResponse
  },
  {
    name: "BatchGetObjects",
    options: {},
    I: BatchGetObjectsRequest,
    O: BatchGetObjectsResponse
  },
  {
    name: "GetTransaction",
    options: {},
    I: GetTransactionRequest,
    O: GetTransactionResponse
  },
  {
    name: "BatchGetTransactions",
    options: {},
    I: BatchGetTransactionsRequest,
    O: BatchGetTransactionsResponse
  },
  {
    name: "GetCheckpoint",
    options: {},
    I: GetCheckpointRequest,
    O: GetCheckpointResponse
  },
  {
    name: "GetEpoch",
    options: {},
    I: GetEpochRequest,
    O: GetEpochResponse
  },
  {
    name: "ListCheckpoints",
    serverStreaming: true,
    options: {},
    I: ListCheckpointsRequest,
    O: ListCheckpointsResponse
  },
  {
    name: "ListTransactions",
    serverStreaming: true,
    options: {},
    I: ListTransactionsRequest,
    O: ListTransactionsResponse
  },
  {
    name: "ListEvents",
    serverStreaming: true,
    options: {},
    I: ListEventsRequest,
    O: ListEventsResponse
  }
]);

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/ledger_service.client.mjs
import { stackIntercept as stackIntercept2 } from "@protobuf-ts/runtime-rpc";
var LedgerServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = LedgerService.typeName;
    this.methods = LedgerService.methods;
    this.options = LedgerService.options;
  }
  /**
  * Query the service for general information about its current state.
  *
  * @generated from protobuf rpc: GetServiceInfo(sui.rpc.v2.GetServiceInfoRequest) returns (sui.rpc.v2.GetServiceInfoResponse);
  */
  getServiceInfo(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetObject(sui.rpc.v2.GetObjectRequest) returns (sui.rpc.v2.GetObjectResponse);
  */
  getObject(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: BatchGetObjects(sui.rpc.v2.BatchGetObjectsRequest) returns (sui.rpc.v2.BatchGetObjectsResponse);
  */
  batchGetObjects(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetTransaction(sui.rpc.v2.GetTransactionRequest) returns (sui.rpc.v2.GetTransactionResponse);
  */
  getTransaction(input, options) {
    const method = this.methods[3], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: BatchGetTransactions(sui.rpc.v2.BatchGetTransactionsRequest) returns (sui.rpc.v2.BatchGetTransactionsResponse);
  */
  batchGetTransactions(input, options) {
    const method = this.methods[4], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetCheckpoint(sui.rpc.v2.GetCheckpointRequest) returns (sui.rpc.v2.GetCheckpointResponse);
  */
  getCheckpoint(input, options) {
    const method = this.methods[5], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetEpoch(sui.rpc.v2.GetEpochRequest) returns (sui.rpc.v2.GetEpochResponse);
  */
  getEpoch(input, options) {
    const method = this.methods[6], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * List checkpoints matching the provided filters.
  *
  * Checkpoints are returned in ascending or descending checkpoint sequence
  * number order according to the query options ordering.
  * A checkpoint matches if any transaction it contains satisfies the filter.
  *
  * @generated from protobuf rpc: ListCheckpoints(sui.rpc.v2.ListCheckpointsRequest) returns (stream sui.rpc.v2.ListCheckpointsResponse);
  */
  listCheckpoints(input, options) {
    const method = this.methods[7], opt = this._transport.mergeOptions(options);
    return stackIntercept2("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * List transactions matching the provided filters.
  *
  * Transactions are returned in ascending or descending transaction sequence
  * order according to the query options ordering.
  *
  * @generated from protobuf rpc: ListTransactions(sui.rpc.v2.ListTransactionsRequest) returns (stream sui.rpc.v2.ListTransactionsResponse);
  */
  listTransactions(input, options) {
    const method = this.methods[8], opt = this._transport.mergeOptions(options);
    return stackIntercept2("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * List events matching the provided filters.
  *
  * Events are returned in ascending or descending packed event sequence order
  * according to the query options ordering.
  *
  * @generated from protobuf rpc: ListEvents(sui.rpc.v2.ListEventsRequest) returns (stream sui.rpc.v2.ListEventsResponse);
  */
  listEvents(input, options) {
    const method = this.methods[9], opt = this._transport.mergeOptions(options);
    return stackIntercept2("serverStreaming", this._transport, method, opt, input);
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/move_package_service.mjs
import { MessageType as MessageType33 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType3 } from "@protobuf-ts/runtime-rpc";
var GetPackageRequest$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetPackageRequest", [{
      no: 1,
      name: "package_id",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var GetPackageRequest = new GetPackageRequest$Type();
var GetPackageResponse$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetPackageResponse", [{
      no: 1,
      name: "package",
      kind: "message",
      T: () => Package
    }]);
  }
};
var GetPackageResponse = new GetPackageResponse$Type();
var GetDatatypeRequest$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetDatatypeRequest", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var GetDatatypeRequest = new GetDatatypeRequest$Type();
var GetDatatypeResponse$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetDatatypeResponse", [{
      no: 1,
      name: "datatype",
      kind: "message",
      T: () => DatatypeDescriptor
    }]);
  }
};
var GetDatatypeResponse = new GetDatatypeResponse$Type();
var GetFunctionRequest$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetFunctionRequest", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var GetFunctionRequest = new GetFunctionRequest$Type();
var GetFunctionResponse$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetFunctionResponse", [{
      no: 1,
      name: "function",
      kind: "message",
      T: () => FunctionDescriptor
    }]);
  }
};
var GetFunctionResponse = new GetFunctionResponse$Type();
var ListPackageVersionsRequest$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.ListPackageVersionsRequest", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var ListPackageVersionsRequest = new ListPackageVersionsRequest$Type();
var ListPackageVersionsResponse$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.ListPackageVersionsResponse", [{
      no: 1,
      name: "versions",
      kind: "message",
      repeat: 2,
      T: () => PackageVersion
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListPackageVersionsResponse = new ListPackageVersionsResponse$Type();
var PackageVersion$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.PackageVersion", [{
      no: 1,
      name: "package_id",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var PackageVersion = new PackageVersion$Type();
var MovePackageService = new ServiceType3("sui.rpc.v2.MovePackageService", [
  {
    name: "GetPackage",
    options: {},
    I: GetPackageRequest,
    O: GetPackageResponse
  },
  {
    name: "GetDatatype",
    options: {},
    I: GetDatatypeRequest,
    O: GetDatatypeResponse
  },
  {
    name: "GetFunction",
    options: {},
    I: GetFunctionRequest,
    O: GetFunctionResponse
  },
  {
    name: "ListPackageVersions",
    options: {},
    I: ListPackageVersionsRequest,
    O: ListPackageVersionsResponse
  }
]);

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/move_package_service.client.mjs
import { stackIntercept as stackIntercept3 } from "@protobuf-ts/runtime-rpc";
var MovePackageServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = MovePackageService.typeName;
    this.methods = MovePackageService.methods;
    this.options = MovePackageService.options;
  }
  /**
  * @generated from protobuf rpc: GetPackage(sui.rpc.v2.GetPackageRequest) returns (sui.rpc.v2.GetPackageResponse);
  */
  getPackage(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept3("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetDatatype(sui.rpc.v2.GetDatatypeRequest) returns (sui.rpc.v2.GetDatatypeResponse);
  */
  getDatatype(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept3("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetFunction(sui.rpc.v2.GetFunctionRequest) returns (sui.rpc.v2.GetFunctionResponse);
  */
  getFunction(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return stackIntercept3("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ListPackageVersions(sui.rpc.v2.ListPackageVersionsRequest) returns (sui.rpc.v2.ListPackageVersionsResponse);
  */
  listPackageVersions(input, options) {
    const method = this.methods[3], opt = this._transport.mergeOptions(options);
    return stackIntercept3("unary", this._transport, method, opt, input);
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature_verification_service.mjs
import { MessageType as MessageType34 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType4 } from "@protobuf-ts/runtime-rpc";
var VerifySignatureRequest$Type = class extends MessageType34 {
  constructor() {
    super("sui.rpc.v2.VerifySignatureRequest", [
      {
        no: 1,
        name: "message",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "signature",
        kind: "message",
        T: () => UserSignature
      },
      {
        no: 3,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "jwks",
        kind: "message",
        repeat: 2,
        T: () => ActiveJwk2
      }
    ]);
  }
};
var VerifySignatureRequest = new VerifySignatureRequest$Type();
var VerifySignatureResponse$Type = class extends MessageType34 {
  constructor() {
    super("sui.rpc.v2.VerifySignatureResponse", [{
      no: 1,
      name: "is_valid",
      kind: "scalar",
      opt: true,
      T: 8
    }, {
      no: 2,
      name: "reason",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var VerifySignatureResponse = new VerifySignatureResponse$Type();
var SignatureVerificationService = new ServiceType4("sui.rpc.v2.SignatureVerificationService", [{
  name: "VerifySignature",
  options: {},
  I: VerifySignatureRequest,
  O: VerifySignatureResponse
}]);

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature_verification_service.client.mjs
import { stackIntercept as stackIntercept4 } from "@protobuf-ts/runtime-rpc";
var SignatureVerificationServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = SignatureVerificationService.typeName;
    this.methods = SignatureVerificationService.methods;
    this.options = SignatureVerificationService.options;
  }
  /**
  * Perform signature verification of a UserSignature against the provided message.
  *
  * @generated from protobuf rpc: VerifySignature(sui.rpc.v2.VerifySignatureRequest) returns (sui.rpc.v2.VerifySignatureResponse);
  */
  verifySignature(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept4("unary", this._transport, method, opt, input);
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/state_service.mjs
import { MessageType as MessageType35 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType5 } from "@protobuf-ts/runtime-rpc";
var CoinMetadata_MetadataCapState = /* @__PURE__ */ (function(CoinMetadata_MetadataCapState$1) {
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["METADATA_CAP_STATE_UNKNOWN"] = 0] = "METADATA_CAP_STATE_UNKNOWN";
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["CLAIMED"] = 1] = "CLAIMED";
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["UNCLAIMED"] = 2] = "UNCLAIMED";
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["DELETED"] = 3] = "DELETED";
  return CoinMetadata_MetadataCapState$1;
})({});
var CoinTreasury_SupplyState = /* @__PURE__ */ (function(CoinTreasury_SupplyState$1) {
  CoinTreasury_SupplyState$1[CoinTreasury_SupplyState$1["SUPPLY_STATE_UNKNOWN"] = 0] = "SUPPLY_STATE_UNKNOWN";
  CoinTreasury_SupplyState$1[CoinTreasury_SupplyState$1["FIXED"] = 1] = "FIXED";
  CoinTreasury_SupplyState$1[CoinTreasury_SupplyState$1["BURN_ONLY"] = 2] = "BURN_ONLY";
  return CoinTreasury_SupplyState$1;
})({});
var RegulatedCoinMetadata_CoinRegulatedState = /* @__PURE__ */ (function(RegulatedCoinMetadata_CoinRegulatedState$1) {
  RegulatedCoinMetadata_CoinRegulatedState$1[RegulatedCoinMetadata_CoinRegulatedState$1["COIN_REGULATED_STATE_UNKNOWN"] = 0] = "COIN_REGULATED_STATE_UNKNOWN";
  RegulatedCoinMetadata_CoinRegulatedState$1[RegulatedCoinMetadata_CoinRegulatedState$1["REGULATED"] = 1] = "REGULATED";
  RegulatedCoinMetadata_CoinRegulatedState$1[RegulatedCoinMetadata_CoinRegulatedState$1["UNREGULATED"] = 2] = "UNREGULATED";
  return RegulatedCoinMetadata_CoinRegulatedState$1;
})({});
var DynamicField_DynamicFieldKind = /* @__PURE__ */ (function(DynamicField_DynamicFieldKind$1) {
  DynamicField_DynamicFieldKind$1[DynamicField_DynamicFieldKind$1["DYNAMIC_FIELD_KIND_UNKNOWN"] = 0] = "DYNAMIC_FIELD_KIND_UNKNOWN";
  DynamicField_DynamicFieldKind$1[DynamicField_DynamicFieldKind$1["FIELD"] = 1] = "FIELD";
  DynamicField_DynamicFieldKind$1[DynamicField_DynamicFieldKind$1["OBJECT"] = 2] = "OBJECT";
  return DynamicField_DynamicFieldKind$1;
})({});
var GetCoinInfoRequest$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.GetCoinInfoRequest", [{
      no: 1,
      name: "coin_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var GetCoinInfoRequest = new GetCoinInfoRequest$Type();
var GetCoinInfoResponse$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.GetCoinInfoResponse", [
      {
        no: 1,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "metadata",
        kind: "message",
        T: () => CoinMetadata
      },
      {
        no: 3,
        name: "treasury",
        kind: "message",
        T: () => CoinTreasury
      },
      {
        no: 4,
        name: "regulated_metadata",
        kind: "message",
        T: () => RegulatedCoinMetadata
      }
    ]);
  }
};
var GetCoinInfoResponse = new GetCoinInfoResponse$Type();
var CoinMetadata$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.CoinMetadata", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "decimals",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "symbol",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "description",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "icon_url",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "metadata_cap_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "metadata_cap_state",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.CoinMetadata.MetadataCapState", CoinMetadata_MetadataCapState]
      }
    ]);
  }
};
var CoinMetadata = new CoinMetadata$Type();
var CoinTreasury$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.CoinTreasury", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "total_supply",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "supply_state",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.CoinTreasury.SupplyState", CoinTreasury_SupplyState]
      }
    ]);
  }
};
var CoinTreasury = new CoinTreasury$Type();
var RegulatedCoinMetadata$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.RegulatedCoinMetadata", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "coin_metadata_object",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "deny_cap_object",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "allow_global_pause",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 5,
        name: "variant",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 6,
        name: "coin_regulated_state",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.RegulatedCoinMetadata.CoinRegulatedState", RegulatedCoinMetadata_CoinRegulatedState]
      }
    ]);
  }
};
var RegulatedCoinMetadata = new RegulatedCoinMetadata$Type();
var GetBalanceRequest$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.GetBalanceRequest", [{
      no: 1,
      name: "owner",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "coin_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var GetBalanceRequest = new GetBalanceRequest$Type();
var GetBalanceResponse$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.GetBalanceResponse", [{
      no: 1,
      name: "balance",
      kind: "message",
      T: () => Balance
    }]);
  }
};
var GetBalanceResponse = new GetBalanceResponse$Type();
var ListBalancesRequest$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListBalancesRequest", [
      {
        no: 1,
        name: "owner",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var ListBalancesRequest = new ListBalancesRequest$Type();
var ListBalancesResponse$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListBalancesResponse", [{
      no: 1,
      name: "balances",
      kind: "message",
      repeat: 2,
      T: () => Balance
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListBalancesResponse = new ListBalancesResponse$Type();
var Balance$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.Balance", [
      {
        no: 1,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "address_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "coin_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var Balance = new Balance$Type();
var ListDynamicFieldsRequest$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListDynamicFieldsRequest", [
      {
        no: 1,
        name: "parent",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var ListDynamicFieldsRequest = new ListDynamicFieldsRequest$Type();
var ListDynamicFieldsResponse$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListDynamicFieldsResponse", [{
      no: 1,
      name: "dynamic_fields",
      kind: "message",
      repeat: 2,
      T: () => DynamicField
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListDynamicFieldsResponse = new ListDynamicFieldsResponse$Type();
var DynamicField$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.DynamicField", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.DynamicField.DynamicFieldKind", DynamicField_DynamicFieldKind]
      },
      {
        no: 2,
        name: "parent",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "field_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "field_object",
        kind: "message",
        T: () => Object$1
      },
      {
        no: 5,
        name: "name",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 6,
        name: "value",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 7,
        name: "value_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "child_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 9,
        name: "child_object",
        kind: "message",
        T: () => Object$1
      }
    ]);
  }
};
var DynamicField = new DynamicField$Type();
var ListOwnedObjectsRequest$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListOwnedObjectsRequest", [
      {
        no: 1,
        name: "owner",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 5,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ListOwnedObjectsRequest = new ListOwnedObjectsRequest$Type();
var ListOwnedObjectsResponse$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListOwnedObjectsResponse", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Object$1
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListOwnedObjectsResponse = new ListOwnedObjectsResponse$Type();
var StateService = new ServiceType5("sui.rpc.v2.StateService", [
  {
    name: "ListDynamicFields",
    options: {},
    I: ListDynamicFieldsRequest,
    O: ListDynamicFieldsResponse
  },
  {
    name: "ListOwnedObjects",
    options: {},
    I: ListOwnedObjectsRequest,
    O: ListOwnedObjectsResponse
  },
  {
    name: "GetCoinInfo",
    options: {},
    I: GetCoinInfoRequest,
    O: GetCoinInfoResponse
  },
  {
    name: "GetBalance",
    options: {},
    I: GetBalanceRequest,
    O: GetBalanceResponse
  },
  {
    name: "ListBalances",
    options: {},
    I: ListBalancesRequest,
    O: ListBalancesResponse
  }
]);

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/state_service.client.mjs
import { stackIntercept as stackIntercept5 } from "@protobuf-ts/runtime-rpc";
var StateServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = StateService.typeName;
    this.methods = StateService.methods;
    this.options = StateService.options;
  }
  /**
  * @generated from protobuf rpc: ListDynamicFields(sui.rpc.v2.ListDynamicFieldsRequest) returns (sui.rpc.v2.ListDynamicFieldsResponse);
  */
  listDynamicFields(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept5("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ListOwnedObjects(sui.rpc.v2.ListOwnedObjectsRequest) returns (sui.rpc.v2.ListOwnedObjectsResponse);
  */
  listOwnedObjects(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept5("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetCoinInfo(sui.rpc.v2.GetCoinInfoRequest) returns (sui.rpc.v2.GetCoinInfoResponse);
  */
  getCoinInfo(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return stackIntercept5("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetBalance(sui.rpc.v2.GetBalanceRequest) returns (sui.rpc.v2.GetBalanceResponse);
  */
  getBalance(input, options) {
    const method = this.methods[3], opt = this._transport.mergeOptions(options);
    return stackIntercept5("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ListBalances(sui.rpc.v2.ListBalancesRequest) returns (sui.rpc.v2.ListBalancesResponse);
  */
  listBalances(input, options) {
    const method = this.methods[4], opt = this._transport.mergeOptions(options);
    return stackIntercept5("unary", this._transport, method, opt, input);
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/subscription_service.mjs
import { MessageType as MessageType36 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType6 } from "@protobuf-ts/runtime-rpc";
var SubscribeCheckpointsRequest$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeCheckpointsRequest", [{
      no: 1,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }, {
      no: 2,
      name: "filter",
      kind: "message",
      T: () => TransactionFilter
    }]);
  }
};
var SubscribeCheckpointsRequest = new SubscribeCheckpointsRequest$Type();
var SubscribeCheckpointsResponse$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeCheckpointsResponse", [{
      no: 1,
      name: "cursor",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "checkpoint",
      kind: "message",
      T: () => Checkpoint
    }]);
  }
};
var SubscribeCheckpointsResponse = new SubscribeCheckpointsResponse$Type();
var SubscribeTransactionsRequest$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeTransactionsRequest", [{
      no: 1,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }, {
      no: 2,
      name: "filter",
      kind: "message",
      T: () => TransactionFilter
    }]);
  }
};
var SubscribeTransactionsRequest = new SubscribeTransactionsRequest$Type();
var SubscribeTransactionsResponse$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeTransactionsResponse", [{
      no: 1,
      name: "transaction",
      kind: "message",
      T: () => ExecutedTransaction
    }, {
      no: 2,
      name: "watermark",
      kind: "message",
      T: () => Watermark
    }]);
  }
};
var SubscribeTransactionsResponse = new SubscribeTransactionsResponse$Type();
var SubscribeEventsRequest$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeEventsRequest", [{
      no: 1,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }, {
      no: 2,
      name: "filter",
      kind: "message",
      T: () => EventFilter
    }]);
  }
};
var SubscribeEventsRequest = new SubscribeEventsRequest$Type();
var SubscribeEventsResponse$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeEventsResponse", [{
      no: 1,
      name: "event",
      kind: "message",
      T: () => Event
    }, {
      no: 2,
      name: "watermark",
      kind: "message",
      T: () => Watermark
    }]);
  }
};
var SubscribeEventsResponse = new SubscribeEventsResponse$Type();
var SubscriptionService = new ServiceType6("sui.rpc.v2.SubscriptionService", [
  {
    name: "SubscribeCheckpoints",
    serverStreaming: true,
    options: {},
    I: SubscribeCheckpointsRequest,
    O: SubscribeCheckpointsResponse
  },
  {
    name: "SubscribeTransactions",
    serverStreaming: true,
    options: {},
    I: SubscribeTransactionsRequest,
    O: SubscribeTransactionsResponse
  },
  {
    name: "SubscribeEvents",
    serverStreaming: true,
    options: {},
    I: SubscribeEventsRequest,
    O: SubscribeEventsResponse
  }
]);

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/subscription_service.client.mjs
import { stackIntercept as stackIntercept6 } from "@protobuf-ts/runtime-rpc";
var SubscriptionServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = SubscriptionService.typeName;
    this.methods = SubscriptionService.methods;
    this.options = SubscriptionService.options;
  }
  /**
  * Subscribe to the stream of checkpoints.
  *
  * The stream begins at the latest executed checkpoint as seen by the
  * server and yields checkpoints matching the filter as they are executed.
  * A checkpoint matches if any transaction it contains satisfies the
  * filter.
  *
  * @generated from protobuf rpc: SubscribeCheckpoints(sui.rpc.v2.SubscribeCheckpointsRequest) returns (stream sui.rpc.v2.SubscribeCheckpointsResponse);
  */
  subscribeCheckpoints(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept6("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * Subscribe to the stream of transactions.
  *
  * The stream begins at the latest executed checkpoint as seen by the
  * server and yields transactions matching the filter as they are executed.
  *
  * @generated from protobuf rpc: SubscribeTransactions(sui.rpc.v2.SubscribeTransactionsRequest) returns (stream sui.rpc.v2.SubscribeTransactionsResponse);
  */
  subscribeTransactions(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept6("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * Subscribe to the stream of events.
  *
  * The stream begins at the latest executed checkpoint as seen by the
  * server and yields events matching the filter as they are emitted.
  *
  * @generated from protobuf rpc: SubscribeEvents(sui.rpc.v2.SubscribeEventsRequest) returns (stream sui.rpc.v2.SubscribeEventsResponse);
  */
  subscribeEvents(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return stackIntercept6("serverStreaming", this._transport, method, opt, input);
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/name_service.mjs
import { MessageType as MessageType37 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType7 } from "@protobuf-ts/runtime-rpc";
var LookupNameRequest$Type = class extends MessageType37 {
  constructor() {
    super("sui.rpc.v2.LookupNameRequest", [{
      no: 1,
      name: "name",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var LookupNameRequest = new LookupNameRequest$Type();
var LookupNameResponse$Type = class extends MessageType37 {
  constructor() {
    super("sui.rpc.v2.LookupNameResponse", [{
      no: 1,
      name: "record",
      kind: "message",
      T: () => NameRecord
    }]);
  }
};
var LookupNameResponse = new LookupNameResponse$Type();
var ReverseLookupNameRequest$Type = class extends MessageType37 {
  constructor() {
    super("sui.rpc.v2.ReverseLookupNameRequest", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var ReverseLookupNameRequest = new ReverseLookupNameRequest$Type();
var ReverseLookupNameResponse$Type = class extends MessageType37 {
  constructor() {
    super("sui.rpc.v2.ReverseLookupNameResponse", [{
      no: 1,
      name: "record",
      kind: "message",
      T: () => NameRecord
    }]);
  }
};
var ReverseLookupNameResponse = new ReverseLookupNameResponse$Type();
var NameRecord$Type = class extends MessageType37 {
  constructor() {
    super("sui.rpc.v2.NameRecord", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "registration_nft_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "expiration_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 5,
        name: "target_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "data",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 9
        }
      }
    ]);
  }
};
var NameRecord = new NameRecord$Type();
var NameService = new ServiceType7("sui.rpc.v2.NameService", [{
  name: "LookupName",
  options: {},
  I: LookupNameRequest,
  O: LookupNameResponse
}, {
  name: "ReverseLookupName",
  options: {},
  I: ReverseLookupNameRequest,
  O: ReverseLookupNameResponse
}]);

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/name_service.client.mjs
import { stackIntercept as stackIntercept7 } from "@protobuf-ts/runtime-rpc";
var NameServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = NameService.typeName;
    this.methods = NameService.methods;
    this.options = NameService.options;
  }
  /**
  * @generated from protobuf rpc: LookupName(sui.rpc.v2.LookupNameRequest) returns (sui.rpc.v2.LookupNameResponse);
  */
  lookupName(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept7("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ReverseLookupName(sui.rpc.v2.ReverseLookupNameRequest) returns (sui.rpc.v2.ReverseLookupNameResponse);
  */
  reverseLookupName(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept7("unary", this._transport, method, opt, input);
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/forking/v1alpha/forking_service.mjs
import { MessageType as MessageType38 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType8 } from "@protobuf-ts/runtime-rpc";
var AdvanceClockRequest$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.AdvanceClockRequest", [{
      no: 1,
      name: "duration_ms",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var AdvanceClockRequest = new AdvanceClockRequest$Type();
var AdvanceClockResponse$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.AdvanceClockResponse", [{
      no: 1,
      name: "timestamp_ms",
      kind: "scalar",
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "tx_digest",
      kind: "scalar",
      T: 9
    }]);
  }
};
var AdvanceClockResponse = new AdvanceClockResponse$Type();
var AdvanceCheckpointRequest$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.AdvanceCheckpointRequest", []);
  }
};
var AdvanceCheckpointRequest = new AdvanceCheckpointRequest$Type();
var AdvanceCheckpointResponse$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.AdvanceCheckpointResponse", [{
      no: 1,
      name: "checkpoint_sequence_number",
      kind: "scalar",
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "timestamp_ms",
      kind: "scalar",
      T: 4,
      L: 0
    }]);
  }
};
var AdvanceCheckpointResponse = new AdvanceCheckpointResponse$Type();
var GetStatusRequest$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.GetStatusRequest", []);
  }
};
var GetStatusRequest = new GetStatusRequest$Type();
var GetStatusResponse$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.GetStatusResponse", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "checkpoint_sequence_number",
        kind: "scalar",
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "timestamp_ms",
        kind: "scalar",
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "forked_at_checkpoint",
        kind: "scalar",
        T: 4,
        L: 0
      }
    ]);
  }
};
var GetStatusResponse = new GetStatusResponse$Type();
var ForkingService = new ServiceType8("sui.forking.v1alpha.ForkingService", [
  {
    name: "AdvanceClock",
    options: {},
    I: AdvanceClockRequest,
    O: AdvanceClockResponse
  },
  {
    name: "AdvanceCheckpoint",
    options: {},
    I: AdvanceCheckpointRequest,
    O: AdvanceCheckpointResponse
  },
  {
    name: "GetStatus",
    options: {},
    I: GetStatusRequest,
    O: GetStatusResponse
  }
]);

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/proto/sui/forking/v1alpha/forking_service.client.mjs
import { stackIntercept as stackIntercept8 } from "@protobuf-ts/runtime-rpc";
var ForkingServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = ForkingService.typeName;
    this.methods = ForkingService.methods;
    this.options = ForkingService.options;
  }
  /**
  * Advance the forked network's clock by a given duration.
  *
  * @generated from protobuf rpc: AdvanceClock(sui.forking.v1alpha.AdvanceClockRequest) returns (sui.forking.v1alpha.AdvanceClockResponse);
  */
  advanceClock(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept8("unary", this._transport, method, opt, input);
  }
  /**
  * Seal pending transactions into a new checkpoint.
  *
  * @generated from protobuf rpc: AdvanceCheckpoint(sui.forking.v1alpha.AdvanceCheckpointRequest) returns (sui.forking.v1alpha.AdvanceCheckpointResponse);
  */
  advanceCheckpoint(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept8("unary", this._transport, method, opt, input);
  }
  /**
  * Return the current state of the forked network.
  *
  * @generated from protobuf rpc: GetStatus(sui.forking.v1alpha.GetStatusRequest) returns (sui.forking.v1alpha.GetStatusResponse);
  */
  getStatus(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return stackIntercept8("unary", this._transport, method, opt, input);
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/client.mjs
import { fromBase64 as fromBase6414, toBase64 as toBase6413 } from "@mysten/utils";
import { GrpcWebFetchTransport } from "@protobuf-ts/grpcweb-transport";
var SUI_CLIENT_BRAND = /* @__PURE__ */ Symbol.for("@mysten/SuiGrpcClient");
var SuiGrpcClient = class extends BaseClient {
  get mvr() {
    return this.core.mvr;
  }
  get [SUI_CLIENT_BRAND]() {
    return true;
  }
  constructor(options) {
    super({ network: options.network });
    const transport = options.transport ?? new GrpcWebFetchTransport({
      baseUrl: options.baseUrl,
      fetchInit: options.fetchInit
    });
    this.transactionExecutionService = new TransactionExecutionServiceClient(transport);
    this.ledgerService = new LedgerServiceClient(transport);
    this.stateService = new StateServiceClient(transport);
    this.subscriptionService = new SubscriptionServiceClient(transport);
    this.movePackageService = new MovePackageServiceClient(transport);
    this.signatureVerificationService = new SignatureVerificationServiceClient(transport);
    this.nameService = new NameServiceClient(transport);
    this.forkingService = new ForkingServiceClient(transport);
    this.core = new GrpcCoreClient({
      client: this,
      base: this,
      network: options.network,
      mvr: options.mvr
    });
  }
  getObjects(input) {
    return this.core.getObjects(input);
  }
  getObject(input) {
    return this.core.getObject(input);
  }
  listCoins(input) {
    return this.core.listCoins(input);
  }
  listOwnedObjects(input) {
    return this.core.listOwnedObjects(input);
  }
  getBalance(input) {
    return this.core.getBalance(input);
  }
  listBalances(input) {
    return this.core.listBalances(input);
  }
  getCoinMetadata(input) {
    return this.core.getCoinMetadata(input);
  }
  getTransaction(input) {
    return this.core.getTransaction(input);
  }
  executeTransaction(input) {
    return this.core.executeTransaction(input);
  }
  signAndExecuteTransaction(input) {
    return this.core.signAndExecuteTransaction(input);
  }
  waitForTransaction(input) {
    return this.core.waitForTransaction(input);
  }
  simulateTransaction(input) {
    return this.core.simulateTransaction(input);
  }
  getReferenceGasPrice(input) {
    return this.core.getReferenceGasPrice(input);
  }
  getCurrentSystemState(input) {
    return this.core.getCurrentSystemState(input);
  }
  getProtocolConfig(input) {
    return this.core.getProtocolConfig(input);
  }
  getChainIdentifier(input) {
    return this.core.getChainIdentifier(input);
  }
  async listDynamicFields(input) {
    const includeValue = input.include?.value ?? false;
    const paths = [
      "field_id",
      "name",
      "value_type",
      "kind",
      "child_id"
    ];
    if (includeValue) paths.push("value");
    const response = await this.stateService.listDynamicFields({
      parent: input.parentId,
      pageToken: input.cursor ? fromBase6414(input.cursor) : void 0,
      pageSize: input.limit,
      readMask: { paths }
    }, { abort: input.signal });
    return {
      dynamicFields: response.response.dynamicFields.map((field) => {
        const isDynamicObject = field.kind === DynamicField_DynamicFieldKind.OBJECT;
        const fieldType = isDynamicObject ? `0x2::dynamic_field::Field<0x2::dynamic_object_field::Wrapper<${field.name?.name}>,0x2::object::ID>` : `0x2::dynamic_field::Field<${field.name?.name},${field.valueType}>`;
        return {
          $kind: isDynamicObject ? "DynamicObject" : "DynamicField",
          fieldId: field.fieldId,
          name: {
            type: field.name?.name,
            bcs: field.name?.value
          },
          valueType: field.valueType,
          type: normalizeStructTag(fieldType),
          childId: field.childId,
          value: includeValue ? {
            type: field.valueType,
            bcs: field.value?.value ?? new Uint8Array()
          } : void 0
        };
      }),
      cursor: response.response.nextPageToken ? toBase6413(response.response.nextPageToken) : null,
      hasNextPage: response.response.nextPageToken !== void 0
    };
  }
  getDynamicField(input) {
    return this.core.getDynamicField(input);
  }
  getDynamicObjectField(input) {
    return this.core.getDynamicObjectField(input);
  }
  listTransactions(input) {
    return this.core.listTransactions(input);
  }
  listEvents(input) {
    return this.core.listEvents(input);
  }
  getMoveFunction(input) {
    return this.core.getMoveFunction(input);
  }
  resolveTransactionPlugin() {
    return this.core.resolveTransactionPlugin();
  }
  verifyZkLoginSignature(input) {
    return this.core.verifyZkLoginSignature(input);
  }
  defaultNameServiceName(input) {
    return this.core.defaultNameServiceName(input);
  }
  resolveNameServiceAddress(input) {
    return this.core.resolveNameServiceAddress(input);
  }
};

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/node_modules/@mysten/sui/dist/grpc/index.mjs
import { GrpcWebFetchTransport as GrpcWebFetchTransport2 } from "@protobuf-ts/grpcweb-transport";

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/scripts/arcade-campaigns/pilot-auth.mjs
var PILOT_SESSION_SCOPE = "challenge-pilot";
var PILOT_TOKEN = /^pilot_[a-f0-9]{64}$/;
var PILOT_AUTH_ACTIONS = ["auth-challenge", "auth-session", "auth-logout"];
var WALLET = /^0x[a-f0-9]{64}$/;
var UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
var ORIGINS = ["https://tree-token.xyz", "https://www.tree-token.xyz"];
var CHALLENGE_MS = 5 * 6e4;
var SESSION_MS = 60 * 6e4;
var CLOCK_HEADROOM_MS = 1e4;
var hash = (value) => createHash3("sha256").update(value).digest("hex");
var exact2 = (value, keys) => value !== null && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key));
var unavailable = () => new PilotError("verification-unavailable", "Pilot sign-in verification is temporarily unavailable. Please try again.", 503);
var badChallenge = () => new PilotError("invalid-challenge", "Request a fresh pilot sign-in message.", 403);
function pilotSignInMessage({ wallet, origin, challengeId, expiresAt }) {
  if (!WALLET.test(wallet || "") || !ORIGINS.includes(origin) || !UUID.test(challengeId || "") || !Number.isFinite(Date.parse(expiresAt))) throw badChallenge();
  return [
    "TREE Arcade \u2014 Free Challenge Pilot Sign-In",
    "",
    "Audience: tree-arcade:challenge-pilot:v1",
    "Origin: " + origin,
    "URI: " + origin + "/play/challenge/",
    "Wallet: " + wallet,
    "Nonce: " + challengeId,
    "Expires: " + new Date(expiresAt).toISOString(),
    "",
    "Authorize up to one hour of access only to the free, no-prize challenge pilot.",
    "No NFTree or purchase is required for this pilot.",
    "This message grants no check-ins, rewards, event access, payments, transfers, or other Arcade permissions.",
    "No blockchain transaction will be submitted."
  ].join("\n");
}
async function verifyPilotPersonalMessage({ message, signature, wallet }, { zkLoginClient } = {}) {
  let parsed;
  try {
    parsed = parseSerializedSignature(signature);
  } catch {
    return false;
  }
  if (parsed.signatureScheme === "MultiSig" && parsed.multisig.multisig_pk.pk_map.some(({ pubKey }) => Object.hasOwn(pubKey, "ZkLogin") || Object.hasOwn(pubKey, "Passkey"))) {
    throw new PilotError("unsupported-signature", "This multisignature wallet format is not supported by the pilot\u2019s pinned verifier.", 400);
  }
  const client = zkLoginClient || new SuiGrpcClient({ network: "mainnet", baseUrl: "https://fullnode.mainnet.sui.io:443" });
  const boundedClient = { core: { verifyZkLoginSignature: (options) => client.core.verifyZkLoginSignature({ ...options, signal: AbortSignal.timeout(8e3) }) } };
  try {
    return await isValidPersonalMessageSignature(new TextEncoder().encode(message), signature, { address: wallet, client: boundedClient });
  } catch {
    throw unavailable();
  }
}
function createPilotAuthenticator({ rpc, clock = Date.now, entropy = randomBytes, nonce = randomUUID, verifyPersonalMessage = verifyPilotPersonalMessage }) {
  function validChallenge(record, wallet, origin) {
    if (!record || !UUID.test(record.id || "") || record.wallet !== wallet || record.origin !== origin || record.consumedAt !== null || !Number.isFinite(Date.parse(record.expiresAt)) || Date.parse(record.expiresAt) <= clock() || record.message !== pilotSignInMessage({ wallet, origin, challengeId: record.id, expiresAt: record.expiresAt })) throw badChallenge();
    return record;
  }
  return async ({ action, body, origin, authorization }) => {
    if (!ORIGINS.includes(origin)) throw new PilotError("origin-not-allowed", "Use the official TREE Arcade.", 403);
    if (action === "auth-challenge") {
      if (!exact2(body, ["wallet"]) || !WALLET.test(body.wallet || "")) throw new PilotError("invalid-request", "Choose a valid Sui wallet.");
      const challengeId = nonce(), expiresAt = new Date(clock() + CHALLENGE_MS - CLOCK_HEADROOM_MS).toISOString();
      const message = pilotSignInMessage({ wallet: body.wallet, origin, challengeId, expiresAt });
      const record = validChallenge(await rpc("arcade_challenge_pilot_auth_create_challenge_v1", {
        p_challenge_id: challengeId,
        p_wallet: body.wallet,
        p_origin: origin,
        p_message: message,
        p_expires_at: expiresAt
      }), body.wallet, origin);
      if (record.id !== challengeId || record.message !== message) throw unavailable();
      return { challenge: { challengeId: record.id, wallet: record.wallet, origin: record.origin, message: record.message, expiresAt: record.expiresAt, sessionScope: PILOT_SESSION_SCOPE } };
    }
    if (action === "auth-session") {
      if (!exact2(body, ["wallet", "challengeId", "signature"]) || !WALLET.test(body.wallet || "") || !UUID.test(body.challengeId || "") || typeof body.signature !== "string" || body.signature.length < 1 || body.signature.length > 16384) throw new PilotError("invalid-request", "Provide the current pilot sign-in message and wallet signature.");
      const record = validChallenge(await rpc("arcade_challenge_pilot_auth_read_challenge_v1", { p_challenge_id: body.challengeId }), body.wallet, origin);
      if (record.id !== body.challengeId) throw badChallenge();
      let verified;
      try {
        verified = await verifyPersonalMessage({ message: record.message, signature: body.signature, wallet: body.wallet });
      } catch (error) {
        if (error instanceof PilotError) throw error;
        throw unavailable();
      }
      if (verified !== true) throw new PilotError("invalid-signature", "The signature does not authorize this pilot sign-in.", 403);
      const token = "pilot_" + entropy(32).toString("hex");
      if (!PILOT_TOKEN.test(token)) throw unavailable();
      const session = await rpc("arcade_challenge_pilot_auth_create_session_v1", {
        p_challenge_id: record.id,
        p_wallet: body.wallet,
        p_origin: origin,
        p_token_sha256: hash(token),
        p_expires_at: new Date(clock() + SESSION_MS - CLOCK_HEADROOM_MS).toISOString()
      });
      if (!session || session.wallet !== body.wallet || session.origin !== origin || session.sessionScope !== PILOT_SESSION_SCOPE || session.revoked !== false || !Number.isFinite(Date.parse(session.expiresAt)) || Date.parse(session.expiresAt) <= clock() || Date.parse(session.expiresAt) > clock() + SESSION_MS + 1e4) throw unavailable();
      return { session: { version: 1, token, wallet: session.wallet, origin: session.origin, expiresAt: session.expiresAt, sessionScope: PILOT_SESSION_SCOPE } };
    }
    if (action === "auth-logout") {
      if (!exact2(body, [])) throw new PilotError("invalid-request", "Send an empty logout request.");
      const token = /^Bearer (pilot_[a-f0-9]{64})$/.exec(authorization || "")?.[1];
      if (!token) throw new PilotError("invalid-session", "Use this pilot\u2019s sign-in to sign out.", 401);
      const revoked = await rpc("arcade_challenge_pilot_auth_revoke_session_v1", { p_token_sha256: hash(token), p_origin: origin });
      if (typeof revoked !== "boolean") throw unavailable();
      return { signedOut: true, sessionScope: PILOT_SESSION_SCOPE };
    }
    throw new PilotError("not-found", "Unknown pilot sign-in action.", 404);
  };
}

// ../../../../../tmp/arcade-challenge-pilot-bcJdfv/netlify/challenge-functions/arcade-challenge-pilot.mjs
var ORIGINS2 = ["https://tree-token.xyz", "https://www.tree-token.xyz"];
var HEX = /^[a-f0-9]{64}$/;
var UUID2 = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
var FLAGS = { mode: "nonpaying-pilot", identityScope: "wallet-session-only", payable: false, prizeEligible: false, awardsEnabled: false };
var hash2 = (text) => createHash4("sha256").update(text).digest("hex");
var plain3 = (value) => value !== null && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
var exact3 = (value, keys) => plain3(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key));
var json = (body, status = 200) => Response.json(body, { status, headers: { "Cache-Control": "no-store", "Netlify-CDN-Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
var unavailable2 = () => new PilotError("service-unavailable", "Challenge verification is temporarily unavailable.", 503);
async function readBody(req, maxBytes = 4096) {
  if (!/^application\/json(?:\s*;|$)/i.test(req.headers.get("content-type") || "") || req.headers.has("content-encoding")) throw new PilotError("invalid-request", "Send an uncompressed JSON request.");
  const reader = req.body?.getReader(), decoder = new TextDecoder("utf-8", { fatal: true });
  let text = "", size = 0;
  try {
    if (reader) for (; ; ) {
      const part = await reader.read();
      if (part.done) break;
      size += part.value.byteLength;
      if (size > maxBytes) {
        await reader.cancel();
        throw new PilotError("request-too-large", "The request is too large.", 413);
      }
      text += decoder.decode(part.value, { stream: true });
    }
    text += decoder.decode();
    const body = JSON.parse(text);
    if (!plain3(body)) throw Error("object required");
    return body;
  } catch (error) {
    if (error instanceof PilotError) throw error;
    throw new PilotError("invalid-request", "Send a valid JSON object.");
  }
}
function validSession(session, origin, now) {
  if (!Number.isFinite(now) || !session || session.revoked !== false || session.origin !== origin || !/^0x[a-f0-9]{64}$/.test(session.wallet || "") || !Number.isFinite(Date.parse(session.expiresAt)) || Date.parse(session.expiresAt) <= now) throw new PilotError("invalid-session", "Sign in to the Arcade again.", 401);
  return session;
}
function challengeForAttempt(record, session, base) {
  if (!plain3(record) || record.wallet !== session.wallet || record.origin !== base.p_origin || record.sessionHash !== base.p_token_sha256 || !UUID2.test(record.attemptId || "") || !HEX.test(record.seedHex || "") || !HEX.test(record.challengeHash || "") || !Array.isArray(record.moves) || record.moves.length > MAX_MOVES || record.version !== record.moves.length || !["active", "completed"].includes(record.status) || !Number.isFinite(Date.parse(record.serverNow)) || !Number.isFinite(Date.parse(record.startedAt)) || !Number.isFinite(Date.parse(record.expiresAt)) || Date.parse(record.expiresAt) <= Date.parse(record.startedAt) || Date.parse(record.startedAt) > Date.parse(record.serverNow)) throw unavailable2();
  const frozen = verifyPilotRules(record.config);
  if (record.pilotId !== frozen.rules.pilotId || record.rulesHash !== frozen.rulesHash || record.adapterId !== ADAPTER.id || record.adapterVersion !== ADAPTER.version || record.sourceHash !== ADAPTER.sourceHash || Date.parse(record.startedAt) < Date.parse(frozen.rules.window.startsAt) || Date.parse(record.startedAt) >= Date.parse(frozen.rules.window.endsAt) || Date.parse(record.expiresAt) > Date.parse(frozen.rules.window.endsAt) || Date.parse(record.expiresAt) > Date.parse(record.startedAt) + frozen.rules.maxAttemptSeconds * 1e3 || Date.parse(record.expiresAt) > Date.parse(session.expiresAt)) throw unavailable2();
  const challenge = createChallenge(record.seedHex, frozen.rules.challengeDate);
  if (contentHash(challenge) !== record.challengeHash) throw unavailable2();
  return challenge;
}
function derivedResult(replay) {
  return { ...FLAGS, completed: replay.completed, won: replay.completed && replay.won, score: replay.score, rounds: replay.rounds, moveCount: replay.moveCount, ruleTargetMet: replay.completed && replay.won, outcome: replay.view.phase };
}
function stateResponse(record, replay) {
  return {
    status: "ok",
    kind: "arcade-challenge-pilot-state",
    ...FLAGS,
    attemptId: record.attemptId,
    pilotId: record.pilotId,
    rulesHash: record.rulesHash,
    adapterId: ADAPTER.id,
    adapterVersion: ADAPTER.version,
    gameId: ADAPTER.gameId,
    gameVersion: ADAPTER.gameVersion,
    version: record.version,
    startedAt: record.startedAt,
    expiresAt: record.expiresAt,
    serverNow: record.serverNow,
    completedAt: record.completedAt ?? null,
    attemptStatus: record.status,
    view: replay.view,
    result: record.status === "completed" ? record.result : null
  };
}
function checkedPublicResponse(value) {
  if (!plain3(value) || value.status !== "ok" || value.mode !== FLAGS.mode || value.identityScope !== FLAGS.identityScope || value.payable !== false || value.prizeEligible !== false || value.awardsEnabled !== false || !UUID2.test(value.attemptId || "") || !Number.isSafeInteger(value.version) || value.version < 0 || value.version > MAX_MOVES || !plain3(value.view) || !["active", "completed"].includes(value.attemptStatus)) throw unavailable2();
  const forbidden = /* @__PURE__ */ new Set(["seed", "seedHex", "rng", "sessionHash", "token_sha256", "attempt_token_sha256", "secret", "wallet", "origin"]);
  const walk = (item) => {
    if (!item || typeof item !== "object") return;
    for (const [key, child] of Object.entries(item)) {
      if (forbidden.has(key)) throw unavailable2();
      walk(child);
    }
  };
  walk(value);
  if (value.result !== null && (!plain3(value.result) || value.result.payable !== false || value.result.prizeEligible !== false || value.result.awardsEnabled !== false || value.result.identityScope !== FLAGS.identityScope)) throw unavailable2();
  return value;
}
function createChallengePilotHandler(deps = {}) {
  const clock = deps.clock || Date.now, entropy = deps.randomBytes || randomBytes2;
  return async (req) => {
    try {
      const url = new URL(req.url), action = url.searchParams.get("action") || "configuration";
      if (!["configuration", "start", "status", "move", ...PILOT_AUTH_ACTIONS].includes(action)) throw new PilotError("not-found", "Unknown challenge action.", 404);
      if (req.method !== (action === "configuration" ? "GET" : "POST")) throw new PilotError("method-not-allowed", "Method not allowed.", 405);
      const origin = req.headers.get("origin") || url.origin;
      if (!ORIGINS2.includes(origin) || !ORIGINS2.includes(url.origin) || req.headers.get("sec-fetch-site") === "cross-site") throw new PilotError("origin-not-allowed", "Use the official TREE Arcade.", 403);
      if (action === "configuration" && !url.searchParams.has("pilotId")) return json({ status: "ok", ...FLAGS, game: ADAPTER, pilotOpen: false, message: "Arborist Trials pilot support. No funded campaign is open through this service." });
      if (PILOT_AUTH_ACTIONS.includes(action)) {
        const authenticate = createPilotAuthenticator({ rpc: deps.rpc || createPilotRpc(), clock, entropy: deps.authRandomBytes, nonce: deps.authRandomUUID, verifyPersonalMessage: deps.verifyPersonalMessage });
        const result = await authenticate({ action, body: await readBody(req, action === "auth-session" ? 24576 : 4096), origin, authorization: req.headers.get("authorization") });
        return json({ status: "ok", ...FLAGS, ...result });
      }
      const auth = /^Bearer ((?:pilot_)?[a-f0-9]{64})$/.exec(req.headers.get("authorization") || "");
      if (!auth) throw new PilotError("invalid-session", "Sign in to the Arcade first.", 401);
      const rpc = deps.rpc || createPilotRpc(), base = { p_token_sha256: hash2(auth[1]), p_origin: origin };
      const session = validSession(await rpc("arcade_challenge_pilot_read_session_v1", base), origin, clock());
      if (session.sessionScope !== (auth[1].startsWith("pilot_") ? PILOT_SESSION_SCOPE : "arcade")) throw new PilotError("invalid-session", "Sign in to the challenge again.", 401);
      if (action === "configuration") {
        const pilotId = url.searchParams.get("pilotId");
        if (!/^[a-z0-9][a-z0-9-]{5,79}$/.test(pilotId || "")) throw new PilotError("invalid-request", "Choose a valid pilot.");
        const record2 = await rpc("arcade_challenge_pilot_load_config_v1", { ...base, p_pilot_id: pilotId });
        if (!record2) throw new PilotError("pilot-not-found", "This pilot is unavailable.", 404);
        const frozen = verifyPilotRecord(record2), now = Date.parse(record2.serverNow);
        return json({ status: "ok", ...FLAGS, pilotOpen: record2.enabled && now >= Date.parse(record2.startsAt) && now < Date.parse(record2.endsAt), serverNow: record2.serverNow, rulesHash: frozen.rulesHash, rules: frozen.rules });
      }
      const body = await readBody(req);
      if (action === "start") {
        if (!exact3(body, ["pilotId", "expectedRulesHash"]) || !/^[a-z0-9][a-z0-9-]{5,79}$/.test(body.pilotId || "") || !HEX.test(body.expectedRulesHash || "")) throw new PilotError("invalid-request", "Choose a pilot and its current rules.");
        const pilot = await rpc("arcade_challenge_pilot_load_config_v1", { ...base, p_pilot_id: body.pilotId });
        if (!pilot) throw new PilotError("pilot-not-found", "This pilot is unavailable.", 404);
        const frozen = verifyPilotRecord(pilot);
        if (body.expectedRulesHash !== frozen.rulesHash) throw new PilotError("rules-changed", "Reload the pilot rules before starting.", 409);
        const now = Date.parse(pilot.serverNow);
        if (!pilot.enabled || now < Date.parse(pilot.startsAt) || now >= Date.parse(pilot.endsAt)) throw new PilotError("pilot-not-open", "This pilot is not open for play.", 409);
        const attemptToken = entropy(32).toString("hex"), seedHex = entropy(32).toString("hex");
        if (!HEX.test(attemptToken) || !HEX.test(seedHex)) throw unavailable2();
        const challenge2 = createChallenge(seedHex, frozen.rules.challengeDate);
        const record2 = await rpc("arcade_challenge_pilot_start_v1", { ...base, p_pilot_id: body.pilotId, p_rules_hash: frozen.rulesHash, p_attempt_token_sha256: hash2(attemptToken), p_seed_hex: seedHex, p_challenge_hash: contentHash(challenge2) });
        validSession(session, origin, Date.parse(record2.serverNow));
        const bound = challengeForAttempt(record2, session, base);
        if (record2.version !== 0 || record2.seedHex !== seedHex || record2.pilotId !== body.pilotId || record2.rulesHash !== frozen.rulesHash || record2.status !== "active") throw unavailable2();
        return json({ ...checkedPublicResponse(stateResponse(record2, inspectReplay(bound, []))), attemptToken, challenge: publicChallenge(bound) });
      }
      const fields = action === "status" ? ["attemptToken"] : ["attemptToken", "expectedVersion", "requestId", "moveId"];
      if (!exact3(body, fields) || !HEX.test(body.attemptToken || "") || action === "move" && (!Number.isSafeInteger(body.expectedVersion) || body.expectedVersion < 0 || body.expectedVersion >= MAX_MOVES || !UUID2.test(body.requestId || "") || !Number.isSafeInteger(body.moveId) || body.moveId < 1 || body.moveId > 30)) throw new PilotError("invalid-request", "Send only the attempt token and a valid move request.");
      const attemptHash = hash2(body.attemptToken);
      const record = await rpc("arcade_challenge_pilot_load_attempt_v1", { ...base, p_attempt_token_sha256: attemptHash, p_request_id: action === "move" ? body.requestId : null });
      if (!record) throw new PilotError("attempt-not-found", "This attempt is unavailable for this session.", 404);
      validSession(session, origin, Date.parse(record.serverNow));
      const challenge = challengeForAttempt(record, session, base);
      const requestHash = action === "move" ? contentHash({ kind: "arcade-pilot-move-v1", attemptId: record.attemptId, rulesHash: record.rulesHash, expectedVersion: body.expectedVersion, requestId: body.requestId, moveId: body.moveId }) : null;
      if (action === "move" && record.replay) {
        if (record.replay.requestHash !== requestHash || record.replay.expectedVersion !== body.expectedVersion || record.replay.moveId !== body.moveId) throw new PilotError("request-conflict", "This request identifier was already used for a different move.", 409);
        return json(checkedPublicResponse(record.replay.response));
      }
      const before = inspectReplay(challenge, record.moves);
      if (action === "status") return json(checkedPublicResponse(stateResponse(record, before)));
      if (record.status !== "active" || before.completed || before.view.phase === "move-limit") throw new PilotError("attempt-finished", "This attempt has already finished.", 409);
      if (Date.parse(record.serverNow) >= Date.parse(record.expiresAt)) throw new PilotError("attempt-expired", "This attempt has expired.", 409);
      if (record.version !== body.expectedVersion) throw new PilotError("version-conflict", "Reload the attempt before making another move.", 409);
      const next = inspectReplay(challenge, [...record.moves, body.moveId]);
      const terminal = next.completed || next.view.phase === "move-limit";
      const response = stateResponse({ ...record, version: record.version + 1, status: terminal ? "completed" : "active", result: terminal ? derivedResult(next) : null }, next);
      const saved = await rpc("arcade_challenge_pilot_commit_move_v1", { ...base, p_attempt_token_sha256: attemptHash, p_expected_version: body.expectedVersion, p_request_id: body.requestId, p_request_sha256: requestHash, p_move_id: body.moveId, p_public_response: response, p_terminal: terminal, p_result: terminal ? derivedResult(next) : null });
      return json(checkedPublicResponse(saved));
    } catch (error) {
      const failure = error instanceof PilotError ? error : error instanceof TrialReplayError ? new PilotError("illegal-move", "Choose a currently available card.") : unavailable2();
      return json({ status: "error", ...FLAGS, error: failure.code, message: failure.message }, failure.status);
    }
  };
}
var arcade_challenge_pilot_default = createChallengePilotHandler();
var config = { path: "/api/arcade-challenge-pilot", method: ["GET", "POST"], rateLimit: { action: "rate_limit", aggregateBy: ["domain", "ip"], windowSize: 60, windowLimit: 60 } };
export {
  config,
  createChallengePilotHandler,
  arcade_challenge_pilot_default as default
};
