
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// contracts/nftree-generation/scripts/acknowledgement-handoff.mjs
import assert5 from "node:assert/strict";
import { bcs as bcs3 } from "@mysten/sui/bcs";

// contracts/nftree-generation/scripts/readiness.mjs
import assert from "node:assert/strict";
import { Transaction } from "@mysten/sui/transactions";
import { SuiGraphQLClient } from "@mysten/sui/graphql";
import { bcs } from "@mysten/sui/bcs";
var C = Object.freeze({
  sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
  nft: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
  nftType: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT",
  oappPackage: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24",
  graphql: "https://graphql.mainnet.sui.io/graphql",
  chain: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
  maxGasMist: 200000000n
});
function readOnlyFetch(fetcher = globalThis.fetch) {
  return async (url, options2) => {
    assert.equal(String(url), C.graphql, "Unexpected endpoint");
    assert.equal(options2?.method, "POST");
    const body = JSON.parse(options2.body);
    assert.equal(typeof body.query, "string");
    assert(!/\b(mutation|executeTransaction)\b/.test(body.query), "Submission is forbidden");
    assert(/^\s*(query\b|\{)/.test(body.query), "Only GraphQL queries allowed");
    return fetcher(url, options2);
  };
}
function newClient() {
  return new SuiGraphQLClient({ network: "mainnet", url: C.graphql, fetch: readOnlyFetch() });
}
function verifyCandidate(data, now = Date.now()) {
  assert.equal(data.chainIdentifier, C.chain);
  const n = data.nft;
  assert.equal(n?.address, C.nft);
  assert.equal(n.owner?.__typename, "AddressOwner");
  assert.equal(n.owner.address.address, C.sender);
  assert.equal(n.asMoveObject?.contents?.type?.repr, C.nftType);
  assert.equal(n.asMoveObject.contents.json.number, "2720");
  assert(n.version && n.digest);
  const age = now - Date.parse(data.checkpoint.timestamp);
  assert(Number.isFinite(age) && age >= -3e4 && age <= 12e4, "Stale checkpoint");
}
async function readCandidate(client) {
  const r = await client.query({ query: `query { chainIdentifier checkpoint { sequenceNumber timestamp }
 nft:object(address:"${C.nft}"){address version digest owner{__typename ... on AddressOwner{address{address}}}
 asMoveObject{contents{type{repr} json}}}}`, signal: AbortSignal.timeout(2e4) });
  assert(!r.errors);
  verifyCandidate(r.data);
  return r.data;
}

// contracts/nftree-generation/scripts/configuration-encoding.mjs
import { Transaction as Transaction2 } from "@mysten/sui/transactions";
import { bcs as bcs2 } from "@mysten/sui/bcs";

// contracts/nftree-generation/scripts/configuration-identities.json
var configuration_identities_default = {
  sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
  nft: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
  nftType: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT",
  oappPackage: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24",
  graphql: "https://graphql.mainnet.sui.io/graphql",
  chain: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
  maxGasMist: "20000000",
  package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
  vault: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
  registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
  admin: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
  oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
  oappAdmin: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
  upgrade: "0xb70e2cdc18d562247bc34bf47efee620a05ec1f059cff5e812a8d433a722999d",
  endpoint: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
  endpointPackage: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
  endpointRegistry: "0x720fc2300c05bb7ad68aefec00a9796b4451c4d1df78bc72cd8c98e774220bec",
  vaultAdmin: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
  uln: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
  ulnPackage: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
  executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989",
  receiveCallId: "64202616f75a5614acfa264418258521299eb6a892eeeea392feef8948c7eb53",
  dvns: [
    "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
    "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
    "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
  ],
  channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
  channelVersion: "1089269258",
  registration: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
  registrationDigest: "DF8dMqSXXtYBoemHsPYk2QJDkuUY2m8zTRDdcu6Y9DFt",
  remoteEid: 30102
};

// contracts/nftree-generation/scripts/configuration-encoding.mjs
var C2 = Object.freeze(configuration_identities_default);
var Arg = bcs2.enum("Argument", { ID: bcs2.vector(bcs2.u8()), Object: bcs2.Address, Pure: bcs2.vector(bcs2.u8()), NestedResult: bcs2.struct("NestedResult", { call_index: bcs2.u16(), result_index: bcs2.u16() }) });
var Calls = bcs2.vector(bcs2.struct("MoveCall", { function: bcs2.struct("Function", { package: bcs2.Address, module_name: bcs2.string(), name: bcs2.string() }), arguments: bcs2.vector(Arg), type_arguments: bcs2.vector(bcs2.string()), is_builder_call: bcs2.bool(), result_ids: bcs2.vector(bcs2.vector(bcs2.u8())) }));
var Info = bcs2.struct("OAppInfoV1", { oapp_object: bcs2.Address, next_nonce_info: bcs2.vector(bcs2.u8()), lz_receive_info: bcs2.vector(bcs2.u8()), extra_info: bcs2.vector(bcs2.u8()) });
var Uln = bcs2.struct("OAppUlnConfig", { use_default_confirmations: bcs2.bool(), use_default_required_dvns: bcs2.bool(), use_default_optional_dvns: bcs2.bool(), uln_config: bcs2.struct("UlnConfig", { confirmations: bcs2.u64(), required_dvns: bcs2.vector(bcs2.Address), optional_dvns: bcs2.vector(bcs2.Address), optional_dvn_threshold: bcs2.u8() }) });
var Executor = bcs2.struct("ExecutorConfig", { max_message_size: bcs2.u64(), executor: bcs2.Address });
var canonical = (x2) => JSON.stringify(x2, (_2, v2) => v2 && typeof v2 === "object" && !Array.isArray(v2) ? Object.fromEntries(Object.entries(v2).sort(([a], [b2]) => a.localeCompare(b2))) : v2);
var ulnValue = (confirmations) => ({ use_default_confirmations: false, use_default_required_dvns: false, use_default_optional_dvns: false, uln_config: { confirmations: String(confirmations), required_dvns: [...C2.dvns], optional_dvns: [], optional_dvn_threshold: 0 } });
function metadata() {
  const calls = [{ function: { package: C2.package, module_name: "vault", name: "lz_receive" }, arguments: [{ Object: C2.vault }, { Object: C2.oapp }, { ID: Array.from(Uint8Array.from(C2.receiveCallId.match(/../g), (v2) => parseInt(v2, 16))) }], type_arguments: [C2.nftType], is_builder_call: false, result_ids: [] }];
  return Uint8Array.from([0, 1, ...Info.serialize({ oapp_object: C2.oapp, next_nonce_info: [], lz_receive_info: [0, 1, ...Calls.serialize(calls).toBytes()], extra_info: [] }).toBytes()]);
}
var metadataBase64 = () => btoa(String.fromCharCode(...metadata()));
var fields = "address version digest owner{__typename ... on Shared{initialSharedVersion} ... on AddressOwner{address{address}}} asMoveObject{contents{type{repr} json}}";
var key = btoa(String.fromCharCode(...Uint8Array.from((C2.package.slice(2) + "96750000").match(/../g), (v2) => parseInt(v2, 16))));
var tables = Object.freeze({ libraries: ["0xa2371851318b3ba333270daf696dedbc7b89a1107ca362643798c1789ce05a01", "u32", "lnUAAA=="], send: ["0x2bd7d044d837b718a7852959c701c04e842e648cf9047b442d55c838846a13e5", "u32", "lnUAAA=="], receive: ["0x5ddc28272722231ecef30237bb48715f128d6995b89a46db25cd9adae0140835", "u32", "lnUAAA=="], executor: ["0x346b468d90db8743673c7ed4fdbe1c40f6a587aac6acc730b3a9bb86cf0919f4", "u32", "lnUAAA=="], appLibraries: ["0x0e679b0fcc94fb07a5ec9a14712f8e35e0994b892e64a434e898450eb670e920", C2.endpointPackage + "::message_lib_manager::OAppConfigKey", key], appSend: ["0xc53b8a5592cdeea1a7421d209ba5c70e6843d2911e5bb86ad9fb744d888eab60", C2.ulnPackage + "::send_uln::OAppConfigKey", key], appReceive: ["0x0d89da4d00f46c4b1dab465a867e60eacbf646e56f8816ae55cd7b9495c1bb09", C2.ulnPackage + "::receive_uln::OAppConfigKey", key], appExecutor: ["0x357a98886ef14de3d15e538a808b410cfe026f6b1f971bb2398978d56e4dc181", C2.ulnPackage + "::send_uln::OAppConfigKey", key] });
var STATE_QUERY = "query { chainIdentifier checkpoint{sequenceNumber timestamp} " + Object.entries({ endpoint: C2.endpoint, uln: C2.uln, oapp: C2.oapp, admin: C2.admin, vault: C2.vault, channel: C2.channel, registration: C2.registration }).map(([n, id]) => n + ':object(address:"' + id + '"){' + fields + "}").join(" ") + " " + Object.entries(tables).map(([n, [id, type, key2]]) => n + ':address(address:"' + id + '"){dynamicField(name:{type:"' + type + '",bcs:"' + key2 + '"}){value{... on MoveValue{json}}}}').join(" ") + "}";

// contracts/nftree-generation/scripts/configuration-review.mjs
import { deriveDynamicFieldID } from "@mysten/sui/utils";

// docs/multichain/generation-milestone/configuration-review/baseline.json
var baseline_default = {
  checkpoint: {
    sequenceNumber: 348223740,
    timestamp: "2026-11-23T04:16:13.683Z"
  },
  endpoint: {
    address: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
    version: 1089269258,
    digest: "7KKLMt5sQiGPhFLHNRdqBs66sm5viuvUQ9Jqxrw4rqKx",
    owner: {
      __typename: "Shared",
      initialSharedVersion: 635685314
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::endpoint_v2::EndpointV2"
        },
        json: {
          id: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
          eid: 30378,
          call_cap: {
            id: "0x8de954b904b90f887ff2e81ff3362ca89e883da6529e55723758cd5093234b0d",
            cap_type: {
              "@variant": "Package",
              pos0: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac"
            }
          },
          oapp_registry: {
            oapps: {
              id: "0x720fc2300c05bb7ad68aefec00a9796b4451c4d1df78bc72cd8c98e774220bec",
              size: "143"
            }
          },
          composer_registry: {
            composers: {
              id: "0xb41ca35805177b946bebf5d339712b4e9bb562b068b33851001f9f0b66847814",
              size: "7"
            }
          },
          message_lib_manager: {
            registry: {
              libs: {
                contents: {
                  id: "0x520bbc08883e22efb29f50283e25b4561ffa7c7b9d7774b14fc1c6272e593e03",
                  size: "2"
                }
              },
              lib_to_type: {
                id: "0xb136bb2fc780a76e636c10f10b10ab33754a3573efa5f1285bf2b35eaf73b50d",
                size: "2"
              }
            },
            default_configs: {
              id: "0xa2371851318b3ba333270daf696dedbc7b89a1107ca362643798c1789ce05a01",
              size: "126"
            },
            oapp_configs: {
              id: "0x0e679b0fcc94fb07a5ec9a14712f8e35e0994b892e64a434e898450eb670e920",
              size: "100"
            }
          }
        }
      }
    }
  },
  uln: {
    address: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
    version: 1096510921,
    digest: "3X8N5Tg1GzQXZPtWGvDu6GhhDrjUy5aL1h486XDuETaY",
    owner: {
      __typename: "Shared",
      initialSharedVersion: 635685319
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0::uln_302::Uln302"
        },
        json: {
          id: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
          call_cap: {
            id: "0xfacd801d08e3a99c907148fa00ec5f17a0a3ac831dbc95bcd75e601006caafa9",
            cap_type: {
              "@variant": "Package",
              pos0: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0"
            }
          },
          send_uln: {
            default_executor_configs: {
              id: "0x346b468d90db8743673c7ed4fdbe1c40f6a587aac6acc730b3a9bb86cf0919f4",
              size: "126"
            },
            default_uln_configs: {
              id: "0x2bd7d044d837b718a7852959c701c04e842e648cf9047b442d55c838846a13e5",
              size: "126"
            },
            oapp_executor_configs: {
              id: "0x357a98886ef14de3d15e538a808b410cfe026f6b1f971bb2398978d56e4dc181",
              size: "54"
            },
            oapp_uln_configs: {
              id: "0xc53b8a5592cdeea1a7421d209ba5c70e6843d2911e5bb86ad9fb744d888eab60",
              size: "214"
            }
          },
          receive_uln: {
            default_uln_configs: {
              id: "0x5ddc28272722231ecef30237bb48715f128d6995b89a46db25cd9adae0140835",
              size: "126"
            },
            oapp_uln_configs: {
              id: "0x0d89da4d00f46c4b1dab465a867e60eacbf646e56f8816ae55cd7b9495c1bb09",
              size: "239"
            },
            verification: "0x950f66ed27ec0a01a52bda147d74165d4cc20165f0cee0ecae6aaacde13d7741"
          }
        }
      }
    }
  },
  oapp: {
    address: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
    version: 1,
    digest: "7LeHSzqW2xxEA7QrcimgN8c7ZKaAJUL3fwvjNy9wnoar",
    owner: {
      __typename: "Shared",
      initialSharedVersion: 1
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::OApp"
        },
        json: {
          id: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
          oapp_cap: {
            id: "0x6b7c66d2135ce12efa6a23037bff2e5ca1b499db24bc200592d08c2595cf5a3a",
            cap_type: {
              "@variant": "Package",
              pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
            }
          },
          admin_cap: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
          peer: {
            peers: {
              id: "0x984eb93d6713b0909152e249bcfa465a6661e7403c5b01266353b97ff2318966",
              size: "0"
            }
          },
          enforced_options: {
            options: {
              id: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
              size: "0"
            }
          },
          sending_call: null
        }
      }
    }
  },
  admin: {
    address: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
    version: 1,
    digest: "CRHN2g1UWgQYiN9TVWbRf8CcTd9FMtr2ky2jnfx79VVB",
    owner: {
      __typename: "AddressOwner",
      address: {
        address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
      }
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::AdminCap"
        },
        json: {
          id: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d"
        }
      }
    }
  },
  vault: {
    address: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
    version: 2,
    digest: "EiVf4xEufWiA56rUMda9QJ7bSYtP6XDDdWHQcxyP1gJq",
    owner: {
      __typename: "Shared",
      initialSharedVersion: 2
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Vault<0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT>"
        },
        json: {
          id: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
          version: "1",
          registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
          cap: {
            id: "0x1711b6b0e442e8299ea3aceb30286234520c8f1c4d2294aa7d031308a3d7bcff",
            cap_type: {
              "@variant": "Package",
              pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
            }
          },
          oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
          nft: null,
          backing: {
            bytes: "BG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWpro="
          },
          route: {
            bytes: "9d/44syWgk+Jc1+hbAaO6BlPu36NaXruvl0TX4pZFus="
          },
          peer: {
            bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
          },
          bound: false,
          paused: false,
          phase: 0,
          generation: "0",
          announced: false,
          ack_sent: false,
          request: {
            bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
          },
          recipient: {
            bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
          }
        }
      }
    }
  },
  channel: {
    address: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
    version: 1089269258,
    digest: "864jUfZhozh3q9nS2x8Pu7WmX8fQxL7iidcGXqp6nbUm",
    owner: {
      __typename: "Shared",
      initialSharedVersion: 1089269258
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::MessagingChannel"
        },
        json: {
          id: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
          oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
          channels: {
            id: "0xc631f02da694ee43bc4923570de9f6d53cbccbdb72986cf63dc84e77744c0e95",
            size: "0"
          },
          is_sending: false
        }
      }
    }
  },
  registration: {
    address: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
    version: 1089269258,
    digest: "7adt8jhhsGqFZMbKHoWje3qLDKWWLMehF7Zf9SduGeei",
    owner: {
      __typename: "ObjectOwner"
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<address,0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::oapp_registry::OAppRegistration>"
        },
        json: {
          id: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
          name: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
          value: {
            messaging_channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
            oapp_info: "",
            delegate: "0x0000000000000000000000000000000000000000000000000000000000000000"
          }
        }
      }
    }
  },
  libraries: {
    dynamicField: {
      value: {
        json: {
          send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
          receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
          receive_lib_timeout: null
        }
      }
    }
  },
  send: {
    dynamicField: {
      value: {
        json: {
          confirmations: "5",
          required_dvns: [
            "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
            "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
            "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
            "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
          ],
          optional_dvns: [],
          optional_dvn_threshold: 0
        }
      }
    }
  },
  receive: {
    dynamicField: {
      value: {
        json: {
          confirmations: "20",
          required_dvns: [
            "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
            "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
            "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
            "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
          ],
          optional_dvns: [],
          optional_dvn_threshold: 0
        }
      }
    }
  },
  executor: {
    dynamicField: {
      value: {
        json: {
          max_message_size: "10000",
          executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
        }
      }
    }
  },
  appLibraries: {
    dynamicField: null
  },
  appSend: {
    dynamicField: null
  },
  appReceive: {
    dynamicField: null
  },
  appExecutor: {
    dynamicField: null
  }
};

// contracts/nftree-generation/scripts/configuration-review.mjs
var check = (v2, m) => {
  if (!v2) throw Error(m);
};
var eq = (a, b2, m) => check(canonical(a) === canonical(b2), m);
var json = (o) => o?.asMoveObject?.contents?.json;
var appNames = ["appLibraries", "appExecutor", "appSend", "appReceive"];
var entries = Object.freeze(Object.fromEntries(appNames.map((n) => {
  const [parent, type, key2] = tables[n], [address, module, name] = type.split("::");
  return [n, { id: deriveDynamicFieldID(parent, { struct: { address, module, name, typeParams: [] } }, Uint8Array.from(atob(key2), (x2) => x2.charCodeAt(0))), parent }];
})));
function validateConfigState(s, stage = 0) {
  check(stage === 0 || stage === 1, "Unknown route configuration stage.");
  for (const name of ["endpoint", "uln", "oapp", "admin", "vault", "channel", "registration"]) {
    const a = s[name], b2 = baseline_default[name];
    check(a?.address === b2.address, "Wrong " + name + " object.");
    eq(a.owner, b2.owner, name + " ownership changed.");
    eq(a.asMoveObject?.contents?.type, b2.asMoveObject.contents.type, name + " type changed.");
  }
  for (const name of ["oapp", "admin", "vault", "channel"]) eq(json(s[name]), json(baseline_default[name]), "Original " + name + " changed. Verify wallet activity.");
  const endpoint = json(s.endpoint), uln = json(s.uln);
  check(endpoint.eid === 30378, "Wrong endpoint ID.");
  eq(endpoint.call_cap, json(baseline_default.endpoint).call_cap, "Endpoint capability changed.");
  eq(uln.call_cap, json(baseline_default.uln).call_cap, "ULN capability changed.");
  for (const [actual, expected] of [[endpoint.message_lib_manager.default_configs.id, tables.libraries[0]], [endpoint.message_lib_manager.oapp_configs.id, tables.appLibraries[0]], [uln.send_uln.oapp_executor_configs.id, tables.appExecutor[0]], [uln.send_uln.oapp_uln_configs.id, tables.appSend[0]], [uln.receive_uln.oapp_uln_configs.id, tables.appReceive[0]]]) check(actual === expected, "Protocol configuration table changed.");
  for (const n of ["libraries", "executor", "send", "receive"]) eq(s[n], baseline_default[n], "Protocol default " + n + " changed. Review before continuing.");
  const reg = structuredClone(json(baseline_default.registration));
  if (stage === 1) reg.value.oapp_info = metadataBase64();
  eq(json(s.registration), reg, "Registration channel, metadata or delegate changed.");
  for (const n of appNames) check(s[n] && Object.hasOwn(s[n], "dynamicField"), "Missing " + n + " lookup.");
  if (stage === 0) {
    for (const n of appNames) check(s[n].dynamicField === null, "Application settings already exist. Check the configuration receipt.");
  } else {
    const get = (n) => s[n].dynamicField?.value?.json;
    eq(get("appLibraries"), { send_lib: C2.ulnPackage, receive_lib: C2.ulnPackage, receive_lib_timeout: null }, "Application libraries differ.");
    eq(get("appExecutor"), { max_message_size: "10000", executor: C2.executor }, "Application executor differs.");
    eq(get("appSend"), ulnValue(5), "Application send security differs.");
    eq(get("appReceive"), ulnValue(20), "Application receive security differs.");
  }
  return s;
}

// contracts/nftree-generation/scripts/binding-review.mjs
import { Transaction as Transaction3 } from "@mysten/sui/transactions";

// contracts/bnb-generation/browser/pinned-build.json
var pinned_build_default = {
  schema: 1,
  chainId: 56,
  admin: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789",
  treasury: "0xC440F06BBC7e58b0d055815f915447e4ae0E3720",
  peer: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
  route: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
  baseNonce: 4739,
  addresses: {
    adapter: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
    pass: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5"
  },
  gasLimits: [
    "1987828",
    "2298085",
    "65443"
  ],
  maxTotalFeeWei: "1000000000000000",
  remoteCodeHashes: {
    endpoint: "0x5ed1f4ec5f4d6bd5eac1fa92e0fb7474be2607dfc5f3eb82ced1c183b64fbeb9",
    usdt: "0x97a48aa4c129657440dafdacd4c836389734d28cc4a0ca7403e68da660a74a59"
  },
  slotDigest: "GNDWXqgPJnZyeQaVFqnZ1HuXSnSiHUAKV1vL4Ke49yMX",
  registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
  adapter: {
    abi: [
      {
        inputs: [
          {
            internalType: "bytes32",
            name: "peer",
            type: "bytes32"
          },
          {
            internalType: "bytes32",
            name: "routeId",
            type: "bytes32"
          }
        ],
        stateMutability: "nonpayable",
        type: "constructor"
      },
      {
        inputs: [],
        name: "Invalid",
        type: "error"
      },
      {
        inputs: [],
        name: "ReentrancyGuardReentrantCall",
        type: "error"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "bytes32",
            name: "guid",
            type: "bytes32"
          },
          {
            indexed: false,
            internalType: "uint8",
            name: "kind",
            type: "uint8"
          },
          {
            indexed: false,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          }
        ],
        name: "MessageApplied",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "bytes32",
            name: "guid",
            type: "bytes32"
          },
          {
            indexed: false,
            internalType: "uint8",
            name: "kind",
            type: "uint8"
          },
          {
            indexed: false,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          }
        ],
        name: "MessageSent",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "address",
            name: "pass",
            type: "address"
          }
        ],
        name: "PassBound",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: false,
            internalType: "uint128",
            name: "gas",
            type: "uint128"
          }
        ],
        name: "ReceiveGasRaised",
        type: "event"
      },
      {
        inputs: [],
        name: "SUI_EID",
        outputs: [
          {
            internalType: "uint32",
            name: "",
            type: "uint32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            components: [
              {
                internalType: "uint32",
                name: "srcEid",
                type: "uint32"
              },
              {
                internalType: "bytes32",
                name: "sender",
                type: "bytes32"
              },
              {
                internalType: "uint64",
                name: "nonce",
                type: "uint64"
              }
            ],
            internalType: "struct Origin",
            name: "origin",
            type: "tuple"
          }
        ],
        name: "allowInitializePath",
        outputs: [
          {
            internalType: "bool",
            name: "",
            type: "bool"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "backingNFT",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "contract TreeSuitePass",
            name: "p",
            type: "address"
          }
        ],
        name: "bindPass",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "binder",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        name: "delivered",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "endpoint",
        outputs: [
          {
            internalType: "contract ILayerZeroEndpointV2",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            components: [
              {
                internalType: "uint32",
                name: "srcEid",
                type: "uint32"
              },
              {
                internalType: "bytes32",
                name: "sender",
                type: "bytes32"
              },
              {
                internalType: "uint64",
                name: "nonce",
                type: "uint64"
              }
            ],
            internalType: "struct Origin",
            name: "origin",
            type: "tuple"
          },
          {
            internalType: "bytes32",
            name: "guid",
            type: "bytes32"
          },
          {
            internalType: "bytes",
            name: "message",
            type: "bytes"
          },
          {
            internalType: "address",
            name: "",
            type: "address"
          },
          {
            internalType: "bytes",
            name: "",
            type: "bytes"
          }
        ],
        name: "lzReceive",
        outputs: [],
        stateMutability: "payable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint32",
            name: "",
            type: "uint32"
          },
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        name: "nextNonce",
        outputs: [
          {
            internalType: "uint64",
            name: "",
            type: "uint64"
          }
        ],
        stateMutability: "pure",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint8",
            name: "kind",
            type: "uint8"
          }
        ],
        name: "outboundPayload",
        outputs: [
          {
            internalType: "bytes",
            name: "",
            type: "bytes"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "pass",
        outputs: [
          {
            internalType: "contract TreeSuitePass",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint8",
            name: "kind",
            type: "uint8"
          }
        ],
        name: "quote",
        outputs: [
          {
            components: [
              {
                internalType: "uint256",
                name: "nativeFee",
                type: "uint256"
              },
              {
                internalType: "uint256",
                name: "lzTokenFee",
                type: "uint256"
              }
            ],
            internalType: "struct MessagingFee",
            name: "",
            type: "tuple"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "receiveGas",
        outputs: [
          {
            internalType: "uint128",
            name: "",
            type: "uint128"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "receiveOptions",
        outputs: [
          {
            internalType: "bytes",
            name: "",
            type: "bytes"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "route",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint8",
            name: "kind",
            type: "uint8"
          }
        ],
        name: "send",
        outputs: [
          {
            components: [
              {
                internalType: "bytes32",
                name: "guid",
                type: "bytes32"
              },
              {
                internalType: "uint64",
                name: "nonce",
                type: "uint64"
              },
              {
                components: [
                  {
                    internalType: "uint256",
                    name: "nativeFee",
                    type: "uint256"
                  },
                  {
                    internalType: "uint256",
                    name: "lzTokenFee",
                    type: "uint256"
                  }
                ],
                internalType: "struct MessagingFee",
                name: "fee",
                type: "tuple"
              }
            ],
            internalType: "struct MessagingReceipt",
            name: "receipt",
            type: "tuple"
          }
        ],
        stateMutability: "payable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint128",
            name: "gas",
            type: "uint128"
          }
        ],
        name: "setReceiveGas",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "suiPeer",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      }
    ],
    evm: {
      bytecode: {
        object: "60e0604052600280546001600160801b0319166301c9c380179055348015610025575f5ffd5b50604051611cb7380380611cb78339810160408190526100449161019f565b60015f5546603814158061006b5750731a44076050125825900e736c501f859c50fe728c3b155b80610074575081155b8061007d575080155b80610109575061759663ffffffff16731a44076050125825900e736c501f859c50fe728c6001600160a01b031663416ecebf6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156100dc573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061010091906101c1565b63ffffffff1614155b1561012757604051636dac6a0960e01b815260040160405180910390fd5b608082905260a08190523360c081905260405163ca5eb5e160e01b81526004810191909152731a44076050125825900e736c501f859c50fe728c9063ca5eb5e1906024015f604051808303815f87803b158015610182575f5ffd5b505af1158015610194573d5f5f3e3d5ffd5b5050505050506101eb565b5f5f604083850312156101b0575f5ffd5b505080516020909101519092909150565b5f602082840312156101d1575f5ffd5b815163ffffffff811681146101e4575f5ffd5b9392505050565b60805160a05160c051611a5c61025b5f395f818161031901528181610413015281816107930152610a8401525f818161038c0152818161086101528181610d43015261109c01525f8181610196015281816104e101528181610bc6015281816112f901526114100152611a5c5ff3fe608060405260043610610105575f3560e01c80637d25a05e11610092578063b1f8671711610062578063b1f867171461033b578063c13bd9361461034f578063d96661ef1461037b578063e495f1d4146103ae578063ff7bd03d146103d9575f5ffd5b80637d25a05e1461028857806383d5f21d146102bf578063a7a1ed72146102e9578063acba7b4214610308575f5ffd5b806315aff54e116100d857806315aff54e146101855780634922eec1146101c65780634cedb60f146101f25780635e280f111461022957806378360c8814610268575f5ffd5b80630200e86b1461010957806307f53ee71461012a57806310265fa51461015357806313137d6514610172575b5f5ffd5b348015610114575f5ffd5b506101286101233660046114b9565b610408565b005b61013d6101383660046114e6565b6104c0565b60405161014a9190611506565b60405180910390f35b34801561015e575f5ffd5b5061012861016d36600461155e565b610788565b6101286101803660046115d3565b610b7f565b348015610190575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b60405190815260200161014a565b3480156101d1575f5ffd5b506101e56101e03660046114e6565b610f8e565b60405161014a91906116b0565b3480156101fd575f5ffd5b50600254610211906001600160801b031681565b6040516001600160801b03909116815260200161014a565b348015610234575f5ffd5b50610250731a44076050125825900e736c501f859c50fe728c81565b6040516001600160a01b03909116815260200161014a565b348015610273575f5ffd5b506101b85f516020611a075f395f51905f5281565b348015610293575f5ffd5b506102a76102a23660046116d5565b611273565b6040516001600160401b03909116815260200161014a565b3480156102ca575f5ffd5b506102d46176aa81565b60405163ffffffff909116815260200161014a565b3480156102f4575f5ffd5b50600154610250906001600160a01b031681565b348015610313575f5ffd5b506102507f000000000000000000000000000000000000000000000000000000000000000081565b348015610346575f5ffd5b506101e561127b565b34801561035a575f5ffd5b5061036e6103693660046114e6565b6112d5565b60405161014a91906116fd565b348015610386575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b3480156103b9575f5ffd5b506101b86103c8366004611714565b60036020525f908152604090205481565b3480156103e4575f5ffd5b506103f86103f336600461172b565b6113ef565b604051901515815260200161014a565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614158061044e57506002546001600160801b03908116908216105b1561046c57604051636dac6a0960e01b815260040160405180910390fd5b600280546001600160801b0319166001600160801b0383169081179091556040519081527f4bbad5fe035af81686d3e8380dfd61d879211cbe2c4e6e05f86ad07cdec099b09060200160405180910390a150565b6104c8611479565b6104d0611451565b6040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91810161051285610f8e565b815260200161051f61127b565b81525f6020909101819052604051631bb8518b60e31b815291925090731a44076050125825900e736c501f859c50fe728c9063ddc28c58906105679085903090600401611745565b6040805180830381865afa158015610581573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906105a59190611815565b805190915015806105b95750602081015115155b806105c5575080513414155b156105e357604051636dac6a0960e01b815260040160405180910390fd5b6040516302637a4560e41b8152731a44076050125825900e736c501f859c50fe728c90632637a45090349061061e9086903390600401611745565b60806040518083038185885af115801561063a573d5f5f3e3d5ffd5b50505050506040513d601f19601f8201168201806040525081019061065f9190611843565b8051909350158061067b575060208301516001600160401b0316155b8061068d575060408301516020015115155b8061069c575060408301515134105b156106ba57604051636dac6a0960e01b815260040160405180910390fd5b825f01517f6d23cdaef17712141c7441cf202389c6ddc063fb5c14788d5c4479b62096d13f8560015f9054906101000a90046001600160a01b03166001600160a01b031663172195226040518163ffffffff1660e01b8152600401602060405180830381865afa158015610730573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061075491906118b6565b6040805160ff90931683526001600160401b0390911660208301520160405180910390a2505061078360015f55565b919050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161415806107ca57506001546001600160a01b031615155b806107dd57506001600160a01b0381163b155b806108595750306001600160a01b0316816001600160a01b03166303eadcfc6040518163ffffffff1660e01b8152600401602060405180830381865afa158015610829573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061084d91906118d1565b6001600160a01b031614155b806108e357507f0000000000000000000000000000000000000000000000000000000000000000816001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156108bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906108e091906118ec565b14155b8061095c57505f516020611a075f395f51905f525f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa158015610935573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061095991906118ec565b14155b806109ec57507355d398326f99059ff775485246999027b31979556001600160a01b0316816001600160a01b031663e5a6b10f6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156109bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906109e091906118d1565b6001600160a01b031614155b80610a7c575073c440f06bbc7e58b0d055815f915447e4ae0e37206001600160a01b0316816001600160a01b03166361d027b36040518163ffffffff1660e01b8152600401602060405180830381865afa158015610a4c573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610a7091906118d1565b6001600160a01b031614155b80610b1857507f00000000000000000000000000000000000000000000000000000000000000006001600160a01b0316816001600160a01b031663f77c47916040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ae8573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610b0c91906118d1565b6001600160a01b031614155b15610b3657604051636dac6a0960e01b815260040160405180910390fd5b600180546001600160a01b0319166001600160a01b0383169081179091556040517f3916d079df018feca66a550908f671cff67410227b4a8c24f13531847e12b9c8905f90a250565b610b87611451565b33731a44076050125825900e736c501f859c50fe728c141580610bbe57506176aa610bb56020890189611903565b63ffffffff1614155b80610bed57507f0000000000000000000000000000000000000000000000000000000000000000876020013514155b80610c0157506001546001600160a01b0316155b80610c0a575085155b80610c2b5750610c20606088016040890161191c565b6001600160401b0316155b80610c3557503415155b15610c5357604051636dac6a0960e01b815260040160405180910390fd5b608a84141580610c7e575084845f818110610c7057610c70611937565b9091013560f81c6003141590505b15610c9c57604051636dac6a0960e01b815260040160405180910390fd5b5f85856001818110610cb057610cb0611937565b919091013560f81c91505f9050610ccb60226002888a61194b565b610cd491611972565b90505f610ce560426022898b61194b565b610cee91611972565b90505f610cff604a60428a8c61194b565b610d089161198f565b60c01c90505f610d1c606a604a8b8d61194b565b610d2591611972565b90505f610d36608a606a8c8e61194b565b610d3f91611972565b90507f000000000000000000000000000000000000000000000000000000000000000085141580610d7d57505f516020611a075f395f51905f528414155b80610d8f57506001600160401b038316155b15610dad57604051636dac6a0960e01b815260040160405180910390fd5b5f8b8b604051610dbe9291906119c5565b60408051918290039091205f8f81526003602052919091205490915015801590610df557505f8d8152600360205260409020548114155b15610e1357604051636dac6a0960e01b815260040160405180910390fd5b8660ff16600103610eb05782151580610e2b57508115155b15610e4957604051636dac6a0960e01b815260040160405180910390fd5b60015460405163579c848360e11b81526001600160401b03861660048201526001600160a01b039091169063af390906906024015b5f604051808303815f87803b158015610e95575f5ffd5b505af1158015610ea7573d5f5f3e3d5ffd5b50505050610f1b565b8660ff16600303610f025760015460405163367938c560e21b81526001600160401b038616600482015260248101859052604481018490526001600160a01b039091169063d9e4e31490606401610e7e565b604051636dac6a0960e01b815260040160405180910390fd5b5f8d815260036020908152604091829020839055815160ff8a1681526001600160401b038716918101919091528e917f37949e68c9d0a4e5f5474ddb8654f999a5dc4b58a8aa1aef313516586e9b320a910160405180910390a250505050505050610f8560015f55565b50505050505050565b6001546060906001600160a01b0316610fba57604051636dac6a0960e01b815260040160405180910390fd5b8160ff166002036110705760035b60015f9054906101000a90046001600160a01b03166001600160a01b031663c19d93fb6040518163ffffffff1660e01b8152600401602060405180830381865afa158015611018573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061103c91906119e8565b600481111561104d5761104d6119d4565b1461106b57604051636dac6a0960e01b815260040160405180910390fd5b611082565b8160ff16600403610f02576004610fc8565b60015460408051630b90ca9160e11b8152905160039285927f0000000000000000000000000000000000000000000000000000000000000000925f516020611a075f395f51905f52926001600160a01b03169163172195229160048083019260209291908290030181865afa1580156110fd573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061112191906118b6565b60015f9054906101000a90046001600160a01b03166001600160a01b0316635467e0a76040518163ffffffff1660e01b8152600401602060405180830381865afa158015611171573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061119591906118ec565b60015f9054906101000a90046001600160a01b03166001600160a01b03166366d003ac6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156111e5573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061120991906118ec565b60405160f897881b6001600160f81b031990811660208301529690971b90951660218701526022860193909352604285019190915260c01b6001600160c01b0319166062840152606a830152608a82015260aa016040516020818303038152906040529050919050565b5f5b92915050565b600254604051600360f01b6020820152600160f81b60228201819052601160f01b6023830152602582015260809190911b6001600160801b0319166026820152606090603601604051602081830303815290604052905090565b604080518082019091525f80825260208201526040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91731a44076050125825900e736c501f859c50fe728c9163ddc28c5891810161134687610f8e565b815260200161135361127b565b81525f6020909101526040516001600160e01b031960e084901b16815261137f91903090600401611745565b6040805180830381865afa158015611399573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906113bd9190611815565b805190915015806113d15750602081015115155b1561127557604051636dac6a0960e01b815260040160405180910390fd5b5f6176aa6114006020840184611903565b63ffffffff1614801561143657507f00000000000000000000000000000000000000000000000000000000000000008260200135145b801561127557506001546001600160a01b0316151592915050565b60025f540361147357604051633ee5aeb560e01b815260040160405180910390fd5b60025f55565b60405180606001604052805f81526020015f6001600160401b031681526020016114b460405180604001604052805f81526020015f81525090565b905290565b5f602082840312156114c9575f5ffd5b81356001600160801b03811681146114df575f5ffd5b9392505050565b5f602082840312156114f6575f5ffd5b813560ff811681146114df575f5ffd5b5f608082019050825182526001600160401b0360208401511660208301526040830151611540604084018280518252602090810151910152565b5092915050565b6001600160a01b038116811461155b575f5ffd5b50565b5f6020828403121561156e575f5ffd5b81356114df81611547565b5f60608284031215611589575f5ffd5b50919050565b5f5f83601f84011261159f575f5ffd5b5081356001600160401b038111156115b5575f5ffd5b6020830191508360208285010111156115cc575f5ffd5b9250929050565b5f5f5f5f5f5f5f60e0888a0312156115e9575f5ffd5b6115f38989611579565b96506060880135955060808801356001600160401b03811115611614575f5ffd5b6116208a828b0161158f565b90965094505060a088013561163481611547565b925060c08801356001600160401b0381111561164e575f5ffd5b61165a8a828b0161158f565b989b979a50959850939692959293505050565b5f81518084525f5b8181101561169157602081850181015186830182015201611675565b505f602082860101526020601f19601f83011685010191505092915050565b602081525f6114df602083018461166d565b803563ffffffff81168114610783575f5ffd5b5f5f604083850312156116e6575f5ffd5b6116ef836116c2565b946020939093013593505050565b815181526020808301519082015260408101611275565b5f60208284031215611724575f5ffd5b5035919050565b5f6060828403121561173b575f5ffd5b6114df8383611579565b6040815263ffffffff8351166040820152602083015160608201525f604084015160a0608084015261177a60e084018261166d565b90506060850151603f198483030160a0850152611797828261166d565b60809690960151151560c08501525050506001600160a01b039190911660209091015290565b5f604082840312156117cd575f5ffd5b604080519081016001600160401b03811182821017156117fb57634e487b7160e01b5f52604160045260245ffd5b604052825181526020928301519281019290925250919050565b5f60408284031215611825575f5ffd5b6114df83836117bd565b6001600160401b038116811461155b575f5ffd5b5f6080828403128015611854575f5ffd5b50604051606081016001600160401b038111828210171561188357634e487b7160e01b5f52604160045260245ffd5b6040528251815260208301516118988161182f565b60208201526118aa84604085016117bd565b60408201529392505050565b5f602082840312156118c6575f5ffd5b81516114df8161182f565b5f602082840312156118e1575f5ffd5b81516114df81611547565b5f602082840312156118fc575f5ffd5b5051919050565b5f60208284031215611913575f5ffd5b6114df826116c2565b5f6020828403121561192c575f5ffd5b81356114df8161182f565b634e487b7160e01b5f52603260045260245ffd5b5f5f85851115611959575f5ffd5b83861115611965575f5ffd5b5050820193919092039150565b80356020831015611275575f19602084900360031b1b1692915050565b80356001600160c01b03198116906008841015611540576001600160c01b031960089490940360031b84901b1690921692915050565b818382375f9101908152919050565b634e487b7160e01b5f52602160045260245ffd5b5f602082840312156119f8575f5ffd5b8151600581106114df575f5ffdfe046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6baa2646970667358221220d5e0a008fcf934cc781ad8e21c7865f692e69e850ec3b05743fb3e9c2c69c09a64736f6c634300081e0033"
      },
      deployedBytecode: {
        immutableReferences: {
          "61": [
            {
              length: 32,
              start: 406
            },
            {
              length: 32,
              start: 1249
            },
            {
              length: 32,
              start: 3014
            },
            {
              length: 32,
              start: 4857
            },
            {
              length: 32,
              start: 5136
            }
          ],
          "63": [
            {
              length: 32,
              start: 908
            },
            {
              length: 32,
              start: 2145
            },
            {
              length: 32,
              start: 3395
            },
            {
              length: 32,
              start: 4252
            }
          ],
          "65": [
            {
              length: 32,
              start: 793
            },
            {
              length: 32,
              start: 1043
            },
            {
              length: 32,
              start: 1939
            },
            {
              length: 32,
              start: 2692
            }
          ]
        },
        object: "608060405260043610610105575f3560e01c80637d25a05e11610092578063b1f8671711610062578063b1f867171461033b578063c13bd9361461034f578063d96661ef1461037b578063e495f1d4146103ae578063ff7bd03d146103d9575f5ffd5b80637d25a05e1461028857806383d5f21d146102bf578063a7a1ed72146102e9578063acba7b4214610308575f5ffd5b806315aff54e116100d857806315aff54e146101855780634922eec1146101c65780634cedb60f146101f25780635e280f111461022957806378360c8814610268575f5ffd5b80630200e86b1461010957806307f53ee71461012a57806310265fa51461015357806313137d6514610172575b5f5ffd5b348015610114575f5ffd5b506101286101233660046114b9565b610408565b005b61013d6101383660046114e6565b6104c0565b60405161014a9190611506565b60405180910390f35b34801561015e575f5ffd5b5061012861016d36600461155e565b610788565b6101286101803660046115d3565b610b7f565b348015610190575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b60405190815260200161014a565b3480156101d1575f5ffd5b506101e56101e03660046114e6565b610f8e565b60405161014a91906116b0565b3480156101fd575f5ffd5b50600254610211906001600160801b031681565b6040516001600160801b03909116815260200161014a565b348015610234575f5ffd5b50610250731a44076050125825900e736c501f859c50fe728c81565b6040516001600160a01b03909116815260200161014a565b348015610273575f5ffd5b506101b85f516020611a075f395f51905f5281565b348015610293575f5ffd5b506102a76102a23660046116d5565b611273565b6040516001600160401b03909116815260200161014a565b3480156102ca575f5ffd5b506102d46176aa81565b60405163ffffffff909116815260200161014a565b3480156102f4575f5ffd5b50600154610250906001600160a01b031681565b348015610313575f5ffd5b506102507f000000000000000000000000000000000000000000000000000000000000000081565b348015610346575f5ffd5b506101e561127b565b34801561035a575f5ffd5b5061036e6103693660046114e6565b6112d5565b60405161014a91906116fd565b348015610386575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b3480156103b9575f5ffd5b506101b86103c8366004611714565b60036020525f908152604090205481565b3480156103e4575f5ffd5b506103f86103f336600461172b565b6113ef565b604051901515815260200161014a565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614158061044e57506002546001600160801b03908116908216105b1561046c57604051636dac6a0960e01b815260040160405180910390fd5b600280546001600160801b0319166001600160801b0383169081179091556040519081527f4bbad5fe035af81686d3e8380dfd61d879211cbe2c4e6e05f86ad07cdec099b09060200160405180910390a150565b6104c8611479565b6104d0611451565b6040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91810161051285610f8e565b815260200161051f61127b565b81525f6020909101819052604051631bb8518b60e31b815291925090731a44076050125825900e736c501f859c50fe728c9063ddc28c58906105679085903090600401611745565b6040805180830381865afa158015610581573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906105a59190611815565b805190915015806105b95750602081015115155b806105c5575080513414155b156105e357604051636dac6a0960e01b815260040160405180910390fd5b6040516302637a4560e41b8152731a44076050125825900e736c501f859c50fe728c90632637a45090349061061e9086903390600401611745565b60806040518083038185885af115801561063a573d5f5f3e3d5ffd5b50505050506040513d601f19601f8201168201806040525081019061065f9190611843565b8051909350158061067b575060208301516001600160401b0316155b8061068d575060408301516020015115155b8061069c575060408301515134105b156106ba57604051636dac6a0960e01b815260040160405180910390fd5b825f01517f6d23cdaef17712141c7441cf202389c6ddc063fb5c14788d5c4479b62096d13f8560015f9054906101000a90046001600160a01b03166001600160a01b031663172195226040518163ffffffff1660e01b8152600401602060405180830381865afa158015610730573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061075491906118b6565b6040805160ff90931683526001600160401b0390911660208301520160405180910390a2505061078360015f55565b919050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161415806107ca57506001546001600160a01b031615155b806107dd57506001600160a01b0381163b155b806108595750306001600160a01b0316816001600160a01b03166303eadcfc6040518163ffffffff1660e01b8152600401602060405180830381865afa158015610829573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061084d91906118d1565b6001600160a01b031614155b806108e357507f0000000000000000000000000000000000000000000000000000000000000000816001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156108bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906108e091906118ec565b14155b8061095c57505f516020611a075f395f51905f525f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa158015610935573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061095991906118ec565b14155b806109ec57507355d398326f99059ff775485246999027b31979556001600160a01b0316816001600160a01b031663e5a6b10f6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156109bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906109e091906118d1565b6001600160a01b031614155b80610a7c575073c440f06bbc7e58b0d055815f915447e4ae0e37206001600160a01b0316816001600160a01b03166361d027b36040518163ffffffff1660e01b8152600401602060405180830381865afa158015610a4c573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610a7091906118d1565b6001600160a01b031614155b80610b1857507f00000000000000000000000000000000000000000000000000000000000000006001600160a01b0316816001600160a01b031663f77c47916040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ae8573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610b0c91906118d1565b6001600160a01b031614155b15610b3657604051636dac6a0960e01b815260040160405180910390fd5b600180546001600160a01b0319166001600160a01b0383169081179091556040517f3916d079df018feca66a550908f671cff67410227b4a8c24f13531847e12b9c8905f90a250565b610b87611451565b33731a44076050125825900e736c501f859c50fe728c141580610bbe57506176aa610bb56020890189611903565b63ffffffff1614155b80610bed57507f0000000000000000000000000000000000000000000000000000000000000000876020013514155b80610c0157506001546001600160a01b0316155b80610c0a575085155b80610c2b5750610c20606088016040890161191c565b6001600160401b0316155b80610c3557503415155b15610c5357604051636dac6a0960e01b815260040160405180910390fd5b608a84141580610c7e575084845f818110610c7057610c70611937565b9091013560f81c6003141590505b15610c9c57604051636dac6a0960e01b815260040160405180910390fd5b5f85856001818110610cb057610cb0611937565b919091013560f81c91505f9050610ccb60226002888a61194b565b610cd491611972565b90505f610ce560426022898b61194b565b610cee91611972565b90505f610cff604a60428a8c61194b565b610d089161198f565b60c01c90505f610d1c606a604a8b8d61194b565b610d2591611972565b90505f610d36608a606a8c8e61194b565b610d3f91611972565b90507f000000000000000000000000000000000000000000000000000000000000000085141580610d7d57505f516020611a075f395f51905f528414155b80610d8f57506001600160401b038316155b15610dad57604051636dac6a0960e01b815260040160405180910390fd5b5f8b8b604051610dbe9291906119c5565b60408051918290039091205f8f81526003602052919091205490915015801590610df557505f8d8152600360205260409020548114155b15610e1357604051636dac6a0960e01b815260040160405180910390fd5b8660ff16600103610eb05782151580610e2b57508115155b15610e4957604051636dac6a0960e01b815260040160405180910390fd5b60015460405163579c848360e11b81526001600160401b03861660048201526001600160a01b039091169063af390906906024015b5f604051808303815f87803b158015610e95575f5ffd5b505af1158015610ea7573d5f5f3e3d5ffd5b50505050610f1b565b8660ff16600303610f025760015460405163367938c560e21b81526001600160401b038616600482015260248101859052604481018490526001600160a01b039091169063d9e4e31490606401610e7e565b604051636dac6a0960e01b815260040160405180910390fd5b5f8d815260036020908152604091829020839055815160ff8a1681526001600160401b038716918101919091528e917f37949e68c9d0a4e5f5474ddb8654f999a5dc4b58a8aa1aef313516586e9b320a910160405180910390a250505050505050610f8560015f55565b50505050505050565b6001546060906001600160a01b0316610fba57604051636dac6a0960e01b815260040160405180910390fd5b8160ff166002036110705760035b60015f9054906101000a90046001600160a01b03166001600160a01b031663c19d93fb6040518163ffffffff1660e01b8152600401602060405180830381865afa158015611018573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061103c91906119e8565b600481111561104d5761104d6119d4565b1461106b57604051636dac6a0960e01b815260040160405180910390fd5b611082565b8160ff16600403610f02576004610fc8565b60015460408051630b90ca9160e11b8152905160039285927f0000000000000000000000000000000000000000000000000000000000000000925f516020611a075f395f51905f52926001600160a01b03169163172195229160048083019260209291908290030181865afa1580156110fd573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061112191906118b6565b60015f9054906101000a90046001600160a01b03166001600160a01b0316635467e0a76040518163ffffffff1660e01b8152600401602060405180830381865afa158015611171573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061119591906118ec565b60015f9054906101000a90046001600160a01b03166001600160a01b03166366d003ac6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156111e5573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061120991906118ec565b60405160f897881b6001600160f81b031990811660208301529690971b90951660218701526022860193909352604285019190915260c01b6001600160c01b0319166062840152606a830152608a82015260aa016040516020818303038152906040529050919050565b5f5b92915050565b600254604051600360f01b6020820152600160f81b60228201819052601160f01b6023830152602582015260809190911b6001600160801b0319166026820152606090603601604051602081830303815290604052905090565b604080518082019091525f80825260208201526040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91731a44076050125825900e736c501f859c50fe728c9163ddc28c5891810161134687610f8e565b815260200161135361127b565b81525f6020909101526040516001600160e01b031960e084901b16815261137f91903090600401611745565b6040805180830381865afa158015611399573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906113bd9190611815565b805190915015806113d15750602081015115155b1561127557604051636dac6a0960e01b815260040160405180910390fd5b5f6176aa6114006020840184611903565b63ffffffff1614801561143657507f00000000000000000000000000000000000000000000000000000000000000008260200135145b801561127557506001546001600160a01b0316151592915050565b60025f540361147357604051633ee5aeb560e01b815260040160405180910390fd5b60025f55565b60405180606001604052805f81526020015f6001600160401b031681526020016114b460405180604001604052805f81526020015f81525090565b905290565b5f602082840312156114c9575f5ffd5b81356001600160801b03811681146114df575f5ffd5b9392505050565b5f602082840312156114f6575f5ffd5b813560ff811681146114df575f5ffd5b5f608082019050825182526001600160401b0360208401511660208301526040830151611540604084018280518252602090810151910152565b5092915050565b6001600160a01b038116811461155b575f5ffd5b50565b5f6020828403121561156e575f5ffd5b81356114df81611547565b5f60608284031215611589575f5ffd5b50919050565b5f5f83601f84011261159f575f5ffd5b5081356001600160401b038111156115b5575f5ffd5b6020830191508360208285010111156115cc575f5ffd5b9250929050565b5f5f5f5f5f5f5f60e0888a0312156115e9575f5ffd5b6115f38989611579565b96506060880135955060808801356001600160401b03811115611614575f5ffd5b6116208a828b0161158f565b90965094505060a088013561163481611547565b925060c08801356001600160401b0381111561164e575f5ffd5b61165a8a828b0161158f565b989b979a50959850939692959293505050565b5f81518084525f5b8181101561169157602081850181015186830182015201611675565b505f602082860101526020601f19601f83011685010191505092915050565b602081525f6114df602083018461166d565b803563ffffffff81168114610783575f5ffd5b5f5f604083850312156116e6575f5ffd5b6116ef836116c2565b946020939093013593505050565b815181526020808301519082015260408101611275565b5f60208284031215611724575f5ffd5b5035919050565b5f6060828403121561173b575f5ffd5b6114df8383611579565b6040815263ffffffff8351166040820152602083015160608201525f604084015160a0608084015261177a60e084018261166d565b90506060850151603f198483030160a0850152611797828261166d565b60809690960151151560c08501525050506001600160a01b039190911660209091015290565b5f604082840312156117cd575f5ffd5b604080519081016001600160401b03811182821017156117fb57634e487b7160e01b5f52604160045260245ffd5b604052825181526020928301519281019290925250919050565b5f60408284031215611825575f5ffd5b6114df83836117bd565b6001600160401b038116811461155b575f5ffd5b5f6080828403128015611854575f5ffd5b50604051606081016001600160401b038111828210171561188357634e487b7160e01b5f52604160045260245ffd5b6040528251815260208301516118988161182f565b60208201526118aa84604085016117bd565b60408201529392505050565b5f602082840312156118c6575f5ffd5b81516114df8161182f565b5f602082840312156118e1575f5ffd5b81516114df81611547565b5f602082840312156118fc575f5ffd5b5051919050565b5f60208284031215611913575f5ffd5b6114df826116c2565b5f6020828403121561192c575f5ffd5b81356114df8161182f565b634e487b7160e01b5f52603260045260245ffd5b5f5f85851115611959575f5ffd5b83861115611965575f5ffd5b5050820193919092039150565b80356020831015611275575f19602084900360031b1b1692915050565b80356001600160c01b03198116906008841015611540576001600160c01b031960089490940360031b84901b1690921692915050565b818382375f9101908152919050565b634e487b7160e01b5f52602160045260245ffd5b5f602082840312156119f8575f5ffd5b8151600581106114df575f5ffdfe046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6baa2646970667358221220d5e0a008fcf934cc781ad8e21c7865f692e69e850ec3b05743fb3e9c2c69c09a64736f6c634300081e0033"
      }
    }
  },
  pass: {
    abi: [
      {
        inputs: [
          {
            internalType: "address",
            name: "verifier",
            type: "address"
          }
        ],
        stateMutability: "nonpayable",
        type: "constructor"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "sender",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          },
          {
            internalType: "address",
            name: "owner",
            type: "address"
          }
        ],
        name: "ERC721IncorrectOwner",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "operator",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "ERC721InsufficientApproval",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "approver",
            type: "address"
          }
        ],
        name: "ERC721InvalidApprover",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "operator",
            type: "address"
          }
        ],
        name: "ERC721InvalidOperator",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "owner",
            type: "address"
          }
        ],
        name: "ERC721InvalidOwner",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "receiver",
            type: "address"
          }
        ],
        name: "ERC721InvalidReceiver",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "sender",
            type: "address"
          }
        ],
        name: "ERC721InvalidSender",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "ERC721NonexistentToken",
        type: "error"
      },
      {
        inputs: [],
        name: "Invalid",
        type: "error"
      },
      {
        inputs: [],
        name: "ReentrancyGuardReentrantCall",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "token",
            type: "address"
          }
        ],
        name: "SafeERC20FailedOperation",
        type: "error"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "address",
            name: "owner",
            type: "address"
          },
          {
            indexed: true,
            internalType: "address",
            name: "approved",
            type: "address"
          },
          {
            indexed: true,
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "Approval",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "address",
            name: "owner",
            type: "address"
          },
          {
            indexed: true,
            internalType: "address",
            name: "operator",
            type: "address"
          },
          {
            indexed: false,
            internalType: "bool",
            name: "approved",
            type: "bool"
          }
        ],
        name: "ApprovalForAll",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          },
          {
            indexed: true,
            internalType: "address",
            name: "buyer",
            type: "address"
          },
          {
            indexed: false,
            internalType: "uint256",
            name: "amount",
            type: "uint256"
          }
        ],
        name: "PassPurchased",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: false,
            internalType: "bool",
            name: "paused",
            type: "bool"
          }
        ],
        name: "PurchasePauseChanged",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          },
          {
            indexed: true,
            internalType: "bytes32",
            name: "request",
            type: "bytes32"
          }
        ],
        name: "RedemptionFinalized",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          },
          {
            indexed: true,
            internalType: "bytes32",
            name: "request",
            type: "bytes32"
          },
          {
            indexed: false,
            internalType: "bytes32",
            name: "recipient",
            type: "bytes32"
          }
        ],
        name: "RedemptionRequested",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          }
        ],
        name: "ReserveConfirmed",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "address",
            name: "from",
            type: "address"
          },
          {
            indexed: true,
            internalType: "address",
            name: "to",
            type: "address"
          },
          {
            indexed: true,
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "Transfer",
        type: "event"
      },
      {
        inputs: [],
        name: "PRICE",
        outputs: [
          {
            internalType: "uint256",
            name: "",
            type: "uint256"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint64",
            name: "gen",
            type: "uint64"
          },
          {
            internalType: "bytes32",
            name: "request",
            type: "bytes32"
          },
          {
            internalType: "bytes32",
            name: "suiRecipient",
            type: "bytes32"
          }
        ],
        name: "acknowledge",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "adapter",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "to",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "approve",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "backingNFT",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "owner",
            type: "address"
          }
        ],
        name: "balanceOf",
        outputs: [
          {
            internalType: "uint256",
            name: "",
            type: "uint256"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "buy",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "wallet",
            type: "address"
          }
        ],
        name: "canPlay",
        outputs: [
          {
            internalType: "bool",
            name: "",
            type: "bool"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint64",
            name: "next",
            type: "uint64"
          }
        ],
        name: "confirmReserve",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "controller",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "currency",
        outputs: [
          {
            internalType: "contract IERC20",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "currencyCodeHash",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "generation",
        outputs: [
          {
            internalType: "uint64",
            name: "",
            type: "uint64"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "getApproved",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "initialBuyer",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "owner",
            type: "address"
          },
          {
            internalType: "address",
            name: "operator",
            type: "address"
          }
        ],
        name: "isApprovedForAll",
        outputs: [
          {
            internalType: "bool",
            name: "",
            type: "bool"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "name",
        outputs: [
          {
            internalType: "string",
            name: "",
            type: "string"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "ownerOf",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "purchasesPaused",
        outputs: [
          {
            internalType: "bool",
            name: "",
            type: "bool"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "recipient",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "redemption",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "bytes32",
            name: "suiRecipient",
            type: "bytes32"
          }
        ],
        name: "requestRedemption",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "route",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "from",
            type: "address"
          },
          {
            internalType: "address",
            name: "to",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "safeTransferFrom",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "from",
            type: "address"
          },
          {
            internalType: "address",
            name: "to",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          },
          {
            internalType: "bytes",
            name: "data",
            type: "bytes"
          }
        ],
        name: "safeTransferFrom",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "operator",
            type: "address"
          },
          {
            internalType: "bool",
            name: "approved",
            type: "bool"
          }
        ],
        name: "setApprovalForAll",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "bool",
            name: "paused",
            type: "bool"
          }
        ],
        name: "setPurchasesPaused",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "state",
        outputs: [
          {
            internalType: "enum TreeSuitePass.State",
            name: "",
            type: "uint8"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "bytes4",
            name: "interfaceId",
            type: "bytes4"
          }
        ],
        name: "supportsInterface",
        outputs: [
          {
            internalType: "bool",
            name: "",
            type: "bool"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "symbol",
        outputs: [
          {
            internalType: "string",
            name: "",
            type: "string"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "tokenURI",
        outputs: [
          {
            internalType: "string",
            name: "",
            type: "string"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "from",
            type: "address"
          },
          {
            internalType: "address",
            name: "to",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "transferFrom",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "treasury",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      }
    ],
    evm: {
      bytecode: {
        object: "610120604052600a805460ff1916600117905534801561001d575f5ffd5b506040516124c33803806124c383398101604081905261003c916104aa565b6040518060400160405280601c81526020017f4e46547265652053756974652047656e65726174696f6e205061737300000000815250604051806040016040528060078152602001662a2922a2a3a2a760c91b815250815f90816100a0919061056f565b5060016100ad828261056f565b50506001600655504660381415806100d857507355d398326f99059ff775485246999027b31979553b155b806100eb57506001600160a01b0381163b155b8061016d57507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610141573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906101659190610629565b60ff16601214155b1561018b57604051636dac6a0960e01b815260040160405180910390fd5b5f819050336001600160a01b0316816001600160a01b031663acba7b426040518163ffffffff1660e01b8152600401602060405180830381865afa1580156101d5573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906101f991906104aa565b6001600160a01b03161415806102945750731a44076050125825900e736c501f859c50fe728c6001600160a01b0316816001600160a01b0316635e280f116040518163ffffffff1660e01b8152600401602060405180830381865afa158015610264573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061028891906104aa565b6001600160a01b031614155b806102fc5750806001600160a01b03166315aff54e6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156102d6573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906102fa9190610649565b155b806103645750806001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa15801561033e573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906103629190610649565b155b806103f057507f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba5f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa1580156103c9573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906103ed9190610649565b14155b1561040e57604051636dac6a0960e01b815260040160405180910390fd5b6001600160a01b038083166080523360a081905260c0526040805163d96661ef60e01b815290519183169163d96661ef916004808201926020929091908290030181865afa158015610462573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906104869190610649565b60e05250507355d398326f99059ff775485246999027b31979553f61010052610660565b5f602082840312156104ba575f5ffd5b81516001600160a01b03811681146104d0575f5ffd5b9392505050565b634e487b7160e01b5f52604160045260245ffd5b600181811c908216806104ff57607f821691505b60208210810361051d57634e487b7160e01b5f52602260045260245ffd5b50919050565b601f82111561056a57805f5260205f20601f840160051c810160208510156105485750805b601f840160051c820191505b81811015610567575f8155600101610554565b50505b505050565b81516001600160401b03811115610588576105886104d7565b61059c8161059684546104eb565b84610523565b6020601f8211600181146105ce575f83156105b75750848201515b5f19600385901b1c1916600184901b178455610567565b5f84815260208120601f198516915b828110156105fd57878501518255602094850194600190920191016105dd565b508482101561061a57868401515f19600387901b60f8161c191681555b50505050600190811b01905550565b5f60208284031215610639575f5ffd5b815160ff811681146104d0575f5ffd5b5f60208284031215610659575f5ffd5b5051919050565b60805160a05160c05160e05161010051611dfc6106c75f395f81816102620152610a5101525f818161049701526108e101525f81816104ff015261073701525f81816103900152610a1001525f818161022301528181610d200152610f3c0152611dfc5ff3fe608060405234801561000f575f5ffd5b50600436106101f2575f3560e01c806370a0823111610114578063b88d4fde116100a9578063d96661ef11610079578063d96661ef14610492578063d9e4e314146104b9578063e5a6b10f146104cc578063e985e9c5146104e7578063f77c4791146104fa575f5ffd5b8063b88d4fde14610445578063c19d93fb14610458578063c87b56dd14610472578063c9f2071514610485575f5ffd5b806397579dd3116100e457806397579dd314610404578063a22cb46514610417578063a6f2ae3a1461042a578063af39090614610432575f5ffd5b806370a08231146103b257806378360c88146103c55780638d859f3e146103ec57806395d89b41146103fc575f5ffd5b806323b872dd1161018a57806361d027b31161015a57806361d027b3146103545780636352211e1461036f57806366d003ac146103825780636af7f9f51461038b575f5ffd5b806323b872dd14610312578063325832ac1461032557806342842e0e146103385780635467e0a71461034b575f5ffd5b8063081812fc116101c5578063081812fc146102a75780630823d5f3146102ba578063095ea7b3146102cd57806317219522146102e2575f5ffd5b806301ffc9a7146101f657806303eadcfc1461021e57806306f660a71461025d57806306fdde0314610292575b5f5ffd5b610209610204366004611962565b610521565b60405190151581526020015b60405180910390f35b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6040516001600160a01b039091168152602001610215565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b604051908152602001610215565b61029a610572565b60405161021591906119ca565b6102456102b53660046119dc565b610601565b6102096102c8366004611a09565b610628565b6102e06102db366004611a22565b61068f565b005b6007546102fa9061010090046001600160401b031681565b6040516001600160401b039091168152602001610215565b6102e0610320366004611a4a565b61069e565b6102e0610333366004611a93565b61072c565b6102e0610346366004611a4a565b6107bc565b61028460085481565b61024573c440f06bbc7e58b0d055815f915447e4ae0e372081565b61024561037d3660046119dc565b6107db565b61028460095481565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6102846103c0366004611a09565b6107e5565b6102847f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba81565b61028468015af1d78b58c4000081565b61029a61082a565b6102846104123660046119dc565b610839565b6102e0610425366004611aac565b6109c4565b6102e06109cf565b6102e0610440366004611af3565b610d15565b6102e0610453366004611b20565b610ea8565b6007546104659060ff1681565b6040516102159190611c0e565b61029a6104803660046119dc565b610ec0565b600a546102099060ff1681565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b6102e06104c7366004611c34565b610f31565b6102457355d398326f99059ff775485246999027b319795581565b6102096104f5366004611c64565b61109d565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b5f6001600160e01b031982166380ac58cd60e01b148061055157506001600160e01b03198216635b5e139f60e01b145b8061056c57506301ffc9a760e01b6001600160e01b03198316145b92915050565b60605f805461058090611c8c565b80601f01602080910402602001604051908101604052809291908181526020018280546105ac90611c8c565b80156105f75780601f106105ce576101008083540402835291602001916105f7565b820191905f5260205f20905b8154815290600101906020018083116105da57829003601f168201915b5050505050905090565b5f61060b826110ca565b505f828152600460205260409020546001600160a01b031661056c565b5f600260075460ff16600481111561064257610642611bfa565b14801561065757506001600160a01b03821615155b801561056c57505060075461010090046001600160401b03165f908152600260205260409020546001600160a01b0391821691161490565b61069a828233611102565b5050565b6001600160a01b0382166106cc57604051633250574960e11b81525f60048201526024015b60405180910390fd5b5f6106d883833361110f565b9050836001600160a01b0316816001600160a01b031614610726576040516364283d7b60e01b81526001600160a01b03808616600483015260248201849052821660448201526064016106c3565b50505050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161461077557604051636dac6a0960e01b815260040160405180910390fd5b600a805460ff19168215159081179091556040519081527fd6d0fdd597c17a0211f0324826035a55dec84b1e6196f3585be220b46767fbb99060200160405180910390a150565b6107d683838360405180602001604052805f815250610ea8565b505050565b5f61056c826110ca565b5f6001600160a01b03821661080f576040516322718ad960e21b81525f60048201526024016106c3565b506001600160a01b03165f9081526003602052604090205490565b60606001805461058090611c8c565b5f6108426111ad565b600260075460ff16600481111561085b5761085b611bfa565b14158061088b5750600754339061087f9061010090046001600160401b03166107db565b6001600160a01b031614155b80610894575081155b156108b257604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff1916600390811791829055600984905560408051602081019290925246908201523060608201527f000000000000000000000000000000000000000000000000000000000000000060808201527f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba60a08201526001600160401b03610100928390041660c08201523360e08201529081018390526101200160408051808303601f19018152908290528051602091820120600881905560075485845290926101009091046001600160401b0316917f5852bd51fa2990e2712a8f82286a04ca0750a7646a7950235ffefdb10585cefe910160405180910390a3506008546109bf6001600655565b919050565b61069a3383836111d7565b6109d76111ad565b600160075460ff1660048111156109f0576109f0611bfa565b1415806109ff5750600a5460ff165b80610a335750336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614155b80610a7357507355d398326f99059ff775485246999027b31979553f7f000000000000000000000000000000000000000000000000000000000000000014155b80610af557507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ac9573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610aed9190611cc4565b60ff16601214155b15610b1357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660021790556040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201525f907355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610b83573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610ba79190611ce4565b9050610be67355d398326f99059ff775485246999027b31979553373c440f06bbc7e58b0d055815f915447e4ae0e372068015af1d78b58c40000611275565b610bf968015af1d78b58c4000082611d0f565b6040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201527355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610c5a573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610c7e9190611ce4565b14610c9c57604051636dac6a0960e01b815260040160405180910390fd5b600754610cb890339061010090046001600160401b03166112cf565b60075460405168015af1d78b58c400008152339161010090046001600160401b0316907f266845010576f42f87c2d262b76328c22b6797abd6c81b34f59fc1b2da1c487e9060200160405180910390a350610d136001600655565b565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610d5e57604051636dac6a0960e01b815260040160405180910390fd5b806001600160401b03165f03610d8757604051636dac6a0960e01b815260040160405180910390fd5b6007546001600160401b038281166101009092041614610ea557600754610dbd9061010090046001600160401b03166001611d22565b6001600160401b0316816001600160401b0316141580610e1557505f60075460ff166004811115610df057610df0611bfa565b14158015610e155750600460075460ff166004811115610e1257610e12611bfa565b14155b15610e3357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff196001600160401b0384166101008102821668ffffffffffffffffff199093169290921760019081179093555f60088190556009819055600a8054909216909317905560405190917ff48a2acdce0f4a30c2d32425d8827b030bbdff66b7694573d92cdd52b818fd1691a25b50565b610eb384848461069e565b61072633858585856112e8565b6060610ecb826110ca565b505f610ee160408051602081019091525f815290565b90505f815111610eff5760405180602001604052805f815250610f2a565b80610f0984611410565b604051602001610f1a929190611d41565b6040516020818303038152906040525b9392505050565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610f7a57604051636dac6a0960e01b815260040160405180910390fd5b610f826111ad565b6007546001600160401b0384811661010090920416141580610fa2575081155b80610faf57506008548214155b80610fbc57506009548114155b15610fda57604051636dac6a0960e01b815260040160405180910390fd5b600460075460ff166004811115610ff357610ff3611bfa565b1461109357600360075460ff16600481111561101157611011611bfa565b1461102f57604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660041790819055611056906001600160401b036101009091041661149f565b600754604051839161010090046001600160401b0316907f4baa52424160077091b85a05340629c1a44cfac77a87274fad62a384fe6193f0905f90a35b6107d66001600655565b6001600160a01b039182165f90815260056020908152604080832093909416825291909152205460ff1690565b5f818152600260205260408120546001600160a01b03168061056c57604051637e27328960e01b8152600481018490526024016106c3565b6107d683838360016114d7565b6007545f9061010090046001600160401b03168314158061117c5750600260075460ff16600481111561114457611144611bfa565b1415801561117c5750600460075460ff16600481111561116657611166611bfa565b14801561117a57506001600160a01b038416155b155b1561119a57604051636dac6a0960e01b815260040160405180910390fd5b6111a58484846115db565b949350505050565b6002600654036111d057604051633ee5aeb560e01b815260040160405180910390fd5b6002600655565b6001600160a01b03821661120957604051630b61174360e31b81526001600160a01b03831660048201526024016106c3565b6001600160a01b038381165f81815260056020908152604080832094871680845294825291829020805460ff191686151590811790915591519182527f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31910160405180910390a3505050565b604080516001600160a01b0385811660248301528416604482015260648082018490528251808303909101815260849091019091526020810180516001600160e01b03166323b872dd60e01b1790526107269085906116cd565b61069a828260405180602001604052805f815250611739565b6001600160a01b0383163b1561140957604051630a85bd0160e11b81526001600160a01b0384169063150b7a029061132a908890889087908790600401611d6f565b6020604051808303815f875af1925050508015611364575060408051601f3d908101601f1916820190925261136191810190611dab565b60015b6113cb573d808015611391576040519150601f19603f3d011682016040523d82523d5f602084013e611396565b606091505b5080515f036113c357604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b805160208201fd5b6001600160e01b03198116630a85bd0160e11b1461140757604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b505b5050505050565b60605f61141c83611750565b60010190505f816001600160401b0381111561143a5761143a611b0c565b6040519080825280601f01601f191660200182016040528015611464576020820181803683370190505b5090508181016020015b5f19016f181899199a1a9b1b9c1cb0b131b232b360811b600a86061a8153600a850494508461146e57509392505050565b5f6114ab5f835f61110f565b90506001600160a01b03811661069a57604051637e27328960e01b8152600481018390526024016106c3565b80806114eb57506001600160a01b03821615155b156115ac575f6114fa846110ca565b90506001600160a01b038316158015906115265750826001600160a01b0316816001600160a01b031614155b80156115395750611537818461109d565b155b156115625760405163a9fbf51f60e01b81526001600160a01b03841660048201526024016106c3565b81156115aa5783856001600160a01b0316826001600160a01b03167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45b505b50505f90815260046020526040902080546001600160a01b0319166001600160a01b0392909216919091179055565b5f828152600260205260408120546001600160a01b039081169083161561160757611607818486611827565b6001600160a01b03811615611641576116225f855f5f6114d7565b6001600160a01b0381165f90815260036020526040902080545f190190555b6001600160a01b0385161561166f576001600160a01b0385165f908152600360205260409020805460010190555b5f8481526002602052604080822080546001600160a01b0319166001600160a01b0389811691821790925591518793918516917fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef91a4949350505050565b5f5f60205f8451602086015f885af1806116ec576040513d5f823e3d81fd5b50505f513d91508115611703578060011415611710565b6001600160a01b0384163b155b1561072657604051635274afe760e01b81526001600160a01b03851660048201526024016106c3565b611743838361188b565b6107d6335f8585856112e8565b5f8072184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b831061178e5772184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b830492506040015b6d04ee2d6d415b85acef810000000083106117ba576d04ee2d6d415b85acef8100000000830492506020015b662386f26fc1000083106117d857662386f26fc10000830492506010015b6305f5e10083106117f0576305f5e100830492506008015b612710831061180457612710830492506004015b60648310611816576064830492506002015b600a831061056c5760010192915050565b6118328383836118ec565b6107d6576001600160a01b03831661186057604051637e27328960e01b8152600481018290526024016106c3565b60405163177e802f60e01b81526001600160a01b0383166004820152602481018290526044016106c3565b6001600160a01b0382166118b457604051633250574960e11b81525f60048201526024016106c3565b5f6118c083835f61110f565b90506001600160a01b038116156107d6576040516339e3563760e11b81525f60048201526024016106c3565b5f6001600160a01b038316158015906111a55750826001600160a01b0316846001600160a01b031614806119255750611925848461109d565b806111a55750505f908152600460205260409020546001600160a01b03908116911614919050565b6001600160e01b031981168114610ea5575f5ffd5b5f60208284031215611972575f5ffd5b8135610f2a8161194d565b5f5b8381101561199757818101518382015260200161197f565b50505f910152565b5f81518084526119b681602086016020860161197d565b601f01601f19169290920160200192915050565b602081525f610f2a602083018461199f565b5f602082840312156119ec575f5ffd5b5035919050565b80356001600160a01b03811681146109bf575f5ffd5b5f60208284031215611a19575f5ffd5b610f2a826119f3565b5f5f60408385031215611a33575f5ffd5b611a3c836119f3565b946020939093013593505050565b5f5f5f60608486031215611a5c575f5ffd5b611a65846119f3565b9250611a73602085016119f3565b929592945050506040919091013590565b803580151581146109bf575f5ffd5b5f60208284031215611aa3575f5ffd5b610f2a82611a84565b5f5f60408385031215611abd575f5ffd5b611ac6836119f3565b9150611ad460208401611a84565b90509250929050565b80356001600160401b03811681146109bf575f5ffd5b5f60208284031215611b03575f5ffd5b610f2a82611add565b634e487b7160e01b5f52604160045260245ffd5b5f5f5f5f60808587031215611b33575f5ffd5b611b3c856119f3565b9350611b4a602086016119f3565b92506040850135915060608501356001600160401b03811115611b6b575f5ffd5b8501601f81018713611b7b575f5ffd5b80356001600160401b03811115611b9457611b94611b0c565b604051601f8201601f19908116603f011681016001600160401b0381118282101715611bc257611bc2611b0c565b604052818152828201602001891015611bd9575f5ffd5b816020840160208301375f6020838301015280935050505092959194509250565b634e487b7160e01b5f52602160045260245ffd5b6020810160058310611c2e57634e487b7160e01b5f52602160045260245ffd5b91905290565b5f5f5f60608486031215611c46575f5ffd5b611c4f84611add565b95602085013595506040909401359392505050565b5f5f60408385031215611c75575f5ffd5b611c7e836119f3565b9150611ad4602084016119f3565b600181811c90821680611ca057607f821691505b602082108103611cbe57634e487b7160e01b5f52602260045260245ffd5b50919050565b5f60208284031215611cd4575f5ffd5b815160ff81168114610f2a575f5ffd5b5f60208284031215611cf4575f5ffd5b5051919050565b634e487b7160e01b5f52601160045260245ffd5b8082018082111561056c5761056c611cfb565b6001600160401b03818116838216019081111561056c5761056c611cfb565b5f8351611d5281846020880161197d565b835190830190611d6681836020880161197d565b01949350505050565b6001600160a01b03858116825284166020820152604081018390526080606082018190525f90611da19083018461199f565b9695505050505050565b5f60208284031215611dbb575f5ffd5b8151610f2a8161194d56fea26469706673582212205cd0600d0bc59401f6362a6ffeeddd9fccccd322ad458bc4283018628c84b01f64736f6c634300081e0033"
      },
      deployedBytecode: {
        immutableReferences: {
          "880": [
            {
              length: 32,
              start: 547
            },
            {
              length: 32,
              start: 3360
            },
            {
              length: 32,
              start: 3900
            }
          ],
          "882": [
            {
              length: 32,
              start: 912
            },
            {
              length: 32,
              start: 2576
            }
          ],
          "884": [
            {
              length: 32,
              start: 1279
            },
            {
              length: 32,
              start: 1847
            }
          ],
          "886": [
            {
              length: 32,
              start: 1175
            },
            {
              length: 32,
              start: 2273
            }
          ],
          "888": [
            {
              length: 32,
              start: 610
            },
            {
              length: 32,
              start: 2641
            }
          ]
        },
        object: "608060405234801561000f575f5ffd5b50600436106101f2575f3560e01c806370a0823111610114578063b88d4fde116100a9578063d96661ef11610079578063d96661ef14610492578063d9e4e314146104b9578063e5a6b10f146104cc578063e985e9c5146104e7578063f77c4791146104fa575f5ffd5b8063b88d4fde14610445578063c19d93fb14610458578063c87b56dd14610472578063c9f2071514610485575f5ffd5b806397579dd3116100e457806397579dd314610404578063a22cb46514610417578063a6f2ae3a1461042a578063af39090614610432575f5ffd5b806370a08231146103b257806378360c88146103c55780638d859f3e146103ec57806395d89b41146103fc575f5ffd5b806323b872dd1161018a57806361d027b31161015a57806361d027b3146103545780636352211e1461036f57806366d003ac146103825780636af7f9f51461038b575f5ffd5b806323b872dd14610312578063325832ac1461032557806342842e0e146103385780635467e0a71461034b575f5ffd5b8063081812fc116101c5578063081812fc146102a75780630823d5f3146102ba578063095ea7b3146102cd57806317219522146102e2575f5ffd5b806301ffc9a7146101f657806303eadcfc1461021e57806306f660a71461025d57806306fdde0314610292575b5f5ffd5b610209610204366004611962565b610521565b60405190151581526020015b60405180910390f35b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6040516001600160a01b039091168152602001610215565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b604051908152602001610215565b61029a610572565b60405161021591906119ca565b6102456102b53660046119dc565b610601565b6102096102c8366004611a09565b610628565b6102e06102db366004611a22565b61068f565b005b6007546102fa9061010090046001600160401b031681565b6040516001600160401b039091168152602001610215565b6102e0610320366004611a4a565b61069e565b6102e0610333366004611a93565b61072c565b6102e0610346366004611a4a565b6107bc565b61028460085481565b61024573c440f06bbc7e58b0d055815f915447e4ae0e372081565b61024561037d3660046119dc565b6107db565b61028460095481565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6102846103c0366004611a09565b6107e5565b6102847f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba81565b61028468015af1d78b58c4000081565b61029a61082a565b6102846104123660046119dc565b610839565b6102e0610425366004611aac565b6109c4565b6102e06109cf565b6102e0610440366004611af3565b610d15565b6102e0610453366004611b20565b610ea8565b6007546104659060ff1681565b6040516102159190611c0e565b61029a6104803660046119dc565b610ec0565b600a546102099060ff1681565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b6102e06104c7366004611c34565b610f31565b6102457355d398326f99059ff775485246999027b319795581565b6102096104f5366004611c64565b61109d565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b5f6001600160e01b031982166380ac58cd60e01b148061055157506001600160e01b03198216635b5e139f60e01b145b8061056c57506301ffc9a760e01b6001600160e01b03198316145b92915050565b60605f805461058090611c8c565b80601f01602080910402602001604051908101604052809291908181526020018280546105ac90611c8c565b80156105f75780601f106105ce576101008083540402835291602001916105f7565b820191905f5260205f20905b8154815290600101906020018083116105da57829003601f168201915b5050505050905090565b5f61060b826110ca565b505f828152600460205260409020546001600160a01b031661056c565b5f600260075460ff16600481111561064257610642611bfa565b14801561065757506001600160a01b03821615155b801561056c57505060075461010090046001600160401b03165f908152600260205260409020546001600160a01b0391821691161490565b61069a828233611102565b5050565b6001600160a01b0382166106cc57604051633250574960e11b81525f60048201526024015b60405180910390fd5b5f6106d883833361110f565b9050836001600160a01b0316816001600160a01b031614610726576040516364283d7b60e01b81526001600160a01b03808616600483015260248201849052821660448201526064016106c3565b50505050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161461077557604051636dac6a0960e01b815260040160405180910390fd5b600a805460ff19168215159081179091556040519081527fd6d0fdd597c17a0211f0324826035a55dec84b1e6196f3585be220b46767fbb99060200160405180910390a150565b6107d683838360405180602001604052805f815250610ea8565b505050565b5f61056c826110ca565b5f6001600160a01b03821661080f576040516322718ad960e21b81525f60048201526024016106c3565b506001600160a01b03165f9081526003602052604090205490565b60606001805461058090611c8c565b5f6108426111ad565b600260075460ff16600481111561085b5761085b611bfa565b14158061088b5750600754339061087f9061010090046001600160401b03166107db565b6001600160a01b031614155b80610894575081155b156108b257604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff1916600390811791829055600984905560408051602081019290925246908201523060608201527f000000000000000000000000000000000000000000000000000000000000000060808201527f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba60a08201526001600160401b03610100928390041660c08201523360e08201529081018390526101200160408051808303601f19018152908290528051602091820120600881905560075485845290926101009091046001600160401b0316917f5852bd51fa2990e2712a8f82286a04ca0750a7646a7950235ffefdb10585cefe910160405180910390a3506008546109bf6001600655565b919050565b61069a3383836111d7565b6109d76111ad565b600160075460ff1660048111156109f0576109f0611bfa565b1415806109ff5750600a5460ff165b80610a335750336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614155b80610a7357507355d398326f99059ff775485246999027b31979553f7f000000000000000000000000000000000000000000000000000000000000000014155b80610af557507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ac9573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610aed9190611cc4565b60ff16601214155b15610b1357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660021790556040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201525f907355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610b83573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610ba79190611ce4565b9050610be67355d398326f99059ff775485246999027b31979553373c440f06bbc7e58b0d055815f915447e4ae0e372068015af1d78b58c40000611275565b610bf968015af1d78b58c4000082611d0f565b6040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201527355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610c5a573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610c7e9190611ce4565b14610c9c57604051636dac6a0960e01b815260040160405180910390fd5b600754610cb890339061010090046001600160401b03166112cf565b60075460405168015af1d78b58c400008152339161010090046001600160401b0316907f266845010576f42f87c2d262b76328c22b6797abd6c81b34f59fc1b2da1c487e9060200160405180910390a350610d136001600655565b565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610d5e57604051636dac6a0960e01b815260040160405180910390fd5b806001600160401b03165f03610d8757604051636dac6a0960e01b815260040160405180910390fd5b6007546001600160401b038281166101009092041614610ea557600754610dbd9061010090046001600160401b03166001611d22565b6001600160401b0316816001600160401b0316141580610e1557505f60075460ff166004811115610df057610df0611bfa565b14158015610e155750600460075460ff166004811115610e1257610e12611bfa565b14155b15610e3357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff196001600160401b0384166101008102821668ffffffffffffffffff199093169290921760019081179093555f60088190556009819055600a8054909216909317905560405190917ff48a2acdce0f4a30c2d32425d8827b030bbdff66b7694573d92cdd52b818fd1691a25b50565b610eb384848461069e565b61072633858585856112e8565b6060610ecb826110ca565b505f610ee160408051602081019091525f815290565b90505f815111610eff5760405180602001604052805f815250610f2a565b80610f0984611410565b604051602001610f1a929190611d41565b6040516020818303038152906040525b9392505050565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610f7a57604051636dac6a0960e01b815260040160405180910390fd5b610f826111ad565b6007546001600160401b0384811661010090920416141580610fa2575081155b80610faf57506008548214155b80610fbc57506009548114155b15610fda57604051636dac6a0960e01b815260040160405180910390fd5b600460075460ff166004811115610ff357610ff3611bfa565b1461109357600360075460ff16600481111561101157611011611bfa565b1461102f57604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660041790819055611056906001600160401b036101009091041661149f565b600754604051839161010090046001600160401b0316907f4baa52424160077091b85a05340629c1a44cfac77a87274fad62a384fe6193f0905f90a35b6107d66001600655565b6001600160a01b039182165f90815260056020908152604080832093909416825291909152205460ff1690565b5f818152600260205260408120546001600160a01b03168061056c57604051637e27328960e01b8152600481018490526024016106c3565b6107d683838360016114d7565b6007545f9061010090046001600160401b03168314158061117c5750600260075460ff16600481111561114457611144611bfa565b1415801561117c5750600460075460ff16600481111561116657611166611bfa565b14801561117a57506001600160a01b038416155b155b1561119a57604051636dac6a0960e01b815260040160405180910390fd5b6111a58484846115db565b949350505050565b6002600654036111d057604051633ee5aeb560e01b815260040160405180910390fd5b6002600655565b6001600160a01b03821661120957604051630b61174360e31b81526001600160a01b03831660048201526024016106c3565b6001600160a01b038381165f81815260056020908152604080832094871680845294825291829020805460ff191686151590811790915591519182527f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31910160405180910390a3505050565b604080516001600160a01b0385811660248301528416604482015260648082018490528251808303909101815260849091019091526020810180516001600160e01b03166323b872dd60e01b1790526107269085906116cd565b61069a828260405180602001604052805f815250611739565b6001600160a01b0383163b1561140957604051630a85bd0160e11b81526001600160a01b0384169063150b7a029061132a908890889087908790600401611d6f565b6020604051808303815f875af1925050508015611364575060408051601f3d908101601f1916820190925261136191810190611dab565b60015b6113cb573d808015611391576040519150601f19603f3d011682016040523d82523d5f602084013e611396565b606091505b5080515f036113c357604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b805160208201fd5b6001600160e01b03198116630a85bd0160e11b1461140757604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b505b5050505050565b60605f61141c83611750565b60010190505f816001600160401b0381111561143a5761143a611b0c565b6040519080825280601f01601f191660200182016040528015611464576020820181803683370190505b5090508181016020015b5f19016f181899199a1a9b1b9c1cb0b131b232b360811b600a86061a8153600a850494508461146e57509392505050565b5f6114ab5f835f61110f565b90506001600160a01b03811661069a57604051637e27328960e01b8152600481018390526024016106c3565b80806114eb57506001600160a01b03821615155b156115ac575f6114fa846110ca565b90506001600160a01b038316158015906115265750826001600160a01b0316816001600160a01b031614155b80156115395750611537818461109d565b155b156115625760405163a9fbf51f60e01b81526001600160a01b03841660048201526024016106c3565b81156115aa5783856001600160a01b0316826001600160a01b03167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45b505b50505f90815260046020526040902080546001600160a01b0319166001600160a01b0392909216919091179055565b5f828152600260205260408120546001600160a01b039081169083161561160757611607818486611827565b6001600160a01b03811615611641576116225f855f5f6114d7565b6001600160a01b0381165f90815260036020526040902080545f190190555b6001600160a01b0385161561166f576001600160a01b0385165f908152600360205260409020805460010190555b5f8481526002602052604080822080546001600160a01b0319166001600160a01b0389811691821790925591518793918516917fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef91a4949350505050565b5f5f60205f8451602086015f885af1806116ec576040513d5f823e3d81fd5b50505f513d91508115611703578060011415611710565b6001600160a01b0384163b155b1561072657604051635274afe760e01b81526001600160a01b03851660048201526024016106c3565b611743838361188b565b6107d6335f8585856112e8565b5f8072184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b831061178e5772184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b830492506040015b6d04ee2d6d415b85acef810000000083106117ba576d04ee2d6d415b85acef8100000000830492506020015b662386f26fc1000083106117d857662386f26fc10000830492506010015b6305f5e10083106117f0576305f5e100830492506008015b612710831061180457612710830492506004015b60648310611816576064830492506002015b600a831061056c5760010192915050565b6118328383836118ec565b6107d6576001600160a01b03831661186057604051637e27328960e01b8152600481018290526024016106c3565b60405163177e802f60e01b81526001600160a01b0383166004820152602481018290526044016106c3565b6001600160a01b0382166118b457604051633250574960e11b81525f60048201526024016106c3565b5f6118c083835f61110f565b90506001600160a01b038116156107d6576040516339e3563760e11b81525f60048201526024016106c3565b5f6001600160a01b038316158015906111a55750826001600160a01b0316846001600160a01b031614806119255750611925848461109d565b806111a55750505f908152600460205260409020546001600160a01b03908116911614919050565b6001600160e01b031981168114610ea5575f5ffd5b5f60208284031215611972575f5ffd5b8135610f2a8161194d565b5f5b8381101561199757818101518382015260200161197f565b50505f910152565b5f81518084526119b681602086016020860161197d565b601f01601f19169290920160200192915050565b602081525f610f2a602083018461199f565b5f602082840312156119ec575f5ffd5b5035919050565b80356001600160a01b03811681146109bf575f5ffd5b5f60208284031215611a19575f5ffd5b610f2a826119f3565b5f5f60408385031215611a33575f5ffd5b611a3c836119f3565b946020939093013593505050565b5f5f5f60608486031215611a5c575f5ffd5b611a65846119f3565b9250611a73602085016119f3565b929592945050506040919091013590565b803580151581146109bf575f5ffd5b5f60208284031215611aa3575f5ffd5b610f2a82611a84565b5f5f60408385031215611abd575f5ffd5b611ac6836119f3565b9150611ad460208401611a84565b90509250929050565b80356001600160401b03811681146109bf575f5ffd5b5f60208284031215611b03575f5ffd5b610f2a82611add565b634e487b7160e01b5f52604160045260245ffd5b5f5f5f5f60808587031215611b33575f5ffd5b611b3c856119f3565b9350611b4a602086016119f3565b92506040850135915060608501356001600160401b03811115611b6b575f5ffd5b8501601f81018713611b7b575f5ffd5b80356001600160401b03811115611b9457611b94611b0c565b604051601f8201601f19908116603f011681016001600160401b0381118282101715611bc257611bc2611b0c565b604052818152828201602001891015611bd9575f5ffd5b816020840160208301375f6020838301015280935050505092959194509250565b634e487b7160e01b5f52602160045260245ffd5b6020810160058310611c2e57634e487b7160e01b5f52602160045260245ffd5b91905290565b5f5f5f60608486031215611c46575f5ffd5b611c4f84611add565b95602085013595506040909401359392505050565b5f5f60408385031215611c75575f5ffd5b611c7e836119f3565b9150611ad4602084016119f3565b600181811c90821680611ca057607f821691505b602082108103611cbe57634e487b7160e01b5f52602260045260245ffd5b50919050565b5f60208284031215611cd4575f5ffd5b815160ff81168114610f2a575f5ffd5b5f60208284031215611cf4575f5ffd5b5051919050565b634e487b7160e01b5f52601160045260245ffd5b8082018082111561056c5761056c611cfb565b6001600160401b03818116838216019081111561056c5761056c611cfb565b5f8351611d5281846020880161197d565b835190830190611d6681836020880161197d565b01949350505050565b6001600160a01b03858116825284166020820152604081018390526080606082018190525f90611da19083018461199f565b9695505050505050565b5f60208284031215611dbb575f5ffd5b8151610f2a8161194d56fea26469706673582212205cd0600d0bc59401f6362a6ffeeddd9fccccd322ad458bc4283018628c84b01f64736f6c634300081e0033"
      }
    }
  }
};

// contracts/nftree-generation/scripts/binding-review.mjs
var assert2 = Object.assign((v2, m = "Binding validation failed") => {
  if (!v2) throw Error(m);
}, { equal: (a, b2, m) => {
  if (a !== b2) throw Error(m || "Binding value differs");
}, deepEqual: (a, b2) => {
  if (canonical(a) !== canonical(b2)) throw Error("Binding structure differs");
} });
var peer = "0x" + pinned_build_default.addresses.adapter.slice(2).toLowerCase().padStart(64, "0");
var options = "00030100110100000000000000000000000000030d40";

// contracts/nftree-generation/scripts/configuration-post-state.mjs
var POST_QUERY = "query($tx:JSON!){simulateTransaction(transaction:$tx,checksEnabled:true,doGasSelection:false){effects{status objectChanges(first:50){pageInfo{hasNextPage} nodes{address outputState{asMoveObject{contents{type{repr} json}}}}}}}}";

// contracts/nftree-generation/scripts/acknowledgement-transaction.mjs
import { Transaction as Transaction4 } from "@mysten/sui/transactions";

// docs/multichain/generation-milestone/reserve-review/quote-protocol-template.json
var quote_protocol_template_default = {
  version: 2,
  sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
  expiration: null,
  gasData: {
    budget: null,
    price: null,
    owner: null,
    payment: null
  },
  inputs: [
    {
      Object: {
        SharedObject: {
          objectId: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
          initialSharedVersion: "2",
          mutable: true
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
          initialSharedVersion: "1",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
          initialSharedVersion: "635685314",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
          initialSharedVersion: "635685319",
          mutable: false
        }
      }
    },
    {
      Pure: {
        bytes: "AQ=="
      }
    },
    {
      Pure: {
        bytes: "AA=="
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
          initialSharedVersion: "1089269258",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x52e0e092bf361557c68bd3b1c370b9c102dc834d874624d910e1656ebc08bedc",
          initialSharedVersion: "635685308",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x5f24ef7da5e93ca930bf3270468bc2268e84cc83e52c129ea3311b0d5df50c8e",
          initialSharedVersion: "635685317",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x05195518fab7b80e60bc7df11cf791d8658c614e7ed401fc768db77e744e70b3",
          initialSharedVersion: "635685318",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x492ac62cfb43eb1e858a877cf7a0cf396bf38bc1420c727c747ecc19cf9f4e5c",
          initialSharedVersion: "635685308",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xb6c5e08243222eb0bf95e98c66d26c628f7e0752b7272165d9e7867ff69c36a4",
          initialSharedVersion: "641876028",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x7f7ded52a6073633f8d642458b7899b0eaa7cd1ed7fb8098bd61730853afd3f7",
          initialSharedVersion: "635685317",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xff718d782c8881e9bcdca063c1e7999c77ee22d7cc6b34c84d5f6f4c2654f7da",
          initialSharedVersion: "635685316",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x1ab2f88e12bece2a39addc97cef895e48e0ed97d03eaa9bd2fa943ab4dd7300e",
          initialSharedVersion: "641875710",
          mutable: false
        }
      }
    }
  ],
  commands: [
    {
      MoveCall: {
        package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
        module: "vault",
        function: "quote",
        typeArguments: [
          "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
        ],
        arguments: [
          {
            Input: 0
          },
          {
            Input: 1
          },
          {
            Input: 4
          },
          {
            Input: 5
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "endpoint_v2",
        function: "quote",
        typeArguments: [],
        arguments: [
          {
            Input: 2
          },
          {
            Input: 6
          },
          {
            Result: 0
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
        module: "uln_302",
        function: "quote",
        typeArguments: [],
        arguments: [
          {
            Input: 3
          },
          {
            NestedResult: [
              1,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x011da80425fb389d1090743a2a33a48c479f4fd218a25db2cdc072b768a47ce5",
        module: "executor_worker",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 8
          },
          {
            NestedResult: [
              2,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x63e8c59b39720d833bffca2f50e51e48ef426ac0c6ab8e92cf6475c42f5bd24e",
        module: "executor_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 9
          },
          {
            NestedResult: [
              3,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              4,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x63e8c59b39720d833bffca2f50e51e48ef426ac0c6ab8e92cf6475c42f5bd24e",
        module: "executor_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 9
          },
          {
            NestedResult: [
              3,
              0
            ]
          },
          {
            NestedResult: [
              4,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x011da80425fb389d1090743a2a33a48c479f4fd218a25db2cdc072b768a47ce5",
        module: "executor_worker",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 8
          },
          {
            NestedResult: [
              2,
              0
            ]
          },
          {
            NestedResult: [
              3,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              2,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              8,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              9,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              8,
              0
            ]
          },
          {
            NestedResult: [
              9,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              2,
              1
            ]
          },
          {
            NestedResult: [
              8,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              2,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              13,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              14,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              13,
              0
            ]
          },
          {
            NestedResult: [
              14,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              2,
              1
            ]
          },
          {
            NestedResult: [
              13,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 14
          },
          {
            NestedResult: [
              2,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              18,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              19,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              18,
              0
            ]
          },
          {
            NestedResult: [
              19,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 14
          },
          {
            NestedResult: [
              2,
              1
            ]
          },
          {
            NestedResult: [
              18,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
        module: "uln_302",
        function: "confirm_quote",
        typeArguments: [],
        arguments: [
          {
            Input: 3
          },
          {
            Input: 7
          },
          {
            NestedResult: [
              1,
              0
            ]
          },
          {
            NestedResult: [
              2,
              0
            ]
          },
          {
            NestedResult: [
              2,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "endpoint_v2",
        function: "confirm_quote",
        typeArguments: [],
        arguments: [
          {
            Input: 2
          },
          {
            Result: 0
          },
          {
            NestedResult: [
              1,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
        module: "vault",
        function: "confirm_quote",
        typeArguments: [
          "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
        ],
        arguments: [
          {
            Input: 0
          },
          {
            Input: 1
          },
          {
            Result: 0
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "messaging_fee",
        function: "native_fee",
        typeArguments: [],
        arguments: [
          {
            NestedResult: [
              25,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "messaging_fee",
        function: "zro_fee",
        typeArguments: [],
        arguments: [
          {
            NestedResult: [
              25,
              1
            ]
          }
        ]
      }
    }
  ]
};

// docs/multichain/generation-milestone/reserve-review/send-protocol-template.json
var send_protocol_template_default = {
  version: 2,
  sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
  expiration: null,
  gasData: {
    budget: null,
    price: null,
    owner: null,
    payment: null
  },
  inputs: [
    {
      Object: {
        SharedObject: {
          objectId: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
          initialSharedVersion: "2",
          mutable: true
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
          initialSharedVersion: "1",
          mutable: true
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
          initialSharedVersion: "635685314",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
          initialSharedVersion: "635685319",
          mutable: false
        }
      }
    },
    {
      Pure: {
        bytes: "QSVZBAAAAAA="
      }
    },
    {
      Pure: {
        bytes: "AQ=="
      }
    },
    {
      Pure: {
        bytes: "AA=="
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
          initialSharedVersion: "1089269258",
          mutable: true
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x52e0e092bf361557c68bd3b1c370b9c102dc834d874624d910e1656ebc08bedc",
          initialSharedVersion: "635685308",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x5f24ef7da5e93ca930bf3270468bc2268e84cc83e52c129ea3311b0d5df50c8e",
          initialSharedVersion: "635685317",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x05195518fab7b80e60bc7df11cf791d8658c614e7ed401fc768db77e744e70b3",
          initialSharedVersion: "635685318",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x492ac62cfb43eb1e858a877cf7a0cf396bf38bc1420c727c747ecc19cf9f4e5c",
          initialSharedVersion: "635685308",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xb6c5e08243222eb0bf95e98c66d26c628f7e0752b7272165d9e7867ff69c36a4",
          initialSharedVersion: "641876028",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x7f7ded52a6073633f8d642458b7899b0eaa7cd1ed7fb8098bd61730853afd3f7",
          initialSharedVersion: "635685317",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xff718d782c8881e9bcdca063c1e7999c77ee22d7cc6b34c84d5f6f4c2654f7da",
          initialSharedVersion: "635685316",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x1ab2f88e12bece2a39addc97cef895e48e0ed97d03eaa9bd2fa943ab4dd7300e",
          initialSharedVersion: "641875710",
          mutable: false
        }
      }
    },
    {
      Pure: {
        bytes: "SFlT4urfSqAq+VDPjpFPvStnUjOF5zw2EYNBRZ2NRcQ="
      }
    }
  ],
  commands: [
    {
      SplitCoins: {
        coin: {
          GasCoin: true
        },
        amounts: [
          {
            Input: 4
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
        module: "vault",
        function: "send",
        typeArguments: [
          "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
        ],
        arguments: [
          {
            Input: 0
          },
          {
            Input: 1
          },
          {
            Input: 5
          },
          {
            Input: 6
          },
          {
            NestedResult: [
              0,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "endpoint_v2",
        function: "send",
        typeArguments: [],
        arguments: [
          {
            Input: 2
          },
          {
            Input: 7
          },
          {
            Result: 1
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
        module: "uln_302",
        function: "send",
        typeArguments: [],
        arguments: [
          {
            Input: 3
          },
          {
            NestedResult: [
              2,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x011da80425fb389d1090743a2a33a48c479f4fd218a25db2cdc072b768a47ce5",
        module: "executor_worker",
        function: "assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 9
          },
          {
            NestedResult: [
              3,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x63e8c59b39720d833bffca2f50e51e48ef426ac0c6ab8e92cf6475c42f5bd24e",
        module: "executor_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              4,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              5,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x63e8c59b39720d833bffca2f50e51e48ef426ac0c6ab8e92cf6475c42f5bd24e",
        module: "executor_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              4,
              0
            ]
          },
          {
            NestedResult: [
              5,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x011da80425fb389d1090743a2a33a48c479f4fd218a25db2cdc072b768a47ce5",
        module: "executor_worker",
        function: "confirm_assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 9
          },
          {
            NestedResult: [
              3,
              0
            ]
          },
          {
            NestedResult: [
              4,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              3,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              9,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              10,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              9,
              0
            ]
          },
          {
            NestedResult: [
              10,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              3,
              1
            ]
          },
          {
            NestedResult: [
              9,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 14
          },
          {
            NestedResult: [
              3,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              14,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              15,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              14,
              0
            ]
          },
          {
            NestedResult: [
              15,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 14
          },
          {
            NestedResult: [
              3,
              1
            ]
          },
          {
            NestedResult: [
              14,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 15
          },
          {
            NestedResult: [
              3,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              19,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              20,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              19,
              0
            ]
          },
          {
            NestedResult: [
              20,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 15
          },
          {
            NestedResult: [
              3,
              1
            ]
          },
          {
            NestedResult: [
              19,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
        module: "uln_302",
        function: "confirm_send",
        typeArguments: [],
        arguments: [
          {
            Input: 3
          },
          {
            Input: 2
          },
          {
            Input: 8
          },
          {
            Input: 7
          },
          {
            Result: 1
          },
          {
            NestedResult: [
              2,
              0
            ]
          },
          {
            NestedResult: [
              3,
              0
            ]
          },
          {
            NestedResult: [
              3,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
        module: "vault",
        function: "confirm_send",
        typeArguments: [
          "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
        ],
        arguments: [
          {
            Input: 0
          },
          {
            Input: 1
          },
          {
            Result: 1
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "endpoint_send",
        function: "destroy",
        typeArguments: [],
        arguments: [
          {
            NestedResult: [
              25,
              0
            ]
          }
        ]
      }
    },
    {
      TransferObjects: {
        objects: [
          {
            NestedResult: [
              26,
              0
            ]
          }
        ],
        address: {
          Input: 16
        }
      }
    },
    {
      MoveCall: {
        package: "0x0000000000000000000000000000000000000000000000000000000000000001",
        module: "option",
        function: "destroy_none",
        typeArguments: [
          "0x0000000000000000000000000000000000000000000000000000000000000002::coin::Coin<0x3de1504cf3fd75762759e353d9d95389618e557d0552697f19b52e4e927c1dee::zro::ZRO>"
        ],
        arguments: [
          {
            NestedResult: [
              26,
              1
            ]
          }
        ]
      }
    }
  ]
};

// contracts/nftree-generation/scripts/acknowledgement-transaction.mjs
var assert3 = (v2, m = "Invalid acknowledgement transaction") => {
  if (!v2) throw Error(m);
};
var MESSAGE_CAP = 150000000n;
var GAS_CAP = 50000000n;
function acknowledgementTransaction(kind, fee = 0n) {
  assert3(["quote", "send"].includes(kind));
  const d = structuredClone(kind === "quote" ? quote_protocol_template_default : send_protocol_template_default);
  d.inputs[kind === "quote" ? 4 : 5] = { Pure: { bytes: "Aw==" } };
  if (kind === "send") {
    assert3(fee > 0n && fee <= MESSAGE_CAP);
    d.inputs[4] = { FundsWithdrawal: { reservation: { MaxAmountU64: String(fee) }, typeArg: { Balance: "0x0000000000000000000000000000000000000000000000000000000000000002::sui::SUI" }, withdrawFrom: { Sender: true } } };
    d.commands[0] = { MoveCall: { package: "0x0000000000000000000000000000000000000000000000000000000000000002", module: "coin", function: "redeem_funds", typeArguments: ["0x0000000000000000000000000000000000000000000000000000000000000002::sui::SUI"], arguments: [{ Input: 4 }] } };
  }
  const tx = Transaction4.from(JSON.stringify(d));
  tx.setGasBudget(GAS_CAP);
  tx.setGasPayment([]);
  return tx;
}

// contracts/bnb-generation/browser/purchase-pinned.json
var purchase_pinned_default = {
  schema: 1,
  admin: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789",
  baseNonce: 4746,
  maxTotalFeeWei: "100000000000000",
  suiDigest: "i6nTSPBKFSUf7GXhsnocnFfuuMtkqvQASR91YTZZdfE",
  currency: "0x55d398326f99059fF775485246999027B3197955",
  price: "25000000000000000000",
  recipient: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
  redemption: "0xc99c328de96599e4ea3332e097436cdc5bd542a0a479f892543b3008664128b3",
  gasLimits: [
    7e4,
    5e4,
    18e4,
    7e4,
    14e4
  ],
  steps: [
    {
      label: "Approve exactly 25 USDT",
      to: "0x55d398326f99059fF775485246999027B3197955",
      data: "0x095ea7b3000000000000000000000000418cc337fc19d8cf3b41a9c6e3138a60e34eb9b50000000000000000000000000000000000000000000000015af1d78b58c40000"
    },
    {
      label: "Unpause private purchase",
      to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
      data: "0x325832ac0000000000000000000000000000000000000000000000000000000000000000"
    },
    {
      label: "Buy generation 1",
      to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
      data: "0xa6f2ae3a"
    },
    {
      label: "Pause further purchases",
      to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
      data: "0x325832ac0000000000000000000000000000000000000000000000000000000000000001"
    },
    {
      label: "Lock redemption to dev Sui wallet",
      to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
      data: "0x97579dd3485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
    }
  ],
  codeHashes: {
    "0x74c20dEB476Dca58459956b1AcD65771197900C9": "0x6efff3014469a796f571b62eb85981489aa5c17103595fa4557ce7c72f1e2e1b",
    "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5": "0xa2fb16a830bce8f5c1e173915fb3f7ad7016be1ff9f0891b92a2921dc3ab1ef4",
    "0x55d398326f99059fF775485246999027B3197955": "0x97a48aa4c129657440dafdacd4c836389734d28cc4a0ca7403e68da660a74a59"
  }
};

// contracts/nftree-generation/scripts/acknowledgement-review.mjs
import { encodePacked, keccak256, concatHex } from "viem";
var redemption = purchase_pinned_default.redemption;
var assert4 = Object.assign((v2, m = "Acknowledgement validation failed") => {
  if (!v2) throw Error(m);
}, { equal: (a, b2, m) => {
  if (a !== b2) throw Error(m || "Acknowledgement value differs");
}, deepEqual: (a, b2) => {
  if (canonical(a) !== canonical(b2)) throw Error("Acknowledgement structure differs");
} });
var executorPayee = "0xf99b445ae678d3f28fe7acb91e5d7ee8ab538d7e231a837b12c593fb624ad630";
var dvnPayee = "0x9004e1e4c6dcc42d1b73269db48d510192665677fcad2079a3c7d1e9e971d34e";
var guid = keccak256(encodePacked(["uint64", "uint32", "bytes32", "uint32", "bytes32"], [2n, 30378, C2.package, 30102, peer]));
var payload = "0x0303" + C2.vault.slice(2) + C2.nft.slice(2) + "0000000000000001" + redemption.slice(2) + C2.sender.slice(2);
var packet = concatHex([encodePacked(["uint8", "uint64", "uint32", "bytes32", "uint32", "bytes32"], [1, 2n, 30378, C2.package, 30102, peer]), guid, payload]);
var b64 = (h2) => btoa(String.fromCharCode(...Uint8Array.from(h2.replace(/^0x/, "").match(/../g), (x2) => parseInt(x2, 16))));
var json2 = (o) => o.asMoveObject.contents.json;
var norm = (x2) => JSON.parse(JSON.stringify(x2, (k2, v2) => k2 === "$kind" || k2 === "type" ? void 0 : ["initialSharedVersion", "version"].includes(k2) ? String(v2) : v2));
function verifyAcknowledgement(result, unsigned, before, post, fee) {
  assert4.equal(result.$kind, "Transaction");
  const t17 = result.Transaction;
  assert4.equal(t17.status.success, true);
  assert4.equal(t17.transaction.sender, C2.sender);
  assert4.equal(t17.transaction.gasData.owner, C2.sender);
  assert4.equal(t17.transaction.gasData.budget, "50000000");
  assert4(BigInt(fee) > 0n && BigInt(fee) <= 150000000n);
  for (const k2 of ["inputs", "commands"]) assert4.equal(canonical(norm(t17.transaction[k2])), canonical(norm(unsigned[k2])), "Exact " + k2);
  const expected = acknowledgementTransaction("send", BigInt(fee)).getData();
  for (const k2 of ["inputs", "commands"]) assert4.equal(canonical(norm(unsigned[k2])), canonical(norm(expected[k2])), "Pinned " + k2);
  const [ex, dvn, sent] = t17.events;
  assert4.equal(t17.events.length, 3);
  assert4.equal(ex.eventType, C2.ulnPackage + "::send_uln::ExecutorFeePaidEvent");
  assert4.equal(ex.json.executor, C2.executor);
  assert4.deepEqual(ex.json.guid, { bytes: b64(guid) });
  assert4.equal(ex.json.fee.recipient, executorPayee);
  assert4.equal(dvn.eventType, C2.ulnPackage + "::send_uln::DVNFeePaidEvent");
  assert4.deepEqual(dvn.json.guid, ex.json.guid);
  assert4.deepEqual(dvn.json.dvns, C2.dvns);
  assert4.equal(dvn.json.fees.length, 3);
  for (const f of dvn.json.fees) assert4.equal(f.recipient, dvnPayee);
  assert4.equal(sent.eventType, C2.endpointPackage + "::messaging_channel::PacketSentEvent");
  assert4.deepEqual(sent.json, { encoded_packet: b64(packet), options: b64(options), send_library: C2.ulnPackage });
  const fees = [ex.json.fee, ...dvn.json.fees];
  assert4(fees.every((x2) => BigInt(x2.fee) > 0n));
  assert4.equal(fees.reduce((n, x2) => n + BigInt(x2.fee), 0n), BigInt(fee));
  const g = t17.effects.gasUsed, gross = BigInt(g.computationCost) + BigInt(g.storageCost), net = gross - BigInt(g.storageRebate);
  assert4(gross > 0n && gross <= 50000000n && net >= 0n);
  const balances = /* @__PURE__ */ new Map([[C2.sender, -BigInt(fee) - net]]);
  for (const x2 of fees) balances.set(x2.recipient, (balances.get(x2.recipient) || 0n) + BigInt(x2.fee));
  assert4.equal(t17.balanceChanges.length, balances.size);
  for (const x2 of t17.balanceChanges) {
    assert4(/^0x0*2::sui::SUI$/.test(x2.coinType));
    assert4.equal(BigInt(x2.amount), balances.get(x2.address));
    balances.delete(x2.address);
  }
  assert4.equal(balances.size, 0);
  assert4(!post.errors);
  const effects = post.data.simulateTransaction.effects;
  assert4.equal(effects.status, "SUCCESS");
  assert4.equal(effects.objectChanges.pageInfo.hasNextPage, false);
  const nodes = effects.objectChanges.nodes, at2 = (id) => nodes.find((x2) => x2.address === id)?.outputState;
  const v2 = structuredClone(json2(before.current.vault));
  assert4.equal(v2.phase, 2);
  assert4.equal(v2.nft, null);
  assert4.equal(v2.ack_sent, false);
  v2.ack_sent = true;
  assert4.deepEqual(json2(at2(C2.vault)), v2);
  for (const n of ["oapp", "channel"]) assert4.deepEqual(json2(at2(C2[n])), json2(before.current[n]));
  const path = nodes.filter((x2) => x2.outputState?.asMoveObject?.contents?.json?.name?.remote_eid === 30102);
  assert4.equal(path.length, 1);
  const pathJson = json2(path[0].outputState);
  assert4.deepEqual(pathJson.name, { remote_eid: 30102, remote_oapp: { bytes: b64(peer) } });
  assert4.equal(pathJson.value.outbound_nonce, "2");
  assert4.equal(pathJson.value.lazy_inbound_nonce, "1");
  assert4.equal(pathJson.value.inbound_payload_hashes.size, "0");
  const shared = /* @__PURE__ */ new Map([[C2.vault, "2"], [C2.oapp, "1"], [C2.channel, C2.channelVersion]]), gasIds = /* @__PURE__ */ new Set([t17.effects.gasObject?.objectId, ...t17.transaction.gasData.payment.map((x2) => x2.objectId)]);
  let writes = /* @__PURE__ */ new Set();
  assert4(!t17.effects.changedObjects.some((x2) => x2.objectId === C2.nft), "Original NFT must not be touched");
  for (const x2 of t17.effects.changedObjects) {
    if (x2.inputState === "Exists") {
      if (gasIds.has(x2.objectId)) {
        assert4.equal(x2.inputOwner.AddressOwner, C2.sender);
        assert4(!x2.outputOwner || x2.outputOwner.AddressOwner === C2.sender);
        continue;
      }
      writes.add(x2.objectId);
      assert4.equal(x2.idOperation, "None");
      {
        assert4.equal(x2.outputState, "ObjectWrite");
        assert4.deepEqual(x2.inputOwner, x2.outputOwner);
        if (shared.has(x2.objectId)) assert4.equal(String(x2.outputOwner.Shared.initialSharedVersion), shared.get(x2.objectId));
        else {
          assert4.equal(x2.objectId, path[0].address);
          assert4.equal(x2.outputOwner.ObjectOwner, json2(before.current.channel).channels.id);
        }
      }
    } else if (x2.outputState === "ObjectWrite") {
      assert4.equal(x2.idOperation, "Created");
      assert4(/^0x0*2::coin::Coin<0x0*2::sui::SUI>$/.test(t17.objectTypes[x2.objectId]));
      assert4([C2.sender, executorPayee, dvnPayee].includes(x2.outputOwner.AddressOwner));
    } else assert4(x2.inputState === "DoesNotExist" && x2.outputOwner === null && (x2.outputState === "DoesNotExist" && x2.idOperation === "Created" || x2.outputState === "AccumulatorWriteV1" && x2.idOperation === "None"));
  }
  assert4.deepEqual([...writes].sort(), [C2.vault, C2.oapp, C2.channel, path[0].address].sort());
  return { guid, payload, messageFeeMist: String(fee), netGasMist: String(net), grossGasMist: String(gross), estimatedTotalMist: String(BigInt(fee) + net), fees, acknowledgementOnly: true, submitted: false };
}

// docs/multichain/generation-milestone/return-completed/sui-state.json
var sui_state_default = {
  data: {
    chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
    checkpoint: {
      sequenceNumber: 348404471,
      timestamp: "2026-11-23T16:26:45.957Z"
    },
    nft: {
      address: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
      version: 1106768687,
      digest: "EVdjowwEmsL8cpGCC2Wq3HZdax5VnGfGqR95FXNKJWgc",
      previousTransaction: {
        digest: "CYqYhXynf4fvaUNN8TnQxX6J1YMB3T2ab5avAbtnwZzn"
      },
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
          },
          json: {
            id: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
            number: "2720",
            name: "Tree NFT #2720",
            description: "A unique tree from the Tree NFT collection. Rarity: Common",
            image_url: "https://black-persistent-capybara-279.mypinata.cloud/ipfs/bafybeieozgvnr7qc4ghsq36zwssuhj7xahuznjlmu6g63clnyt37hjsi4m/2720.jpg",
            rarity: "Common"
          }
        }
      }
    },
    vault: {
      address: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
      asMoveObject: {
        contents: {
          type: {
            repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Vault<0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT>"
          },
          json: {
            id: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
            version: "1",
            registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
            cap: {
              id: "0x1711b6b0e442e8299ea3aceb30286234520c8f1c4d2294aa7d031308a3d7bcff",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            nft: null,
            backing: {
              bytes: "BG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWpro="
            },
            route: {
              bytes: "9d/44syWgk+Jc1+hbAaO6BlPu36NaXruvl0TX4pZFus="
            },
            peer: {
              bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
            },
            bound: true,
            paused: false,
            phase: 2,
            generation: "1",
            announced: true,
            ack_sent: false,
            request: {
              bytes: "yZwyjellmeTqMzLgl0Ns3FvVQqCkefiSVDswCGZBKLM="
            },
            recipient: {
              bytes: "SFlT4urfSqAq+VDPjpFPvStnUjOF5zw2EYNBRZ2NRcQ="
            }
          }
        }
      }
    }
  }
};

// docs/multichain/generation-milestone/binding-completed/user-receipt.json
var user_receipt_default = {
  digest: "EkZHu7fFx93QkttEekqXuqHrnQnfS6pNbZLUmeCcVf1a",
  packageId: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
  vaultId: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
  gasMist: "9266747",
  channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
  peer: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c9",
  empty: true,
  generation: 0,
  step: 6,
  bound: true,
  current: {
    chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
    checkpoint: {
      sequenceNumber: 348240446,
      timestamp: "2026-11-23T05:23:36.524Z"
    },
    endpoint: {
      address: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
      version: 1096510922,
      digest: "9o4Ns6gwz7FmuGreY6LA1i1JokDsGsbuDksV9Kf9zSnJ",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 635685314
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::endpoint_v2::EndpointV2"
          },
          json: {
            id: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
            eid: 30378,
            call_cap: {
              id: "0x8de954b904b90f887ff2e81ff3362ca89e883da6529e55723758cd5093234b0d",
              cap_type: {
                "@variant": "Package",
                pos0: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac"
              }
            },
            oapp_registry: {
              oapps: {
                id: "0x720fc2300c05bb7ad68aefec00a9796b4451c4d1df78bc72cd8c98e774220bec",
                size: "143"
              }
            },
            composer_registry: {
              composers: {
                id: "0xb41ca35805177b946bebf5d339712b4e9bb562b068b33851001f9f0b66847814",
                size: "7"
              }
            },
            message_lib_manager: {
              registry: {
                libs: {
                  contents: {
                    id: "0x520bbc08883e22efb29f50283e25b4561ffa7c7b9d7774b14fc1c6272e593e03",
                    size: "2"
                  }
                },
                lib_to_type: {
                  id: "0xb136bb2fc780a76e636c10f10b10ab33754a3573efa5f1285bf2b35eaf73b50d",
                  size: "2"
                }
              },
              default_configs: {
                id: "0xa2371851318b3ba333270daf696dedbc7b89a1107ca362643798c1789ce05a01",
                size: "126"
              },
              oapp_configs: {
                id: "0x0e679b0fcc94fb07a5ec9a14712f8e35e0994b892e64a434e898450eb670e920",
                size: "101"
              }
            }
          }
        }
      }
    },
    uln: {
      address: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
      version: 1096510922,
      digest: "DZyejj6bY4E6EmLaw3kgsWXera1RVmgwL8xLDHrLVhCt",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 635685319
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0::uln_302::Uln302"
          },
          json: {
            id: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
            call_cap: {
              id: "0xfacd801d08e3a99c907148fa00ec5f17a0a3ac831dbc95bcd75e601006caafa9",
              cap_type: {
                "@variant": "Package",
                pos0: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0"
              }
            },
            send_uln: {
              default_executor_configs: {
                id: "0x346b468d90db8743673c7ed4fdbe1c40f6a587aac6acc730b3a9bb86cf0919f4",
                size: "126"
              },
              default_uln_configs: {
                id: "0x2bd7d044d837b718a7852959c701c04e842e648cf9047b442d55c838846a13e5",
                size: "126"
              },
              oapp_executor_configs: {
                id: "0x357a98886ef14de3d15e538a808b410cfe026f6b1f971bb2398978d56e4dc181",
                size: "55"
              },
              oapp_uln_configs: {
                id: "0xc53b8a5592cdeea1a7421d209ba5c70e6843d2911e5bb86ad9fb744d888eab60",
                size: "215"
              }
            },
            receive_uln: {
              default_uln_configs: {
                id: "0x5ddc28272722231ecef30237bb48715f128d6995b89a46db25cd9adae0140835",
                size: "126"
              },
              oapp_uln_configs: {
                id: "0x0d89da4d00f46c4b1dab465a867e60eacbf646e56f8816ae55cd7b9495c1bb09",
                size: "240"
              },
              verification: "0x950f66ed27ec0a01a52bda147d74165d4cc20165f0cee0ecae6aaacde13d7741"
            }
          }
        }
      }
    },
    oapp: {
      address: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
      version: 1096510923,
      digest: "F72w92xHUVa8J2fHAmVkWjyhpmmZubUxTufqNCPKeZ2H",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::OApp"
          },
          json: {
            id: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            oapp_cap: {
              id: "0x6b7c66d2135ce12efa6a23037bff2e5ca1b499db24bc200592d08c2595cf5a3a",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            admin_cap: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
            peer: {
              peers: {
                id: "0x984eb93d6713b0909152e249bcfa465a6661e7403c5b01266353b97ff2318966",
                size: "1"
              }
            },
            enforced_options: {
              options: {
                id: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
                size: "2"
              }
            },
            sending_call: null
          }
        }
      }
    },
    admin: {
      address: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
      version: 1096510923,
      digest: "CXbdvybk5zVFVkPzd7imMGpj85r974bT5B1dMhCybeWo",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::AdminCap"
          },
          json: {
            id: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d"
          }
        }
      }
    },
    vault: {
      address: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
      version: 1096510923,
      digest: "7Ws7gNQy9yg7nmwRQH3XbZYifNLavknAgvLJYg6W1fEz",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 2
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Vault<0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT>"
          },
          json: {
            id: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
            version: "1",
            registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
            cap: {
              id: "0x1711b6b0e442e8299ea3aceb30286234520c8f1c4d2294aa7d031308a3d7bcff",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            nft: null,
            backing: {
              bytes: "BG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWpro="
            },
            route: {
              bytes: "9d/44syWgk+Jc1+hbAaO6BlPu36NaXruvl0TX4pZFus="
            },
            peer: {
              bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
            },
            bound: true,
            paused: false,
            phase: 0,
            generation: "0",
            announced: false,
            ack_sent: false,
            request: {
              bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            },
            recipient: {
              bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            }
          }
        }
      }
    },
    channel: {
      address: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
      version: 1096510923,
      digest: "6YArcujgwcw7YughAQ8GidRijkHX38LpNzSSQ3cnVs8t",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1089269258
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::MessagingChannel"
          },
          json: {
            id: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
            oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            channels: {
              id: "0xc631f02da694ee43bc4923570de9f6d53cbccbdb72986cf63dc84e77744c0e95",
              size: "1"
            },
            is_sending: false
          }
        }
      }
    },
    registration: {
      address: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
      version: 1096510922,
      digest: "8fcLbkwf639cvZt7t54EXo4wypKhLcodVebYfKcCzBx7",
      owner: {
        __typename: "ObjectOwner"
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<address,0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::oapp_registry::OAppRegistration>"
          },
          json: {
            id: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
            name: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            value: {
              messaging_channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
              oapp_info: "AAENo9hF9KsYoKjS8GaXIqHZFhwuphrXFKvBTUFHIf0U5ADwAQABAcRFUZvx1u2KtgAtIK1+2Bqa0l4xmQ35tyID0K2G/S6SBXZhdWx0Cmx6X3JlY2VpdmUDAfXf+OLMloJPiXNfoWwGjugZT7t+jWl67r5dE1+KWRbrAQ2j2EX0qxigqNLwZpciodkWHC6mGtcUq8FNQUch/RTkACBkICYW91pWFKz6JkQYJYUhKZ62qJLu7qOS/u+JSMfrUwFTMHhmNmM2ZDQzOWVhMGRhMmYzZTliYTc5ZTQ5OTJhN2E0YzExMzIxNWZiZjU0YzQ0MmFjOTAyMGMzMTVmOTUzNzA1Ojpjb2xsZWN0aW9uOjpORlQAAAA=",
              delegate: "0x0000000000000000000000000000000000000000000000000000000000000000"
            }
          }
        }
      }
    },
    libraries: {
      dynamicField: {
        value: {
          json: {
            send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib_timeout: null
          }
        }
      }
    },
    send: {
      dynamicField: {
        value: {
          json: {
            confirmations: "5",
            required_dvns: [
              "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
              "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
              "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
              "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
            ],
            optional_dvns: [],
            optional_dvn_threshold: 0
          }
        }
      }
    },
    receive: {
      dynamicField: {
        value: {
          json: {
            confirmations: "20",
            required_dvns: [
              "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
              "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
              "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
              "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
            ],
            optional_dvns: [],
            optional_dvn_threshold: 0
          }
        }
      }
    },
    executor: {
      dynamicField: {
        value: {
          json: {
            max_message_size: "10000",
            executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
          }
        }
      }
    },
    appLibraries: {
      dynamicField: {
        value: {
          json: {
            send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib_timeout: null
          }
        }
      }
    },
    appSend: {
      dynamicField: {
        value: {
          json: {
            use_default_confirmations: false,
            use_default_required_dvns: false,
            use_default_optional_dvns: false,
            uln_config: {
              confirmations: "5",
              required_dvns: [
                "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
                "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
                "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
              ],
              optional_dvns: [],
              optional_dvn_threshold: 0
            }
          }
        }
      }
    },
    appReceive: {
      dynamicField: {
        value: {
          json: {
            use_default_confirmations: false,
            use_default_required_dvns: false,
            use_default_optional_dvns: false,
            uln_config: {
              confirmations: "20",
              required_dvns: [
                "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
                "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
                "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
              ],
              optional_dvns: [],
              optional_dvn_threshold: 0
            }
          }
        }
      }
    },
    appExecutor: {
      dynamicField: {
        value: {
          json: {
            max_message_size: "10000",
            executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
          }
        }
      }
    }
  },
  candidate: {
    chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
    checkpoint: {
      sequenceNumber: 348240446,
      timestamp: "2026-11-23T05:23:36.524Z"
    },
    nft: {
      address: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
      version: 1100579540,
      digest: "4kUybSr2UuXay8xoJrQqsqTLqbmbaBB3nP3pjrAfQXxr",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
          },
          json: {
            id: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
            number: "2720",
            name: "Tree NFT #2720",
            description: "A unique tree from the Tree NFT collection. Rarity: Common",
            image_url: "https://black-persistent-capybara-279.mypinata.cloud/ipfs/bafybeieozgvnr7qc4ghsq36zwssuhj7xahuznjlmu6g63clnyt37hjsi4m/2720.jpg",
            rarity: "Common"
          }
        }
      }
    }
  },
  bnb: {
    chainId: 56,
    block: "0x80f3565",
    adapter: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
    pass: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
    purchasesPaused: true,
    state: "Unconfirmed",
    generation: 0,
    canPlay: false
  },
  bnbConfiguration: {
    complete: true,
    stage: 4,
    block: "0x80f3566",
    hashes: [
      "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733",
      "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
      "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
      "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b"
    ],
    totalGasFeeWei: "23726950000000"
  }
};

// contracts/nftree-generation/scripts/acknowledgement-state.mjs
var check2 = (v2, m) => {
  if (!v2) throw Error(m);
};
function validateAcknowledgementState(s, ack = false) {
  check2(s.chainIdentifier === C2.chain, "Wrong Sui chain");
  const expected = structuredClone(sui_state_default.data.vault.asMoveObject.contents.json);
  expected.ack_sent = ack;
  check2(canonical(s.vault.asMoveObject.contents.json) === canonical(expected), "Vault is not in the expected first acknowledgement state");
  for (const n of ["oapp", "channel"]) check2(canonical(s[n].asMoveObject.contents.json) === canonical(user_receipt_default.current[n].asMoveObject.contents.json), "Bound " + n + " changed");
  const normalized = structuredClone(s);
  for (const n of ["vault", "oapp", "channel"]) normalized[n].asMoveObject.contents.json = structuredClone(baseline_default[n].asMoveObject.contents.json);
  validateConfigState(normalized, 1);
}
function validateAcknowledgementBefore(p) {
  validateAcknowledgementState(p.current);
  const n = p.candidate.nft;
  check2(n.address === C2.nft && n.owner?.address?.address === C2.sender && n.asMoveObject.contents.type.repr === C2.nftType && n.asMoveObject.contents.json.number === "2720", "Original identity or ownership changed");
  check2(p.bnb?.complete && p.bnb.sourceVerified && p.bnb.state === "Locked" && p.bnb.purchasesPaused && !p.bnb.canPlay, "BNB must remain locked");
}

// vendor/generation-acknowledgement/bnb-verifier.mjs
var u1 = "6.15.0";
function hr(t17, e, n) {
  let r = e.split("|").map((s) => s.trim());
  for (let s = 0; s < r.length; s++) switch (e) {
    case "any":
      return;
    case "bigint":
    case "boolean":
    case "number":
    case "string":
      if (typeof t17 === e) return;
  }
  let a = new Error(`invalid value for type ${e}`);
  throw a.code = "INVALID_ARGUMENT", a.argument = `value.${n}`, a.value = t17, a;
}
function I(t17, e, n) {
  for (let r in e) {
    let a = e[r], s = n ? n[r] : null;
    s && hr(a, s, r), Object.defineProperty(t17, r, { enumerable: true, value: a, writable: false });
  }
}
function H0(t17, e) {
  if (t17 == null) return "null";
  if (e == null && (e = /* @__PURE__ */ new Set()), typeof t17 == "object") {
    if (e.has(t17)) return "[Circular]";
    e.add(t17);
  }
  if (Array.isArray(t17)) return "[ " + t17.map((n) => H0(n, e)).join(", ") + " ]";
  if (t17 instanceof Uint8Array) {
    let n = "0123456789abcdef", r = "0x";
    for (let a = 0; a < t17.length; a++) r += n[t17[a] >> 4], r += n[t17[a] & 15];
    return r;
  }
  if (typeof t17 == "object" && typeof t17.toJSON == "function") return H0(t17.toJSON(), e);
  switch (typeof t17) {
    case "boolean":
    case "number":
    case "symbol":
      return t17.toString();
    case "bigint":
      return BigInt(t17).toString();
    case "string":
      return JSON.stringify(t17);
    case "object": {
      let n = Object.keys(t17);
      return n.sort(), "{ " + n.map((r) => `${H0(r, e)}: ${H0(t17[r], e)}`).join(", ") + " }";
    }
  }
  return "[ COULD NOT SERIALIZE ]";
}
function ye(t17, e) {
  return t17 && t17.code === e;
}
function xe(t17, e, n) {
  let r = t17;
  {
    let s = [];
    if (n) {
      if ("message" in n || "code" in n || "name" in n) throw new Error(`value will overwrite populated values: ${H0(n)}`);
      for (let o in n) {
        if (o === "shortMessage") continue;
        let f = n[o];
        s.push(o + "=" + H0(f));
      }
    }
    s.push(`code=${e}`), s.push(`version=${u1}`), s.length && (t17 += " (" + s.join(", ") + ")");
  }
  let a;
  switch (e) {
    case "INVALID_ARGUMENT":
      a = new TypeError(t17);
      break;
    case "NUMERIC_FAULT":
    case "BUFFER_OVERRUN":
      a = new RangeError(t17);
      break;
    default:
      a = new Error(t17);
  }
  return I(a, { code: e }), n && Object.assign(a, n), a.shortMessage == null && I(a, { shortMessage: r }), a;
}
function A(t17, e, n, r) {
  if (!t17) throw xe(e, n, r);
}
function l(t17, e, n, r) {
  A(t17, e, "INVALID_ARGUMENT", { argument: n, value: r });
}
function ee(t17, e, n) {
  n == null && (n = ""), n && (n = ": " + n), A(t17 >= e, "missing argument" + n, "MISSING_ARGUMENT", { count: t17, expectedCount: e }), A(t17 <= e, "too many arguments" + n, "UNEXPECTED_ARGUMENT", { count: t17, expectedCount: e });
}
var gr = ["NFD", "NFC", "NFKD", "NFKC"].reduce((t17, e) => {
  try {
    if ("test".normalize(e) !== "test") throw new Error("bad");
    if (e === "NFD" && "\xE9".normalize("NFD") !== "e\u0301") throw new Error("broken");
    t17.push(e);
  } catch {
  }
  return t17;
}, []);
function Je(t17) {
  A(gr.indexOf(t17) >= 0, "platform missing String.prototype.normalize", "UNSUPPORTED_OPERATION", { operation: "String.prototype.normalize", info: { form: t17 } });
}
function W0(t17, e, n) {
  if (n == null && (n = ""), t17 !== e) {
    let r = n, a = "new";
    n && (r += ".", a += " " + n), A(false, `private constructor; use ${r}from* methods`, "UNSUPPORTED_OPERATION", { operation: a });
  }
}
function l1(t17, e, n) {
  if (t17 instanceof Uint8Array) return n ? new Uint8Array(t17) : t17;
  if (typeof t17 == "string" && t17.match(/^0x(?:[0-9a-f][0-9a-f])*$/i)) {
    let r = new Uint8Array((t17.length - 2) / 2), a = 2;
    for (let s = 0; s < r.length; s++) r[s] = parseInt(t17.substring(a, a + 2), 16), a += 2;
    return r;
  }
  l(false, "invalid BytesLike value", e || "value", t17);
}
function M(t17, e) {
  return l1(t17, e, false);
}
function H(t17, e) {
  return l1(t17, e, true);
}
function G0(t17, e) {
  return !(typeof t17 != "string" || !t17.match(/^0x[0-9A-Fa-f]*$/) || typeof e == "number" && t17.length !== 2 + 2 * e || e === true && t17.length % 2 !== 0);
}
var b1 = "0123456789abcdef";
function C3(t17) {
  let e = M(t17), n = "0x";
  for (let r = 0; r < e.length; r++) {
    let a = e[r];
    n += b1[(a & 240) >> 4] + b1[a & 15];
  }
  return n;
}
function u0(t17) {
  return "0x" + t17.map((e) => C3(e).substring(2)).join("");
}
function b0(t17, e, n) {
  let r = M(t17);
  return n != null && n > r.length && A(false, "cannot slice beyond data bounds", "BUFFER_OVERRUN", { buffer: r, length: r.length, offset: n }), C3(r.slice(e ?? 0, n ?? r.length));
}
function p1(t17, e, n) {
  let r = M(t17);
  A(e >= r.length, "padding exceeds data length", "BUFFER_OVERRUN", { buffer: new Uint8Array(r), length: e, offset: e + 1 });
  let a = new Uint8Array(e);
  return a.fill(0), n ? a.set(r, e - r.length) : a.set(r, 0), C3(a);
}
function Xe(t17, e) {
  return p1(t17, e, true);
}
function Ze(t17, e) {
  return p1(t17, e, false);
}
var we = BigInt(0);
var r0 = BigInt(1);
var q0 = 9007199254740991;
function Ye(t17, e) {
  let n = te(t17, "value"), r = BigInt(a0(e, "width"));
  if (A(n >> r === we, "overflow", "NUMERIC_FAULT", { operation: "fromTwos", fault: "overflow", value: t17 }), n >> r - r0) {
    let a = (r0 << r) - r0;
    return -((~n & a) + r0);
  }
  return n;
}
function Qe(t17, e) {
  let n = e0(t17, "value"), r = BigInt(a0(e, "width")), a = r0 << r - r0;
  if (n < we) {
    n = -n, A(n <= a, "too low", "NUMERIC_FAULT", { operation: "toTwos", fault: "overflow", value: t17 });
    let s = (r0 << r) - r0;
    return (~n & s) + r0;
  } else A(n < a, "too high", "NUMERIC_FAULT", { operation: "toTwos", fault: "overflow", value: t17 });
  return n;
}
function K0(t17, e) {
  let n = te(t17, "value"), r = BigInt(a0(e, "bits"));
  return n & (r0 << r) - r0;
}
function e0(t17, e) {
  switch (typeof t17) {
    case "bigint":
      return t17;
    case "number":
      return l(Number.isInteger(t17), "underflow", e || "value", t17), l(t17 >= -q0 && t17 <= q0, "overflow", e || "value", t17), BigInt(t17);
    case "string":
      try {
        if (t17 === "") throw new Error("empty string");
        return t17[0] === "-" && t17[1] !== "-" ? -BigInt(t17.substring(1)) : BigInt(t17);
      } catch (n) {
        l(false, `invalid BigNumberish string: ${n.message}`, e || "value", t17);
      }
  }
  l(false, "invalid BigNumberish value", e || "value", t17);
}
function te(t17, e) {
  let n = e0(t17, e);
  return A(n >= we, "unsigned value cannot be negative", "NUMERIC_FAULT", { fault: "overflow", operation: "getUint", value: t17 }), n;
}
var h1 = "0123456789abcdef";
function Ee(t17) {
  if (t17 instanceof Uint8Array) {
    let e = "0x0";
    for (let n of t17) e += h1[n >> 4], e += h1[n & 15];
    return BigInt(e);
  }
  return e0(t17);
}
function a0(t17, e) {
  switch (typeof t17) {
    case "bigint":
      return l(t17 >= -q0 && t17 <= q0, "overflow", e || "value", t17), Number(t17);
    case "number":
      return l(Number.isInteger(t17), "underflow", e || "value", t17), l(t17 >= -q0 && t17 <= q0, "overflow", e || "value", t17), t17;
    case "string":
      try {
        if (t17 === "") throw new Error("empty string");
        return a0(BigInt(t17), e);
      } catch (n) {
        l(false, `invalid numeric string: ${n.message}`, e || "value", t17);
      }
  }
  l(false, "invalid numeric value", e || "value", t17);
}
function et(t17) {
  return a0(Ee(t17));
}
function ne(t17, e) {
  let r = te(t17, "value").toString(16);
  if (e == null) r.length % 2 && (r = "0" + r);
  else {
    let a = a0(e, "width");
    for (A(a * 2 >= r.length, `value exceeds width (${a} bytes)`, "NUMERIC_FAULT", { operation: "toBeHex", fault: "overflow", value: t17 }); r.length < a * 2; ) r = "0" + r;
  }
  return "0x" + r;
}
function tt(t17) {
  let e = te(t17, "value");
  if (e === we) return new Uint8Array([]);
  let n = e.toString(16);
  n.length % 2 && (n = "0" + n);
  let r = new Uint8Array(n.length / 2);
  for (let a = 0; a < r.length; a++) {
    let s = a * 2;
    r[a] = parseInt(n.substring(s, s + 2), 16);
  }
  return r;
}
function mr(t17, e, n, r, a) {
  l(false, `invalid codepoint at offset ${e}; ${t17}`, "bytes", n);
}
function g1(t17, e, n, r, a) {
  if (t17 === "BAD_PREFIX" || t17 === "UNEXPECTED_CONTINUE") {
    let s = 0;
    for (let o = e + 1; o < n.length && n[o] >> 6 === 2; o++) s++;
    return s;
  }
  return t17 === "OVERRUN" ? n.length - e - 1 : 0;
}
function yr(t17, e, n, r, a) {
  return t17 === "OVERLONG" ? (l(typeof a == "number", "invalid bad code point for replacement", "badCodepoint", a), r.push(a), 0) : (r.push(65533), g1(t17, e, n, r, a));
}
var m1 = Object.freeze({ error: mr, ignore: g1, replace: yr });
function xr(t17, e) {
  e == null && (e = m1.error);
  let n = M(t17, "bytes"), r = [], a = 0;
  for (; a < n.length; ) {
    let s = n[a++];
    if (!(s >> 7)) {
      r.push(s);
      continue;
    }
    let o = null, f = null;
    if ((s & 224) === 192) o = 1, f = 127;
    else if ((s & 240) === 224) o = 2, f = 2047;
    else if ((s & 248) === 240) o = 3, f = 65535;
    else {
      (s & 192) === 128 ? a += e("UNEXPECTED_CONTINUE", a - 1, n, r) : a += e("BAD_PREFIX", a - 1, n, r);
      continue;
    }
    if (a - 1 + o >= n.length) {
      a += e("OVERRUN", a - 1, n, r);
      continue;
    }
    let c = s & (1 << 8 - o - 1) - 1;
    for (let d = 0; d < o; d++) {
      let u = n[a];
      if ((u & 192) != 128) {
        a += e("MISSING_CONTINUE", a, n, r), c = null;
        break;
      }
      c = c << 6 | u & 63, a++;
    }
    if (c !== null) {
      if (c > 1114111) {
        a += e("OUT_OF_RANGE", a - 1 - o, n, r, c);
        continue;
      }
      if (c >= 55296 && c <= 57343) {
        a += e("UTF16_SURROGATE", a - 1 - o, n, r, c);
        continue;
      }
      if (c <= f) {
        a += e("OVERLONG", a - 1 - o, n, r, c);
        continue;
      }
      r.push(c);
    }
  }
  return r;
}
function re(t17, e) {
  l(typeof t17 == "string", "invalid string value", "str", t17), e != null && (Je(e), t17 = t17.normalize(e));
  let n = [];
  for (let r = 0; r < t17.length; r++) {
    let a = t17.charCodeAt(r);
    if (a < 128) n.push(a);
    else if (a < 2048) n.push(a >> 6 | 192), n.push(a & 63 | 128);
    else if ((a & 64512) == 55296) {
      r++;
      let s = t17.charCodeAt(r);
      l(r < t17.length && (s & 64512) === 56320, "invalid surrogate pair", "str", t17);
      let o = 65536 + ((a & 1023) << 10) + (s & 1023);
      n.push(o >> 18 | 240), n.push(o >> 12 & 63 | 128), n.push(o >> 6 & 63 | 128), n.push(o & 63 | 128);
    } else n.push(a >> 12 | 224), n.push(a >> 6 & 63 | 128), n.push(a & 63 | 128);
  }
  return new Uint8Array(n);
}
function wr(t17) {
  return t17.map((e) => e <= 65535 ? String.fromCharCode(e) : (e -= 65536, String.fromCharCode((e >> 10 & 1023) + 55296, (e & 1023) + 56320))).join("");
}
function nt(t17, e) {
  return wr(xr(t17, e));
}
function y1(t17) {
  let e = [];
  for (; t17; ) e.unshift(t17 & 255), t17 >>= 8;
  return e;
}
function w1(t17) {
  if (Array.isArray(t17)) {
    let r = [];
    if (t17.forEach(function(s) {
      r = r.concat(w1(s));
    }), r.length <= 55) return r.unshift(192 + r.length), r;
    let a = y1(r.length);
    return a.unshift(247 + a.length), a.concat(r);
  }
  let e = Array.prototype.slice.call(M(t17, "object"));
  if (e.length === 1 && e[0] <= 127) return e;
  if (e.length <= 55) return e.unshift(128 + e.length), e;
  let n = y1(e.length);
  return n.unshift(183 + n.length), n.concat(e);
}
var x1 = "0123456789abcdef";
function rt(t17) {
  let e = "0x";
  for (let n of w1(t17)) e += x1[n >> 4], e += x1[n & 15];
  return e;
}
var V = 32;
var at = new Uint8Array(V);
var Er = ["then"];
var ve = {};
var S1 = /* @__PURE__ */ new WeakMap();
function U0(t17) {
  return S1.get(t17);
}
function E1(t17, e) {
  S1.set(t17, e);
}
function ae(t17, e) {
  let n = new Error(`deferred error during ABI decoding triggered accessing ${t17}`);
  throw n.error = e, n;
}
function st(t17, e, n) {
  return t17.indexOf(null) >= 0 ? e.map((r, a) => r instanceof l0 ? st(U0(r), r, n) : r) : t17.reduce((r, a, s) => {
    let o = e.getValue(a);
    return a in r || (n && o instanceof l0 && (o = st(U0(o), o, n)), r[a] = o), r;
  }, {});
}
var l0 = class t extends Array {
  #e;
  constructor(...e) {
    let n = e[0], r = e[1], a = (e[2] || []).slice(), s = true;
    n !== ve && (r = e, a = [], s = false), super(r.length), r.forEach((c, d) => {
      this[d] = c;
    });
    let o = a.reduce((c, d) => (typeof d == "string" && c.set(d, (c.get(d) || 0) + 1), c), /* @__PURE__ */ new Map());
    if (E1(this, Object.freeze(r.map((c, d) => {
      let u = a[d];
      return u != null && o.get(u) === 1 ? u : null;
    }))), this.#e = [], this.#e == null && this.#e, !s) return;
    Object.freeze(this);
    let f = new Proxy(this, { get: (c, d, u) => {
      if (typeof d == "string") {
        if (d.match(/^[0-9]+$/)) {
          let p = a0(d, "%index");
          if (p < 0 || p >= this.length) throw new RangeError("out of result range");
          let m = c[p];
          return m instanceof Error && ae(`index ${p}`, m), m;
        }
        if (Er.indexOf(d) >= 0) return Reflect.get(c, d, u);
        let g = c[d];
        if (g instanceof Function) return function(...p) {
          return g.apply(this === u ? c : this, p);
        };
        if (!(d in c)) return c.getValue.apply(this === u ? c : this, [d]);
      }
      return Reflect.get(c, d, u);
    } });
    return E1(f, U0(this)), f;
  }
  toArray(e) {
    let n = [];
    return this.forEach((r, a) => {
      r instanceof Error && ae(`index ${a}`, r), e && r instanceof t && (r = r.toArray(e)), n.push(r);
    }), n;
  }
  toObject(e) {
    let n = U0(this);
    return n.reduce((r, a, s) => (A(a != null, `value at index ${s} unnamed`, "UNSUPPORTED_OPERATION", { operation: "toObject()" }), st(n, this, e)), {});
  }
  slice(e, n) {
    e == null && (e = 0), e < 0 && (e += this.length, e < 0 && (e = 0)), n == null && (n = this.length), n < 0 && (n += this.length, n < 0 && (n = 0)), n > this.length && (n = this.length);
    let r = U0(this), a = [], s = [];
    for (let o = e; o < n; o++) a.push(this[o]), s.push(r[o]);
    return new t(ve, a, s);
  }
  filter(e, n) {
    let r = U0(this), a = [], s = [];
    for (let o = 0; o < this.length; o++) {
      let f = this[o];
      f instanceof Error && ae(`index ${o}`, f), e.call(n, f, o, this) && (a.push(f), s.push(r[o]));
    }
    return new t(ve, a, s);
  }
  map(e, n) {
    let r = [];
    for (let a = 0; a < this.length; a++) {
      let s = this[a];
      s instanceof Error && ae(`index ${a}`, s), r.push(e.call(n, s, a, this));
    }
    return r;
  }
  getValue(e) {
    let n = U0(this).indexOf(e);
    if (n === -1) return;
    let r = this[n];
    return r instanceof Error && ae(`property ${JSON.stringify(e)}`, r.error), r;
  }
  static fromItems(e, n) {
    return new t(ve, e, n);
  }
};
function v1(t17) {
  let e = tt(t17);
  return A(e.length <= V, "value out-of-bounds", "BUFFER_OVERRUN", { buffer: e, length: V, offset: e.length }), e.length !== V && (e = H(u0([at.slice(e.length % V), e]))), e;
}
var _ = class {
  name;
  type;
  localName;
  dynamic;
  constructor(e, n, r, a) {
    I(this, { name: e, type: n, localName: r, dynamic: a }, { name: "string", type: "string", localName: "string", dynamic: "boolean" });
  }
  _throwError(e, n) {
    l(false, e, this.localName, n);
  }
};
var D0 = class {
  #e;
  #t;
  constructor() {
    this.#e = [], this.#t = 0;
  }
  get data() {
    return u0(this.#e);
  }
  get length() {
    return this.#t;
  }
  #n(e) {
    return this.#e.push(e), this.#t += e.length, e.length;
  }
  appendWriter(e) {
    return this.#n(H(e.data));
  }
  writeBytes(e) {
    let n = H(e), r = n.length % V;
    return r && (n = H(u0([n, at.slice(r)]))), this.#n(n);
  }
  writeValue(e) {
    return this.#n(v1(e));
  }
  writeUpdatableValue() {
    let e = this.#e.length;
    return this.#e.push(at), this.#t += V, (n) => {
      this.#e[e] = v1(n);
    };
  }
};
var Se = class t2 {
  allowLoose;
  #e;
  #t;
  #n;
  #r;
  #a;
  constructor(e, n, r) {
    I(this, { allowLoose: !!n }), this.#e = H(e), this.#n = 0, this.#r = null, this.#a = r ?? 1024, this.#t = 0;
  }
  get data() {
    return C3(this.#e);
  }
  get dataLength() {
    return this.#e.length;
  }
  get consumed() {
    return this.#t;
  }
  get bytes() {
    return new Uint8Array(this.#e);
  }
  #s(e) {
    if (this.#r) return this.#r.#s(e);
    this.#n += e, A(this.#a < 1 || this.#n <= this.#a * this.dataLength, `compressed ABI data exceeds inflation ratio of ${this.#a} ( see: https://github.com/ethers-io/ethers.js/issues/4537 )`, "BUFFER_OVERRUN", { buffer: H(this.#e), offset: this.#t, length: e, info: { bytesRead: this.#n, dataLength: this.dataLength } });
  }
  #i(e, n, r) {
    let a = Math.ceil(n / V) * V;
    return this.#t + a > this.#e.length && (this.allowLoose && r && this.#t + n <= this.#e.length ? a = n : A(false, "data out-of-bounds", "BUFFER_OVERRUN", { buffer: H(this.#e), length: this.#e.length, offset: this.#t + a })), this.#e.slice(this.#t, this.#t + a);
  }
  subReader(e) {
    let n = new t2(this.#e.slice(this.#t + e), this.allowLoose, this.#a);
    return n.#r = this, n;
  }
  readBytes(e, n) {
    let r = this.#i(0, e, !!n);
    return this.#s(e), this.#t += r.length, r.slice(0, e);
  }
  readValue() {
    return Ee(this.readBytes(V));
  }
  readIndex() {
    return et(this.readBytes(V));
  }
};
function it(t17) {
  if (!Number.isSafeInteger(t17) || t17 < 0) throw new Error(`Wrong positive integer: ${t17}`);
}
function ot(t17, ...e) {
  if (!(t17 instanceof Uint8Array)) throw new Error("Expected Uint8Array");
  if (e.length > 0 && !e.includes(t17.length)) throw new Error(`Expected Uint8Array of length ${e}, not of length=${t17.length}`);
}
function ft(t17, e = true) {
  if (t17.destroyed) throw new Error("Hash instance has been destroyed");
  if (e && t17.finished) throw new Error("Hash#digest() has already been called");
}
function B1(t17, e) {
  ot(t17);
  let n = e.outputLen;
  if (t17.length < n) throw new Error(`digestInto() expects output buffer of length at least ${n}`);
}
var Be = BigInt(4294967295);
var I1 = BigInt(32);
function vr(t17, e = false) {
  return e ? { h: Number(t17 & Be), l: Number(t17 >> I1 & Be) } : { h: Number(t17 >> I1 & Be) | 0, l: Number(t17 & Be) | 0 };
}
function T1(t17, e = false) {
  let n = new Uint32Array(t17.length), r = new Uint32Array(t17.length);
  for (let a = 0; a < t17.length; a++) {
    let { h: s, l: o } = vr(t17[a], e);
    [n[a], r[a]] = [s, o];
  }
  return [n, r];
}
var A1 = (t17, e, n) => t17 << n | e >>> 32 - n;
var k1 = (t17, e, n) => e << n | t17 >>> 32 - n;
var C1 = (t17, e, n) => e << n - 32 | t17 >>> 64 - n;
var O1 = (t17, e, n) => t17 << n - 32 | e >>> 64 - n;
var Sr = (t17) => t17 instanceof Uint8Array;
var P1 = (t17) => new Uint32Array(t17.buffer, t17.byteOffset, Math.floor(t17.byteLength / 4));
var Br = new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
if (!Br) throw new Error("Non little-endian hardware is not supported");
function Ir(t17) {
  if (typeof t17 != "string") throw new Error(`utf8ToBytes expected string, got ${typeof t17}`);
  return new Uint8Array(new TextEncoder().encode(t17));
}
function Te(t17) {
  if (typeof t17 == "string" && (t17 = Ir(t17)), !Sr(t17)) throw new Error(`expected Uint8Array, got ${typeof t17}`);
  return t17;
}
var Ie = class {
  clone() {
    return this._cloneInto();
  }
};
var ba = {}.toString;
function N1(t17) {
  let e = (r) => t17().update(Te(r)).digest(), n = t17();
  return e.outputLen = n.outputLen, e.blockLen = n.blockLen, e.create = () => t17(), e;
}
function R1(t17) {
  let e = (r, a) => t17(a).update(Te(r)).digest(), n = t17({});
  return e.outputLen = n.outputLen, e.blockLen = n.blockLen, e.create = (r) => t17(r), e;
}
var [D1, F1, L1] = [[], [], []];
var Tr = BigInt(0);
var se = BigInt(1);
var Ar = BigInt(2);
var kr = BigInt(7);
var Cr = BigInt(256);
var Or = BigInt(113);
for (let t17 = 0, e = se, n = 1, r = 0; t17 < 24; t17++) {
  [n, r] = [r, (2 * n + 3 * r) % 5], D1.push(2 * (5 * r + n)), F1.push((t17 + 1) * (t17 + 2) / 2 % 64);
  let a = Tr;
  for (let s = 0; s < 7; s++) e = (e << se ^ (e >> kr) * Or) % Cr, e & Ar && (a ^= se << (se << BigInt(s)) - se);
  L1.push(a);
}
var [Pr, Nr] = T1(L1, true);
var _1 = (t17, e, n) => n > 32 ? C1(t17, e, n) : A1(t17, e, n);
var U1 = (t17, e, n) => n > 32 ? O1(t17, e, n) : k1(t17, e, n);
function Rr(t17, e = 24) {
  let n = new Uint32Array(10);
  for (let r = 24 - e; r < 24; r++) {
    for (let o = 0; o < 10; o++) n[o] = t17[o] ^ t17[o + 10] ^ t17[o + 20] ^ t17[o + 30] ^ t17[o + 40];
    for (let o = 0; o < 10; o += 2) {
      let f = (o + 8) % 10, c = (o + 2) % 10, d = n[c], u = n[c + 1], g = _1(d, u, 1) ^ n[f], p = U1(d, u, 1) ^ n[f + 1];
      for (let m = 0; m < 50; m += 10) t17[o + m] ^= g, t17[o + m + 1] ^= p;
    }
    let a = t17[2], s = t17[3];
    for (let o = 0; o < 24; o++) {
      let f = F1[o], c = _1(a, s, f), d = U1(a, s, f), u = D1[o];
      a = t17[u], s = t17[u + 1], t17[u] = c, t17[u + 1] = d;
    }
    for (let o = 0; o < 50; o += 10) {
      for (let f = 0; f < 10; f++) n[f] = t17[o + f];
      for (let f = 0; f < 10; f++) t17[o + f] ^= ~n[(f + 2) % 10] & n[(f + 4) % 10];
    }
    t17[0] ^= Pr[r], t17[1] ^= Nr[r];
  }
  n.fill(0);
}
var Ae = class t3 extends Ie {
  constructor(e, n, r, a = false, s = 24) {
    if (super(), this.blockLen = e, this.suffix = n, this.outputLen = r, this.enableXOF = a, this.rounds = s, this.pos = 0, this.posOut = 0, this.finished = false, this.destroyed = false, it(r), 0 >= this.blockLen || this.blockLen >= 200) throw new Error("Sha3 supports only keccak-f1600 function");
    this.state = new Uint8Array(200), this.state32 = P1(this.state);
  }
  keccak() {
    Rr(this.state32, this.rounds), this.posOut = 0, this.pos = 0;
  }
  update(e) {
    ft(this);
    let { blockLen: n, state: r } = this;
    e = Te(e);
    let a = e.length;
    for (let s = 0; s < a; ) {
      let o = Math.min(n - this.pos, a - s);
      for (let f = 0; f < o; f++) r[this.pos++] ^= e[s++];
      this.pos === n && this.keccak();
    }
    return this;
  }
  finish() {
    if (this.finished) return;
    this.finished = true;
    let { state: e, suffix: n, pos: r, blockLen: a } = this;
    e[r] ^= n, n & 128 && r === a - 1 && this.keccak(), e[a - 1] ^= 128, this.keccak();
  }
  writeInto(e) {
    ft(this, false), ot(e), this.finish();
    let n = this.state, { blockLen: r } = this;
    for (let a = 0, s = e.length; a < s; ) {
      this.posOut >= r && this.keccak();
      let o = Math.min(r - this.posOut, s - a);
      e.set(n.subarray(this.posOut, this.posOut + o), a), this.posOut += o, a += o;
    }
    return e;
  }
  xofInto(e) {
    if (!this.enableXOF) throw new Error("XOF is not possible for this instance");
    return this.writeInto(e);
  }
  xof(e) {
    return it(e), this.xofInto(new Uint8Array(e));
  }
  digestInto(e) {
    if (B1(e, this), this.finished) throw new Error("digest() was already called");
    return this.writeInto(e), this.destroy(), e;
  }
  digest() {
    return this.digestInto(new Uint8Array(this.outputLen));
  }
  destroy() {
    this.destroyed = true, this.state.fill(0);
  }
  _cloneInto(e) {
    let { blockLen: n, suffix: r, outputLen: a, rounds: s, enableXOF: o } = this;
    return e || (e = new t3(n, r, a, o, s)), e.state32.set(this.state32), e.pos = this.pos, e.posOut = this.posOut, e.finished = this.finished, e.rounds = s, e.suffix = r, e.outputLen = a, e.enableXOF = o, e.destroyed = this.destroyed, e;
  }
};
var B0 = (t17, e, n) => N1(() => new Ae(e, t17, n));
var ma = B0(6, 144, 224 / 8);
var ya = B0(6, 136, 256 / 8);
var xa = B0(6, 104, 384 / 8);
var wa = B0(6, 72, 512 / 8);
var Ea = B0(1, 144, 224 / 8);
var M1 = B0(1, 136, 256 / 8);
var va = B0(1, 104, 384 / 8);
var Sa = B0(1, 72, 512 / 8);
var V1 = (t17, e, n) => R1((r = {}) => new Ae(e, t17, r.dkLen === void 0 ? n : r.dkLen, true));
var Ba = V1(31, 168, 128 / 8);
var Ia = V1(31, 136, 256 / 8);
var z1 = false;
var $1 = function(t17) {
  return M1(t17);
};
var j1 = $1;
function U(t17) {
  let e = M(t17, "data");
  return C3(j1(e));
}
U._ = $1;
U.lock = function() {
  z1 = true;
};
U.register = function(t17) {
  if (z1) throw new TypeError("keccak256 is locked");
  j1 = t17;
};
Object.freeze(U);
var _r = BigInt(0);
var Ur = BigInt(36);
function H1(t17) {
  t17 = t17.toLowerCase();
  let e = t17.substring(2).split(""), n = new Uint8Array(40);
  for (let a = 0; a < 40; a++) n[a] = e[a].charCodeAt(0);
  let r = M(U(n));
  for (let a = 0; a < 40; a += 2) r[a >> 1] >> 4 >= 8 && (e[a] = e[a].toUpperCase()), (r[a >> 1] & 15) >= 8 && (e[a + 1] = e[a + 1].toUpperCase());
  return "0x" + e.join("");
}
var ct = {};
for (let t17 = 0; t17 < 10; t17++) ct[String(t17)] = String(t17);
for (let t17 = 0; t17 < 26; t17++) ct[String.fromCharCode(65 + t17)] = String(10 + t17);
var W1 = 15;
function Dr(t17) {
  t17 = t17.toUpperCase(), t17 = t17.substring(4) + t17.substring(0, 2) + "00";
  let e = t17.split("").map((r) => ct[r]).join("");
  for (; e.length >= W1; ) {
    let r = e.substring(0, W1);
    e = parseInt(r, 10) % 97 + e.substring(r.length);
  }
  let n = String(98 - parseInt(e, 10) % 97);
  for (; n.length < 2; ) n = "0" + n;
  return n;
}
var Fr = (function() {
  let t17 = {};
  for (let e = 0; e < 36; e++) {
    let n = "0123456789abcdefghijklmnopqrstuvwxyz"[e];
    t17[n] = BigInt(e);
  }
  return t17;
})();
function Lr(t17) {
  t17 = t17.toLowerCase();
  let e = _r;
  for (let n = 0; n < t17.length; n++) e = e * Ur + Fr[t17[n]];
  return e;
}
function X(t17) {
  if (l(typeof t17 == "string", "invalid address", "address", t17), t17.match(/^(0x)?[0-9a-fA-F]{40}$/)) {
    t17.startsWith("0x") || (t17 = "0x" + t17);
    let e = H1(t17);
    return l(!t17.match(/([A-F].*[a-f])|([a-f].*[A-F])/) || e === t17, "bad address checksum", "address", t17), e;
  }
  if (t17.match(/^XE[0-9]{2}[0-9A-Za-z]{30,31}$/)) {
    l(t17.substring(2, 4) === Dr(t17), "bad icap checksum", "address", t17);
    let e = Lr(t17.substring(4)).toString(16);
    for (; e.length < 40; ) e = "0" + e;
    return H1("0x" + e);
  }
  l(false, "invalid address", "address", t17);
}
function ie(t17) {
  let e = X(t17.from), r = e0(t17.nonce, "tx.nonce").toString(16);
  return r === "0" ? r = "0x" : r.length % 2 ? r = "0x0" + r : r = "0x" + r, X(b0(U(rt([e, r])), 12));
}
var s0 = {};
function y(t17, e) {
  let n = false;
  return e < 0 && (n = true, e *= -1), new P(s0, `${n ? "" : "u"}int${e}`, t17, { signed: n, width: e });
}
function T(t17, e) {
  return new P(s0, `bytes${e || ""}`, t17, { size: e });
}
var G1 = /* @__PURE__ */ Symbol.for("_ethers_typed");
var P = class t4 {
  type;
  value;
  #e;
  _typedSymbol;
  constructor(e, n, r, a) {
    a == null && (a = null), W0(s0, e, "Typed"), I(this, { _typedSymbol: G1, type: n, value: r }), this.#e = a, this.format();
  }
  format() {
    if (this.type === "array") throw new Error("");
    if (this.type === "dynamicArray") throw new Error("");
    return this.type === "tuple" ? `tuple(${this.value.map((e) => e.format()).join(",")})` : this.type;
  }
  defaultValue() {
    return 0;
  }
  minValue() {
    return 0;
  }
  maxValue() {
    return 0;
  }
  isBigInt() {
    return !!this.type.match(/^u?int[0-9]+$/);
  }
  isData() {
    return this.type.startsWith("bytes");
  }
  isString() {
    return this.type === "string";
  }
  get tupleName() {
    if (this.type !== "tuple") throw TypeError("not a tuple");
    return this.#e;
  }
  get arrayLength() {
    if (this.type !== "array") throw TypeError("not an array");
    return this.#e === true ? -1 : this.#e === false ? this.value.length : null;
  }
  static from(e, n) {
    return new t4(s0, e, n);
  }
  static uint8(e) {
    return y(e, 8);
  }
  static uint16(e) {
    return y(e, 16);
  }
  static uint24(e) {
    return y(e, 24);
  }
  static uint32(e) {
    return y(e, 32);
  }
  static uint40(e) {
    return y(e, 40);
  }
  static uint48(e) {
    return y(e, 48);
  }
  static uint56(e) {
    return y(e, 56);
  }
  static uint64(e) {
    return y(e, 64);
  }
  static uint72(e) {
    return y(e, 72);
  }
  static uint80(e) {
    return y(e, 80);
  }
  static uint88(e) {
    return y(e, 88);
  }
  static uint96(e) {
    return y(e, 96);
  }
  static uint104(e) {
    return y(e, 104);
  }
  static uint112(e) {
    return y(e, 112);
  }
  static uint120(e) {
    return y(e, 120);
  }
  static uint128(e) {
    return y(e, 128);
  }
  static uint136(e) {
    return y(e, 136);
  }
  static uint144(e) {
    return y(e, 144);
  }
  static uint152(e) {
    return y(e, 152);
  }
  static uint160(e) {
    return y(e, 160);
  }
  static uint168(e) {
    return y(e, 168);
  }
  static uint176(e) {
    return y(e, 176);
  }
  static uint184(e) {
    return y(e, 184);
  }
  static uint192(e) {
    return y(e, 192);
  }
  static uint200(e) {
    return y(e, 200);
  }
  static uint208(e) {
    return y(e, 208);
  }
  static uint216(e) {
    return y(e, 216);
  }
  static uint224(e) {
    return y(e, 224);
  }
  static uint232(e) {
    return y(e, 232);
  }
  static uint240(e) {
    return y(e, 240);
  }
  static uint248(e) {
    return y(e, 248);
  }
  static uint256(e) {
    return y(e, 256);
  }
  static uint(e) {
    return y(e, 256);
  }
  static int8(e) {
    return y(e, -8);
  }
  static int16(e) {
    return y(e, -16);
  }
  static int24(e) {
    return y(e, -24);
  }
  static int32(e) {
    return y(e, -32);
  }
  static int40(e) {
    return y(e, -40);
  }
  static int48(e) {
    return y(e, -48);
  }
  static int56(e) {
    return y(e, -56);
  }
  static int64(e) {
    return y(e, -64);
  }
  static int72(e) {
    return y(e, -72);
  }
  static int80(e) {
    return y(e, -80);
  }
  static int88(e) {
    return y(e, -88);
  }
  static int96(e) {
    return y(e, -96);
  }
  static int104(e) {
    return y(e, -104);
  }
  static int112(e) {
    return y(e, -112);
  }
  static int120(e) {
    return y(e, -120);
  }
  static int128(e) {
    return y(e, -128);
  }
  static int136(e) {
    return y(e, -136);
  }
  static int144(e) {
    return y(e, -144);
  }
  static int152(e) {
    return y(e, -152);
  }
  static int160(e) {
    return y(e, -160);
  }
  static int168(e) {
    return y(e, -168);
  }
  static int176(e) {
    return y(e, -176);
  }
  static int184(e) {
    return y(e, -184);
  }
  static int192(e) {
    return y(e, -192);
  }
  static int200(e) {
    return y(e, -200);
  }
  static int208(e) {
    return y(e, -208);
  }
  static int216(e) {
    return y(e, -216);
  }
  static int224(e) {
    return y(e, -224);
  }
  static int232(e) {
    return y(e, -232);
  }
  static int240(e) {
    return y(e, -240);
  }
  static int248(e) {
    return y(e, -248);
  }
  static int256(e) {
    return y(e, -256);
  }
  static int(e) {
    return y(e, -256);
  }
  static bytes1(e) {
    return T(e, 1);
  }
  static bytes2(e) {
    return T(e, 2);
  }
  static bytes3(e) {
    return T(e, 3);
  }
  static bytes4(e) {
    return T(e, 4);
  }
  static bytes5(e) {
    return T(e, 5);
  }
  static bytes6(e) {
    return T(e, 6);
  }
  static bytes7(e) {
    return T(e, 7);
  }
  static bytes8(e) {
    return T(e, 8);
  }
  static bytes9(e) {
    return T(e, 9);
  }
  static bytes10(e) {
    return T(e, 10);
  }
  static bytes11(e) {
    return T(e, 11);
  }
  static bytes12(e) {
    return T(e, 12);
  }
  static bytes13(e) {
    return T(e, 13);
  }
  static bytes14(e) {
    return T(e, 14);
  }
  static bytes15(e) {
    return T(e, 15);
  }
  static bytes16(e) {
    return T(e, 16);
  }
  static bytes17(e) {
    return T(e, 17);
  }
  static bytes18(e) {
    return T(e, 18);
  }
  static bytes19(e) {
    return T(e, 19);
  }
  static bytes20(e) {
    return T(e, 20);
  }
  static bytes21(e) {
    return T(e, 21);
  }
  static bytes22(e) {
    return T(e, 22);
  }
  static bytes23(e) {
    return T(e, 23);
  }
  static bytes24(e) {
    return T(e, 24);
  }
  static bytes25(e) {
    return T(e, 25);
  }
  static bytes26(e) {
    return T(e, 26);
  }
  static bytes27(e) {
    return T(e, 27);
  }
  static bytes28(e) {
    return T(e, 28);
  }
  static bytes29(e) {
    return T(e, 29);
  }
  static bytes30(e) {
    return T(e, 30);
  }
  static bytes31(e) {
    return T(e, 31);
  }
  static bytes32(e) {
    return T(e, 32);
  }
  static address(e) {
    return new t4(s0, "address", e);
  }
  static bool(e) {
    return new t4(s0, "bool", !!e);
  }
  static bytes(e) {
    return new t4(s0, "bytes", e);
  }
  static string(e) {
    return new t4(s0, "string", e);
  }
  static array(e, n) {
    throw new Error("not implemented yet");
  }
  static tuple(e, n) {
    throw new Error("not implemented yet");
  }
  static overrides(e) {
    return new t4(s0, "overrides", Object.assign({}, e));
  }
  static isTyped(e) {
    return e && typeof e == "object" && "_typedSymbol" in e && e._typedSymbol === G1;
  }
  static dereference(e, n) {
    if (t4.isTyped(e)) {
      if (e.type !== n) throw new Error(`invalid type: expecetd ${n}, got ${e.type}`);
      return e.value;
    }
    return e;
  }
};
var ke = class extends _ {
  constructor(e) {
    super("address", "address", e, false);
  }
  defaultValue() {
    return "0x0000000000000000000000000000000000000000";
  }
  encode(e, n) {
    let r = P.dereference(n, "string");
    try {
      r = X(r);
    } catch (a) {
      return this._throwError(a.message, n);
    }
    return e.writeValue(r);
  }
  decode(e) {
    return X(ne(e.readValue(), 20));
  }
};
var Ce = class extends _ {
  coder;
  constructor(e) {
    super(e.name, e.type, "_", e.dynamic), this.coder = e;
  }
  defaultValue() {
    return this.coder.defaultValue();
  }
  encode(e, n) {
    return this.coder.encode(e, n);
  }
  decode(e) {
    return this.coder.decode(e);
  }
};
function dt(t17, e, n) {
  let r = [];
  if (Array.isArray(n)) r = n;
  else if (n && typeof n == "object") {
    let c = {};
    r = e.map((d) => {
      let u = d.localName;
      return A(u, "cannot encode object for signature with missing names", "INVALID_ARGUMENT", { argument: "values", info: { coder: d }, value: n }), A(!c[u], "cannot encode object for signature with duplicate names", "INVALID_ARGUMENT", { argument: "values", info: { coder: d }, value: n }), c[u] = true, n[u];
    });
  } else l(false, "invalid tuple value", "tuple", n);
  l(e.length === r.length, "types/value length mismatch", "tuple", n);
  let a = new D0(), s = new D0(), o = [];
  e.forEach((c, d) => {
    let u = r[d];
    if (c.dynamic) {
      let g = s.length;
      c.encode(s, u);
      let p = a.writeUpdatableValue();
      o.push((m) => {
        p(m + g);
      });
    } else c.encode(a, u);
  }), o.forEach((c) => {
    c(a.length);
  });
  let f = t17.appendWriter(a);
  return f += t17.appendWriter(s), f;
}
function ut(t17, e) {
  let n = [], r = [], a = t17.subReader(0);
  return e.forEach((s) => {
    let o = null;
    if (s.dynamic) {
      let f = t17.readIndex(), c = a.subReader(f);
      try {
        o = s.decode(c);
      } catch (d) {
        if (ye(d, "BUFFER_OVERRUN")) throw d;
        o = d, o.baseType = s.name, o.name = s.localName, o.type = s.type;
      }
    } else try {
      o = s.decode(t17);
    } catch (f) {
      if (ye(f, "BUFFER_OVERRUN")) throw f;
      o = f, o.baseType = s.name, o.name = s.localName, o.type = s.type;
    }
    if (o == null) throw new Error("investigate");
    n.push(o), r.push(s.localName || null);
  }), l0.fromItems(n, r);
}
var Oe = class extends _ {
  coder;
  length;
  constructor(e, n, r) {
    let a = e.type + "[" + (n >= 0 ? n : "") + "]", s = n === -1 || e.dynamic;
    super("array", a, r, s), I(this, { coder: e, length: n });
  }
  defaultValue() {
    let e = this.coder.defaultValue(), n = [];
    for (let r = 0; r < this.length; r++) n.push(e);
    return n;
  }
  encode(e, n) {
    let r = P.dereference(n, "array");
    Array.isArray(r) || this._throwError("expected array value", r);
    let a = this.length;
    a === -1 && (a = r.length, e.writeValue(r.length)), ee(r.length, a, "coder array" + (this.localName ? " " + this.localName : ""));
    let s = [];
    for (let o = 0; o < r.length; o++) s.push(this.coder);
    return dt(e, s, r);
  }
  decode(e) {
    let n = this.length;
    n === -1 && (n = e.readIndex(), A(n * V <= e.dataLength, "insufficient data length", "BUFFER_OVERRUN", { buffer: e.bytes, offset: n * V, length: e.dataLength }));
    let r = [];
    for (let a = 0; a < n; a++) r.push(new Ce(this.coder));
    return ut(e, r);
  }
};
var Pe = class extends _ {
  constructor(e) {
    super("bool", "bool", e, false);
  }
  defaultValue() {
    return false;
  }
  encode(e, n) {
    let r = P.dereference(n, "bool");
    return e.writeValue(r ? 1 : 0);
  }
  decode(e) {
    return !!e.readValue();
  }
};
var oe = class extends _ {
  constructor(e, n) {
    super(e, e, n, true);
  }
  defaultValue() {
    return "0x";
  }
  encode(e, n) {
    n = H(n);
    let r = e.writeValue(n.length);
    return r += e.writeBytes(n), r;
  }
  decode(e) {
    return e.readBytes(e.readIndex(), true);
  }
};
var Ne = class extends oe {
  constructor(e) {
    super("bytes", e);
  }
  decode(e) {
    return C3(super.decode(e));
  }
};
var Re = class extends _ {
  size;
  constructor(e, n) {
    let r = "bytes" + String(e);
    super(r, r, n, false), I(this, { size: e }, { size: "number" });
  }
  defaultValue() {
    return "0x0000000000000000000000000000000000000000000000000000000000000000".substring(0, 2 + this.size * 2);
  }
  encode(e, n) {
    let r = H(P.dereference(n, this.type));
    return r.length !== this.size && this._throwError("incorrect data length", n), e.writeBytes(r);
  }
  decode(e) {
    return C3(e.readBytes(this.size));
  }
};
var zr = new Uint8Array([]);
var _e = class extends _ {
  constructor(e) {
    super("null", "", e, false);
  }
  defaultValue() {
    return null;
  }
  encode(e, n) {
    return n != null && this._throwError("not null", n), e.writeBytes(zr);
  }
  decode(e) {
    return e.readBytes(0), null;
  }
};
var $r = BigInt(0);
var jr = BigInt(1);
var Hr = BigInt("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
var Ue = class extends _ {
  size;
  signed;
  constructor(e, n, r) {
    let a = (n ? "int" : "uint") + e * 8;
    super(a, a, r, false), I(this, { size: e, signed: n }, { size: "number", signed: "boolean" });
  }
  defaultValue() {
    return 0;
  }
  encode(e, n) {
    let r = e0(P.dereference(n, this.type)), a = K0(Hr, V * 8);
    if (this.signed) {
      let s = K0(a, this.size * 8 - 1);
      (r > s || r < -(s + jr)) && this._throwError("value out-of-bounds", n), r = Qe(r, 8 * V);
    } else (r < $r || r > K0(a, this.size * 8)) && this._throwError("value out-of-bounds", n);
    return e.writeValue(r);
  }
  decode(e) {
    let n = K0(e.readValue(), this.size * 8);
    return this.signed && (n = Ye(n, this.size * 8)), n;
  }
};
var De = class extends oe {
  constructor(e) {
    super("string", e);
  }
  defaultValue() {
    return "";
  }
  encode(e, n) {
    return super.encode(e, re(P.dereference(n, "string")));
  }
  decode(e) {
    return nt(super.decode(e));
  }
};
var F0 = class extends _ {
  coders;
  constructor(e, n) {
    let r = false, a = [];
    e.forEach((o) => {
      o.dynamic && (r = true), a.push(o.type);
    });
    let s = "tuple(" + a.join(",") + ")";
    super("tuple", s, n, r), I(this, { coders: Object.freeze(e.slice()) });
  }
  defaultValue() {
    let e = [];
    this.coders.forEach((r) => {
      e.push(r.defaultValue());
    });
    let n = this.coders.reduce((r, a) => {
      let s = a.localName;
      return s && (r[s] || (r[s] = 0), r[s]++), r;
    }, {});
    return this.coders.forEach((r, a) => {
      let s = r.localName;
      !s || n[s] !== 1 || (s === "length" && (s = "_length"), e[s] == null && (e[s] = e[a]));
    }), Object.freeze(e);
  }
  encode(e, n) {
    let r = P.dereference(n, "tuple");
    return dt(e, this.coders, r);
  }
  decode(e) {
    return ut(e, this.coders);
  }
};
function I0(t17) {
  return U(re(t17));
}
function W(t17) {
  let e = /* @__PURE__ */ new Set();
  return t17.forEach((n) => e.add(n)), Object.freeze(e);
}
var Wr = "external public payable override";
var Gr = W(Wr.split(" "));
var nn = "constant external internal payable private public pure view override";
var qr = W(nn.split(" "));
var rn = "constructor error event fallback function receive struct";
var an = W(rn.split(" "));
var sn = "calldata memory storage payable indexed";
var Kr = W(sn.split(" "));
var Jr = "tuple returns";
var Xr = [rn, sn, Jr, nn].join(" ");
var Zr = W(Xr.split(" "));
var Yr = { "(": "OPEN_PAREN", ")": "CLOSE_PAREN", "[": "OPEN_BRACKET", "]": "CLOSE_BRACKET", ",": "COMMA", "@": "AT" };
var Qr = new RegExp("^(\\s*)");
var e6 = new RegExp("^([0-9]+)");
var t6 = new RegExp("^([a-zA-Z$_][a-zA-Z0-9$_]*)");
var on = new RegExp("^([a-zA-Z$_][a-zA-Z0-9$_]*)$");
var fn = new RegExp("^(address|bool|bytes([0-9]*)|string|u?int([0-9]*))$");
var i0 = class t5 {
  #e;
  #t;
  get offset() {
    return this.#e;
  }
  get length() {
    return this.#t.length - this.#e;
  }
  constructor(e) {
    this.#e = 0, this.#t = e.slice();
  }
  clone() {
    return new t5(this.#t);
  }
  reset() {
    this.#e = 0;
  }
  #n(e = 0, n = 0) {
    return new t5(this.#t.slice(e, n).map((r) => Object.freeze(Object.assign({}, r, { match: r.match - e, linkBack: r.linkBack - e, linkNext: r.linkNext - e }))));
  }
  popKeyword(e) {
    let n = this.peek();
    if (n.type !== "KEYWORD" || !e.has(n.text)) throw new Error(`expected keyword ${n.text}`);
    return this.pop().text;
  }
  popType(e) {
    if (this.peek().type !== e) {
      let n = this.peek();
      throw new Error(`expected ${e}; got ${n.type} ${JSON.stringify(n.text)}`);
    }
    return this.pop().text;
  }
  popParen() {
    let e = this.peek();
    if (e.type !== "OPEN_PAREN") throw new Error("bad start");
    let n = this.#n(this.#e + 1, e.match + 1);
    return this.#e = e.match + 1, n;
  }
  popParams() {
    let e = this.peek();
    if (e.type !== "OPEN_PAREN") throw new Error("bad start");
    let n = [];
    for (; this.#e < e.match - 1; ) {
      let r = this.peek().linkNext;
      n.push(this.#n(this.#e + 1, r)), this.#e = r;
    }
    return this.#e = e.match + 1, n;
  }
  peek() {
    if (this.#e >= this.#t.length) throw new Error("out-of-bounds");
    return this.#t[this.#e];
  }
  peekKeyword(e) {
    let n = this.peekType("KEYWORD");
    return n != null && e.has(n) ? n : null;
  }
  peekType(e) {
    if (this.length === 0) return null;
    let n = this.peek();
    return n.type === e ? n.text : null;
  }
  pop() {
    let e = this.peek();
    return this.#e++, e;
  }
  toString() {
    let e = [];
    for (let n = this.#e; n < this.#t.length; n++) {
      let r = this.#t[n];
      e.push(`${r.type}:${r.text}`);
    }
    return `<TokenString ${e.join(" ")}>`;
  }
};
function O0(t17) {
  let e = [], n = (o) => {
    let f = s < t17.length ? JSON.stringify(t17[s]) : "$EOI";
    throw new Error(`invalid token ${f} at ${s}: ${o}`);
  }, r = [], a = [], s = 0;
  for (; s < t17.length; ) {
    let o = t17.substring(s), f = o.match(Qr);
    f && (s += f[1].length, o = t17.substring(s));
    let c = { depth: r.length, linkBack: -1, linkNext: -1, match: -1, type: "", text: "", offset: s, value: -1 };
    e.push(c);
    let d = Yr[o[0]] || "";
    if (d) {
      if (c.type = d, c.text = o[0], s++, d === "OPEN_PAREN") r.push(e.length - 1), a.push(e.length - 1);
      else if (d == "CLOSE_PAREN") r.length === 0 && n("no matching open bracket"), c.match = r.pop(), e[c.match].match = e.length - 1, c.depth--, c.linkBack = a.pop(), e[c.linkBack].linkNext = e.length - 1;
      else if (d === "COMMA") c.linkBack = a.pop(), e[c.linkBack].linkNext = e.length - 1, a.push(e.length - 1);
      else if (d === "OPEN_BRACKET") c.type = "BRACKET";
      else if (d === "CLOSE_BRACKET") {
        let u = e.pop().text;
        if (e.length > 0 && e[e.length - 1].type === "NUMBER") {
          let g = e.pop().text;
          u = g + u, e[e.length - 1].value = a0(g);
        }
        if (e.length === 0 || e[e.length - 1].type !== "BRACKET") throw new Error("missing opening bracket");
        e[e.length - 1].text += u;
      }
      continue;
    }
    if (f = o.match(t6), f) {
      if (c.text = f[1], s += c.text.length, Zr.has(c.text)) {
        c.type = "KEYWORD";
        continue;
      }
      if (c.text.match(fn)) {
        c.type = "TYPE";
        continue;
      }
      c.type = "ID";
      continue;
    }
    if (f = o.match(e6), f) {
      c.text = f[1], c.type = "NUMBER", s += c.text.length;
      continue;
    }
    throw new Error(`unexpected token ${JSON.stringify(o[0])} at position ${s}`);
  }
  return new i0(e.map((o) => Object.freeze(o)));
}
function q1(t17, e) {
  let n = [];
  for (let r in e.keys()) t17.has(r) && n.push(r);
  if (n.length > 1) throw new Error(`conflicting types: ${n.join(", ")}`);
}
function Fe(t17, e) {
  if (e.peekKeyword(an)) {
    let n = e.pop().text;
    if (n !== t17) throw new Error(`expected ${t17}, got ${n}`);
  }
  return e.popType("ID");
}
function x0(t17, e) {
  let n = /* @__PURE__ */ new Set();
  for (; ; ) {
    let r = t17.peekType("KEYWORD");
    if (r == null || e && !e.has(r)) break;
    if (t17.pop(), n.has(r)) throw new Error(`duplicate keywords: ${JSON.stringify(r)}`);
    n.add(r);
  }
  return Object.freeze(n);
}
function cn(t17) {
  let e = x0(t17, qr);
  return q1(e, W("constant payable nonpayable".split(" "))), q1(e, W("pure view payable nonpayable".split(" "))), e.has("view") ? "view" : e.has("pure") ? "pure" : e.has("payable") ? "payable" : e.has("nonpayable") ? "nonpayable" : e.has("constant") ? "view" : "nonpayable";
}
function y0(t17, e) {
  return t17.popParams().map((n) => D.from(n, e));
}
function dn(t17) {
  if (t17.peekType("AT")) {
    if (t17.pop(), t17.peekType("NUMBER")) return e0(t17.pop().text);
    throw new Error("invalid gas");
  }
  return null;
}
function L0(t17) {
  if (t17.length) throw new Error(`unexpected tokens at offset ${t17.offset}: ${t17.toString()}`);
}
var n6 = new RegExp(/^(.*)\[([0-9]*)\]$/);
function K1(t17) {
  let e = t17.match(fn);
  if (l(e, "invalid type", "type", t17), t17 === "uint") return "uint256";
  if (t17 === "int") return "int256";
  if (e[2]) {
    let n = parseInt(e[2]);
    l(n !== 0 && n <= 32, "invalid bytes length", "type", t17);
  } else if (e[3]) {
    let n = parseInt(e[3]);
    l(n !== 0 && n <= 256 && n % 8 === 0, "invalid numeric width", "type", t17);
  }
  return t17;
}
var N = {};
var G = /* @__PURE__ */ Symbol.for("_ethers_internal");
var J1 = "_ParamTypeInternal";
var X1 = "_ErrorInternal";
var Z1 = "_EventInternal";
var Y1 = "_ConstructorInternal";
var Q1 = "_FallbackInternal";
var en = "_FunctionInternal";
var tn = "_StructInternal";
var D = class t7 {
  name;
  type;
  baseType;
  indexed;
  components;
  arrayLength;
  arrayChildren;
  constructor(e, n, r, a, s, o, f, c) {
    if (W0(e, N, "ParamType"), Object.defineProperty(this, G, { value: J1 }), o && (o = Object.freeze(o.slice())), a === "array") {
      if (f == null || c == null) throw new Error("");
    } else if (f != null || c != null) throw new Error("");
    if (a === "tuple") {
      if (o == null) throw new Error("");
    } else if (o != null) throw new Error("");
    I(this, { name: n, type: r, baseType: a, indexed: s, components: o, arrayLength: f, arrayChildren: c });
  }
  format(e) {
    if (e == null && (e = "sighash"), e === "json") {
      let r = this.name || "";
      if (this.isArray()) {
        let s = JSON.parse(this.arrayChildren.format("json"));
        return s.name = r, s.type += `[${this.arrayLength < 0 ? "" : String(this.arrayLength)}]`, JSON.stringify(s);
      }
      let a = { type: this.baseType === "tuple" ? "tuple" : this.type, name: r };
      return typeof this.indexed == "boolean" && (a.indexed = this.indexed), this.isTuple() && (a.components = this.components.map((s) => JSON.parse(s.format(e)))), JSON.stringify(a);
    }
    let n = "";
    return this.isArray() ? (n += this.arrayChildren.format(e), n += `[${this.arrayLength < 0 ? "" : String(this.arrayLength)}]`) : this.isTuple() ? n += "(" + this.components.map((r) => r.format(e)).join(e === "full" ? ", " : ",") + ")" : n += this.type, e !== "sighash" && (this.indexed === true && (n += " indexed"), e === "full" && this.name && (n += " " + this.name)), n;
  }
  isArray() {
    return this.baseType === "array";
  }
  isTuple() {
    return this.baseType === "tuple";
  }
  isIndexable() {
    return this.indexed != null;
  }
  walk(e, n) {
    if (this.isArray()) {
      if (!Array.isArray(e)) throw new Error("invalid array value");
      if (this.arrayLength !== -1 && e.length !== this.arrayLength) throw new Error("array is wrong length");
      let r = this;
      return e.map((a) => r.arrayChildren.walk(a, n));
    }
    if (this.isTuple()) {
      if (!Array.isArray(e)) throw new Error("invalid tuple value");
      if (e.length !== this.components.length) throw new Error("array is wrong length");
      let r = this;
      return e.map((a, s) => r.components[s].walk(a, n));
    }
    return n(this.type, e);
  }
  #e(e, n, r, a) {
    if (this.isArray()) {
      if (!Array.isArray(n)) throw new Error("invalid array value");
      if (this.arrayLength !== -1 && n.length !== this.arrayLength) throw new Error("array is wrong length");
      let o = this.arrayChildren, f = n.slice();
      f.forEach((c, d) => {
        o.#e(e, c, r, (u) => {
          f[d] = u;
        });
      }), a(f);
      return;
    }
    if (this.isTuple()) {
      let o = this.components, f;
      if (Array.isArray(n)) f = n.slice();
      else {
        if (n == null || typeof n != "object") throw new Error("invalid tuple value");
        f = o.map((c) => {
          if (!c.name) throw new Error("cannot use object value with unnamed components");
          if (!(c.name in n)) throw new Error(`missing value for component ${c.name}`);
          return n[c.name];
        });
      }
      if (f.length !== this.components.length) throw new Error("array is wrong length");
      f.forEach((c, d) => {
        o[d].#e(e, c, r, (u) => {
          f[d] = u;
        });
      }), a(f);
      return;
    }
    let s = r(this.type, n);
    s.then ? e.push((async function() {
      a(await s);
    })()) : a(s);
  }
  async walkAsync(e, n) {
    let r = [], a = [e];
    return this.#e(r, e, n, (s) => {
      a[0] = s;
    }), r.length && await Promise.all(r), a[0];
  }
  static from(e, n) {
    if (t7.isParamType(e)) return e;
    if (typeof e == "string") try {
      return t7.from(O0(e), n);
    } catch {
      l(false, "invalid param type", "obj", e);
    }
    else if (e instanceof i0) {
      let f = "", c = "", d = null;
      x0(e, W(["tuple"])).has("tuple") || e.peekType("OPEN_PAREN") ? (c = "tuple", d = e.popParams().map((S) => t7.from(S)), f = `tuple(${d.map((S) => S.format()).join(",")})`) : (f = K1(e.popType("TYPE")), c = f);
      let u = null, g = null;
      for (; e.length && e.peekType("BRACKET"); ) {
        let S = e.pop();
        u = new t7(N, "", f, c, null, d, g, u), g = S.value, f += S.text, c = "array", d = null;
      }
      let p = null;
      if (x0(e, Kr).has("indexed")) {
        if (!n) throw new Error("");
        p = true;
      }
      let E = e.peekType("ID") ? e.pop().text : "";
      if (e.length) throw new Error("leftover tokens");
      return new t7(N, E, f, c, p, d, g, u);
    }
    let r = e.name;
    l(!r || typeof r == "string" && r.match(on), "invalid name", "obj.name", r);
    let a = e.indexed;
    a != null && (l(n, "parameter cannot be indexed", "obj.indexed", e.indexed), a = !!a);
    let s = e.type, o = s.match(n6);
    if (o) {
      let f = parseInt(o[2] || "-1"), c = t7.from({ type: o[1], components: e.components });
      return new t7(N, r || "", s, "array", a, null, f, c);
    }
    if (s === "tuple" || s.startsWith("tuple(") || s.startsWith("(")) {
      let f = e.components != null ? e.components.map((d) => t7.from(d)) : null;
      return new t7(N, r || "", s, "tuple", a, f, null, null);
    }
    return s = K1(e.type), new t7(N, r || "", s, s, a, null, null, null);
  }
  static isParamType(e) {
    return e && e[G] === J1;
  }
};
var C0 = class t8 {
  type;
  inputs;
  constructor(e, n, r) {
    W0(e, N, "Fragment"), r = Object.freeze(r.slice()), I(this, { type: n, inputs: r });
  }
  static from(e) {
    if (typeof e == "string") {
      try {
        t8.from(JSON.parse(e));
      } catch {
      }
      return t8.from(O0(e));
    }
    if (e instanceof i0) switch (e.peekKeyword(an)) {
      case "constructor":
        return A0.from(e);
      case "error":
        return Z.from(e);
      case "event":
        return T0.from(e);
      case "fallback":
      case "receive":
        return ce.from(e);
      case "function":
        return k0.from(e);
      case "struct":
        return J0.from(e);
    }
    else if (typeof e == "object") {
      switch (e.type) {
        case "constructor":
          return A0.from(e);
        case "error":
          return Z.from(e);
        case "event":
          return T0.from(e);
        case "fallback":
        case "receive":
          return ce.from(e);
        case "function":
          return k0.from(e);
        case "struct":
          return J0.from(e);
      }
      A(false, `unsupported type: ${e.type}`, "UNSUPPORTED_OPERATION", { operation: "Fragment.from" });
    }
    l(false, "unsupported frgament object", "obj", e);
  }
  static isConstructor(e) {
    return A0.isFragment(e);
  }
  static isError(e) {
    return Z.isFragment(e);
  }
  static isEvent(e) {
    return T0.isFragment(e);
  }
  static isFunction(e) {
    return k0.isFragment(e);
  }
  static isStruct(e) {
    return J0.isFragment(e);
  }
};
var M0 = class extends C0 {
  name;
  constructor(e, n, r, a) {
    super(e, n, a), l(typeof r == "string" && r.match(on), "invalid identifier", "name", r), a = Object.freeze(a.slice()), I(this, { name: r });
  }
};
function fe(t17, e) {
  return "(" + e.map((n) => n.format(t17)).join(t17 === "full" ? ", " : ",") + ")";
}
var Z = class t9 extends M0 {
  constructor(e, n, r) {
    super(e, "error", n, r), Object.defineProperty(this, G, { value: X1 });
  }
  get selector() {
    return I0(this.format("sighash")).substring(0, 10);
  }
  format(e) {
    if (e == null && (e = "sighash"), e === "json") return JSON.stringify({ type: "error", name: this.name, inputs: this.inputs.map((r) => JSON.parse(r.format(e))) });
    let n = [];
    return e !== "sighash" && n.push("error"), n.push(this.name + fe(e, this.inputs)), n.join(" ");
  }
  static from(e) {
    if (t9.isFragment(e)) return e;
    if (typeof e == "string") return t9.from(O0(e));
    if (e instanceof i0) {
      let n = Fe("error", e), r = y0(e);
      return L0(e), new t9(N, n, r);
    }
    return new t9(N, e.name, e.inputs ? e.inputs.map(D.from) : []);
  }
  static isFragment(e) {
    return e && e[G] === X1;
  }
};
var T0 = class t10 extends M0 {
  anonymous;
  constructor(e, n, r, a) {
    super(e, "event", n, r), Object.defineProperty(this, G, { value: Z1 }), I(this, { anonymous: a });
  }
  get topicHash() {
    return I0(this.format("sighash"));
  }
  format(e) {
    if (e == null && (e = "sighash"), e === "json") return JSON.stringify({ type: "event", anonymous: this.anonymous, name: this.name, inputs: this.inputs.map((r) => JSON.parse(r.format(e))) });
    let n = [];
    return e !== "sighash" && n.push("event"), n.push(this.name + fe(e, this.inputs)), e !== "sighash" && this.anonymous && n.push("anonymous"), n.join(" ");
  }
  static getTopicHash(e, n) {
    return n = (n || []).map((a) => D.from(a)), new t10(N, e, n, false).topicHash;
  }
  static from(e) {
    if (t10.isFragment(e)) return e;
    if (typeof e == "string") try {
      return t10.from(O0(e));
    } catch {
      l(false, "invalid event fragment", "obj", e);
    }
    else if (e instanceof i0) {
      let n = Fe("event", e), r = y0(e, true), a = !!x0(e, W(["anonymous"])).has("anonymous");
      return L0(e), new t10(N, n, r, a);
    }
    return new t10(N, e.name, e.inputs ? e.inputs.map((n) => D.from(n, true)) : [], !!e.anonymous);
  }
  static isFragment(e) {
    return e && e[G] === Z1;
  }
};
var A0 = class t11 extends C0 {
  payable;
  gas;
  constructor(e, n, r, a, s) {
    super(e, n, r), Object.defineProperty(this, G, { value: Y1 }), I(this, { payable: a, gas: s });
  }
  format(e) {
    if (A(e != null && e !== "sighash", "cannot format a constructor for sighash", "UNSUPPORTED_OPERATION", { operation: "format(sighash)" }), e === "json") return JSON.stringify({ type: "constructor", stateMutability: this.payable ? "payable" : "undefined", payable: this.payable, gas: this.gas != null ? this.gas : void 0, inputs: this.inputs.map((r) => JSON.parse(r.format(e))) });
    let n = [`constructor${fe(e, this.inputs)}`];
    return this.payable && n.push("payable"), this.gas != null && n.push(`@${this.gas.toString()}`), n.join(" ");
  }
  static from(e) {
    if (t11.isFragment(e)) return e;
    if (typeof e == "string") try {
      return t11.from(O0(e));
    } catch {
      l(false, "invalid constuctor fragment", "obj", e);
    }
    else if (e instanceof i0) {
      x0(e, W(["constructor"]));
      let n = y0(e), r = !!x0(e, Gr).has("payable"), a = dn(e);
      return L0(e), new t11(N, "constructor", n, r, a);
    }
    return new t11(N, "constructor", e.inputs ? e.inputs.map(D.from) : [], !!e.payable, e.gas != null ? e.gas : null);
  }
  static isFragment(e) {
    return e && e[G] === Y1;
  }
};
var ce = class t12 extends C0 {
  payable;
  constructor(e, n, r) {
    super(e, "fallback", n), Object.defineProperty(this, G, { value: Q1 }), I(this, { payable: r });
  }
  format(e) {
    let n = this.inputs.length === 0 ? "receive" : "fallback";
    if (e === "json") {
      let r = this.payable ? "payable" : "nonpayable";
      return JSON.stringify({ type: n, stateMutability: r });
    }
    return `${n}()${this.payable ? " payable" : ""}`;
  }
  static from(e) {
    if (t12.isFragment(e)) return e;
    if (typeof e == "string") try {
      return t12.from(O0(e));
    } catch {
      l(false, "invalid fallback fragment", "obj", e);
    }
    else if (e instanceof i0) {
      let n = e.toString(), r = e.peekKeyword(W(["fallback", "receive"]));
      if (l(r, "type must be fallback or receive", "obj", n), e.popKeyword(W(["fallback", "receive"])) === "receive") {
        let f = y0(e);
        return l(f.length === 0, "receive cannot have arguments", "obj.inputs", f), x0(e, W(["payable"])), L0(e), new t12(N, [], true);
      }
      let s = y0(e);
      s.length ? l(s.length === 1 && s[0].type === "bytes", "invalid fallback inputs", "obj.inputs", s.map((f) => f.format("minimal")).join(", ")) : s = [D.from("bytes")];
      let o = cn(e);
      if (l(o === "nonpayable" || o === "payable", "fallback cannot be constants", "obj.stateMutability", o), x0(e, W(["returns"])).has("returns")) {
        let f = y0(e);
        l(f.length === 1 && f[0].type === "bytes", "invalid fallback outputs", "obj.outputs", f.map((c) => c.format("minimal")).join(", "));
      }
      return L0(e), new t12(N, s, o === "payable");
    }
    if (e.type === "receive") return new t12(N, [], true);
    if (e.type === "fallback") {
      let n = [D.from("bytes")], r = e.stateMutability === "payable";
      return new t12(N, n, r);
    }
    l(false, "invalid fallback description", "obj", e);
  }
  static isFragment(e) {
    return e && e[G] === Q1;
  }
};
var k0 = class t13 extends M0 {
  constant;
  outputs;
  stateMutability;
  payable;
  gas;
  constructor(e, n, r, a, s, o) {
    super(e, "function", n, a), Object.defineProperty(this, G, { value: en }), s = Object.freeze(s.slice()), I(this, { constant: r === "view" || r === "pure", gas: o, outputs: s, payable: r === "payable", stateMutability: r });
  }
  get selector() {
    return I0(this.format("sighash")).substring(0, 10);
  }
  format(e) {
    if (e == null && (e = "sighash"), e === "json") return JSON.stringify({ type: "function", name: this.name, constant: this.constant, stateMutability: this.stateMutability !== "nonpayable" ? this.stateMutability : void 0, payable: this.payable, gas: this.gas != null ? this.gas : void 0, inputs: this.inputs.map((r) => JSON.parse(r.format(e))), outputs: this.outputs.map((r) => JSON.parse(r.format(e))) });
    let n = [];
    return e !== "sighash" && n.push("function"), n.push(this.name + fe(e, this.inputs)), e !== "sighash" && (this.stateMutability !== "nonpayable" && n.push(this.stateMutability), this.outputs && this.outputs.length && (n.push("returns"), n.push(fe(e, this.outputs))), this.gas != null && n.push(`@${this.gas.toString()}`)), n.join(" ");
  }
  static getSelector(e, n) {
    return n = (n || []).map((a) => D.from(a)), new t13(N, e, "view", n, [], null).selector;
  }
  static from(e) {
    if (t13.isFragment(e)) return e;
    if (typeof e == "string") try {
      return t13.from(O0(e));
    } catch {
      l(false, "invalid function fragment", "obj", e);
    }
    else if (e instanceof i0) {
      let r = Fe("function", e), a = y0(e), s = cn(e), o = [];
      x0(e, W(["returns"])).has("returns") && (o = y0(e));
      let f = dn(e);
      return L0(e), new t13(N, r, s, a, o, f);
    }
    let n = e.stateMutability;
    return n == null && (n = "payable", typeof e.constant == "boolean" ? (n = "view", e.constant || (n = "payable", typeof e.payable == "boolean" && !e.payable && (n = "nonpayable"))) : typeof e.payable == "boolean" && !e.payable && (n = "nonpayable")), new t13(N, e.name, n, e.inputs ? e.inputs.map(D.from) : [], e.outputs ? e.outputs.map(D.from) : [], e.gas != null ? e.gas : null);
  }
  static isFragment(e) {
    return e && e[G] === en;
  }
};
var J0 = class t14 extends M0 {
  constructor(e, n, r) {
    super(e, "struct", n, r), Object.defineProperty(this, G, { value: tn });
  }
  format() {
    throw new Error("@TODO");
  }
  static from(e) {
    if (typeof e == "string") try {
      return t14.from(O0(e));
    } catch {
      l(false, "invalid struct fragment", "obj", e);
    }
    else if (e instanceof i0) {
      let n = Fe("struct", e), r = y0(e);
      return L0(e), new t14(N, n, r);
    }
    return new t14(N, e.name, e.inputs ? e.inputs.map(D.from) : []);
  }
  static isFragment(e) {
    return e && e[G] === tn;
  }
};
var o0 = /* @__PURE__ */ new Map();
o0.set(0, "GENERIC_PANIC");
o0.set(1, "ASSERT_FALSE");
o0.set(17, "OVERFLOW");
o0.set(18, "DIVIDE_BY_ZERO");
o0.set(33, "ENUM_RANGE_ERROR");
o0.set(34, "BAD_STORAGE_DATA");
o0.set(49, "STACK_UNDERFLOW");
o0.set(50, "ARRAY_RANGE_ERROR");
o0.set(65, "OUT_OF_MEMORY");
o0.set(81, "UNINITIALIZED_FUNCTION_CALL");
var r6 = new RegExp(/^bytes([0-9]*)$/);
var a6 = new RegExp(/^(u?int)([0-9]*)$/);
var bt = null;
var un = 1024;
function s6(t17, e, n, r) {
  let a = "missing revert data", s = null, o = null, f = null;
  if (n) {
    a = "execution reverted";
    let d = M(n);
    if (n = C3(n), d.length === 0) a += " (no data present; likely require(false) occurred", s = "require(false)";
    else if (d.length % 32 !== 4) a += " (could not decode reason; invalid data length)";
    else if (C3(d.slice(0, 4)) === "0x08c379a0") try {
      s = r.decode(["string"], d.slice(4))[0], f = { signature: "Error(string)", name: "Error", args: [s] }, a += `: ${JSON.stringify(s)}`;
    } catch {
      a += " (could not decode reason; invalid string data)";
    }
    else if (C3(d.slice(0, 4)) === "0x4e487b71") try {
      let u = Number(r.decode(["uint256"], d.slice(4))[0]);
      f = { signature: "Panic(uint256)", name: "Panic", args: [u] }, s = `Panic due to ${o0.get(u) || "UNKNOWN"}(${u})`, a += `: ${s}`;
    } catch {
      a += " (could not decode panic code)";
    }
    else a += " (unknown custom error)";
  }
  let c = { to: e.to ? X(e.to) : null, data: e.data || "0x" };
  return e.from && (c.from = X(e.from)), xe(a, "CALL_EXCEPTION", { action: t17, data: n, reason: s, transaction: c, invocation: o, revert: f });
}
var w0 = class t15 {
  #e(e) {
    if (e.isArray()) return new Oe(this.#e(e.arrayChildren), e.arrayLength, e.name);
    if (e.isTuple()) return new F0(e.components.map((r) => this.#e(r)), e.name);
    switch (e.baseType) {
      case "address":
        return new ke(e.name);
      case "bool":
        return new Pe(e.name);
      case "string":
        return new De(e.name);
      case "bytes":
        return new Ne(e.name);
      case "":
        return new _e(e.name);
    }
    let n = e.type.match(a6);
    if (n) {
      let r = parseInt(n[2] || "256");
      return l(r !== 0 && r <= 256 && r % 8 === 0, "invalid " + n[1] + " bit length", "param", e), new Ue(r / 8, n[1] === "int", e.name);
    }
    if (n = e.type.match(r6), n) {
      let r = parseInt(n[1]);
      return l(r !== 0 && r <= 32, "invalid bytes length", "param", e), new Re(r, e.name);
    }
    l(false, "invalid type", "type", e.type);
  }
  getDefaultValue(e) {
    let n = e.map((a) => this.#e(D.from(a)));
    return new F0(n, "_").defaultValue();
  }
  encode(e, n) {
    ee(n.length, e.length, "types/values length mismatch");
    let r = e.map((o) => this.#e(D.from(o))), a = new F0(r, "_"), s = new D0();
    return a.encode(s, n), s.data;
  }
  decode(e, n, r) {
    let a = e.map((o) => this.#e(D.from(o)));
    return new F0(a, "_").decode(new Se(n, r, un));
  }
  static _setDefaultMaxInflation(e) {
    l(typeof e == "number" && Number.isInteger(e), "invalid defaultMaxInflation factor", "value", e), un = e;
  }
  static defaultAbiCoder() {
    return bt == null && (bt = new t15()), bt;
  }
  static getBuiltinCallException(e, n, r) {
    return s6(e, n, r, t15.defaultAbiCoder());
  }
};
var de = class {
  fragment;
  name;
  signature;
  topic;
  args;
  constructor(e, n, r) {
    let a = e.name, s = e.format();
    I(this, { fragment: e, name: a, signature: s, topic: n, args: r });
  }
};
var ue = class {
  fragment;
  name;
  args;
  signature;
  selector;
  value;
  constructor(e, n, r, a) {
    let s = e.name, o = e.format();
    I(this, { fragment: e, name: s, args: r, signature: o, selector: n, value: a });
  }
};
var be = class {
  fragment;
  name;
  args;
  signature;
  selector;
  constructor(e, n, r) {
    let a = e.name, s = e.format();
    I(this, { fragment: e, name: a, args: r, signature: s, selector: n });
  }
};
var X0 = class {
  hash;
  _isIndexed;
  static isIndexed(e) {
    return !!(e && e._isIndexed);
  }
  constructor(e) {
    I(this, { hash: e, _isIndexed: true });
  }
};
var bn = { 0: "generic panic", 1: "assert(false)", 17: "arithmetic overflow", 18: "division or modulo by zero", 33: "enum overflow", 34: "invalid encoded storage byte array accessed", 49: "out-of-bounds array access; popping on an empty array", 50: "out-of-bounds access of an array or bytesN", 65: "out of memory", 81: "uninitialized function" };
var ln = { "0x08c379a0": { signature: "Error(string)", name: "Error", inputs: ["string"], reason: (t17) => `reverted with reason string ${JSON.stringify(t17)}` }, "0x4e487b71": { signature: "Panic(uint256)", name: "Panic", inputs: ["uint256"], reason: (t17) => {
  let e = "unknown panic code";
  return t17 >= 0 && t17 <= 255 && bn[t17.toString()] && (e = bn[t17.toString()]), `reverted with panic code 0x${t17.toString(16)} (${e})`;
} } };
var F = class t16 {
  fragments;
  deploy;
  fallback;
  receive;
  #e;
  #t;
  #n;
  #r;
  constructor(e) {
    let n = [];
    typeof e == "string" ? n = JSON.parse(e) : n = e, this.#n = /* @__PURE__ */ new Map(), this.#e = /* @__PURE__ */ new Map(), this.#t = /* @__PURE__ */ new Map();
    let r = [];
    for (let o of n) try {
      r.push(C0.from(o));
    } catch (f) {
      console.log(`[Warning] Invalid Fragment ${JSON.stringify(o)}:`, f.message);
    }
    I(this, { fragments: Object.freeze(r) });
    let a = null, s = false;
    this.#r = this.getAbiCoder(), this.fragments.forEach((o, f) => {
      let c;
      switch (o.type) {
        case "constructor":
          if (this.deploy) {
            console.log("duplicate definition - constructor");
            return;
          }
          I(this, { deploy: o });
          return;
        case "fallback":
          o.inputs.length === 0 ? s = true : (l(!a || o.payable !== a.payable, "conflicting fallback fragments", `fragments[${f}]`, o), a = o, s = a.payable);
          return;
        case "function":
          c = this.#n;
          break;
        case "event":
          c = this.#t;
          break;
        case "error":
          c = this.#e;
          break;
        default:
          return;
      }
      let d = o.format();
      c.has(d) || c.set(d, o);
    }), this.deploy || I(this, { deploy: A0.from("constructor()") }), I(this, { fallback: a, receive: s });
  }
  format(e) {
    let n = e ? "minimal" : "full";
    return this.fragments.map((a) => a.format(n));
  }
  formatJson() {
    let e = this.fragments.map((n) => n.format("json"));
    return JSON.stringify(e.map((n) => JSON.parse(n)));
  }
  getAbiCoder() {
    return w0.defaultAbiCoder();
  }
  #a(e, n, r) {
    if (G0(e)) {
      let s = e.toLowerCase();
      for (let o of this.#n.values()) if (s === o.selector) return o;
      return null;
    }
    if (e.indexOf("(") === -1) {
      let s = [];
      for (let [o, f] of this.#n) o.split("(")[0] === e && s.push(f);
      if (n) {
        let o = n.length > 0 ? n[n.length - 1] : null, f = n.length, c = true;
        P.isTyped(o) && o.type === "overrides" && (c = false, f--);
        for (let d = s.length - 1; d >= 0; d--) {
          let u = s[d].inputs.length;
          u !== f && (!c || u !== f - 1) && s.splice(d, 1);
        }
        for (let d = s.length - 1; d >= 0; d--) {
          let u = s[d].inputs;
          for (let g = 0; g < n.length; g++) if (P.isTyped(n[g])) {
            if (g >= u.length) {
              if (n[g].type === "overrides") continue;
              s.splice(d, 1);
              break;
            }
            if (n[g].type !== u[g].baseType) {
              s.splice(d, 1);
              break;
            }
          }
        }
      }
      if (s.length === 1 && n && n.length !== s[0].inputs.length) {
        let o = n[n.length - 1];
        (o == null || Array.isArray(o) || typeof o != "object") && s.splice(0, 1);
      }
      if (s.length === 0) return null;
      if (s.length > 1 && r) {
        let o = s.map((f) => JSON.stringify(f.format())).join(", ");
        l(false, `ambiguous function description (i.e. matches ${o})`, "key", e);
      }
      return s[0];
    }
    let a = this.#n.get(k0.from(e).format());
    return a || null;
  }
  getFunctionName(e) {
    let n = this.#a(e, null, false);
    return l(n, "no matching function", "key", e), n.name;
  }
  hasFunction(e) {
    return !!this.#a(e, null, false);
  }
  getFunction(e, n) {
    return this.#a(e, n || null, true);
  }
  forEachFunction(e) {
    let n = Array.from(this.#n.keys());
    n.sort((r, a) => r.localeCompare(a));
    for (let r = 0; r < n.length; r++) {
      let a = n[r];
      e(this.#n.get(a), r);
    }
  }
  #s(e, n, r) {
    if (G0(e)) {
      let s = e.toLowerCase();
      for (let o of this.#t.values()) if (s === o.topicHash) return o;
      return null;
    }
    if (e.indexOf("(") === -1) {
      let s = [];
      for (let [o, f] of this.#t) o.split("(")[0] === e && s.push(f);
      if (n) {
        for (let o = s.length - 1; o >= 0; o--) s[o].inputs.length < n.length && s.splice(o, 1);
        for (let o = s.length - 1; o >= 0; o--) {
          let f = s[o].inputs;
          for (let c = 0; c < n.length; c++) if (P.isTyped(n[c]) && n[c].type !== f[c].baseType) {
            s.splice(o, 1);
            break;
          }
        }
      }
      if (s.length === 0) return null;
      if (s.length > 1 && r) {
        let o = s.map((f) => JSON.stringify(f.format())).join(", ");
        l(false, `ambiguous event description (i.e. matches ${o})`, "key", e);
      }
      return s[0];
    }
    let a = this.#t.get(T0.from(e).format());
    return a || null;
  }
  getEventName(e) {
    let n = this.#s(e, null, false);
    return l(n, "no matching event", "key", e), n.name;
  }
  hasEvent(e) {
    return !!this.#s(e, null, false);
  }
  getEvent(e, n) {
    return this.#s(e, n || null, true);
  }
  forEachEvent(e) {
    let n = Array.from(this.#t.keys());
    n.sort((r, a) => r.localeCompare(a));
    for (let r = 0; r < n.length; r++) {
      let a = n[r];
      e(this.#t.get(a), r);
    }
  }
  getError(e, n) {
    if (G0(e)) {
      let a = e.toLowerCase();
      if (ln[a]) return Z.from(ln[a].signature);
      for (let s of this.#e.values()) if (a === s.selector) return s;
      return null;
    }
    if (e.indexOf("(") === -1) {
      let a = [];
      for (let [s, o] of this.#e) s.split("(")[0] === e && a.push(o);
      if (a.length === 0) return e === "Error" ? Z.from("error Error(string)") : e === "Panic" ? Z.from("error Panic(uint256)") : null;
      if (a.length > 1) {
        let s = a.map((o) => JSON.stringify(o.format())).join(", ");
        l(false, `ambiguous error description (i.e. ${s})`, "name", e);
      }
      return a[0];
    }
    if (e = Z.from(e).format(), e === "Error(string)") return Z.from("error Error(string)");
    if (e === "Panic(uint256)") return Z.from("error Panic(uint256)");
    let r = this.#e.get(e);
    return r || null;
  }
  forEachError(e) {
    let n = Array.from(this.#e.keys());
    n.sort((r, a) => r.localeCompare(a));
    for (let r = 0; r < n.length; r++) {
      let a = n[r];
      e(this.#e.get(a), r);
    }
  }
  _decodeParams(e, n) {
    return this.#r.decode(e, n);
  }
  _encodeParams(e, n) {
    return this.#r.encode(e, n);
  }
  encodeDeploy(e) {
    return this._encodeParams(this.deploy.inputs, e || []);
  }
  decodeErrorResult(e, n) {
    if (typeof e == "string") {
      let r = this.getError(e);
      l(r, "unknown error", "fragment", e), e = r;
    }
    return l(b0(n, 0, 4) === e.selector, `data signature does not match error ${e.name}.`, "data", n), this._decodeParams(e.inputs, b0(n, 4));
  }
  encodeErrorResult(e, n) {
    if (typeof e == "string") {
      let r = this.getError(e);
      l(r, "unknown error", "fragment", e), e = r;
    }
    return u0([e.selector, this._encodeParams(e.inputs, n || [])]);
  }
  decodeFunctionData(e, n) {
    if (typeof e == "string") {
      let r = this.getFunction(e);
      l(r, "unknown function", "fragment", e), e = r;
    }
    return l(b0(n, 0, 4) === e.selector, `data signature does not match function ${e.name}.`, "data", n), this._decodeParams(e.inputs, b0(n, 4));
  }
  encodeFunctionData(e, n) {
    if (typeof e == "string") {
      let r = this.getFunction(e);
      l(r, "unknown function", "fragment", e), e = r;
    }
    return u0([e.selector, this._encodeParams(e.inputs, n || [])]);
  }
  decodeFunctionResult(e, n) {
    if (typeof e == "string") {
      let s = this.getFunction(e);
      l(s, "unknown function", "fragment", e), e = s;
    }
    let r = "invalid length for result data", a = H(n);
    if (a.length % 32 === 0) try {
      return this.#r.decode(e.outputs, a);
    } catch {
      r = "could not decode result data";
    }
    A(false, r, "BAD_DATA", { value: C3(a), info: { method: e.name, signature: e.format() } });
  }
  makeError(e, n) {
    let r = M(e, "data"), a = w0.getBuiltinCallException("call", n, r);
    if (a.message.startsWith("execution reverted (unknown custom error)")) {
      let f = C3(r.slice(0, 4)), c = this.getError(f);
      if (c) try {
        let d = this.#r.decode(c.inputs, r.slice(4));
        a.revert = { name: c.name, signature: c.format(), args: d }, a.reason = a.revert.signature, a.message = `execution reverted: ${a.reason}`;
      } catch {
        a.message = "execution reverted (coult not decode custom error)";
      }
    }
    let o = this.parseTransaction(n);
    return o && (a.invocation = { method: o.name, signature: o.signature, args: o.args }), a;
  }
  encodeFunctionResult(e, n) {
    if (typeof e == "string") {
      let r = this.getFunction(e);
      l(r, "unknown function", "fragment", e), e = r;
    }
    return C3(this.#r.encode(e.outputs, n || []));
  }
  encodeFilterTopics(e, n) {
    if (typeof e == "string") {
      let s = this.getEvent(e);
      l(s, "unknown event", "eventFragment", e), e = s;
    }
    A(n.length <= e.inputs.length, `too many arguments for ${e.format()}`, "UNEXPECTED_ARGUMENT", { count: n.length, expectedCount: e.inputs.length });
    let r = [];
    e.anonymous || r.push(e.topicHash);
    let a = (s, o) => s.type === "string" ? I0(o) : s.type === "bytes" ? U(C3(o)) : (s.type === "bool" && typeof o == "boolean" ? o = o ? "0x01" : "0x00" : s.type.match(/^u?int/) ? o = ne(o) : s.type.match(/^bytes/) ? o = Ze(o, 32) : s.type === "address" && this.#r.encode(["address"], [o]), Xe(C3(o), 32));
    for (n.forEach((s, o) => {
      let f = e.inputs[o];
      if (!f.indexed) {
        l(s == null, "cannot filter non-indexed parameters; must be null", "contract." + f.name, s);
        return;
      }
      s == null ? r.push(null) : f.baseType === "array" || f.baseType === "tuple" ? l(false, "filtering with tuples or arrays not supported", "contract." + f.name, s) : Array.isArray(s) ? r.push(s.map((c) => a(f, c))) : r.push(a(f, s));
    }); r.length && r[r.length - 1] === null; ) r.pop();
    return r;
  }
  encodeEventLog(e, n) {
    if (typeof e == "string") {
      let o = this.getEvent(e);
      l(o, "unknown event", "eventFragment", e), e = o;
    }
    let r = [], a = [], s = [];
    return e.anonymous || r.push(e.topicHash), l(n.length === e.inputs.length, "event arguments/values mismatch", "values", n), e.inputs.forEach((o, f) => {
      let c = n[f];
      if (o.indexed) if (o.type === "string") r.push(I0(c));
      else if (o.type === "bytes") r.push(U(c));
      else {
        if (o.baseType === "tuple" || o.baseType === "array") throw new Error("not implemented");
        r.push(this.#r.encode([o.type], [c]));
      }
      else a.push(o), s.push(c);
    }), { data: this.#r.encode(a, s), topics: r };
  }
  decodeEventLog(e, n, r) {
    if (typeof e == "string") {
      let m = this.getEvent(e);
      l(m, "unknown event", "eventFragment", e), e = m;
    }
    if (r != null && !e.anonymous) {
      let m = e.topicHash;
      l(G0(r[0], 32) && r[0].toLowerCase() === m, "fragment/topic mismatch", "topics[0]", r[0]), r = r.slice(1);
    }
    let a = [], s = [], o = [];
    e.inputs.forEach((m, E) => {
      m.indexed ? m.type === "string" || m.type === "bytes" || m.baseType === "tuple" || m.baseType === "array" ? (a.push(D.from({ type: "bytes32", name: m.name })), o.push(true)) : (a.push(m), o.push(false)) : (s.push(m), o.push(false));
    });
    let f = r != null ? this.#r.decode(a, u0(r)) : null, c = this.#r.decode(s, n, true), d = [], u = [], g = 0, p = 0;
    return e.inputs.forEach((m, E) => {
      let S = null;
      if (m.indexed) if (f == null) S = new X0(null);
      else if (o[E]) S = new X0(f[p++]);
      else try {
        S = f[p++];
      } catch (j) {
        S = j;
      }
      else try {
        S = c[g++];
      } catch (j) {
        S = j;
      }
      d.push(S), u.push(m.name || null);
    }), l0.fromItems(d, u);
  }
  parseTransaction(e) {
    let n = M(e.data, "tx.data"), r = e0(e.value != null ? e.value : 0, "tx.value"), a = this.getFunction(C3(n.slice(0, 4)));
    if (!a) return null;
    let s = this.#r.decode(a.inputs, n.slice(4));
    return new ue(a, a.selector, s, r);
  }
  parseCallResult(e) {
    throw new Error("@TODO");
  }
  parseLog(e) {
    let n = this.getEvent(e.topics[0]);
    return !n || n.anonymous ? null : new de(n, n.topicHash, this.decodeEventLog(n, e.data, e.topics));
  }
  parseError(e) {
    let n = C3(e), r = this.getError(b0(n, 0, 4));
    if (!r) return null;
    let a = this.#r.decode(r.inputs, b0(n, 4));
    return new be(r, r.selector, a);
  }
  static from(e) {
    return e instanceof t16 ? e : typeof e == "string" ? new t16(JSON.parse(e)) : typeof e.formatJson == "function" ? new t16(e.formatJson()) : typeof e.format == "function" ? new t16(e.format("json")) : new t16(e);
  }
};
var x = { schema: 1, chainId: 56, admin: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", treasury: "0xC440F06BBC7e58b0d055815f915447e4ae0E3720", peer: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92", route: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb", baseNonce: 4739, addresses: { adapter: "0x74c20dEB476Dca58459956b1AcD65771197900C9", pass: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5" }, gasLimits: ["1987828", "2298085", "65443"], maxTotalFeeWei: "1000000000000000", remoteCodeHashes: { endpoint: "0x5ed1f4ec5f4d6bd5eac1fa92e0fb7474be2607dfc5f3eb82ced1c183b64fbeb9", usdt: "0x97a48aa4c129657440dafdacd4c836389734d28cc4a0ca7403e68da660a74a59" }, slotDigest: "GNDWXqgPJnZyeQaVFqnZ1HuXSnSiHUAKV1vL4Ke49yMX", registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210", adapter: { abi: [{ inputs: [{ internalType: "bytes32", name: "peer", type: "bytes32" }, { internalType: "bytes32", name: "routeId", type: "bytes32" }], stateMutability: "nonpayable", type: "constructor" }, { inputs: [], name: "Invalid", type: "error" }, { inputs: [], name: "ReentrancyGuardReentrantCall", type: "error" }, { anonymous: false, inputs: [{ indexed: true, internalType: "bytes32", name: "guid", type: "bytes32" }, { indexed: false, internalType: "uint8", name: "kind", type: "uint8" }, { indexed: false, internalType: "uint64", name: "generation", type: "uint64" }], name: "MessageApplied", type: "event" }, { anonymous: false, inputs: [{ indexed: true, internalType: "bytes32", name: "guid", type: "bytes32" }, { indexed: false, internalType: "uint8", name: "kind", type: "uint8" }, { indexed: false, internalType: "uint64", name: "generation", type: "uint64" }], name: "MessageSent", type: "event" }, { anonymous: false, inputs: [{ indexed: true, internalType: "address", name: "pass", type: "address" }], name: "PassBound", type: "event" }, { anonymous: false, inputs: [{ indexed: false, internalType: "uint128", name: "gas", type: "uint128" }], name: "ReceiveGasRaised", type: "event" }, { inputs: [], name: "SUI_EID", outputs: [{ internalType: "uint32", name: "", type: "uint32" }], stateMutability: "view", type: "function" }, { inputs: [{ components: [{ internalType: "uint32", name: "srcEid", type: "uint32" }, { internalType: "bytes32", name: "sender", type: "bytes32" }, { internalType: "uint64", name: "nonce", type: "uint64" }], internalType: "struct Origin", name: "origin", type: "tuple" }], name: "allowInitializePath", outputs: [{ internalType: "bool", name: "", type: "bool" }], stateMutability: "view", type: "function" }, { inputs: [], name: "backingNFT", outputs: [{ internalType: "bytes32", name: "", type: "bytes32" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "contract TreeSuitePass", name: "p", type: "address" }], name: "bindPass", outputs: [], stateMutability: "nonpayable", type: "function" }, { inputs: [], name: "binder", outputs: [{ internalType: "address", name: "", type: "address" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "bytes32", name: "", type: "bytes32" }], name: "delivered", outputs: [{ internalType: "bytes32", name: "", type: "bytes32" }], stateMutability: "view", type: "function" }, { inputs: [], name: "endpoint", outputs: [{ internalType: "contract ILayerZeroEndpointV2", name: "", type: "address" }], stateMutability: "view", type: "function" }, { inputs: [{ components: [{ internalType: "uint32", name: "srcEid", type: "uint32" }, { internalType: "bytes32", name: "sender", type: "bytes32" }, { internalType: "uint64", name: "nonce", type: "uint64" }], internalType: "struct Origin", name: "origin", type: "tuple" }, { internalType: "bytes32", name: "guid", type: "bytes32" }, { internalType: "bytes", name: "message", type: "bytes" }, { internalType: "address", name: "", type: "address" }, { internalType: "bytes", name: "", type: "bytes" }], name: "lzReceive", outputs: [], stateMutability: "payable", type: "function" }, { inputs: [{ internalType: "uint32", name: "", type: "uint32" }, { internalType: "bytes32", name: "", type: "bytes32" }], name: "nextNonce", outputs: [{ internalType: "uint64", name: "", type: "uint64" }], stateMutability: "pure", type: "function" }, { inputs: [{ internalType: "uint8", name: "kind", type: "uint8" }], name: "outboundPayload", outputs: [{ internalType: "bytes", name: "", type: "bytes" }], stateMutability: "view", type: "function" }, { inputs: [], name: "pass", outputs: [{ internalType: "contract TreeSuitePass", name: "", type: "address" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "uint8", name: "kind", type: "uint8" }], name: "quote", outputs: [{ components: [{ internalType: "uint256", name: "nativeFee", type: "uint256" }, { internalType: "uint256", name: "lzTokenFee", type: "uint256" }], internalType: "struct MessagingFee", name: "", type: "tuple" }], stateMutability: "view", type: "function" }, { inputs: [], name: "receiveGas", outputs: [{ internalType: "uint128", name: "", type: "uint128" }], stateMutability: "view", type: "function" }, { inputs: [], name: "receiveOptions", outputs: [{ internalType: "bytes", name: "", type: "bytes" }], stateMutability: "view", type: "function" }, { inputs: [], name: "route", outputs: [{ internalType: "bytes32", name: "", type: "bytes32" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "uint8", name: "kind", type: "uint8" }], name: "send", outputs: [{ components: [{ internalType: "bytes32", name: "guid", type: "bytes32" }, { internalType: "uint64", name: "nonce", type: "uint64" }, { components: [{ internalType: "uint256", name: "nativeFee", type: "uint256" }, { internalType: "uint256", name: "lzTokenFee", type: "uint256" }], internalType: "struct MessagingFee", name: "fee", type: "tuple" }], internalType: "struct MessagingReceipt", name: "receipt", type: "tuple" }], stateMutability: "payable", type: "function" }, { inputs: [{ internalType: "uint128", name: "gas", type: "uint128" }], name: "setReceiveGas", outputs: [], stateMutability: "nonpayable", type: "function" }, { inputs: [], name: "suiPeer", outputs: [{ internalType: "bytes32", name: "", type: "bytes32" }], stateMutability: "view", type: "function" }], evm: { bytecode: { object: "60e0604052600280546001600160801b0319166301c9c380179055348015610025575f5ffd5b50604051611cb7380380611cb78339810160408190526100449161019f565b60015f5546603814158061006b5750731a44076050125825900e736c501f859c50fe728c3b155b80610074575081155b8061007d575080155b80610109575061759663ffffffff16731a44076050125825900e736c501f859c50fe728c6001600160a01b031663416ecebf6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156100dc573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061010091906101c1565b63ffffffff1614155b1561012757604051636dac6a0960e01b815260040160405180910390fd5b608082905260a08190523360c081905260405163ca5eb5e160e01b81526004810191909152731a44076050125825900e736c501f859c50fe728c9063ca5eb5e1906024015f604051808303815f87803b158015610182575f5ffd5b505af1158015610194573d5f5f3e3d5ffd5b5050505050506101eb565b5f5f604083850312156101b0575f5ffd5b505080516020909101519092909150565b5f602082840312156101d1575f5ffd5b815163ffffffff811681146101e4575f5ffd5b9392505050565b60805160a05160c051611a5c61025b5f395f818161031901528181610413015281816107930152610a8401525f818161038c0152818161086101528181610d43015261109c01525f8181610196015281816104e101528181610bc6015281816112f901526114100152611a5c5ff3fe608060405260043610610105575f3560e01c80637d25a05e11610092578063b1f8671711610062578063b1f867171461033b578063c13bd9361461034f578063d96661ef1461037b578063e495f1d4146103ae578063ff7bd03d146103d9575f5ffd5b80637d25a05e1461028857806383d5f21d146102bf578063a7a1ed72146102e9578063acba7b4214610308575f5ffd5b806315aff54e116100d857806315aff54e146101855780634922eec1146101c65780634cedb60f146101f25780635e280f111461022957806378360c8814610268575f5ffd5b80630200e86b1461010957806307f53ee71461012a57806310265fa51461015357806313137d6514610172575b5f5ffd5b348015610114575f5ffd5b506101286101233660046114b9565b610408565b005b61013d6101383660046114e6565b6104c0565b60405161014a9190611506565b60405180910390f35b34801561015e575f5ffd5b5061012861016d36600461155e565b610788565b6101286101803660046115d3565b610b7f565b348015610190575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b60405190815260200161014a565b3480156101d1575f5ffd5b506101e56101e03660046114e6565b610f8e565b60405161014a91906116b0565b3480156101fd575f5ffd5b50600254610211906001600160801b031681565b6040516001600160801b03909116815260200161014a565b348015610234575f5ffd5b50610250731a44076050125825900e736c501f859c50fe728c81565b6040516001600160a01b03909116815260200161014a565b348015610273575f5ffd5b506101b85f516020611a075f395f51905f5281565b348015610293575f5ffd5b506102a76102a23660046116d5565b611273565b6040516001600160401b03909116815260200161014a565b3480156102ca575f5ffd5b506102d46176aa81565b60405163ffffffff909116815260200161014a565b3480156102f4575f5ffd5b50600154610250906001600160a01b031681565b348015610313575f5ffd5b506102507f000000000000000000000000000000000000000000000000000000000000000081565b348015610346575f5ffd5b506101e561127b565b34801561035a575f5ffd5b5061036e6103693660046114e6565b6112d5565b60405161014a91906116fd565b348015610386575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b3480156103b9575f5ffd5b506101b86103c8366004611714565b60036020525f908152604090205481565b3480156103e4575f5ffd5b506103f86103f336600461172b565b6113ef565b604051901515815260200161014a565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614158061044e57506002546001600160801b03908116908216105b1561046c57604051636dac6a0960e01b815260040160405180910390fd5b600280546001600160801b0319166001600160801b0383169081179091556040519081527f4bbad5fe035af81686d3e8380dfd61d879211cbe2c4e6e05f86ad07cdec099b09060200160405180910390a150565b6104c8611479565b6104d0611451565b6040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91810161051285610f8e565b815260200161051f61127b565b81525f6020909101819052604051631bb8518b60e31b815291925090731a44076050125825900e736c501f859c50fe728c9063ddc28c58906105679085903090600401611745565b6040805180830381865afa158015610581573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906105a59190611815565b805190915015806105b95750602081015115155b806105c5575080513414155b156105e357604051636dac6a0960e01b815260040160405180910390fd5b6040516302637a4560e41b8152731a44076050125825900e736c501f859c50fe728c90632637a45090349061061e9086903390600401611745565b60806040518083038185885af115801561063a573d5f5f3e3d5ffd5b50505050506040513d601f19601f8201168201806040525081019061065f9190611843565b8051909350158061067b575060208301516001600160401b0316155b8061068d575060408301516020015115155b8061069c575060408301515134105b156106ba57604051636dac6a0960e01b815260040160405180910390fd5b825f01517f6d23cdaef17712141c7441cf202389c6ddc063fb5c14788d5c4479b62096d13f8560015f9054906101000a90046001600160a01b03166001600160a01b031663172195226040518163ffffffff1660e01b8152600401602060405180830381865afa158015610730573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061075491906118b6565b6040805160ff90931683526001600160401b0390911660208301520160405180910390a2505061078360015f55565b919050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161415806107ca57506001546001600160a01b031615155b806107dd57506001600160a01b0381163b155b806108595750306001600160a01b0316816001600160a01b03166303eadcfc6040518163ffffffff1660e01b8152600401602060405180830381865afa158015610829573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061084d91906118d1565b6001600160a01b031614155b806108e357507f0000000000000000000000000000000000000000000000000000000000000000816001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156108bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906108e091906118ec565b14155b8061095c57505f516020611a075f395f51905f525f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa158015610935573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061095991906118ec565b14155b806109ec57507355d398326f99059ff775485246999027b31979556001600160a01b0316816001600160a01b031663e5a6b10f6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156109bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906109e091906118d1565b6001600160a01b031614155b80610a7c575073c440f06bbc7e58b0d055815f915447e4ae0e37206001600160a01b0316816001600160a01b03166361d027b36040518163ffffffff1660e01b8152600401602060405180830381865afa158015610a4c573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610a7091906118d1565b6001600160a01b031614155b80610b1857507f00000000000000000000000000000000000000000000000000000000000000006001600160a01b0316816001600160a01b031663f77c47916040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ae8573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610b0c91906118d1565b6001600160a01b031614155b15610b3657604051636dac6a0960e01b815260040160405180910390fd5b600180546001600160a01b0319166001600160a01b0383169081179091556040517f3916d079df018feca66a550908f671cff67410227b4a8c24f13531847e12b9c8905f90a250565b610b87611451565b33731a44076050125825900e736c501f859c50fe728c141580610bbe57506176aa610bb56020890189611903565b63ffffffff1614155b80610bed57507f0000000000000000000000000000000000000000000000000000000000000000876020013514155b80610c0157506001546001600160a01b0316155b80610c0a575085155b80610c2b5750610c20606088016040890161191c565b6001600160401b0316155b80610c3557503415155b15610c5357604051636dac6a0960e01b815260040160405180910390fd5b608a84141580610c7e575084845f818110610c7057610c70611937565b9091013560f81c6003141590505b15610c9c57604051636dac6a0960e01b815260040160405180910390fd5b5f85856001818110610cb057610cb0611937565b919091013560f81c91505f9050610ccb60226002888a61194b565b610cd491611972565b90505f610ce560426022898b61194b565b610cee91611972565b90505f610cff604a60428a8c61194b565b610d089161198f565b60c01c90505f610d1c606a604a8b8d61194b565b610d2591611972565b90505f610d36608a606a8c8e61194b565b610d3f91611972565b90507f000000000000000000000000000000000000000000000000000000000000000085141580610d7d57505f516020611a075f395f51905f528414155b80610d8f57506001600160401b038316155b15610dad57604051636dac6a0960e01b815260040160405180910390fd5b5f8b8b604051610dbe9291906119c5565b60408051918290039091205f8f81526003602052919091205490915015801590610df557505f8d8152600360205260409020548114155b15610e1357604051636dac6a0960e01b815260040160405180910390fd5b8660ff16600103610eb05782151580610e2b57508115155b15610e4957604051636dac6a0960e01b815260040160405180910390fd5b60015460405163579c848360e11b81526001600160401b03861660048201526001600160a01b039091169063af390906906024015b5f604051808303815f87803b158015610e95575f5ffd5b505af1158015610ea7573d5f5f3e3d5ffd5b50505050610f1b565b8660ff16600303610f025760015460405163367938c560e21b81526001600160401b038616600482015260248101859052604481018490526001600160a01b039091169063d9e4e31490606401610e7e565b604051636dac6a0960e01b815260040160405180910390fd5b5f8d815260036020908152604091829020839055815160ff8a1681526001600160401b038716918101919091528e917f37949e68c9d0a4e5f5474ddb8654f999a5dc4b58a8aa1aef313516586e9b320a910160405180910390a250505050505050610f8560015f55565b50505050505050565b6001546060906001600160a01b0316610fba57604051636dac6a0960e01b815260040160405180910390fd5b8160ff166002036110705760035b60015f9054906101000a90046001600160a01b03166001600160a01b031663c19d93fb6040518163ffffffff1660e01b8152600401602060405180830381865afa158015611018573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061103c91906119e8565b600481111561104d5761104d6119d4565b1461106b57604051636dac6a0960e01b815260040160405180910390fd5b611082565b8160ff16600403610f02576004610fc8565b60015460408051630b90ca9160e11b8152905160039285927f0000000000000000000000000000000000000000000000000000000000000000925f516020611a075f395f51905f52926001600160a01b03169163172195229160048083019260209291908290030181865afa1580156110fd573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061112191906118b6565b60015f9054906101000a90046001600160a01b03166001600160a01b0316635467e0a76040518163ffffffff1660e01b8152600401602060405180830381865afa158015611171573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061119591906118ec565b60015f9054906101000a90046001600160a01b03166001600160a01b03166366d003ac6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156111e5573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061120991906118ec565b60405160f897881b6001600160f81b031990811660208301529690971b90951660218701526022860193909352604285019190915260c01b6001600160c01b0319166062840152606a830152608a82015260aa016040516020818303038152906040529050919050565b5f5b92915050565b600254604051600360f01b6020820152600160f81b60228201819052601160f01b6023830152602582015260809190911b6001600160801b0319166026820152606090603601604051602081830303815290604052905090565b604080518082019091525f80825260208201526040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91731a44076050125825900e736c501f859c50fe728c9163ddc28c5891810161134687610f8e565b815260200161135361127b565b81525f6020909101526040516001600160e01b031960e084901b16815261137f91903090600401611745565b6040805180830381865afa158015611399573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906113bd9190611815565b805190915015806113d15750602081015115155b1561127557604051636dac6a0960e01b815260040160405180910390fd5b5f6176aa6114006020840184611903565b63ffffffff1614801561143657507f00000000000000000000000000000000000000000000000000000000000000008260200135145b801561127557506001546001600160a01b0316151592915050565b60025f540361147357604051633ee5aeb560e01b815260040160405180910390fd5b60025f55565b60405180606001604052805f81526020015f6001600160401b031681526020016114b460405180604001604052805f81526020015f81525090565b905290565b5f602082840312156114c9575f5ffd5b81356001600160801b03811681146114df575f5ffd5b9392505050565b5f602082840312156114f6575f5ffd5b813560ff811681146114df575f5ffd5b5f608082019050825182526001600160401b0360208401511660208301526040830151611540604084018280518252602090810151910152565b5092915050565b6001600160a01b038116811461155b575f5ffd5b50565b5f6020828403121561156e575f5ffd5b81356114df81611547565b5f60608284031215611589575f5ffd5b50919050565b5f5f83601f84011261159f575f5ffd5b5081356001600160401b038111156115b5575f5ffd5b6020830191508360208285010111156115cc575f5ffd5b9250929050565b5f5f5f5f5f5f5f60e0888a0312156115e9575f5ffd5b6115f38989611579565b96506060880135955060808801356001600160401b03811115611614575f5ffd5b6116208a828b0161158f565b90965094505060a088013561163481611547565b925060c08801356001600160401b0381111561164e575f5ffd5b61165a8a828b0161158f565b989b979a50959850939692959293505050565b5f81518084525f5b8181101561169157602081850181015186830182015201611675565b505f602082860101526020601f19601f83011685010191505092915050565b602081525f6114df602083018461166d565b803563ffffffff81168114610783575f5ffd5b5f5f604083850312156116e6575f5ffd5b6116ef836116c2565b946020939093013593505050565b815181526020808301519082015260408101611275565b5f60208284031215611724575f5ffd5b5035919050565b5f6060828403121561173b575f5ffd5b6114df8383611579565b6040815263ffffffff8351166040820152602083015160608201525f604084015160a0608084015261177a60e084018261166d565b90506060850151603f198483030160a0850152611797828261166d565b60809690960151151560c08501525050506001600160a01b039190911660209091015290565b5f604082840312156117cd575f5ffd5b604080519081016001600160401b03811182821017156117fb57634e487b7160e01b5f52604160045260245ffd5b604052825181526020928301519281019290925250919050565b5f60408284031215611825575f5ffd5b6114df83836117bd565b6001600160401b038116811461155b575f5ffd5b5f6080828403128015611854575f5ffd5b50604051606081016001600160401b038111828210171561188357634e487b7160e01b5f52604160045260245ffd5b6040528251815260208301516118988161182f565b60208201526118aa84604085016117bd565b60408201529392505050565b5f602082840312156118c6575f5ffd5b81516114df8161182f565b5f602082840312156118e1575f5ffd5b81516114df81611547565b5f602082840312156118fc575f5ffd5b5051919050565b5f60208284031215611913575f5ffd5b6114df826116c2565b5f6020828403121561192c575f5ffd5b81356114df8161182f565b634e487b7160e01b5f52603260045260245ffd5b5f5f85851115611959575f5ffd5b83861115611965575f5ffd5b5050820193919092039150565b80356020831015611275575f19602084900360031b1b1692915050565b80356001600160c01b03198116906008841015611540576001600160c01b031960089490940360031b84901b1690921692915050565b818382375f9101908152919050565b634e487b7160e01b5f52602160045260245ffd5b5f602082840312156119f8575f5ffd5b8151600581106114df575f5ffdfe046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6baa2646970667358221220d5e0a008fcf934cc781ad8e21c7865f692e69e850ec3b05743fb3e9c2c69c09a64736f6c634300081e0033" }, deployedBytecode: { immutableReferences: { "61": [{ length: 32, start: 406 }, { length: 32, start: 1249 }, { length: 32, start: 3014 }, { length: 32, start: 4857 }, { length: 32, start: 5136 }], "63": [{ length: 32, start: 908 }, { length: 32, start: 2145 }, { length: 32, start: 3395 }, { length: 32, start: 4252 }], "65": [{ length: 32, start: 793 }, { length: 32, start: 1043 }, { length: 32, start: 1939 }, { length: 32, start: 2692 }] }, object: "608060405260043610610105575f3560e01c80637d25a05e11610092578063b1f8671711610062578063b1f867171461033b578063c13bd9361461034f578063d96661ef1461037b578063e495f1d4146103ae578063ff7bd03d146103d9575f5ffd5b80637d25a05e1461028857806383d5f21d146102bf578063a7a1ed72146102e9578063acba7b4214610308575f5ffd5b806315aff54e116100d857806315aff54e146101855780634922eec1146101c65780634cedb60f146101f25780635e280f111461022957806378360c8814610268575f5ffd5b80630200e86b1461010957806307f53ee71461012a57806310265fa51461015357806313137d6514610172575b5f5ffd5b348015610114575f5ffd5b506101286101233660046114b9565b610408565b005b61013d6101383660046114e6565b6104c0565b60405161014a9190611506565b60405180910390f35b34801561015e575f5ffd5b5061012861016d36600461155e565b610788565b6101286101803660046115d3565b610b7f565b348015610190575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b60405190815260200161014a565b3480156101d1575f5ffd5b506101e56101e03660046114e6565b610f8e565b60405161014a91906116b0565b3480156101fd575f5ffd5b50600254610211906001600160801b031681565b6040516001600160801b03909116815260200161014a565b348015610234575f5ffd5b50610250731a44076050125825900e736c501f859c50fe728c81565b6040516001600160a01b03909116815260200161014a565b348015610273575f5ffd5b506101b85f516020611a075f395f51905f5281565b348015610293575f5ffd5b506102a76102a23660046116d5565b611273565b6040516001600160401b03909116815260200161014a565b3480156102ca575f5ffd5b506102d46176aa81565b60405163ffffffff909116815260200161014a565b3480156102f4575f5ffd5b50600154610250906001600160a01b031681565b348015610313575f5ffd5b506102507f000000000000000000000000000000000000000000000000000000000000000081565b348015610346575f5ffd5b506101e561127b565b34801561035a575f5ffd5b5061036e6103693660046114e6565b6112d5565b60405161014a91906116fd565b348015610386575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b3480156103b9575f5ffd5b506101b86103c8366004611714565b60036020525f908152604090205481565b3480156103e4575f5ffd5b506103f86103f336600461172b565b6113ef565b604051901515815260200161014a565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614158061044e57506002546001600160801b03908116908216105b1561046c57604051636dac6a0960e01b815260040160405180910390fd5b600280546001600160801b0319166001600160801b0383169081179091556040519081527f4bbad5fe035af81686d3e8380dfd61d879211cbe2c4e6e05f86ad07cdec099b09060200160405180910390a150565b6104c8611479565b6104d0611451565b6040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91810161051285610f8e565b815260200161051f61127b565b81525f6020909101819052604051631bb8518b60e31b815291925090731a44076050125825900e736c501f859c50fe728c9063ddc28c58906105679085903090600401611745565b6040805180830381865afa158015610581573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906105a59190611815565b805190915015806105b95750602081015115155b806105c5575080513414155b156105e357604051636dac6a0960e01b815260040160405180910390fd5b6040516302637a4560e41b8152731a44076050125825900e736c501f859c50fe728c90632637a45090349061061e9086903390600401611745565b60806040518083038185885af115801561063a573d5f5f3e3d5ffd5b50505050506040513d601f19601f8201168201806040525081019061065f9190611843565b8051909350158061067b575060208301516001600160401b0316155b8061068d575060408301516020015115155b8061069c575060408301515134105b156106ba57604051636dac6a0960e01b815260040160405180910390fd5b825f01517f6d23cdaef17712141c7441cf202389c6ddc063fb5c14788d5c4479b62096d13f8560015f9054906101000a90046001600160a01b03166001600160a01b031663172195226040518163ffffffff1660e01b8152600401602060405180830381865afa158015610730573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061075491906118b6565b6040805160ff90931683526001600160401b0390911660208301520160405180910390a2505061078360015f55565b919050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161415806107ca57506001546001600160a01b031615155b806107dd57506001600160a01b0381163b155b806108595750306001600160a01b0316816001600160a01b03166303eadcfc6040518163ffffffff1660e01b8152600401602060405180830381865afa158015610829573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061084d91906118d1565b6001600160a01b031614155b806108e357507f0000000000000000000000000000000000000000000000000000000000000000816001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156108bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906108e091906118ec565b14155b8061095c57505f516020611a075f395f51905f525f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa158015610935573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061095991906118ec565b14155b806109ec57507355d398326f99059ff775485246999027b31979556001600160a01b0316816001600160a01b031663e5a6b10f6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156109bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906109e091906118d1565b6001600160a01b031614155b80610a7c575073c440f06bbc7e58b0d055815f915447e4ae0e37206001600160a01b0316816001600160a01b03166361d027b36040518163ffffffff1660e01b8152600401602060405180830381865afa158015610a4c573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610a7091906118d1565b6001600160a01b031614155b80610b1857507f00000000000000000000000000000000000000000000000000000000000000006001600160a01b0316816001600160a01b031663f77c47916040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ae8573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610b0c91906118d1565b6001600160a01b031614155b15610b3657604051636dac6a0960e01b815260040160405180910390fd5b600180546001600160a01b0319166001600160a01b0383169081179091556040517f3916d079df018feca66a550908f671cff67410227b4a8c24f13531847e12b9c8905f90a250565b610b87611451565b33731a44076050125825900e736c501f859c50fe728c141580610bbe57506176aa610bb56020890189611903565b63ffffffff1614155b80610bed57507f0000000000000000000000000000000000000000000000000000000000000000876020013514155b80610c0157506001546001600160a01b0316155b80610c0a575085155b80610c2b5750610c20606088016040890161191c565b6001600160401b0316155b80610c3557503415155b15610c5357604051636dac6a0960e01b815260040160405180910390fd5b608a84141580610c7e575084845f818110610c7057610c70611937565b9091013560f81c6003141590505b15610c9c57604051636dac6a0960e01b815260040160405180910390fd5b5f85856001818110610cb057610cb0611937565b919091013560f81c91505f9050610ccb60226002888a61194b565b610cd491611972565b90505f610ce560426022898b61194b565b610cee91611972565b90505f610cff604a60428a8c61194b565b610d089161198f565b60c01c90505f610d1c606a604a8b8d61194b565b610d2591611972565b90505f610d36608a606a8c8e61194b565b610d3f91611972565b90507f000000000000000000000000000000000000000000000000000000000000000085141580610d7d57505f516020611a075f395f51905f528414155b80610d8f57506001600160401b038316155b15610dad57604051636dac6a0960e01b815260040160405180910390fd5b5f8b8b604051610dbe9291906119c5565b60408051918290039091205f8f81526003602052919091205490915015801590610df557505f8d8152600360205260409020548114155b15610e1357604051636dac6a0960e01b815260040160405180910390fd5b8660ff16600103610eb05782151580610e2b57508115155b15610e4957604051636dac6a0960e01b815260040160405180910390fd5b60015460405163579c848360e11b81526001600160401b03861660048201526001600160a01b039091169063af390906906024015b5f604051808303815f87803b158015610e95575f5ffd5b505af1158015610ea7573d5f5f3e3d5ffd5b50505050610f1b565b8660ff16600303610f025760015460405163367938c560e21b81526001600160401b038616600482015260248101859052604481018490526001600160a01b039091169063d9e4e31490606401610e7e565b604051636dac6a0960e01b815260040160405180910390fd5b5f8d815260036020908152604091829020839055815160ff8a1681526001600160401b038716918101919091528e917f37949e68c9d0a4e5f5474ddb8654f999a5dc4b58a8aa1aef313516586e9b320a910160405180910390a250505050505050610f8560015f55565b50505050505050565b6001546060906001600160a01b0316610fba57604051636dac6a0960e01b815260040160405180910390fd5b8160ff166002036110705760035b60015f9054906101000a90046001600160a01b03166001600160a01b031663c19d93fb6040518163ffffffff1660e01b8152600401602060405180830381865afa158015611018573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061103c91906119e8565b600481111561104d5761104d6119d4565b1461106b57604051636dac6a0960e01b815260040160405180910390fd5b611082565b8160ff16600403610f02576004610fc8565b60015460408051630b90ca9160e11b8152905160039285927f0000000000000000000000000000000000000000000000000000000000000000925f516020611a075f395f51905f52926001600160a01b03169163172195229160048083019260209291908290030181865afa1580156110fd573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061112191906118b6565b60015f9054906101000a90046001600160a01b03166001600160a01b0316635467e0a76040518163ffffffff1660e01b8152600401602060405180830381865afa158015611171573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061119591906118ec565b60015f9054906101000a90046001600160a01b03166001600160a01b03166366d003ac6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156111e5573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061120991906118ec565b60405160f897881b6001600160f81b031990811660208301529690971b90951660218701526022860193909352604285019190915260c01b6001600160c01b0319166062840152606a830152608a82015260aa016040516020818303038152906040529050919050565b5f5b92915050565b600254604051600360f01b6020820152600160f81b60228201819052601160f01b6023830152602582015260809190911b6001600160801b0319166026820152606090603601604051602081830303815290604052905090565b604080518082019091525f80825260208201526040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91731a44076050125825900e736c501f859c50fe728c9163ddc28c5891810161134687610f8e565b815260200161135361127b565b81525f6020909101526040516001600160e01b031960e084901b16815261137f91903090600401611745565b6040805180830381865afa158015611399573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906113bd9190611815565b805190915015806113d15750602081015115155b1561127557604051636dac6a0960e01b815260040160405180910390fd5b5f6176aa6114006020840184611903565b63ffffffff1614801561143657507f00000000000000000000000000000000000000000000000000000000000000008260200135145b801561127557506001546001600160a01b0316151592915050565b60025f540361147357604051633ee5aeb560e01b815260040160405180910390fd5b60025f55565b60405180606001604052805f81526020015f6001600160401b031681526020016114b460405180604001604052805f81526020015f81525090565b905290565b5f602082840312156114c9575f5ffd5b81356001600160801b03811681146114df575f5ffd5b9392505050565b5f602082840312156114f6575f5ffd5b813560ff811681146114df575f5ffd5b5f608082019050825182526001600160401b0360208401511660208301526040830151611540604084018280518252602090810151910152565b5092915050565b6001600160a01b038116811461155b575f5ffd5b50565b5f6020828403121561156e575f5ffd5b81356114df81611547565b5f60608284031215611589575f5ffd5b50919050565b5f5f83601f84011261159f575f5ffd5b5081356001600160401b038111156115b5575f5ffd5b6020830191508360208285010111156115cc575f5ffd5b9250929050565b5f5f5f5f5f5f5f60e0888a0312156115e9575f5ffd5b6115f38989611579565b96506060880135955060808801356001600160401b03811115611614575f5ffd5b6116208a828b0161158f565b90965094505060a088013561163481611547565b925060c08801356001600160401b0381111561164e575f5ffd5b61165a8a828b0161158f565b989b979a50959850939692959293505050565b5f81518084525f5b8181101561169157602081850181015186830182015201611675565b505f602082860101526020601f19601f83011685010191505092915050565b602081525f6114df602083018461166d565b803563ffffffff81168114610783575f5ffd5b5f5f604083850312156116e6575f5ffd5b6116ef836116c2565b946020939093013593505050565b815181526020808301519082015260408101611275565b5f60208284031215611724575f5ffd5b5035919050565b5f6060828403121561173b575f5ffd5b6114df8383611579565b6040815263ffffffff8351166040820152602083015160608201525f604084015160a0608084015261177a60e084018261166d565b90506060850151603f198483030160a0850152611797828261166d565b60809690960151151560c08501525050506001600160a01b039190911660209091015290565b5f604082840312156117cd575f5ffd5b604080519081016001600160401b03811182821017156117fb57634e487b7160e01b5f52604160045260245ffd5b604052825181526020928301519281019290925250919050565b5f60408284031215611825575f5ffd5b6114df83836117bd565b6001600160401b038116811461155b575f5ffd5b5f6080828403128015611854575f5ffd5b50604051606081016001600160401b038111828210171561188357634e487b7160e01b5f52604160045260245ffd5b6040528251815260208301516118988161182f565b60208201526118aa84604085016117bd565b60408201529392505050565b5f602082840312156118c6575f5ffd5b81516114df8161182f565b5f602082840312156118e1575f5ffd5b81516114df81611547565b5f602082840312156118fc575f5ffd5b5051919050565b5f60208284031215611913575f5ffd5b6114df826116c2565b5f6020828403121561192c575f5ffd5b81356114df8161182f565b634e487b7160e01b5f52603260045260245ffd5b5f5f85851115611959575f5ffd5b83861115611965575f5ffd5b5050820193919092039150565b80356020831015611275575f19602084900360031b1b1692915050565b80356001600160c01b03198116906008841015611540576001600160c01b031960089490940360031b84901b1690921692915050565b818382375f9101908152919050565b634e487b7160e01b5f52602160045260245ffd5b5f602082840312156119f8575f5ffd5b8151600581106114df575f5ffdfe046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6baa2646970667358221220d5e0a008fcf934cc781ad8e21c7865f692e69e850ec3b05743fb3e9c2c69c09a64736f6c634300081e0033" } } }, pass: { abi: [{ inputs: [{ internalType: "address", name: "verifier", type: "address" }], stateMutability: "nonpayable", type: "constructor" }, { inputs: [{ internalType: "address", name: "sender", type: "address" }, { internalType: "uint256", name: "tokenId", type: "uint256" }, { internalType: "address", name: "owner", type: "address" }], name: "ERC721IncorrectOwner", type: "error" }, { inputs: [{ internalType: "address", name: "operator", type: "address" }, { internalType: "uint256", name: "tokenId", type: "uint256" }], name: "ERC721InsufficientApproval", type: "error" }, { inputs: [{ internalType: "address", name: "approver", type: "address" }], name: "ERC721InvalidApprover", type: "error" }, { inputs: [{ internalType: "address", name: "operator", type: "address" }], name: "ERC721InvalidOperator", type: "error" }, { inputs: [{ internalType: "address", name: "owner", type: "address" }], name: "ERC721InvalidOwner", type: "error" }, { inputs: [{ internalType: "address", name: "receiver", type: "address" }], name: "ERC721InvalidReceiver", type: "error" }, { inputs: [{ internalType: "address", name: "sender", type: "address" }], name: "ERC721InvalidSender", type: "error" }, { inputs: [{ internalType: "uint256", name: "tokenId", type: "uint256" }], name: "ERC721NonexistentToken", type: "error" }, { inputs: [], name: "Invalid", type: "error" }, { inputs: [], name: "ReentrancyGuardReentrantCall", type: "error" }, { inputs: [{ internalType: "address", name: "token", type: "address" }], name: "SafeERC20FailedOperation", type: "error" }, { anonymous: false, inputs: [{ indexed: true, internalType: "address", name: "owner", type: "address" }, { indexed: true, internalType: "address", name: "approved", type: "address" }, { indexed: true, internalType: "uint256", name: "tokenId", type: "uint256" }], name: "Approval", type: "event" }, { anonymous: false, inputs: [{ indexed: true, internalType: "address", name: "owner", type: "address" }, { indexed: true, internalType: "address", name: "operator", type: "address" }, { indexed: false, internalType: "bool", name: "approved", type: "bool" }], name: "ApprovalForAll", type: "event" }, { anonymous: false, inputs: [{ indexed: true, internalType: "uint64", name: "generation", type: "uint64" }, { indexed: true, internalType: "address", name: "buyer", type: "address" }, { indexed: false, internalType: "uint256", name: "amount", type: "uint256" }], name: "PassPurchased", type: "event" }, { anonymous: false, inputs: [{ indexed: false, internalType: "bool", name: "paused", type: "bool" }], name: "PurchasePauseChanged", type: "event" }, { anonymous: false, inputs: [{ indexed: true, internalType: "uint64", name: "generation", type: "uint64" }, { indexed: true, internalType: "bytes32", name: "request", type: "bytes32" }], name: "RedemptionFinalized", type: "event" }, { anonymous: false, inputs: [{ indexed: true, internalType: "uint64", name: "generation", type: "uint64" }, { indexed: true, internalType: "bytes32", name: "request", type: "bytes32" }, { indexed: false, internalType: "bytes32", name: "recipient", type: "bytes32" }], name: "RedemptionRequested", type: "event" }, { anonymous: false, inputs: [{ indexed: true, internalType: "uint64", name: "generation", type: "uint64" }], name: "ReserveConfirmed", type: "event" }, { anonymous: false, inputs: [{ indexed: true, internalType: "address", name: "from", type: "address" }, { indexed: true, internalType: "address", name: "to", type: "address" }, { indexed: true, internalType: "uint256", name: "tokenId", type: "uint256" }], name: "Transfer", type: "event" }, { inputs: [], name: "PRICE", outputs: [{ internalType: "uint256", name: "", type: "uint256" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "uint64", name: "gen", type: "uint64" }, { internalType: "bytes32", name: "request", type: "bytes32" }, { internalType: "bytes32", name: "suiRecipient", type: "bytes32" }], name: "acknowledge", outputs: [], stateMutability: "nonpayable", type: "function" }, { inputs: [], name: "adapter", outputs: [{ internalType: "address", name: "", type: "address" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "address", name: "to", type: "address" }, { internalType: "uint256", name: "tokenId", type: "uint256" }], name: "approve", outputs: [], stateMutability: "nonpayable", type: "function" }, { inputs: [], name: "backingNFT", outputs: [{ internalType: "bytes32", name: "", type: "bytes32" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "address", name: "owner", type: "address" }], name: "balanceOf", outputs: [{ internalType: "uint256", name: "", type: "uint256" }], stateMutability: "view", type: "function" }, { inputs: [], name: "buy", outputs: [], stateMutability: "nonpayable", type: "function" }, { inputs: [{ internalType: "address", name: "wallet", type: "address" }], name: "canPlay", outputs: [{ internalType: "bool", name: "", type: "bool" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "uint64", name: "next", type: "uint64" }], name: "confirmReserve", outputs: [], stateMutability: "nonpayable", type: "function" }, { inputs: [], name: "controller", outputs: [{ internalType: "address", name: "", type: "address" }], stateMutability: "view", type: "function" }, { inputs: [], name: "currency", outputs: [{ internalType: "contract IERC20", name: "", type: "address" }], stateMutability: "view", type: "function" }, { inputs: [], name: "currencyCodeHash", outputs: [{ internalType: "bytes32", name: "", type: "bytes32" }], stateMutability: "view", type: "function" }, { inputs: [], name: "generation", outputs: [{ internalType: "uint64", name: "", type: "uint64" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "uint256", name: "tokenId", type: "uint256" }], name: "getApproved", outputs: [{ internalType: "address", name: "", type: "address" }], stateMutability: "view", type: "function" }, { inputs: [], name: "initialBuyer", outputs: [{ internalType: "address", name: "", type: "address" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "address", name: "owner", type: "address" }, { internalType: "address", name: "operator", type: "address" }], name: "isApprovedForAll", outputs: [{ internalType: "bool", name: "", type: "bool" }], stateMutability: "view", type: "function" }, { inputs: [], name: "name", outputs: [{ internalType: "string", name: "", type: "string" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "uint256", name: "tokenId", type: "uint256" }], name: "ownerOf", outputs: [{ internalType: "address", name: "", type: "address" }], stateMutability: "view", type: "function" }, { inputs: [], name: "purchasesPaused", outputs: [{ internalType: "bool", name: "", type: "bool" }], stateMutability: "view", type: "function" }, { inputs: [], name: "recipient", outputs: [{ internalType: "bytes32", name: "", type: "bytes32" }], stateMutability: "view", type: "function" }, { inputs: [], name: "redemption", outputs: [{ internalType: "bytes32", name: "", type: "bytes32" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "bytes32", name: "suiRecipient", type: "bytes32" }], name: "requestRedemption", outputs: [{ internalType: "bytes32", name: "", type: "bytes32" }], stateMutability: "nonpayable", type: "function" }, { inputs: [], name: "route", outputs: [{ internalType: "bytes32", name: "", type: "bytes32" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "address", name: "from", type: "address" }, { internalType: "address", name: "to", type: "address" }, { internalType: "uint256", name: "tokenId", type: "uint256" }], name: "safeTransferFrom", outputs: [], stateMutability: "nonpayable", type: "function" }, { inputs: [{ internalType: "address", name: "from", type: "address" }, { internalType: "address", name: "to", type: "address" }, { internalType: "uint256", name: "tokenId", type: "uint256" }, { internalType: "bytes", name: "data", type: "bytes" }], name: "safeTransferFrom", outputs: [], stateMutability: "nonpayable", type: "function" }, { inputs: [{ internalType: "address", name: "operator", type: "address" }, { internalType: "bool", name: "approved", type: "bool" }], name: "setApprovalForAll", outputs: [], stateMutability: "nonpayable", type: "function" }, { inputs: [{ internalType: "bool", name: "paused", type: "bool" }], name: "setPurchasesPaused", outputs: [], stateMutability: "nonpayable", type: "function" }, { inputs: [], name: "state", outputs: [{ internalType: "enum TreeSuitePass.State", name: "", type: "uint8" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "bytes4", name: "interfaceId", type: "bytes4" }], name: "supportsInterface", outputs: [{ internalType: "bool", name: "", type: "bool" }], stateMutability: "view", type: "function" }, { inputs: [], name: "symbol", outputs: [{ internalType: "string", name: "", type: "string" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "uint256", name: "tokenId", type: "uint256" }], name: "tokenURI", outputs: [{ internalType: "string", name: "", type: "string" }], stateMutability: "view", type: "function" }, { inputs: [{ internalType: "address", name: "from", type: "address" }, { internalType: "address", name: "to", type: "address" }, { internalType: "uint256", name: "tokenId", type: "uint256" }], name: "transferFrom", outputs: [], stateMutability: "nonpayable", type: "function" }, { inputs: [], name: "treasury", outputs: [{ internalType: "address", name: "", type: "address" }], stateMutability: "view", type: "function" }], evm: { bytecode: { object: "610120604052600a805460ff1916600117905534801561001d575f5ffd5b506040516124c33803806124c383398101604081905261003c916104aa565b6040518060400160405280601c81526020017f4e46547265652053756974652047656e65726174696f6e205061737300000000815250604051806040016040528060078152602001662a2922a2a3a2a760c91b815250815f90816100a0919061056f565b5060016100ad828261056f565b50506001600655504660381415806100d857507355d398326f99059ff775485246999027b31979553b155b806100eb57506001600160a01b0381163b155b8061016d57507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610141573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906101659190610629565b60ff16601214155b1561018b57604051636dac6a0960e01b815260040160405180910390fd5b5f819050336001600160a01b0316816001600160a01b031663acba7b426040518163ffffffff1660e01b8152600401602060405180830381865afa1580156101d5573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906101f991906104aa565b6001600160a01b03161415806102945750731a44076050125825900e736c501f859c50fe728c6001600160a01b0316816001600160a01b0316635e280f116040518163ffffffff1660e01b8152600401602060405180830381865afa158015610264573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061028891906104aa565b6001600160a01b031614155b806102fc5750806001600160a01b03166315aff54e6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156102d6573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906102fa9190610649565b155b806103645750806001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa15801561033e573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906103629190610649565b155b806103f057507f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba5f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa1580156103c9573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906103ed9190610649565b14155b1561040e57604051636dac6a0960e01b815260040160405180910390fd5b6001600160a01b038083166080523360a081905260c0526040805163d96661ef60e01b815290519183169163d96661ef916004808201926020929091908290030181865afa158015610462573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906104869190610649565b60e05250507355d398326f99059ff775485246999027b31979553f61010052610660565b5f602082840312156104ba575f5ffd5b81516001600160a01b03811681146104d0575f5ffd5b9392505050565b634e487b7160e01b5f52604160045260245ffd5b600181811c908216806104ff57607f821691505b60208210810361051d57634e487b7160e01b5f52602260045260245ffd5b50919050565b601f82111561056a57805f5260205f20601f840160051c810160208510156105485750805b601f840160051c820191505b81811015610567575f8155600101610554565b50505b505050565b81516001600160401b03811115610588576105886104d7565b61059c8161059684546104eb565b84610523565b6020601f8211600181146105ce575f83156105b75750848201515b5f19600385901b1c1916600184901b178455610567565b5f84815260208120601f198516915b828110156105fd57878501518255602094850194600190920191016105dd565b508482101561061a57868401515f19600387901b60f8161c191681555b50505050600190811b01905550565b5f60208284031215610639575f5ffd5b815160ff811681146104d0575f5ffd5b5f60208284031215610659575f5ffd5b5051919050565b60805160a05160c05160e05161010051611dfc6106c75f395f81816102620152610a5101525f818161049701526108e101525f81816104ff015261073701525f81816103900152610a1001525f818161022301528181610d200152610f3c0152611dfc5ff3fe608060405234801561000f575f5ffd5b50600436106101f2575f3560e01c806370a0823111610114578063b88d4fde116100a9578063d96661ef11610079578063d96661ef14610492578063d9e4e314146104b9578063e5a6b10f146104cc578063e985e9c5146104e7578063f77c4791146104fa575f5ffd5b8063b88d4fde14610445578063c19d93fb14610458578063c87b56dd14610472578063c9f2071514610485575f5ffd5b806397579dd3116100e457806397579dd314610404578063a22cb46514610417578063a6f2ae3a1461042a578063af39090614610432575f5ffd5b806370a08231146103b257806378360c88146103c55780638d859f3e146103ec57806395d89b41146103fc575f5ffd5b806323b872dd1161018a57806361d027b31161015a57806361d027b3146103545780636352211e1461036f57806366d003ac146103825780636af7f9f51461038b575f5ffd5b806323b872dd14610312578063325832ac1461032557806342842e0e146103385780635467e0a71461034b575f5ffd5b8063081812fc116101c5578063081812fc146102a75780630823d5f3146102ba578063095ea7b3146102cd57806317219522146102e2575f5ffd5b806301ffc9a7146101f657806303eadcfc1461021e57806306f660a71461025d57806306fdde0314610292575b5f5ffd5b610209610204366004611962565b610521565b60405190151581526020015b60405180910390f35b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6040516001600160a01b039091168152602001610215565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b604051908152602001610215565b61029a610572565b60405161021591906119ca565b6102456102b53660046119dc565b610601565b6102096102c8366004611a09565b610628565b6102e06102db366004611a22565b61068f565b005b6007546102fa9061010090046001600160401b031681565b6040516001600160401b039091168152602001610215565b6102e0610320366004611a4a565b61069e565b6102e0610333366004611a93565b61072c565b6102e0610346366004611a4a565b6107bc565b61028460085481565b61024573c440f06bbc7e58b0d055815f915447e4ae0e372081565b61024561037d3660046119dc565b6107db565b61028460095481565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6102846103c0366004611a09565b6107e5565b6102847f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba81565b61028468015af1d78b58c4000081565b61029a61082a565b6102846104123660046119dc565b610839565b6102e0610425366004611aac565b6109c4565b6102e06109cf565b6102e0610440366004611af3565b610d15565b6102e0610453366004611b20565b610ea8565b6007546104659060ff1681565b6040516102159190611c0e565b61029a6104803660046119dc565b610ec0565b600a546102099060ff1681565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b6102e06104c7366004611c34565b610f31565b6102457355d398326f99059ff775485246999027b319795581565b6102096104f5366004611c64565b61109d565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b5f6001600160e01b031982166380ac58cd60e01b148061055157506001600160e01b03198216635b5e139f60e01b145b8061056c57506301ffc9a760e01b6001600160e01b03198316145b92915050565b60605f805461058090611c8c565b80601f01602080910402602001604051908101604052809291908181526020018280546105ac90611c8c565b80156105f75780601f106105ce576101008083540402835291602001916105f7565b820191905f5260205f20905b8154815290600101906020018083116105da57829003601f168201915b5050505050905090565b5f61060b826110ca565b505f828152600460205260409020546001600160a01b031661056c565b5f600260075460ff16600481111561064257610642611bfa565b14801561065757506001600160a01b03821615155b801561056c57505060075461010090046001600160401b03165f908152600260205260409020546001600160a01b0391821691161490565b61069a828233611102565b5050565b6001600160a01b0382166106cc57604051633250574960e11b81525f60048201526024015b60405180910390fd5b5f6106d883833361110f565b9050836001600160a01b0316816001600160a01b031614610726576040516364283d7b60e01b81526001600160a01b03808616600483015260248201849052821660448201526064016106c3565b50505050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161461077557604051636dac6a0960e01b815260040160405180910390fd5b600a805460ff19168215159081179091556040519081527fd6d0fdd597c17a0211f0324826035a55dec84b1e6196f3585be220b46767fbb99060200160405180910390a150565b6107d683838360405180602001604052805f815250610ea8565b505050565b5f61056c826110ca565b5f6001600160a01b03821661080f576040516322718ad960e21b81525f60048201526024016106c3565b506001600160a01b03165f9081526003602052604090205490565b60606001805461058090611c8c565b5f6108426111ad565b600260075460ff16600481111561085b5761085b611bfa565b14158061088b5750600754339061087f9061010090046001600160401b03166107db565b6001600160a01b031614155b80610894575081155b156108b257604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff1916600390811791829055600984905560408051602081019290925246908201523060608201527f000000000000000000000000000000000000000000000000000000000000000060808201527f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba60a08201526001600160401b03610100928390041660c08201523360e08201529081018390526101200160408051808303601f19018152908290528051602091820120600881905560075485845290926101009091046001600160401b0316917f5852bd51fa2990e2712a8f82286a04ca0750a7646a7950235ffefdb10585cefe910160405180910390a3506008546109bf6001600655565b919050565b61069a3383836111d7565b6109d76111ad565b600160075460ff1660048111156109f0576109f0611bfa565b1415806109ff5750600a5460ff165b80610a335750336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614155b80610a7357507355d398326f99059ff775485246999027b31979553f7f000000000000000000000000000000000000000000000000000000000000000014155b80610af557507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ac9573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610aed9190611cc4565b60ff16601214155b15610b1357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660021790556040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201525f907355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610b83573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610ba79190611ce4565b9050610be67355d398326f99059ff775485246999027b31979553373c440f06bbc7e58b0d055815f915447e4ae0e372068015af1d78b58c40000611275565b610bf968015af1d78b58c4000082611d0f565b6040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201527355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610c5a573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610c7e9190611ce4565b14610c9c57604051636dac6a0960e01b815260040160405180910390fd5b600754610cb890339061010090046001600160401b03166112cf565b60075460405168015af1d78b58c400008152339161010090046001600160401b0316907f266845010576f42f87c2d262b76328c22b6797abd6c81b34f59fc1b2da1c487e9060200160405180910390a350610d136001600655565b565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610d5e57604051636dac6a0960e01b815260040160405180910390fd5b806001600160401b03165f03610d8757604051636dac6a0960e01b815260040160405180910390fd5b6007546001600160401b038281166101009092041614610ea557600754610dbd9061010090046001600160401b03166001611d22565b6001600160401b0316816001600160401b0316141580610e1557505f60075460ff166004811115610df057610df0611bfa565b14158015610e155750600460075460ff166004811115610e1257610e12611bfa565b14155b15610e3357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff196001600160401b0384166101008102821668ffffffffffffffffff199093169290921760019081179093555f60088190556009819055600a8054909216909317905560405190917ff48a2acdce0f4a30c2d32425d8827b030bbdff66b7694573d92cdd52b818fd1691a25b50565b610eb384848461069e565b61072633858585856112e8565b6060610ecb826110ca565b505f610ee160408051602081019091525f815290565b90505f815111610eff5760405180602001604052805f815250610f2a565b80610f0984611410565b604051602001610f1a929190611d41565b6040516020818303038152906040525b9392505050565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610f7a57604051636dac6a0960e01b815260040160405180910390fd5b610f826111ad565b6007546001600160401b0384811661010090920416141580610fa2575081155b80610faf57506008548214155b80610fbc57506009548114155b15610fda57604051636dac6a0960e01b815260040160405180910390fd5b600460075460ff166004811115610ff357610ff3611bfa565b1461109357600360075460ff16600481111561101157611011611bfa565b1461102f57604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660041790819055611056906001600160401b036101009091041661149f565b600754604051839161010090046001600160401b0316907f4baa52424160077091b85a05340629c1a44cfac77a87274fad62a384fe6193f0905f90a35b6107d66001600655565b6001600160a01b039182165f90815260056020908152604080832093909416825291909152205460ff1690565b5f818152600260205260408120546001600160a01b03168061056c57604051637e27328960e01b8152600481018490526024016106c3565b6107d683838360016114d7565b6007545f9061010090046001600160401b03168314158061117c5750600260075460ff16600481111561114457611144611bfa565b1415801561117c5750600460075460ff16600481111561116657611166611bfa565b14801561117a57506001600160a01b038416155b155b1561119a57604051636dac6a0960e01b815260040160405180910390fd5b6111a58484846115db565b949350505050565b6002600654036111d057604051633ee5aeb560e01b815260040160405180910390fd5b6002600655565b6001600160a01b03821661120957604051630b61174360e31b81526001600160a01b03831660048201526024016106c3565b6001600160a01b038381165f81815260056020908152604080832094871680845294825291829020805460ff191686151590811790915591519182527f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31910160405180910390a3505050565b604080516001600160a01b0385811660248301528416604482015260648082018490528251808303909101815260849091019091526020810180516001600160e01b03166323b872dd60e01b1790526107269085906116cd565b61069a828260405180602001604052805f815250611739565b6001600160a01b0383163b1561140957604051630a85bd0160e11b81526001600160a01b0384169063150b7a029061132a908890889087908790600401611d6f565b6020604051808303815f875af1925050508015611364575060408051601f3d908101601f1916820190925261136191810190611dab565b60015b6113cb573d808015611391576040519150601f19603f3d011682016040523d82523d5f602084013e611396565b606091505b5080515f036113c357604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b805160208201fd5b6001600160e01b03198116630a85bd0160e11b1461140757604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b505b5050505050565b60605f61141c83611750565b60010190505f816001600160401b0381111561143a5761143a611b0c565b6040519080825280601f01601f191660200182016040528015611464576020820181803683370190505b5090508181016020015b5f19016f181899199a1a9b1b9c1cb0b131b232b360811b600a86061a8153600a850494508461146e57509392505050565b5f6114ab5f835f61110f565b90506001600160a01b03811661069a57604051637e27328960e01b8152600481018390526024016106c3565b80806114eb57506001600160a01b03821615155b156115ac575f6114fa846110ca565b90506001600160a01b038316158015906115265750826001600160a01b0316816001600160a01b031614155b80156115395750611537818461109d565b155b156115625760405163a9fbf51f60e01b81526001600160a01b03841660048201526024016106c3565b81156115aa5783856001600160a01b0316826001600160a01b03167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45b505b50505f90815260046020526040902080546001600160a01b0319166001600160a01b0392909216919091179055565b5f828152600260205260408120546001600160a01b039081169083161561160757611607818486611827565b6001600160a01b03811615611641576116225f855f5f6114d7565b6001600160a01b0381165f90815260036020526040902080545f190190555b6001600160a01b0385161561166f576001600160a01b0385165f908152600360205260409020805460010190555b5f8481526002602052604080822080546001600160a01b0319166001600160a01b0389811691821790925591518793918516917fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef91a4949350505050565b5f5f60205f8451602086015f885af1806116ec576040513d5f823e3d81fd5b50505f513d91508115611703578060011415611710565b6001600160a01b0384163b155b1561072657604051635274afe760e01b81526001600160a01b03851660048201526024016106c3565b611743838361188b565b6107d6335f8585856112e8565b5f8072184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b831061178e5772184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b830492506040015b6d04ee2d6d415b85acef810000000083106117ba576d04ee2d6d415b85acef8100000000830492506020015b662386f26fc1000083106117d857662386f26fc10000830492506010015b6305f5e10083106117f0576305f5e100830492506008015b612710831061180457612710830492506004015b60648310611816576064830492506002015b600a831061056c5760010192915050565b6118328383836118ec565b6107d6576001600160a01b03831661186057604051637e27328960e01b8152600481018290526024016106c3565b60405163177e802f60e01b81526001600160a01b0383166004820152602481018290526044016106c3565b6001600160a01b0382166118b457604051633250574960e11b81525f60048201526024016106c3565b5f6118c083835f61110f565b90506001600160a01b038116156107d6576040516339e3563760e11b81525f60048201526024016106c3565b5f6001600160a01b038316158015906111a55750826001600160a01b0316846001600160a01b031614806119255750611925848461109d565b806111a55750505f908152600460205260409020546001600160a01b03908116911614919050565b6001600160e01b031981168114610ea5575f5ffd5b5f60208284031215611972575f5ffd5b8135610f2a8161194d565b5f5b8381101561199757818101518382015260200161197f565b50505f910152565b5f81518084526119b681602086016020860161197d565b601f01601f19169290920160200192915050565b602081525f610f2a602083018461199f565b5f602082840312156119ec575f5ffd5b5035919050565b80356001600160a01b03811681146109bf575f5ffd5b5f60208284031215611a19575f5ffd5b610f2a826119f3565b5f5f60408385031215611a33575f5ffd5b611a3c836119f3565b946020939093013593505050565b5f5f5f60608486031215611a5c575f5ffd5b611a65846119f3565b9250611a73602085016119f3565b929592945050506040919091013590565b803580151581146109bf575f5ffd5b5f60208284031215611aa3575f5ffd5b610f2a82611a84565b5f5f60408385031215611abd575f5ffd5b611ac6836119f3565b9150611ad460208401611a84565b90509250929050565b80356001600160401b03811681146109bf575f5ffd5b5f60208284031215611b03575f5ffd5b610f2a82611add565b634e487b7160e01b5f52604160045260245ffd5b5f5f5f5f60808587031215611b33575f5ffd5b611b3c856119f3565b9350611b4a602086016119f3565b92506040850135915060608501356001600160401b03811115611b6b575f5ffd5b8501601f81018713611b7b575f5ffd5b80356001600160401b03811115611b9457611b94611b0c565b604051601f8201601f19908116603f011681016001600160401b0381118282101715611bc257611bc2611b0c565b604052818152828201602001891015611bd9575f5ffd5b816020840160208301375f6020838301015280935050505092959194509250565b634e487b7160e01b5f52602160045260245ffd5b6020810160058310611c2e57634e487b7160e01b5f52602160045260245ffd5b91905290565b5f5f5f60608486031215611c46575f5ffd5b611c4f84611add565b95602085013595506040909401359392505050565b5f5f60408385031215611c75575f5ffd5b611c7e836119f3565b9150611ad4602084016119f3565b600181811c90821680611ca057607f821691505b602082108103611cbe57634e487b7160e01b5f52602260045260245ffd5b50919050565b5f60208284031215611cd4575f5ffd5b815160ff81168114610f2a575f5ffd5b5f60208284031215611cf4575f5ffd5b5051919050565b634e487b7160e01b5f52601160045260245ffd5b8082018082111561056c5761056c611cfb565b6001600160401b03818116838216019081111561056c5761056c611cfb565b5f8351611d5281846020880161197d565b835190830190611d6681836020880161197d565b01949350505050565b6001600160a01b03858116825284166020820152604081018390526080606082018190525f90611da19083018461199f565b9695505050505050565b5f60208284031215611dbb575f5ffd5b8151610f2a8161194d56fea26469706673582212205cd0600d0bc59401f6362a6ffeeddd9fccccd322ad458bc4283018628c84b01f64736f6c634300081e0033" }, deployedBytecode: { immutableReferences: { "880": [{ length: 32, start: 547 }, { length: 32, start: 3360 }, { length: 32, start: 3900 }], "882": [{ length: 32, start: 912 }, { length: 32, start: 2576 }], "884": [{ length: 32, start: 1279 }, { length: 32, start: 1847 }], "886": [{ length: 32, start: 1175 }, { length: 32, start: 2273 }], "888": [{ length: 32, start: 610 }, { length: 32, start: 2641 }] }, object: "608060405234801561000f575f5ffd5b50600436106101f2575f3560e01c806370a0823111610114578063b88d4fde116100a9578063d96661ef11610079578063d96661ef14610492578063d9e4e314146104b9578063e5a6b10f146104cc578063e985e9c5146104e7578063f77c4791146104fa575f5ffd5b8063b88d4fde14610445578063c19d93fb14610458578063c87b56dd14610472578063c9f2071514610485575f5ffd5b806397579dd3116100e457806397579dd314610404578063a22cb46514610417578063a6f2ae3a1461042a578063af39090614610432575f5ffd5b806370a08231146103b257806378360c88146103c55780638d859f3e146103ec57806395d89b41146103fc575f5ffd5b806323b872dd1161018a57806361d027b31161015a57806361d027b3146103545780636352211e1461036f57806366d003ac146103825780636af7f9f51461038b575f5ffd5b806323b872dd14610312578063325832ac1461032557806342842e0e146103385780635467e0a71461034b575f5ffd5b8063081812fc116101c5578063081812fc146102a75780630823d5f3146102ba578063095ea7b3146102cd57806317219522146102e2575f5ffd5b806301ffc9a7146101f657806303eadcfc1461021e57806306f660a71461025d57806306fdde0314610292575b5f5ffd5b610209610204366004611962565b610521565b60405190151581526020015b60405180910390f35b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6040516001600160a01b039091168152602001610215565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b604051908152602001610215565b61029a610572565b60405161021591906119ca565b6102456102b53660046119dc565b610601565b6102096102c8366004611a09565b610628565b6102e06102db366004611a22565b61068f565b005b6007546102fa9061010090046001600160401b031681565b6040516001600160401b039091168152602001610215565b6102e0610320366004611a4a565b61069e565b6102e0610333366004611a93565b61072c565b6102e0610346366004611a4a565b6107bc565b61028460085481565b61024573c440f06bbc7e58b0d055815f915447e4ae0e372081565b61024561037d3660046119dc565b6107db565b61028460095481565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6102846103c0366004611a09565b6107e5565b6102847f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba81565b61028468015af1d78b58c4000081565b61029a61082a565b6102846104123660046119dc565b610839565b6102e0610425366004611aac565b6109c4565b6102e06109cf565b6102e0610440366004611af3565b610d15565b6102e0610453366004611b20565b610ea8565b6007546104659060ff1681565b6040516102159190611c0e565b61029a6104803660046119dc565b610ec0565b600a546102099060ff1681565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b6102e06104c7366004611c34565b610f31565b6102457355d398326f99059ff775485246999027b319795581565b6102096104f5366004611c64565b61109d565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b5f6001600160e01b031982166380ac58cd60e01b148061055157506001600160e01b03198216635b5e139f60e01b145b8061056c57506301ffc9a760e01b6001600160e01b03198316145b92915050565b60605f805461058090611c8c565b80601f01602080910402602001604051908101604052809291908181526020018280546105ac90611c8c565b80156105f75780601f106105ce576101008083540402835291602001916105f7565b820191905f5260205f20905b8154815290600101906020018083116105da57829003601f168201915b5050505050905090565b5f61060b826110ca565b505f828152600460205260409020546001600160a01b031661056c565b5f600260075460ff16600481111561064257610642611bfa565b14801561065757506001600160a01b03821615155b801561056c57505060075461010090046001600160401b03165f908152600260205260409020546001600160a01b0391821691161490565b61069a828233611102565b5050565b6001600160a01b0382166106cc57604051633250574960e11b81525f60048201526024015b60405180910390fd5b5f6106d883833361110f565b9050836001600160a01b0316816001600160a01b031614610726576040516364283d7b60e01b81526001600160a01b03808616600483015260248201849052821660448201526064016106c3565b50505050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161461077557604051636dac6a0960e01b815260040160405180910390fd5b600a805460ff19168215159081179091556040519081527fd6d0fdd597c17a0211f0324826035a55dec84b1e6196f3585be220b46767fbb99060200160405180910390a150565b6107d683838360405180602001604052805f815250610ea8565b505050565b5f61056c826110ca565b5f6001600160a01b03821661080f576040516322718ad960e21b81525f60048201526024016106c3565b506001600160a01b03165f9081526003602052604090205490565b60606001805461058090611c8c565b5f6108426111ad565b600260075460ff16600481111561085b5761085b611bfa565b14158061088b5750600754339061087f9061010090046001600160401b03166107db565b6001600160a01b031614155b80610894575081155b156108b257604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff1916600390811791829055600984905560408051602081019290925246908201523060608201527f000000000000000000000000000000000000000000000000000000000000000060808201527f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba60a08201526001600160401b03610100928390041660c08201523360e08201529081018390526101200160408051808303601f19018152908290528051602091820120600881905560075485845290926101009091046001600160401b0316917f5852bd51fa2990e2712a8f82286a04ca0750a7646a7950235ffefdb10585cefe910160405180910390a3506008546109bf6001600655565b919050565b61069a3383836111d7565b6109d76111ad565b600160075460ff1660048111156109f0576109f0611bfa565b1415806109ff5750600a5460ff165b80610a335750336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614155b80610a7357507355d398326f99059ff775485246999027b31979553f7f000000000000000000000000000000000000000000000000000000000000000014155b80610af557507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ac9573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610aed9190611cc4565b60ff16601214155b15610b1357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660021790556040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201525f907355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610b83573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610ba79190611ce4565b9050610be67355d398326f99059ff775485246999027b31979553373c440f06bbc7e58b0d055815f915447e4ae0e372068015af1d78b58c40000611275565b610bf968015af1d78b58c4000082611d0f565b6040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201527355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610c5a573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610c7e9190611ce4565b14610c9c57604051636dac6a0960e01b815260040160405180910390fd5b600754610cb890339061010090046001600160401b03166112cf565b60075460405168015af1d78b58c400008152339161010090046001600160401b0316907f266845010576f42f87c2d262b76328c22b6797abd6c81b34f59fc1b2da1c487e9060200160405180910390a350610d136001600655565b565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610d5e57604051636dac6a0960e01b815260040160405180910390fd5b806001600160401b03165f03610d8757604051636dac6a0960e01b815260040160405180910390fd5b6007546001600160401b038281166101009092041614610ea557600754610dbd9061010090046001600160401b03166001611d22565b6001600160401b0316816001600160401b0316141580610e1557505f60075460ff166004811115610df057610df0611bfa565b14158015610e155750600460075460ff166004811115610e1257610e12611bfa565b14155b15610e3357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff196001600160401b0384166101008102821668ffffffffffffffffff199093169290921760019081179093555f60088190556009819055600a8054909216909317905560405190917ff48a2acdce0f4a30c2d32425d8827b030bbdff66b7694573d92cdd52b818fd1691a25b50565b610eb384848461069e565b61072633858585856112e8565b6060610ecb826110ca565b505f610ee160408051602081019091525f815290565b90505f815111610eff5760405180602001604052805f815250610f2a565b80610f0984611410565b604051602001610f1a929190611d41565b6040516020818303038152906040525b9392505050565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610f7a57604051636dac6a0960e01b815260040160405180910390fd5b610f826111ad565b6007546001600160401b0384811661010090920416141580610fa2575081155b80610faf57506008548214155b80610fbc57506009548114155b15610fda57604051636dac6a0960e01b815260040160405180910390fd5b600460075460ff166004811115610ff357610ff3611bfa565b1461109357600360075460ff16600481111561101157611011611bfa565b1461102f57604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660041790819055611056906001600160401b036101009091041661149f565b600754604051839161010090046001600160401b0316907f4baa52424160077091b85a05340629c1a44cfac77a87274fad62a384fe6193f0905f90a35b6107d66001600655565b6001600160a01b039182165f90815260056020908152604080832093909416825291909152205460ff1690565b5f818152600260205260408120546001600160a01b03168061056c57604051637e27328960e01b8152600481018490526024016106c3565b6107d683838360016114d7565b6007545f9061010090046001600160401b03168314158061117c5750600260075460ff16600481111561114457611144611bfa565b1415801561117c5750600460075460ff16600481111561116657611166611bfa565b14801561117a57506001600160a01b038416155b155b1561119a57604051636dac6a0960e01b815260040160405180910390fd5b6111a58484846115db565b949350505050565b6002600654036111d057604051633ee5aeb560e01b815260040160405180910390fd5b6002600655565b6001600160a01b03821661120957604051630b61174360e31b81526001600160a01b03831660048201526024016106c3565b6001600160a01b038381165f81815260056020908152604080832094871680845294825291829020805460ff191686151590811790915591519182527f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31910160405180910390a3505050565b604080516001600160a01b0385811660248301528416604482015260648082018490528251808303909101815260849091019091526020810180516001600160e01b03166323b872dd60e01b1790526107269085906116cd565b61069a828260405180602001604052805f815250611739565b6001600160a01b0383163b1561140957604051630a85bd0160e11b81526001600160a01b0384169063150b7a029061132a908890889087908790600401611d6f565b6020604051808303815f875af1925050508015611364575060408051601f3d908101601f1916820190925261136191810190611dab565b60015b6113cb573d808015611391576040519150601f19603f3d011682016040523d82523d5f602084013e611396565b606091505b5080515f036113c357604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b805160208201fd5b6001600160e01b03198116630a85bd0160e11b1461140757604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b505b5050505050565b60605f61141c83611750565b60010190505f816001600160401b0381111561143a5761143a611b0c565b6040519080825280601f01601f191660200182016040528015611464576020820181803683370190505b5090508181016020015b5f19016f181899199a1a9b1b9c1cb0b131b232b360811b600a86061a8153600a850494508461146e57509392505050565b5f6114ab5f835f61110f565b90506001600160a01b03811661069a57604051637e27328960e01b8152600481018390526024016106c3565b80806114eb57506001600160a01b03821615155b156115ac575f6114fa846110ca565b90506001600160a01b038316158015906115265750826001600160a01b0316816001600160a01b031614155b80156115395750611537818461109d565b155b156115625760405163a9fbf51f60e01b81526001600160a01b03841660048201526024016106c3565b81156115aa5783856001600160a01b0316826001600160a01b03167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45b505b50505f90815260046020526040902080546001600160a01b0319166001600160a01b0392909216919091179055565b5f828152600260205260408120546001600160a01b039081169083161561160757611607818486611827565b6001600160a01b03811615611641576116225f855f5f6114d7565b6001600160a01b0381165f90815260036020526040902080545f190190555b6001600160a01b0385161561166f576001600160a01b0385165f908152600360205260409020805460010190555b5f8481526002602052604080822080546001600160a01b0319166001600160a01b0389811691821790925591518793918516917fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef91a4949350505050565b5f5f60205f8451602086015f885af1806116ec576040513d5f823e3d81fd5b50505f513d91508115611703578060011415611710565b6001600160a01b0384163b155b1561072657604051635274afe760e01b81526001600160a01b03851660048201526024016106c3565b611743838361188b565b6107d6335f8585856112e8565b5f8072184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b831061178e5772184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b830492506040015b6d04ee2d6d415b85acef810000000083106117ba576d04ee2d6d415b85acef8100000000830492506020015b662386f26fc1000083106117d857662386f26fc10000830492506010015b6305f5e10083106117f0576305f5e100830492506008015b612710831061180457612710830492506004015b60648310611816576064830492506002015b600a831061056c5760010192915050565b6118328383836118ec565b6107d6576001600160a01b03831661186057604051637e27328960e01b8152600481018290526024016106c3565b60405163177e802f60e01b81526001600160a01b0383166004820152602481018290526044016106c3565b6001600160a01b0382166118b457604051633250574960e11b81525f60048201526024016106c3565b5f6118c083835f61110f565b90506001600160a01b038116156107d6576040516339e3563760e11b81525f60048201526024016106c3565b5f6001600160a01b038316158015906111a55750826001600160a01b0316846001600160a01b031614806119255750611925848461109d565b806111a55750505f908152600460205260409020546001600160a01b03908116911614919050565b6001600160e01b031981168114610ea5575f5ffd5b5f60208284031215611972575f5ffd5b8135610f2a8161194d565b5f5b8381101561199757818101518382015260200161197f565b50505f910152565b5f81518084526119b681602086016020860161197d565b601f01601f19169290920160200192915050565b602081525f610f2a602083018461199f565b5f602082840312156119ec575f5ffd5b5035919050565b80356001600160a01b03811681146109bf575f5ffd5b5f60208284031215611a19575f5ffd5b610f2a826119f3565b5f5f60408385031215611a33575f5ffd5b611a3c836119f3565b946020939093013593505050565b5f5f5f60608486031215611a5c575f5ffd5b611a65846119f3565b9250611a73602085016119f3565b929592945050506040919091013590565b803580151581146109bf575f5ffd5b5f60208284031215611aa3575f5ffd5b610f2a82611a84565b5f5f60408385031215611abd575f5ffd5b611ac6836119f3565b9150611ad460208401611a84565b90509250929050565b80356001600160401b03811681146109bf575f5ffd5b5f60208284031215611b03575f5ffd5b610f2a82611add565b634e487b7160e01b5f52604160045260245ffd5b5f5f5f5f60808587031215611b33575f5ffd5b611b3c856119f3565b9350611b4a602086016119f3565b92506040850135915060608501356001600160401b03811115611b6b575f5ffd5b8501601f81018713611b7b575f5ffd5b80356001600160401b03811115611b9457611b94611b0c565b604051601f8201601f19908116603f011681016001600160401b0381118282101715611bc257611bc2611b0c565b604052818152828201602001891015611bd9575f5ffd5b816020840160208301375f6020838301015280935050505092959194509250565b634e487b7160e01b5f52602160045260245ffd5b6020810160058310611c2e57634e487b7160e01b5f52602160045260245ffd5b91905290565b5f5f5f60608486031215611c46575f5ffd5b611c4f84611add565b95602085013595506040909401359392505050565b5f5f60408385031215611c75575f5ffd5b611c7e836119f3565b9150611ad4602084016119f3565b600181811c90821680611ca057607f821691505b602082108103611cbe57634e487b7160e01b5f52602260045260245ffd5b50919050565b5f60208284031215611cd4575f5ffd5b815160ff81168114610f2a575f5ffd5b5f60208284031215611cf4575f5ffd5b5051919050565b634e487b7160e01b5f52601160045260245ffd5b8082018082111561056c5761056c611cfb565b6001600160401b03818116838216019081111561056c5761056c611cfb565b5f8351611d5281846020880161197d565b835190830190611d6681836020880161197d565b01949350505050565b6001600160a01b03858116825284166020820152604081018390526080606082018190525f90611da19083018461199f565b9695505050505050565b5f60208284031215611dbb575f5ffd5b8151610f2a8161194d56fea26469706673582212205cd0600d0bc59401f6362a6ffeeddd9fccccd322ad458bc4283018628c84b01f64736f6c634300081e0033" } } } };
var Ni = BigInt(x.maxTotalFeeWei);
var h = (t17, e) => {
  if (!t17) throw Error(e);
};
var Ri = new F(x.adapter.abi);
var _i = new F(x.pass.abi);
var o6 = /* @__PURE__ */ new Set(["eth_chainId", "eth_getTransactionCount", "eth_getCode", "eth_getBalance", "eth_gasPrice", "eth_getTransactionByHash", "eth_getTransactionReceipt", "eth_blockNumber", "eth_getBlockByNumber", "eth_estimateGas", "eth_call"]);
function V0(t17) {
  return async (e, n = []) => (h(o6.has(e), "Read operation not allowed."), t17.request({ method: e, params: n }));
}
function f6() {
  h(ie({ from: x.admin, nonce: x.baseNonce }) === x.addresses.adapter && ie({ from: x.admin, nonce: x.baseNonce + 1 }) === x.addresses.pass, "Invalid pinned addresses."), X(x.admin);
}
f6();
var R = { schema: 1, admin: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", adapter: "0x74c20dEB476Dca58459956b1AcD65771197900C9", endpoint: "0x1a44076050125825900e736c501f859c50fe728c", sendLibrary: "0x9f8c645f2d0b2159767bd6e0839de4be49e823de", receiveLibrary: "0xb217266c3a98c8b2709ee26836c98cf12f6ccec1", baseNonce: 4742, maxTotalFeeWei: "100000000000000", gasLimits: [12e4, 14e4, 4e5, 35e4], steps: [{ method: "setSendLibrary", to: "0x1a44076050125825900e736c501f859c50fe728c", value: "0x0", data: "0x9535ff3000000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa0000000000000000000000009f8c645f2d0b2159767bd6e0839de4be49e823de" }, { method: "setReceiveLibrary", to: "0x1a44076050125825900e736c501f859c50fe728c", value: "0x0", data: "0x6a14d71500000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa000000000000000000000000b217266c3a98c8b2709ee26836c98cf12f6ccec10000000000000000000000000000000000000000000000000000000000000000" }, { method: "setConfig", to: "0x1a44076050125825900e736c501f859c50fe728c", value: "0x0", data: "0x6dbd9f9000000000000000000000000074c20deb476dca58459956b1acd65771197900c90000000000000000000000009f8c645f2d0b2159767bd6e0839de4be49e823de000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000027100000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d58485900000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000" }, { method: "setConfig", to: "0x1a44076050125825900e736c501f859c50fe728c", value: "0x0", data: "0x6dbd9f9000000000000000000000000074c20deb476dca58459956b1acd65771197900c9000000000000000000000000b217266c3a98c8b2709ee26836c98cf12f6ccec100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000" }], codeHashes: { "0x1a44076050125825900e736c501f859c50fe728c": "0x5ed1f4ec5f4d6bd5eac1fa92e0fb7474be2607dfc5f3eb82ced1c183b64fbeb9", "0x9f8c645f2d0b2159767bd6e0839de4be49e823de": "0xdd60d5461da3a779567301a7f52c4de2fd7d4c829b3e8de663bb2149be857275", "0xb217266c3a98c8b2709ee26836c98cf12f6ccec1": "0xa24b487071c9c9f0b7d5dc4809c4390f5c921b353047ed7d203af1b0e69c27b2", "0x3ebd570ed38b1b3b4bc886999fcf507e9d584859": "0x389be47b3fd7cf26fb6d72c2454d05589f74d20be8cb09173cd63d40525a8035", "0x247624e2143504730aec22912ed41f092498bef2": "0xd759ad655213af8a91ae58de7d2d6c0572941994d295a162183409e1ac13f8d1", "0x31f748a368a893bdb5abb67ec95f232507601a73": "0xd759ad655213af8a91ae58de7d2d6c0572941994d295a162183409e1ac13f8d1", "0xfd6865c841c2d64565562fcc7e05e619a30615f0": "0xd759ad655213af8a91ae58de7d2d6c0572941994d295a162183409e1ac13f8d1" }, states: [{ defaultSendLibrary: true, rawSendSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", rawReceiveSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", sendLibrary: "0x9F8C645f2D0b2159767Bd6E0839DE4BE49e823DE", receiveLibrary: ["0xB217266c3A98C8B2709Ee26836C98cf12f6cCEC1", true], delegate: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", executor: "0x00000000000000000000000000000000000000000000000000000000000027100000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d584859", sendSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000004000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fa9ba83c102283958b997adc8b44ed3a3cdb5dda000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000", receiveSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000004000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fa9ba83c102283958b997adc8b44ed3a3cdb5dda000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000" }, { defaultSendLibrary: false, rawSendSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", rawReceiveSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", sendLibrary: "0x9F8C645f2D0b2159767Bd6E0839DE4BE49e823DE", receiveLibrary: ["0xB217266c3A98C8B2709Ee26836C98cf12f6cCEC1", true], delegate: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", executor: "0x00000000000000000000000000000000000000000000000000000000000027100000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d584859", sendSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000004000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fa9ba83c102283958b997adc8b44ed3a3cdb5dda000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000", receiveSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000004000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fa9ba83c102283958b997adc8b44ed3a3cdb5dda000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000" }, { defaultSendLibrary: false, rawSendSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", rawReceiveSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", sendLibrary: "0x9F8C645f2D0b2159767Bd6E0839DE4BE49e823DE", receiveLibrary: ["0xB217266c3A98C8B2709Ee26836C98cf12f6cCEC1", false], delegate: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", executor: "0x00000000000000000000000000000000000000000000000000000000000027100000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d584859", sendSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000004000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fa9ba83c102283958b997adc8b44ed3a3cdb5dda000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000", receiveSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000004000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fa9ba83c102283958b997adc8b44ed3a3cdb5dda000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000" }, { defaultSendLibrary: false, rawSendSecurity: "0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000", rawReceiveSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", sendLibrary: "0x9F8C645f2D0b2159767Bd6E0839DE4BE49e823DE", receiveLibrary: ["0xB217266c3A98C8B2709Ee26836C98cf12f6cCEC1", false], delegate: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", executor: "0x00000000000000000000000000000000000000000000000000000000000027100000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d584859", sendSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000", receiveSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000004000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fa9ba83c102283958b997adc8b44ed3a3cdb5dda000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000" }, { defaultSendLibrary: false, rawSendSecurity: "0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000", rawReceiveSecurity: "0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000", sendLibrary: "0x9F8C645f2D0b2159767Bd6E0839DE4BE49e823DE", receiveLibrary: ["0xB217266c3A98C8B2709Ee26836C98cf12f6cCEC1", false], delegate: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", executor: "0x00000000000000000000000000000000000000000000000000000000000027100000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d584859", sendSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000", receiveSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000" }], suiDigest: "6sbCjzYbNLWYBY8QuZjLyKeGnGZjtLUWktmrZZb1fRU8" };
function z0(t17) {
  let e = BigInt(t17), n = [], r = 0;
  if (e === 0n) return [0];
  for (; e > 0; ) n[r] = Number(e & 127n), e >>= 7n, e > 0n && (n[r] |= 128), r += 1;
  return n;
}
function hn(t17) {
  let e = 0n, n = 0n, r = 0;
  for (; ; ) {
    if (r >= t17.length) throw new Error("ULEB decode error: buffer overflow");
    let a = t17[r];
    if (r += 1, e += BigInt(a & 127) << n, !(a & 128)) break;
    n += 7n;
  }
  if (e > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("ULEB decode error: value exceeds MAX_SAFE_INTEGER");
  return { value: Number(e), length: r };
}
var gn = class {
  constructor(t17) {
    this.bytePosition = 0, this.dataView = new DataView(t17.buffer, t17.byteOffset, t17.byteLength);
  }
  shift(t17) {
    return this.bytePosition += t17, this;
  }
  read8() {
    let t17 = this.dataView.getUint8(this.bytePosition);
    return this.shift(1), t17;
  }
  read16() {
    let t17 = this.dataView.getUint16(this.bytePosition, true);
    return this.shift(2), t17;
  }
  read32() {
    let t17 = this.dataView.getUint32(this.bytePosition, true);
    return this.shift(4), t17;
  }
  read64() {
    let t17 = this.read32(), e = this.read32().toString(16) + t17.toString(16).padStart(8, "0");
    return BigInt("0x" + e).toString(10);
  }
  read128() {
    let t17 = BigInt(this.read64()), e = BigInt(this.read64()).toString(16) + t17.toString(16).padStart(16, "0");
    return BigInt("0x" + e).toString(10);
  }
  read256() {
    let t17 = BigInt(this.read128()), e = BigInt(this.read128()).toString(16) + t17.toString(16).padStart(32, "0");
    return BigInt("0x" + e).toString(10);
  }
  readBytes(t17) {
    let e = this.bytePosition + this.dataView.byteOffset, n = new Uint8Array(this.dataView.buffer, e, t17);
    return this.shift(t17), n;
  }
  readULEB() {
    let t17 = this.bytePosition + this.dataView.byteOffset, { value: e, length: n } = hn(new Uint8Array(this.dataView.buffer, t17));
    return this.shift(n), e;
  }
  readVec(t17) {
    let e = this.readULEB(), n = [];
    for (let r = 0; r < e; r++) n.push(t17(this, r, e));
    return n;
  }
};
var d6 = (t17) => Object.freeze(t17());
function u6(t17) {
  return t17 instanceof Uint8Array || ArrayBuffer.isView(t17) && t17.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in t17 && t17.BYTES_PER_ELEMENT === 1;
}
function mn(t17) {
  if (!u6(t17)) throw new TypeError("Uint8Array expected");
}
function b6(t17, e) {
  if (typeof e != "string") throw new TypeError(`${t17}: string expected`);
  return true;
}
function l6(...t17) {
  let e = (s) => s, n = (s, o) => (f) => s(o(f)), r = t17.map((s) => s.encode).reduceRight(n, e), a = t17.map((s) => s.decode).reduce(n, e);
  return { encode: r, decode: a };
}
var yn = (() => {
  try {
    let t17 = new TextDecoder();
    return t17.decode(Uint8Array.of(65, 48, 43, 127)) === "A0+\x7F" ? t17 : void 0;
  } catch {
    return;
  }
})();
var lt = 8192;
function p6(t17) {
  let e = t17.length;
  if (yn !== void 0 && e >= 12) return yn.decode(t17);
  if (e <= lt) return String.fromCharCode.apply(null, t17);
  let n = "";
  for (let r = 0; r < e; r += lt) n += String.fromCharCode.apply(null, t17.subarray(r, r + lt));
  return n;
}
function h6(t17, e) {
  let n = t17.length;
  if (n > 128) throw new Error("alphabet: max 128 letters");
  let r = new Uint8Array(n), a = new Int8Array(128).fill(-1);
  for (let s = 0; s < n; s++) {
    let o = t17.charCodeAt(s);
    if (t17.codePointAt(s) !== o || o > 127) throw new Error("alphabet: single-char ASCII letters only");
    r[s] = o, a[o] = s;
  }
  if (e !== void 0) for (let s of Object.keys(e)) {
    let o = s.charCodeAt(0), f = a[e[s].charCodeAt(0)];
    if (s.length !== 1 || o > 127 || f === void 0 || f === -1) throw new Error(`alphabet: invalid alias ${s}`);
    a[o] = f;
  }
  return { encode: (s) => {
    let o = new Uint8Array(s.length);
    for (let f = 0; f < s.length; f++) {
      let c = s[f], d = r[c];
      if (d === void 0) throw new Error(`alphabet.encode: invalid digit ${c}`);
      o[f] = d;
    }
    return p6(o);
  }, decode: (s) => {
    b6("decode", s);
    let o = s.length, f = new Uint8Array(o);
    for (let c = 0; c < o; c++) {
      let d = s.charCodeAt(c), u = d < 128 ? a[d] : -1;
      if (u === -1) throw new Error(`Unknown letter "${s[c]}". Allowed: ${t17}`);
      f[c] = u;
    }
    return f;
  } };
}
var xn = 656356768;
var g6 = { encode: (t17) => {
  mn(t17);
  let e = t17.length;
  if (e === 0) return new Uint8Array(0);
  let n = 0;
  for (; n < e - 1 && t17[n] === 0; ) n++;
  let r = Math.ceil(e / 2), a = new Uint16Array(r), s = e & 1;
  s && (a[0] = t17[0]);
  for (let p = s, m = s; p < e; p += 2, m++) a[m] = t17[p] << 8 | t17[p + 1];
  let o = [], f = 0;
  for (; f < r; ) {
    let p = 0;
    for (let m = f; m < r; m++) {
      let E = p * 65536 + a[m], S = Math.floor(E / xn);
      p = E - S * xn, a[m] = S, S === 0 && m === f && f++;
    }
    o.push(p);
  }
  let c = o.length - 1, d = c * 5;
  for (let p = o[c]; d++, !(p < 58); p = Math.floor(p / 58)) ;
  let u = new Uint8Array(n + d), g = u.length - 1;
  for (let p = 0; p < c; p++) {
    let m = o[p];
    for (let E = 0; E < 5; E++) u[g--] = m % 58, m = Math.floor(m / 58);
  }
  for (let p = o[c]; g >= n; p = Math.floor(p / 58)) u[g--] = p % 58;
  return u;
}, decode: (t17) => {
  mn(t17);
  let e = t17.length;
  if (e === 0) return new Uint8Array(0);
  if (e >= 65536) throw new Error("invalid length");
  let n = 0;
  for (; n < e - 1 && t17[n] === 0; ) n++;
  let r = new Uint16Array(Math.ceil(e * 6 / 16) + 1), a = 0, s = 0, o = e % 5 || 5;
  for (; s < e; ) {
    let u = 0, g = 1;
    for (let m = s + o; s < m; s++) {
      let E = t17[s];
      if (E >= 58) throw new Error(`invalid integer: ${E}`);
      u = u * 58 + E, g *= 58;
    }
    o = 5;
    let p = u;
    for (let m = 0; m < a; m++) {
      let E = r[m] * g + p;
      p = Math.floor(E / 65536), r[m] = E - p * 65536;
    }
    for (; p > 0; p = Math.floor(p / 65536)) r[a++] = p % 65536;
  }
  let f = a === 0 ? 1 : a * 2 - (r[a - 1] < 256 ? 1 : 0), c = new Uint8Array(n + f), d = c.length - 1;
  for (let u = 0; u < a; u++) {
    let g = r[u];
    c[d--] = g & 255, d >= n && (c[d--] = g >> 8);
  }
  return c;
} };
var m6 = (t17) => l6(g6, h6(t17));
var pt = d6(() => m6("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"));
var P0 = (t17) => pt.encode(t17);
var N0 = (t17) => pt.decode(t17);
function p0(t17) {
  return Uint8Array.from(atob(t17), (e) => e.charCodeAt(0));
}
var ht = 8192;
function f0(t17) {
  if (t17.length < ht) return btoa(String.fromCharCode(...t17));
  let e = "";
  for (var n = 0; n < t17.length; n += ht) {
    let r = t17.slice(n, n + ht);
    e += String.fromCharCode(...r);
  }
  return btoa(e);
}
function $0(t17) {
  let e = t17.startsWith("0x") ? t17.slice(2) : t17, n = e.length % 2 === 0 ? e : `0${e}`, r = n.match(/[0-9a-fA-F]{2}/g)?.map((a) => parseInt(a, 16)) ?? [];
  if (r.length !== n.length / 2) throw new Error(`Invalid hex string ${t17}`);
  return Uint8Array.from(r);
}
function c0(t17) {
  return t17.reduce((e, n) => e + n.toString(16).padStart(2, "0"), "");
}
function gt(t17, e) {
  switch (e) {
    case "base58":
      return P0(t17);
    case "base64":
      return f0(t17);
    case "hex":
      return c0(t17);
    default:
      throw new Error("Unsupported encoding, supported values are: base64, hex");
  }
}
function mt(t17, e = ["<", ">"]) {
  let [n, r] = e, a = [], s = "", o = 0;
  for (let f = 0; f < t17.length; f++) {
    let c = t17[f];
    if (c === n && o++, c === r && o--, o === 0 && c === ",") {
      a.push(s.trim()), s = "";
      continue;
    }
    s += c;
  }
  return a.push(s.trim()), a;
}
var wn = class {
  constructor({ initialSize: t17 = 1024, maxSize: e = 1 / 0, allocateSize: n = 1024 } = {}) {
    this.bytePosition = 0, this.size = t17, this.maxSize = e, this.allocateSize = n, this.dataView = new DataView(new ArrayBuffer(t17));
  }
  ensureSizeOrGrow(t17) {
    let e = this.bytePosition + t17;
    if (e > this.size) {
      let n = Math.min(this.maxSize, Math.max(this.size + e, this.size + this.allocateSize));
      if (e > n) throw new Error(`Attempting to serialize to BCS, but buffer does not have enough size. Allocated size: ${this.size}, Max size: ${this.maxSize}, Required size: ${e}`);
      this.size = n;
      let r = new ArrayBuffer(this.size);
      new Uint8Array(r).set(new Uint8Array(this.dataView.buffer)), this.dataView = new DataView(r);
    }
  }
  shift(t17) {
    return this.bytePosition += t17, this;
  }
  write8(t17) {
    return this.ensureSizeOrGrow(1), this.dataView.setUint8(this.bytePosition, Number(t17)), this.shift(1);
  }
  writeBytes(t17) {
    this.ensureSizeOrGrow(t17.length);
    for (let e = 0; e < t17.length; e++) this.dataView.setUint8(this.bytePosition + e, t17[e]);
    return this.shift(t17.length);
  }
  write16(t17) {
    return this.ensureSizeOrGrow(2), this.dataView.setUint16(this.bytePosition, Number(t17), true), this.shift(2);
  }
  write32(t17) {
    return this.ensureSizeOrGrow(4), this.dataView.setUint32(this.bytePosition, Number(t17), true), this.shift(4);
  }
  write64(t17) {
    return yt(BigInt(t17), 8).forEach((e) => this.write8(e)), this;
  }
  write128(t17) {
    return yt(BigInt(t17), 16).forEach((e) => this.write8(e)), this;
  }
  write256(t17) {
    return yt(BigInt(t17), 32).forEach((e) => this.write8(e)), this;
  }
  writeULEB(t17) {
    return z0(t17).forEach((e) => this.write8(e)), this;
  }
  writeVec(t17, e) {
    return this.writeULEB(t17.length), Array.from(t17).forEach((n, r) => e(this, n, r, t17.length)), this;
  }
  *[Symbol.iterator]() {
    for (let t17 = 0; t17 < this.bytePosition; t17++) yield this.dataView.getUint8(t17);
    return this.toBytes();
  }
  toBytes() {
    return new Uint8Array(this.dataView.buffer.slice(0, this.bytePosition));
  }
  toString(t17) {
    return gt(this.toBytes(), t17);
  }
};
function yt(t17, e) {
  let n = new Uint8Array(e), r = 0;
  for (; t17 > 0; ) n[r] = Number(t17 % BigInt(256)), t17 = t17 / BigInt(256), r += 1;
  return n;
}
var Y = class En {
  #e;
  #t;
  constructor(e) {
    this.name = e.name, this.read = e.read, this.serializedSize = e.serializedSize ?? (() => null), this.#e = e.write, this.#t = e.serialize ?? ((n, r) => {
      let a = new wn({ initialSize: this.serializedSize(n) ?? void 0, ...r });
      return this.#e(n, a), a.toBytes();
    }), this.validate = e.validate ?? (() => {
    });
  }
  write(e, n) {
    this.validate(e), this.#e(e, n);
  }
  serialize(e, n) {
    return this.validate(e), new x6(this, this.#t(e, n));
  }
  parse(e) {
    let n = new gn(e);
    return this.read(n);
  }
  fromHex(e) {
    return this.parse($0(e));
  }
  fromBase58(e) {
    return this.parse(N0(e));
  }
  fromBase64(e) {
    return this.parse(p0(e));
  }
  transform({ name: e, input: n, output: r, validate: a }) {
    return new En({ name: e ?? this.name, read: (s) => r ? r(this.read(s)) : this.read(s), write: (s, o) => this.#e(n ? n(s) : s, o), serializedSize: (s) => this.serializedSize(n ? n(s) : s), serialize: (s, o) => this.#t(n ? n(s) : s, o), validate: (s) => {
      a?.(s), this.validate(n ? n(s) : s);
    } });
  }
};
var y6 = /* @__PURE__ */ Symbol.for("@mysten/serialized-bcs");
var x6 = class {
  #e;
  #t;
  get [y6]() {
    return true;
  }
  constructor(t17, e) {
    this.#e = t17, this.#t = e;
  }
  toBytes() {
    return this.#t;
  }
  toHex() {
    return c0(this.#t);
  }
  toBase64() {
    return f0(this.#t);
  }
  toBase58() {
    return P0(this.#t);
  }
  parse() {
    return this.#e.parse(this.#t);
  }
};
function le({ size: t17, ...e }) {
  return new Y({ ...e, serializedSize: () => t17 });
}
function Le({ readMethod: t17, writeMethod: e, ...n }) {
  return le({ ...n, read: (r) => r[t17](), write: (r, a) => a[e](r), validate: (r) => {
    if (r < 0 || r > n.maxValue) throw new TypeError(`Invalid ${n.name} value: ${r}. Expected value in range 0-${n.maxValue}`);
    n.validate?.(r);
  } });
}
function Me({ readMethod: t17, writeMethod: e, ...n }) {
  return le({ ...n, read: (r) => r[t17](), write: (r, a) => a[e](BigInt(r)), validate: (r) => {
    let a = BigInt(r);
    if (a < 0 || a > n.maxValue) throw new TypeError(`Invalid ${n.name} value: ${a}. Expected value in range 0-${n.maxValue}`);
    n.validate?.(a);
  } });
}
function vn({ serialize: t17, ...e }) {
  let n = new Y({ ...e, serialize: t17, write: (r, a) => {
    for (let s of n.serialize(r).toBytes()) a.write8(s);
  } });
  return n;
}
function Sn({ toBytes: t17, fromBytes: e, ...n }) {
  return new Y({ ...n, read: (r) => {
    let a = r.readULEB();
    return e(r.readBytes(a));
  }, write: (r, a) => {
    let s = t17(r);
    a.writeULEB(s.length);
    for (let o = 0; o < s.length; o++) a.write8(s[o]);
  }, serialize: (r) => {
    let a = t17(r), s = z0(a.length), o = new Uint8Array(s.length + a.length);
    return o.set(s, 0), o.set(a, s.length), o;
  }, validate: (r) => {
    if (typeof r != "string") throw new TypeError(`Invalid ${n.name} value: ${r}. Expected string`);
    n.validate?.(r);
  } });
}
function Bn(t17) {
  let e = null;
  function n() {
    return e || (e = t17()), e;
  }
  return new Y({ name: "lazy", read: (r) => n().read(r), serializedSize: (r) => n().serializedSize(r), write: (r, a) => n().write(r, a), serialize: (r, a) => n().serialize(r, a).toBytes() });
}
var xt = class extends Y {
  constructor({ name: t17, fields: e, ...n }) {
    let r = Object.entries(e);
    super({ name: t17, serializedSize: (a) => {
      let s = 0;
      for (let [o, f] of r) {
        let c = f.serializedSize(a[o]);
        if (c == null) return null;
        s += c;
      }
      return s;
    }, read: (a) => {
      let s = {};
      for (let [o, f] of r) s[o] = f.read(a);
      return s;
    }, write: (a, s) => {
      for (let [o, f] of r) f.write(a[o], s);
    }, ...n, validate: (a) => {
      if (n?.validate?.(a), typeof a != "object" || a == null) throw new TypeError(`Expected object, found ${typeof a}`);
    } });
  }
};
var wt = class extends Y {
  constructor({ fields: t17, ...e }) {
    let n = Object.entries(t17);
    super({ read: (r) => {
      let a = r.readULEB(), s = n[a];
      if (!s) throw new TypeError(`Unknown value ${a} for enum ${e.name}`);
      let [o, f] = s;
      return { [o]: f?.read(r) ?? true, $kind: o };
    }, write: (r, a) => {
      let [s, o] = Object.entries(r).filter(([f]) => Object.hasOwn(t17, f))[0];
      for (let f = 0; f < n.length; f++) {
        let [c, d] = n[f];
        if (c === s) {
          a.writeULEB(f), d?.write(o, a);
          return;
        }
      }
    }, ...e, validate: (r) => {
      if (e?.validate?.(r), typeof r != "object" || r == null) throw new TypeError(`Expected object, found ${typeof r}`);
      let a = Object.keys(r).filter((o) => r[o] !== void 0 && Object.hasOwn(t17, o));
      if (a.length !== 1) throw new TypeError(`Expected object with one key, but found ${a.length} for type ${e.name}}`);
      let [s] = a;
      if (!Object.hasOwn(t17, s)) throw new TypeError(`Invalid enum variant ${s}`);
    } });
  }
};
var Et = class extends Y {
  constructor({ fields: t17, name: e, ...n }) {
    super({ name: e ?? `(${t17.map((r) => r.name).join(", ")})`, serializedSize: (r) => {
      let a = 0;
      for (let s = 0; s < t17.length; s++) {
        let o = t17[s].serializedSize(r[s]);
        if (o == null) return null;
        a += o;
      }
      return a;
    }, read: (r) => {
      let a = [];
      for (let s of t17) a.push(s.read(r));
      return a;
    }, write: (r, a) => {
      for (let s = 0; s < t17.length; s++) t17[s].write(r[s], a);
    }, ...n, validate: (r) => {
      if (n?.validate?.(r), !Array.isArray(r)) throw new TypeError(`Expected array, found ${typeof r}`);
      if (r.length !== t17.length) throw new TypeError(`Expected array of length ${t17.length}, found ${r.length}`);
    } });
  }
};
function w6(t17, e, n) {
  return new Y({ read: (r) => {
    let a = new Array(t17);
    for (let s = 0; s < t17; s++) a[s] = e.read(r);
    return a;
  }, write: (r, a) => {
    for (let s of r) e.write(s, a);
  }, ...n, name: n?.name ?? `${e.name}[${t17}]`, validate: (r) => {
    if (n?.validate?.(r), !r || typeof r != "object" || !("length" in r)) throw new TypeError(`Expected array, found ${typeof r}`);
    if (r.length !== t17) throw new TypeError(`Expected array of length ${t17}, found ${r.length}`);
  } });
}
function E6(t17) {
  return i.enum(`Option<${t17.name}>`, { None: null, Some: t17 }).transform({ input: (e) => e == null ? { None: true } : { Some: e }, output: (e) => e.$kind === "Some" ? e.Some : null });
}
function v6(t17, e) {
  return new Y({ read: (n) => {
    let r = n.readULEB(), a = new Array(r);
    for (let s = 0; s < r; s++) a[s] = t17.read(n);
    return a;
  }, write: (n, r) => {
    r.writeULEB(n.length);
    for (let a of n) t17.write(a, r);
  }, ...e, name: e?.name ?? `vector<${t17.name}>`, validate: (n) => {
    if (e?.validate?.(n), !n || typeof n != "object" || !("length" in n)) throw new TypeError(`Expected array, found ${typeof n}`);
  } });
}
function vt(t17, e) {
  for (let n = 0; n < Math.min(t17.length, e.length); n++) if (t17[n] !== e[n]) return t17[n] - e[n];
  return t17.length - e.length;
}
function S6(t17, e) {
  return new Y({ name: `Map<${t17.name}, ${e.name}>`, read: (n) => {
    let r = n.readULEB(), a = /* @__PURE__ */ new Map();
    for (let s = 0; s < r; s++) a.set(t17.read(n), e.read(n));
    return a;
  }, write: (n, r) => {
    let a = [...n.entries()].map(([s, o]) => [t17.serialize(s).toBytes(), o]);
    a.sort(([s], [o]) => vt(s, o)), r.writeULEB(a.length);
    for (let [s, o] of a) r.writeBytes(s), e.write(o, r);
  } });
}
var i = { u8(t17) {
  return Le({ readMethod: "read8", writeMethod: "write8", size: 1, maxValue: 2 ** 8 - 1, ...t17, name: t17?.name ?? "u8" });
}, u16(t17) {
  return Le({ readMethod: "read16", writeMethod: "write16", size: 2, maxValue: 2 ** 16 - 1, ...t17, name: t17?.name ?? "u16" });
}, u32(t17) {
  return Le({ readMethod: "read32", writeMethod: "write32", size: 4, maxValue: 2 ** 32 - 1, ...t17, name: t17?.name ?? "u32" });
}, u64(t17) {
  return Me({ readMethod: "read64", writeMethod: "write64", size: 8, maxValue: 2n ** 64n - 1n, ...t17, name: t17?.name ?? "u64" });
}, u128(t17) {
  return Me({ readMethod: "read128", writeMethod: "write128", size: 16, maxValue: 2n ** 128n - 1n, ...t17, name: t17?.name ?? "u128" });
}, u256(t17) {
  return Me({ readMethod: "read256", writeMethod: "write256", size: 32, maxValue: 2n ** 256n - 1n, ...t17, name: t17?.name ?? "u256" });
}, bool(t17) {
  return le({ size: 1, read: (e) => e.read8() === 1, write: (e, n) => n.write8(e ? 1 : 0), ...t17, name: t17?.name ?? "bool", validate: (e) => {
    if (t17?.validate?.(e), typeof e != "boolean") throw new TypeError(`Expected boolean, found ${typeof e}`);
  } });
}, uleb128(t17) {
  return vn({ read: (e) => e.readULEB(), serialize: (e) => Uint8Array.from(z0(e)), ...t17, name: t17?.name ?? "uleb128" });
}, bytes(t17, e) {
  return le({ size: t17, read: (n) => n.readBytes(t17), write: (n, r) => {
    r.writeBytes(new Uint8Array(n));
  }, ...e, name: e?.name ?? `bytes[${t17}]`, validate: (n) => {
    if (e?.validate?.(n), !n || typeof n != "object" || !("length" in n)) throw new TypeError(`Expected array, found ${typeof n}`);
    if (n.length !== t17) throw new TypeError(`Expected array of length ${t17}, found ${n.length}`);
  } });
}, byteVector(t17) {
  return new Y({ read: (e) => {
    let n = e.readULEB();
    return e.readBytes(n);
  }, write: (e, n) => {
    let r = new Uint8Array(e);
    n.writeULEB(r.length), n.writeBytes(r);
  }, ...t17, name: t17?.name ?? "vector<u8>", serializedSize: (e) => {
    let n = "length" in e ? e.length : null;
    return n == null ? null : z0(n).length + n;
  }, validate: (e) => {
    if (t17?.validate?.(e), !e || typeof e != "object" || !("length" in e)) throw new TypeError(`Expected array, found ${typeof e}`);
  } });
}, string(t17) {
  return Sn({ toBytes: (e) => new TextEncoder().encode(e), fromBytes: (e) => new TextDecoder().decode(e), ...t17, name: t17?.name ?? "string" });
}, fixedArray: w6, option: E6, vector: v6, tuple(t17, e) {
  return new Et({ fields: t17, ...e });
}, struct(t17, e, n) {
  return new xt({ name: t17, fields: e, ...n });
}, enum(t17, e, n) {
  return new wt({ name: t17, fields: e, ...n });
}, map: S6, lazy(t17) {
  return Bn(t17);
} };
var Ve = 32;
function In(t17) {
  return B6(t17) && I6(t17) === Ve;
}
function Z0(t17, e = false) {
  let n = t17.toLowerCase();
  return !e && n.startsWith("0x") && (n = n.slice(2)), `0x${n.padStart(Ve * 2, "0")}`;
}
function B6(t17) {
  return /^(0x|0X)?[a-fA-F0-9]+$/.test(t17) && t17.length % 2 === 0;
}
function I6(t17) {
  return /^(0x|0X)/.test(t17) ? (t17.length - 2) / 2 : t17.length / 2;
}
var T6 = /^vector<(.+)>$/;
var A6 = /^([^:]+)::([^:]+)::([^<]+)(<(.+)>)?/;
var St = class Y0 {
  static parseFromStr(e, n = false) {
    if (e === "address") return { address: null };
    if (e === "bool") return { bool: null };
    if (e === "u8") return { u8: null };
    if (e === "u16") return { u16: null };
    if (e === "u32") return { u32: null };
    if (e === "u64") return { u64: null };
    if (e === "u128") return { u128: null };
    if (e === "u256") return { u256: null };
    if (e === "signer") return { signer: null };
    let r = e.match(T6);
    if (r) return { vector: Y0.parseFromStr(r[1], n) };
    let a = e.match(A6);
    if (a) return { struct: { address: n ? Z0(a[1]) : a[1], module: a[2], name: a[3], typeParams: a[5] === void 0 ? [] : Y0.parseStructTypeArgs(a[5], n) } };
    throw new Error(`Encountered unexpected token when parsing type args for ${e}`);
  }
  static parseStructTypeArgs(e, n = false) {
    return mt(e).map((r) => Y0.parseFromStr(r, n));
  }
  static tagToString(e) {
    if ("bool" in e) return "bool";
    if ("u8" in e) return "u8";
    if ("u16" in e) return "u16";
    if ("u32" in e) return "u32";
    if ("u64" in e) return "u64";
    if ("u128" in e) return "u128";
    if ("u256" in e) return "u256";
    if ("address" in e) return "address";
    if ("signer" in e) return "signer";
    if ("vector" in e) return `vector<${Y0.tagToString(e.vector)}>`;
    if ("struct" in e) {
      let n = e.struct, r = n.typeParams.map(Y0.tagToString).join(", ");
      return `${n.address}::${n.module}::${n.name}${r ? `<${r}>` : ""}`;
    }
    throw new Error("Invalid TypeTag");
  }
};
function k6(t17) {
  return i.u64({ name: "unsafe_u64", ...t17 }).transform({ input: (e) => e, output: (e) => Number(e) });
}
function C6(t17) {
  return i.enum("Option", { None: null, Some: t17 });
}
var v = i.bytes(Ve).transform({ validate: (t17) => {
  let e = typeof t17 == "string" ? t17 : c0(t17);
  if (!e || !In(Z0(e))) throw new Error(`Invalid Sui address ${e}`);
}, input: (t17) => typeof t17 == "string" ? $0(Z0(t17)) : t17, output: (t17) => Z0(c0(t17)) });
var O = i.byteVector().transform({ name: "ObjectDigest", input: (t17) => N0(t17), output: (t17) => P0(new Uint8Array(t17)), validate: (t17) => {
  if (N0(t17).length !== 32) throw new Error("ObjectDigest must be 32 bytes");
} });
var q = i.struct("SuiObjectRef", { objectId: v, version: i.u64(), digest: O });
var Bt = i.struct("SharedObjectRef", { objectId: v, initialSharedVersion: i.u64(), mutable: i.bool() });
var It = i.enum("ObjectArg", { ImmOrOwnedObject: q, SharedObject: Bt, Receiving: q });
var t0 = i.enum("Owner", { AddressOwner: v, ObjectOwner: v, Shared: i.struct("Shared", { initialSharedVersion: i.u64() }), Immutable: null, ConsensusAddressOwner: i.struct("ConsensusAddressOwner", { startVersion: i.u64(), owner: v }) });
var O6 = i.enum("Reservation", { MaxAmountU64: i.u64() });
var P6 = i.enum("WithdrawalType", { Balance: i.lazy(() => h0) });
var N6 = i.enum("WithdrawFrom", { Sender: null, Sponsor: null });
var R6 = i.struct("FundsWithdrawal", { reservation: O6, typeArg: P6, withdrawFrom: N6 });
var Tt = i.enum("CallArg", { Pure: i.struct("Pure", { bytes: i.byteVector().transform({ input: (t17) => typeof t17 == "string" ? p0(t17) : t17, output: (t17) => f0(new Uint8Array(t17)) }) }), Object: It, FundsWithdrawal: R6 });
var At = i.enum("TypeTag", { bool: null, u8: null, u64: null, u128: null, address: null, signer: null, vector: i.lazy(() => At), struct: i.lazy(() => $e), u16: null, u32: null, u256: null });
var h0 = At.transform({ input: (t17) => typeof t17 == "string" ? St.parseFromStr(t17, true) : t17, output: (t17) => St.tagToString(t17) });
var d0 = i.enum("Argument", { GasCoin: null, Input: i.u16(), Result: i.u16(), NestedResult: i.tuple([i.u16(), i.u16()]) });
var kt = i.struct("ProgrammableMoveCall", { package: v, module: i.string(), function: i.string(), typeArguments: i.vector(h0), arguments: i.vector(d0) });
var Ct = i.enum("Command", { MoveCall: kt, TransferObjects: i.struct("TransferObjects", { objects: i.vector(d0), address: d0 }), SplitCoins: i.struct("SplitCoins", { coin: d0, amounts: i.vector(d0) }), MergeCoins: i.struct("MergeCoins", { destination: d0, sources: i.vector(d0) }), Publish: i.struct("Publish", { modules: i.vector(i.byteVector().transform({ input: (t17) => typeof t17 == "string" ? p0(t17) : t17, output: (t17) => f0(new Uint8Array(t17)) })), dependencies: i.vector(v) }), MakeMoveVec: i.struct("MakeMoveVec", { type: C6(h0).transform({ input: (t17) => t17 === null ? { None: true } : { Some: t17 }, output: (t17) => t17.Some ?? null }), elements: i.vector(d0) }), Upgrade: i.struct("Upgrade", { modules: i.vector(i.byteVector().transform({ input: (t17) => typeof t17 == "string" ? p0(t17) : t17, output: (t17) => f0(new Uint8Array(t17)) })), dependencies: i.vector(v), package: v, ticket: d0 }) });
var pe = i.struct("ProgrammableTransaction", { inputs: i.vector(Tt), commands: i.vector(Ct) });
var _6 = i.struct("ValidDuring", { minEpoch: i.option(i.u64()), maxEpoch: i.option(i.u64()), minTimestamp: i.option(i.u64()), maxTimestamp: i.option(i.u64()), chain: O, nonce: i.u32() });
var ze = i.enum("TransactionExpiration", { None: null, Epoch: k6(), ValidDuring: _6 });
var $e = i.struct("StructTag", { address: v, module: i.string(), name: i.string(), typeParams: i.vector(At) });
var je = i.struct("GasData", { payment: i.vector(q), owner: v, price: i.u64(), budget: i.u64() });
var Ot = i.enum("IntentScope", { TransactionData: null, TransactionEffects: null, CheckpointSummary: null, PersonalMessage: null });
var Pt = i.enum("IntentVersion", { V0: null });
var Nt = i.enum("AppId", { Sui: null });
var Rt = i.struct("Intent", { scope: Ot, version: Pt, appId: Nt });
function He(t17) {
  return i.struct(`IntentMessage<${t17.name}>`, { intent: Rt, value: t17 });
}
var _t = i.enum("CompressedSignature", { ED25519: i.bytes(64), Secp256k1: i.bytes(64), Secp256r1: i.bytes(64), ZkLogin: i.byteVector(), Passkey: i.byteVector() });
var Ut = i.enum("PublicKey", { ED25519: i.bytes(32), Secp256k1: i.bytes(33), Secp256r1: i.bytes(33), ZkLogin: i.byteVector(), Passkey: i.bytes(33) });
var Dt = i.struct("MultiSigPkMap", { pubKey: Ut, weight: i.u8() });
var Ft = i.struct("MultiSigPublicKey", { pk_map: i.vector(Dt), threshold: i.u16() });
var Tn = i.struct("MultiSig", { sigs: i.vector(_t), bitmap: i.u16(), multisig_pk: Ft });
var An = i.byteVector().transform({ input: (t17) => typeof t17 == "string" ? p0(t17) : t17, output: (t17) => f0(new Uint8Array(t17)) });
var kn = i.struct("PasskeyAuthenticator", { authenticatorData: i.byteVector(), clientDataJson: i.string(), userSignature: i.byteVector() });
var Lt = i.enum("MoveObjectType", { Other: $e, GasCoin: null, StakedSui: null, Coin: h0, AccumulatorBalanceWrapper: null });
var Mt = i.struct("TypeOrigin", { moduleName: i.string(), datatypeName: i.string(), package: v });
var Vt = i.struct("UpgradeInfo", { upgradedId: v, upgradedVersion: i.u64() });
var zt = i.struct("MovePackage", { id: v, version: i.u64(), moduleMap: i.map(i.string(), i.byteVector()), typeOriginTable: i.vector(Mt), linkageTable: i.map(v, Vt) });
var $t = i.struct("MoveObject", { type: Lt, hasPublicTransfer: i.bool(), version: i.u64(), contents: i.byteVector() });
var he = i.enum("Data", { Move: $t, Package: zt });
var Cn = i.struct("ObjectInner", { data: he, owner: t0, previousTransaction: O, storageRebate: i.u64() });
var On = i.struct("ChangeEpoch", { epoch: i.u64(), protocolVersion: i.u64(), storageCharge: i.u64(), computationCharge: i.u64(), storageRebate: i.u64(), nonRefundableStorageFee: i.u64(), epochStartTimestampMs: i.u64(), systemPackages: i.vector(i.tuple([i.u64(), i.vector(i.byteVector()), i.vector(v)])) });
var U6 = i.enum("GenesisObject", { RawObject: i.struct("RawObject", { data: he, owner: t0 }) });
var D6 = i.struct("GenesisTransaction", { objects: i.vector(U6) });
var F6 = i.struct("ConsensusCommitPrologue", { epoch: i.u64(), round: i.u64(), commitTimestampMs: i.u64() });
var L6 = i.struct("ConsensusCommitPrologueV2", { epoch: i.u64(), round: i.u64(), commitTimestampMs: i.u64(), consensusCommitDigest: O });
var Pn = i.enum("ConsensusDeterminedVersionAssignments", { CancelledTransactions: i.vector(i.tuple([O, i.vector(i.tuple([v, i.u64()]))])), CancelledTransactionsV2: i.vector(i.tuple([O, i.vector(i.tuple([i.tuple([v, i.u64()]), i.u64()]))])) });
var M6 = i.struct("ConsensusCommitPrologueV3", { epoch: i.u64(), round: i.u64(), subDagIndex: i.option(i.u64()), commitTimestampMs: i.u64(), consensusCommitDigest: O, consensusDeterminedVersionAssignments: Pn });
var V6 = i.struct("ConsensusCommitPrologueV4", { epoch: i.u64(), round: i.u64(), subDagIndex: i.option(i.u64()), commitTimestampMs: i.u64(), consensusCommitDigest: O, consensusDeterminedVersionAssignments: Pn, additionalStateDigest: O });
var z6 = i.struct("ActiveJwk", { jwkId: i.struct("JwkId", { iss: i.string(), kid: i.string() }), jwk: i.struct("JWK", { kty: i.string(), e: i.string(), n: i.string(), alg: i.string() }), epoch: i.u64() });
var $6 = i.struct("AuthenticatorStateUpdate", { epoch: i.u64(), round: i.u64(), newActiveJwks: i.vector(z6), authenticatorObjInitialSharedVersion: i.u64() });
var j6 = i.struct("RandomnessStateUpdate", { epoch: i.u64(), randomnessRound: i.u64(), randomBytes: i.byteVector(), randomnessObjInitialSharedVersion: i.u64() });
var H6 = i.struct("AuthenticatorStateExpire", { minEpoch: i.u64(), authenticatorObjInitialSharedVersion: i.u64() });
var W6 = i.enum("ExecutionTimeObservationKey", { MoveEntryPoint: i.struct("MoveEntryPoint", { package: v, module: i.string(), function: i.string(), typeArguments: i.vector(h0) }), TransferObjects: null, SplitCoins: null, MergeCoins: null, Publish: null, MakeMoveVec: null, Upgrade: null });
var G6 = i.enum("StoredExecutionTimeObservations", { V1: i.vector(i.tuple([W6, i.vector(i.tuple([i.byteVector(), i.struct("Duration", { secs: i.u64(), nanos: i.u32() })]))])) });
var q6 = i.struct("WriteAccumulatorStorageCost", { storageCost: i.u64() });
var K6 = i.enum("EndOfEpochTransactionKind", { ChangeEpoch: On, AuthenticatorStateCreate: null, AuthenticatorStateExpire: H6, RandomnessStateCreate: null, DenyListStateCreate: null, BridgeStateCreate: O, BridgeCommitteeInit: i.u64(), StoreExecutionTimeObservations: G6, AccumulatorRootCreate: null, CoinRegistryCreate: null, DisplayRegistryCreate: null, AddressAliasStateCreate: null, WriteAccumulatorStorageCost: q6 });
var jt = i.enum("TransactionKind", { ProgrammableTransaction: pe, ChangeEpoch: On, Genesis: D6, ConsensusCommitPrologue: F6, AuthenticatorStateUpdate: $6, EndOfEpochTransaction: i.vector(K6), RandomnessStateUpdate: j6, ConsensusCommitPrologueV2: L6, ConsensusCommitPrologueV3: M6, ConsensusCommitPrologueV4: V6, ProgrammableSystemTransaction: pe });
var Ht = i.struct("TransactionDataV1", { kind: jt, sender: v, gasData: je, expiration: ze });
var Wt = i.enum("TransactionData", { V1: Ht });
var Gt = i.struct("SenderSignedTransaction", { intentMessage: He(Wt), txSignatures: i.vector(An) });
var Nn = i.vector(Gt, { name: "SenderSignedData" });
var J6 = i.enum("PackageUpgradeError", { UnableToFetchPackage: i.struct("UnableToFetchPackage", { packageId: v }), NotAPackage: i.struct("NotAPackage", { objectId: v }), IncompatibleUpgrade: null, DigestDoesNotMatch: i.struct("DigestDoesNotMatch", { digest: i.byteVector() }), UnknownUpgradePolicy: i.struct("UnknownUpgradePolicy", { policy: i.u8() }), PackageIDDoesNotMatch: i.struct("PackageIDDoesNotMatch", { packageId: v, ticketId: v }) });
var X6 = i.struct("ModuleId", { address: v, name: i.string() });
var Rn = i.struct("MoveLocation", { module: X6, function: i.u16(), instruction: i.u16(), functionName: i.option(i.string()) });
var Z6 = i.enum("CommandArgumentError", { TypeMismatch: null, InvalidBCSBytes: null, InvalidUsageOfPureArg: null, InvalidArgumentToPrivateEntryFunction: null, IndexOutOfBounds: i.struct("IndexOutOfBounds", { idx: i.u16() }), SecondaryIndexOutOfBounds: i.struct("SecondaryIndexOutOfBounds", { resultIdx: i.u16(), secondaryIdx: i.u16() }), InvalidResultArity: i.struct("InvalidResultArity", { resultIdx: i.u16() }), InvalidGasCoinUsage: null, InvalidValueUsage: null, InvalidObjectByValue: null, InvalidObjectByMutRef: null, SharedObjectOperationNotAllowed: null, InvalidArgumentArity: null, InvalidTransferObject: null, InvalidMakeMoveVecNonObjectArgument: null, ArgumentWithoutValue: null, CannotMoveBorrowedValue: null, CannotWriteToExtendedReference: null, InvalidReferenceArgument: null });
var Y6 = i.enum("TypeArgumentError", { TypeNotFound: null, ConstraintNotSatisfied: null });
var Q6 = i.enum("ExecutionFailureStatus", { InsufficientGas: null, InvalidGasObject: null, InvariantViolation: null, FeatureNotYetSupported: null, MoveObjectTooBig: i.struct("MoveObjectTooBig", { objectSize: i.u64(), maxObjectSize: i.u64() }), MovePackageTooBig: i.struct("MovePackageTooBig", { objectSize: i.u64(), maxObjectSize: i.u64() }), CircularObjectOwnership: i.struct("CircularObjectOwnership", { object: v }), InsufficientCoinBalance: null, CoinBalanceOverflow: null, PublishErrorNonZeroAddress: null, SuiMoveVerificationError: null, MovePrimitiveRuntimeError: i.option(Rn), MoveAbort: i.tuple([Rn, i.u64()]), VMVerificationOrDeserializationError: null, VMInvariantViolation: null, FunctionNotFound: null, ArityMismatch: null, TypeArityMismatch: null, NonEntryFunctionInvoked: null, CommandArgumentError: i.struct("CommandArgumentError", { argIdx: i.u16(), kind: Z6 }), TypeArgumentError: i.struct("TypeArgumentError", { argumentIdx: i.u16(), kind: Y6 }), UnusedValueWithoutDrop: i.struct("UnusedValueWithoutDrop", { resultIdx: i.u16(), secondaryIdx: i.u16() }), InvalidPublicFunctionReturnType: i.struct("InvalidPublicFunctionReturnType", { idx: i.u16() }), InvalidTransferObject: null, EffectsTooLarge: i.struct("EffectsTooLarge", { currentSize: i.u64(), maxSize: i.u64() }), PublishUpgradeMissingDependency: null, PublishUpgradeDependencyDowngrade: null, PackageUpgradeError: i.struct("PackageUpgradeError", { upgradeError: J6 }), WrittenObjectsTooLarge: i.struct("WrittenObjectsTooLarge", { currentSize: i.u64(), maxSize: i.u64() }), CertificateDenied: null, SuiMoveVerificationTimedout: null, SharedObjectOperationNotAllowed: null, InputObjectDeleted: null, ExecutionCancelledDueToSharedObjectCongestion: i.struct("ExecutionCancelledDueToSharedObjectCongestion", { congested_objects: i.vector(v) }), AddressDeniedForCoin: i.struct("AddressDeniedForCoin", { address: v, coinType: i.string() }), CoinTypeGlobalPause: i.struct("CoinTypeGlobalPause", { coinType: i.string() }), ExecutionCancelledDueToRandomnessUnavailable: null, MoveVectorElemTooBig: i.struct("MoveVectorElemTooBig", { valueSize: i.u64(), maxScaledSize: i.u64() }), MoveRawValueTooBig: i.struct("MoveRawValueTooBig", { valueSize: i.u64(), maxScaledSize: i.u64() }), InvalidLinkage: null, InsufficientBalanceForWithdraw: null, NonExclusiveWriteInputObjectModified: i.struct("NonExclusiveWriteInputObjectModified", { id: v }) });
var _n = i.enum("ExecutionStatus", { Success: null, Failure: i.struct("Failure", { error: Q6, command: i.option(i.u64()) }) });
var Un = i.struct("GasCostSummary", { computationCost: i.u64(), storageCost: i.u64(), storageRebate: i.u64(), nonRefundableStorageFee: i.u64() });
var e5 = i.struct("TransactionEffectsV1", { status: _n, executedEpoch: i.u64(), gasUsed: Un, modifiedAtVersions: i.vector(i.tuple([v, i.u64()])), sharedObjects: i.vector(q), transactionDigest: O, created: i.vector(i.tuple([q, t0])), mutated: i.vector(i.tuple([q, t0])), unwrapped: i.vector(i.tuple([q, t0])), deleted: i.vector(q), unwrappedThenDeleted: i.vector(q), wrapped: i.vector(q), gasObject: i.tuple([q, t0]), eventsDigest: i.option(O), dependencies: i.vector(O) });
var qt = i.tuple([i.u64(), O]);
var t52 = i.enum("ObjectIn", { NotExist: null, Exist: i.tuple([qt, t0]) });
var n5 = i.struct("AccumulatorAddress", { address: v, ty: h0 });
var r5 = i.enum("AccumulatorOperation", { Merge: null, Split: null });
var a5 = i.enum("AccumulatorValue", { Integer: i.u64(), IntegerTuple: i.tuple([i.u64(), i.u64()]), EventDigest: i.vector(i.tuple([i.u64(), O])) });
var s5 = i.struct("AccumulatorWriteV1", { address: n5, operation: r5, value: a5 });
var i5 = i.enum("ObjectOut", { NotExist: null, ObjectWrite: i.tuple([O, t0]), PackageWrite: qt, AccumulatorWriteV1: s5 });
var o5 = i.enum("IDOperation", { None: null, Created: null, Deleted: null });
var f5 = i.struct("EffectsObjectChange", { inputState: t52, outputState: i5, idOperation: o5 });
var c5 = i.enum("UnchangedConsensusKind", { ReadOnlyRoot: qt, MutateConsensusStreamEnded: i.u64(), ReadConsensusStreamEnded: i.u64(), Cancelled: i.u64(), PerEpochConfig: null });
var d5 = i.struct("TransactionEffectsV2", { status: _n, executedEpoch: i.u64(), gasUsed: Un, transactionDigest: O, gasObjectIndex: i.option(i.u32()), eventsDigest: i.option(O), dependencies: i.vector(O), lamportVersion: i.u64(), changedObjects: i.vector(i.tuple([v, f5])), unchangedConsensusObjects: i.vector(i.tuple([v, c5])), auxDataDigest: i.option(O) });
var Dn = i.enum("TransactionEffects", { V1: e5, V2: d5 });
var w = { ...i, U8: i.u8(), U16: i.u16(), U32: i.u32(), U64: i.u64(), U128: i.u128(), U256: i.u256(), ULEB128: i.uleb128(), Bool: i.bool(), String: i.string(), Address: v, AppId: Nt, Argument: d0, CallArg: Tt, Command: Ct, CompressedSignature: _t, Data: he, GasData: je, Intent: Rt, IntentMessage: He, IntentScope: Ot, IntentVersion: Pt, MoveObject: $t, MoveObjectType: Lt, MovePackage: zt, MultiSig: Tn, MultiSigPkMap: Dt, MultiSigPublicKey: Ft, Object: Cn, ObjectArg: It, ObjectDigest: O, Owner: t0, PasskeyAuthenticator: kn, ProgrammableMoveCall: kt, ProgrammableTransaction: pe, PublicKey: Ut, SenderSignedData: Nn, SenderSignedTransaction: Gt, SharedObjectRef: Bt, StructTag: $e, SuiObjectRef: q, TransactionData: Wt, TransactionDataV1: Ht, TransactionEffects: Dn, TransactionExpiration: ze, TransactionKind: jt, TypeOrigin: Mt, TypeTag: h0, UpgradeInfo: Vt };
function Fn(t17) {
  return t17 instanceof Uint8Array || ArrayBuffer.isView(t17) && t17.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in t17 && t17.BYTES_PER_ELEMENT === 1;
}
var Kt = (t17) => t17 ? `"${t17}" ` : "";
function ge(t17, e = "") {
  if (typeof t17 != "number") throw new TypeError(Kt(e) + "expected number, got " + typeof t17);
  if (!Number.isSafeInteger(t17) || t17 < 0) throw new RangeError(Kt(e) + "expected integer >= 0, got " + t17);
  return t17;
}
function E0(t17, e, n = "") {
  if (Fn(t17) && (e === void 0 || t17.length === e)) return t17;
  e !== void 0 && ge(e, "length");
  let r = Fn(t17), a = e !== void 0 ? ` of length ${e}` : "", s = r ? `length=${t17.length}` : `type=${typeof t17}`, o = Kt(n) + "expected Uint8Array" + a + ", got " + s;
  throw r ? new RangeError(o) : new TypeError(o);
}
function Jt(t17) {
  return Uint8Array.from(E0(t17));
}
var Ln = (t17, e) => {
  if (t17 === null || typeof t17 != "object" || Array.isArray(t17)) throw new TypeError((e === "object" ? "" : `"${e}" `) + "expected object, got type=" + typeof t17);
};
function Xt(t17, e = true) {
  if (t17.destroyed) throw new Error("hash was destroyed");
  if (e && t17.finished) throw new Error("digest() was already called");
}
function Mn(t17, e) {
  E0(t17, void 0, "output");
  let n = e.outputLen;
  if (!(t17.length >= n)) throw new RangeError('"output" expected length >= ' + n);
}
function me(t17) {
  return new Uint32Array(t17.buffer, t17.byteOffset, Math.floor(t17.byteLength / 4));
}
function We(...t17) {
  for (let e = 0; e < t17.length; e++) t17[e].fill(0);
}
var Vn = new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
function zn(t17) {
  return t17 << 24 & 4278190080 | t17 << 8 & 16711680 | t17 >>> 8 & 65280 | t17 >>> 24 & 255;
}
var g0 = Vn ? (t17) => t17 : (t17) => zn(t17) >>> 0;
function u5(t17) {
  for (let e = 0; e < t17.length; e++) t17[e] = zn(t17[e]);
  return t17;
}
var j0 = Vn ? (t17) => t17 : u5;
function Zt(t17, e, n = "opts") {
  return Ln(t17, "defaults"), e !== void 0 && Ln(e, n), Object.assign(t17, e);
}
function $n(t17, e = {}) {
  if (typeof t17 != "function") throw new TypeError('"hashCons" expected function, got type=' + typeof t17);
  e = Zt({}, e, "info");
  let n = (a, s) => t17(s).update(a).digest(), r = t17(void 0);
  return n.outputLen = r.outputLen, n.blockLen = r.blockLen, n.canXOF = r.canXOF, n.create = (a) => t17(a), Object.assign(n, e), Object.freeze(n);
}
var jn = Uint8Array.from([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 14, 10, 4, 8, 9, 15, 13, 6, 1, 12, 0, 2, 11, 7, 5, 3, 11, 8, 12, 0, 5, 2, 15, 13, 10, 14, 3, 6, 7, 1, 9, 4, 7, 9, 3, 1, 13, 12, 11, 14, 2, 6, 5, 10, 4, 0, 15, 8, 9, 0, 5, 7, 2, 4, 10, 15, 14, 1, 11, 12, 6, 8, 3, 13, 2, 12, 6, 10, 0, 11, 8, 3, 4, 13, 7, 5, 15, 14, 1, 9, 12, 5, 1, 15, 14, 13, 4, 10, 0, 7, 6, 3, 9, 2, 8, 11, 13, 11, 7, 14, 12, 1, 3, 9, 5, 0, 15, 4, 8, 6, 2, 10, 6, 15, 14, 9, 11, 3, 0, 8, 12, 2, 13, 7, 1, 4, 10, 5, 10, 2, 8, 4, 7, 6, 1, 5, 15, 11, 9, 14, 3, 12, 13, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 14, 10, 4, 8, 9, 15, 13, 6, 1, 12, 0, 2, 11, 7, 5, 3, 11, 8, 12, 0, 5, 2, 15, 13, 10, 14, 3, 6, 7, 1, 9, 4, 7, 9, 3, 1, 13, 12, 11, 14, 2, 6, 5, 10, 4, 0, 15, 8, 9, 0, 5, 7, 2, 4, 10, 15, 14, 1, 11, 12, 6, 8, 3, 13, 2, 12, 6, 10, 0, 11, 8, 3, 4, 13, 7, 5, 15, 14, 1, 9]);
var Hn = (t17) => t17 / 2 ** 32 | 0;
var Wn = (t17) => t17 >>> 0;
var Yt = (t17, e, n) => t17 >>> n | e << 32 - n;
var Qt = (t17, e, n) => t17 << 32 - n | e >>> n;
var Gn = (t17, e, n) => t17 << 64 - n | e >>> n - 32;
var qn = (t17, e, n) => t17 >>> n - 32 | e << 64 - n;
var Kn = (t17, e) => e;
var Jn = (t17, e) => t17;
function e1(t17, e, n, r) {
  let a = (e >>> 0) + (r >>> 0);
  return { h: t17 + n + (a / 2 ** 32 | 0) | 0, l: a | 0 };
}
var t1 = (t17, e, n) => (t17 >>> 0) + (e >>> 0) + (n >>> 0);
var n1 = (t17, e, n, r) => e + n + r + (t17 / 2 ** 32 | 0) | 0;
var L = Uint32Array.from([4089235720, 1779033703, 2227873595, 3144134277, 4271175723, 1013904242, 1595750129, 2773480762, 2917565137, 1359893119, 725511199, 2600822924, 4215389547, 528734635, 327033209, 1541459225]);
var b = new Uint32Array(32);
function R0(t17, e, n, r, a, s) {
  let o = a[s], f = a[s + 1], c = b[2 * t17], d = b[2 * t17 + 1], u = b[2 * e], g = b[2 * e + 1], p = b[2 * n], m = b[2 * n + 1], E = b[2 * r], S = b[2 * r + 1], j = t1(c, u, o);
  d = n1(j, d, g, f), c = j | 0;
  let K = S ^ d, J = E ^ c;
  S = Kn(K, J), E = Jn(K, J), { h: m, l: p } = e1(m, p, S, E), K = g ^ m, J = u ^ p, g = Yt(K, J, 24), u = Qt(K, J, 24), b[2 * t17] = c, b[2 * t17 + 1] = d, b[2 * e] = u, b[2 * e + 1] = g, b[2 * n] = p, b[2 * n + 1] = m, b[2 * r] = E, b[2 * r + 1] = S;
}
function _0(t17, e, n, r, a, s) {
  let o = a[s], f = a[s + 1], c = b[2 * t17], d = b[2 * t17 + 1], u = b[2 * e], g = b[2 * e + 1], p = b[2 * n], m = b[2 * n + 1], E = b[2 * r], S = b[2 * r + 1], j = t1(c, u, o);
  d = n1(j, d, g, f), c = j | 0;
  let K = S ^ d, J = E ^ c;
  S = Yt(K, J, 16), E = Qt(K, J, 16), { h: m, l: p } = e1(m, p, S, E), K = g ^ m, J = u ^ p, g = Gn(K, J, 63), u = qn(K, J, 63), b[2 * t17] = c, b[2 * t17 + 1] = d, b[2 * e] = u, b[2 * e + 1] = g, b[2 * n] = p, b[2 * n + 1] = m, b[2 * r] = E, b[2 * r + 1] = S;
}
function l5(t17, e = {}, n, r, a) {
  if (ge(n), t17 <= 0 || t17 > n) throw new Error('"dkLen" must be 1..' + n + ", got " + t17);
  let { key: s, salt: o, personalization: f } = e;
  if (s !== void 0 && (s.length < 1 || s.length > n)) throw new Error('"key" expected to be undefined or of length=1..' + n);
  o !== void 0 && E0(o, r, "salt"), f !== void 0 && E0(f, a, "personalization");
}
var r1 = class {
  buffer;
  buffer32;
  finished = false;
  destroyed = false;
  length = 0;
  pos = 0;
  blockLen;
  outputLen;
  canXOF = false;
  constructor(e, n) {
    ge(e), ge(n), this.blockLen = e, this.outputLen = n, this.buffer = new Uint8Array(e), this.buffer32 = me(this.buffer);
  }
  update(e) {
    Xt(this), E0(e);
    let { blockLen: n, buffer: r, buffer32: a } = this, s = e.length, o = e.byteOffset, f = e.buffer;
    for (let c = 0; c < s; ) {
      this.pos === n && (j0(a), this.compress(a, 0, false), j0(a), this.pos = 0);
      let d = Math.min(n - this.pos, s - c), u = o + c;
      if (d === n && !(u % 4) && c + d < s) {
        let g = new Uint32Array(f, u, Math.floor((s - c) / 4));
        j0(g);
        for (let p = 0; c + n < s; p += a.length, c += n) this.length += n, this.compress(g, p, false);
        j0(g);
        continue;
      }
      r.set(c === 0 && d === s ? e : e.subarray(c, c + d), this.pos), this.pos += d, this.length += d, c += d;
    }
    return this;
  }
  digestInto(e) {
    if (Xt(this), Mn(e, this), e.byteOffset & 3) throw new RangeError('"output" expected 4-byte aligned byteOffset, got ' + e.byteOffset);
    let { pos: n, buffer32: r } = this;
    this.finished = true, this.buffer.fill(0, n), j0(r), this.compress(r, 0, true), j0(r);
    let a = this.get(), s = e === this.buffer ? r : me(e), o = Math.floor(this.outputLen / 4);
    for (let u = 0; u < o; u++) s[u] = g0(a[u]);
    let f = this.outputLen % 4;
    if (!f) return;
    let c = o * 4, d = a[o];
    for (let u = 0; u < f; u++) e[c + u] = d >>> 8 * u;
  }
  digest() {
    let { buffer: e, outputLen: n } = this;
    this.digestInto(e);
    let r = e.slice(0, n);
    return this.destroy(), r;
  }
  _cloneInto(e) {
    let { buffer: n, length: r, finished: a, destroyed: s, outputLen: o, pos: f } = this;
    return e ||= new this.constructor({ dkLen: o }), e.set(...this.get()), e.buffer.set(n), e.destroyed = s, e.finished = a, e.length = r, e.pos = f, e.outputLen = o, e;
  }
  clone() {
    return this._cloneInto();
  }
};
var a1 = class extends r1 {
  v0l = L[0] | 0;
  v0h = L[1] | 0;
  v1l = L[2] | 0;
  v1h = L[3] | 0;
  v2l = L[4] | 0;
  v2h = L[5] | 0;
  v3l = L[6] | 0;
  v3h = L[7] | 0;
  v4l = L[8] | 0;
  v4h = L[9] | 0;
  v5l = L[10] | 0;
  v5h = L[11] | 0;
  v6l = L[12] | 0;
  v6h = L[13] | 0;
  v7l = L[14] | 0;
  v7h = L[15] | 0;
  constructor(e = {}) {
    e = Zt({}, e);
    let n = e.dkLen === void 0 ? 64 : e.dkLen;
    super(128, n), l5(n, e, 64, 16, 16);
    let { key: r, personalization: a, salt: s } = e, o = 0;
    if (r !== void 0 && (E0(r, void 0, "key"), o = r.length), this.v0l ^= this.outputLen | o << 8 | 65536 | 1 << 24, s !== void 0) {
      E0(s, void 0, "salt");
      let f = me(Jt(s));
      this.v4l ^= g0(f[0]), this.v4h ^= g0(f[1]), this.v5l ^= g0(f[2]), this.v5h ^= g0(f[3]);
    }
    if (a !== void 0) {
      E0(a, void 0, "personalization");
      let f = me(Jt(a));
      this.v6l ^= g0(f[0]), this.v6h ^= g0(f[1]), this.v7l ^= g0(f[2]), this.v7h ^= g0(f[3]);
    }
    if (r !== void 0) {
      let f = new Uint8Array(this.blockLen);
      f.set(r), this.update(f), We(f);
    }
  }
  get() {
    let { v0l: e, v0h: n, v1l: r, v1h: a, v2l: s, v2h: o, v3l: f, v3h: c, v4l: d, v4h: u, v5l: g, v5h: p, v6l: m, v6h: E, v7l: S, v7h: j } = this;
    return [e, n, r, a, s, o, f, c, d, u, g, p, m, E, S, j];
  }
  set(e, n, r, a, s, o, f, c, d, u, g, p, m, E, S, j) {
    this.v0l = e | 0, this.v0h = n | 0, this.v1l = r | 0, this.v1h = a | 0, this.v2l = s | 0, this.v2h = o | 0, this.v3l = f | 0, this.v3h = c | 0, this.v4l = d | 0, this.v4h = u | 0, this.v5l = g | 0, this.v5h = p | 0, this.v6l = m | 0, this.v6h = E | 0, this.v7l = S | 0, this.v7h = j | 0;
  }
  compress(e, n, r) {
    let { v0l: a, v0h: s, v1l: o, v1h: f, v2l: c, v2h: d, v3l: u, v3h: g, v4l: p, v4h: m, v5l: E, v5h: S, v6l: j, v6h: K, v7l: J, v7h: br } = this;
    b[0] = a, b[1] = s, b[2] = o, b[3] = f, b[4] = c, b[5] = d, b[6] = u, b[7] = g, b[8] = p, b[9] = m, b[10] = E, b[11] = S, b[12] = j, b[13] = K, b[14] = J, b[15] = br, b.set(L, 16);
    let lr = Wn(this.length), pr = Hn(this.length);
    b[24] = L[8] ^ lr, b[25] = L[9] ^ pr, r && (b[28] = ~b[28], b[29] = ~b[29]);
    let z = 0, $ = jn;
    for (let d1 = 0; d1 < 12; d1++) R0(0, 4, 8, 12, e, n + 2 * $[z++]), _0(0, 4, 8, 12, e, n + 2 * $[z++]), R0(1, 5, 9, 13, e, n + 2 * $[z++]), _0(1, 5, 9, 13, e, n + 2 * $[z++]), R0(2, 6, 10, 14, e, n + 2 * $[z++]), _0(2, 6, 10, 14, e, n + 2 * $[z++]), R0(3, 7, 11, 15, e, n + 2 * $[z++]), _0(3, 7, 11, 15, e, n + 2 * $[z++]), R0(0, 5, 10, 15, e, n + 2 * $[z++]), _0(0, 5, 10, 15, e, n + 2 * $[z++]), R0(1, 6, 11, 12, e, n + 2 * $[z++]), _0(1, 6, 11, 12, e, n + 2 * $[z++]), R0(2, 7, 8, 13, e, n + 2 * $[z++]), _0(2, 7, 8, 13, e, n + 2 * $[z++]), R0(3, 4, 9, 14, e, n + 2 * $[z++]), _0(3, 4, 9, 14, e, n + 2 * $[z++]);
    this.v0l ^= b[0] ^ b[16], this.v0h ^= b[1] ^ b[17], this.v1l ^= b[2] ^ b[18], this.v1h ^= b[3] ^ b[19], this.v2l ^= b[4] ^ b[20], this.v2h ^= b[5] ^ b[21], this.v3l ^= b[6] ^ b[22], this.v3h ^= b[7] ^ b[23], this.v4l ^= b[8] ^ b[24], this.v4h ^= b[9] ^ b[25], this.v5l ^= b[10] ^ b[26], this.v5h ^= b[11] ^ b[27], this.v6l ^= b[12] ^ b[28], this.v6h ^= b[13] ^ b[29], this.v7l ^= b[14] ^ b[30], this.v7h ^= b[15] ^ b[31], We(b);
  }
  destroy() {
    this.destroyed = true, We(this.buffer32), this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  }
};
var Xn = $n((t17) => new a1(t17));
function s1(t17, e, n) {
  let r = w.Address.serialize(t17).toBytes(), a = w.TypeTag.serialize(e).toBytes(), s = w.u64().serialize(n.length).toBytes(), o = Xn.create({ dkLen: 32 });
  return o.update(new Uint8Array([240])), o.update(r), o.update(s), o.update(n), o.update(a), `0x${c0(o.digest().slice(0, 32))}`;
}
var Zn = { sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4", nft: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba", nftType: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT", oappPackage: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24", graphql: "https://graphql.mainnet.sui.io/graphql", chain: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S", maxGasMist: "20000000", package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92", vault: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb", registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210", admin: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d", oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4", oappAdmin: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d", upgrade: "0xb70e2cdc18d562247bc34bf47efee620a05ec1f059cff5e812a8d433a722999d", endpoint: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91", endpointPackage: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac", endpointRegistry: "0x720fc2300c05bb7ad68aefec00a9796b4451c4d1df78bc72cd8c98e774220bec", vaultAdmin: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac", uln: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f", ulnPackage: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0", executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989", receiveCallId: "64202616f75a5614acfa264418258521299eb6a892eeeea392feef8948c7eb53", dvns: ["0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb", "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685", "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"], channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023", channelVersion: "1089269258", registration: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a", registrationDigest: "DF8dMqSXXtYBoemHsPYk2QJDkuUY2m8zTRDdcu6Y9DFt", remoteEid: 30102 };
var Q = Object.freeze(Zn);
var h5 = w.enum("Argument", { ID: w.vector(w.u8()), Object: w.Address, Pure: w.vector(w.u8()), NestedResult: w.struct("NestedResult", { call_index: w.u16(), result_index: w.u16() }) });
var g5 = w.vector(w.struct("MoveCall", { function: w.struct("Function", { package: w.Address, module_name: w.string(), name: w.string() }), arguments: w.vector(h5), type_arguments: w.vector(w.string()), is_builder_call: w.bool(), result_ids: w.vector(w.vector(w.u8())) }));
var m5 = w.struct("OAppInfoV1", { oapp_object: w.Address, next_nonce_info: w.vector(w.u8()), lz_receive_info: w.vector(w.u8()), extra_info: w.vector(w.u8()) });
var tf = w.struct("OAppUlnConfig", { use_default_confirmations: w.bool(), use_default_required_dvns: w.bool(), use_default_optional_dvns: w.bool(), uln_config: w.struct("UlnConfig", { confirmations: w.u64(), required_dvns: w.vector(w.Address), optional_dvns: w.vector(w.Address), optional_dvn_threshold: w.u8() }) });
var nf = w.struct("ExecutorConfig", { max_message_size: w.u64(), executor: w.Address });
var y5 = "address version digest owner{__typename ... on Shared{initialSharedVersion} ... on AddressOwner{address{address}}} asMoveObject{contents{type{repr} json}}";
var Ge = btoa(String.fromCharCode(...Uint8Array.from((Q.package.slice(2) + "96750000").match(/../g), (t17) => parseInt(t17, 16))));
var i1 = Object.freeze({ libraries: ["0xa2371851318b3ba333270daf696dedbc7b89a1107ca362643798c1789ce05a01", "u32", "lnUAAA=="], send: ["0x2bd7d044d837b718a7852959c701c04e842e648cf9047b442d55c838846a13e5", "u32", "lnUAAA=="], receive: ["0x5ddc28272722231ecef30237bb48715f128d6995b89a46db25cd9adae0140835", "u32", "lnUAAA=="], executor: ["0x346b468d90db8743673c7ed4fdbe1c40f6a587aac6acc730b3a9bb86cf0919f4", "u32", "lnUAAA=="], appLibraries: ["0x0e679b0fcc94fb07a5ec9a14712f8e35e0994b892e64a434e898450eb670e920", Q.endpointPackage + "::message_lib_manager::OAppConfigKey", Ge], appSend: ["0xc53b8a5592cdeea1a7421d209ba5c70e6843d2911e5bb86ad9fb744d888eab60", Q.ulnPackage + "::send_uln::OAppConfigKey", Ge], appReceive: ["0x0d89da4d00f46c4b1dab465a867e60eacbf646e56f8816ae55cd7b9495c1bb09", Q.ulnPackage + "::receive_uln::OAppConfigKey", Ge], appExecutor: ["0x357a98886ef14de3d15e538a808b410cfe026f6b1f971bb2398978d56e4dc181", Q.ulnPackage + "::send_uln::OAppConfigKey", Ge] });
var x5 = "query { chainIdentifier checkpoint{sequenceNumber timestamp} " + Object.entries({ endpoint: Q.endpoint, uln: Q.uln, oapp: Q.oapp, admin: Q.admin, vault: Q.vault, channel: Q.channel, registration: Q.registration }).map(([t17, e]) => t17 + ':object(address:"' + e + '"){' + y5 + "}").join(" ") + " " + Object.entries(i1).map(([t17, [e, n, r]]) => t17 + ':address(address:"' + e + '"){dynamicField(name:{type:"' + n + '",bcs:"' + r + '"}){value{... on MoveValue{json}}}}').join(" ") + "}";
var w5 = ["appLibraries", "appExecutor", "appSend", "appReceive"];
var bf = Object.freeze(Object.fromEntries(w5.map((t17) => {
  let [e, n, r] = i1[t17], [a, s, o] = n.split("::");
  return [t17, { id: s1(e, { struct: { address: a, module: s, name: o, typeParams: [] } }, Uint8Array.from(atob(r), (f) => f.charCodeAt(0))), parent: e }];
})));
var Ef = BigInt(R.maxTotalFeeWei);
var E5 = (t17, e) => String(t17).toLowerCase() === String(e).toLowerCase();
var Yn = (t17) => JSON.stringify(t17, (e, n) => typeof n == "bigint" ? String(n) : n);
var Qn = new F(["function isDefaultSendLibrary(address,uint32)view returns(bool)", "function getSendLibrary(address,uint32)view returns(address)", "function getReceiveLibrary(address,uint32)view returns(address,bool)", "function delegates(address)view returns(address)", "function getConfig(address,address,uint32,uint32)view returns(bytes)"]);
var v5 = new F(["function getAppUlnConfig(address,uint32)view returns(tuple(uint64 confirmations,uint8 requiredDVNCount,uint8 optionalDVNCount,uint8 optionalDVNThreshold,address[] requiredDVNs,address[] optionalDVNs))"]);
async function tr(t17) {
  let e = V0(t17);
  h(BigInt(await e("eth_chainId")) === 56n, "BNB mainnet required");
  let n = await e("eth_blockNumber");
  for (let [f, c] of Object.entries(R.codeHashes)) h(U(await e("eth_getCode", [f, n])) === c, "Protocol code changed");
  let r = async (f, c) => Qn.decodeFunctionResult(f, await e("eth_call", [{ to: R.endpoint, data: Qn.encodeFunctionData(f, c) }, n])), a = (f) => e("eth_call", [{ to: f, data: v5.encodeFunctionData("getAppUlnConfig", [R.adapter, 30378]) }, n]), s = { defaultSendLibrary: (await r("isDefaultSendLibrary", [R.adapter, 30378]))[0], rawSendSecurity: await a(R.sendLibrary), rawReceiveSecurity: await a(R.receiveLibrary), sendLibrary: (await r("getSendLibrary", [R.adapter, 30378]))[0], receiveLibrary: Array.from(await r("getReceiveLibrary", [R.adapter, 30378])), delegate: (await r("delegates", [R.adapter]))[0], executor: (await r("getConfig", [R.adapter, R.sendLibrary, 30378, 1]))[0], sendSecurity: (await r("getConfig", [R.adapter, R.sendLibrary, 30378, 2]))[0], receiveSecurity: (await r("getConfig", [R.adapter, R.receiveLibrary, 30378, 2]))[0] }, o = R.states.map((f, c) => E5(Yn(f), Yn(s)) ? c : -1).filter((f) => f >= 0);
  return h(o.length === 1, "Live settings differ from the reviewed sequence. Recover receipts before continuing."), { stage: o[0], block: n, state: s };
}
var B = { schema: 1, admin: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", baseNonce: 4746, maxTotalFeeWei: "100000000000000", suiDigest: "i6nTSPBKFSUf7GXhsnocnFfuuMtkqvQASR91YTZZdfE", currency: "0x55d398326f99059fF775485246999027B3197955", price: "25000000000000000000", recipient: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4", redemption: "0xc99c328de96599e4ea3332e097436cdc5bd542a0a479f892543b3008664128b3", gasLimits: [7e4, 5e4, 18e4, 7e4, 14e4], steps: [{ label: "Approve exactly 25 USDT", to: "0x55d398326f99059fF775485246999027B3197955", data: "0x095ea7b3000000000000000000000000418cc337fc19d8cf3b41a9c6e3138a60e34eb9b50000000000000000000000000000000000000000000000015af1d78b58c40000" }, { label: "Unpause private purchase", to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5", data: "0x325832ac0000000000000000000000000000000000000000000000000000000000000000" }, { label: "Buy generation 1", to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5", data: "0xa6f2ae3a" }, { label: "Pause further purchases", to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5", data: "0x325832ac0000000000000000000000000000000000000000000000000000000000000001" }, { label: "Lock redemption to dev Sui wallet", to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5", data: "0x97579dd3485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4" }], codeHashes: { "0x74c20dEB476Dca58459956b1AcD65771197900C9": "0x6efff3014469a796f571b62eb85981489aa5c17103595fa4557ce7c72f1e2e1b", "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5": "0xa2fb16a830bce8f5c1e173915fb3f7ad7016be1ff9f0891b92a2921dc3ab1ef4", "0x55d398326f99059fF775485246999027B3197955": "0x97a48aa4c129657440dafdacd4c836389734d28cc4a0ca7403e68da660a74a59" } };
var nr = BigInt(B.maxTotalFeeWei);
var kf = B.steps.map((t17) => t17.label);
var k = (t17, e) => String(t17).toLowerCase() === String(e).toLowerCase();
var m0 = new F(x.pass.abi);
var o1 = new F(x.adapter.abi);
var qe = new F(["function allowance(address,address)view returns(uint256)", "function balanceOf(address)view returns(uint256)", "function decimals()view returns(uint8)", "event Approval(address indexed owner,address indexed spender,uint256 value)", "event Transfer(address indexed from,address indexed to,uint256 value)"]);
function B5(t17) {
  h(t17?.schema === 1 && t17.baseNonce === B.baseNonce, "Unrecognized purchase sequence."), h(Array.isArray(t17.hashes) && t17.hashes.length <= 5 && Array.isArray(t17.requests) && t17.requests.length === t17.hashes.length, "Invalid progress"), h(new Set(t17.hashes.map((e) => e.toLowerCase())).size === t17.hashes.length, "Duplicate receipt");
  for (let e of t17.hashes) h(/^0x[0-9a-f]{64}$/i.test(e), "Invalid hash");
  for (let e = 0; e < t17.requests.length; e++) f1(t17.requests[e], e);
  t17.attempt && (h(t17.attempt.index === t17.hashes.length && t17.hashes.length < 5, "Invalid pending step"), f1(t17.attempt.request, t17.attempt.index));
}
function f1(t17, e) {
  h(Number.isInteger(e) && e >= 0 && e < 5, "Invalid step"), h(Object.keys(t17).every((n) => ["from", "to", "data", "value", "chainId", "nonce", "gas", "gasPrice"].includes(n)), "Unexpected transaction field"), h(k(t17.from, B.admin) && k(t17.to, B.steps[e].to), "Wrong sender/destination"), h(t17.data === B.steps[e].data && BigInt(t17.value) === 0n, "Changed calldata or payment"), h(BigInt(t17.chainId) === 56n && BigInt(t17.nonce) === BigInt(B.baseNonce + e), "Wrong chain or nonce"), h(BigInt(t17.gas) === BigInt(B.gasLimits[e]) && BigInt(t17.gasPrice) > 0n && BigInt(t17.gas) * BigInt(t17.gasPrice) <= nr, "Fee ceiling changed");
}
function I5(t17, e, n, r) {
  f1(r, n), h(t17 && e, "Receipt not indexed yet; do not resend"), h(BigInt(e.status) === 1n, "Transaction failed. Return its receipt to Codex."), h(k(t17.hash, e.transactionHash) && k(t17.blockHash, e.blockHash), "Receipt identity differs"), h(k(t17.from, B.admin) && k(t17.to, B.steps[n].to) && BigInt(t17.nonce) === BigInt(B.baseNonce + n) && BigInt(t17.value) === 0n && (t17.input ?? t17.data) === B.steps[n].data, "Submitted content differs");
  let a = t17.chainId != null ? BigInt(t17.chainId) : (BigInt(t17.v ?? 0) - 35n) / 2n;
  h(a === 56n, "Wrong transaction chain"), h(!e.contractAddress, "Unexpected deployment");
  let s = BigInt(t17.maxFeePerGas ?? t17.gasPrice), o = BigInt(e.gasUsed), f = BigInt(e.effectiveGasPrice ?? t17.gasPrice);
  return h(BigInt(t17.gas) <= BigInt(r.gas) && s <= BigInt(r.gasPrice) && o <= BigInt(t17.gas) && f <= s, "Wallet increased fee limits"), T5(e, n), o * f;
}
function T5(t17, e) {
  let r = (t17.logs || []).filter((s) => k(s.address, B.currency) || k(s.address, x.addresses.pass)).map((s) => {
    let o = (k(s.address, B.currency) ? qe : m0).parseLog(s);
    return h(o, "Unknown token event"), { address: s.address, name: o.name, args: o.args };
  }), a = (s, o) => r.filter((f) => k(f.address, s) && f.name === o);
  if (e === 0) {
    let s = a(B.currency, "Approval");
    h(s.length === 1 && k(s[0].args.owner, x.admin) && k(s[0].args.spender, x.addresses.pass) && s[0].args.value === BigInt(B.price), "Exact allowance event missing"), h(r.length === 1, "Unexpected approval effects");
  } else if (e === 1 || e === 3) {
    let s = a(x.addresses.pass, "PurchasePauseChanged");
    h(s.length === 1 && s[0].args.paused === (e === 3) && r.length === 1, "Pause event differs");
  } else if (e === 2) {
    let s = a(B.currency, "Transfer"), o = a(x.addresses.pass, "Transfer"), f = a(x.addresses.pass, "PassPurchased");
    h(s.length === 1 && k(s[0].args.from, x.admin) && k(s[0].args.to, x.treasury) && s[0].args.value === BigInt(B.price), "Payment does not match 25 USDT to treasury"), h(o.length === 1 && BigInt(o[0].args.from) === 0n && k(o[0].args.to, x.admin) && o[0].args.tokenId === 1n, "Mint differs"), h(f.length === 1 && f[0].args.generation === 1n && k(f[0].args.buyer, x.admin) && f[0].args.amount === BigInt(B.price), "Purchase event differs");
    let c = a(B.currency, "Approval");
    h(c.length <= 1 && c.every((d) => k(d.args.owner, x.admin) && k(d.args.spender, x.addresses.pass) && d.args.value === 0n) && r.length === 3 + c.length, "Unexpected payment effects");
  } else {
    let s = a(x.addresses.pass, "RedemptionRequested");
    h(s.length === 1 && s[0].args.generation === 1n && k(s[0].args.request, B.redemption) && k(s[0].args.recipient, B.recipient) && r.length === 1, "Redemption lock differs");
  }
}
async function A5(t17, e) {
  h(Number.isInteger(e) && e >= 0 && e <= 5, "Invalid stage");
  let n = await tr(t17);
  h(n.stage === 4, "Security configuration changed");
  let r = V0(t17), a = n.block;
  for (let [g, p] of Object.entries(B.codeHashes)) h(U(await r("eth_getCode", [g, a])) === p, "Purchase contract runtime changed");
  let s = async (g, p, m, E = []) => p.decodeFunctionResult(m, await r("eth_call", [{ to: g, data: p.encodeFunctionData(m, E) }, a]))[0];
  for (let [g, p] of [["controller", x.admin], ["initialBuyer", x.admin], ["treasury", x.treasury], ["adapter", x.addresses.adapter], ["route", x.route], ["currency", B.currency]]) h(k(await s(x.addresses.pass, m0, g), p), "Wrong " + g);
  h(k(await s(x.addresses.adapter, o1, "pass"), x.addresses.pass) && k(await s(x.addresses.adapter, o1, "suiPeer"), x.peer) && k(await s(x.addresses.adapter, o1, "route"), x.route), "Adapter binding differs"), h(await s(B.currency, qe, "decimals") === 18n && await s(x.addresses.pass, m0, "PRICE") === BigInt(B.price), "Currency denomination differs");
  let o = Number(await s(x.addresses.pass, m0, "state")), f = Number(await s(x.addresses.pass, m0, "generation")), c = await s(x.addresses.pass, m0, "purchasesPaused"), d = await s(x.addresses.pass, m0, "canPlay", [x.admin]), u = await s(B.currency, qe, "allowance", [x.admin, x.addresses.pass]);
  return h(o === (e < 3 ? 1 : e < 5 ? 2 : 3) && f === 1 && c === (e < 2 || e >= 4) && d === (e === 3 || e === 4), "On-chain lifecycle differs from receipts. Recover progress; do not repeat actions."), h(u === (e === 1 || e === 2 ? BigInt(B.price) : 0n), "Unexpected allowance; stop for review"), h(k(await s(x.addresses.pass, m0, "redemption"), e === 5 ? B.redemption : "0x" + "0".repeat(64)) && k(await s(x.addresses.pass, m0, "recipient"), e === 5 ? B.recipient : "0x" + "0".repeat(64)), "Unexpected redemption"), e >= 3 && h(k(await s(x.addresses.pass, m0, "ownerOf", [1]), x.admin), "Wrong pass owner"), e < 3 && h(await s(B.currency, qe, "balanceOf", [x.admin]) >= BigInt(B.price), "At least 25 USDT is required"), { stage: e, block: a, state: o, generation: f, purchasesPaused: c, canPlay: d, allowance: String(u) };
}
async function rr(t17, e) {
  B5(e);
  let n = V0(t17), r = 0n, a = [];
  for (let o = 0; o < e.hashes.length; o++) {
    let f = e.hashes[o], c = await n("eth_getTransactionByHash", [f]), d = await n("eth_getTransactionReceipt", [f]);
    h(k(c?.hash, f) && k(d?.transactionHash, f), "Receipt not indexed; do not resend"), r += I5(c, d, o, e.requests[o]);
    let u = await n("eth_getBlockByNumber", [d.blockNumber, false]);
    h(k(u?.hash, d.blockHash), "Receipt block changed"), a.push(d);
  }
  return h(r <= nr, "Actual fees exceed approved limit"), { ...await A5(t17, e.hashes.length), spent: r, receipts: a, complete: e.hashes.length === 5 };
}
var ar = { schema: 1, baseNonce: 4746, hashes: ["0x90513e77348c8432bde9da795b64eb42aa755c781f68595685cb6b8d8ecccc34", "0xa6479792eec6e606d5ee7f4f4ecd7627c1f51478d574148e545995df89e2d90e", "0x80ed100d08356834a8be8e008972e943d080aa0025b0160112e9289e51e3278a", "0x403974ee957126e7c35f8680734028e56a320470a1f53e79deedcadbf6faf704", "0xeb391e4f8d85c1c0765c564ac21d1862a805a7d1cc6eca6a84d0607229e3a43c"], requests: [{ from: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", to: "0x55d398326f99059fF775485246999027B3197955", data: "0x095ea7b3000000000000000000000000418cc337fc19d8cf3b41a9c6e3138a60e34eb9b50000000000000000000000000000000000000000000000015af1d78b58c40000", value: "0x0", chainId: "0x38", nonce: "0x128a", gas: "0x11170", gasPrice: "0x2faf080" }, { from: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5", data: "0x325832ac0000000000000000000000000000000000000000000000000000000000000000", value: "0x0", chainId: "0x38", nonce: "0x128b", gas: "0xc350", gasPrice: "0x2faf080" }, { from: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5", data: "0xa6f2ae3a", value: "0x0", chainId: "0x38", nonce: "0x128c", gas: "0x2bf20", gasPrice: "0x2faf080" }, { from: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5", data: "0x325832ac0000000000000000000000000000000000000000000000000000000000000001", value: "0x0", chainId: "0x38", nonce: "0x128d", gas: "0x11170", gasPrice: "0x2faf080" }, { from: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5", data: "0x97579dd3485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4", value: "0x0", chainId: "0x38", nonce: "0x128e", gas: "0x222e0", gasPrice: "0x2faf080" }], attempt: null };
var Q0 = { feeAllocation: { executor: { address: "0x3ebD570ed38B1b3b4BC886999fcF507e9D584859", feeWei: "4540051919132878" }, requiredDvns: [{ address: "0x247624e2143504730aeC22912ed41F092498bEf2", feeWei: "12393688110727" }, { address: "0x31F748a368a893Bdb5aBB67ec95F232507601A73", feeWei: "12244828949784" }, { address: "0xfD6865c841c2d64565562fCc7e05e619A30615f0", feeWei: "12393688110727" }], optionalDvns: [] }, mode: "LOCAL_FORK_ONLY", submittedToMainnet: false, balanceOverrides: false, block: 135297691, nonce: 4751, request: { from: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789", to: "0x74c20dEB476Dca58459956b1AcD65771197900C9", data: "0x07f53ee70000000000000000000000000000000000000000000000000000000000000002", value: "0x1042d5715612f4", gasPrice: "0x2faf080", nonce: "0x128f", chainId: "0x38", gas: "0x734a6" }, nativeFeeWei: "4577084124304116", gasPriceWei: "50000000", estimatedGas: "377784", gasLimit: "472230", maximumGasWei: "23611500000000", actualLocalGasWei: "18510850000000", estimatedMaximumTotalWei: "4600695624304116", localTotalWei: "4595594974304116", proposedTotalCapWei: "6000000000000000", proposedMessageCapWei: "5900000000000000", proposedGasCapWei: "100000000000000", guid: "0xb46132353e03697bb27ed5581c3ac1b2e0a2ba1e365a11a388bcf0390cba6b99", payload: "0x0302f5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba0000000000000001c99c328de96599e4ea3332e097436cdc5bd542a0a479f892543b3008664128b3485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4", encodedPacket: "0x0100000000000000010000759600000000000000000000000074c20deb476dca58459956b1acd65771197900c9000076aac445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92b46132353e03697bb27ed5581c3ac1b2e0a2ba1e365a11a388bcf0390cba6b990302f5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba0000000000000001c99c328de96599e4ea3332e097436cdc5bd542a0a479f892543b3008664128b3485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4", options: "0x00030100110100000000000000000000000001c9c380", sendLibrary: "0x9F8C645f2D0b2159767Bd6E0839DE4BE49e823DE", sourceEid: 30102, destinationEid: 30378, sequence: 1, recipient: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4", redemption: "0xc99c328de96599e4ea3332e097436cdc5bd542a0a479f892543b3008664128b3", before: { stage: 5, block: "0x8107a9c", state: 3, generation: 1, purchasesPaused: true, canPlay: false, allowance: "0" }, after: { stage: 5, block: "0x8107a9d", state: 3, generation: 1, purchasesPaused: true, canPlay: false, allowance: "0" }, exactFeeRequired: true, wrongKindsRejected: true, receipt: { transactionHash: "0x302e62d4780e791c924cb4efa9864f3804634ef6faca44989fee55bcdbfbba72", transactionIndex: "0x0", blockNumber: "0x8107a9d", blockHash: "0xad7b4c198a66891a2a5bb7ec273202d8de9d5730bc269a226c5b6710b7840a8e", from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789", to: "0x74c20deb476dca58459956b1acd65771197900c9", cumulativeGasUsed: "0x5a629", gasUsed: "0x5a629", contractAddress: null, logs: [{ address: "0x9f8c645f2d0b2159767bd6e0839de4be49e823de", blockHash: "0xad7b4c198a66891a2a5bb7ec273202d8de9d5730bc269a226c5b6710b7840a8e", blockNumber: "0x8107a9d", data: "0x0000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d5848590000000000000000000000000000000000000000000000000010212735e6d8ce", logIndex: "0x0", removed: false, topics: ["0x61ed099e74a97a1d7f8bb0952a88ca8b7b8ebd00c126ea04671f92a81213318a"], transactionHash: "0x302e62d4780e791c924cb4efa9864f3804634ef6faca44989fee55bcdbfbba72", transactionIndex: "0x0" }, { address: "0x9f8c645f2d0b2159767bd6e0839de4be49e823de", blockHash: "0xad7b4c198a66891a2a5bb7ec273202d8de9d5730bc269a226c5b6710b7840a8e", blockNumber: "0x8107a9d", data: "0x000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000b45a160968700000000000000000000000000000000000000000000000000000b22f8ae0d1800000000000000000000000000000000000000000000000000000b45a1609687", logIndex: "0x1", removed: false, topics: ["0x07ea52d82345d6e838192107d8fd7123d9c2ec8e916cd0aad13fd2b60db24644"], transactionHash: "0x302e62d4780e791c924cb4efa9864f3804634ef6faca44989fee55bcdbfbba72", transactionIndex: "0x0" }, { address: "0x1a44076050125825900e736c501f859c50fe728c", blockHash: "0xad7b4c198a66891a2a5bb7ec273202d8de9d5730bc269a226c5b6710b7840a8e", blockNumber: "0x8107a9d", data: "0x000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000001800000000000000000000000009f8c645f2d0b2159767bd6e0839de4be49e823de00000000000000000000000000000000000000000000000000000000000000fb0100000000000000010000759600000000000000000000000074c20deb476dca58459956b1acd65771197900c9000076aac445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92b46132353e03697bb27ed5581c3ac1b2e0a2ba1e365a11a388bcf0390cba6b990302f5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba0000000000000001c99c328de96599e4ea3332e097436cdc5bd542a0a479f892543b3008664128b3485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c40000000000000000000000000000000000000000000000000000000000000000000000001600030100110100000000000000000000000001c9c38000000000000000000000", logIndex: "0x2", removed: false, topics: ["0x1ab700d4ced0c005b164c0f789fd09fcbb0156d4c2041b8a3bfbcd961cd1567f"], transactionHash: "0x302e62d4780e791c924cb4efa9864f3804634ef6faca44989fee55bcdbfbba72", transactionIndex: "0x0" }, { address: "0x74c20deb476dca58459956b1acd65771197900c9", blockHash: "0xad7b4c198a66891a2a5bb7ec273202d8de9d5730bc269a226c5b6710b7840a8e", blockNumber: "0x8107a9d", data: "0x00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", logIndex: "0x3", removed: false, topics: ["0x6d23cdaef17712141c7441cf202389c6ddc063fb5c14788d5c4479b62096d13f", "0xb46132353e03697bb27ed5581c3ac1b2e0a2ba1e365a11a388bcf0390cba6b99"], transactionHash: "0x302e62d4780e791c924cb4efa9864f3804634ef6faca44989fee55bcdbfbba72", transactionIndex: "0x0" }], logsBloom: "0x00000000060000000000000000000040000000000004000000000000001800000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000001000000000000000000000000000000000000000000000000000008000000000000000000000000010000000000000000001000000000000000000000000080000000000000000000000000000000000000000000000808000000000100000000000000000000000400000000444000000000000000000000008000000000000000000000000000000020000000000000000000000040000000000000000000000002000000000010000000000000000000000", status: "0x1", effectiveGasPrice: "0x2faf080", type: "0x0" } };
var v0 = Object.assign((t17, e = "Return fee validation failed") => {
  if (!t17) throw Error(e);
}, { equal: (t17, e) => {
  if (t17 !== e) throw Error("Return fee value differs");
}, deepEqual: (t17, e) => {
  if (JSON.stringify(t17) !== JSON.stringify(e)) throw Error("Required verifiers differ");
} });
var sr = new F(["event ExecutorFeePaid(address executor,uint256 fee)", "event DVNFeePaid(address[] requiredDVNs,address[] optionalDVNs,uint256[] fees)"]);
var ir = w0.defaultAbiCoder();
function or(t17, e) {
  let n = t17.logs.filter((f) => f.address.toLowerCase() === R.sendLibrary.toLowerCase());
  v0.equal(n.length, 2);
  let r = sr.parseLog(n[0]), a = sr.parseLog(n[1]);
  v0.equal(r.name, "ExecutorFeePaid"), v0.equal(a.name, "DVNFeePaid");
  let [, s] = ir.decode(["uint32", "address"], R.states[4].executor), [o] = ir.decode(["tuple(uint64 confirmations,uint8 requiredDVNCount,uint8 optionalDVNCount,uint8 optionalDVNThreshold,address[] requiredDVNs,address[] optionalDVNs)"], R.states[4].sendSecurity);
  return v0.equal(r.args.executor, s), v0.deepEqual(Array.from(a.args.requiredDVNs), Array.from(o.requiredDVNs)), v0.equal(a.args.optionalDVNs.length, 0), v0.equal(a.args.fees.length, 3), v0(r.args.fee > 0n && a.args.fees.every((f) => f > 0n)), v0.equal(r.args.fee + a.args.fees.reduce((f, c) => f + c, 0n), BigInt(e)), { executor: { address: s, feeWei: String(r.args.fee) }, requiredDvns: Array.from(a.args.requiredDVNs, (f, c) => ({ address: f, feeWei: String(a.args.fees[c]) })), optionalDvns: [] };
}
var S0 = { ...B, baseNonce: 4751, gasLimit: 6e5, guid: Q0.guid, payload: Q0.payload, packet: Q0.encodedPacket, options: Q0.options, sendLibrary: Q0.sendLibrary };
var fr = 6000000000000000n;
var O5 = 5900000000000000n;
var cr = 100000000000000n;
var n0 = (t17, e) => String(t17).toLowerCase() === String(e).toLowerCase();
var Ke = new F(x.adapter.abi);
var dr = new F(["function outboundNonce(address,uint32,bytes32)view returns(uint64)", "event PacketSent(bytes encodedPayload,bytes options,address sendLibrary)"]);
var ur = "0x1a44076050125825900e736c501f859c50fE728c";
function c1(t17, e = 0) {
  h(e === 0, "Only one return send is approved"), h(Object.keys(t17).every((s) => ["from", "to", "data", "value", "chainId", "nonce", "gas", "gasPrice"].includes(s)), "Unexpected transaction field"), h(n0(t17.from, x.admin) && n0(t17.to, x.addresses.adapter), "Wrong sender or adapter"), h(t17.data === Ke.encodeFunctionData("send", [2]), "Only send(2) is approved"), h(BigInt(t17.chainId) === 56n && BigInt(t17.nonce) === 4751n, "Wrong chain or nonce");
  let n = BigInt(t17.value), r = BigInt(t17.gas), a = BigInt(t17.gasPrice);
  h(n > 0n && n <= O5 && r === 600000n && a > 0n && r * a <= cr && n + r * a <= fr, "Approved fee ceiling exceeded");
}
function P5(t17) {
  h(t17?.schema === 1 && t17.baseNonce === S0.baseNonce, "Wrong return sequence"), h(Array.isArray(t17.hashes) && t17.hashes.length <= 1 && Array.isArray(t17.requests) && t17.requests.length === t17.hashes.length, "Invalid return progress");
  for (let e of t17.hashes) h(/^0x[0-9a-f]{64}$/i.test(e), "Invalid hash");
  for (let e of t17.requests) c1(e);
  t17.attempt && (h(!t17.hashes.length && t17.attempt.index === 0, "Invalid unresolved request"), c1(t17.attempt.request));
}
function N5(t17, e, n) {
  c1(n), h(t17 && e && BigInt(e.status) === 1n, "Source transaction unavailable or failed; do not resend"), h(n0(t17.hash, e.transactionHash) && n0(t17.blockHash, e.blockHash), "Receipt identity differs"), h(n0(t17.from, x.admin) && n0(t17.to, x.addresses.adapter) && BigInt(t17.nonce) === 4751n && (t17.input ?? t17.data) === n.data && BigInt(t17.value) === BigInt(n.value), "Submitted return intent differs");
  let r = t17.chainId != null ? BigInt(t17.chainId) : (BigInt(t17.v ?? 0) - 35n) / 2n;
  h(r === 56n && !e.contractAddress, "Wrong chain or deployment");
  let a = BigInt(t17.maxFeePerGas ?? t17.gasPrice), s = BigInt(e.effectiveGasPrice ?? t17.gasPrice), o = BigInt(e.gasUsed);
  h(BigInt(t17.gas) <= BigInt(n.gas) && a <= BigInt(n.gasPrice) && o <= BigInt(t17.gas) && s <= a, "Wallet increased fee limits"), h(e.logs.length === 4 && !e.logs.some((g) => g.removed), "Unexpected source events");
  let f = e.logs.filter((g) => n0(g.address, ur)).map((g) => dr.parseLog(g)), c = e.logs.filter((g) => n0(g.address, x.addresses.adapter)).map((g) => Ke.parseLog(g));
  h(f.length === 1 && f[0]?.name === "PacketSent" && f[0].args.encodedPayload === S0.packet && f[0].args.options === S0.options && n0(f[0].args.sendLibrary, S0.sendLibrary), "Packet differs"), h(c.length === 1 && c[0]?.name === "MessageSent" && c[0].args.guid === S0.guid && c[0].args.kind === 2n && c[0].args.generation === 1n, "Return message differs");
  let d = or(e, BigInt(n.value)), u = o * s;
  return h(u <= cr && u + BigInt(n.value) <= fr, "Actual fees exceed cap"), { gasWei: String(u), messageFeeWei: String(BigInt(n.value)), totalWei: String(u + BigInt(n.value)), fees: d };
}
async function R5(t17, e) {
  P5(e);
  let n = await rr(t17, ar);
  h(n.complete && n.state === 3 && !n.canPlay, "The pass must stay locked");
  let r = V0(t17), a = await r("eth_blockNumber"), s = async (p, m, E, S = []) => m.decodeFunctionResult(E, await r("eth_call", [{ to: p, data: m.encodeFunctionData(E, S) }, a]));
  h((await s(x.addresses.adapter, Ke, "outboundPayload", [2]))[0] === S0.payload && (await s(x.addresses.adapter, Ke, "receiveOptions"))[0] === S0.options, "Locked payload or receive options changed");
  let o = (await s(ur, dr, "outboundNonce", [x.addresses.adapter, 30378, x.peer]))[0];
  if (h(o === BigInt(e.hashes.length), "A return message already exists or saved progress differs. Recover its receipt; do not resend."), !e.hashes.length) return { complete: false, stage: 0, block: a };
  let f = e.hashes[0], c = await r("eth_getTransactionByHash", [f]), d = await r("eth_getTransactionReceipt", [f]);
  h(n0(c?.hash, f) && n0(d?.transactionHash, f), "Receipt not indexed; do not resend");
  let u = N5(c, d, e.requests[0]), g = await r("eth_getBlockByNumber", [d.blockNumber, false]);
  return h(n0(g?.hash, d.blockHash), "Receipt block changed"), { complete: true, stage: 1, block: a, ...u, receipt: d, guid: S0.guid, payload: S0.payload, sourceVerified: true, destinationVerified: false };
}

// docs/multichain/generation-milestone/return-completed/session.json
var session_default = {
  schema: 1,
  baseNonce: 4751,
  hashes: [
    "0xedb9edeecf1fd27e8851e57e436d9a7944933d9f0c85101d4f59be3e2f87e3b0"
  ],
  requests: [
    {
      from: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789",
      to: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
      data: "0x07f53ee70000000000000000000000000000000000000000000000000000000000000002",
      value: "0x1042d5715612f4",
      chainId: "0x38",
      nonce: "0x128f",
      gas: "0x927c0",
      gasPrice: "0x2faf080"
    }
  ],
  attempt: null
};

// docs/multichain/generation-milestone/acknowledgement-review/before.json
var before_default = {
  current: {
    chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
    checkpoint: {
      sequenceNumber: 348405336,
      timestamp: "2026-11-23T16:30:17.051Z"
    },
    endpoint: {
      address: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
      version: 1096510922,
      digest: "9o4Ns6gwz7FmuGreY6LA1i1JokDsGsbuDksV9Kf9zSnJ",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 635685314
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::endpoint_v2::EndpointV2"
          },
          json: {
            id: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
            eid: 30378,
            call_cap: {
              id: "0x8de954b904b90f887ff2e81ff3362ca89e883da6529e55723758cd5093234b0d",
              cap_type: {
                "@variant": "Package",
                pos0: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac"
              }
            },
            oapp_registry: {
              oapps: {
                id: "0x720fc2300c05bb7ad68aefec00a9796b4451c4d1df78bc72cd8c98e774220bec",
                size: "143"
              }
            },
            composer_registry: {
              composers: {
                id: "0xb41ca35805177b946bebf5d339712b4e9bb562b068b33851001f9f0b66847814",
                size: "7"
              }
            },
            message_lib_manager: {
              registry: {
                libs: {
                  contents: {
                    id: "0x520bbc08883e22efb29f50283e25b4561ffa7c7b9d7774b14fc1c6272e593e03",
                    size: "2"
                  }
                },
                lib_to_type: {
                  id: "0xb136bb2fc780a76e636c10f10b10ab33754a3573efa5f1285bf2b35eaf73b50d",
                  size: "2"
                }
              },
              default_configs: {
                id: "0xa2371851318b3ba333270daf696dedbc7b89a1107ca362643798c1789ce05a01",
                size: "126"
              },
              oapp_configs: {
                id: "0x0e679b0fcc94fb07a5ec9a14712f8e35e0994b892e64a434e898450eb670e920",
                size: "101"
              }
            }
          }
        }
      }
    },
    uln: {
      address: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
      version: 1096510922,
      digest: "DZyejj6bY4E6EmLaw3kgsWXera1RVmgwL8xLDHrLVhCt",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 635685319
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0::uln_302::Uln302"
          },
          json: {
            id: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
            call_cap: {
              id: "0xfacd801d08e3a99c907148fa00ec5f17a0a3ac831dbc95bcd75e601006caafa9",
              cap_type: {
                "@variant": "Package",
                pos0: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0"
              }
            },
            send_uln: {
              default_executor_configs: {
                id: "0x346b468d90db8743673c7ed4fdbe1c40f6a587aac6acc730b3a9bb86cf0919f4",
                size: "126"
              },
              default_uln_configs: {
                id: "0x2bd7d044d837b718a7852959c701c04e842e648cf9047b442d55c838846a13e5",
                size: "126"
              },
              oapp_executor_configs: {
                id: "0x357a98886ef14de3d15e538a808b410cfe026f6b1f971bb2398978d56e4dc181",
                size: "55"
              },
              oapp_uln_configs: {
                id: "0xc53b8a5592cdeea1a7421d209ba5c70e6843d2911e5bb86ad9fb744d888eab60",
                size: "215"
              }
            },
            receive_uln: {
              default_uln_configs: {
                id: "0x5ddc28272722231ecef30237bb48715f128d6995b89a46db25cd9adae0140835",
                size: "126"
              },
              oapp_uln_configs: {
                id: "0x0d89da4d00f46c4b1dab465a867e60eacbf646e56f8816ae55cd7b9495c1bb09",
                size: "240"
              },
              verification: "0x950f66ed27ec0a01a52bda147d74165d4cc20165f0cee0ecae6aaacde13d7741"
            }
          }
        }
      }
    },
    oapp: {
      address: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
      version: 1106221114,
      digest: "7SgwU4oGTynAF4e7mh15ZnMjPBahXEvGBh2mwB66qQ8p",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::OApp"
          },
          json: {
            id: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            oapp_cap: {
              id: "0x6b7c66d2135ce12efa6a23037bff2e5ca1b499db24bc200592d08c2595cf5a3a",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            admin_cap: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
            peer: {
              peers: {
                id: "0x984eb93d6713b0909152e249bcfa465a6661e7403c5b01266353b97ff2318966",
                size: "1"
              }
            },
            enforced_options: {
              options: {
                id: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
                size: "2"
              }
            },
            sending_call: null
          }
        }
      }
    },
    admin: {
      address: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
      version: 1096510923,
      digest: "CXbdvybk5zVFVkPzd7imMGpj85r974bT5B1dMhCybeWo",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::AdminCap"
          },
          json: {
            id: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d"
          }
        }
      }
    },
    vault: {
      address: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
      version: 1106768687,
      digest: "4fAKyArwHnnWqZL4Sbc4S85HHBXJAkz9bYvoHxwT983b",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 2
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Vault<0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT>"
          },
          json: {
            id: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
            version: "1",
            registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
            cap: {
              id: "0x1711b6b0e442e8299ea3aceb30286234520c8f1c4d2294aa7d031308a3d7bcff",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            nft: null,
            backing: {
              bytes: "BG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWpro="
            },
            route: {
              bytes: "9d/44syWgk+Jc1+hbAaO6BlPu36NaXruvl0TX4pZFus="
            },
            peer: {
              bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
            },
            bound: true,
            paused: false,
            phase: 2,
            generation: "1",
            announced: true,
            ack_sent: false,
            request: {
              bytes: "yZwyjellmeTqMzLgl0Ns3FvVQqCkefiSVDswCGZBKLM="
            },
            recipient: {
              bytes: "SFlT4urfSqAq+VDPjpFPvStnUjOF5zw2EYNBRZ2NRcQ="
            }
          }
        }
      }
    },
    channel: {
      address: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
      version: 1106768687,
      digest: "uvDrQHntMRsvx5c2wAtNEZ8aytYRGBWrmeiubLYfLVW",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1089269258
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::MessagingChannel"
          },
          json: {
            id: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
            oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            channels: {
              id: "0xc631f02da694ee43bc4923570de9f6d53cbccbdb72986cf63dc84e77744c0e95",
              size: "1"
            },
            is_sending: false
          }
        }
      }
    },
    registration: {
      address: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
      version: 1096510922,
      digest: "8fcLbkwf639cvZt7t54EXo4wypKhLcodVebYfKcCzBx7",
      owner: {
        __typename: "ObjectOwner"
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<address,0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::oapp_registry::OAppRegistration>"
          },
          json: {
            id: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
            name: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            value: {
              messaging_channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
              oapp_info: "AAENo9hF9KsYoKjS8GaXIqHZFhwuphrXFKvBTUFHIf0U5ADwAQABAcRFUZvx1u2KtgAtIK1+2Bqa0l4xmQ35tyID0K2G/S6SBXZhdWx0Cmx6X3JlY2VpdmUDAfXf+OLMloJPiXNfoWwGjugZT7t+jWl67r5dE1+KWRbrAQ2j2EX0qxigqNLwZpciodkWHC6mGtcUq8FNQUch/RTkACBkICYW91pWFKz6JkQYJYUhKZ62qJLu7qOS/u+JSMfrUwFTMHhmNmM2ZDQzOWVhMGRhMmYzZTliYTc5ZTQ5OTJhN2E0YzExMzIxNWZiZjU0YzQ0MmFjOTAyMGMzMTVmOTUzNzA1Ojpjb2xsZWN0aW9uOjpORlQAAAA=",
              delegate: "0x0000000000000000000000000000000000000000000000000000000000000000"
            }
          }
        }
      }
    },
    libraries: {
      dynamicField: {
        value: {
          json: {
            send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib_timeout: null
          }
        }
      }
    },
    send: {
      dynamicField: {
        value: {
          json: {
            confirmations: "5",
            required_dvns: [
              "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
              "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
              "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
              "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
            ],
            optional_dvns: [],
            optional_dvn_threshold: 0
          }
        }
      }
    },
    receive: {
      dynamicField: {
        value: {
          json: {
            confirmations: "20",
            required_dvns: [
              "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
              "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
              "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
              "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
            ],
            optional_dvns: [],
            optional_dvn_threshold: 0
          }
        }
      }
    },
    executor: {
      dynamicField: {
        value: {
          json: {
            max_message_size: "10000",
            executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
          }
        }
      }
    },
    appLibraries: {
      dynamicField: {
        value: {
          json: {
            send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib_timeout: null
          }
        }
      }
    },
    appSend: {
      dynamicField: {
        value: {
          json: {
            use_default_confirmations: false,
            use_default_required_dvns: false,
            use_default_optional_dvns: false,
            uln_config: {
              confirmations: "5",
              required_dvns: [
                "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
                "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
                "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
              ],
              optional_dvns: [],
              optional_dvn_threshold: 0
            }
          }
        }
      }
    },
    appReceive: {
      dynamicField: {
        value: {
          json: {
            use_default_confirmations: false,
            use_default_required_dvns: false,
            use_default_optional_dvns: false,
            uln_config: {
              confirmations: "20",
              required_dvns: [
                "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
                "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
                "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
              ],
              optional_dvns: [],
              optional_dvn_threshold: 0
            }
          }
        }
      }
    },
    appExecutor: {
      dynamicField: {
        value: {
          json: {
            max_message_size: "10000",
            executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
          }
        }
      }
    }
  },
  candidate: {
    chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
    checkpoint: {
      sequenceNumber: 348405336,
      timestamp: "2026-11-23T16:30:17.051Z"
    },
    nft: {
      address: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
      version: 1106768687,
      digest: "EVdjowwEmsL8cpGCC2Wq3HZdax5VnGfGqR95FXNKJWgc",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
          },
          json: {
            id: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
            number: "2720",
            name: "Tree NFT #2720",
            description: "A unique tree from the Tree NFT collection. Rarity: Common",
            image_url: "https://black-persistent-capybara-279.mypinata.cloud/ipfs/bafybeieozgvnr7qc4ghsq36zwssuhj7xahuznjlmu6g63clnyt37hjsi4m/2720.jpg",
            rarity: "Common"
          }
        }
      }
    }
  }
};

// contracts/nftree-generation/scripts/acknowledgement-handoff.mjs
async function bnb() {
  let id = 0;
  const allowed = /* @__PURE__ */ new Set(["eth_chainId", "eth_blockNumber", "eth_getCode", "eth_call", "eth_getTransactionByHash", "eth_getTransactionReceipt", "eth_getBlockByNumber"]);
  const provider = { request: async (q2) => {
    assert5(allowed.has(q2.method));
    const r = await fetch("https://bsc-rpc.publicnode.com", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: ++id, ...q2 }), signal: AbortSignal.timeout(2e4) }), j = await r.json();
    assert5(r.ok && !j.error);
    return j.result;
  } };
  const p = await R5(provider, session_default);
  assert5(p.complete && p.sourceVerified);
  return { complete: true, sourceVerified: true, state: "Locked", purchasesPaused: true, canPlay: false, guid: p.guid, block: p.block };
}
async function state(client, ack = false) {
  const r = await client.query({ query: STATE_QUERY });
  assert5(!r.errors);
  const s = r.data;
  assert5(Math.abs(Date.now() - Date.parse(s.checkpoint.timestamp)) < 12e4);
  validateAcknowledgementState(s, ack);
  return s;
}
async function prepareAcknowledgementHandoff(client = newClient()) {
  const before = { current: await state(client), candidate: await readCandidate(client), bnb: await bnb() };
  validateAcknowledgementBefore(before);
  const q2 = acknowledgementTransaction("quote"), qb = await q2.build({ client }), qr2 = await client.core.simulateTransaction({ transaction: qb, checksEnabled: true, doGasSelection: false, include: { commandResults: true } });
  assert5(qr2.Transaction.status.success);
  const fee = BigInt(bcs3.u64().parse(Uint8Array.from(qr2.commandResults.at(-2).returnValues[0].bcs)));
  assert5.equal(BigInt(bcs3.u64().parse(Uint8Array.from(qr2.commandResults.at(-1).returnValues[0].bcs))), 0n);
  assert5(fee > 0n && fee <= MESSAGE_CAP);
  const balance = await client.core.getBalance({ owner: C2.sender });
  assert5(BigInt(balance.balance.addressBalance) >= fee + GAS_CAP, "Insufficient SUI address balance for message fee and maximum gas");
  const tx = acknowledgementTransaction("send", fee), bytes = await tx.build({ client }), simulation = await client.core.simulateTransaction({ transaction: bytes, checksEnabled: true, doGasSelection: false, include: { effects: true, events: true, transaction: true, balanceChanges: true, objectTypes: true, bcs: true } });
  assert5.deepEqual(Buffer.from(Object.values(simulation.Transaction.bcs)), Buffer.from(bytes));
  const post = await client.query({ query: POST_QUERY, variables: { tx: { bcs: { value: Buffer.from(bytes).toString("base64") } } } });
  const proof = verifyAcknowledgement(simulation, JSON.parse(await tx.toJSON()), before, post, fee);
  const after = { current: await state(client), candidate: await readCandidate(client), bnb: await bnb() };
  validateAcknowledgementBefore(after);
  for (const n of ["vault", "oapp", "channel", "admin", "registration", "appSend", "appReceive", "appLibraries", "appExecutor"]) assert5.equal(canonical(before.current[n]), canonical(after.current[n]));
  assert5.deepEqual(before.candidate.nft, after.candidate.nft);
  return { schema: "tree-generation-acknowledgement-handoff-v1", preparedAt: Date.now(), transactionBase64: Buffer.from(bytes).toString("base64"), messageFeeMist: String(fee), estimatedNetGasMist: proof.netGasMist, estimatedTotalMist: proof.estimatedTotalMist, before, after, simulation, post, proof };
}
async function verifyAcknowledgementReceipt(digest, client = newClient()) {
  const result = await client.core.getTransaction({ digest, include: { effects: true, events: true, transaction: true, balanceChanges: true, objectTypes: true, bcs: true } });
  assert5.equal(result.Transaction?.digest, digest);
  const t17 = result.Transaction, fee = BigInt(t17.transaction.inputs[4].FundsWithdrawal.reservation.MaxAmountU64), expected = acknowledgementTransaction("send", fee);
  const ids = t17.effects.changedObjects.filter((x2) => x2.outputState === "ObjectWrite").map((x2) => x2.objectId), r = await client.query({ query: "query{checkpoint{sequenceNumber timestamp} " + ids.map((id, i2) => "o" + i2 + ':object(address:"' + id + '"){' + fields + "}").join(" ") + "}" });
  assert5(!r.errors);
  assert5(Math.abs(Date.now() - Date.parse(r.data.checkpoint.timestamp)) < 12e4);
  const objects = Object.entries(r.data).filter(([k2]) => k2 !== "checkpoint").map(([, o]) => o);
  const post = { data: { simulateTransaction: { effects: { status: "SUCCESS", objectChanges: { pageInfo: { hasNextPage: false }, nodes: objects.map((o) => ({ address: o.address, outputState: { asMoveObject: o.asMoveObject } })) } } } } };
  const proof = verifyAcknowledgement(result, JSON.parse(await expected.toJSON()), before_default, post, fee);
  await state(client, true);
  return { digest, packageId: C2.package, vaultId: C2.vault, originalNft: C2.nft, ...proof, submitted: true, sourceVerified: true, phase: 2, generation: 1, ackSent: true, checkpoint: r.data.checkpoint, destinationVerified: false, destinationStatus: "not checked" };
}

// netlify/preview-functions/generation-acknowledgement.mjs
var config = { path: "/api/generation-acknowledgement" };
async function handler(request) {
  const headers = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };
  if (request.method !== "GET") return new Response("Read-only endpoint", { status: 405, headers });
  try {
    const url = new URL(request.url), digest = url.searchParams.get("digest");
    if (digest) {
      if (!/^[1-9A-HJ-NP-Za-km-z]{43,44}$/.test(digest) || [...url.searchParams].length !== 1) throw Error("Invalid receipt request");
      return Response.json(await verifyAcknowledgementReceipt(digest), { headers });
    }
    if (url.search) throw Error("Unexpected parameters");
    return Response.json(await prepareAcknowledgementHandoff(), { headers });
  } catch (e) {
    return Response.json({ error: String(e.message) }, { status: 502, headers });
  }
}
export {
  config,
  handler as default
};
/*! Bundled license information:

@noble/hashes/esm/utils.js:
  (*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) *)

@scure/base/index.js:
  (*! scure-base - MIT License (c) 2022 Paul Miller (paulmillr.com) *)
*/
