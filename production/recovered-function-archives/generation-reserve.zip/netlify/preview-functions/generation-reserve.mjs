
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// contracts/nftree-generation/scripts/reserve-handoff.mjs
import assert11 from "node:assert/strict";
import { bcs as bcs3 } from "@mysten/sui/bcs";

// contracts/nftree-generation/scripts/readiness.mjs
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { Transaction } from "@mysten/sui/transactions";
import { SuiGraphQLClient } from "@mysten/sui/graphql";
import { bcs } from "@mysten/sui/bcs";

// docs/multichain/generation-milestone/publication-bytecode.json
var publication_bytecode_default = { modules: ["oRzrCwcAAAUJAQAGAgYEAwofBCkCBSs+B2lLCLQBYAaUAg4MogLrAwADAQgCAgIABwAABQABAAAEAgAAAAkDBAABAQkHAQACBgEEAAIHCAEAAwYGAggACAADCAAIAAEKAgEGCgICBgoCAwEIAAMBAgoCAQIAAQYIAAIHCgkACgkABQEBAwMCBgIHCgIDAwMKAgdCeXRlczMyBmFwcGVuZAdieXRlczMyBWNvZGVjBmRlY29kZQZlbmNvZGUKZnJvbV9ieXRlcwh0b19ieXRlcwZ2ZWN0b3IEd29yZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAJFujb3ocxkOisDdFDf8eQ5nhgGnGVF+1/KrzfTnX3AMIZAAAAAAAAAAKAgEAAAEAAAVCCgAxASYEEAoAMQQlBA0KAwYAAAAAAAAAACQMBgUSCQwGBRIJDAYLBgQVBRcHACcxAwsAQAYCAAAAAAAAAAwIDQgOAREFOAANCA4CEQU4ADEIDAcKBzEAJAQ4CwcxARcMBw0ICgMKBzEIGDAG/wAAAAAAAAAcM0QGBSUNCA4EEQU4AA0IDgURBTgACwgCAAEBAAAKXAoAQQYGigAAAAAAAAAhBA0KAAYAAAAAAAAAAEIGFDEDIQwBBQ8JDAELAQQSBRYLAAEHACcKAAYBAAAAAAAAAEIGFAwFCgUxASYEJAoFMQQlDAIFJgkMAgsCBCkFLQsAAQcAJwYAAAAAAAAAAAwDBkIAAAAAAAAADAQKBAZKAAAAAAAAACMERAsDMQgvCgAKBEIGFDQbDAMLBAYBAAAAAAAAABYMBAUxCgMGAAAAAAAAAAAkBEkFTQsAAQcAJwsFCgAGAgAAAAAAAAARAgoABiIAAAAAAAAAEQILAwoABkoAAAAAAAAAEQILAAZqAAAAAAAAABECAgACAAAACyIHAQwHBgAAAAAAAAAADAYKBgYgAAAAAAAAACMEHQoGDAQNBwwDCwQMBQoACgELBRZCBhQMAgsDCwJEBgsGBgEAAAAAAAAAFgwGBQQLAAELBxEEAgAA", "oRzrCwcAAAUNAQAuAi6KAQO4AfUCBK0ESAX1BLQFB6kKmwkIxBOAAgbEFbUCCvkXoAELmRkCDJsZpRQNwC0uDu4tIAB6BCgEKQU5BToFOwVOBVAFUQVSACsHWAEjAVoBdwIsAjwCWQJzAnUCdgMnBn8AGwIAAAAIAAASCAAAHAgBDAAAFgMAAAgDAAAGAwAAAQMAABADAAATAwABAwACAAAAAAEdBwACBAwAAxEHAAQVAAAFBwgABgoAAAcLCAAIDAcACQ0HAAsADAALDggADBcHAA0PBwEAAA4ZBwAPBQwBAAERCQcAERoEABIUAgAUGAIAFQIHABYeAgAASAABAABUAgMAAGcEAQAAewUBAQwAMQYBAQwAQgcBAQwAbggBAQwAZAkKAQwAJQsBAQwAeQwBAQwATg0BAQwAYA4BAQwAXA8QAQwAPREQAABiEhMBDABrFBUBDAAwFhcBDAAvGBkBDABfGhsBDABqGhwBDAAkGhwBDABdDxABDABDGh0BDAAhGh4BDABFGh4BDABoGh8BDABxICEAADMBIgAAXhocAQwFZT0KAAY0RkcACjJKSwAKOEsQAAstUBAACy5VFwALL1YZAAtEQxwAC05FRgALT1QVAAtTJicBAgtiUhMAC21BAQALb0ABAAxJMxAADTUwAQEADT42LgEADT83AQEADUs0HgEADUw0HgEADVcBMAEADXIuMAEADkoyMwAOfQEyAQAQNy4BAQMRRiofAQgRRyoKAQgRUygpABF4NR8AE2EsAQEME3AuAQEIE3UsAQEIFGwkCgAVQAocABVBHxwAFU0/HgAVdD8KABV+ARwAJyU2AzorPC07AzIvMR80Li8fMC8tLzEuLh81ODs5Ly42Li4uNjk1OwMuNTw3PjVCCS4vSCxICy41TDAuLS46LjVNDC4xUzIKAggABwgdAAUIDAUFCgIHCB0BCAICBggCBggBAgYLAwEJAAYIAQMHCAIGCAEHCB0CBwsDAQkACQADBwsDAQkABggBAQUGCwMBCQAGCAEHCA8KAgcIHQEFCAcLAwEJAAYIAQcIFQYIFAYIDwcIEQgeBwgdAgYLAwEJAAYIFQMHCwMBCQAGCBULCgIIEAgLAgcLAwEJAAYKAgIGCwMBCQACAQoCAwYIFQIKAgUGCwMBCQAGCBUCCgIHCB0BCwoCCA0IEgYHCwMBCQAHCBUCCgILGQEIHAcIHQELCgIIDggTAwYLAwEJAAcIFQsKAggOCBMCCA4IEwMGCwMBCQAGCBULCgIIDQgSAggNCBIBBgsDAQkAAQIBCB4BAwEBAQgaAQYIAgELFwEIGgEOBAgBBQgUCAIBBggdAQgAAgYJAAcIHQMIDAgUBQEHCB0BCBsBBgkAAQgUAgkABQEIAQEJAAEIDAELFwEJAAQBCBsLAwEJAAgaAQgYAQgWAQYLFwEJAAEGCBsBBwsXAQkAAgcLFwEJAAkAAQgEAQsDAQkAAgEBAQgFAQgIBAcIDwYIDAoCBwgdAQgVAQYIHgcHCBUGCBQGCA8HCBEOCB4HCB0FBwgVBggUDg0KAgEIBwIGCBUOBAEKAggeCxcBCxkBCBwDBggVBggMCwoCCBAICwEIEAgOCB4DCB4KAgUKAgsXAQsZAQgcAQsZAQgcDwEBAQEBAQEBAQMCCB4IHggeCB4BBgoCBgIIHggeAwgeCB4BCAYBCAkEAQEBCgINDQoCAQEBAQoCBAMNAwMEBAYIFQ4NCgICCgIKAgcGCBUGCAwOCgIKAgEHCB0BCxkBCB8JBwgVBggMDgoCCgILGQEIHAsXAQsZAQgfCxcBBQcIHQMHCBUGCAwLCgIIDggTAwYIFQYIDAsKAggNCBIIQWRtaW5DYXAFQm91bmQHQnl0ZXMzMgRDYWxsB0NhbGxDYXAEQ29pbglDb21wbGV0ZWQKRW5kcG9pbnRWMgZGdW5kZWQCSUQOTHpSZWNlaXZlUGFyYW0QTWVzc2FnaW5nQ2hhbm5lbAxNZXNzYWdpbmdGZWUQTWVzc2FnaW5nUmVjZWlwdARPQXBwBk9wdGlvbgxQYXVzZUNoYW5nZWQKUXVvdGVQYXJhbQhSZWdpc3RyeQhSZWxlYXNlZANTVUkJU2VuZFBhcmFtC1Nsb3RDcmVhdGVkBlN0cmluZwlUeENvbnRleHQIVHlwZU5hbWUDVUlEBVZBVUxUBVZhdWx0BFZvaWQDWlJPCGFja19zZW50B2FkYXB0ZXIJYWxsb2NhdGVkCWFubm91bmNlZAVhc2NpaQdiYWNraW5nBGJpbmQFYm91bmQHYnl0ZXMzMgRjYWxsCGNhbGxfY2FwA2NhcAVjb2RlYwRjb2luD2NvbWJpbmVfb3B0aW9ucw9jb25maXJtX2x6X3NlbmQNY29uZmlybV9xdW90ZQxjb25maXJtX3NlbmQLY3JlYXRlX3Nsb3QGZGVjb2RlC2Rlc3RpbmF0aW9uB2Rlc3Ryb3kMZGVzdHJveV9ub25lC2R1bW15X2ZpZWxkBGVtaXQGZW5jb2RlDmVuZHBvaW50X3F1b3RlDWVuZHBvaW50X3NlbmQLZW5kcG9pbnRfdjIFZXZlbnQRZXhlY3V0aW9uX29wdGlvbnMHZXh0cmFjdARmaWxsDGZyb21fYWRkcmVzcwdmcm9tX2lkBGZ1bmQKZ2VuZXJhdGlvbghnZXRfcGVlcgRoZWxkAmlkCmlkX2FkZHJlc3MEaW5pdAppbnRvX2J5dGVzC2ludG9fc3RyaW5nB2lzX25vbmUHaXNfc29tZQdpc196ZXJvCmx6X3JlY2VpdmUHbHpfc2VuZBFtZXNzYWdpbmdfY2hhbm5lbA1tZXNzYWdpbmdfZmVlEW1lc3NhZ2luZ19yZWNlaXB0A25ldwxuZXdfcmVnaXN0cnkDbmZ0CG5mdF90eXBlBG5vbmUEb2FwcAZvYmplY3QGb3B0aW9uBnBhdXNlZAdwYXlsb2FkEnBheWxvYWRfZm9yX3JldmlldwRwZWVyBXBoYXNlB3Byb2Nlc3MPcHVibGljX3RyYW5zZmVyBXF1b3RlCXJlY2lwaWVudAhyZWdpc3Rlcg1yZWdpc3Rlcl9vYXBwCHJlZ2lzdHJ5DnJlZ2lzdHJ5X2FkbWluC3JlZ2lzdHJ5X2lkB3JlcXVlc3QFcm91dGUEc2VuZAZzZW5kZXIUc2V0X2VuZm9yY2VkX29wdGlvbnMKc2V0X3BhdXNlZAhzZXRfcGVlcgxzaGFyZV9vYmplY3QEc2xvdARzb21lA3N1aQp0b19hZGRyZXNzCHRyYW5zZmVyCnR4X2NvbnRleHQJdHlwZV9uYW1lDHVpZF90b19pbm5lcgh2YWxpZGF0ZQV2YXVsdAt2YXVsdF9hZG1pbgd2ZXJzaW9uEXdpdGhfb3JpZ2luYWxfaWRzDHplcm9fYnl0ZXMzMgN6cm8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAJFujb3ocxkOisDdFDf8eQ5nhgGnGVF+1/KrzfTnX3Cjeno4IemNHABkH+2mP34qwRns0Iim3SxkmQGeuvErpMb6u+Imwi5w7N9GSgPwfi3W65bLeJBD8MSD0A+mjbaw94VBM8/11didZ41PZ2VOJYY5VfQVSaX8ZtS5Oknwd7v3CivwBEMsu25Tj5X8rHOabWpnFA7BtFeUc+iEt5W4kAwgBAAAAAAAAAA4ElnUAAAUgBG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWproFIEhZU+Lq30qgKvlQz46RT70rZ1Izhec8NhGDQUWdjUXECgJSUWY2YzZkNDM5ZWEwZGEyZjNlOWJhNzllNDk5MmE3YTRjMTEzMjE1ZmJmNTRjNDQyYWM5MDIwYzMxNWY5NTM3MDU6OmNvbGxlY3Rpb246Ok5GVAMIAgAAAAAAAAADCAMAAAAAAAAAAwgEAAAAAAAAAAMIBQAAAAAAAAADCAYAAAAAAAAAAwgHAAAAAAAAAAMICAAAAAAAAAADCAkAAAAAAAAAAwgKAAAAAAAAAAMICwAAAAAAAAADCAwAAAAAAAAACgIXFgADAQARAQAAAAAAAAAAAAAAAAADDUAKAgEAAAIBNgEBAgJGCBtmCBoCAgdGCBt8AyoLFwEIDFgFcQsXAQgaJAVWCgIDAhFGCBt8A2YIGioIDFgFVQsXAQkAJAgeaggeXggeJgFbAV8CQwMiAR8BaQgeYwgeBAIDZggaeggaVQgeBQIFeggaVQgeQwMzDiAIHgYCA3oIGkMDaQgeBwICeggaXggeCAICeggaWwEJAgR6CBpDA2kIHmMIHgMuAAAAACMpCgEuET0HAyEEBwULCwEBBwAnDgAKATgADAMMBAsDBwIHBAoBEQEMBQoBETgOBTgBEgEMAgsECgEuET04AgsCCwEuET04AwsFOAQCAAEAAAABCwsEETgHAAsAOAULATgGCwILAxICAgACAAAAARgKABAAFAcAIQQHBQ0LAAELAQEHDicLARABFAsAOAEhBBUFFwcAJwIAAwAAAAEZCgA3ABQHACEEBwUNCwABCwEBBw4nCwEQARQLADcBFCEEFgUYBwAnAgAEAQAAMVoKAC4LARECOAcRMxErCgAQBBQhBA0FEwsAAQsCAQcFJwoAEAU4CAQcCgAQBjgJDAMFHgkMAwsDBCEFJwsAAQsCAQcGJwsCETgMBA4EETkMBgsEBwAKAC44AQoADwY4CgoAEAcUOAsKABAIFBE+CgYRPxFCCQkxAAYAAAAAAAAAAAkJEUIRQjkADAUKAA8FCgY4DAsALjgBCwYOBTcCFBIEOA0LBTgOAgAFAQAAOngKADcAFAcAIQQHBQsLAAEHDicKADcDFCAEEQUVCwABBw0nCgA3BBQxACEEHggMAwUkCgA3BBQxAyEMAwsDBDIKADcFOA8ELwoANwYUDAIFNAkMAgU0CQwCCwIENwU7CwABBwgnDgE4EBE/CgA3AhQhBEQFSAsAAQcHJwoANwcUBgEAAAAAAAAAFgoANgcVCgA2BQsBOBExAQoANgQVCQoANggVCQoANgkVEUIKADYKFRFCCgA2CxUKAC44EgoANwIUCgA3BxQHAQsANwwUEgU4EwIABgEAAAEPCgAuCwE4FAoCCgA2AxULAC44EgsCEgg4FQIABwEAAAEKCgALATgUCwILADcNCwMLBBEdAgAIAQAAOmYKAC4LATgUCgA3BhQgBBAKADcEFDEAIQwIBRIJDAgLCAQVBSMLAAELAwELAgELBAELBwELBQEHCCcKAi44FgoANw4UIQQwDgYRQCAMCQUyCQwJCwkENQVDCwABCwMBCwIBCwQBCwcBCwUBBwknCgIKAwsECwUHAQoGCwcRKgoCCgMHAUgBAAcQESkLAgsDBwFIAwAHEBEpCgYKADYMFQgKADYGFQsALjgSCwYSBzgXAgAJAAAAHjQKADcAFAcAIQQHBQ0LAAELAQEHDicKATgWCgA3DhQhBBUFGwsAAQsBAQcJJwoANwYUBCgLAQcBESQLADcMFCEMAgUuCwABCwEBCQwCCwIEMQUzBwonAgAKAQAARDAKAC4KATgYCwEKADcNCwIRJREeDAYBAQwEAQEMBQcBIQQhCwUKADcMFCEEHg4GOBkMAwUjCQwDBSMJDAMLAwQmBSoLAAEHCicLBjgaCwAOBDgbAgALAAAASfQBCwERHwwODA8MCwwNDBAMDAoMMQIhBA8IDAMFEwoMMQQhDAMLAwQuCxAKADcPFCEEKwsNCgA3AhQhBCgKCwoANwcUIQwCBTAJDAIFMAkMAgUwCQwCCwIEMwU3CwABBwsnCgA3CBQEPAVACwABBwgnDg8RQCAESQ4OEUAgDAQFSwkMBAsEBE4FUgsAAQcLJwsMMQQhBJ4BCgA3BBQxAiEEXwgMBgVlCgA3BBQxAyEMBgsGBHMKADcJFARwCgA3BTgPDAUFdQkMBQV1CQwFCwUEeAV8CwABBwgnCg8KADcKFCEEiQELDgoANwsUIQwHBYsBCQwHCwcEjgEFkgELAAEHDCcxAwoANgQVCwAuOBILCwsPEgY4HAIKADcEFDECIQSnAQgMCAWtAQoANwQUMQMhDAgLCATFAQoPCgA3ChQhBLwBCg4KADcLFCEMCQW+AQkMCQsJBMEBBesBCwABBwwnCgA3BBQxASEE0AEKADcFOB0MCgXSAQkMCgsKBNUBBdkBCwABBwgnMQIKADYEFQoPCgA2ChUKDgoANgsVCgA2BTgeDg4RQTgfCwAuOBILCwsPCw4SCTggAgAMAAAATmsKATEBIQQxCgA3AxQgBAoFDgsAAQcNJwoANwQUMQEhBBkKADcFOB0MAgUbCQwCCwIEHgUiCwABBwgnMQEKADcPFAoANwIUCwA3BxQRQhFCESAMBQVpCwExAyEETgoANwQUMQIhBD4IDAQFRAoANwQUMQMhDAQLBARLCgA3BTgPDAMFUAkMAwVQCQwDCwMEUwVXCwABBwgnMQMKADcPFAoANwIUCgA3BxQKADcKFAsANwsUESAMBQsFAgANAAAAT9wBCwExASEEB0gBAAwDBQlIAwAMAwsDDAwKAAcBCgwHEREhDAQOBEEbBgIAAAAAAAAAJAQXBRsLAAEHDycLAAcBCwwLAhEhDAkOCUEbBhYAAAAAAAAAJgQ4DgkGAAAAAAAAAABCGxQxACEENQ4JBgEAAAAAAAAAQhsUMQMhDAUFOgkMBQU6CQwFCwUEPQU/Bw8nBgIAAAAAAAAADA0yAAAAAAAAAAAAAAAAAAAAAAwPCg0OCUEbIwTTAQoNBgQAAAAAAAAAFg4JQRslBFAFUgcPJw4JCg0GAQAAAAAAAAAWQhsUNAYAAQAAAAAAABgOCQoNBgIAAAAAAAAAFkIbFDQWDA4OCQoNQhsUMQEhBHYFbA4JCg0GAwAAAAAAAAAWQhsUMQEhDAYFeAkMBgsGBHsFfQcPJwoOBhEAAAAAAAAAIQSEAQgMCAWIAQoOBiEAAAAAAAAAIQwICwgElAEKDQYDAAAAAAAAABYKDhYOCUEbJQwHBZYBCQwHCwcEmQEFmwEHDycyAAAAAAAAAAAAAAAAAAAAAAwKBgAAAAAAAAAADAsKCwYQAAAAAAAAACMEyAELCjEILw4JCg0GBAAAAAAAAAAWCgsWQhsUNRsMCgoOBiEAAAAAAAAAIQTDAQ4JCg0GFAAAAAAAAAAWCgsWQhsUMQAhBMEBBcMBBw8nCwsGAQAAAAAAAAAWDAsFnwELDwsKFgwPCw0GAwAAAAAAAAAWCw4WDA0FQwsPMkANAwAAAAAAAAAAAAAAAAAmBNgBBdoBBw8nCwkCAA4BAABRFgoACgE4GAoACgI4IQwFCgELAgsDEQ0MBgsBCwA3DQcBCwULBgkLBBEoAgAPAQAAUSwKAC4KAS44GAoALgoCOCEMBgoBLgoCCwMRDQwHCwIxASEEGQgKADYIFQUdCAoANgkVCwELADcNBwELBgsHCwQ4IgoFLhE9OCMLBREmAgAQAQAAAQoKAAoBLjgYCwELADcNCwIRIgIAEQEAAAEJCgAKATgYCwELADcNCwIRIwIAEgEAAAEECwA3BBQCABMBAAABBAsANw8UAgAUAQAAAQQLADcCFAIAFQEAAAEECwALATghAgAWAQAAAQQLADcHFAIAFwEAAB4TCgA3BBQxASEECwsAAQgMAQURCwA3BBQxAiEMAQsBAgAYAQAAAQQLADcFOB0CABkBAAABBAsANwEUAgAaAQAAAQQLABAFFAIAGwEAAAECBwECABwBAAABBAsANwwUAgACAQEBAwEDAgIGAgQCAgIDAgUDBgMKAwsDBQMJAwwDDQMOAw8DEAMIAwMDBAMHAi4DLgkuCi4LLgwuDS4OLg8uEC4RLhIuEy4ULhUuFi4A"], dependencies: ["0x0000000000000000000000000000000000000000000000000000000000000001", "0x0000000000000000000000000000000000000000000000000000000000000002", "0x28de9e8e087a6347001907fb698fdf8ab0467b342229b74b19264067aebc4ae9", "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac", "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24", "0x00245ba36f7a1cc643a2b037450dff1e4399e18069c6545fb5fcaaf37d39d7dc", "0x3de1504cf3fd75762759e353d9d95389618e557d0552697f19b52e4e927c1dee"], digest: [189, 19, 105, 36, 114, 65, 94, 95, 188, 46, 70, 250, 68, 72, 20, 4, 79, 129, 126, 120, 249, 13, 203, 109, 11, 186, 205, 87, 164, 221, 203, 28] };

// docs/multichain/generation-milestone/validation.json
var validation_default = {
  baseline: "462ff86a7b120f3c89bc9a24eccc46fbac8a491f",
  baselineTrackedFilesPreserved: 1785,
  moveReleaseModuleCount: 2,
  moveReleaseBuildSha256: "75255e5a7721f244580d206fe98a528968a07795d52eba1635cacf5b15b6d473",
  moveTests: 52,
  evmTests: 16,
  compiler: "sui 1.83.1-6a567faf6de1",
  solc: "0.8.30",
  deployment: false,
  gameplayEnabled: false
};

// contracts/nftree-generation/scripts/readiness.mjs
var C = Object.freeze({
  sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
  nft: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
  nftType: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT",
  oappPackage: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24",
  graphql: "https://graphql.mainnet.sui.io/graphql",
  chain: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
  maxGasMist: 200000000n
});
var check = (condition, message) => assert(condition, message);
var equal = (a, b, message) => assert.deepEqual(a, b, message);
function verifyBuild() {
  const bytes = JSON.stringify(publication_bytecode_default) + "\n";
  assert.equal(createHash("sha256").update(bytes).digest("hex"), validation_default.moveReleaseBuildSha256);
  assert.equal(publication_bytecode_default.modules.length, 2);
}
function readOnlyFetch(fetcher = globalThis.fetch) {
  return async (url, options2) => {
    assert.equal(String(url), C.graphql, "Unexpected endpoint");
    assert.equal(options2?.method, "POST");
    const body = JSON.parse(options2.body);
    assert.equal(typeof body.query, "string");
    assert(!/\b(mutation|executeTransaction)\b/.test(body.query), "Submission is forbidden");
    assert(/^\s*(query\b|\{)/.test(body.query), "Only GraphQL queries allowed");
    return fetcher(url, options2);
  };
}
function newClient() {
  return new SuiGraphQLClient({ network: "mainnet", url: C.graphql, fetch: readOnlyFetch() });
}
function verifyCandidate(data, now = Date.now()) {
  assert.equal(data.chainIdentifier, C.chain);
  const n = data.nft;
  assert.equal(n?.address, C.nft);
  assert.equal(n.owner?.__typename, "AddressOwner");
  assert.equal(n.owner.address.address, C.sender);
  assert.equal(n.asMoveObject?.contents?.type?.repr, C.nftType);
  assert.equal(n.asMoveObject.contents.json.number, "2720");
  assert(n.version && n.digest);
  const age = now - Date.parse(data.checkpoint.timestamp);
  assert(Number.isFinite(age) && age >= -3e4 && age <= 12e4, "Stale checkpoint");
}
async function readCandidate(client) {
  const r = await client.query({ query: `query { chainIdentifier checkpoint { sequenceNumber timestamp }
 nft:object(address:"${C.nft}"){address version digest owner{__typename ... on AddressOwner{address{address}}}
 asMoveObject{contents{type{repr} json}}}}`, signal: AbortSignal.timeout(2e4) });
  assert(!r.errors);
  verifyCandidate(r.data);
  return r.data;
}
function verifyPublication(result) {
  check(result?.$kind === "Transaction" && result.Transaction?.status?.success === true, "Publication did not succeed. No NFT deposit is permitted.");
  const t = result.Transaction;
  check(t.transaction?.sender === C.sender, "Wrong publication sender.");
  const commands = t.transaction.commands;
  check(commands?.length === 2 && commands[0].Publish && commands[1].TransferObjects, "Unexpected publication command.");
  equal(commands[0].Publish.modules, publication_bytecode_default.modules, "Wrong published modules.");
  equal(commands[0].Publish.dependencies, publication_bytecode_default.dependencies, "Wrong dependencies.");
  equal(commands[1].TransferObjects.objects.map((x) => x.NestedResult), [[0, 0]], "Upgrade authority transfer changed.");
  const inputs = t.transaction.inputs;
  check(inputs?.length === 1, "Unexpected publication inputs.");
  const target = inputs[commands[1].TransferObjects.address.Input]?.Pure?.bytes;
  check(target === btoa(String.fromCharCode(...Uint8Array.from(C.sender.slice(2).match(/../g), (x) => parseInt(x, 16)))), "Upgrade authority recipient changed.");
  check(t.transaction.gasData?.owner === C.sender, "Gas must be paid by the dev wallet.");
  const gasIds = /* @__PURE__ */ new Set([t.effects?.gasObject?.objectId, ...(t.transaction.gasData.payment ?? []).map((x) => x.objectId)]);
  const changes = t.effects?.changedObjects;
  check(Array.isArray(changes) && !changes.some((x) => x.objectId === C.nft), "Original NFT was unexpectedly touched.");
  const created = [];
  for (const x of changes) {
    if (x.inputState === "Exists") {
      check(gasIds.has(x.objectId) && x.inputOwner?.AddressOwner === C.sender, "Unexpected existing object mutation.");
    } else if (["ObjectWrite", "PackageWrite"].includes(x.outputState)) {
      created.push(x);
    } else {
      const transient = x.inputState === "DoesNotExist" && x.outputState === "DoesNotExist" && x.idOperation === "Created";
      const addressGas = x.inputState === "DoesNotExist" && x.outputState === "AccumulatorWriteV1" && x.idOperation === "None" && x.outputOwner === null;
      check(transient || addressGas, "Unexpected object effect.");
    }
  }
  check(created.length === 6, "Unexpected number of created objects.");
  const typed = created.map((x) => ({ id: x.objectId, type: t.objectTypes?.[x.objectId], owner: x.outputOwner }));
  const packages = typed.filter((x) => x.type === "package");
  check(packages.length === 1, "Missing new package.");
  const packageId = packages[0].id;
  const expected = [packageId + "::vault::Registry", packageId + "::vault::AdminCap", C.oappPackage + "::oapp::OApp", C.oappPackage + "::oapp::AdminCap", "0x0000000000000000000000000000000000000000000000000000000000000002::package::UpgradeCap"];
  for (const type of expected) {
    const found = typed.filter((x) => x.type === type);
    check(found.length === 1, "Created object type differs: " + type);
    if (type.endsWith("Cap")) check(found[0].owner?.AddressOwner === C.sender, "A capability left the dev wallet.");
    else check(found[0].owner?.Shared || found[0].owner?.$kind === "Shared", "Expected a shared empty registry/OApp.");
  }
  check((t.events ?? []).length === 0, "Unexpected publication events.");
  const g = t.effects.gasUsed;
  check(g, "Missing gas summary.");
  const gas = BigInt(g.computationCost) + BigInt(g.storageCost) - BigInt(g.storageRebate);
  check(gas > 0n && gas <= C.maxGasMist, "Estimated gas exceeds the reviewed 0.2-SUI limit.");
  check(t.balanceChanges?.length === 1 && t.balanceChanges[0].address === C.sender && /^0x0*2::sui::SUI$/.test(t.balanceChanges[0].coinType) && BigInt(t.balanceChanges[0].amount) === -gas, "Unexpected asset payment.");
  return { gasMist: String(gas), packageId, registryId: typed.find((x) => x.type === expected[0]).id, oappId: typed.find((x) => x.type === expected[2]).id, objects: typed };
}

// contracts/nftree-generation/scripts/configuration-encoding.mjs
import { Transaction as Transaction2 } from "@mysten/sui/transactions";
import { bcs as bcs2 } from "@mysten/sui/bcs";

// contracts/nftree-generation/scripts/configuration-identities.json
var configuration_identities_default = {
  sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
  nft: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
  nftType: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT",
  oappPackage: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24",
  graphql: "https://graphql.mainnet.sui.io/graphql",
  chain: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
  maxGasMist: "20000000",
  package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
  vault: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
  registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
  admin: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
  oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
  oappAdmin: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
  upgrade: "0xb70e2cdc18d562247bc34bf47efee620a05ec1f059cff5e812a8d433a722999d",
  endpoint: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
  endpointPackage: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
  endpointRegistry: "0x720fc2300c05bb7ad68aefec00a9796b4451c4d1df78bc72cd8c98e774220bec",
  vaultAdmin: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
  uln: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
  ulnPackage: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
  executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989",
  receiveCallId: "64202616f75a5614acfa264418258521299eb6a892eeeea392feef8948c7eb53",
  dvns: [
    "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
    "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
    "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
  ],
  channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
  channelVersion: "1089269258",
  registration: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
  registrationDigest: "DF8dMqSXXtYBoemHsPYk2QJDkuUY2m8zTRDdcu6Y9DFt",
  remoteEid: 30102
};

// contracts/nftree-generation/scripts/configuration-encoding.mjs
var C2 = Object.freeze(configuration_identities_default);
var Arg = bcs2.enum("Argument", { ID: bcs2.vector(bcs2.u8()), Object: bcs2.Address, Pure: bcs2.vector(bcs2.u8()), NestedResult: bcs2.struct("NestedResult", { call_index: bcs2.u16(), result_index: bcs2.u16() }) });
var Calls = bcs2.vector(bcs2.struct("MoveCall", { function: bcs2.struct("Function", { package: bcs2.Address, module_name: bcs2.string(), name: bcs2.string() }), arguments: bcs2.vector(Arg), type_arguments: bcs2.vector(bcs2.string()), is_builder_call: bcs2.bool(), result_ids: bcs2.vector(bcs2.vector(bcs2.u8())) }));
var Info = bcs2.struct("OAppInfoV1", { oapp_object: bcs2.Address, next_nonce_info: bcs2.vector(bcs2.u8()), lz_receive_info: bcs2.vector(bcs2.u8()), extra_info: bcs2.vector(bcs2.u8()) });
var Uln = bcs2.struct("OAppUlnConfig", { use_default_confirmations: bcs2.bool(), use_default_required_dvns: bcs2.bool(), use_default_optional_dvns: bcs2.bool(), uln_config: bcs2.struct("UlnConfig", { confirmations: bcs2.u64(), required_dvns: bcs2.vector(bcs2.Address), optional_dvns: bcs2.vector(bcs2.Address), optional_dvn_threshold: bcs2.u8() }) });
var Executor = bcs2.struct("ExecutorConfig", { max_message_size: bcs2.u64(), executor: bcs2.Address });
var canonical = (x) => JSON.stringify(x, (_, v) => v && typeof v === "object" && !Array.isArray(v) ? Object.fromEntries(Object.entries(v).sort(([a], [b]) => a.localeCompare(b))) : v);
var ulnValue = (confirmations) => ({ use_default_confirmations: false, use_default_required_dvns: false, use_default_optional_dvns: false, uln_config: { confirmations: String(confirmations), required_dvns: [...C2.dvns], optional_dvns: [], optional_dvn_threshold: 0 } });
function metadata() {
  const calls = [{ function: { package: C2.package, module_name: "vault", name: "lz_receive" }, arguments: [{ Object: C2.vault }, { Object: C2.oapp }, { ID: Array.from(Uint8Array.from(C2.receiveCallId.match(/../g), (v) => parseInt(v, 16))) }], type_arguments: [C2.nftType], is_builder_call: false, result_ids: [] }];
  return Uint8Array.from([0, 1, ...Info.serialize({ oapp_object: C2.oapp, next_nonce_info: [], lz_receive_info: [0, 1, ...Calls.serialize(calls).toBytes()], extra_info: [] }).toBytes()]);
}
var metadataBase64 = () => btoa(String.fromCharCode(...metadata()));
var fields = "address version digest owner{__typename ... on Shared{initialSharedVersion} ... on AddressOwner{address{address}}} asMoveObject{contents{type{repr} json}}";
var key = btoa(String.fromCharCode(...Uint8Array.from((C2.package.slice(2) + "96750000").match(/../g), (v) => parseInt(v, 16))));
var tables = Object.freeze({ libraries: ["0xa2371851318b3ba333270daf696dedbc7b89a1107ca362643798c1789ce05a01", "u32", "lnUAAA=="], send: ["0x2bd7d044d837b718a7852959c701c04e842e648cf9047b442d55c838846a13e5", "u32", "lnUAAA=="], receive: ["0x5ddc28272722231ecef30237bb48715f128d6995b89a46db25cd9adae0140835", "u32", "lnUAAA=="], executor: ["0x346b468d90db8743673c7ed4fdbe1c40f6a587aac6acc730b3a9bb86cf0919f4", "u32", "lnUAAA=="], appLibraries: ["0x0e679b0fcc94fb07a5ec9a14712f8e35e0994b892e64a434e898450eb670e920", C2.endpointPackage + "::message_lib_manager::OAppConfigKey", key], appSend: ["0xc53b8a5592cdeea1a7421d209ba5c70e6843d2911e5bb86ad9fb744d888eab60", C2.ulnPackage + "::send_uln::OAppConfigKey", key], appReceive: ["0x0d89da4d00f46c4b1dab465a867e60eacbf646e56f8816ae55cd7b9495c1bb09", C2.ulnPackage + "::receive_uln::OAppConfigKey", key], appExecutor: ["0x357a98886ef14de3d15e538a808b410cfe026f6b1f971bb2398978d56e4dc181", C2.ulnPackage + "::send_uln::OAppConfigKey", key] });
var STATE_QUERY = "query { chainIdentifier checkpoint{sequenceNumber timestamp} " + Object.entries({ endpoint: C2.endpoint, uln: C2.uln, oapp: C2.oapp, admin: C2.admin, vault: C2.vault, channel: C2.channel, registration: C2.registration }).map(([n, id]) => n + ':object(address:"' + id + '"){' + fields + "}").join(" ") + " " + Object.entries(tables).map(([n, [id, type, key2]]) => n + ':address(address:"' + id + '"){dynamicField(name:{type:"' + type + '",bcs:"' + key2 + '"}){value{... on MoveValue{json}}}}').join(" ") + "}";

// contracts/nftree-generation/scripts/configuration-review.mjs
import { deriveDynamicFieldID } from "@mysten/sui/utils";

// docs/multichain/generation-milestone/configuration-review/baseline.json
var baseline_default = {
  checkpoint: {
    sequenceNumber: 348223740,
    timestamp: "2026-11-23T04:16:13.683Z"
  },
  endpoint: {
    address: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
    version: 1089269258,
    digest: "7KKLMt5sQiGPhFLHNRdqBs66sm5viuvUQ9Jqxrw4rqKx",
    owner: {
      __typename: "Shared",
      initialSharedVersion: 635685314
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::endpoint_v2::EndpointV2"
        },
        json: {
          id: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
          eid: 30378,
          call_cap: {
            id: "0x8de954b904b90f887ff2e81ff3362ca89e883da6529e55723758cd5093234b0d",
            cap_type: {
              "@variant": "Package",
              pos0: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac"
            }
          },
          oapp_registry: {
            oapps: {
              id: "0x720fc2300c05bb7ad68aefec00a9796b4451c4d1df78bc72cd8c98e774220bec",
              size: "143"
            }
          },
          composer_registry: {
            composers: {
              id: "0xb41ca35805177b946bebf5d339712b4e9bb562b068b33851001f9f0b66847814",
              size: "7"
            }
          },
          message_lib_manager: {
            registry: {
              libs: {
                contents: {
                  id: "0x520bbc08883e22efb29f50283e25b4561ffa7c7b9d7774b14fc1c6272e593e03",
                  size: "2"
                }
              },
              lib_to_type: {
                id: "0xb136bb2fc780a76e636c10f10b10ab33754a3573efa5f1285bf2b35eaf73b50d",
                size: "2"
              }
            },
            default_configs: {
              id: "0xa2371851318b3ba333270daf696dedbc7b89a1107ca362643798c1789ce05a01",
              size: "126"
            },
            oapp_configs: {
              id: "0x0e679b0fcc94fb07a5ec9a14712f8e35e0994b892e64a434e898450eb670e920",
              size: "100"
            }
          }
        }
      }
    }
  },
  uln: {
    address: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
    version: 1096510921,
    digest: "3X8N5Tg1GzQXZPtWGvDu6GhhDrjUy5aL1h486XDuETaY",
    owner: {
      __typename: "Shared",
      initialSharedVersion: 635685319
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0::uln_302::Uln302"
        },
        json: {
          id: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
          call_cap: {
            id: "0xfacd801d08e3a99c907148fa00ec5f17a0a3ac831dbc95bcd75e601006caafa9",
            cap_type: {
              "@variant": "Package",
              pos0: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0"
            }
          },
          send_uln: {
            default_executor_configs: {
              id: "0x346b468d90db8743673c7ed4fdbe1c40f6a587aac6acc730b3a9bb86cf0919f4",
              size: "126"
            },
            default_uln_configs: {
              id: "0x2bd7d044d837b718a7852959c701c04e842e648cf9047b442d55c838846a13e5",
              size: "126"
            },
            oapp_executor_configs: {
              id: "0x357a98886ef14de3d15e538a808b410cfe026f6b1f971bb2398978d56e4dc181",
              size: "54"
            },
            oapp_uln_configs: {
              id: "0xc53b8a5592cdeea1a7421d209ba5c70e6843d2911e5bb86ad9fb744d888eab60",
              size: "214"
            }
          },
          receive_uln: {
            default_uln_configs: {
              id: "0x5ddc28272722231ecef30237bb48715f128d6995b89a46db25cd9adae0140835",
              size: "126"
            },
            oapp_uln_configs: {
              id: "0x0d89da4d00f46c4b1dab465a867e60eacbf646e56f8816ae55cd7b9495c1bb09",
              size: "239"
            },
            verification: "0x950f66ed27ec0a01a52bda147d74165d4cc20165f0cee0ecae6aaacde13d7741"
          }
        }
      }
    }
  },
  oapp: {
    address: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
    version: 1,
    digest: "7LeHSzqW2xxEA7QrcimgN8c7ZKaAJUL3fwvjNy9wnoar",
    owner: {
      __typename: "Shared",
      initialSharedVersion: 1
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::OApp"
        },
        json: {
          id: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
          oapp_cap: {
            id: "0x6b7c66d2135ce12efa6a23037bff2e5ca1b499db24bc200592d08c2595cf5a3a",
            cap_type: {
              "@variant": "Package",
              pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
            }
          },
          admin_cap: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
          peer: {
            peers: {
              id: "0x984eb93d6713b0909152e249bcfa465a6661e7403c5b01266353b97ff2318966",
              size: "0"
            }
          },
          enforced_options: {
            options: {
              id: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
              size: "0"
            }
          },
          sending_call: null
        }
      }
    }
  },
  admin: {
    address: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
    version: 1,
    digest: "CRHN2g1UWgQYiN9TVWbRf8CcTd9FMtr2ky2jnfx79VVB",
    owner: {
      __typename: "AddressOwner",
      address: {
        address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
      }
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::AdminCap"
        },
        json: {
          id: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d"
        }
      }
    }
  },
  vault: {
    address: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
    version: 2,
    digest: "EiVf4xEufWiA56rUMda9QJ7bSYtP6XDDdWHQcxyP1gJq",
    owner: {
      __typename: "Shared",
      initialSharedVersion: 2
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Vault<0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT>"
        },
        json: {
          id: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
          version: "1",
          registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
          cap: {
            id: "0x1711b6b0e442e8299ea3aceb30286234520c8f1c4d2294aa7d031308a3d7bcff",
            cap_type: {
              "@variant": "Package",
              pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
            }
          },
          oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
          nft: null,
          backing: {
            bytes: "BG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWpro="
          },
          route: {
            bytes: "9d/44syWgk+Jc1+hbAaO6BlPu36NaXruvl0TX4pZFus="
          },
          peer: {
            bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
          },
          bound: false,
          paused: false,
          phase: 0,
          generation: "0",
          announced: false,
          ack_sent: false,
          request: {
            bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
          },
          recipient: {
            bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
          }
        }
      }
    }
  },
  channel: {
    address: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
    version: 1089269258,
    digest: "864jUfZhozh3q9nS2x8Pu7WmX8fQxL7iidcGXqp6nbUm",
    owner: {
      __typename: "Shared",
      initialSharedVersion: 1089269258
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::MessagingChannel"
        },
        json: {
          id: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
          oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
          channels: {
            id: "0xc631f02da694ee43bc4923570de9f6d53cbccbdb72986cf63dc84e77744c0e95",
            size: "0"
          },
          is_sending: false
        }
      }
    }
  },
  registration: {
    address: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
    version: 1089269258,
    digest: "7adt8jhhsGqFZMbKHoWje3qLDKWWLMehF7Zf9SduGeei",
    owner: {
      __typename: "ObjectOwner"
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<address,0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::oapp_registry::OAppRegistration>"
        },
        json: {
          id: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
          name: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
          value: {
            messaging_channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
            oapp_info: "",
            delegate: "0x0000000000000000000000000000000000000000000000000000000000000000"
          }
        }
      }
    }
  },
  libraries: {
    dynamicField: {
      value: {
        json: {
          send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
          receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
          receive_lib_timeout: null
        }
      }
    }
  },
  send: {
    dynamicField: {
      value: {
        json: {
          confirmations: "5",
          required_dvns: [
            "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
            "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
            "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
            "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
          ],
          optional_dvns: [],
          optional_dvn_threshold: 0
        }
      }
    }
  },
  receive: {
    dynamicField: {
      value: {
        json: {
          confirmations: "20",
          required_dvns: [
            "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
            "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
            "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
            "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
          ],
          optional_dvns: [],
          optional_dvn_threshold: 0
        }
      }
    }
  },
  executor: {
    dynamicField: {
      value: {
        json: {
          max_message_size: "10000",
          executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
        }
      }
    }
  },
  appLibraries: {
    dynamicField: null
  },
  appSend: {
    dynamicField: null
  },
  appReceive: {
    dynamicField: null
  },
  appExecutor: {
    dynamicField: null
  }
};

// contracts/nftree-generation/scripts/configuration-review.mjs
var check2 = (v, m) => {
  if (!v) throw Error(m);
};
var eq = (a, b, m) => check2(canonical(a) === canonical(b), m);
var json = (o) => o?.asMoveObject?.contents?.json;
var appNames = ["appLibraries", "appExecutor", "appSend", "appReceive"];
var entries = Object.freeze(Object.fromEntries(appNames.map((n) => {
  const [parent, type, key2] = tables[n], [address, module, name] = type.split("::");
  return [n, { id: deriveDynamicFieldID(parent, { struct: { address, module, name, typeParams: [] } }, Uint8Array.from(atob(key2), (x) => x.charCodeAt(0))), parent }];
})));
function validateConfigState(s, stage = 0) {
  check2(stage === 0 || stage === 1, "Unknown route configuration stage.");
  for (const name of ["endpoint", "uln", "oapp", "admin", "vault", "channel", "registration"]) {
    const a = s[name], b = baseline_default[name];
    check2(a?.address === b.address, "Wrong " + name + " object.");
    eq(a.owner, b.owner, name + " ownership changed.");
    eq(a.asMoveObject?.contents?.type, b.asMoveObject.contents.type, name + " type changed.");
  }
  for (const name of ["oapp", "admin", "vault", "channel"]) eq(json(s[name]), json(baseline_default[name]), "Original " + name + " changed. Verify wallet activity.");
  const endpoint = json(s.endpoint), uln = json(s.uln);
  check2(endpoint.eid === 30378, "Wrong endpoint ID.");
  eq(endpoint.call_cap, json(baseline_default.endpoint).call_cap, "Endpoint capability changed.");
  eq(uln.call_cap, json(baseline_default.uln).call_cap, "ULN capability changed.");
  for (const [actual, expected] of [[endpoint.message_lib_manager.default_configs.id, tables.libraries[0]], [endpoint.message_lib_manager.oapp_configs.id, tables.appLibraries[0]], [uln.send_uln.oapp_executor_configs.id, tables.appExecutor[0]], [uln.send_uln.oapp_uln_configs.id, tables.appSend[0]], [uln.receive_uln.oapp_uln_configs.id, tables.appReceive[0]]]) check2(actual === expected, "Protocol configuration table changed.");
  for (const n of ["libraries", "executor", "send", "receive"]) eq(s[n], baseline_default[n], "Protocol default " + n + " changed. Review before continuing.");
  const reg = structuredClone(json(baseline_default.registration));
  if (stage === 1) reg.value.oapp_info = metadataBase64();
  eq(json(s.registration), reg, "Registration channel, metadata or delegate changed.");
  for (const n of appNames) check2(s[n] && Object.hasOwn(s[n], "dynamicField"), "Missing " + n + " lookup.");
  if (stage === 0) {
    for (const n of appNames) check2(s[n].dynamicField === null, "Application settings already exist. Check the configuration receipt.");
  } else {
    const get = (n) => s[n].dynamicField?.value?.json;
    eq(get("appLibraries"), { send_lib: C2.ulnPackage, receive_lib: C2.ulnPackage, receive_lib_timeout: null }, "Application libraries differ.");
    eq(get("appExecutor"), { max_message_size: "10000", executor: C2.executor }, "Application executor differs.");
    eq(get("appSend"), ulnValue(5), "Application send security differs.");
    eq(get("appReceive"), ulnValue(20), "Application receive security differs.");
  }
  return s;
}

// contracts/nftree-generation/scripts/binding-handoff.mjs
import assert8 from "node:assert/strict";

// contracts/nftree-generation/scripts/registration-review.mjs
import { Transaction as Transaction6 } from "@mysten/sui/transactions";

// contracts/bnb-generation/browser/pinned-build.json
var pinned_build_default = {
  schema: 1,
  chainId: 56,
  admin: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789",
  treasury: "0xC440F06BBC7e58b0d055815f915447e4ae0E3720",
  peer: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
  route: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
  baseNonce: 4739,
  addresses: {
    adapter: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
    pass: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5"
  },
  gasLimits: [
    "1987828",
    "2298085",
    "65443"
  ],
  maxTotalFeeWei: "1000000000000000",
  remoteCodeHashes: {
    endpoint: "0x5ed1f4ec5f4d6bd5eac1fa92e0fb7474be2607dfc5f3eb82ced1c183b64fbeb9",
    usdt: "0x97a48aa4c129657440dafdacd4c836389734d28cc4a0ca7403e68da660a74a59"
  },
  slotDigest: "GNDWXqgPJnZyeQaVFqnZ1HuXSnSiHUAKV1vL4Ke49yMX",
  registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
  adapter: {
    abi: [
      {
        inputs: [
          {
            internalType: "bytes32",
            name: "peer",
            type: "bytes32"
          },
          {
            internalType: "bytes32",
            name: "routeId",
            type: "bytes32"
          }
        ],
        stateMutability: "nonpayable",
        type: "constructor"
      },
      {
        inputs: [],
        name: "Invalid",
        type: "error"
      },
      {
        inputs: [],
        name: "ReentrancyGuardReentrantCall",
        type: "error"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "bytes32",
            name: "guid",
            type: "bytes32"
          },
          {
            indexed: false,
            internalType: "uint8",
            name: "kind",
            type: "uint8"
          },
          {
            indexed: false,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          }
        ],
        name: "MessageApplied",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "bytes32",
            name: "guid",
            type: "bytes32"
          },
          {
            indexed: false,
            internalType: "uint8",
            name: "kind",
            type: "uint8"
          },
          {
            indexed: false,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          }
        ],
        name: "MessageSent",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "address",
            name: "pass",
            type: "address"
          }
        ],
        name: "PassBound",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: false,
            internalType: "uint128",
            name: "gas",
            type: "uint128"
          }
        ],
        name: "ReceiveGasRaised",
        type: "event"
      },
      {
        inputs: [],
        name: "SUI_EID",
        outputs: [
          {
            internalType: "uint32",
            name: "",
            type: "uint32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            components: [
              {
                internalType: "uint32",
                name: "srcEid",
                type: "uint32"
              },
              {
                internalType: "bytes32",
                name: "sender",
                type: "bytes32"
              },
              {
                internalType: "uint64",
                name: "nonce",
                type: "uint64"
              }
            ],
            internalType: "struct Origin",
            name: "origin",
            type: "tuple"
          }
        ],
        name: "allowInitializePath",
        outputs: [
          {
            internalType: "bool",
            name: "",
            type: "bool"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "backingNFT",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "contract TreeSuitePass",
            name: "p",
            type: "address"
          }
        ],
        name: "bindPass",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "binder",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        name: "delivered",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "endpoint",
        outputs: [
          {
            internalType: "contract ILayerZeroEndpointV2",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            components: [
              {
                internalType: "uint32",
                name: "srcEid",
                type: "uint32"
              },
              {
                internalType: "bytes32",
                name: "sender",
                type: "bytes32"
              },
              {
                internalType: "uint64",
                name: "nonce",
                type: "uint64"
              }
            ],
            internalType: "struct Origin",
            name: "origin",
            type: "tuple"
          },
          {
            internalType: "bytes32",
            name: "guid",
            type: "bytes32"
          },
          {
            internalType: "bytes",
            name: "message",
            type: "bytes"
          },
          {
            internalType: "address",
            name: "",
            type: "address"
          },
          {
            internalType: "bytes",
            name: "",
            type: "bytes"
          }
        ],
        name: "lzReceive",
        outputs: [],
        stateMutability: "payable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint32",
            name: "",
            type: "uint32"
          },
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        name: "nextNonce",
        outputs: [
          {
            internalType: "uint64",
            name: "",
            type: "uint64"
          }
        ],
        stateMutability: "pure",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint8",
            name: "kind",
            type: "uint8"
          }
        ],
        name: "outboundPayload",
        outputs: [
          {
            internalType: "bytes",
            name: "",
            type: "bytes"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "pass",
        outputs: [
          {
            internalType: "contract TreeSuitePass",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint8",
            name: "kind",
            type: "uint8"
          }
        ],
        name: "quote",
        outputs: [
          {
            components: [
              {
                internalType: "uint256",
                name: "nativeFee",
                type: "uint256"
              },
              {
                internalType: "uint256",
                name: "lzTokenFee",
                type: "uint256"
              }
            ],
            internalType: "struct MessagingFee",
            name: "",
            type: "tuple"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "receiveGas",
        outputs: [
          {
            internalType: "uint128",
            name: "",
            type: "uint128"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "receiveOptions",
        outputs: [
          {
            internalType: "bytes",
            name: "",
            type: "bytes"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "route",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint8",
            name: "kind",
            type: "uint8"
          }
        ],
        name: "send",
        outputs: [
          {
            components: [
              {
                internalType: "bytes32",
                name: "guid",
                type: "bytes32"
              },
              {
                internalType: "uint64",
                name: "nonce",
                type: "uint64"
              },
              {
                components: [
                  {
                    internalType: "uint256",
                    name: "nativeFee",
                    type: "uint256"
                  },
                  {
                    internalType: "uint256",
                    name: "lzTokenFee",
                    type: "uint256"
                  }
                ],
                internalType: "struct MessagingFee",
                name: "fee",
                type: "tuple"
              }
            ],
            internalType: "struct MessagingReceipt",
            name: "receipt",
            type: "tuple"
          }
        ],
        stateMutability: "payable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint128",
            name: "gas",
            type: "uint128"
          }
        ],
        name: "setReceiveGas",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "suiPeer",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      }
    ],
    evm: {
      bytecode: {
        object: "60e0604052600280546001600160801b0319166301c9c380179055348015610025575f5ffd5b50604051611cb7380380611cb78339810160408190526100449161019f565b60015f5546603814158061006b5750731a44076050125825900e736c501f859c50fe728c3b155b80610074575081155b8061007d575080155b80610109575061759663ffffffff16731a44076050125825900e736c501f859c50fe728c6001600160a01b031663416ecebf6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156100dc573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061010091906101c1565b63ffffffff1614155b1561012757604051636dac6a0960e01b815260040160405180910390fd5b608082905260a08190523360c081905260405163ca5eb5e160e01b81526004810191909152731a44076050125825900e736c501f859c50fe728c9063ca5eb5e1906024015f604051808303815f87803b158015610182575f5ffd5b505af1158015610194573d5f5f3e3d5ffd5b5050505050506101eb565b5f5f604083850312156101b0575f5ffd5b505080516020909101519092909150565b5f602082840312156101d1575f5ffd5b815163ffffffff811681146101e4575f5ffd5b9392505050565b60805160a05160c051611a5c61025b5f395f818161031901528181610413015281816107930152610a8401525f818161038c0152818161086101528181610d43015261109c01525f8181610196015281816104e101528181610bc6015281816112f901526114100152611a5c5ff3fe608060405260043610610105575f3560e01c80637d25a05e11610092578063b1f8671711610062578063b1f867171461033b578063c13bd9361461034f578063d96661ef1461037b578063e495f1d4146103ae578063ff7bd03d146103d9575f5ffd5b80637d25a05e1461028857806383d5f21d146102bf578063a7a1ed72146102e9578063acba7b4214610308575f5ffd5b806315aff54e116100d857806315aff54e146101855780634922eec1146101c65780634cedb60f146101f25780635e280f111461022957806378360c8814610268575f5ffd5b80630200e86b1461010957806307f53ee71461012a57806310265fa51461015357806313137d6514610172575b5f5ffd5b348015610114575f5ffd5b506101286101233660046114b9565b610408565b005b61013d6101383660046114e6565b6104c0565b60405161014a9190611506565b60405180910390f35b34801561015e575f5ffd5b5061012861016d36600461155e565b610788565b6101286101803660046115d3565b610b7f565b348015610190575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b60405190815260200161014a565b3480156101d1575f5ffd5b506101e56101e03660046114e6565b610f8e565b60405161014a91906116b0565b3480156101fd575f5ffd5b50600254610211906001600160801b031681565b6040516001600160801b03909116815260200161014a565b348015610234575f5ffd5b50610250731a44076050125825900e736c501f859c50fe728c81565b6040516001600160a01b03909116815260200161014a565b348015610273575f5ffd5b506101b85f516020611a075f395f51905f5281565b348015610293575f5ffd5b506102a76102a23660046116d5565b611273565b6040516001600160401b03909116815260200161014a565b3480156102ca575f5ffd5b506102d46176aa81565b60405163ffffffff909116815260200161014a565b3480156102f4575f5ffd5b50600154610250906001600160a01b031681565b348015610313575f5ffd5b506102507f000000000000000000000000000000000000000000000000000000000000000081565b348015610346575f5ffd5b506101e561127b565b34801561035a575f5ffd5b5061036e6103693660046114e6565b6112d5565b60405161014a91906116fd565b348015610386575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b3480156103b9575f5ffd5b506101b86103c8366004611714565b60036020525f908152604090205481565b3480156103e4575f5ffd5b506103f86103f336600461172b565b6113ef565b604051901515815260200161014a565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614158061044e57506002546001600160801b03908116908216105b1561046c57604051636dac6a0960e01b815260040160405180910390fd5b600280546001600160801b0319166001600160801b0383169081179091556040519081527f4bbad5fe035af81686d3e8380dfd61d879211cbe2c4e6e05f86ad07cdec099b09060200160405180910390a150565b6104c8611479565b6104d0611451565b6040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91810161051285610f8e565b815260200161051f61127b565b81525f6020909101819052604051631bb8518b60e31b815291925090731a44076050125825900e736c501f859c50fe728c9063ddc28c58906105679085903090600401611745565b6040805180830381865afa158015610581573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906105a59190611815565b805190915015806105b95750602081015115155b806105c5575080513414155b156105e357604051636dac6a0960e01b815260040160405180910390fd5b6040516302637a4560e41b8152731a44076050125825900e736c501f859c50fe728c90632637a45090349061061e9086903390600401611745565b60806040518083038185885af115801561063a573d5f5f3e3d5ffd5b50505050506040513d601f19601f8201168201806040525081019061065f9190611843565b8051909350158061067b575060208301516001600160401b0316155b8061068d575060408301516020015115155b8061069c575060408301515134105b156106ba57604051636dac6a0960e01b815260040160405180910390fd5b825f01517f6d23cdaef17712141c7441cf202389c6ddc063fb5c14788d5c4479b62096d13f8560015f9054906101000a90046001600160a01b03166001600160a01b031663172195226040518163ffffffff1660e01b8152600401602060405180830381865afa158015610730573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061075491906118b6565b6040805160ff90931683526001600160401b0390911660208301520160405180910390a2505061078360015f55565b919050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161415806107ca57506001546001600160a01b031615155b806107dd57506001600160a01b0381163b155b806108595750306001600160a01b0316816001600160a01b03166303eadcfc6040518163ffffffff1660e01b8152600401602060405180830381865afa158015610829573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061084d91906118d1565b6001600160a01b031614155b806108e357507f0000000000000000000000000000000000000000000000000000000000000000816001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156108bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906108e091906118ec565b14155b8061095c57505f516020611a075f395f51905f525f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa158015610935573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061095991906118ec565b14155b806109ec57507355d398326f99059ff775485246999027b31979556001600160a01b0316816001600160a01b031663e5a6b10f6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156109bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906109e091906118d1565b6001600160a01b031614155b80610a7c575073c440f06bbc7e58b0d055815f915447e4ae0e37206001600160a01b0316816001600160a01b03166361d027b36040518163ffffffff1660e01b8152600401602060405180830381865afa158015610a4c573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610a7091906118d1565b6001600160a01b031614155b80610b1857507f00000000000000000000000000000000000000000000000000000000000000006001600160a01b0316816001600160a01b031663f77c47916040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ae8573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610b0c91906118d1565b6001600160a01b031614155b15610b3657604051636dac6a0960e01b815260040160405180910390fd5b600180546001600160a01b0319166001600160a01b0383169081179091556040517f3916d079df018feca66a550908f671cff67410227b4a8c24f13531847e12b9c8905f90a250565b610b87611451565b33731a44076050125825900e736c501f859c50fe728c141580610bbe57506176aa610bb56020890189611903565b63ffffffff1614155b80610bed57507f0000000000000000000000000000000000000000000000000000000000000000876020013514155b80610c0157506001546001600160a01b0316155b80610c0a575085155b80610c2b5750610c20606088016040890161191c565b6001600160401b0316155b80610c3557503415155b15610c5357604051636dac6a0960e01b815260040160405180910390fd5b608a84141580610c7e575084845f818110610c7057610c70611937565b9091013560f81c6003141590505b15610c9c57604051636dac6a0960e01b815260040160405180910390fd5b5f85856001818110610cb057610cb0611937565b919091013560f81c91505f9050610ccb60226002888a61194b565b610cd491611972565b90505f610ce560426022898b61194b565b610cee91611972565b90505f610cff604a60428a8c61194b565b610d089161198f565b60c01c90505f610d1c606a604a8b8d61194b565b610d2591611972565b90505f610d36608a606a8c8e61194b565b610d3f91611972565b90507f000000000000000000000000000000000000000000000000000000000000000085141580610d7d57505f516020611a075f395f51905f528414155b80610d8f57506001600160401b038316155b15610dad57604051636dac6a0960e01b815260040160405180910390fd5b5f8b8b604051610dbe9291906119c5565b60408051918290039091205f8f81526003602052919091205490915015801590610df557505f8d8152600360205260409020548114155b15610e1357604051636dac6a0960e01b815260040160405180910390fd5b8660ff16600103610eb05782151580610e2b57508115155b15610e4957604051636dac6a0960e01b815260040160405180910390fd5b60015460405163579c848360e11b81526001600160401b03861660048201526001600160a01b039091169063af390906906024015b5f604051808303815f87803b158015610e95575f5ffd5b505af1158015610ea7573d5f5f3e3d5ffd5b50505050610f1b565b8660ff16600303610f025760015460405163367938c560e21b81526001600160401b038616600482015260248101859052604481018490526001600160a01b039091169063d9e4e31490606401610e7e565b604051636dac6a0960e01b815260040160405180910390fd5b5f8d815260036020908152604091829020839055815160ff8a1681526001600160401b038716918101919091528e917f37949e68c9d0a4e5f5474ddb8654f999a5dc4b58a8aa1aef313516586e9b320a910160405180910390a250505050505050610f8560015f55565b50505050505050565b6001546060906001600160a01b0316610fba57604051636dac6a0960e01b815260040160405180910390fd5b8160ff166002036110705760035b60015f9054906101000a90046001600160a01b03166001600160a01b031663c19d93fb6040518163ffffffff1660e01b8152600401602060405180830381865afa158015611018573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061103c91906119e8565b600481111561104d5761104d6119d4565b1461106b57604051636dac6a0960e01b815260040160405180910390fd5b611082565b8160ff16600403610f02576004610fc8565b60015460408051630b90ca9160e11b8152905160039285927f0000000000000000000000000000000000000000000000000000000000000000925f516020611a075f395f51905f52926001600160a01b03169163172195229160048083019260209291908290030181865afa1580156110fd573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061112191906118b6565b60015f9054906101000a90046001600160a01b03166001600160a01b0316635467e0a76040518163ffffffff1660e01b8152600401602060405180830381865afa158015611171573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061119591906118ec565b60015f9054906101000a90046001600160a01b03166001600160a01b03166366d003ac6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156111e5573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061120991906118ec565b60405160f897881b6001600160f81b031990811660208301529690971b90951660218701526022860193909352604285019190915260c01b6001600160c01b0319166062840152606a830152608a82015260aa016040516020818303038152906040529050919050565b5f5b92915050565b600254604051600360f01b6020820152600160f81b60228201819052601160f01b6023830152602582015260809190911b6001600160801b0319166026820152606090603601604051602081830303815290604052905090565b604080518082019091525f80825260208201526040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91731a44076050125825900e736c501f859c50fe728c9163ddc28c5891810161134687610f8e565b815260200161135361127b565b81525f6020909101526040516001600160e01b031960e084901b16815261137f91903090600401611745565b6040805180830381865afa158015611399573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906113bd9190611815565b805190915015806113d15750602081015115155b1561127557604051636dac6a0960e01b815260040160405180910390fd5b5f6176aa6114006020840184611903565b63ffffffff1614801561143657507f00000000000000000000000000000000000000000000000000000000000000008260200135145b801561127557506001546001600160a01b0316151592915050565b60025f540361147357604051633ee5aeb560e01b815260040160405180910390fd5b60025f55565b60405180606001604052805f81526020015f6001600160401b031681526020016114b460405180604001604052805f81526020015f81525090565b905290565b5f602082840312156114c9575f5ffd5b81356001600160801b03811681146114df575f5ffd5b9392505050565b5f602082840312156114f6575f5ffd5b813560ff811681146114df575f5ffd5b5f608082019050825182526001600160401b0360208401511660208301526040830151611540604084018280518252602090810151910152565b5092915050565b6001600160a01b038116811461155b575f5ffd5b50565b5f6020828403121561156e575f5ffd5b81356114df81611547565b5f60608284031215611589575f5ffd5b50919050565b5f5f83601f84011261159f575f5ffd5b5081356001600160401b038111156115b5575f5ffd5b6020830191508360208285010111156115cc575f5ffd5b9250929050565b5f5f5f5f5f5f5f60e0888a0312156115e9575f5ffd5b6115f38989611579565b96506060880135955060808801356001600160401b03811115611614575f5ffd5b6116208a828b0161158f565b90965094505060a088013561163481611547565b925060c08801356001600160401b0381111561164e575f5ffd5b61165a8a828b0161158f565b989b979a50959850939692959293505050565b5f81518084525f5b8181101561169157602081850181015186830182015201611675565b505f602082860101526020601f19601f83011685010191505092915050565b602081525f6114df602083018461166d565b803563ffffffff81168114610783575f5ffd5b5f5f604083850312156116e6575f5ffd5b6116ef836116c2565b946020939093013593505050565b815181526020808301519082015260408101611275565b5f60208284031215611724575f5ffd5b5035919050565b5f6060828403121561173b575f5ffd5b6114df8383611579565b6040815263ffffffff8351166040820152602083015160608201525f604084015160a0608084015261177a60e084018261166d565b90506060850151603f198483030160a0850152611797828261166d565b60809690960151151560c08501525050506001600160a01b039190911660209091015290565b5f604082840312156117cd575f5ffd5b604080519081016001600160401b03811182821017156117fb57634e487b7160e01b5f52604160045260245ffd5b604052825181526020928301519281019290925250919050565b5f60408284031215611825575f5ffd5b6114df83836117bd565b6001600160401b038116811461155b575f5ffd5b5f6080828403128015611854575f5ffd5b50604051606081016001600160401b038111828210171561188357634e487b7160e01b5f52604160045260245ffd5b6040528251815260208301516118988161182f565b60208201526118aa84604085016117bd565b60408201529392505050565b5f602082840312156118c6575f5ffd5b81516114df8161182f565b5f602082840312156118e1575f5ffd5b81516114df81611547565b5f602082840312156118fc575f5ffd5b5051919050565b5f60208284031215611913575f5ffd5b6114df826116c2565b5f6020828403121561192c575f5ffd5b81356114df8161182f565b634e487b7160e01b5f52603260045260245ffd5b5f5f85851115611959575f5ffd5b83861115611965575f5ffd5b5050820193919092039150565b80356020831015611275575f19602084900360031b1b1692915050565b80356001600160c01b03198116906008841015611540576001600160c01b031960089490940360031b84901b1690921692915050565b818382375f9101908152919050565b634e487b7160e01b5f52602160045260245ffd5b5f602082840312156119f8575f5ffd5b8151600581106114df575f5ffdfe046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6baa2646970667358221220d5e0a008fcf934cc781ad8e21c7865f692e69e850ec3b05743fb3e9c2c69c09a64736f6c634300081e0033"
      },
      deployedBytecode: {
        immutableReferences: {
          "61": [
            {
              length: 32,
              start: 406
            },
            {
              length: 32,
              start: 1249
            },
            {
              length: 32,
              start: 3014
            },
            {
              length: 32,
              start: 4857
            },
            {
              length: 32,
              start: 5136
            }
          ],
          "63": [
            {
              length: 32,
              start: 908
            },
            {
              length: 32,
              start: 2145
            },
            {
              length: 32,
              start: 3395
            },
            {
              length: 32,
              start: 4252
            }
          ],
          "65": [
            {
              length: 32,
              start: 793
            },
            {
              length: 32,
              start: 1043
            },
            {
              length: 32,
              start: 1939
            },
            {
              length: 32,
              start: 2692
            }
          ]
        },
        object: "608060405260043610610105575f3560e01c80637d25a05e11610092578063b1f8671711610062578063b1f867171461033b578063c13bd9361461034f578063d96661ef1461037b578063e495f1d4146103ae578063ff7bd03d146103d9575f5ffd5b80637d25a05e1461028857806383d5f21d146102bf578063a7a1ed72146102e9578063acba7b4214610308575f5ffd5b806315aff54e116100d857806315aff54e146101855780634922eec1146101c65780634cedb60f146101f25780635e280f111461022957806378360c8814610268575f5ffd5b80630200e86b1461010957806307f53ee71461012a57806310265fa51461015357806313137d6514610172575b5f5ffd5b348015610114575f5ffd5b506101286101233660046114b9565b610408565b005b61013d6101383660046114e6565b6104c0565b60405161014a9190611506565b60405180910390f35b34801561015e575f5ffd5b5061012861016d36600461155e565b610788565b6101286101803660046115d3565b610b7f565b348015610190575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b60405190815260200161014a565b3480156101d1575f5ffd5b506101e56101e03660046114e6565b610f8e565b60405161014a91906116b0565b3480156101fd575f5ffd5b50600254610211906001600160801b031681565b6040516001600160801b03909116815260200161014a565b348015610234575f5ffd5b50610250731a44076050125825900e736c501f859c50fe728c81565b6040516001600160a01b03909116815260200161014a565b348015610273575f5ffd5b506101b85f516020611a075f395f51905f5281565b348015610293575f5ffd5b506102a76102a23660046116d5565b611273565b6040516001600160401b03909116815260200161014a565b3480156102ca575f5ffd5b506102d46176aa81565b60405163ffffffff909116815260200161014a565b3480156102f4575f5ffd5b50600154610250906001600160a01b031681565b348015610313575f5ffd5b506102507f000000000000000000000000000000000000000000000000000000000000000081565b348015610346575f5ffd5b506101e561127b565b34801561035a575f5ffd5b5061036e6103693660046114e6565b6112d5565b60405161014a91906116fd565b348015610386575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b3480156103b9575f5ffd5b506101b86103c8366004611714565b60036020525f908152604090205481565b3480156103e4575f5ffd5b506103f86103f336600461172b565b6113ef565b604051901515815260200161014a565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614158061044e57506002546001600160801b03908116908216105b1561046c57604051636dac6a0960e01b815260040160405180910390fd5b600280546001600160801b0319166001600160801b0383169081179091556040519081527f4bbad5fe035af81686d3e8380dfd61d879211cbe2c4e6e05f86ad07cdec099b09060200160405180910390a150565b6104c8611479565b6104d0611451565b6040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91810161051285610f8e565b815260200161051f61127b565b81525f6020909101819052604051631bb8518b60e31b815291925090731a44076050125825900e736c501f859c50fe728c9063ddc28c58906105679085903090600401611745565b6040805180830381865afa158015610581573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906105a59190611815565b805190915015806105b95750602081015115155b806105c5575080513414155b156105e357604051636dac6a0960e01b815260040160405180910390fd5b6040516302637a4560e41b8152731a44076050125825900e736c501f859c50fe728c90632637a45090349061061e9086903390600401611745565b60806040518083038185885af115801561063a573d5f5f3e3d5ffd5b50505050506040513d601f19601f8201168201806040525081019061065f9190611843565b8051909350158061067b575060208301516001600160401b0316155b8061068d575060408301516020015115155b8061069c575060408301515134105b156106ba57604051636dac6a0960e01b815260040160405180910390fd5b825f01517f6d23cdaef17712141c7441cf202389c6ddc063fb5c14788d5c4479b62096d13f8560015f9054906101000a90046001600160a01b03166001600160a01b031663172195226040518163ffffffff1660e01b8152600401602060405180830381865afa158015610730573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061075491906118b6565b6040805160ff90931683526001600160401b0390911660208301520160405180910390a2505061078360015f55565b919050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161415806107ca57506001546001600160a01b031615155b806107dd57506001600160a01b0381163b155b806108595750306001600160a01b0316816001600160a01b03166303eadcfc6040518163ffffffff1660e01b8152600401602060405180830381865afa158015610829573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061084d91906118d1565b6001600160a01b031614155b806108e357507f0000000000000000000000000000000000000000000000000000000000000000816001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156108bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906108e091906118ec565b14155b8061095c57505f516020611a075f395f51905f525f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa158015610935573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061095991906118ec565b14155b806109ec57507355d398326f99059ff775485246999027b31979556001600160a01b0316816001600160a01b031663e5a6b10f6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156109bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906109e091906118d1565b6001600160a01b031614155b80610a7c575073c440f06bbc7e58b0d055815f915447e4ae0e37206001600160a01b0316816001600160a01b03166361d027b36040518163ffffffff1660e01b8152600401602060405180830381865afa158015610a4c573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610a7091906118d1565b6001600160a01b031614155b80610b1857507f00000000000000000000000000000000000000000000000000000000000000006001600160a01b0316816001600160a01b031663f77c47916040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ae8573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610b0c91906118d1565b6001600160a01b031614155b15610b3657604051636dac6a0960e01b815260040160405180910390fd5b600180546001600160a01b0319166001600160a01b0383169081179091556040517f3916d079df018feca66a550908f671cff67410227b4a8c24f13531847e12b9c8905f90a250565b610b87611451565b33731a44076050125825900e736c501f859c50fe728c141580610bbe57506176aa610bb56020890189611903565b63ffffffff1614155b80610bed57507f0000000000000000000000000000000000000000000000000000000000000000876020013514155b80610c0157506001546001600160a01b0316155b80610c0a575085155b80610c2b5750610c20606088016040890161191c565b6001600160401b0316155b80610c3557503415155b15610c5357604051636dac6a0960e01b815260040160405180910390fd5b608a84141580610c7e575084845f818110610c7057610c70611937565b9091013560f81c6003141590505b15610c9c57604051636dac6a0960e01b815260040160405180910390fd5b5f85856001818110610cb057610cb0611937565b919091013560f81c91505f9050610ccb60226002888a61194b565b610cd491611972565b90505f610ce560426022898b61194b565b610cee91611972565b90505f610cff604a60428a8c61194b565b610d089161198f565b60c01c90505f610d1c606a604a8b8d61194b565b610d2591611972565b90505f610d36608a606a8c8e61194b565b610d3f91611972565b90507f000000000000000000000000000000000000000000000000000000000000000085141580610d7d57505f516020611a075f395f51905f528414155b80610d8f57506001600160401b038316155b15610dad57604051636dac6a0960e01b815260040160405180910390fd5b5f8b8b604051610dbe9291906119c5565b60408051918290039091205f8f81526003602052919091205490915015801590610df557505f8d8152600360205260409020548114155b15610e1357604051636dac6a0960e01b815260040160405180910390fd5b8660ff16600103610eb05782151580610e2b57508115155b15610e4957604051636dac6a0960e01b815260040160405180910390fd5b60015460405163579c848360e11b81526001600160401b03861660048201526001600160a01b039091169063af390906906024015b5f604051808303815f87803b158015610e95575f5ffd5b505af1158015610ea7573d5f5f3e3d5ffd5b50505050610f1b565b8660ff16600303610f025760015460405163367938c560e21b81526001600160401b038616600482015260248101859052604481018490526001600160a01b039091169063d9e4e31490606401610e7e565b604051636dac6a0960e01b815260040160405180910390fd5b5f8d815260036020908152604091829020839055815160ff8a1681526001600160401b038716918101919091528e917f37949e68c9d0a4e5f5474ddb8654f999a5dc4b58a8aa1aef313516586e9b320a910160405180910390a250505050505050610f8560015f55565b50505050505050565b6001546060906001600160a01b0316610fba57604051636dac6a0960e01b815260040160405180910390fd5b8160ff166002036110705760035b60015f9054906101000a90046001600160a01b03166001600160a01b031663c19d93fb6040518163ffffffff1660e01b8152600401602060405180830381865afa158015611018573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061103c91906119e8565b600481111561104d5761104d6119d4565b1461106b57604051636dac6a0960e01b815260040160405180910390fd5b611082565b8160ff16600403610f02576004610fc8565b60015460408051630b90ca9160e11b8152905160039285927f0000000000000000000000000000000000000000000000000000000000000000925f516020611a075f395f51905f52926001600160a01b03169163172195229160048083019260209291908290030181865afa1580156110fd573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061112191906118b6565b60015f9054906101000a90046001600160a01b03166001600160a01b0316635467e0a76040518163ffffffff1660e01b8152600401602060405180830381865afa158015611171573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061119591906118ec565b60015f9054906101000a90046001600160a01b03166001600160a01b03166366d003ac6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156111e5573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061120991906118ec565b60405160f897881b6001600160f81b031990811660208301529690971b90951660218701526022860193909352604285019190915260c01b6001600160c01b0319166062840152606a830152608a82015260aa016040516020818303038152906040529050919050565b5f5b92915050565b600254604051600360f01b6020820152600160f81b60228201819052601160f01b6023830152602582015260809190911b6001600160801b0319166026820152606090603601604051602081830303815290604052905090565b604080518082019091525f80825260208201526040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91731a44076050125825900e736c501f859c50fe728c9163ddc28c5891810161134687610f8e565b815260200161135361127b565b81525f6020909101526040516001600160e01b031960e084901b16815261137f91903090600401611745565b6040805180830381865afa158015611399573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906113bd9190611815565b805190915015806113d15750602081015115155b1561127557604051636dac6a0960e01b815260040160405180910390fd5b5f6176aa6114006020840184611903565b63ffffffff1614801561143657507f00000000000000000000000000000000000000000000000000000000000000008260200135145b801561127557506001546001600160a01b0316151592915050565b60025f540361147357604051633ee5aeb560e01b815260040160405180910390fd5b60025f55565b60405180606001604052805f81526020015f6001600160401b031681526020016114b460405180604001604052805f81526020015f81525090565b905290565b5f602082840312156114c9575f5ffd5b81356001600160801b03811681146114df575f5ffd5b9392505050565b5f602082840312156114f6575f5ffd5b813560ff811681146114df575f5ffd5b5f608082019050825182526001600160401b0360208401511660208301526040830151611540604084018280518252602090810151910152565b5092915050565b6001600160a01b038116811461155b575f5ffd5b50565b5f6020828403121561156e575f5ffd5b81356114df81611547565b5f60608284031215611589575f5ffd5b50919050565b5f5f83601f84011261159f575f5ffd5b5081356001600160401b038111156115b5575f5ffd5b6020830191508360208285010111156115cc575f5ffd5b9250929050565b5f5f5f5f5f5f5f60e0888a0312156115e9575f5ffd5b6115f38989611579565b96506060880135955060808801356001600160401b03811115611614575f5ffd5b6116208a828b0161158f565b90965094505060a088013561163481611547565b925060c08801356001600160401b0381111561164e575f5ffd5b61165a8a828b0161158f565b989b979a50959850939692959293505050565b5f81518084525f5b8181101561169157602081850181015186830182015201611675565b505f602082860101526020601f19601f83011685010191505092915050565b602081525f6114df602083018461166d565b803563ffffffff81168114610783575f5ffd5b5f5f604083850312156116e6575f5ffd5b6116ef836116c2565b946020939093013593505050565b815181526020808301519082015260408101611275565b5f60208284031215611724575f5ffd5b5035919050565b5f6060828403121561173b575f5ffd5b6114df8383611579565b6040815263ffffffff8351166040820152602083015160608201525f604084015160a0608084015261177a60e084018261166d565b90506060850151603f198483030160a0850152611797828261166d565b60809690960151151560c08501525050506001600160a01b039190911660209091015290565b5f604082840312156117cd575f5ffd5b604080519081016001600160401b03811182821017156117fb57634e487b7160e01b5f52604160045260245ffd5b604052825181526020928301519281019290925250919050565b5f60408284031215611825575f5ffd5b6114df83836117bd565b6001600160401b038116811461155b575f5ffd5b5f6080828403128015611854575f5ffd5b50604051606081016001600160401b038111828210171561188357634e487b7160e01b5f52604160045260245ffd5b6040528251815260208301516118988161182f565b60208201526118aa84604085016117bd565b60408201529392505050565b5f602082840312156118c6575f5ffd5b81516114df8161182f565b5f602082840312156118e1575f5ffd5b81516114df81611547565b5f602082840312156118fc575f5ffd5b5051919050565b5f60208284031215611913575f5ffd5b6114df826116c2565b5f6020828403121561192c575f5ffd5b81356114df8161182f565b634e487b7160e01b5f52603260045260245ffd5b5f5f85851115611959575f5ffd5b83861115611965575f5ffd5b5050820193919092039150565b80356020831015611275575f19602084900360031b1b1692915050565b80356001600160c01b03198116906008841015611540576001600160c01b031960089490940360031b84901b1690921692915050565b818382375f9101908152919050565b634e487b7160e01b5f52602160045260245ffd5b5f602082840312156119f8575f5ffd5b8151600581106114df575f5ffdfe046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6baa2646970667358221220d5e0a008fcf934cc781ad8e21c7865f692e69e850ec3b05743fb3e9c2c69c09a64736f6c634300081e0033"
      }
    }
  },
  pass: {
    abi: [
      {
        inputs: [
          {
            internalType: "address",
            name: "verifier",
            type: "address"
          }
        ],
        stateMutability: "nonpayable",
        type: "constructor"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "sender",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          },
          {
            internalType: "address",
            name: "owner",
            type: "address"
          }
        ],
        name: "ERC721IncorrectOwner",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "operator",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "ERC721InsufficientApproval",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "approver",
            type: "address"
          }
        ],
        name: "ERC721InvalidApprover",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "operator",
            type: "address"
          }
        ],
        name: "ERC721InvalidOperator",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "owner",
            type: "address"
          }
        ],
        name: "ERC721InvalidOwner",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "receiver",
            type: "address"
          }
        ],
        name: "ERC721InvalidReceiver",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "sender",
            type: "address"
          }
        ],
        name: "ERC721InvalidSender",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "ERC721NonexistentToken",
        type: "error"
      },
      {
        inputs: [],
        name: "Invalid",
        type: "error"
      },
      {
        inputs: [],
        name: "ReentrancyGuardReentrantCall",
        type: "error"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "token",
            type: "address"
          }
        ],
        name: "SafeERC20FailedOperation",
        type: "error"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "address",
            name: "owner",
            type: "address"
          },
          {
            indexed: true,
            internalType: "address",
            name: "approved",
            type: "address"
          },
          {
            indexed: true,
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "Approval",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "address",
            name: "owner",
            type: "address"
          },
          {
            indexed: true,
            internalType: "address",
            name: "operator",
            type: "address"
          },
          {
            indexed: false,
            internalType: "bool",
            name: "approved",
            type: "bool"
          }
        ],
        name: "ApprovalForAll",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          },
          {
            indexed: true,
            internalType: "address",
            name: "buyer",
            type: "address"
          },
          {
            indexed: false,
            internalType: "uint256",
            name: "amount",
            type: "uint256"
          }
        ],
        name: "PassPurchased",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: false,
            internalType: "bool",
            name: "paused",
            type: "bool"
          }
        ],
        name: "PurchasePauseChanged",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          },
          {
            indexed: true,
            internalType: "bytes32",
            name: "request",
            type: "bytes32"
          }
        ],
        name: "RedemptionFinalized",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          },
          {
            indexed: true,
            internalType: "bytes32",
            name: "request",
            type: "bytes32"
          },
          {
            indexed: false,
            internalType: "bytes32",
            name: "recipient",
            type: "bytes32"
          }
        ],
        name: "RedemptionRequested",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "uint64",
            name: "generation",
            type: "uint64"
          }
        ],
        name: "ReserveConfirmed",
        type: "event"
      },
      {
        anonymous: false,
        inputs: [
          {
            indexed: true,
            internalType: "address",
            name: "from",
            type: "address"
          },
          {
            indexed: true,
            internalType: "address",
            name: "to",
            type: "address"
          },
          {
            indexed: true,
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "Transfer",
        type: "event"
      },
      {
        inputs: [],
        name: "PRICE",
        outputs: [
          {
            internalType: "uint256",
            name: "",
            type: "uint256"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint64",
            name: "gen",
            type: "uint64"
          },
          {
            internalType: "bytes32",
            name: "request",
            type: "bytes32"
          },
          {
            internalType: "bytes32",
            name: "suiRecipient",
            type: "bytes32"
          }
        ],
        name: "acknowledge",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "adapter",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "to",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "approve",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "backingNFT",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "owner",
            type: "address"
          }
        ],
        name: "balanceOf",
        outputs: [
          {
            internalType: "uint256",
            name: "",
            type: "uint256"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "buy",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "wallet",
            type: "address"
          }
        ],
        name: "canPlay",
        outputs: [
          {
            internalType: "bool",
            name: "",
            type: "bool"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint64",
            name: "next",
            type: "uint64"
          }
        ],
        name: "confirmReserve",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "controller",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "currency",
        outputs: [
          {
            internalType: "contract IERC20",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "currencyCodeHash",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "generation",
        outputs: [
          {
            internalType: "uint64",
            name: "",
            type: "uint64"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "getApproved",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "initialBuyer",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "owner",
            type: "address"
          },
          {
            internalType: "address",
            name: "operator",
            type: "address"
          }
        ],
        name: "isApprovedForAll",
        outputs: [
          {
            internalType: "bool",
            name: "",
            type: "bool"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "name",
        outputs: [
          {
            internalType: "string",
            name: "",
            type: "string"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "ownerOf",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "purchasesPaused",
        outputs: [
          {
            internalType: "bool",
            name: "",
            type: "bool"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "recipient",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "redemption",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "bytes32",
            name: "suiRecipient",
            type: "bytes32"
          }
        ],
        name: "requestRedemption",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "route",
        outputs: [
          {
            internalType: "bytes32",
            name: "",
            type: "bytes32"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "from",
            type: "address"
          },
          {
            internalType: "address",
            name: "to",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "safeTransferFrom",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "from",
            type: "address"
          },
          {
            internalType: "address",
            name: "to",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          },
          {
            internalType: "bytes",
            name: "data",
            type: "bytes"
          }
        ],
        name: "safeTransferFrom",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "operator",
            type: "address"
          },
          {
            internalType: "bool",
            name: "approved",
            type: "bool"
          }
        ],
        name: "setApprovalForAll",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "bool",
            name: "paused",
            type: "bool"
          }
        ],
        name: "setPurchasesPaused",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "state",
        outputs: [
          {
            internalType: "enum TreeSuitePass.State",
            name: "",
            type: "uint8"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "bytes4",
            name: "interfaceId",
            type: "bytes4"
          }
        ],
        name: "supportsInterface",
        outputs: [
          {
            internalType: "bool",
            name: "",
            type: "bool"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [],
        name: "symbol",
        outputs: [
          {
            internalType: "string",
            name: "",
            type: "string"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "tokenURI",
        outputs: [
          {
            internalType: "string",
            name: "",
            type: "string"
          }
        ],
        stateMutability: "view",
        type: "function"
      },
      {
        inputs: [
          {
            internalType: "address",
            name: "from",
            type: "address"
          },
          {
            internalType: "address",
            name: "to",
            type: "address"
          },
          {
            internalType: "uint256",
            name: "tokenId",
            type: "uint256"
          }
        ],
        name: "transferFrom",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
      },
      {
        inputs: [],
        name: "treasury",
        outputs: [
          {
            internalType: "address",
            name: "",
            type: "address"
          }
        ],
        stateMutability: "view",
        type: "function"
      }
    ],
    evm: {
      bytecode: {
        object: "610120604052600a805460ff1916600117905534801561001d575f5ffd5b506040516124c33803806124c383398101604081905261003c916104aa565b6040518060400160405280601c81526020017f4e46547265652053756974652047656e65726174696f6e205061737300000000815250604051806040016040528060078152602001662a2922a2a3a2a760c91b815250815f90816100a0919061056f565b5060016100ad828261056f565b50506001600655504660381415806100d857507355d398326f99059ff775485246999027b31979553b155b806100eb57506001600160a01b0381163b155b8061016d57507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610141573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906101659190610629565b60ff16601214155b1561018b57604051636dac6a0960e01b815260040160405180910390fd5b5f819050336001600160a01b0316816001600160a01b031663acba7b426040518163ffffffff1660e01b8152600401602060405180830381865afa1580156101d5573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906101f991906104aa565b6001600160a01b03161415806102945750731a44076050125825900e736c501f859c50fe728c6001600160a01b0316816001600160a01b0316635e280f116040518163ffffffff1660e01b8152600401602060405180830381865afa158015610264573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061028891906104aa565b6001600160a01b031614155b806102fc5750806001600160a01b03166315aff54e6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156102d6573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906102fa9190610649565b155b806103645750806001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa15801561033e573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906103629190610649565b155b806103f057507f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba5f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa1580156103c9573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906103ed9190610649565b14155b1561040e57604051636dac6a0960e01b815260040160405180910390fd5b6001600160a01b038083166080523360a081905260c0526040805163d96661ef60e01b815290519183169163d96661ef916004808201926020929091908290030181865afa158015610462573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906104869190610649565b60e05250507355d398326f99059ff775485246999027b31979553f61010052610660565b5f602082840312156104ba575f5ffd5b81516001600160a01b03811681146104d0575f5ffd5b9392505050565b634e487b7160e01b5f52604160045260245ffd5b600181811c908216806104ff57607f821691505b60208210810361051d57634e487b7160e01b5f52602260045260245ffd5b50919050565b601f82111561056a57805f5260205f20601f840160051c810160208510156105485750805b601f840160051c820191505b81811015610567575f8155600101610554565b50505b505050565b81516001600160401b03811115610588576105886104d7565b61059c8161059684546104eb565b84610523565b6020601f8211600181146105ce575f83156105b75750848201515b5f19600385901b1c1916600184901b178455610567565b5f84815260208120601f198516915b828110156105fd57878501518255602094850194600190920191016105dd565b508482101561061a57868401515f19600387901b60f8161c191681555b50505050600190811b01905550565b5f60208284031215610639575f5ffd5b815160ff811681146104d0575f5ffd5b5f60208284031215610659575f5ffd5b5051919050565b60805160a05160c05160e05161010051611dfc6106c75f395f81816102620152610a5101525f818161049701526108e101525f81816104ff015261073701525f81816103900152610a1001525f818161022301528181610d200152610f3c0152611dfc5ff3fe608060405234801561000f575f5ffd5b50600436106101f2575f3560e01c806370a0823111610114578063b88d4fde116100a9578063d96661ef11610079578063d96661ef14610492578063d9e4e314146104b9578063e5a6b10f146104cc578063e985e9c5146104e7578063f77c4791146104fa575f5ffd5b8063b88d4fde14610445578063c19d93fb14610458578063c87b56dd14610472578063c9f2071514610485575f5ffd5b806397579dd3116100e457806397579dd314610404578063a22cb46514610417578063a6f2ae3a1461042a578063af39090614610432575f5ffd5b806370a08231146103b257806378360c88146103c55780638d859f3e146103ec57806395d89b41146103fc575f5ffd5b806323b872dd1161018a57806361d027b31161015a57806361d027b3146103545780636352211e1461036f57806366d003ac146103825780636af7f9f51461038b575f5ffd5b806323b872dd14610312578063325832ac1461032557806342842e0e146103385780635467e0a71461034b575f5ffd5b8063081812fc116101c5578063081812fc146102a75780630823d5f3146102ba578063095ea7b3146102cd57806317219522146102e2575f5ffd5b806301ffc9a7146101f657806303eadcfc1461021e57806306f660a71461025d57806306fdde0314610292575b5f5ffd5b610209610204366004611962565b610521565b60405190151581526020015b60405180910390f35b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6040516001600160a01b039091168152602001610215565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b604051908152602001610215565b61029a610572565b60405161021591906119ca565b6102456102b53660046119dc565b610601565b6102096102c8366004611a09565b610628565b6102e06102db366004611a22565b61068f565b005b6007546102fa9061010090046001600160401b031681565b6040516001600160401b039091168152602001610215565b6102e0610320366004611a4a565b61069e565b6102e0610333366004611a93565b61072c565b6102e0610346366004611a4a565b6107bc565b61028460085481565b61024573c440f06bbc7e58b0d055815f915447e4ae0e372081565b61024561037d3660046119dc565b6107db565b61028460095481565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6102846103c0366004611a09565b6107e5565b6102847f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba81565b61028468015af1d78b58c4000081565b61029a61082a565b6102846104123660046119dc565b610839565b6102e0610425366004611aac565b6109c4565b6102e06109cf565b6102e0610440366004611af3565b610d15565b6102e0610453366004611b20565b610ea8565b6007546104659060ff1681565b6040516102159190611c0e565b61029a6104803660046119dc565b610ec0565b600a546102099060ff1681565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b6102e06104c7366004611c34565b610f31565b6102457355d398326f99059ff775485246999027b319795581565b6102096104f5366004611c64565b61109d565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b5f6001600160e01b031982166380ac58cd60e01b148061055157506001600160e01b03198216635b5e139f60e01b145b8061056c57506301ffc9a760e01b6001600160e01b03198316145b92915050565b60605f805461058090611c8c565b80601f01602080910402602001604051908101604052809291908181526020018280546105ac90611c8c565b80156105f75780601f106105ce576101008083540402835291602001916105f7565b820191905f5260205f20905b8154815290600101906020018083116105da57829003601f168201915b5050505050905090565b5f61060b826110ca565b505f828152600460205260409020546001600160a01b031661056c565b5f600260075460ff16600481111561064257610642611bfa565b14801561065757506001600160a01b03821615155b801561056c57505060075461010090046001600160401b03165f908152600260205260409020546001600160a01b0391821691161490565b61069a828233611102565b5050565b6001600160a01b0382166106cc57604051633250574960e11b81525f60048201526024015b60405180910390fd5b5f6106d883833361110f565b9050836001600160a01b0316816001600160a01b031614610726576040516364283d7b60e01b81526001600160a01b03808616600483015260248201849052821660448201526064016106c3565b50505050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161461077557604051636dac6a0960e01b815260040160405180910390fd5b600a805460ff19168215159081179091556040519081527fd6d0fdd597c17a0211f0324826035a55dec84b1e6196f3585be220b46767fbb99060200160405180910390a150565b6107d683838360405180602001604052805f815250610ea8565b505050565b5f61056c826110ca565b5f6001600160a01b03821661080f576040516322718ad960e21b81525f60048201526024016106c3565b506001600160a01b03165f9081526003602052604090205490565b60606001805461058090611c8c565b5f6108426111ad565b600260075460ff16600481111561085b5761085b611bfa565b14158061088b5750600754339061087f9061010090046001600160401b03166107db565b6001600160a01b031614155b80610894575081155b156108b257604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff1916600390811791829055600984905560408051602081019290925246908201523060608201527f000000000000000000000000000000000000000000000000000000000000000060808201527f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba60a08201526001600160401b03610100928390041660c08201523360e08201529081018390526101200160408051808303601f19018152908290528051602091820120600881905560075485845290926101009091046001600160401b0316917f5852bd51fa2990e2712a8f82286a04ca0750a7646a7950235ffefdb10585cefe910160405180910390a3506008546109bf6001600655565b919050565b61069a3383836111d7565b6109d76111ad565b600160075460ff1660048111156109f0576109f0611bfa565b1415806109ff5750600a5460ff165b80610a335750336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614155b80610a7357507355d398326f99059ff775485246999027b31979553f7f000000000000000000000000000000000000000000000000000000000000000014155b80610af557507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ac9573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610aed9190611cc4565b60ff16601214155b15610b1357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660021790556040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201525f907355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610b83573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610ba79190611ce4565b9050610be67355d398326f99059ff775485246999027b31979553373c440f06bbc7e58b0d055815f915447e4ae0e372068015af1d78b58c40000611275565b610bf968015af1d78b58c4000082611d0f565b6040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201527355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610c5a573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610c7e9190611ce4565b14610c9c57604051636dac6a0960e01b815260040160405180910390fd5b600754610cb890339061010090046001600160401b03166112cf565b60075460405168015af1d78b58c400008152339161010090046001600160401b0316907f266845010576f42f87c2d262b76328c22b6797abd6c81b34f59fc1b2da1c487e9060200160405180910390a350610d136001600655565b565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610d5e57604051636dac6a0960e01b815260040160405180910390fd5b806001600160401b03165f03610d8757604051636dac6a0960e01b815260040160405180910390fd5b6007546001600160401b038281166101009092041614610ea557600754610dbd9061010090046001600160401b03166001611d22565b6001600160401b0316816001600160401b0316141580610e1557505f60075460ff166004811115610df057610df0611bfa565b14158015610e155750600460075460ff166004811115610e1257610e12611bfa565b14155b15610e3357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff196001600160401b0384166101008102821668ffffffffffffffffff199093169290921760019081179093555f60088190556009819055600a8054909216909317905560405190917ff48a2acdce0f4a30c2d32425d8827b030bbdff66b7694573d92cdd52b818fd1691a25b50565b610eb384848461069e565b61072633858585856112e8565b6060610ecb826110ca565b505f610ee160408051602081019091525f815290565b90505f815111610eff5760405180602001604052805f815250610f2a565b80610f0984611410565b604051602001610f1a929190611d41565b6040516020818303038152906040525b9392505050565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610f7a57604051636dac6a0960e01b815260040160405180910390fd5b610f826111ad565b6007546001600160401b0384811661010090920416141580610fa2575081155b80610faf57506008548214155b80610fbc57506009548114155b15610fda57604051636dac6a0960e01b815260040160405180910390fd5b600460075460ff166004811115610ff357610ff3611bfa565b1461109357600360075460ff16600481111561101157611011611bfa565b1461102f57604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660041790819055611056906001600160401b036101009091041661149f565b600754604051839161010090046001600160401b0316907f4baa52424160077091b85a05340629c1a44cfac77a87274fad62a384fe6193f0905f90a35b6107d66001600655565b6001600160a01b039182165f90815260056020908152604080832093909416825291909152205460ff1690565b5f818152600260205260408120546001600160a01b03168061056c57604051637e27328960e01b8152600481018490526024016106c3565b6107d683838360016114d7565b6007545f9061010090046001600160401b03168314158061117c5750600260075460ff16600481111561114457611144611bfa565b1415801561117c5750600460075460ff16600481111561116657611166611bfa565b14801561117a57506001600160a01b038416155b155b1561119a57604051636dac6a0960e01b815260040160405180910390fd5b6111a58484846115db565b949350505050565b6002600654036111d057604051633ee5aeb560e01b815260040160405180910390fd5b6002600655565b6001600160a01b03821661120957604051630b61174360e31b81526001600160a01b03831660048201526024016106c3565b6001600160a01b038381165f81815260056020908152604080832094871680845294825291829020805460ff191686151590811790915591519182527f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31910160405180910390a3505050565b604080516001600160a01b0385811660248301528416604482015260648082018490528251808303909101815260849091019091526020810180516001600160e01b03166323b872dd60e01b1790526107269085906116cd565b61069a828260405180602001604052805f815250611739565b6001600160a01b0383163b1561140957604051630a85bd0160e11b81526001600160a01b0384169063150b7a029061132a908890889087908790600401611d6f565b6020604051808303815f875af1925050508015611364575060408051601f3d908101601f1916820190925261136191810190611dab565b60015b6113cb573d808015611391576040519150601f19603f3d011682016040523d82523d5f602084013e611396565b606091505b5080515f036113c357604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b805160208201fd5b6001600160e01b03198116630a85bd0160e11b1461140757604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b505b5050505050565b60605f61141c83611750565b60010190505f816001600160401b0381111561143a5761143a611b0c565b6040519080825280601f01601f191660200182016040528015611464576020820181803683370190505b5090508181016020015b5f19016f181899199a1a9b1b9c1cb0b131b232b360811b600a86061a8153600a850494508461146e57509392505050565b5f6114ab5f835f61110f565b90506001600160a01b03811661069a57604051637e27328960e01b8152600481018390526024016106c3565b80806114eb57506001600160a01b03821615155b156115ac575f6114fa846110ca565b90506001600160a01b038316158015906115265750826001600160a01b0316816001600160a01b031614155b80156115395750611537818461109d565b155b156115625760405163a9fbf51f60e01b81526001600160a01b03841660048201526024016106c3565b81156115aa5783856001600160a01b0316826001600160a01b03167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45b505b50505f90815260046020526040902080546001600160a01b0319166001600160a01b0392909216919091179055565b5f828152600260205260408120546001600160a01b039081169083161561160757611607818486611827565b6001600160a01b03811615611641576116225f855f5f6114d7565b6001600160a01b0381165f90815260036020526040902080545f190190555b6001600160a01b0385161561166f576001600160a01b0385165f908152600360205260409020805460010190555b5f8481526002602052604080822080546001600160a01b0319166001600160a01b0389811691821790925591518793918516917fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef91a4949350505050565b5f5f60205f8451602086015f885af1806116ec576040513d5f823e3d81fd5b50505f513d91508115611703578060011415611710565b6001600160a01b0384163b155b1561072657604051635274afe760e01b81526001600160a01b03851660048201526024016106c3565b611743838361188b565b6107d6335f8585856112e8565b5f8072184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b831061178e5772184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b830492506040015b6d04ee2d6d415b85acef810000000083106117ba576d04ee2d6d415b85acef8100000000830492506020015b662386f26fc1000083106117d857662386f26fc10000830492506010015b6305f5e10083106117f0576305f5e100830492506008015b612710831061180457612710830492506004015b60648310611816576064830492506002015b600a831061056c5760010192915050565b6118328383836118ec565b6107d6576001600160a01b03831661186057604051637e27328960e01b8152600481018290526024016106c3565b60405163177e802f60e01b81526001600160a01b0383166004820152602481018290526044016106c3565b6001600160a01b0382166118b457604051633250574960e11b81525f60048201526024016106c3565b5f6118c083835f61110f565b90506001600160a01b038116156107d6576040516339e3563760e11b81525f60048201526024016106c3565b5f6001600160a01b038316158015906111a55750826001600160a01b0316846001600160a01b031614806119255750611925848461109d565b806111a55750505f908152600460205260409020546001600160a01b03908116911614919050565b6001600160e01b031981168114610ea5575f5ffd5b5f60208284031215611972575f5ffd5b8135610f2a8161194d565b5f5b8381101561199757818101518382015260200161197f565b50505f910152565b5f81518084526119b681602086016020860161197d565b601f01601f19169290920160200192915050565b602081525f610f2a602083018461199f565b5f602082840312156119ec575f5ffd5b5035919050565b80356001600160a01b03811681146109bf575f5ffd5b5f60208284031215611a19575f5ffd5b610f2a826119f3565b5f5f60408385031215611a33575f5ffd5b611a3c836119f3565b946020939093013593505050565b5f5f5f60608486031215611a5c575f5ffd5b611a65846119f3565b9250611a73602085016119f3565b929592945050506040919091013590565b803580151581146109bf575f5ffd5b5f60208284031215611aa3575f5ffd5b610f2a82611a84565b5f5f60408385031215611abd575f5ffd5b611ac6836119f3565b9150611ad460208401611a84565b90509250929050565b80356001600160401b03811681146109bf575f5ffd5b5f60208284031215611b03575f5ffd5b610f2a82611add565b634e487b7160e01b5f52604160045260245ffd5b5f5f5f5f60808587031215611b33575f5ffd5b611b3c856119f3565b9350611b4a602086016119f3565b92506040850135915060608501356001600160401b03811115611b6b575f5ffd5b8501601f81018713611b7b575f5ffd5b80356001600160401b03811115611b9457611b94611b0c565b604051601f8201601f19908116603f011681016001600160401b0381118282101715611bc257611bc2611b0c565b604052818152828201602001891015611bd9575f5ffd5b816020840160208301375f6020838301015280935050505092959194509250565b634e487b7160e01b5f52602160045260245ffd5b6020810160058310611c2e57634e487b7160e01b5f52602160045260245ffd5b91905290565b5f5f5f60608486031215611c46575f5ffd5b611c4f84611add565b95602085013595506040909401359392505050565b5f5f60408385031215611c75575f5ffd5b611c7e836119f3565b9150611ad4602084016119f3565b600181811c90821680611ca057607f821691505b602082108103611cbe57634e487b7160e01b5f52602260045260245ffd5b50919050565b5f60208284031215611cd4575f5ffd5b815160ff81168114610f2a575f5ffd5b5f60208284031215611cf4575f5ffd5b5051919050565b634e487b7160e01b5f52601160045260245ffd5b8082018082111561056c5761056c611cfb565b6001600160401b03818116838216019081111561056c5761056c611cfb565b5f8351611d5281846020880161197d565b835190830190611d6681836020880161197d565b01949350505050565b6001600160a01b03858116825284166020820152604081018390526080606082018190525f90611da19083018461199f565b9695505050505050565b5f60208284031215611dbb575f5ffd5b8151610f2a8161194d56fea26469706673582212205cd0600d0bc59401f6362a6ffeeddd9fccccd322ad458bc4283018628c84b01f64736f6c634300081e0033"
      },
      deployedBytecode: {
        immutableReferences: {
          "880": [
            {
              length: 32,
              start: 547
            },
            {
              length: 32,
              start: 3360
            },
            {
              length: 32,
              start: 3900
            }
          ],
          "882": [
            {
              length: 32,
              start: 912
            },
            {
              length: 32,
              start: 2576
            }
          ],
          "884": [
            {
              length: 32,
              start: 1279
            },
            {
              length: 32,
              start: 1847
            }
          ],
          "886": [
            {
              length: 32,
              start: 1175
            },
            {
              length: 32,
              start: 2273
            }
          ],
          "888": [
            {
              length: 32,
              start: 610
            },
            {
              length: 32,
              start: 2641
            }
          ]
        },
        object: "608060405234801561000f575f5ffd5b50600436106101f2575f3560e01c806370a0823111610114578063b88d4fde116100a9578063d96661ef11610079578063d96661ef14610492578063d9e4e314146104b9578063e5a6b10f146104cc578063e985e9c5146104e7578063f77c4791146104fa575f5ffd5b8063b88d4fde14610445578063c19d93fb14610458578063c87b56dd14610472578063c9f2071514610485575f5ffd5b806397579dd3116100e457806397579dd314610404578063a22cb46514610417578063a6f2ae3a1461042a578063af39090614610432575f5ffd5b806370a08231146103b257806378360c88146103c55780638d859f3e146103ec57806395d89b41146103fc575f5ffd5b806323b872dd1161018a57806361d027b31161015a57806361d027b3146103545780636352211e1461036f57806366d003ac146103825780636af7f9f51461038b575f5ffd5b806323b872dd14610312578063325832ac1461032557806342842e0e146103385780635467e0a71461034b575f5ffd5b8063081812fc116101c5578063081812fc146102a75780630823d5f3146102ba578063095ea7b3146102cd57806317219522146102e2575f5ffd5b806301ffc9a7146101f657806303eadcfc1461021e57806306f660a71461025d57806306fdde0314610292575b5f5ffd5b610209610204366004611962565b610521565b60405190151581526020015b60405180910390f35b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6040516001600160a01b039091168152602001610215565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b604051908152602001610215565b61029a610572565b60405161021591906119ca565b6102456102b53660046119dc565b610601565b6102096102c8366004611a09565b610628565b6102e06102db366004611a22565b61068f565b005b6007546102fa9061010090046001600160401b031681565b6040516001600160401b039091168152602001610215565b6102e0610320366004611a4a565b61069e565b6102e0610333366004611a93565b61072c565b6102e0610346366004611a4a565b6107bc565b61028460085481565b61024573c440f06bbc7e58b0d055815f915447e4ae0e372081565b61024561037d3660046119dc565b6107db565b61028460095481565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6102846103c0366004611a09565b6107e5565b6102847f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba81565b61028468015af1d78b58c4000081565b61029a61082a565b6102846104123660046119dc565b610839565b6102e0610425366004611aac565b6109c4565b6102e06109cf565b6102e0610440366004611af3565b610d15565b6102e0610453366004611b20565b610ea8565b6007546104659060ff1681565b6040516102159190611c0e565b61029a6104803660046119dc565b610ec0565b600a546102099060ff1681565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b6102e06104c7366004611c34565b610f31565b6102457355d398326f99059ff775485246999027b319795581565b6102096104f5366004611c64565b61109d565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b5f6001600160e01b031982166380ac58cd60e01b148061055157506001600160e01b03198216635b5e139f60e01b145b8061056c57506301ffc9a760e01b6001600160e01b03198316145b92915050565b60605f805461058090611c8c565b80601f01602080910402602001604051908101604052809291908181526020018280546105ac90611c8c565b80156105f75780601f106105ce576101008083540402835291602001916105f7565b820191905f5260205f20905b8154815290600101906020018083116105da57829003601f168201915b5050505050905090565b5f61060b826110ca565b505f828152600460205260409020546001600160a01b031661056c565b5f600260075460ff16600481111561064257610642611bfa565b14801561065757506001600160a01b03821615155b801561056c57505060075461010090046001600160401b03165f908152600260205260409020546001600160a01b0391821691161490565b61069a828233611102565b5050565b6001600160a01b0382166106cc57604051633250574960e11b81525f60048201526024015b60405180910390fd5b5f6106d883833361110f565b9050836001600160a01b0316816001600160a01b031614610726576040516364283d7b60e01b81526001600160a01b03808616600483015260248201849052821660448201526064016106c3565b50505050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161461077557604051636dac6a0960e01b815260040160405180910390fd5b600a805460ff19168215159081179091556040519081527fd6d0fdd597c17a0211f0324826035a55dec84b1e6196f3585be220b46767fbb99060200160405180910390a150565b6107d683838360405180602001604052805f815250610ea8565b505050565b5f61056c826110ca565b5f6001600160a01b03821661080f576040516322718ad960e21b81525f60048201526024016106c3565b506001600160a01b03165f9081526003602052604090205490565b60606001805461058090611c8c565b5f6108426111ad565b600260075460ff16600481111561085b5761085b611bfa565b14158061088b5750600754339061087f9061010090046001600160401b03166107db565b6001600160a01b031614155b80610894575081155b156108b257604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff1916600390811791829055600984905560408051602081019290925246908201523060608201527f000000000000000000000000000000000000000000000000000000000000000060808201527f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba60a08201526001600160401b03610100928390041660c08201523360e08201529081018390526101200160408051808303601f19018152908290528051602091820120600881905560075485845290926101009091046001600160401b0316917f5852bd51fa2990e2712a8f82286a04ca0750a7646a7950235ffefdb10585cefe910160405180910390a3506008546109bf6001600655565b919050565b61069a3383836111d7565b6109d76111ad565b600160075460ff1660048111156109f0576109f0611bfa565b1415806109ff5750600a5460ff165b80610a335750336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614155b80610a7357507355d398326f99059ff775485246999027b31979553f7f000000000000000000000000000000000000000000000000000000000000000014155b80610af557507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ac9573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610aed9190611cc4565b60ff16601214155b15610b1357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660021790556040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201525f907355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610b83573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610ba79190611ce4565b9050610be67355d398326f99059ff775485246999027b31979553373c440f06bbc7e58b0d055815f915447e4ae0e372068015af1d78b58c40000611275565b610bf968015af1d78b58c4000082611d0f565b6040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201527355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610c5a573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610c7e9190611ce4565b14610c9c57604051636dac6a0960e01b815260040160405180910390fd5b600754610cb890339061010090046001600160401b03166112cf565b60075460405168015af1d78b58c400008152339161010090046001600160401b0316907f266845010576f42f87c2d262b76328c22b6797abd6c81b34f59fc1b2da1c487e9060200160405180910390a350610d136001600655565b565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610d5e57604051636dac6a0960e01b815260040160405180910390fd5b806001600160401b03165f03610d8757604051636dac6a0960e01b815260040160405180910390fd5b6007546001600160401b038281166101009092041614610ea557600754610dbd9061010090046001600160401b03166001611d22565b6001600160401b0316816001600160401b0316141580610e1557505f60075460ff166004811115610df057610df0611bfa565b14158015610e155750600460075460ff166004811115610e1257610e12611bfa565b14155b15610e3357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff196001600160401b0384166101008102821668ffffffffffffffffff199093169290921760019081179093555f60088190556009819055600a8054909216909317905560405190917ff48a2acdce0f4a30c2d32425d8827b030bbdff66b7694573d92cdd52b818fd1691a25b50565b610eb384848461069e565b61072633858585856112e8565b6060610ecb826110ca565b505f610ee160408051602081019091525f815290565b90505f815111610eff5760405180602001604052805f815250610f2a565b80610f0984611410565b604051602001610f1a929190611d41565b6040516020818303038152906040525b9392505050565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610f7a57604051636dac6a0960e01b815260040160405180910390fd5b610f826111ad565b6007546001600160401b0384811661010090920416141580610fa2575081155b80610faf57506008548214155b80610fbc57506009548114155b15610fda57604051636dac6a0960e01b815260040160405180910390fd5b600460075460ff166004811115610ff357610ff3611bfa565b1461109357600360075460ff16600481111561101157611011611bfa565b1461102f57604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660041790819055611056906001600160401b036101009091041661149f565b600754604051839161010090046001600160401b0316907f4baa52424160077091b85a05340629c1a44cfac77a87274fad62a384fe6193f0905f90a35b6107d66001600655565b6001600160a01b039182165f90815260056020908152604080832093909416825291909152205460ff1690565b5f818152600260205260408120546001600160a01b03168061056c57604051637e27328960e01b8152600481018490526024016106c3565b6107d683838360016114d7565b6007545f9061010090046001600160401b03168314158061117c5750600260075460ff16600481111561114457611144611bfa565b1415801561117c5750600460075460ff16600481111561116657611166611bfa565b14801561117a57506001600160a01b038416155b155b1561119a57604051636dac6a0960e01b815260040160405180910390fd5b6111a58484846115db565b949350505050565b6002600654036111d057604051633ee5aeb560e01b815260040160405180910390fd5b6002600655565b6001600160a01b03821661120957604051630b61174360e31b81526001600160a01b03831660048201526024016106c3565b6001600160a01b038381165f81815260056020908152604080832094871680845294825291829020805460ff191686151590811790915591519182527f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31910160405180910390a3505050565b604080516001600160a01b0385811660248301528416604482015260648082018490528251808303909101815260849091019091526020810180516001600160e01b03166323b872dd60e01b1790526107269085906116cd565b61069a828260405180602001604052805f815250611739565b6001600160a01b0383163b1561140957604051630a85bd0160e11b81526001600160a01b0384169063150b7a029061132a908890889087908790600401611d6f565b6020604051808303815f875af1925050508015611364575060408051601f3d908101601f1916820190925261136191810190611dab565b60015b6113cb573d808015611391576040519150601f19603f3d011682016040523d82523d5f602084013e611396565b606091505b5080515f036113c357604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b805160208201fd5b6001600160e01b03198116630a85bd0160e11b1461140757604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b505b5050505050565b60605f61141c83611750565b60010190505f816001600160401b0381111561143a5761143a611b0c565b6040519080825280601f01601f191660200182016040528015611464576020820181803683370190505b5090508181016020015b5f19016f181899199a1a9b1b9c1cb0b131b232b360811b600a86061a8153600a850494508461146e57509392505050565b5f6114ab5f835f61110f565b90506001600160a01b03811661069a57604051637e27328960e01b8152600481018390526024016106c3565b80806114eb57506001600160a01b03821615155b156115ac575f6114fa846110ca565b90506001600160a01b038316158015906115265750826001600160a01b0316816001600160a01b031614155b80156115395750611537818461109d565b155b156115625760405163a9fbf51f60e01b81526001600160a01b03841660048201526024016106c3565b81156115aa5783856001600160a01b0316826001600160a01b03167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45b505b50505f90815260046020526040902080546001600160a01b0319166001600160a01b0392909216919091179055565b5f828152600260205260408120546001600160a01b039081169083161561160757611607818486611827565b6001600160a01b03811615611641576116225f855f5f6114d7565b6001600160a01b0381165f90815260036020526040902080545f190190555b6001600160a01b0385161561166f576001600160a01b0385165f908152600360205260409020805460010190555b5f8481526002602052604080822080546001600160a01b0319166001600160a01b0389811691821790925591518793918516917fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef91a4949350505050565b5f5f60205f8451602086015f885af1806116ec576040513d5f823e3d81fd5b50505f513d91508115611703578060011415611710565b6001600160a01b0384163b155b1561072657604051635274afe760e01b81526001600160a01b03851660048201526024016106c3565b611743838361188b565b6107d6335f8585856112e8565b5f8072184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b831061178e5772184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b830492506040015b6d04ee2d6d415b85acef810000000083106117ba576d04ee2d6d415b85acef8100000000830492506020015b662386f26fc1000083106117d857662386f26fc10000830492506010015b6305f5e10083106117f0576305f5e100830492506008015b612710831061180457612710830492506004015b60648310611816576064830492506002015b600a831061056c5760010192915050565b6118328383836118ec565b6107d6576001600160a01b03831661186057604051637e27328960e01b8152600481018290526024016106c3565b60405163177e802f60e01b81526001600160a01b0383166004820152602481018290526044016106c3565b6001600160a01b0382166118b457604051633250574960e11b81525f60048201526024016106c3565b5f6118c083835f61110f565b90506001600160a01b038116156107d6576040516339e3563760e11b81525f60048201526024016106c3565b5f6001600160a01b038316158015906111a55750826001600160a01b0316846001600160a01b031614806119255750611925848461109d565b806111a55750505f908152600460205260409020546001600160a01b03908116911614919050565b6001600160e01b031981168114610ea5575f5ffd5b5f60208284031215611972575f5ffd5b8135610f2a8161194d565b5f5b8381101561199757818101518382015260200161197f565b50505f910152565b5f81518084526119b681602086016020860161197d565b601f01601f19169290920160200192915050565b602081525f610f2a602083018461199f565b5f602082840312156119ec575f5ffd5b5035919050565b80356001600160a01b03811681146109bf575f5ffd5b5f60208284031215611a19575f5ffd5b610f2a826119f3565b5f5f60408385031215611a33575f5ffd5b611a3c836119f3565b946020939093013593505050565b5f5f5f60608486031215611a5c575f5ffd5b611a65846119f3565b9250611a73602085016119f3565b929592945050506040919091013590565b803580151581146109bf575f5ffd5b5f60208284031215611aa3575f5ffd5b610f2a82611a84565b5f5f60408385031215611abd575f5ffd5b611ac6836119f3565b9150611ad460208401611a84565b90509250929050565b80356001600160401b03811681146109bf575f5ffd5b5f60208284031215611b03575f5ffd5b610f2a82611add565b634e487b7160e01b5f52604160045260245ffd5b5f5f5f5f60808587031215611b33575f5ffd5b611b3c856119f3565b9350611b4a602086016119f3565b92506040850135915060608501356001600160401b03811115611b6b575f5ffd5b8501601f81018713611b7b575f5ffd5b80356001600160401b03811115611b9457611b94611b0c565b604051601f8201601f19908116603f011681016001600160401b0381118282101715611bc257611bc2611b0c565b604052818152828201602001891015611bd9575f5ffd5b816020840160208301375f6020838301015280935050505092959194509250565b634e487b7160e01b5f52602160045260245ffd5b6020810160058310611c2e57634e487b7160e01b5f52602160045260245ffd5b91905290565b5f5f5f60608486031215611c46575f5ffd5b611c4f84611add565b95602085013595506040909401359392505050565b5f5f60408385031215611c75575f5ffd5b611c7e836119f3565b9150611ad4602084016119f3565b600181811c90821680611ca057607f821691505b602082108103611cbe57634e487b7160e01b5f52602260045260245ffd5b50919050565b5f60208284031215611cd4575f5ffd5b815160ff81168114610f2a575f5ffd5b5f60208284031215611cf4575f5ffd5b5051919050565b634e487b7160e01b5f52601160045260245ffd5b8082018082111561056c5761056c611cfb565b6001600160401b03818116838216019081111561056c5761056c611cfb565b5f8351611d5281846020880161197d565b835190830190611d6681836020880161197d565b01949350505050565b6001600160a01b03858116825284166020820152604081018390526080606082018190525f90611da19083018461199f565b9695505050505050565b5f60208284031215611dbb575f5ffd5b8151610f2a8161194d56fea26469706673582212205cd0600d0bc59401f6362a6ffeeddd9fccccd322ad458bc4283018628c84b01f64736f6c634300081e0033"
      }
    }
  }
};

// contracts/nftree-generation/scripts/slot-review.mjs
import assert3 from "node:assert/strict";
import fs2 from "node:fs";
import { createHash as createHash3 } from "node:crypto";
import { Transaction as Transaction3 } from "@mysten/sui/transactions";

// contracts/nftree-generation/scripts/verify-published.mjs
import assert2 from "node:assert/strict";
import { createHash as createHash2 } from "node:crypto";
import fs from "node:fs";
var DIGEST = "DVoQj1tPzfASPesS1bdEsEBQnQ7AhzNS4kxeuEiQVq6S";
var PACKAGE = "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92";
var hash = (b) => createHash2("sha256").update(b).digest("hex");
function verifyPublished({ transaction, objects, package: packageResult, candidate }) {
  verifyBuild();
  const proof = verifyPublication(transaction);
  assert2.equal(transaction.Transaction.digest, DIGEST);
  assert2.equal(proof.packageId, PACKAGE);
  assert2.equal(transaction.Transaction.transaction.gasData.budget, "100000000");
  assert2(!packageResult.errors && !objects.errors);
  const pkg = packageResult.data.object;
  assert2.equal(pkg.address, PACKAGE);
  assert2.equal(pkg.version, 1);
  assert2.equal(pkg.previousTransaction.digest, DIGEST);
  assert2.equal(pkg.asMovePackage.modules.pageInfo.hasNextPage, false);
  const modules = pkg.asMovePackage.modules.nodes;
  assert2.deepEqual(modules.map((m) => m.name).sort(), ["codec", "vault"]);
  const offsets = { codec: 220, vault: 2567 };
  const moduleEvidence = [];
  for (const m of modules) {
    const actual = Buffer.from(m.bytes, "base64");
    const source = publication_bytecode_default.modules.map((x) => Buffer.from(x, "base64")).filter((x) => x.length === actual.length);
    assert2.equal(source.length, 1);
    const expected = Buffer.from(source[0]), offset = offsets[m.name];
    assert2(expected.subarray(offset, offset + 32).equals(Buffer.alloc(32)));
    Buffer.from(PACKAGE.slice(2), "hex").copy(expected, offset);
    assert2(actual.equals(expected), "Published module differs: " + m.name);
    moduleEvidence.push({ name: m.name, bytes: actual.length, sha256: hash(actual), selfAddressOffset: offset });
  }
  const data = objects.data;
  assert2.equal(data.chainIdentifier, C.chain);
  const rows = Object.values(data).filter((x) => x && typeof x === "object" && x.address);
  assert2.equal(rows.length, 5);
  for (const item of proof.objects.filter((x) => x.type !== "package")) {
    const row = rows.find((x) => x.address === item.id);
    assert2(row);
    assert2.equal(row.version, 1);
    assert2.equal(row.asMoveObject.contents.type.repr, item.type);
    if (item.type.endsWith("Cap")) {
      assert2.equal(row.owner.__typename, "AddressOwner");
      assert2.equal(row.owner.address.address, C.sender);
    } else assert2.equal(row.owner.__typename, "Shared");
  }
  const json5 = (id) => rows.find((x) => x.address === id).asMoveObject.contents.json;
  const registry = json5(proof.registryId), oapp = json5(proof.oappId);
  assert2.equal(registry.version, "1");
  assert2.equal(registry.slot, null);
  assert2.equal(registry.oapp, proof.oappId);
  assert2.equal(registry.backing, C.nft);
  assert2.equal(Buffer.from(registry.nft_type, "base64").toString(), C.nftType.slice(2));
  assert2.equal(registry.cap.cap_type["@variant"], "Package");
  assert2.equal(registry.cap.cap_type.pos0, PACKAGE);
  const admin = proof.objects.find((x) => x.type === PACKAGE + "::vault::AdminCap");
  assert2.equal(json5(admin.id).registry, proof.registryId);
  const appAdmin = proof.objects.find((x) => x.type === C.oappPackage + "::oapp::AdminCap");
  assert2.equal(oapp.admin_cap, appAdmin.id);
  assert2.equal(oapp.oapp_cap.cap_type.pos0, PACKAGE);
  assert2.equal(oapp.peer.peers.size, "0");
  assert2.equal(oapp.enforced_options.options.size, "0");
  assert2.equal(oapp.sending_call, null);
  const upgrade = proof.objects.find((x) => x.type.endsWith("::package::UpgradeCap"));
  assert2.equal(json5(upgrade.id).package, PACKAGE);
  assert2.equal(json5(upgrade.id).version, "1");
  assert2.equal(json5(upgrade.id).policy, 0);
  verifyCandidate(candidate, Date.parse(candidate.checkpoint.timestamp));
  return { digest: DIGEST, ...proof, modules: moduleEvidence, stateCheckpoint: data.checkpoint, nftCheckpoint: candidate.checkpoint, candidate: candidate.nft, capabilitiesOwnedBy: C.sender, upgradePolicy: "compatible retained in dev wallet", emptyRegistry: true, slotCreated: false, peersConfigured: false, nftDeposited: false };
}
function readEvidence() {
  const root = new URL("../../../docs/multichain/generation-milestone/published/", import.meta.url);
  return Object.fromEntries(["transaction", "objects", "package", "candidate"].map((k) => [k, JSON.parse(fs.readFileSync(new URL(k + ".json", root)))]));
}
if (process.argv[1]?.endsWith("/verify-published.mjs")) console.log(JSON.stringify(verifyPublished(readEvidence()), null, 2));

// docs/multichain/generation-milestone/published/transaction.json
var transaction_default = {
  $kind: "Transaction",
  Transaction: {
    digest: "DVoQj1tPzfASPesS1bdEsEBQnQ7AhzNS4kxeuEiQVq6S",
    status: {
      success: true,
      error: null
    },
    effects: {
      bcs: {
        "0": 1,
        "1": 0,
        "2": 39,
        "3": 5,
        "4": 0,
        "5": 0,
        "6": 0,
        "7": 0,
        "8": 0,
        "9": 0,
        "10": 160,
        "11": 134,
        "12": 1,
        "13": 0,
        "14": 0,
        "15": 0,
        "16": 0,
        "17": 0,
        "18": 48,
        "19": 95,
        "20": 38,
        "21": 4,
        "22": 0,
        "23": 0,
        "24": 0,
        "25": 0,
        "26": 0,
        "27": 0,
        "28": 0,
        "29": 0,
        "30": 0,
        "31": 0,
        "32": 0,
        "33": 0,
        "34": 0,
        "35": 0,
        "36": 0,
        "37": 0,
        "38": 0,
        "39": 0,
        "40": 0,
        "41": 0,
        "42": 32,
        "43": 185,
        "44": 172,
        "45": 251,
        "46": 11,
        "47": 69,
        "48": 115,
        "49": 39,
        "50": 240,
        "51": 7,
        "52": 102,
        "53": 187,
        "54": 153,
        "55": 124,
        "56": 109,
        "57": 220,
        "58": 43,
        "59": 217,
        "60": 3,
        "61": 192,
        "62": 57,
        "63": 103,
        "64": 252,
        "65": 82,
        "66": 44,
        "67": 152,
        "68": 186,
        "69": 184,
        "70": 35,
        "71": 34,
        "72": 160,
        "73": 249,
        "74": 171,
        "75": 0,
        "76": 0,
        "77": 0,
        "78": 1,
        "79": 0,
        "80": 0,
        "81": 0,
        "82": 0,
        "83": 0,
        "84": 0,
        "85": 0,
        "86": 11,
        "87": 13,
        "88": 163,
        "89": 216,
        "90": 69,
        "91": 244,
        "92": 171,
        "93": 24,
        "94": 160,
        "95": 168,
        "96": 210,
        "97": 240,
        "98": 102,
        "99": 151,
        "100": 34,
        "101": 161,
        "102": 217,
        "103": 22,
        "104": 28,
        "105": 46,
        "106": 166,
        "107": 26,
        "108": 215,
        "109": 20,
        "110": 171,
        "111": 193,
        "112": 77,
        "113": 65,
        "114": 71,
        "115": 33,
        "116": 253,
        "117": 20,
        "118": 228,
        "119": 0,
        "120": 1,
        "121": 32,
        "122": 94,
        "123": 46,
        "124": 80,
        "125": 73,
        "126": 107,
        "127": 91,
        "128": 166,
        "129": 49,
        "130": 47,
        "131": 96,
        "132": 182,
        "133": 45,
        "134": 240,
        "135": 168,
        "136": 130,
        "137": 211,
        "138": 157,
        "139": 63,
        "140": 53,
        "141": 220,
        "142": 202,
        "143": 71,
        "144": 208,
        "145": 252,
        "146": 146,
        "147": 83,
        "148": 14,
        "149": 234,
        "150": 55,
        "151": 192,
        "152": 90,
        "153": 11,
        "154": 2,
        "155": 1,
        "156": 0,
        "157": 0,
        "158": 0,
        "159": 0,
        "160": 0,
        "161": 0,
        "162": 0,
        "163": 1,
        "164": 23,
        "165": 17,
        "166": 182,
        "167": 176,
        "168": 228,
        "169": 66,
        "170": 232,
        "171": 41,
        "172": 158,
        "173": 163,
        "174": 172,
        "175": 235,
        "176": 48,
        "177": 40,
        "178": 98,
        "179": 52,
        "180": 82,
        "181": 12,
        "182": 143,
        "183": 28,
        "184": 77,
        "185": 34,
        "186": 148,
        "187": 170,
        "188": 125,
        "189": 3,
        "190": 19,
        "191": 8,
        "192": 163,
        "193": 215,
        "194": 188,
        "195": 255,
        "196": 0,
        "197": 0,
        "198": 1,
        "199": 41,
        "200": 130,
        "201": 4,
        "202": 214,
        "203": 13,
        "204": 26,
        "205": 136,
        "206": 110,
        "207": 114,
        "208": 241,
        "209": 236,
        "210": 225,
        "211": 141,
        "212": 225,
        "213": 121,
        "214": 6,
        "215": 93,
        "216": 72,
        "217": 122,
        "218": 118,
        "219": 66,
        "220": 15,
        "221": 147,
        "222": 177,
        "223": 155,
        "224": 247,
        "225": 246,
        "226": 28,
        "227": 114,
        "228": 117,
        "229": 194,
        "230": 16,
        "231": 0,
        "232": 1,
        "233": 32,
        "234": 165,
        "235": 78,
        "236": 98,
        "237": 67,
        "238": 190,
        "239": 47,
        "240": 48,
        "241": 205,
        "242": 206,
        "243": 172,
        "244": 186,
        "245": 211,
        "246": 148,
        "247": 132,
        "248": 180,
        "249": 162,
        "250": 192,
        "251": 173,
        "252": 179,
        "253": 37,
        "254": 156,
        "255": 217,
        "256": 251,
        "257": 233,
        "258": 19,
        "259": 169,
        "260": 207,
        "261": 236,
        "262": 201,
        "263": 109,
        "264": 105,
        "265": 182,
        "266": 2,
        "267": 1,
        "268": 0,
        "269": 0,
        "270": 0,
        "271": 0,
        "272": 0,
        "273": 0,
        "274": 0,
        "275": 1,
        "276": 78,
        "277": 127,
        "278": 222,
        "279": 15,
        "280": 162,
        "281": 45,
        "282": 120,
        "283": 162,
        "284": 145,
        "285": 111,
        "286": 126,
        "287": 168,
        "288": 210,
        "289": 231,
        "290": 212,
        "291": 104,
        "292": 141,
        "293": 4,
        "294": 238,
        "295": 76,
        "296": 96,
        "297": 21,
        "298": 45,
        "299": 138,
        "300": 9,
        "301": 212,
        "302": 163,
        "303": 52,
        "304": 232,
        "305": 159,
        "306": 106,
        "307": 172,
        "308": 0,
        "309": 1,
        "310": 32,
        "311": 171,
        "312": 67,
        "313": 181,
        "314": 148,
        "315": 238,
        "316": 206,
        "317": 63,
        "318": 113,
        "319": 4,
        "320": 42,
        "321": 233,
        "322": 64,
        "323": 31,
        "324": 0,
        "325": 235,
        "326": 244,
        "327": 88,
        "328": 170,
        "329": 83,
        "330": 222,
        "331": 57,
        "332": 84,
        "333": 197,
        "334": 69,
        "335": 98,
        "336": 156,
        "337": 115,
        "338": 132,
        "339": 174,
        "340": 84,
        "341": 108,
        "342": 176,
        "343": 0,
        "344": 72,
        "345": 89,
        "346": 83,
        "347": 226,
        "348": 234,
        "349": 223,
        "350": 74,
        "351": 160,
        "352": 42,
        "353": 249,
        "354": 80,
        "355": 207,
        "356": 142,
        "357": 145,
        "358": 79,
        "359": 189,
        "360": 43,
        "361": 103,
        "362": 82,
        "363": 51,
        "364": 133,
        "365": 231,
        "366": 60,
        "367": 54,
        "368": 17,
        "369": 131,
        "370": 65,
        "371": 69,
        "372": 157,
        "373": 141,
        "374": 69,
        "375": 196,
        "376": 1,
        "377": 107,
        "378": 124,
        "379": 102,
        "380": 210,
        "381": 19,
        "382": 92,
        "383": 225,
        "384": 46,
        "385": 250,
        "386": 106,
        "387": 35,
        "388": 3,
        "389": 123,
        "390": 255,
        "391": 46,
        "392": 92,
        "393": 161,
        "394": 180,
        "395": 153,
        "396": 219,
        "397": 36,
        "398": 188,
        "399": 32,
        "400": 5,
        "401": 146,
        "402": 208,
        "403": 140,
        "404": 37,
        "405": 149,
        "406": 207,
        "407": 90,
        "408": 58,
        "409": 0,
        "410": 0,
        "411": 1,
        "412": 151,
        "413": 190,
        "414": 153,
        "415": 184,
        "416": 229,
        "417": 195,
        "418": 184,
        "419": 149,
        "420": 51,
        "421": 35,
        "422": 192,
        "423": 164,
        "424": 129,
        "425": 184,
        "426": 72,
        "427": 201,
        "428": 144,
        "429": 185,
        "430": 211,
        "431": 40,
        "432": 20,
        "433": 149,
        "434": 13,
        "435": 128,
        "436": 59,
        "437": 117,
        "438": 75,
        "439": 78,
        "440": 20,
        "441": 15,
        "442": 226,
        "443": 93,
        "444": 0,
        "445": 1,
        "446": 32,
        "447": 169,
        "448": 168,
        "449": 255,
        "450": 47,
        "451": 156,
        "452": 13,
        "453": 134,
        "454": 186,
        "455": 242,
        "456": 55,
        "457": 36,
        "458": 124,
        "459": 127,
        "460": 241,
        "461": 204,
        "462": 73,
        "463": 187,
        "464": 135,
        "465": 77,
        "466": 173,
        "467": 66,
        "468": 144,
        "469": 251,
        "470": 139,
        "471": 10,
        "472": 115,
        "473": 17,
        "474": 62,
        "475": 118,
        "476": 213,
        "477": 109,
        "478": 82,
        "479": 0,
        "480": 72,
        "481": 89,
        "482": 83,
        "483": 226,
        "484": 234,
        "485": 223,
        "486": 74,
        "487": 160,
        "488": 42,
        "489": 249,
        "490": 80,
        "491": 207,
        "492": 142,
        "493": 145,
        "494": 79,
        "495": 189,
        "496": 43,
        "497": 103,
        "498": 82,
        "499": 51,
        "500": 133,
        "501": 231,
        "502": 60,
        "503": 54,
        "504": 17,
        "505": 131,
        "506": 65,
        "507": 69,
        "508": 157,
        "509": 141,
        "510": 69,
        "511": 196,
        "512": 1,
        "513": 152,
        "514": 78,
        "515": 185,
        "516": 61,
        "517": 103,
        "518": 19,
        "519": 176,
        "520": 144,
        "521": 145,
        "522": 82,
        "523": 226,
        "524": 73,
        "525": 188,
        "526": 250,
        "527": 70,
        "528": 90,
        "529": 102,
        "530": 97,
        "531": 231,
        "532": 64,
        "533": 60,
        "534": 91,
        "535": 1,
        "536": 38,
        "537": 99,
        "538": 83,
        "539": 185,
        "540": 127,
        "541": 242,
        "542": 49,
        "543": 137,
        "544": 102,
        "545": 0,
        "546": 0,
        "547": 1,
        "548": 183,
        "549": 14,
        "550": 44,
        "551": 220,
        "552": 24,
        "553": 213,
        "554": 98,
        "555": 36,
        "556": 123,
        "557": 195,
        "558": 75,
        "559": 244,
        "560": 126,
        "561": 254,
        "562": 230,
        "563": 32,
        "564": 160,
        "565": 94,
        "566": 193,
        "567": 240,
        "568": 89,
        "569": 207,
        "570": 245,
        "571": 232,
        "572": 18,
        "573": 168,
        "574": 212,
        "575": 51,
        "576": 167,
        "577": 34,
        "578": 153,
        "579": 157,
        "580": 0,
        "581": 1,
        "582": 32,
        "583": 65,
        "584": 252,
        "585": 49,
        "586": 145,
        "587": 19,
        "588": 77,
        "589": 101,
        "590": 9,
        "591": 19,
        "592": 224,
        "593": 76,
        "594": 163,
        "595": 237,
        "596": 93,
        "597": 102,
        "598": 162,
        "599": 209,
        "600": 69,
        "601": 62,
        "602": 14,
        "603": 63,
        "604": 241,
        "605": 188,
        "606": 139,
        "607": 125,
        "608": 38,
        "609": 199,
        "610": 88,
        "611": 194,
        "612": 66,
        "613": 211,
        "614": 178,
        "615": 0,
        "616": 72,
        "617": 89,
        "618": 83,
        "619": 226,
        "620": 234,
        "621": 223,
        "622": 74,
        "623": 160,
        "624": 42,
        "625": 249,
        "626": 80,
        "627": 207,
        "628": 142,
        "629": 145,
        "630": 79,
        "631": 189,
        "632": 43,
        "633": 103,
        "634": 82,
        "635": 51,
        "636": 133,
        "637": 231,
        "638": 60,
        "639": 54,
        "640": 17,
        "641": 131,
        "642": 65,
        "643": 69,
        "644": 157,
        "645": 141,
        "646": 69,
        "647": 196,
        "648": 1,
        "649": 196,
        "650": 69,
        "651": 81,
        "652": 155,
        "653": 241,
        "654": 214,
        "655": 237,
        "656": 138,
        "657": 182,
        "658": 0,
        "659": 45,
        "660": 32,
        "661": 173,
        "662": 126,
        "663": 216,
        "664": 26,
        "665": 154,
        "666": 210,
        "667": 94,
        "668": 49,
        "669": 153,
        "670": 13,
        "671": 249,
        "672": 183,
        "673": 34,
        "674": 3,
        "675": 208,
        "676": 173,
        "677": 134,
        "678": 253,
        "679": 46,
        "680": 146,
        "681": 0,
        "682": 2,
        "683": 1,
        "684": 0,
        "685": 0,
        "686": 0,
        "687": 0,
        "688": 0,
        "689": 0,
        "690": 0,
        "691": 32,
        "692": 136,
        "693": 116,
        "694": 111,
        "695": 242,
        "696": 197,
        "697": 225,
        "698": 41,
        "699": 43,
        "700": 223,
        "701": 101,
        "702": 1,
        "703": 235,
        "704": 63,
        "705": 9,
        "706": 28,
        "707": 242,
        "708": 20,
        "709": 148,
        "710": 32,
        "711": 196,
        "712": 117,
        "713": 215,
        "714": 19,
        "715": 101,
        "716": 114,
        "717": 199,
        "718": 97,
        "719": 128,
        "720": 171,
        "721": 106,
        "722": 90,
        "723": 169,
        "724": 1,
        "725": 209,
        "726": 192,
        "727": 219,
        "728": 240,
        "729": 44,
        "730": 149,
        "731": 77,
        "732": 136,
        "733": 207,
        "734": 150,
        "735": 2,
        "736": 244,
        "737": 60,
        "738": 135,
        "739": 125,
        "740": 218,
        "741": 237,
        "742": 61,
        "743": 140,
        "744": 245,
        "745": 175,
        "746": 180,
        "747": 231,
        "748": 31,
        "749": 131,
        "750": 204,
        "751": 249,
        "752": 251,
        "753": 237,
        "754": 120,
        "755": 228,
        "756": 151,
        "757": 0,
        "758": 0,
        "759": 1,
        "760": 224,
        "761": 125,
        "762": 255,
        "763": 18,
        "764": 247,
        "765": 144,
        "766": 158,
        "767": 232,
        "768": 47,
        "769": 125,
        "770": 129,
        "771": 239,
        "772": 49,
        "773": 95,
        "774": 18,
        "775": 245,
        "776": 86,
        "777": 254,
        "778": 115,
        "779": 103,
        "780": 97,
        "781": 57,
        "782": 186,
        "783": 133,
        "784": 85,
        "785": 17,
        "786": 224,
        "787": 91,
        "788": 79,
        "789": 112,
        "790": 44,
        "791": 240,
        "792": 0,
        "793": 3,
        "794": 72,
        "795": 89,
        "796": 83,
        "797": 226,
        "798": 234,
        "799": 223,
        "800": 74,
        "801": 160,
        "802": 42,
        "803": 249,
        "804": 80,
        "805": 207,
        "806": 142,
        "807": 145,
        "808": 79,
        "809": 189,
        "810": 43,
        "811": 103,
        "812": 82,
        "813": 51,
        "814": 133,
        "815": 231,
        "816": 60,
        "817": 54,
        "818": 17,
        "819": 131,
        "820": 65,
        "821": 69,
        "822": 157,
        "823": 141,
        "824": 69,
        "825": 196,
        "826": 7,
        "827": 0,
        "828": 0,
        "829": 0,
        "830": 0,
        "831": 0,
        "832": 0,
        "833": 0,
        "834": 0,
        "835": 0,
        "836": 0,
        "837": 0,
        "838": 0,
        "839": 0,
        "840": 0,
        "841": 0,
        "842": 0,
        "843": 0,
        "844": 0,
        "845": 0,
        "846": 0,
        "847": 0,
        "848": 0,
        "849": 0,
        "850": 0,
        "851": 0,
        "852": 0,
        "853": 0,
        "854": 0,
        "855": 0,
        "856": 0,
        "857": 0,
        "858": 2,
        "859": 7,
        "860": 98,
        "861": 97,
        "862": 108,
        "863": 97,
        "864": 110,
        "865": 99,
        "866": 101,
        "867": 7,
        "868": 66,
        "869": 97,
        "870": 108,
        "871": 97,
        "872": 110,
        "873": 99,
        "874": 101,
        "875": 1,
        "876": 7,
        "877": 0,
        "878": 0,
        "879": 0,
        "880": 0,
        "881": 0,
        "882": 0,
        "883": 0,
        "884": 0,
        "885": 0,
        "886": 0,
        "887": 0,
        "888": 0,
        "889": 0,
        "890": 0,
        "891": 0,
        "892": 0,
        "893": 0,
        "894": 0,
        "895": 0,
        "896": 0,
        "897": 0,
        "898": 0,
        "899": 0,
        "900": 0,
        "901": 0,
        "902": 0,
        "903": 0,
        "904": 0,
        "905": 0,
        "906": 0,
        "907": 0,
        "908": 2,
        "909": 3,
        "910": 115,
        "911": 117,
        "912": 105,
        "913": 3,
        "914": 83,
        "915": 85,
        "916": 73,
        "917": 0,
        "918": 1,
        "919": 0,
        "920": 208,
        "921": 229,
        "922": 39,
        "923": 4,
        "924": 0,
        "925": 0,
        "926": 0,
        "927": 0,
        "928": 0,
        "929": 0,
        "930": 0
      },
      version: 2,
      status: {
        success: true,
        error: null
      },
      gasUsed: {
        computationCost: "100000",
        storageCost: "69623600",
        storageRebate: "0",
        nonRefundableStorageFee: "0"
      },
      transactionDigest: "DVoQj1tPzfASPesS1bdEsEBQnQ7AhzNS4kxeuEiQVq6S",
      gasObject: null,
      eventsDigest: null,
      dependencies: [],
      lamportVersion: "1",
      changedObjects: [
        {
          objectId: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
          inputState: "DoesNotExist",
          inputVersion: null,
          inputDigest: null,
          inputOwner: null,
          outputState: "ObjectWrite",
          outputVersion: "1",
          outputDigest: "7LeHSzqW2xxEA7QrcimgN8c7ZKaAJUL3fwvjNy9wnoar",
          outputOwner: {
            Shared: {
              initialSharedVersion: "1"
            },
            $kind: "Shared"
          },
          idOperation: "Created"
        },
        {
          objectId: "0x1711b6b0e442e8299ea3aceb30286234520c8f1c4d2294aa7d031308a3d7bcff",
          inputState: "DoesNotExist",
          inputVersion: null,
          inputDigest: null,
          inputOwner: null,
          outputState: "DoesNotExist",
          outputVersion: null,
          outputDigest: null,
          outputOwner: null,
          idOperation: "Created"
        },
        {
          objectId: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
          inputState: "DoesNotExist",
          inputVersion: null,
          inputDigest: null,
          inputOwner: null,
          outputState: "ObjectWrite",
          outputVersion: "1",
          outputDigest: "C8HbQXjdhJTwpjy4aNx7PaYJp3oikopu9QwNgC5kdPaM",
          outputOwner: {
            Shared: {
              initialSharedVersion: "1"
            },
            $kind: "Shared"
          },
          idOperation: "Created"
        },
        {
          objectId: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
          inputState: "DoesNotExist",
          inputVersion: null,
          inputDigest: null,
          inputOwner: null,
          outputState: "ObjectWrite",
          outputVersion: "1",
          outputDigest: "CXYbjFxRkbB7SDn82yNUgTdRGbjvNPpE8dBsyq13genK",
          outputOwner: {
            AddressOwner: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
            $kind: "AddressOwner"
          },
          idOperation: "Created"
        },
        {
          objectId: "0x6b7c66d2135ce12efa6a23037bff2e5ca1b499db24bc200592d08c2595cf5a3a",
          inputState: "DoesNotExist",
          inputVersion: null,
          inputDigest: null,
          inputOwner: null,
          outputState: "DoesNotExist",
          outputVersion: null,
          outputDigest: null,
          outputOwner: null,
          idOperation: "Created"
        },
        {
          objectId: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
          inputState: "DoesNotExist",
          inputVersion: null,
          inputDigest: null,
          inputOwner: null,
          outputState: "ObjectWrite",
          outputVersion: "1",
          outputDigest: "CRHN2g1UWgQYiN9TVWbRf8CcTd9FMtr2ky2jnfx79VVB",
          outputOwner: {
            AddressOwner: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
            $kind: "AddressOwner"
          },
          idOperation: "Created"
        },
        {
          objectId: "0x984eb93d6713b0909152e249bcfa465a6661e7403c5b01266353b97ff2318966",
          inputState: "DoesNotExist",
          inputVersion: null,
          inputDigest: null,
          inputOwner: null,
          outputState: "DoesNotExist",
          outputVersion: null,
          outputDigest: null,
          outputOwner: null,
          idOperation: "Created"
        },
        {
          objectId: "0xb70e2cdc18d562247bc34bf47efee620a05ec1f059cff5e812a8d433a722999d",
          inputState: "DoesNotExist",
          inputVersion: null,
          inputDigest: null,
          inputOwner: null,
          outputState: "ObjectWrite",
          outputVersion: "1",
          outputDigest: "5SaYRBQ1KG5DD1bbYMLkDAPMmvfxkv6Q254Hm41cVrGR",
          outputOwner: {
            AddressOwner: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
            $kind: "AddressOwner"
          },
          idOperation: "Created"
        },
        {
          objectId: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
          inputState: "DoesNotExist",
          inputVersion: null,
          inputDigest: null,
          inputOwner: null,
          outputState: "PackageWrite",
          outputVersion: "1",
          outputDigest: "ABfRdTrhPgxDcLyZqRq7vyRyBSfaWcifjfsEcrE9i89N",
          outputOwner: null,
          idOperation: "Created"
        },
        {
          objectId: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
          inputState: "DoesNotExist",
          inputVersion: null,
          inputDigest: null,
          inputOwner: null,
          outputState: "DoesNotExist",
          outputVersion: null,
          outputDigest: null,
          outputOwner: null,
          idOperation: "Created"
        },
        {
          objectId: "0xe07dff12f7909ee82f7d81ef315f12f556fe73676139ba855511e05b4f702cf0",
          inputState: "DoesNotExist",
          inputVersion: null,
          inputDigest: null,
          inputOwner: null,
          outputState: "AccumulatorWriteV1",
          outputVersion: null,
          outputDigest: null,
          outputOwner: null,
          idOperation: "None"
        }
      ],
      unchangedConsensusObjects: [],
      auxiliaryDataDigest: null
    },
    epoch: "1319",
    objectTypes: {
      "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4": "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::OApp",
      "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210": "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Registry",
      "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac": "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::AdminCap",
      "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d": "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::AdminCap",
      "0xb70e2cdc18d562247bc34bf47efee620a05ec1f059cff5e812a8d433a722999d": "0x0000000000000000000000000000000000000000000000000000000000000002::package::UpgradeCap",
      "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92": "package"
    },
    transaction: {
      gasData: {
        budget: "100000000",
        owner: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
        payment: [],
        price: "100"
      },
      sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
      expiration: {
        $kind: "ValidDuring",
        ValidDuring: {
          minEpoch: "1319",
          maxEpoch: "1320",
          minTimestamp: null,
          maxTimestamp: null,
          chain: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
          nonce: 2451457856
        }
      },
      commands: [
        {
          $kind: "Publish",
          Publish: {
            modules: [
              "oRzrCwcAAAUJAQAGAgYEAwofBCkCBSs+B2lLCLQBYAaUAg4MogLrAwADAQgCAgIABwAABQABAAAEAgAAAAkDBAABAQkHAQACBgEEAAIHCAEAAwYGAggACAADCAAIAAEKAgEGCgICBgoCAwEIAAMBAgoCAQIAAQYIAAIHCgkACgkABQEBAwMCBgIHCgIDAwMKAgdCeXRlczMyBmFwcGVuZAdieXRlczMyBWNvZGVjBmRlY29kZQZlbmNvZGUKZnJvbV9ieXRlcwh0b19ieXRlcwZ2ZWN0b3IEd29yZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAJFujb3ocxkOisDdFDf8eQ5nhgGnGVF+1/KrzfTnX3AMIZAAAAAAAAAAKAgEAAAEAAAVCCgAxASYEEAoAMQQlBA0KAwYAAAAAAAAAACQMBgUSCQwGBRIJDAYLBgQVBRcHACcxAwsAQAYCAAAAAAAAAAwIDQgOAREFOAANCA4CEQU4ADEIDAcKBzEAJAQ4CwcxARcMBw0ICgMKBzEIGDAG/wAAAAAAAAAcM0QGBSUNCA4EEQU4AA0IDgURBTgACwgCAAEBAAAKXAoAQQYGigAAAAAAAAAhBA0KAAYAAAAAAAAAAEIGFDEDIQwBBQ8JDAELAQQSBRYLAAEHACcKAAYBAAAAAAAAAEIGFAwFCgUxASYEJAoFMQQlDAIFJgkMAgsCBCkFLQsAAQcAJwYAAAAAAAAAAAwDBkIAAAAAAAAADAQKBAZKAAAAAAAAACMERAsDMQgvCgAKBEIGFDQbDAMLBAYBAAAAAAAAABYMBAUxCgMGAAAAAAAAAAAkBEkFTQsAAQcAJwsFCgAGAgAAAAAAAAARAgoABiIAAAAAAAAAEQILAwoABkoAAAAAAAAAEQILAAZqAAAAAAAAABECAgACAAAACyIHAQwHBgAAAAAAAAAADAYKBgYgAAAAAAAAACMEHQoGDAQNBwwDCwQMBQoACgELBRZCBhQMAgsDCwJEBgsGBgEAAAAAAAAAFgwGBQQLAAELBxEEAgAA",
              "oRzrCwcAAAUNAQAuAi6KAQO4AfUCBK0ESAX1BLQFB6kKmwkIxBOAAgbEFbUCCvkXoAELmRkCDJsZpRQNwC0uDu4tIAB6BCgEKQU5BToFOwVOBVAFUQVSACsHWAEjAVoBdwIsAjwCWQJzAnUCdgMnBn8AGwIAAAAIAAASCAAAHAgBDAAAFgMAAAgDAAAGAwAAAQMAABADAAATAwABAwACAAAAAAEdBwACBAwAAxEHAAQVAAAFBwgABgoAAAcLCAAIDAcACQ0HAAsADAALDggADBcHAA0PBwEAAA4ZBwAPBQwBAAERCQcAERoEABIUAgAUGAIAFQIHABYeAgAASAABAABUAgMAAGcEAQAAewUBAQwAMQYBAQwAQgcBAQwAbggBAQwAZAkKAQwAJQsBAQwAeQwBAQwATg0BAQwAYA4BAQwAXA8QAQwAPREQAABiEhMBDABrFBUBDAAwFhcBDAAvGBkBDABfGhsBDABqGhwBDAAkGhwBDABdDxABDABDGh0BDAAhGh4BDABFGh4BDABoGh8BDABxICEAADMBIgAAXhocAQwFZT0KAAY0RkcACjJKSwAKOEsQAAstUBAACy5VFwALL1YZAAtEQxwAC05FRgALT1QVAAtTJicBAgtiUhMAC21BAQALb0ABAAxJMxAADTUwAQEADT42LgEADT83AQEADUs0HgEADUw0HgEADVcBMAEADXIuMAEADkoyMwAOfQEyAQAQNy4BAQMRRiofAQgRRyoKAQgRUygpABF4NR8AE2EsAQEME3AuAQEIE3UsAQEIFGwkCgAVQAocABVBHxwAFU0/HgAVdD8KABV+ARwAJyU2AzorPC07AzIvMR80Li8fMC8tLzEuLh81ODs5Ly42Li4uNjk1OwMuNTw3PjVCCS4vSCxICy41TDAuLS46LjVNDC4xUzIKAggABwgdAAUIDAUFCgIHCB0BCAICBggCBggBAgYLAwEJAAYIAQMHCAIGCAEHCB0CBwsDAQkACQADBwsDAQkABggBAQUGCwMBCQAGCAEHCA8KAgcIHQEFCAcLAwEJAAYIAQcIFQYIFAYIDwcIEQgeBwgdAgYLAwEJAAYIFQMHCwMBCQAGCBULCgIIEAgLAgcLAwEJAAYKAgIGCwMBCQACAQoCAwYIFQIKAgUGCwMBCQAGCBUCCgIHCB0BCwoCCA0IEgYHCwMBCQAHCBUCCgILGQEIHAcIHQELCgIIDggTAwYLAwEJAAcIFQsKAggOCBMCCA4IEwMGCwMBCQAGCBULCgIIDQgSAggNCBIBBgsDAQkAAQIBCB4BAwEBAQgaAQYIAgELFwEIGgEOBAgBBQgUCAIBBggdAQgAAgYJAAcIHQMIDAgUBQEHCB0BCBsBBgkAAQgUAgkABQEIAQEJAAEIDAELFwEJAAQBCBsLAwEJAAgaAQgYAQgWAQYLFwEJAAEGCBsBBwsXAQkAAgcLFwEJAAkAAQgEAQsDAQkAAgEBAQgFAQgIBAcIDwYIDAoCBwgdAQgVAQYIHgcHCBUGCBQGCA8HCBEOCB4HCB0FBwgVBggUDg0KAgEIBwIGCBUOBAEKAggeCxcBCxkBCBwDBggVBggMCwoCCBAICwEIEAgOCB4DCB4KAgUKAgsXAQsZAQgcAQsZAQgcDwEBAQEBAQEBAQMCCB4IHggeCB4BBgoCBgIIHggeAwgeCB4BCAYBCAkEAQEBCgINDQoCAQEBAQoCBAMNAwMEBAYIFQ4NCgICCgIKAgcGCBUGCAwOCgIKAgEHCB0BCxkBCB8JBwgVBggMDgoCCgILGQEIHAsXAQsZAQgfCxcBBQcIHQMHCBUGCAwLCgIIDggTAwYIFQYIDAsKAggNCBIIQWRtaW5DYXAFQm91bmQHQnl0ZXMzMgRDYWxsB0NhbGxDYXAEQ29pbglDb21wbGV0ZWQKRW5kcG9pbnRWMgZGdW5kZWQCSUQOTHpSZWNlaXZlUGFyYW0QTWVzc2FnaW5nQ2hhbm5lbAxNZXNzYWdpbmdGZWUQTWVzc2FnaW5nUmVjZWlwdARPQXBwBk9wdGlvbgxQYXVzZUNoYW5nZWQKUXVvdGVQYXJhbQhSZWdpc3RyeQhSZWxlYXNlZANTVUkJU2VuZFBhcmFtC1Nsb3RDcmVhdGVkBlN0cmluZwlUeENvbnRleHQIVHlwZU5hbWUDVUlEBVZBVUxUBVZhdWx0BFZvaWQDWlJPCGFja19zZW50B2FkYXB0ZXIJYWxsb2NhdGVkCWFubm91bmNlZAVhc2NpaQdiYWNraW5nBGJpbmQFYm91bmQHYnl0ZXMzMgRjYWxsCGNhbGxfY2FwA2NhcAVjb2RlYwRjb2luD2NvbWJpbmVfb3B0aW9ucw9jb25maXJtX2x6X3NlbmQNY29uZmlybV9xdW90ZQxjb25maXJtX3NlbmQLY3JlYXRlX3Nsb3QGZGVjb2RlC2Rlc3RpbmF0aW9uB2Rlc3Ryb3kMZGVzdHJveV9ub25lC2R1bW15X2ZpZWxkBGVtaXQGZW5jb2RlDmVuZHBvaW50X3F1b3RlDWVuZHBvaW50X3NlbmQLZW5kcG9pbnRfdjIFZXZlbnQRZXhlY3V0aW9uX29wdGlvbnMHZXh0cmFjdARmaWxsDGZyb21fYWRkcmVzcwdmcm9tX2lkBGZ1bmQKZ2VuZXJhdGlvbghnZXRfcGVlcgRoZWxkAmlkCmlkX2FkZHJlc3MEaW5pdAppbnRvX2J5dGVzC2ludG9fc3RyaW5nB2lzX25vbmUHaXNfc29tZQdpc196ZXJvCmx6X3JlY2VpdmUHbHpfc2VuZBFtZXNzYWdpbmdfY2hhbm5lbA1tZXNzYWdpbmdfZmVlEW1lc3NhZ2luZ19yZWNlaXB0A25ldwxuZXdfcmVnaXN0cnkDbmZ0CG5mdF90eXBlBG5vbmUEb2FwcAZvYmplY3QGb3B0aW9uBnBhdXNlZAdwYXlsb2FkEnBheWxvYWRfZm9yX3JldmlldwRwZWVyBXBoYXNlB3Byb2Nlc3MPcHVibGljX3RyYW5zZmVyBXF1b3RlCXJlY2lwaWVudAhyZWdpc3Rlcg1yZWdpc3Rlcl9vYXBwCHJlZ2lzdHJ5DnJlZ2lzdHJ5X2FkbWluC3JlZ2lzdHJ5X2lkB3JlcXVlc3QFcm91dGUEc2VuZAZzZW5kZXIUc2V0X2VuZm9yY2VkX29wdGlvbnMKc2V0X3BhdXNlZAhzZXRfcGVlcgxzaGFyZV9vYmplY3QEc2xvdARzb21lA3N1aQp0b19hZGRyZXNzCHRyYW5zZmVyCnR4X2NvbnRleHQJdHlwZV9uYW1lDHVpZF90b19pbm5lcgh2YWxpZGF0ZQV2YXVsdAt2YXVsdF9hZG1pbgd2ZXJzaW9uEXdpdGhfb3JpZ2luYWxfaWRzDHplcm9fYnl0ZXMzMgN6cm8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAJFujb3ocxkOisDdFDf8eQ5nhgGnGVF+1/KrzfTnX3Cjeno4IemNHABkH+2mP34qwRns0Iim3SxkmQGeuvErpMb6u+Imwi5w7N9GSgPwfi3W65bLeJBD8MSD0A+mjbaw94VBM8/11didZ41PZ2VOJYY5VfQVSaX8ZtS5Oknwd7v3CivwBEMsu25Tj5X8rHOabWpnFA7BtFeUc+iEt5W4kAwgBAAAAAAAAAA4ElnUAAAUgBG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWproFIEhZU+Lq30qgKvlQz46RT70rZ1Izhec8NhGDQUWdjUXECgJSUWY2YzZkNDM5ZWEwZGEyZjNlOWJhNzllNDk5MmE3YTRjMTEzMjE1ZmJmNTRjNDQyYWM5MDIwYzMxNWY5NTM3MDU6OmNvbGxlY3Rpb246Ok5GVAMIAgAAAAAAAAADCAMAAAAAAAAAAwgEAAAAAAAAAAMIBQAAAAAAAAADCAYAAAAAAAAAAwgHAAAAAAAAAAMICAAAAAAAAAADCAkAAAAAAAAAAwgKAAAAAAAAAAMICwAAAAAAAAADCAwAAAAAAAAACgIXFgADAQARAQAAAAAAAAAAAAAAAAADDUAKAgEAAAIBNgEBAgJGCBtmCBoCAgdGCBt8AyoLFwEIDFgFcQsXAQgaJAVWCgIDAhFGCBt8A2YIGioIDFgFVQsXAQkAJAgeaggeXggeJgFbAV8CQwMiAR8BaQgeYwgeBAIDZggaeggaVQgeBQIFeggaVQgeQwMzDiAIHgYCA3oIGkMDaQgeBwICeggaXggeCAICeggaWwEJAgR6CBpDA2kIHmMIHgMuAAAAACMpCgEuET0HAyEEBwULCwEBBwAnDgAKATgADAMMBAsDBwIHBAoBEQEMBQoBETgOBTgBEgEMAgsECgEuET04AgsCCwEuET04AwsFOAQCAAEAAAABCwsEETgHAAsAOAULATgGCwILAxICAgACAAAAARgKABAAFAcAIQQHBQ0LAAELAQEHDicLARABFAsAOAEhBBUFFwcAJwIAAwAAAAEZCgA3ABQHACEEBwUNCwABCwEBBw4nCwEQARQLADcBFCEEFgUYBwAnAgAEAQAAMVoKAC4LARECOAcRMxErCgAQBBQhBA0FEwsAAQsCAQcFJwoAEAU4CAQcCgAQBjgJDAMFHgkMAwsDBCEFJwsAAQsCAQcGJwsCETgMBA4EETkMBgsEBwAKAC44AQoADwY4CgoAEAcUOAsKABAIFBE+CgYRPxFCCQkxAAYAAAAAAAAAAAkJEUIRQjkADAUKAA8FCgY4DAsALjgBCwYOBTcCFBIEOA0LBTgOAgAFAQAAOngKADcAFAcAIQQHBQsLAAEHDicKADcDFCAEEQUVCwABBw0nCgA3BBQxACEEHggMAwUkCgA3BBQxAyEMAwsDBDIKADcFOA8ELwoANwYUDAIFNAkMAgU0CQwCCwIENwU7CwABBwgnDgE4EBE/CgA3AhQhBEQFSAsAAQcHJwoANwcUBgEAAAAAAAAAFgoANgcVCgA2BQsBOBExAQoANgQVCQoANggVCQoANgkVEUIKADYKFRFCCgA2CxUKAC44EgoANwIUCgA3BxQHAQsANwwUEgU4EwIABgEAAAEPCgAuCwE4FAoCCgA2AxULAC44EgsCEgg4FQIABwEAAAEKCgALATgUCwILADcNCwMLBBEdAgAIAQAAOmYKAC4LATgUCgA3BhQgBBAKADcEFDEAIQwIBRIJDAgLCAQVBSMLAAELAwELAgELBAELBwELBQEHCCcKAi44FgoANw4UIQQwDgYRQCAMCQUyCQwJCwkENQVDCwABCwMBCwIBCwQBCwcBCwUBBwknCgIKAwsECwUHAQoGCwcRKgoCCgMHAUgBAAcQESkLAgsDBwFIAwAHEBEpCgYKADYMFQgKADYGFQsALjgSCwYSBzgXAgAJAAAAHjQKADcAFAcAIQQHBQ0LAAELAQEHDicKATgWCgA3DhQhBBUFGwsAAQsBAQcJJwoANwYUBCgLAQcBESQLADcMFCEMAgUuCwABCwEBCQwCCwIEMQUzBwonAgAKAQAARDAKAC4KATgYCwEKADcNCwIRJREeDAYBAQwEAQEMBQcBIQQhCwUKADcMFCEEHg4GOBkMAwUjCQwDBSMJDAMLAwQmBSoLAAEHCicLBjgaCwAOBDgbAgALAAAASfQBCwERHwwODA8MCwwNDBAMDAoMMQIhBA8IDAMFEwoMMQQhDAMLAwQuCxAKADcPFCEEKwsNCgA3AhQhBCgKCwoANwcUIQwCBTAJDAIFMAkMAgUwCQwCCwIEMwU3CwABBwsnCgA3CBQEPAVACwABBwgnDg8RQCAESQ4OEUAgDAQFSwkMBAsEBE4FUgsAAQcLJwsMMQQhBJ4BCgA3BBQxAiEEXwgMBgVlCgA3BBQxAyEMBgsGBHMKADcJFARwCgA3BTgPDAUFdQkMBQV1CQwFCwUEeAV8CwABBwgnCg8KADcKFCEEiQELDgoANwsUIQwHBYsBCQwHCwcEjgEFkgELAAEHDCcxAwoANgQVCwAuOBILCwsPEgY4HAIKADcEFDECIQSnAQgMCAWtAQoANwQUMQMhDAgLCATFAQoPCgA3ChQhBLwBCg4KADcLFCEMCQW+AQkMCQsJBMEBBesBCwABBwwnCgA3BBQxASEE0AEKADcFOB0MCgXSAQkMCgsKBNUBBdkBCwABBwgnMQIKADYEFQoPCgA2ChUKDgoANgsVCgA2BTgeDg4RQTgfCwAuOBILCwsPCw4SCTggAgAMAAAATmsKATEBIQQxCgA3AxQgBAoFDgsAAQcNJwoANwQUMQEhBBkKADcFOB0MAgUbCQwCCwIEHgUiCwABBwgnMQEKADcPFAoANwIUCwA3BxQRQhFCESAMBQVpCwExAyEETgoANwQUMQIhBD4IDAQFRAoANwQUMQMhDAQLBARLCgA3BTgPDAMFUAkMAwVQCQwDCwMEUwVXCwABBwgnMQMKADcPFAoANwIUCgA3BxQKADcKFAsANwsUESAMBQsFAgANAAAAT9wBCwExASEEB0gBAAwDBQlIAwAMAwsDDAwKAAcBCgwHEREhDAQOBEEbBgIAAAAAAAAAJAQXBRsLAAEHDycLAAcBCwwLAhEhDAkOCUEbBhYAAAAAAAAAJgQ4DgkGAAAAAAAAAABCGxQxACEENQ4JBgEAAAAAAAAAQhsUMQMhDAUFOgkMBQU6CQwFCwUEPQU/Bw8nBgIAAAAAAAAADA0yAAAAAAAAAAAAAAAAAAAAAAwPCg0OCUEbIwTTAQoNBgQAAAAAAAAAFg4JQRslBFAFUgcPJw4JCg0GAQAAAAAAAAAWQhsUNAYAAQAAAAAAABgOCQoNBgIAAAAAAAAAFkIbFDQWDA4OCQoNQhsUMQEhBHYFbA4JCg0GAwAAAAAAAAAWQhsUMQEhDAYFeAkMBgsGBHsFfQcPJwoOBhEAAAAAAAAAIQSEAQgMCAWIAQoOBiEAAAAAAAAAIQwICwgElAEKDQYDAAAAAAAAABYKDhYOCUEbJQwHBZYBCQwHCwcEmQEFmwEHDycyAAAAAAAAAAAAAAAAAAAAAAwKBgAAAAAAAAAADAsKCwYQAAAAAAAAACMEyAELCjEILw4JCg0GBAAAAAAAAAAWCgsWQhsUNRsMCgoOBiEAAAAAAAAAIQTDAQ4JCg0GFAAAAAAAAAAWCgsWQhsUMQAhBMEBBcMBBw8nCwsGAQAAAAAAAAAWDAsFnwELDwsKFgwPCw0GAwAAAAAAAAAWCw4WDA0FQwsPMkANAwAAAAAAAAAAAAAAAAAmBNgBBdoBBw8nCwkCAA4BAABRFgoACgE4GAoACgI4IQwFCgELAgsDEQ0MBgsBCwA3DQcBCwULBgkLBBEoAgAPAQAAUSwKAC4KAS44GAoALgoCOCEMBgoBLgoCCwMRDQwHCwIxASEEGQgKADYIFQUdCAoANgkVCwELADcNBwELBgsHCwQ4IgoFLhE9OCMLBREmAgAQAQAAAQoKAAoBLjgYCwELADcNCwIRIgIAEQEAAAEJCgAKATgYCwELADcNCwIRIwIAEgEAAAEECwA3BBQCABMBAAABBAsANw8UAgAUAQAAAQQLADcCFAIAFQEAAAEECwALATghAgAWAQAAAQQLADcHFAIAFwEAAB4TCgA3BBQxASEECwsAAQgMAQURCwA3BBQxAiEMAQsBAgAYAQAAAQQLADcFOB0CABkBAAABBAsANwEUAgAaAQAAAQQLABAFFAIAGwEAAAECBwECABwBAAABBAsANwwUAgACAQEBAwEDAgIGAgQCAgIDAgUDBgMKAwsDBQMJAwwDDQMOAw8DEAMIAwMDBAMHAi4DLgkuCi4LLgwuDS4OLg8uEC4RLhIuEy4ULhUuFi4A"
            ],
            dependencies: [
              "0x0000000000000000000000000000000000000000000000000000000000000001",
              "0x0000000000000000000000000000000000000000000000000000000000000002",
              "0x28de9e8e087a6347001907fb698fdf8ab0467b342229b74b19264067aebc4ae9",
              "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
              "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24",
              "0x00245ba36f7a1cc643a2b037450dff1e4399e18069c6545fb5fcaaf37d39d7dc",
              "0x3de1504cf3fd75762759e353d9d95389618e557d0552697f19b52e4e927c1dee"
            ]
          }
        },
        {
          $kind: "TransferObjects",
          TransferObjects: {
            objects: [
              {
                $kind: "NestedResult",
                NestedResult: [
                  0,
                  0
                ]
              }
            ],
            address: {
              $kind: "Input",
              Input: 0
            }
          }
        }
      ],
      inputs: [
        {
          $kind: "Pure",
          Pure: {
            bytes: "SFlT4urfSqAq+VDPjpFPvStnUjOF5zw2EYNBRZ2NRcQ="
          }
        }
      ],
      version: 2
    },
    bcs: {
      "0": 0,
      "1": 0,
      "2": 1,
      "3": 0,
      "4": 32,
      "5": 72,
      "6": 89,
      "7": 83,
      "8": 226,
      "9": 234,
      "10": 223,
      "11": 74,
      "12": 160,
      "13": 42,
      "14": 249,
      "15": 80,
      "16": 207,
      "17": 142,
      "18": 145,
      "19": 79,
      "20": 189,
      "21": 43,
      "22": 103,
      "23": 82,
      "24": 51,
      "25": 133,
      "26": 231,
      "27": 60,
      "28": 54,
      "29": 17,
      "30": 131,
      "31": 65,
      "32": 69,
      "33": 157,
      "34": 141,
      "35": 69,
      "36": 196,
      "37": 2,
      "38": 4,
      "39": 2,
      "40": 182,
      "41": 6,
      "42": 161,
      "43": 28,
      "44": 235,
      "45": 11,
      "46": 7,
      "47": 0,
      "48": 0,
      "49": 5,
      "50": 9,
      "51": 1,
      "52": 0,
      "53": 6,
      "54": 2,
      "55": 6,
      "56": 4,
      "57": 3,
      "58": 10,
      "59": 31,
      "60": 4,
      "61": 41,
      "62": 2,
      "63": 5,
      "64": 43,
      "65": 62,
      "66": 7,
      "67": 105,
      "68": 75,
      "69": 8,
      "70": 180,
      "71": 1,
      "72": 96,
      "73": 6,
      "74": 148,
      "75": 2,
      "76": 14,
      "77": 12,
      "78": 162,
      "79": 2,
      "80": 235,
      "81": 3,
      "82": 0,
      "83": 3,
      "84": 1,
      "85": 8,
      "86": 2,
      "87": 2,
      "88": 2,
      "89": 0,
      "90": 7,
      "91": 0,
      "92": 0,
      "93": 5,
      "94": 0,
      "95": 1,
      "96": 0,
      "97": 0,
      "98": 4,
      "99": 2,
      "100": 0,
      "101": 0,
      "102": 0,
      "103": 9,
      "104": 3,
      "105": 4,
      "106": 0,
      "107": 1,
      "108": 1,
      "109": 9,
      "110": 7,
      "111": 1,
      "112": 0,
      "113": 2,
      "114": 6,
      "115": 1,
      "116": 4,
      "117": 0,
      "118": 2,
      "119": 7,
      "120": 8,
      "121": 1,
      "122": 0,
      "123": 3,
      "124": 6,
      "125": 6,
      "126": 2,
      "127": 8,
      "128": 0,
      "129": 8,
      "130": 0,
      "131": 3,
      "132": 8,
      "133": 0,
      "134": 8,
      "135": 0,
      "136": 1,
      "137": 10,
      "138": 2,
      "139": 1,
      "140": 6,
      "141": 10,
      "142": 2,
      "143": 2,
      "144": 6,
      "145": 10,
      "146": 2,
      "147": 3,
      "148": 1,
      "149": 8,
      "150": 0,
      "151": 3,
      "152": 1,
      "153": 2,
      "154": 10,
      "155": 2,
      "156": 1,
      "157": 2,
      "158": 0,
      "159": 1,
      "160": 6,
      "161": 8,
      "162": 0,
      "163": 2,
      "164": 7,
      "165": 10,
      "166": 9,
      "167": 0,
      "168": 10,
      "169": 9,
      "170": 0,
      "171": 5,
      "172": 1,
      "173": 1,
      "174": 3,
      "175": 3,
      "176": 2,
      "177": 6,
      "178": 2,
      "179": 7,
      "180": 10,
      "181": 2,
      "182": 3,
      "183": 3,
      "184": 3,
      "185": 10,
      "186": 2,
      "187": 7,
      "188": 66,
      "189": 121,
      "190": 116,
      "191": 101,
      "192": 115,
      "193": 51,
      "194": 50,
      "195": 6,
      "196": 97,
      "197": 112,
      "198": 112,
      "199": 101,
      "200": 110,
      "201": 100,
      "202": 7,
      "203": 98,
      "204": 121,
      "205": 116,
      "206": 101,
      "207": 115,
      "208": 51,
      "209": 50,
      "210": 5,
      "211": 99,
      "212": 111,
      "213": 100,
      "214": 101,
      "215": 99,
      "216": 6,
      "217": 100,
      "218": 101,
      "219": 99,
      "220": 111,
      "221": 100,
      "222": 101,
      "223": 6,
      "224": 101,
      "225": 110,
      "226": 99,
      "227": 111,
      "228": 100,
      "229": 101,
      "230": 10,
      "231": 102,
      "232": 114,
      "233": 111,
      "234": 109,
      "235": 95,
      "236": 98,
      "237": 121,
      "238": 116,
      "239": 101,
      "240": 115,
      "241": 8,
      "242": 116,
      "243": 111,
      "244": 95,
      "245": 98,
      "246": 121,
      "247": 116,
      "248": 101,
      "249": 115,
      "250": 6,
      "251": 118,
      "252": 101,
      "253": 99,
      "254": 116,
      "255": 111,
      "256": 114,
      "257": 4,
      "258": 119,
      "259": 111,
      "260": 114,
      "261": 100,
      "262": 0,
      "263": 0,
      "264": 0,
      "265": 0,
      "266": 0,
      "267": 0,
      "268": 0,
      "269": 0,
      "270": 0,
      "271": 0,
      "272": 0,
      "273": 0,
      "274": 0,
      "275": 0,
      "276": 0,
      "277": 0,
      "278": 0,
      "279": 0,
      "280": 0,
      "281": 0,
      "282": 0,
      "283": 0,
      "284": 0,
      "285": 0,
      "286": 0,
      "287": 0,
      "288": 0,
      "289": 0,
      "290": 0,
      "291": 0,
      "292": 0,
      "293": 0,
      "294": 0,
      "295": 0,
      "296": 0,
      "297": 0,
      "298": 0,
      "299": 0,
      "300": 0,
      "301": 0,
      "302": 0,
      "303": 0,
      "304": 0,
      "305": 0,
      "306": 0,
      "307": 0,
      "308": 0,
      "309": 0,
      "310": 0,
      "311": 0,
      "312": 0,
      "313": 0,
      "314": 0,
      "315": 0,
      "316": 0,
      "317": 0,
      "318": 0,
      "319": 0,
      "320": 0,
      "321": 0,
      "322": 0,
      "323": 0,
      "324": 0,
      "325": 1,
      "326": 0,
      "327": 36,
      "328": 91,
      "329": 163,
      "330": 111,
      "331": 122,
      "332": 28,
      "333": 198,
      "334": 67,
      "335": 162,
      "336": 176,
      "337": 55,
      "338": 69,
      "339": 13,
      "340": 255,
      "341": 30,
      "342": 67,
      "343": 153,
      "344": 225,
      "345": 128,
      "346": 105,
      "347": 198,
      "348": 84,
      "349": 95,
      "350": 181,
      "351": 252,
      "352": 170,
      "353": 243,
      "354": 125,
      "355": 57,
      "356": 215,
      "357": 220,
      "358": 3,
      "359": 8,
      "360": 100,
      "361": 0,
      "362": 0,
      "363": 0,
      "364": 0,
      "365": 0,
      "366": 0,
      "367": 0,
      "368": 10,
      "369": 2,
      "370": 1,
      "371": 0,
      "372": 0,
      "373": 1,
      "374": 0,
      "375": 0,
      "376": 5,
      "377": 66,
      "378": 10,
      "379": 0,
      "380": 49,
      "381": 1,
      "382": 38,
      "383": 4,
      "384": 16,
      "385": 10,
      "386": 0,
      "387": 49,
      "388": 4,
      "389": 37,
      "390": 4,
      "391": 13,
      "392": 10,
      "393": 3,
      "394": 6,
      "395": 0,
      "396": 0,
      "397": 0,
      "398": 0,
      "399": 0,
      "400": 0,
      "401": 0,
      "402": 0,
      "403": 36,
      "404": 12,
      "405": 6,
      "406": 5,
      "407": 18,
      "408": 9,
      "409": 12,
      "410": 6,
      "411": 5,
      "412": 18,
      "413": 9,
      "414": 12,
      "415": 6,
      "416": 11,
      "417": 6,
      "418": 4,
      "419": 21,
      "420": 5,
      "421": 23,
      "422": 7,
      "423": 0,
      "424": 39,
      "425": 49,
      "426": 3,
      "427": 11,
      "428": 0,
      "429": 64,
      "430": 6,
      "431": 2,
      "432": 0,
      "433": 0,
      "434": 0,
      "435": 0,
      "436": 0,
      "437": 0,
      "438": 0,
      "439": 12,
      "440": 8,
      "441": 13,
      "442": 8,
      "443": 14,
      "444": 1,
      "445": 17,
      "446": 5,
      "447": 56,
      "448": 0,
      "449": 13,
      "450": 8,
      "451": 14,
      "452": 2,
      "453": 17,
      "454": 5,
      "455": 56,
      "456": 0,
      "457": 49,
      "458": 8,
      "459": 12,
      "460": 7,
      "461": 10,
      "462": 7,
      "463": 49,
      "464": 0,
      "465": 36,
      "466": 4,
      "467": 56,
      "468": 11,
      "469": 7,
      "470": 49,
      "471": 1,
      "472": 23,
      "473": 12,
      "474": 7,
      "475": 13,
      "476": 8,
      "477": 10,
      "478": 3,
      "479": 10,
      "480": 7,
      "481": 49,
      "482": 8,
      "483": 24,
      "484": 48,
      "485": 6,
      "486": 255,
      "487": 0,
      "488": 0,
      "489": 0,
      "490": 0,
      "491": 0,
      "492": 0,
      "493": 0,
      "494": 28,
      "495": 51,
      "496": 68,
      "497": 6,
      "498": 5,
      "499": 37,
      "500": 13,
      "501": 8,
      "502": 14,
      "503": 4,
      "504": 17,
      "505": 5,
      "506": 56,
      "507": 0,
      "508": 13,
      "509": 8,
      "510": 14,
      "511": 5,
      "512": 17,
      "513": 5,
      "514": 56,
      "515": 0,
      "516": 11,
      "517": 8,
      "518": 2,
      "519": 0,
      "520": 1,
      "521": 1,
      "522": 0,
      "523": 0,
      "524": 10,
      "525": 92,
      "526": 10,
      "527": 0,
      "528": 65,
      "529": 6,
      "530": 6,
      "531": 138,
      "532": 0,
      "533": 0,
      "534": 0,
      "535": 0,
      "536": 0,
      "537": 0,
      "538": 0,
      "539": 33,
      "540": 4,
      "541": 13,
      "542": 10,
      "543": 0,
      "544": 6,
      "545": 0,
      "546": 0,
      "547": 0,
      "548": 0,
      "549": 0,
      "550": 0,
      "551": 0,
      "552": 0,
      "553": 66,
      "554": 6,
      "555": 20,
      "556": 49,
      "557": 3,
      "558": 33,
      "559": 12,
      "560": 1,
      "561": 5,
      "562": 15,
      "563": 9,
      "564": 12,
      "565": 1,
      "566": 11,
      "567": 1,
      "568": 4,
      "569": 18,
      "570": 5,
      "571": 22,
      "572": 11,
      "573": 0,
      "574": 1,
      "575": 7,
      "576": 0,
      "577": 39,
      "578": 10,
      "579": 0,
      "580": 6,
      "581": 1,
      "582": 0,
      "583": 0,
      "584": 0,
      "585": 0,
      "586": 0,
      "587": 0,
      "588": 0,
      "589": 66,
      "590": 6,
      "591": 20,
      "592": 12,
      "593": 5,
      "594": 10,
      "595": 5,
      "596": 49,
      "597": 1,
      "598": 38,
      "599": 4,
      "600": 36,
      "601": 10,
      "602": 5,
      "603": 49,
      "604": 4,
      "605": 37,
      "606": 12,
      "607": 2,
      "608": 5,
      "609": 38,
      "610": 9,
      "611": 12,
      "612": 2,
      "613": 11,
      "614": 2,
      "615": 4,
      "616": 41,
      "617": 5,
      "618": 45,
      "619": 11,
      "620": 0,
      "621": 1,
      "622": 7,
      "623": 0,
      "624": 39,
      "625": 6,
      "626": 0,
      "627": 0,
      "628": 0,
      "629": 0,
      "630": 0,
      "631": 0,
      "632": 0,
      "633": 0,
      "634": 12,
      "635": 3,
      "636": 6,
      "637": 66,
      "638": 0,
      "639": 0,
      "640": 0,
      "641": 0,
      "642": 0,
      "643": 0,
      "644": 0,
      "645": 12,
      "646": 4,
      "647": 10,
      "648": 4,
      "649": 6,
      "650": 74,
      "651": 0,
      "652": 0,
      "653": 0,
      "654": 0,
      "655": 0,
      "656": 0,
      "657": 0,
      "658": 35,
      "659": 4,
      "660": 68,
      "661": 11,
      "662": 3,
      "663": 49,
      "664": 8,
      "665": 47,
      "666": 10,
      "667": 0,
      "668": 10,
      "669": 4,
      "670": 66,
      "671": 6,
      "672": 20,
      "673": 52,
      "674": 27,
      "675": 12,
      "676": 3,
      "677": 11,
      "678": 4,
      "679": 6,
      "680": 1,
      "681": 0,
      "682": 0,
      "683": 0,
      "684": 0,
      "685": 0,
      "686": 0,
      "687": 0,
      "688": 22,
      "689": 12,
      "690": 4,
      "691": 5,
      "692": 49,
      "693": 10,
      "694": 3,
      "695": 6,
      "696": 0,
      "697": 0,
      "698": 0,
      "699": 0,
      "700": 0,
      "701": 0,
      "702": 0,
      "703": 0,
      "704": 36,
      "705": 4,
      "706": 73,
      "707": 5,
      "708": 77,
      "709": 11,
      "710": 0,
      "711": 1,
      "712": 7,
      "713": 0,
      "714": 39,
      "715": 11,
      "716": 5,
      "717": 10,
      "718": 0,
      "719": 6,
      "720": 2,
      "721": 0,
      "722": 0,
      "723": 0,
      "724": 0,
      "725": 0,
      "726": 0,
      "727": 0,
      "728": 17,
      "729": 2,
      "730": 10,
      "731": 0,
      "732": 6,
      "733": 34,
      "734": 0,
      "735": 0,
      "736": 0,
      "737": 0,
      "738": 0,
      "739": 0,
      "740": 0,
      "741": 17,
      "742": 2,
      "743": 11,
      "744": 3,
      "745": 10,
      "746": 0,
      "747": 6,
      "748": 74,
      "749": 0,
      "750": 0,
      "751": 0,
      "752": 0,
      "753": 0,
      "754": 0,
      "755": 0,
      "756": 17,
      "757": 2,
      "758": 11,
      "759": 0,
      "760": 6,
      "761": 106,
      "762": 0,
      "763": 0,
      "764": 0,
      "765": 0,
      "766": 0,
      "767": 0,
      "768": 0,
      "769": 17,
      "770": 2,
      "771": 2,
      "772": 0,
      "773": 2,
      "774": 0,
      "775": 0,
      "776": 0,
      "777": 11,
      "778": 34,
      "779": 7,
      "780": 1,
      "781": 12,
      "782": 7,
      "783": 6,
      "784": 0,
      "785": 0,
      "786": 0,
      "787": 0,
      "788": 0,
      "789": 0,
      "790": 0,
      "791": 0,
      "792": 12,
      "793": 6,
      "794": 10,
      "795": 6,
      "796": 6,
      "797": 32,
      "798": 0,
      "799": 0,
      "800": 0,
      "801": 0,
      "802": 0,
      "803": 0,
      "804": 0,
      "805": 35,
      "806": 4,
      "807": 29,
      "808": 10,
      "809": 6,
      "810": 12,
      "811": 4,
      "812": 13,
      "813": 7,
      "814": 12,
      "815": 3,
      "816": 11,
      "817": 4,
      "818": 12,
      "819": 5,
      "820": 10,
      "821": 0,
      "822": 10,
      "823": 1,
      "824": 11,
      "825": 5,
      "826": 22,
      "827": 66,
      "828": 6,
      "829": 20,
      "830": 12,
      "831": 2,
      "832": 11,
      "833": 3,
      "834": 11,
      "835": 2,
      "836": 68,
      "837": 6,
      "838": 11,
      "839": 6,
      "840": 6,
      "841": 1,
      "842": 0,
      "843": 0,
      "844": 0,
      "845": 0,
      "846": 0,
      "847": 0,
      "848": 0,
      "849": 22,
      "850": 12,
      "851": 6,
      "852": 5,
      "853": 4,
      "854": 11,
      "855": 0,
      "856": 1,
      "857": 11,
      "858": 7,
      "859": 17,
      "860": 4,
      "861": 2,
      "862": 0,
      "863": 0,
      "864": 210,
      "865": 46,
      "866": 161,
      "867": 28,
      "868": 235,
      "869": 11,
      "870": 7,
      "871": 0,
      "872": 0,
      "873": 5,
      "874": 13,
      "875": 1,
      "876": 0,
      "877": 46,
      "878": 2,
      "879": 46,
      "880": 138,
      "881": 1,
      "882": 3,
      "883": 184,
      "884": 1,
      "885": 245,
      "886": 2,
      "887": 4,
      "888": 173,
      "889": 4,
      "890": 72,
      "891": 5,
      "892": 245,
      "893": 4,
      "894": 180,
      "895": 5,
      "896": 7,
      "897": 169,
      "898": 10,
      "899": 155,
      "900": 9,
      "901": 8,
      "902": 196,
      "903": 19,
      "904": 128,
      "905": 2,
      "906": 6,
      "907": 196,
      "908": 21,
      "909": 181,
      "910": 2,
      "911": 10,
      "912": 249,
      "913": 23,
      "914": 160,
      "915": 1,
      "916": 11,
      "917": 153,
      "918": 25,
      "919": 2,
      "920": 12,
      "921": 155,
      "922": 25,
      "923": 165,
      "924": 20,
      "925": 13,
      "926": 192,
      "927": 45,
      "928": 46,
      "929": 14,
      "930": 238,
      "931": 45,
      "932": 32,
      "933": 0,
      "934": 122,
      "935": 4,
      "936": 40,
      "937": 4,
      "938": 41,
      "939": 5,
      "940": 57,
      "941": 5,
      "942": 58,
      "943": 5,
      "944": 59,
      "945": 5,
      "946": 78,
      "947": 5,
      "948": 80,
      "949": 5,
      "950": 81,
      "951": 5,
      "952": 82,
      "953": 0,
      "954": 43,
      "955": 7,
      "956": 88,
      "957": 1,
      "958": 35,
      "959": 1,
      "960": 90,
      "961": 1,
      "962": 119,
      "963": 2,
      "964": 44,
      "965": 2,
      "966": 60,
      "967": 2,
      "968": 89,
      "969": 2,
      "970": 115,
      "971": 2,
      "972": 117,
      "973": 2,
      "974": 118,
      "975": 3,
      "976": 39,
      "977": 6,
      "978": 127,
      "979": 0,
      "980": 27,
      "981": 2,
      "982": 0,
      "983": 0,
      "984": 0,
      "985": 8,
      "986": 0,
      "987": 0,
      "988": 18,
      "989": 8,
      "990": 0,
      "991": 0,
      "992": 28,
      "993": 8,
      "994": 1,
      "995": 12,
      "996": 0,
      "997": 0,
      "998": 22,
      "999": 3,
      "1000": 0,
      "1001": 0,
      "1002": 8,
      "1003": 3,
      "1004": 0,
      "1005": 0,
      "1006": 6,
      "1007": 3,
      "1008": 0,
      "1009": 0,
      "1010": 1,
      "1011": 3,
      "1012": 0,
      "1013": 0,
      "1014": 16,
      "1015": 3,
      "1016": 0,
      "1017": 0,
      "1018": 19,
      "1019": 3,
      "1020": 0,
      "1021": 1,
      "1022": 3,
      "1023": 0,
      "1024": 2,
      "1025": 0,
      "1026": 0,
      "1027": 0,
      "1028": 0,
      "1029": 1,
      "1030": 29,
      "1031": 7,
      "1032": 0,
      "1033": 2,
      "1034": 4,
      "1035": 12,
      "1036": 0,
      "1037": 3,
      "1038": 17,
      "1039": 7,
      "1040": 0,
      "1041": 4,
      "1042": 21,
      "1043": 0,
      "1044": 0,
      "1045": 5,
      "1046": 7,
      "1047": 8,
      "1048": 0,
      "1049": 6,
      "1050": 10,
      "1051": 0,
      "1052": 0,
      "1053": 7,
      "1054": 11,
      "1055": 8,
      "1056": 0,
      "1057": 8,
      "1058": 12,
      "1059": 7,
      "1060": 0,
      "1061": 9,
      "1062": 13,
      "1063": 7,
      "1064": 0,
      "1065": 11,
      "1066": 0,
      "1067": 12,
      "1068": 0,
      "1069": 11,
      "1070": 14,
      "1071": 8,
      "1072": 0,
      "1073": 12,
      "1074": 23,
      "1075": 7,
      "1076": 0,
      "1077": 13,
      "1078": 15,
      "1079": 7,
      "1080": 1,
      "1081": 0,
      "1082": 0,
      "1083": 14,
      "1084": 25,
      "1085": 7,
      "1086": 0,
      "1087": 15,
      "1088": 5,
      "1089": 12,
      "1090": 1,
      "1091": 0,
      "1092": 1,
      "1093": 17,
      "1094": 9,
      "1095": 7,
      "1096": 0,
      "1097": 17,
      "1098": 26,
      "1099": 4,
      "1100": 0,
      "1101": 18,
      "1102": 20,
      "1103": 2,
      "1104": 0,
      "1105": 20,
      "1106": 24,
      "1107": 2,
      "1108": 0,
      "1109": 21,
      "1110": 2,
      "1111": 7,
      "1112": 0,
      "1113": 22,
      "1114": 30,
      "1115": 2,
      "1116": 0,
      "1117": 0,
      "1118": 72,
      "1119": 0,
      "1120": 1,
      "1121": 0,
      "1122": 0,
      "1123": 84,
      "1124": 2,
      "1125": 3,
      "1126": 0,
      "1127": 0,
      "1128": 103,
      "1129": 4,
      "1130": 1,
      "1131": 0,
      "1132": 0,
      "1133": 123,
      "1134": 5,
      "1135": 1,
      "1136": 1,
      "1137": 12,
      "1138": 0,
      "1139": 49,
      "1140": 6,
      "1141": 1,
      "1142": 1,
      "1143": 12,
      "1144": 0,
      "1145": 66,
      "1146": 7,
      "1147": 1,
      "1148": 1,
      "1149": 12,
      "1150": 0,
      "1151": 110,
      "1152": 8,
      "1153": 1,
      "1154": 1,
      "1155": 12,
      "1156": 0,
      "1157": 100,
      "1158": 9,
      "1159": 10,
      "1160": 1,
      "1161": 12,
      "1162": 0,
      "1163": 37,
      "1164": 11,
      "1165": 1,
      "1166": 1,
      "1167": 12,
      "1168": 0,
      "1169": 121,
      "1170": 12,
      "1171": 1,
      "1172": 1,
      "1173": 12,
      "1174": 0,
      "1175": 78,
      "1176": 13,
      "1177": 1,
      "1178": 1,
      "1179": 12,
      "1180": 0,
      "1181": 96,
      "1182": 14,
      "1183": 1,
      "1184": 1,
      "1185": 12,
      "1186": 0,
      "1187": 92,
      "1188": 15,
      "1189": 16,
      "1190": 1,
      "1191": 12,
      "1192": 0,
      "1193": 61,
      "1194": 17,
      "1195": 16,
      "1196": 0,
      "1197": 0,
      "1198": 98,
      "1199": 18,
      "1200": 19,
      "1201": 1,
      "1202": 12,
      "1203": 0,
      "1204": 107,
      "1205": 20,
      "1206": 21,
      "1207": 1,
      "1208": 12,
      "1209": 0,
      "1210": 48,
      "1211": 22,
      "1212": 23,
      "1213": 1,
      "1214": 12,
      "1215": 0,
      "1216": 47,
      "1217": 24,
      "1218": 25,
      "1219": 1,
      "1220": 12,
      "1221": 0,
      "1222": 95,
      "1223": 26,
      "1224": 27,
      "1225": 1,
      "1226": 12,
      "1227": 0,
      "1228": 106,
      "1229": 26,
      "1230": 28,
      "1231": 1,
      "1232": 12,
      "1233": 0,
      "1234": 36,
      "1235": 26,
      "1236": 28,
      "1237": 1,
      "1238": 12,
      "1239": 0,
      "1240": 93,
      "1241": 15,
      "1242": 16,
      "1243": 1,
      "1244": 12,
      "1245": 0,
      "1246": 67,
      "1247": 26,
      "1248": 29,
      "1249": 1,
      "1250": 12,
      "1251": 0,
      "1252": 33,
      "1253": 26,
      "1254": 30,
      "1255": 1,
      "1256": 12,
      "1257": 0,
      "1258": 69,
      "1259": 26,
      "1260": 30,
      "1261": 1,
      "1262": 12,
      "1263": 0,
      "1264": 104,
      "1265": 26,
      "1266": 31,
      "1267": 1,
      "1268": 12,
      "1269": 0,
      "1270": 113,
      "1271": 32,
      "1272": 33,
      "1273": 0,
      "1274": 0,
      "1275": 51,
      "1276": 1,
      "1277": 34,
      "1278": 0,
      "1279": 0,
      "1280": 94,
      "1281": 26,
      "1282": 28,
      "1283": 1,
      "1284": 12,
      "1285": 5,
      "1286": 101,
      "1287": 61,
      "1288": 10,
      "1289": 0,
      "1290": 6,
      "1291": 52,
      "1292": 70,
      "1293": 71,
      "1294": 0,
      "1295": 10,
      "1296": 50,
      "1297": 74,
      "1298": 75,
      "1299": 0,
      "1300": 10,
      "1301": 56,
      "1302": 75,
      "1303": 16,
      "1304": 0,
      "1305": 11,
      "1306": 45,
      "1307": 80,
      "1308": 16,
      "1309": 0,
      "1310": 11,
      "1311": 46,
      "1312": 85,
      "1313": 23,
      "1314": 0,
      "1315": 11,
      "1316": 47,
      "1317": 86,
      "1318": 25,
      "1319": 0,
      "1320": 11,
      "1321": 68,
      "1322": 67,
      "1323": 28,
      "1324": 0,
      "1325": 11,
      "1326": 78,
      "1327": 69,
      "1328": 70,
      "1329": 0,
      "1330": 11,
      "1331": 79,
      "1332": 84,
      "1333": 21,
      "1334": 0,
      "1335": 11,
      "1336": 83,
      "1337": 38,
      "1338": 39,
      "1339": 1,
      "1340": 2,
      "1341": 11,
      "1342": 98,
      "1343": 82,
      "1344": 19,
      "1345": 0,
      "1346": 11,
      "1347": 109,
      "1348": 65,
      "1349": 1,
      "1350": 0,
      "1351": 11,
      "1352": 111,
      "1353": 64,
      "1354": 1,
      "1355": 0,
      "1356": 12,
      "1357": 73,
      "1358": 51,
      "1359": 16,
      "1360": 0,
      "1361": 13,
      "1362": 53,
      "1363": 48,
      "1364": 1,
      "1365": 1,
      "1366": 0,
      "1367": 13,
      "1368": 62,
      "1369": 54,
      "1370": 46,
      "1371": 1,
      "1372": 0,
      "1373": 13,
      "1374": 63,
      "1375": 55,
      "1376": 1,
      "1377": 1,
      "1378": 0,
      "1379": 13,
      "1380": 75,
      "1381": 52,
      "1382": 30,
      "1383": 1,
      "1384": 0,
      "1385": 13,
      "1386": 76,
      "1387": 52,
      "1388": 30,
      "1389": 1,
      "1390": 0,
      "1391": 13,
      "1392": 87,
      "1393": 1,
      "1394": 48,
      "1395": 1,
      "1396": 0,
      "1397": 13,
      "1398": 114,
      "1399": 46,
      "1400": 48,
      "1401": 1,
      "1402": 0,
      "1403": 14,
      "1404": 74,
      "1405": 50,
      "1406": 51,
      "1407": 0,
      "1408": 14,
      "1409": 125,
      "1410": 1,
      "1411": 50,
      "1412": 1,
      "1413": 0,
      "1414": 16,
      "1415": 55,
      "1416": 46,
      "1417": 1,
      "1418": 1,
      "1419": 3,
      "1420": 17,
      "1421": 70,
      "1422": 42,
      "1423": 31,
      "1424": 1,
      "1425": 8,
      "1426": 17,
      "1427": 71,
      "1428": 42,
      "1429": 10,
      "1430": 1,
      "1431": 8,
      "1432": 17,
      "1433": 83,
      "1434": 40,
      "1435": 41,
      "1436": 0,
      "1437": 17,
      "1438": 120,
      "1439": 53,
      "1440": 31,
      "1441": 0,
      "1442": 19,
      "1443": 97,
      "1444": 44,
      "1445": 1,
      "1446": 1,
      "1447": 12,
      "1448": 19,
      "1449": 112,
      "1450": 46,
      "1451": 1,
      "1452": 1,
      "1453": 8,
      "1454": 19,
      "1455": 117,
      "1456": 44,
      "1457": 1,
      "1458": 1,
      "1459": 8,
      "1460": 20,
      "1461": 108,
      "1462": 36,
      "1463": 10,
      "1464": 0,
      "1465": 21,
      "1466": 64,
      "1467": 10,
      "1468": 28,
      "1469": 0,
      "1470": 21,
      "1471": 65,
      "1472": 31,
      "1473": 28,
      "1474": 0,
      "1475": 21,
      "1476": 77,
      "1477": 63,
      "1478": 30,
      "1479": 0,
      "1480": 21,
      "1481": 116,
      "1482": 63,
      "1483": 10,
      "1484": 0,
      "1485": 21,
      "1486": 126,
      "1487": 1,
      "1488": 28,
      "1489": 0,
      "1490": 39,
      "1491": 37,
      "1492": 54,
      "1493": 3,
      "1494": 58,
      "1495": 43,
      "1496": 60,
      "1497": 45,
      "1498": 59,
      "1499": 3,
      "1500": 50,
      "1501": 47,
      "1502": 49,
      "1503": 31,
      "1504": 52,
      "1505": 46,
      "1506": 47,
      "1507": 31,
      "1508": 48,
      "1509": 47,
      "1510": 45,
      "1511": 47,
      "1512": 49,
      "1513": 46,
      "1514": 46,
      "1515": 31,
      "1516": 53,
      "1517": 56,
      "1518": 59,
      "1519": 57,
      "1520": 47,
      "1521": 46,
      "1522": 54,
      "1523": 46,
      "1524": 46,
      "1525": 46,
      "1526": 54,
      "1527": 57,
      "1528": 53,
      "1529": 59,
      "1530": 3,
      "1531": 46,
      "1532": 53,
      "1533": 60,
      "1534": 55,
      "1535": 62,
      "1536": 53,
      "1537": 66,
      "1538": 9,
      "1539": 46,
      "1540": 47,
      "1541": 72,
      "1542": 44,
      "1543": 72,
      "1544": 11,
      "1545": 46,
      "1546": 53,
      "1547": 76,
      "1548": 48,
      "1549": 46,
      "1550": 45,
      "1551": 46,
      "1552": 58,
      "1553": 46,
      "1554": 53,
      "1555": 77,
      "1556": 12,
      "1557": 46,
      "1558": 49,
      "1559": 83,
      "1560": 50,
      "1561": 10,
      "1562": 2,
      "1563": 8,
      "1564": 0,
      "1565": 7,
      "1566": 8,
      "1567": 29,
      "1568": 0,
      "1569": 5,
      "1570": 8,
      "1571": 12,
      "1572": 5,
      "1573": 5,
      "1574": 10,
      "1575": 2,
      "1576": 7,
      "1577": 8,
      "1578": 29,
      "1579": 1,
      "1580": 8,
      "1581": 2,
      "1582": 2,
      "1583": 6,
      "1584": 8,
      "1585": 2,
      "1586": 6,
      "1587": 8,
      "1588": 1,
      "1589": 2,
      "1590": 6,
      "1591": 11,
      "1592": 3,
      "1593": 1,
      "1594": 9,
      "1595": 0,
      "1596": 6,
      "1597": 8,
      "1598": 1,
      "1599": 3,
      "1600": 7,
      "1601": 8,
      "1602": 2,
      "1603": 6,
      "1604": 8,
      "1605": 1,
      "1606": 7,
      "1607": 8,
      "1608": 29,
      "1609": 2,
      "1610": 7,
      "1611": 11,
      "1612": 3,
      "1613": 1,
      "1614": 9,
      "1615": 0,
      "1616": 9,
      "1617": 0,
      "1618": 3,
      "1619": 7,
      "1620": 11,
      "1621": 3,
      "1622": 1,
      "1623": 9,
      "1624": 0,
      "1625": 6,
      "1626": 8,
      "1627": 1,
      "1628": 1,
      "1629": 5,
      "1630": 6,
      "1631": 11,
      "1632": 3,
      "1633": 1,
      "1634": 9,
      "1635": 0,
      "1636": 6,
      "1637": 8,
      "1638": 1,
      "1639": 7,
      "1640": 8,
      "1641": 15,
      "1642": 10,
      "1643": 2,
      "1644": 7,
      "1645": 8,
      "1646": 29,
      "1647": 1,
      "1648": 5,
      "1649": 8,
      "1650": 7,
      "1651": 11,
      "1652": 3,
      "1653": 1,
      "1654": 9,
      "1655": 0,
      "1656": 6,
      "1657": 8,
      "1658": 1,
      "1659": 7,
      "1660": 8,
      "1661": 21,
      "1662": 6,
      "1663": 8,
      "1664": 20,
      "1665": 6,
      "1666": 8,
      "1667": 15,
      "1668": 7,
      "1669": 8,
      "1670": 17,
      "1671": 8,
      "1672": 30,
      "1673": 7,
      "1674": 8,
      "1675": 29,
      "1676": 2,
      "1677": 6,
      "1678": 11,
      "1679": 3,
      "1680": 1,
      "1681": 9,
      "1682": 0,
      "1683": 6,
      "1684": 8,
      "1685": 21,
      "1686": 3,
      "1687": 7,
      "1688": 11,
      "1689": 3,
      "1690": 1,
      "1691": 9,
      "1692": 0,
      "1693": 6,
      "1694": 8,
      "1695": 21,
      "1696": 11,
      "1697": 10,
      "1698": 2,
      "1699": 8,
      "1700": 16,
      "1701": 8,
      "1702": 11,
      "1703": 2,
      "1704": 7,
      "1705": 11,
      "1706": 3,
      "1707": 1,
      "1708": 9,
      "1709": 0,
      "1710": 6,
      "1711": 10,
      "1712": 2,
      "1713": 2,
      "1714": 6,
      "1715": 11,
      "1716": 3,
      "1717": 1,
      "1718": 9,
      "1719": 0,
      "1720": 2,
      "1721": 1,
      "1722": 10,
      "1723": 2,
      "1724": 3,
      "1725": 6,
      "1726": 8,
      "1727": 21,
      "1728": 2,
      "1729": 10,
      "1730": 2,
      "1731": 5,
      "1732": 6,
      "1733": 11,
      "1734": 3,
      "1735": 1,
      "1736": 9,
      "1737": 0,
      "1738": 6,
      "1739": 8,
      "1740": 21,
      "1741": 2,
      "1742": 10,
      "1743": 2,
      "1744": 7,
      "1745": 8,
      "1746": 29,
      "1747": 1,
      "1748": 11,
      "1749": 10,
      "1750": 2,
      "1751": 8,
      "1752": 13,
      "1753": 8,
      "1754": 18,
      "1755": 6,
      "1756": 7,
      "1757": 11,
      "1758": 3,
      "1759": 1,
      "1760": 9,
      "1761": 0,
      "1762": 7,
      "1763": 8,
      "1764": 21,
      "1765": 2,
      "1766": 10,
      "1767": 2,
      "1768": 11,
      "1769": 25,
      "1770": 1,
      "1771": 8,
      "1772": 28,
      "1773": 7,
      "1774": 8,
      "1775": 29,
      "1776": 1,
      "1777": 11,
      "1778": 10,
      "1779": 2,
      "1780": 8,
      "1781": 14,
      "1782": 8,
      "1783": 19,
      "1784": 3,
      "1785": 6,
      "1786": 11,
      "1787": 3,
      "1788": 1,
      "1789": 9,
      "1790": 0,
      "1791": 7,
      "1792": 8,
      "1793": 21,
      "1794": 11,
      "1795": 10,
      "1796": 2,
      "1797": 8,
      "1798": 14,
      "1799": 8,
      "1800": 19,
      "1801": 2,
      "1802": 8,
      "1803": 14,
      "1804": 8,
      "1805": 19,
      "1806": 3,
      "1807": 6,
      "1808": 11,
      "1809": 3,
      "1810": 1,
      "1811": 9,
      "1812": 0,
      "1813": 6,
      "1814": 8,
      "1815": 21,
      "1816": 11,
      "1817": 10,
      "1818": 2,
      "1819": 8,
      "1820": 13,
      "1821": 8,
      "1822": 18,
      "1823": 2,
      "1824": 8,
      "1825": 13,
      "1826": 8,
      "1827": 18,
      "1828": 1,
      "1829": 6,
      "1830": 11,
      "1831": 3,
      "1832": 1,
      "1833": 9,
      "1834": 0,
      "1835": 1,
      "1836": 2,
      "1837": 1,
      "1838": 8,
      "1839": 30,
      "1840": 1,
      "1841": 3,
      "1842": 1,
      "1843": 1,
      "1844": 1,
      "1845": 8,
      "1846": 26,
      "1847": 1,
      "1848": 6,
      "1849": 8,
      "1850": 2,
      "1851": 1,
      "1852": 11,
      "1853": 23,
      "1854": 1,
      "1855": 8,
      "1856": 26,
      "1857": 1,
      "1858": 14,
      "1859": 4,
      "1860": 8,
      "1861": 1,
      "1862": 5,
      "1863": 8,
      "1864": 20,
      "1865": 8,
      "1866": 2,
      "1867": 1,
      "1868": 6,
      "1869": 8,
      "1870": 29,
      "1871": 1,
      "1872": 8,
      "1873": 0,
      "1874": 2,
      "1875": 6,
      "1876": 9,
      "1877": 0,
      "1878": 7,
      "1879": 8,
      "1880": 29,
      "1881": 3,
      "1882": 8,
      "1883": 12,
      "1884": 8,
      "1885": 20,
      "1886": 5,
      "1887": 1,
      "1888": 7,
      "1889": 8,
      "1890": 29,
      "1891": 1,
      "1892": 8,
      "1893": 27,
      "1894": 1,
      "1895": 6,
      "1896": 9,
      "1897": 0,
      "1898": 1,
      "1899": 8,
      "1900": 20,
      "1901": 2,
      "1902": 9,
      "1903": 0,
      "1904": 5,
      "1905": 1,
      "1906": 8,
      "1907": 1,
      "1908": 1,
      "1909": 9,
      "1910": 0,
      "1911": 1,
      "1912": 8,
      "1913": 12,
      "1914": 1,
      "1915": 11,
      "1916": 23,
      "1917": 1,
      "1918": 9,
      "1919": 0,
      "1920": 4,
      "1921": 1,
      "1922": 8,
      "1923": 27,
      "1924": 11,
      "1925": 3,
      "1926": 1,
      "1927": 9,
      "1928": 0,
      "1929": 8,
      "1930": 26,
      "1931": 1,
      "1932": 8,
      "1933": 24,
      "1934": 1,
      "1935": 8,
      "1936": 22,
      "1937": 1,
      "1938": 6,
      "1939": 11,
      "1940": 23,
      "1941": 1,
      "1942": 9,
      "1943": 0,
      "1944": 1,
      "1945": 6,
      "1946": 8,
      "1947": 27,
      "1948": 1,
      "1949": 7,
      "1950": 11,
      "1951": 23,
      "1952": 1,
      "1953": 9,
      "1954": 0,
      "1955": 2,
      "1956": 7,
      "1957": 11,
      "1958": 23,
      "1959": 1,
      "1960": 9,
      "1961": 0,
      "1962": 9,
      "1963": 0,
      "1964": 1,
      "1965": 8,
      "1966": 4,
      "1967": 1,
      "1968": 11,
      "1969": 3,
      "1970": 1,
      "1971": 9,
      "1972": 0,
      "1973": 2,
      "1974": 1,
      "1975": 1,
      "1976": 1,
      "1977": 8,
      "1978": 5,
      "1979": 1,
      "1980": 8,
      "1981": 8,
      "1982": 4,
      "1983": 7,
      "1984": 8,
      "1985": 15,
      "1986": 6,
      "1987": 8,
      "1988": 12,
      "1989": 10,
      "1990": 2,
      "1991": 7,
      "1992": 8,
      "1993": 29,
      "1994": 1,
      "1995": 8,
      "1996": 21,
      "1997": 1,
      "1998": 6,
      "1999": 8,
      "2000": 30,
      "2001": 7,
      "2002": 7,
      "2003": 8,
      "2004": 21,
      "2005": 6,
      "2006": 8,
      "2007": 20,
      "2008": 6,
      "2009": 8,
      "2010": 15,
      "2011": 7,
      "2012": 8,
      "2013": 17,
      "2014": 14,
      "2015": 8,
      "2016": 30,
      "2017": 7,
      "2018": 8,
      "2019": 29,
      "2020": 5,
      "2021": 7,
      "2022": 8,
      "2023": 21,
      "2024": 6,
      "2025": 8,
      "2026": 20,
      "2027": 14,
      "2028": 13,
      "2029": 10,
      "2030": 2,
      "2031": 1,
      "2032": 8,
      "2033": 7,
      "2034": 2,
      "2035": 6,
      "2036": 8,
      "2037": 21,
      "2038": 14,
      "2039": 4,
      "2040": 1,
      "2041": 10,
      "2042": 2,
      "2043": 8,
      "2044": 30,
      "2045": 11,
      "2046": 23,
      "2047": 1,
      "2048": 11,
      "2049": 25,
      "2050": 1,
      "2051": 8,
      "2052": 28,
      "2053": 3,
      "2054": 6,
      "2055": 8,
      "2056": 21,
      "2057": 6,
      "2058": 8,
      "2059": 12,
      "2060": 11,
      "2061": 10,
      "2062": 2,
      "2063": 8,
      "2064": 16,
      "2065": 8,
      "2066": 11,
      "2067": 1,
      "2068": 8,
      "2069": 16,
      "2070": 8,
      "2071": 14,
      "2072": 8,
      "2073": 30,
      "2074": 3,
      "2075": 8,
      "2076": 30,
      "2077": 10,
      "2078": 2,
      "2079": 5,
      "2080": 10,
      "2081": 2,
      "2082": 11,
      "2083": 23,
      "2084": 1,
      "2085": 11,
      "2086": 25,
      "2087": 1,
      "2088": 8,
      "2089": 28,
      "2090": 1,
      "2091": 11,
      "2092": 25,
      "2093": 1,
      "2094": 8,
      "2095": 28,
      "2096": 15,
      "2097": 1,
      "2098": 1,
      "2099": 1,
      "2100": 1,
      "2101": 1,
      "2102": 1,
      "2103": 1,
      "2104": 1,
      "2105": 1,
      "2106": 3,
      "2107": 2,
      "2108": 8,
      "2109": 30,
      "2110": 8,
      "2111": 30,
      "2112": 8,
      "2113": 30,
      "2114": 8,
      "2115": 30,
      "2116": 1,
      "2117": 6,
      "2118": 10,
      "2119": 2,
      "2120": 6,
      "2121": 2,
      "2122": 8,
      "2123": 30,
      "2124": 8,
      "2125": 30,
      "2126": 3,
      "2127": 8,
      "2128": 30,
      "2129": 8,
      "2130": 30,
      "2131": 1,
      "2132": 8,
      "2133": 6,
      "2134": 1,
      "2135": 8,
      "2136": 9,
      "2137": 4,
      "2138": 1,
      "2139": 1,
      "2140": 1,
      "2141": 10,
      "2142": 2,
      "2143": 13,
      "2144": 13,
      "2145": 10,
      "2146": 2,
      "2147": 1,
      "2148": 1,
      "2149": 1,
      "2150": 1,
      "2151": 10,
      "2152": 2,
      "2153": 4,
      "2154": 3,
      "2155": 13,
      "2156": 3,
      "2157": 3,
      "2158": 4,
      "2159": 4,
      "2160": 6,
      "2161": 8,
      "2162": 21,
      "2163": 14,
      "2164": 13,
      "2165": 10,
      "2166": 2,
      "2167": 2,
      "2168": 10,
      "2169": 2,
      "2170": 10,
      "2171": 2,
      "2172": 7,
      "2173": 6,
      "2174": 8,
      "2175": 21,
      "2176": 6,
      "2177": 8,
      "2178": 12,
      "2179": 14,
      "2180": 10,
      "2181": 2,
      "2182": 10,
      "2183": 2,
      "2184": 1,
      "2185": 7,
      "2186": 8,
      "2187": 29,
      "2188": 1,
      "2189": 11,
      "2190": 25,
      "2191": 1,
      "2192": 8,
      "2193": 31,
      "2194": 9,
      "2195": 7,
      "2196": 8,
      "2197": 21,
      "2198": 6,
      "2199": 8,
      "2200": 12,
      "2201": 14,
      "2202": 10,
      "2203": 2,
      "2204": 10,
      "2205": 2,
      "2206": 11,
      "2207": 25,
      "2208": 1,
      "2209": 8,
      "2210": 28,
      "2211": 11,
      "2212": 23,
      "2213": 1,
      "2214": 11,
      "2215": 25,
      "2216": 1,
      "2217": 8,
      "2218": 31,
      "2219": 11,
      "2220": 23,
      "2221": 1,
      "2222": 5,
      "2223": 7,
      "2224": 8,
      "2225": 29,
      "2226": 3,
      "2227": 7,
      "2228": 8,
      "2229": 21,
      "2230": 6,
      "2231": 8,
      "2232": 12,
      "2233": 11,
      "2234": 10,
      "2235": 2,
      "2236": 8,
      "2237": 14,
      "2238": 8,
      "2239": 19,
      "2240": 3,
      "2241": 6,
      "2242": 8,
      "2243": 21,
      "2244": 6,
      "2245": 8,
      "2246": 12,
      "2247": 11,
      "2248": 10,
      "2249": 2,
      "2250": 8,
      "2251": 13,
      "2252": 8,
      "2253": 18,
      "2254": 8,
      "2255": 65,
      "2256": 100,
      "2257": 109,
      "2258": 105,
      "2259": 110,
      "2260": 67,
      "2261": 97,
      "2262": 112,
      "2263": 5,
      "2264": 66,
      "2265": 111,
      "2266": 117,
      "2267": 110,
      "2268": 100,
      "2269": 7,
      "2270": 66,
      "2271": 121,
      "2272": 116,
      "2273": 101,
      "2274": 115,
      "2275": 51,
      "2276": 50,
      "2277": 4,
      "2278": 67,
      "2279": 97,
      "2280": 108,
      "2281": 108,
      "2282": 7,
      "2283": 67,
      "2284": 97,
      "2285": 108,
      "2286": 108,
      "2287": 67,
      "2288": 97,
      "2289": 112,
      "2290": 4,
      "2291": 67,
      "2292": 111,
      "2293": 105,
      "2294": 110,
      "2295": 9,
      "2296": 67,
      "2297": 111,
      "2298": 109,
      "2299": 112,
      "2300": 108,
      "2301": 101,
      "2302": 116,
      "2303": 101,
      "2304": 100,
      "2305": 10,
      "2306": 69,
      "2307": 110,
      "2308": 100,
      "2309": 112,
      "2310": 111,
      "2311": 105,
      "2312": 110,
      "2313": 116,
      "2314": 86,
      "2315": 50,
      "2316": 6,
      "2317": 70,
      "2318": 117,
      "2319": 110,
      "2320": 100,
      "2321": 101,
      "2322": 100,
      "2323": 2,
      "2324": 73,
      "2325": 68,
      "2326": 14,
      "2327": 76,
      "2328": 122,
      "2329": 82,
      "2330": 101,
      "2331": 99,
      "2332": 101,
      "2333": 105,
      "2334": 118,
      "2335": 101,
      "2336": 80,
      "2337": 97,
      "2338": 114,
      "2339": 97,
      "2340": 109,
      "2341": 16,
      "2342": 77,
      "2343": 101,
      "2344": 115,
      "2345": 115,
      "2346": 97,
      "2347": 103,
      "2348": 105,
      "2349": 110,
      "2350": 103,
      "2351": 67,
      "2352": 104,
      "2353": 97,
      "2354": 110,
      "2355": 110,
      "2356": 101,
      "2357": 108,
      "2358": 12,
      "2359": 77,
      "2360": 101,
      "2361": 115,
      "2362": 115,
      "2363": 97,
      "2364": 103,
      "2365": 105,
      "2366": 110,
      "2367": 103,
      "2368": 70,
      "2369": 101,
      "2370": 101,
      "2371": 16,
      "2372": 77,
      "2373": 101,
      "2374": 115,
      "2375": 115,
      "2376": 97,
      "2377": 103,
      "2378": 105,
      "2379": 110,
      "2380": 103,
      "2381": 82,
      "2382": 101,
      "2383": 99,
      "2384": 101,
      "2385": 105,
      "2386": 112,
      "2387": 116,
      "2388": 4,
      "2389": 79,
      "2390": 65,
      "2391": 112,
      "2392": 112,
      "2393": 6,
      "2394": 79,
      "2395": 112,
      "2396": 116,
      "2397": 105,
      "2398": 111,
      "2399": 110,
      "2400": 12,
      "2401": 80,
      "2402": 97,
      "2403": 117,
      "2404": 115,
      "2405": 101,
      "2406": 67,
      "2407": 104,
      "2408": 97,
      "2409": 110,
      "2410": 103,
      "2411": 101,
      "2412": 100,
      "2413": 10,
      "2414": 81,
      "2415": 117,
      "2416": 111,
      "2417": 116,
      "2418": 101,
      "2419": 80,
      "2420": 97,
      "2421": 114,
      "2422": 97,
      "2423": 109,
      "2424": 8,
      "2425": 82,
      "2426": 101,
      "2427": 103,
      "2428": 105,
      "2429": 115,
      "2430": 116,
      "2431": 114,
      "2432": 121,
      "2433": 8,
      "2434": 82,
      "2435": 101,
      "2436": 108,
      "2437": 101,
      "2438": 97,
      "2439": 115,
      "2440": 101,
      "2441": 100,
      "2442": 3,
      "2443": 83,
      "2444": 85,
      "2445": 73,
      "2446": 9,
      "2447": 83,
      "2448": 101,
      "2449": 110,
      "2450": 100,
      "2451": 80,
      "2452": 97,
      "2453": 114,
      "2454": 97,
      "2455": 109,
      "2456": 11,
      "2457": 83,
      "2458": 108,
      "2459": 111,
      "2460": 116,
      "2461": 67,
      "2462": 114,
      "2463": 101,
      "2464": 97,
      "2465": 116,
      "2466": 101,
      "2467": 100,
      "2468": 6,
      "2469": 83,
      "2470": 116,
      "2471": 114,
      "2472": 105,
      "2473": 110,
      "2474": 103,
      "2475": 9,
      "2476": 84,
      "2477": 120,
      "2478": 67,
      "2479": 111,
      "2480": 110,
      "2481": 116,
      "2482": 101,
      "2483": 120,
      "2484": 116,
      "2485": 8,
      "2486": 84,
      "2487": 121,
      "2488": 112,
      "2489": 101,
      "2490": 78,
      "2491": 97,
      "2492": 109,
      "2493": 101,
      "2494": 3,
      "2495": 85,
      "2496": 73,
      "2497": 68,
      "2498": 5,
      "2499": 86,
      "2500": 65,
      "2501": 85,
      "2502": 76,
      "2503": 84,
      "2504": 5,
      "2505": 86,
      "2506": 97,
      "2507": 117,
      "2508": 108,
      "2509": 116,
      "2510": 4,
      "2511": 86,
      "2512": 111,
      "2513": 105,
      "2514": 100,
      "2515": 3,
      "2516": 90,
      "2517": 82,
      "2518": 79,
      "2519": 8,
      "2520": 97,
      "2521": 99,
      "2522": 107,
      "2523": 95,
      "2524": 115,
      "2525": 101,
      "2526": 110,
      "2527": 116,
      "2528": 7,
      "2529": 97,
      "2530": 100,
      "2531": 97,
      "2532": 112,
      "2533": 116,
      "2534": 101,
      "2535": 114,
      "2536": 9,
      "2537": 97,
      "2538": 108,
      "2539": 108,
      "2540": 111,
      "2541": 99,
      "2542": 97,
      "2543": 116,
      "2544": 101,
      "2545": 100,
      "2546": 9,
      "2547": 97,
      "2548": 110,
      "2549": 110,
      "2550": 111,
      "2551": 117,
      "2552": 110,
      "2553": 99,
      "2554": 101,
      "2555": 100,
      "2556": 5,
      "2557": 97,
      "2558": 115,
      "2559": 99,
      "2560": 105,
      "2561": 105,
      "2562": 7,
      "2563": 98,
      "2564": 97,
      "2565": 99,
      "2566": 107,
      "2567": 105,
      "2568": 110,
      "2569": 103,
      "2570": 4,
      "2571": 98,
      "2572": 105,
      "2573": 110,
      "2574": 100,
      "2575": 5,
      "2576": 98,
      "2577": 111,
      "2578": 117,
      "2579": 110,
      "2580": 100,
      "2581": 7,
      "2582": 98,
      "2583": 121,
      "2584": 116,
      "2585": 101,
      "2586": 115,
      "2587": 51,
      "2588": 50,
      "2589": 4,
      "2590": 99,
      "2591": 97,
      "2592": 108,
      "2593": 108,
      "2594": 8,
      "2595": 99,
      "2596": 97,
      "2597": 108,
      "2598": 108,
      "2599": 95,
      "2600": 99,
      "2601": 97,
      "2602": 112,
      "2603": 3,
      "2604": 99,
      "2605": 97,
      "2606": 112,
      "2607": 5,
      "2608": 99,
      "2609": 111,
      "2610": 100,
      "2611": 101,
      "2612": 99,
      "2613": 4,
      "2614": 99,
      "2615": 111,
      "2616": 105,
      "2617": 110,
      "2618": 15,
      "2619": 99,
      "2620": 111,
      "2621": 109,
      "2622": 98,
      "2623": 105,
      "2624": 110,
      "2625": 101,
      "2626": 95,
      "2627": 111,
      "2628": 112,
      "2629": 116,
      "2630": 105,
      "2631": 111,
      "2632": 110,
      "2633": 115,
      "2634": 15,
      "2635": 99,
      "2636": 111,
      "2637": 110,
      "2638": 102,
      "2639": 105,
      "2640": 114,
      "2641": 109,
      "2642": 95,
      "2643": 108,
      "2644": 122,
      "2645": 95,
      "2646": 115,
      "2647": 101,
      "2648": 110,
      "2649": 100,
      "2650": 13,
      "2651": 99,
      "2652": 111,
      "2653": 110,
      "2654": 102,
      "2655": 105,
      "2656": 114,
      "2657": 109,
      "2658": 95,
      "2659": 113,
      "2660": 117,
      "2661": 111,
      "2662": 116,
      "2663": 101,
      "2664": 12,
      "2665": 99,
      "2666": 111,
      "2667": 110,
      "2668": 102,
      "2669": 105,
      "2670": 114,
      "2671": 109,
      "2672": 95,
      "2673": 115,
      "2674": 101,
      "2675": 110,
      "2676": 100,
      "2677": 11,
      "2678": 99,
      "2679": 114,
      "2680": 101,
      "2681": 97,
      "2682": 116,
      "2683": 101,
      "2684": 95,
      "2685": 115,
      "2686": 108,
      "2687": 111,
      "2688": 116,
      "2689": 6,
      "2690": 100,
      "2691": 101,
      "2692": 99,
      "2693": 111,
      "2694": 100,
      "2695": 101,
      "2696": 11,
      "2697": 100,
      "2698": 101,
      "2699": 115,
      "2700": 116,
      "2701": 105,
      "2702": 110,
      "2703": 97,
      "2704": 116,
      "2705": 105,
      "2706": 111,
      "2707": 110,
      "2708": 7,
      "2709": 100,
      "2710": 101,
      "2711": 115,
      "2712": 116,
      "2713": 114,
      "2714": 111,
      "2715": 121,
      "2716": 12,
      "2717": 100,
      "2718": 101,
      "2719": 115,
      "2720": 116,
      "2721": 114,
      "2722": 111,
      "2723": 121,
      "2724": 95,
      "2725": 110,
      "2726": 111,
      "2727": 110,
      "2728": 101,
      "2729": 11,
      "2730": 100,
      "2731": 117,
      "2732": 109,
      "2733": 109,
      "2734": 121,
      "2735": 95,
      "2736": 102,
      "2737": 105,
      "2738": 101,
      "2739": 108,
      "2740": 100,
      "2741": 4,
      "2742": 101,
      "2743": 109,
      "2744": 105,
      "2745": 116,
      "2746": 6,
      "2747": 101,
      "2748": 110,
      "2749": 99,
      "2750": 111,
      "2751": 100,
      "2752": 101,
      "2753": 14,
      "2754": 101,
      "2755": 110,
      "2756": 100,
      "2757": 112,
      "2758": 111,
      "2759": 105,
      "2760": 110,
      "2761": 116,
      "2762": 95,
      "2763": 113,
      "2764": 117,
      "2765": 111,
      "2766": 116,
      "2767": 101,
      "2768": 13,
      "2769": 101,
      "2770": 110,
      "2771": 100,
      "2772": 112,
      "2773": 111,
      "2774": 105,
      "2775": 110,
      "2776": 116,
      "2777": 95,
      "2778": 115,
      "2779": 101,
      "2780": 110,
      "2781": 100,
      "2782": 11,
      "2783": 101,
      "2784": 110,
      "2785": 100,
      "2786": 112,
      "2787": 111,
      "2788": 105,
      "2789": 110,
      "2790": 116,
      "2791": 95,
      "2792": 118,
      "2793": 50,
      "2794": 5,
      "2795": 101,
      "2796": 118,
      "2797": 101,
      "2798": 110,
      "2799": 116,
      "2800": 17,
      "2801": 101,
      "2802": 120,
      "2803": 101,
      "2804": 99,
      "2805": 117,
      "2806": 116,
      "2807": 105,
      "2808": 111,
      "2809": 110,
      "2810": 95,
      "2811": 111,
      "2812": 112,
      "2813": 116,
      "2814": 105,
      "2815": 111,
      "2816": 110,
      "2817": 115,
      "2818": 7,
      "2819": 101,
      "2820": 120,
      "2821": 116,
      "2822": 114,
      "2823": 97,
      "2824": 99,
      "2825": 116,
      "2826": 4,
      "2827": 102,
      "2828": 105,
      "2829": 108,
      "2830": 108,
      "2831": 12,
      "2832": 102,
      "2833": 114,
      "2834": 111,
      "2835": 109,
      "2836": 95,
      "2837": 97,
      "2838": 100,
      "2839": 100,
      "2840": 114,
      "2841": 101,
      "2842": 115,
      "2843": 115,
      "2844": 7,
      "2845": 102,
      "2846": 114,
      "2847": 111,
      "2848": 109,
      "2849": 95,
      "2850": 105,
      "2851": 100,
      "2852": 4,
      "2853": 102,
      "2854": 117,
      "2855": 110,
      "2856": 100,
      "2857": 10,
      "2858": 103,
      "2859": 101,
      "2860": 110,
      "2861": 101,
      "2862": 114,
      "2863": 97,
      "2864": 116,
      "2865": 105,
      "2866": 111,
      "2867": 110,
      "2868": 8,
      "2869": 103,
      "2870": 101,
      "2871": 116,
      "2872": 95,
      "2873": 112,
      "2874": 101,
      "2875": 101,
      "2876": 114,
      "2877": 4,
      "2878": 104,
      "2879": 101,
      "2880": 108,
      "2881": 100,
      "2882": 2,
      "2883": 105,
      "2884": 100,
      "2885": 10,
      "2886": 105,
      "2887": 100,
      "2888": 95,
      "2889": 97,
      "2890": 100,
      "2891": 100,
      "2892": 114,
      "2893": 101,
      "2894": 115,
      "2895": 115,
      "2896": 4,
      "2897": 105,
      "2898": 110,
      "2899": 105,
      "2900": 116,
      "2901": 10,
      "2902": 105,
      "2903": 110,
      "2904": 116,
      "2905": 111,
      "2906": 95,
      "2907": 98,
      "2908": 121,
      "2909": 116,
      "2910": 101,
      "2911": 115,
      "2912": 11,
      "2913": 105,
      "2914": 110,
      "2915": 116,
      "2916": 111,
      "2917": 95,
      "2918": 115,
      "2919": 116,
      "2920": 114,
      "2921": 105,
      "2922": 110,
      "2923": 103,
      "2924": 7,
      "2925": 105,
      "2926": 115,
      "2927": 95,
      "2928": 110,
      "2929": 111,
      "2930": 110,
      "2931": 101,
      "2932": 7,
      "2933": 105,
      "2934": 115,
      "2935": 95,
      "2936": 115,
      "2937": 111,
      "2938": 109,
      "2939": 101,
      "2940": 7,
      "2941": 105,
      "2942": 115,
      "2943": 95,
      "2944": 122,
      "2945": 101,
      "2946": 114,
      "2947": 111,
      "2948": 10,
      "2949": 108,
      "2950": 122,
      "2951": 95,
      "2952": 114,
      "2953": 101,
      "2954": 99,
      "2955": 101,
      "2956": 105,
      "2957": 118,
      "2958": 101,
      "2959": 7,
      "2960": 108,
      "2961": 122,
      "2962": 95,
      "2963": 115,
      "2964": 101,
      "2965": 110,
      "2966": 100,
      "2967": 17,
      "2968": 109,
      "2969": 101,
      "2970": 115,
      "2971": 115,
      "2972": 97,
      "2973": 103,
      "2974": 105,
      "2975": 110,
      "2976": 103,
      "2977": 95,
      "2978": 99,
      "2979": 104,
      "2980": 97,
      "2981": 110,
      "2982": 110,
      "2983": 101,
      "2984": 108,
      "2985": 13,
      "2986": 109,
      "2987": 101,
      "2988": 115,
      "2989": 115,
      "2990": 97,
      "2991": 103,
      "2992": 105,
      "2993": 110,
      "2994": 103,
      "2995": 95,
      "2996": 102,
      "2997": 101,
      "2998": 101,
      "2999": 17,
      "3000": 109,
      "3001": 101,
      "3002": 115,
      "3003": 115,
      "3004": 97,
      "3005": 103,
      "3006": 105,
      "3007": 110,
      "3008": 103,
      "3009": 95,
      "3010": 114,
      "3011": 101,
      "3012": 99,
      "3013": 101,
      "3014": 105,
      "3015": 112,
      "3016": 116,
      "3017": 3,
      "3018": 110,
      "3019": 101,
      "3020": 119,
      "3021": 12,
      "3022": 110,
      "3023": 101,
      "3024": 119,
      "3025": 95,
      "3026": 114,
      "3027": 101,
      "3028": 103,
      "3029": 105,
      "3030": 115,
      "3031": 116,
      "3032": 114,
      "3033": 121,
      "3034": 3,
      "3035": 110,
      "3036": 102,
      "3037": 116,
      "3038": 8,
      "3039": 110,
      "3040": 102,
      "3041": 116,
      "3042": 95,
      "3043": 116,
      "3044": 121,
      "3045": 112,
      "3046": 101,
      "3047": 4,
      "3048": 110,
      "3049": 111,
      "3050": 110,
      "3051": 101,
      "3052": 4,
      "3053": 111,
      "3054": 97,
      "3055": 112,
      "3056": 112,
      "3057": 6,
      "3058": 111,
      "3059": 98,
      "3060": 106,
      "3061": 101,
      "3062": 99,
      "3063": 116,
      "3064": 6,
      "3065": 111,
      "3066": 112,
      "3067": 116,
      "3068": 105,
      "3069": 111,
      "3070": 110,
      "3071": 6,
      "3072": 112,
      "3073": 97,
      "3074": 117,
      "3075": 115,
      "3076": 101,
      "3077": 100,
      "3078": 7,
      "3079": 112,
      "3080": 97,
      "3081": 121,
      "3082": 108,
      "3083": 111,
      "3084": 97,
      "3085": 100,
      "3086": 18,
      "3087": 112,
      "3088": 97,
      "3089": 121,
      "3090": 108,
      "3091": 111,
      "3092": 97,
      "3093": 100,
      "3094": 95,
      "3095": 102,
      "3096": 111,
      "3097": 114,
      "3098": 95,
      "3099": 114,
      "3100": 101,
      "3101": 118,
      "3102": 105,
      "3103": 101,
      "3104": 119,
      "3105": 4,
      "3106": 112,
      "3107": 101,
      "3108": 101,
      "3109": 114,
      "3110": 5,
      "3111": 112,
      "3112": 104,
      "3113": 97,
      "3114": 115,
      "3115": 101,
      "3116": 7,
      "3117": 112,
      "3118": 114,
      "3119": 111,
      "3120": 99,
      "3121": 101,
      "3122": 115,
      "3123": 115,
      "3124": 15,
      "3125": 112,
      "3126": 117,
      "3127": 98,
      "3128": 108,
      "3129": 105,
      "3130": 99,
      "3131": 95,
      "3132": 116,
      "3133": 114,
      "3134": 97,
      "3135": 110,
      "3136": 115,
      "3137": 102,
      "3138": 101,
      "3139": 114,
      "3140": 5,
      "3141": 113,
      "3142": 117,
      "3143": 111,
      "3144": 116,
      "3145": 101,
      "3146": 9,
      "3147": 114,
      "3148": 101,
      "3149": 99,
      "3150": 105,
      "3151": 112,
      "3152": 105,
      "3153": 101,
      "3154": 110,
      "3155": 116,
      "3156": 8,
      "3157": 114,
      "3158": 101,
      "3159": 103,
      "3160": 105,
      "3161": 115,
      "3162": 116,
      "3163": 101,
      "3164": 114,
      "3165": 13,
      "3166": 114,
      "3167": 101,
      "3168": 103,
      "3169": 105,
      "3170": 115,
      "3171": 116,
      "3172": 101,
      "3173": 114,
      "3174": 95,
      "3175": 111,
      "3176": 97,
      "3177": 112,
      "3178": 112,
      "3179": 8,
      "3180": 114,
      "3181": 101,
      "3182": 103,
      "3183": 105,
      "3184": 115,
      "3185": 116,
      "3186": 114,
      "3187": 121,
      "3188": 14,
      "3189": 114,
      "3190": 101,
      "3191": 103,
      "3192": 105,
      "3193": 115,
      "3194": 116,
      "3195": 114,
      "3196": 121,
      "3197": 95,
      "3198": 97,
      "3199": 100,
      "3200": 109,
      "3201": 105,
      "3202": 110,
      "3203": 11,
      "3204": 114,
      "3205": 101,
      "3206": 103,
      "3207": 105,
      "3208": 115,
      "3209": 116,
      "3210": 114,
      "3211": 121,
      "3212": 95,
      "3213": 105,
      "3214": 100,
      "3215": 7,
      "3216": 114,
      "3217": 101,
      "3218": 113,
      "3219": 117,
      "3220": 101,
      "3221": 115,
      "3222": 116,
      "3223": 5,
      "3224": 114,
      "3225": 111,
      "3226": 117,
      "3227": 116,
      "3228": 101,
      "3229": 4,
      "3230": 115,
      "3231": 101,
      "3232": 110,
      "3233": 100,
      "3234": 6,
      "3235": 115,
      "3236": 101,
      "3237": 110,
      "3238": 100,
      "3239": 101,
      "3240": 114,
      "3241": 20,
      "3242": 115,
      "3243": 101,
      "3244": 116,
      "3245": 95,
      "3246": 101,
      "3247": 110,
      "3248": 102,
      "3249": 111,
      "3250": 114,
      "3251": 99,
      "3252": 101,
      "3253": 100,
      "3254": 95,
      "3255": 111,
      "3256": 112,
      "3257": 116,
      "3258": 105,
      "3259": 111,
      "3260": 110,
      "3261": 115,
      "3262": 10,
      "3263": 115,
      "3264": 101,
      "3265": 116,
      "3266": 95,
      "3267": 112,
      "3268": 97,
      "3269": 117,
      "3270": 115,
      "3271": 101,
      "3272": 100,
      "3273": 8,
      "3274": 115,
      "3275": 101,
      "3276": 116,
      "3277": 95,
      "3278": 112,
      "3279": 101,
      "3280": 101,
      "3281": 114,
      "3282": 12,
      "3283": 115,
      "3284": 104,
      "3285": 97,
      "3286": 114,
      "3287": 101,
      "3288": 95,
      "3289": 111,
      "3290": 98,
      "3291": 106,
      "3292": 101,
      "3293": 99,
      "3294": 116,
      "3295": 4,
      "3296": 115,
      "3297": 108,
      "3298": 111,
      "3299": 116,
      "3300": 4,
      "3301": 115,
      "3302": 111,
      "3303": 109,
      "3304": 101,
      "3305": 3,
      "3306": 115,
      "3307": 117,
      "3308": 105,
      "3309": 10,
      "3310": 116,
      "3311": 111,
      "3312": 95,
      "3313": 97,
      "3314": 100,
      "3315": 100,
      "3316": 114,
      "3317": 101,
      "3318": 115,
      "3319": 115,
      "3320": 8,
      "3321": 116,
      "3322": 114,
      "3323": 97,
      "3324": 110,
      "3325": 115,
      "3326": 102,
      "3327": 101,
      "3328": 114,
      "3329": 10,
      "3330": 116,
      "3331": 120,
      "3332": 95,
      "3333": 99,
      "3334": 111,
      "3335": 110,
      "3336": 116,
      "3337": 101,
      "3338": 120,
      "3339": 116,
      "3340": 9,
      "3341": 116,
      "3342": 121,
      "3343": 112,
      "3344": 101,
      "3345": 95,
      "3346": 110,
      "3347": 97,
      "3348": 109,
      "3349": 101,
      "3350": 12,
      "3351": 117,
      "3352": 105,
      "3353": 100,
      "3354": 95,
      "3355": 116,
      "3356": 111,
      "3357": 95,
      "3358": 105,
      "3359": 110,
      "3360": 110,
      "3361": 101,
      "3362": 114,
      "3363": 8,
      "3364": 118,
      "3365": 97,
      "3366": 108,
      "3367": 105,
      "3368": 100,
      "3369": 97,
      "3370": 116,
      "3371": 101,
      "3372": 5,
      "3373": 118,
      "3374": 97,
      "3375": 117,
      "3376": 108,
      "3377": 116,
      "3378": 11,
      "3379": 118,
      "3380": 97,
      "3381": 117,
      "3382": 108,
      "3383": 116,
      "3384": 95,
      "3385": 97,
      "3386": 100,
      "3387": 109,
      "3388": 105,
      "3389": 110,
      "3390": 7,
      "3391": 118,
      "3392": 101,
      "3393": 114,
      "3394": 115,
      "3395": 105,
      "3396": 111,
      "3397": 110,
      "3398": 17,
      "3399": 119,
      "3400": 105,
      "3401": 116,
      "3402": 104,
      "3403": 95,
      "3404": 111,
      "3405": 114,
      "3406": 105,
      "3407": 103,
      "3408": 105,
      "3409": 110,
      "3410": 97,
      "3411": 108,
      "3412": 95,
      "3413": 105,
      "3414": 100,
      "3415": 115,
      "3416": 12,
      "3417": 122,
      "3418": 101,
      "3419": 114,
      "3420": 111,
      "3421": 95,
      "3422": 98,
      "3423": 121,
      "3424": 116,
      "3425": 101,
      "3426": 115,
      "3427": 51,
      "3428": 50,
      "3429": 3,
      "3430": 122,
      "3431": 114,
      "3432": 111,
      "3433": 0,
      "3434": 0,
      "3435": 0,
      "3436": 0,
      "3437": 0,
      "3438": 0,
      "3439": 0,
      "3440": 0,
      "3441": 0,
      "3442": 0,
      "3443": 0,
      "3444": 0,
      "3445": 0,
      "3446": 0,
      "3447": 0,
      "3448": 0,
      "3449": 0,
      "3450": 0,
      "3451": 0,
      "3452": 0,
      "3453": 0,
      "3454": 0,
      "3455": 0,
      "3456": 0,
      "3457": 0,
      "3458": 0,
      "3459": 0,
      "3460": 0,
      "3461": 0,
      "3462": 0,
      "3463": 0,
      "3464": 0,
      "3465": 0,
      "3466": 0,
      "3467": 0,
      "3468": 0,
      "3469": 0,
      "3470": 0,
      "3471": 0,
      "3472": 0,
      "3473": 0,
      "3474": 0,
      "3475": 0,
      "3476": 0,
      "3477": 0,
      "3478": 0,
      "3479": 0,
      "3480": 0,
      "3481": 0,
      "3482": 0,
      "3483": 0,
      "3484": 0,
      "3485": 0,
      "3486": 0,
      "3487": 0,
      "3488": 0,
      "3489": 0,
      "3490": 0,
      "3491": 0,
      "3492": 0,
      "3493": 0,
      "3494": 0,
      "3495": 0,
      "3496": 1,
      "3497": 0,
      "3498": 0,
      "3499": 0,
      "3500": 0,
      "3501": 0,
      "3502": 0,
      "3503": 0,
      "3504": 0,
      "3505": 0,
      "3506": 0,
      "3507": 0,
      "3508": 0,
      "3509": 0,
      "3510": 0,
      "3511": 0,
      "3512": 0,
      "3513": 0,
      "3514": 0,
      "3515": 0,
      "3516": 0,
      "3517": 0,
      "3518": 0,
      "3519": 0,
      "3520": 0,
      "3521": 0,
      "3522": 0,
      "3523": 0,
      "3524": 0,
      "3525": 0,
      "3526": 0,
      "3527": 0,
      "3528": 2,
      "3529": 0,
      "3530": 36,
      "3531": 91,
      "3532": 163,
      "3533": 111,
      "3534": 122,
      "3535": 28,
      "3536": 198,
      "3537": 67,
      "3538": 162,
      "3539": 176,
      "3540": 55,
      "3541": 69,
      "3542": 13,
      "3543": 255,
      "3544": 30,
      "3545": 67,
      "3546": 153,
      "3547": 225,
      "3548": 128,
      "3549": 105,
      "3550": 198,
      "3551": 84,
      "3552": 95,
      "3553": 181,
      "3554": 252,
      "3555": 170,
      "3556": 243,
      "3557": 125,
      "3558": 57,
      "3559": 215,
      "3560": 220,
      "3561": 40,
      "3562": 222,
      "3563": 158,
      "3564": 142,
      "3565": 8,
      "3566": 122,
      "3567": 99,
      "3568": 71,
      "3569": 0,
      "3570": 25,
      "3571": 7,
      "3572": 251,
      "3573": 105,
      "3574": 143,
      "3575": 223,
      "3576": 138,
      "3577": 176,
      "3578": 70,
      "3579": 123,
      "3580": 52,
      "3581": 34,
      "3582": 41,
      "3583": 183,
      "3584": 75,
      "3585": 25,
      "3586": 38,
      "3587": 64,
      "3588": 103,
      "3589": 174,
      "3590": 188,
      "3591": 74,
      "3592": 233,
      "3593": 49,
      "3594": 190,
      "3595": 174,
      "3596": 248,
      "3597": 137,
      "3598": 176,
      "3599": 139,
      "3600": 156,
      "3601": 59,
      "3602": 55,
      "3603": 209,
      "3604": 146,
      "3605": 128,
      "3606": 252,
      "3607": 31,
      "3608": 139,
      "3609": 117,
      "3610": 186,
      "3611": 229,
      "3612": 178,
      "3613": 222,
      "3614": 36,
      "3615": 16,
      "3616": 252,
      "3617": 49,
      "3618": 32,
      "3619": 244,
      "3620": 3,
      "3621": 233,
      "3622": 163,
      "3623": 109,
      "3624": 172,
      "3625": 61,
      "3626": 225,
      "3627": 80,
      "3628": 76,
      "3629": 243,
      "3630": 253,
      "3631": 117,
      "3632": 118,
      "3633": 39,
      "3634": 89,
      "3635": 227,
      "3636": 83,
      "3637": 217,
      "3638": 217,
      "3639": 83,
      "3640": 137,
      "3641": 97,
      "3642": 142,
      "3643": 85,
      "3644": 125,
      "3645": 5,
      "3646": 82,
      "3647": 105,
      "3648": 127,
      "3649": 25,
      "3650": 181,
      "3651": 46,
      "3652": 78,
      "3653": 146,
      "3654": 124,
      "3655": 29,
      "3656": 238,
      "3657": 253,
      "3658": 194,
      "3659": 138,
      "3660": 252,
      "3661": 1,
      "3662": 16,
      "3663": 203,
      "3664": 46,
      "3665": 219,
      "3666": 148,
      "3667": 227,
      "3668": 229,
      "3669": 127,
      "3670": 43,
      "3671": 28,
      "3672": 230,
      "3673": 155,
      "3674": 90,
      "3675": 153,
      "3676": 197,
      "3677": 3,
      "3678": 176,
      "3679": 109,
      "3680": 21,
      "3681": 229,
      "3682": 28,
      "3683": 250,
      "3684": 33,
      "3685": 45,
      "3686": 229,
      "3687": 110,
      "3688": 36,
      "3689": 3,
      "3690": 8,
      "3691": 1,
      "3692": 0,
      "3693": 0,
      "3694": 0,
      "3695": 0,
      "3696": 0,
      "3697": 0,
      "3698": 0,
      "3699": 14,
      "3700": 4,
      "3701": 150,
      "3702": 117,
      "3703": 0,
      "3704": 0,
      "3705": 5,
      "3706": 32,
      "3707": 4,
      "3708": 109,
      "3709": 162,
      "3710": 169,
      "3711": 225,
      "3712": 91,
      "3713": 216,
      "3714": 34,
      "3715": 186,
      "3716": 4,
      "3717": 145,
      "3718": 217,
      "3719": 120,
      "3720": 148,
      "3721": 124,
      "3722": 193,
      "3723": 191,
      "3724": 177,
      "3725": 253,
      "3726": 48,
      "3727": 230,
      "3728": 248,
      "3729": 19,
      "3730": 165,
      "3731": 251,
      "3732": 16,
      "3733": 185,
      "3734": 178,
      "3735": 177,
      "3736": 214,
      "3737": 166,
      "3738": 186,
      "3739": 5,
      "3740": 32,
      "3741": 72,
      "3742": 89,
      "3743": 83,
      "3744": 226,
      "3745": 234,
      "3746": 223,
      "3747": 74,
      "3748": 160,
      "3749": 42,
      "3750": 249,
      "3751": 80,
      "3752": 207,
      "3753": 142,
      "3754": 145,
      "3755": 79,
      "3756": 189,
      "3757": 43,
      "3758": 103,
      "3759": 82,
      "3760": 51,
      "3761": 133,
      "3762": 231,
      "3763": 60,
      "3764": 54,
      "3765": 17,
      "3766": 131,
      "3767": 65,
      "3768": 69,
      "3769": 157,
      "3770": 141,
      "3771": 69,
      "3772": 196,
      "3773": 10,
      "3774": 2,
      "3775": 82,
      "3776": 81,
      "3777": 102,
      "3778": 54,
      "3779": 99,
      "3780": 54,
      "3781": 100,
      "3782": 52,
      "3783": 51,
      "3784": 57,
      "3785": 101,
      "3786": 97,
      "3787": 48,
      "3788": 100,
      "3789": 97,
      "3790": 50,
      "3791": 102,
      "3792": 51,
      "3793": 101,
      "3794": 57,
      "3795": 98,
      "3796": 97,
      "3797": 55,
      "3798": 57,
      "3799": 101,
      "3800": 52,
      "3801": 57,
      "3802": 57,
      "3803": 50,
      "3804": 97,
      "3805": 55,
      "3806": 97,
      "3807": 52,
      "3808": 99,
      "3809": 49,
      "3810": 49,
      "3811": 51,
      "3812": 50,
      "3813": 49,
      "3814": 53,
      "3815": 102,
      "3816": 98,
      "3817": 102,
      "3818": 53,
      "3819": 52,
      "3820": 99,
      "3821": 52,
      "3822": 52,
      "3823": 50,
      "3824": 97,
      "3825": 99,
      "3826": 57,
      "3827": 48,
      "3828": 50,
      "3829": 48,
      "3830": 99,
      "3831": 51,
      "3832": 49,
      "3833": 53,
      "3834": 102,
      "3835": 57,
      "3836": 53,
      "3837": 51,
      "3838": 55,
      "3839": 48,
      "3840": 53,
      "3841": 58,
      "3842": 58,
      "3843": 99,
      "3844": 111,
      "3845": 108,
      "3846": 108,
      "3847": 101,
      "3848": 99,
      "3849": 116,
      "3850": 105,
      "3851": 111,
      "3852": 110,
      "3853": 58,
      "3854": 58,
      "3855": 78,
      "3856": 70,
      "3857": 84,
      "3858": 3,
      "3859": 8,
      "3860": 2,
      "3861": 0,
      "3862": 0,
      "3863": 0,
      "3864": 0,
      "3865": 0,
      "3866": 0,
      "3867": 0,
      "3868": 3,
      "3869": 8,
      "3870": 3,
      "3871": 0,
      "3872": 0,
      "3873": 0,
      "3874": 0,
      "3875": 0,
      "3876": 0,
      "3877": 0,
      "3878": 3,
      "3879": 8,
      "3880": 4,
      "3881": 0,
      "3882": 0,
      "3883": 0,
      "3884": 0,
      "3885": 0,
      "3886": 0,
      "3887": 0,
      "3888": 3,
      "3889": 8,
      "3890": 5,
      "3891": 0,
      "3892": 0,
      "3893": 0,
      "3894": 0,
      "3895": 0,
      "3896": 0,
      "3897": 0,
      "3898": 3,
      "3899": 8,
      "3900": 6,
      "3901": 0,
      "3902": 0,
      "3903": 0,
      "3904": 0,
      "3905": 0,
      "3906": 0,
      "3907": 0,
      "3908": 3,
      "3909": 8,
      "3910": 7,
      "3911": 0,
      "3912": 0,
      "3913": 0,
      "3914": 0,
      "3915": 0,
      "3916": 0,
      "3917": 0,
      "3918": 3,
      "3919": 8,
      "3920": 8,
      "3921": 0,
      "3922": 0,
      "3923": 0,
      "3924": 0,
      "3925": 0,
      "3926": 0,
      "3927": 0,
      "3928": 3,
      "3929": 8,
      "3930": 9,
      "3931": 0,
      "3932": 0,
      "3933": 0,
      "3934": 0,
      "3935": 0,
      "3936": 0,
      "3937": 0,
      "3938": 3,
      "3939": 8,
      "3940": 10,
      "3941": 0,
      "3942": 0,
      "3943": 0,
      "3944": 0,
      "3945": 0,
      "3946": 0,
      "3947": 0,
      "3948": 3,
      "3949": 8,
      "3950": 11,
      "3951": 0,
      "3952": 0,
      "3953": 0,
      "3954": 0,
      "3955": 0,
      "3956": 0,
      "3957": 0,
      "3958": 3,
      "3959": 8,
      "3960": 12,
      "3961": 0,
      "3962": 0,
      "3963": 0,
      "3964": 0,
      "3965": 0,
      "3966": 0,
      "3967": 0,
      "3968": 10,
      "3969": 2,
      "3970": 23,
      "3971": 22,
      "3972": 0,
      "3973": 3,
      "3974": 1,
      "3975": 0,
      "3976": 17,
      "3977": 1,
      "3978": 0,
      "3979": 0,
      "3980": 0,
      "3981": 0,
      "3982": 0,
      "3983": 0,
      "3984": 0,
      "3985": 0,
      "3986": 0,
      "3987": 0,
      "3988": 0,
      "3989": 0,
      "3990": 0,
      "3991": 3,
      "3992": 13,
      "3993": 64,
      "3994": 10,
      "3995": 2,
      "3996": 1,
      "3997": 0,
      "3998": 0,
      "3999": 2,
      "4000": 1,
      "4001": 54,
      "4002": 1,
      "4003": 1,
      "4004": 2,
      "4005": 2,
      "4006": 70,
      "4007": 8,
      "4008": 27,
      "4009": 102,
      "4010": 8,
      "4011": 26,
      "4012": 2,
      "4013": 2,
      "4014": 7,
      "4015": 70,
      "4016": 8,
      "4017": 27,
      "4018": 124,
      "4019": 3,
      "4020": 42,
      "4021": 11,
      "4022": 23,
      "4023": 1,
      "4024": 8,
      "4025": 12,
      "4026": 88,
      "4027": 5,
      "4028": 113,
      "4029": 11,
      "4030": 23,
      "4031": 1,
      "4032": 8,
      "4033": 26,
      "4034": 36,
      "4035": 5,
      "4036": 86,
      "4037": 10,
      "4038": 2,
      "4039": 3,
      "4040": 2,
      "4041": 17,
      "4042": 70,
      "4043": 8,
      "4044": 27,
      "4045": 124,
      "4046": 3,
      "4047": 102,
      "4048": 8,
      "4049": 26,
      "4050": 42,
      "4051": 8,
      "4052": 12,
      "4053": 88,
      "4054": 5,
      "4055": 85,
      "4056": 11,
      "4057": 23,
      "4058": 1,
      "4059": 9,
      "4060": 0,
      "4061": 36,
      "4062": 8,
      "4063": 30,
      "4064": 106,
      "4065": 8,
      "4066": 30,
      "4067": 94,
      "4068": 8,
      "4069": 30,
      "4070": 38,
      "4071": 1,
      "4072": 91,
      "4073": 1,
      "4074": 95,
      "4075": 2,
      "4076": 67,
      "4077": 3,
      "4078": 34,
      "4079": 1,
      "4080": 31,
      "4081": 1,
      "4082": 105,
      "4083": 8,
      "4084": 30,
      "4085": 99,
      "4086": 8,
      "4087": 30,
      "4088": 4,
      "4089": 2,
      "4090": 3,
      "4091": 102,
      "4092": 8,
      "4093": 26,
      "4094": 122,
      "4095": 8,
      "4096": 26,
      "4097": 85,
      "4098": 8,
      "4099": 30,
      "4100": 5,
      "4101": 2,
      "4102": 5,
      "4103": 122,
      "4104": 8,
      "4105": 26,
      "4106": 85,
      "4107": 8,
      "4108": 30,
      "4109": 67,
      "4110": 3,
      "4111": 51,
      "4112": 14,
      "4113": 32,
      "4114": 8,
      "4115": 30,
      "4116": 6,
      "4117": 2,
      "4118": 3,
      "4119": 122,
      "4120": 8,
      "4121": 26,
      "4122": 67,
      "4123": 3,
      "4124": 105,
      "4125": 8,
      "4126": 30,
      "4127": 7,
      "4128": 2,
      "4129": 2,
      "4130": 122,
      "4131": 8,
      "4132": 26,
      "4133": 94,
      "4134": 8,
      "4135": 30,
      "4136": 8,
      "4137": 2,
      "4138": 2,
      "4139": 122,
      "4140": 8,
      "4141": 26,
      "4142": 91,
      "4143": 1,
      "4144": 9,
      "4145": 2,
      "4146": 4,
      "4147": 122,
      "4148": 8,
      "4149": 26,
      "4150": 67,
      "4151": 3,
      "4152": 105,
      "4153": 8,
      "4154": 30,
      "4155": 99,
      "4156": 8,
      "4157": 30,
      "4158": 3,
      "4159": 46,
      "4160": 0,
      "4161": 0,
      "4162": 0,
      "4163": 0,
      "4164": 35,
      "4165": 41,
      "4166": 10,
      "4167": 1,
      "4168": 46,
      "4169": 17,
      "4170": 61,
      "4171": 7,
      "4172": 3,
      "4173": 33,
      "4174": 4,
      "4175": 7,
      "4176": 5,
      "4177": 11,
      "4178": 11,
      "4179": 1,
      "4180": 1,
      "4181": 7,
      "4182": 0,
      "4183": 39,
      "4184": 14,
      "4185": 0,
      "4186": 10,
      "4187": 1,
      "4188": 56,
      "4189": 0,
      "4190": 12,
      "4191": 3,
      "4192": 12,
      "4193": 4,
      "4194": 11,
      "4195": 3,
      "4196": 7,
      "4197": 2,
      "4198": 7,
      "4199": 4,
      "4200": 10,
      "4201": 1,
      "4202": 17,
      "4203": 1,
      "4204": 12,
      "4205": 5,
      "4206": 10,
      "4207": 1,
      "4208": 17,
      "4209": 56,
      "4210": 14,
      "4211": 5,
      "4212": 56,
      "4213": 1,
      "4214": 18,
      "4215": 1,
      "4216": 12,
      "4217": 2,
      "4218": 11,
      "4219": 4,
      "4220": 10,
      "4221": 1,
      "4222": 46,
      "4223": 17,
      "4224": 61,
      "4225": 56,
      "4226": 2,
      "4227": 11,
      "4228": 2,
      "4229": 11,
      "4230": 1,
      "4231": 46,
      "4232": 17,
      "4233": 61,
      "4234": 56,
      "4235": 3,
      "4236": 11,
      "4237": 5,
      "4238": 56,
      "4239": 4,
      "4240": 2,
      "4241": 0,
      "4242": 1,
      "4243": 0,
      "4244": 0,
      "4245": 0,
      "4246": 1,
      "4247": 11,
      "4248": 11,
      "4249": 4,
      "4250": 17,
      "4251": 56,
      "4252": 7,
      "4253": 0,
      "4254": 11,
      "4255": 0,
      "4256": 56,
      "4257": 5,
      "4258": 11,
      "4259": 1,
      "4260": 56,
      "4261": 6,
      "4262": 11,
      "4263": 2,
      "4264": 11,
      "4265": 3,
      "4266": 18,
      "4267": 2,
      "4268": 2,
      "4269": 0,
      "4270": 2,
      "4271": 0,
      "4272": 0,
      "4273": 0,
      "4274": 1,
      "4275": 24,
      "4276": 10,
      "4277": 0,
      "4278": 16,
      "4279": 0,
      "4280": 20,
      "4281": 7,
      "4282": 0,
      "4283": 33,
      "4284": 4,
      "4285": 7,
      "4286": 5,
      "4287": 13,
      "4288": 11,
      "4289": 0,
      "4290": 1,
      "4291": 11,
      "4292": 1,
      "4293": 1,
      "4294": 7,
      "4295": 14,
      "4296": 39,
      "4297": 11,
      "4298": 1,
      "4299": 16,
      "4300": 1,
      "4301": 20,
      "4302": 11,
      "4303": 0,
      "4304": 56,
      "4305": 1,
      "4306": 33,
      "4307": 4,
      "4308": 21,
      "4309": 5,
      "4310": 23,
      "4311": 7,
      "4312": 0,
      "4313": 39,
      "4314": 2,
      "4315": 0,
      "4316": 3,
      "4317": 0,
      "4318": 0,
      "4319": 0,
      "4320": 1,
      "4321": 25,
      "4322": 10,
      "4323": 0,
      "4324": 55,
      "4325": 0,
      "4326": 20,
      "4327": 7,
      "4328": 0,
      "4329": 33,
      "4330": 4,
      "4331": 7,
      "4332": 5,
      "4333": 13,
      "4334": 11,
      "4335": 0,
      "4336": 1,
      "4337": 11,
      "4338": 1,
      "4339": 1,
      "4340": 7,
      "4341": 14,
      "4342": 39,
      "4343": 11,
      "4344": 1,
      "4345": 16,
      "4346": 1,
      "4347": 20,
      "4348": 11,
      "4349": 0,
      "4350": 55,
      "4351": 1,
      "4352": 20,
      "4353": 33,
      "4354": 4,
      "4355": 22,
      "4356": 5,
      "4357": 24,
      "4358": 7,
      "4359": 0,
      "4360": 39,
      "4361": 2,
      "4362": 0,
      "4363": 4,
      "4364": 1,
      "4365": 0,
      "4366": 0,
      "4367": 49,
      "4368": 90,
      "4369": 10,
      "4370": 0,
      "4371": 46,
      "4372": 11,
      "4373": 1,
      "4374": 17,
      "4375": 2,
      "4376": 56,
      "4377": 7,
      "4378": 17,
      "4379": 51,
      "4380": 17,
      "4381": 43,
      "4382": 10,
      "4383": 0,
      "4384": 16,
      "4385": 4,
      "4386": 20,
      "4387": 33,
      "4388": 4,
      "4389": 13,
      "4390": 5,
      "4391": 19,
      "4392": 11,
      "4393": 0,
      "4394": 1,
      "4395": 11,
      "4396": 2,
      "4397": 1,
      "4398": 7,
      "4399": 5,
      "4400": 39,
      "4401": 10,
      "4402": 0,
      "4403": 16,
      "4404": 5,
      "4405": 56,
      "4406": 8,
      "4407": 4,
      "4408": 28,
      "4409": 10,
      "4410": 0,
      "4411": 16,
      "4412": 6,
      "4413": 56,
      "4414": 9,
      "4415": 12,
      "4416": 3,
      "4417": 5,
      "4418": 30,
      "4419": 9,
      "4420": 12,
      "4421": 3,
      "4422": 11,
      "4423": 3,
      "4424": 4,
      "4425": 33,
      "4426": 5,
      "4427": 39,
      "4428": 11,
      "4429": 0,
      "4430": 1,
      "4431": 11,
      "4432": 2,
      "4433": 1,
      "4434": 7,
      "4435": 6,
      "4436": 39,
      "4437": 11,
      "4438": 2,
      "4439": 17,
      "4440": 56,
      "4441": 12,
      "4442": 4,
      "4443": 14,
      "4444": 4,
      "4445": 17,
      "4446": 57,
      "4447": 12,
      "4448": 6,
      "4449": 11,
      "4450": 4,
      "4451": 7,
      "4452": 0,
      "4453": 10,
      "4454": 0,
      "4455": 46,
      "4456": 56,
      "4457": 1,
      "4458": 10,
      "4459": 0,
      "4460": 15,
      "4461": 6,
      "4462": 56,
      "4463": 10,
      "4464": 10,
      "4465": 0,
      "4466": 16,
      "4467": 7,
      "4468": 20,
      "4469": 56,
      "4470": 11,
      "4471": 10,
      "4472": 0,
      "4473": 16,
      "4474": 8,
      "4475": 20,
      "4476": 17,
      "4477": 62,
      "4478": 10,
      "4479": 6,
      "4480": 17,
      "4481": 63,
      "4482": 17,
      "4483": 66,
      "4484": 9,
      "4485": 9,
      "4486": 49,
      "4487": 0,
      "4488": 6,
      "4489": 0,
      "4490": 0,
      "4491": 0,
      "4492": 0,
      "4493": 0,
      "4494": 0,
      "4495": 0,
      "4496": 0,
      "4497": 9,
      "4498": 9,
      "4499": 17,
      "4500": 66,
      "4501": 17,
      "4502": 66,
      "4503": 57,
      "4504": 0,
      "4505": 12,
      "4506": 5,
      "4507": 10,
      "4508": 0,
      "4509": 15,
      "4510": 5,
      "4511": 10,
      "4512": 6,
      "4513": 56,
      "4514": 12,
      "4515": 11,
      "4516": 0,
      "4517": 46,
      "4518": 56,
      "4519": 1,
      "4520": 11,
      "4521": 6,
      "4522": 14,
      "4523": 5,
      "4524": 55,
      "4525": 2,
      "4526": 20,
      "4527": 18,
      "4528": 4,
      "4529": 56,
      "4530": 13,
      "4531": 11,
      "4532": 5,
      "4533": 56,
      "4534": 14,
      "4535": 2,
      "4536": 0,
      "4537": 5,
      "4538": 1,
      "4539": 0,
      "4540": 0,
      "4541": 58,
      "4542": 120,
      "4543": 10,
      "4544": 0,
      "4545": 55,
      "4546": 0,
      "4547": 20,
      "4548": 7,
      "4549": 0,
      "4550": 33,
      "4551": 4,
      "4552": 7,
      "4553": 5,
      "4554": 11,
      "4555": 11,
      "4556": 0,
      "4557": 1,
      "4558": 7,
      "4559": 14,
      "4560": 39,
      "4561": 10,
      "4562": 0,
      "4563": 55,
      "4564": 3,
      "4565": 20,
      "4566": 32,
      "4567": 4,
      "4568": 17,
      "4569": 5,
      "4570": 21,
      "4571": 11,
      "4572": 0,
      "4573": 1,
      "4574": 7,
      "4575": 13,
      "4576": 39,
      "4577": 10,
      "4578": 0,
      "4579": 55,
      "4580": 4,
      "4581": 20,
      "4582": 49,
      "4583": 0,
      "4584": 33,
      "4585": 4,
      "4586": 30,
      "4587": 8,
      "4588": 12,
      "4589": 3,
      "4590": 5,
      "4591": 36,
      "4592": 10,
      "4593": 0,
      "4594": 55,
      "4595": 4,
      "4596": 20,
      "4597": 49,
      "4598": 3,
      "4599": 33,
      "4600": 12,
      "4601": 3,
      "4602": 11,
      "4603": 3,
      "4604": 4,
      "4605": 50,
      "4606": 10,
      "4607": 0,
      "4608": 55,
      "4609": 5,
      "4610": 56,
      "4611": 15,
      "4612": 4,
      "4613": 47,
      "4614": 10,
      "4615": 0,
      "4616": 55,
      "4617": 6,
      "4618": 20,
      "4619": 12,
      "4620": 2,
      "4621": 5,
      "4622": 52,
      "4623": 9,
      "4624": 12,
      "4625": 2,
      "4626": 5,
      "4627": 52,
      "4628": 9,
      "4629": 12,
      "4630": 2,
      "4631": 11,
      "4632": 2,
      "4633": 4,
      "4634": 55,
      "4635": 5,
      "4636": 59,
      "4637": 11,
      "4638": 0,
      "4639": 1,
      "4640": 7,
      "4641": 8,
      "4642": 39,
      "4643": 14,
      "4644": 1,
      "4645": 56,
      "4646": 16,
      "4647": 17,
      "4648": 63,
      "4649": 10,
      "4650": 0,
      "4651": 55,
      "4652": 2,
      "4653": 20,
      "4654": 33,
      "4655": 4,
      "4656": 68,
      "4657": 5,
      "4658": 72,
      "4659": 11,
      "4660": 0,
      "4661": 1,
      "4662": 7,
      "4663": 7,
      "4664": 39,
      "4665": 10,
      "4666": 0,
      "4667": 55,
      "4668": 7,
      "4669": 20,
      "4670": 6,
      "4671": 1,
      "4672": 0,
      "4673": 0,
      "4674": 0,
      "4675": 0,
      "4676": 0,
      "4677": 0,
      "4678": 0,
      "4679": 22,
      "4680": 10,
      "4681": 0,
      "4682": 54,
      "4683": 7,
      "4684": 21,
      "4685": 10,
      "4686": 0,
      "4687": 54,
      "4688": 5,
      "4689": 11,
      "4690": 1,
      "4691": 56,
      "4692": 17,
      "4693": 49,
      "4694": 1,
      "4695": 10,
      "4696": 0,
      "4697": 54,
      "4698": 4,
      "4699": 21,
      "4700": 9,
      "4701": 10,
      "4702": 0,
      "4703": 54,
      "4704": 8,
      "4705": 21,
      "4706": 9,
      "4707": 10,
      "4708": 0,
      "4709": 54,
      "4710": 9,
      "4711": 21,
      "4712": 17,
      "4713": 66,
      "4714": 10,
      "4715": 0,
      "4716": 54,
      "4717": 10,
      "4718": 21,
      "4719": 17,
      "4720": 66,
      "4721": 10,
      "4722": 0,
      "4723": 54,
      "4724": 11,
      "4725": 21,
      "4726": 10,
      "4727": 0,
      "4728": 46,
      "4729": 56,
      "4730": 18,
      "4731": 10,
      "4732": 0,
      "4733": 55,
      "4734": 2,
      "4735": 20,
      "4736": 10,
      "4737": 0,
      "4738": 55,
      "4739": 7,
      "4740": 20,
      "4741": 7,
      "4742": 1,
      "4743": 11,
      "4744": 0,
      "4745": 55,
      "4746": 12,
      "4747": 20,
      "4748": 18,
      "4749": 5,
      "4750": 56,
      "4751": 19,
      "4752": 2,
      "4753": 0,
      "4754": 6,
      "4755": 1,
      "4756": 0,
      "4757": 0,
      "4758": 1,
      "4759": 15,
      "4760": 10,
      "4761": 0,
      "4762": 46,
      "4763": 11,
      "4764": 1,
      "4765": 56,
      "4766": 20,
      "4767": 10,
      "4768": 2,
      "4769": 10,
      "4770": 0,
      "4771": 54,
      "4772": 3,
      "4773": 21,
      "4774": 11,
      "4775": 0,
      "4776": 46,
      "4777": 56,
      "4778": 18,
      "4779": 11,
      "4780": 2,
      "4781": 18,
      "4782": 8,
      "4783": 56,
      "4784": 21,
      "4785": 2,
      "4786": 0,
      "4787": 7,
      "4788": 1,
      "4789": 0,
      "4790": 0,
      "4791": 1,
      "4792": 10,
      "4793": 10,
      "4794": 0,
      "4795": 11,
      "4796": 1,
      "4797": 56,
      "4798": 20,
      "4799": 11,
      "4800": 2,
      "4801": 11,
      "4802": 0,
      "4803": 55,
      "4804": 13,
      "4805": 11,
      "4806": 3,
      "4807": 11,
      "4808": 4,
      "4809": 17,
      "4810": 29,
      "4811": 2,
      "4812": 0,
      "4813": 8,
      "4814": 1,
      "4815": 0,
      "4816": 0,
      "4817": 58,
      "4818": 102,
      "4819": 10,
      "4820": 0,
      "4821": 46,
      "4822": 11,
      "4823": 1,
      "4824": 56,
      "4825": 20,
      "4826": 10,
      "4827": 0,
      "4828": 55,
      "4829": 6,
      "4830": 20,
      "4831": 32,
      "4832": 4,
      "4833": 16,
      "4834": 10,
      "4835": 0,
      "4836": 55,
      "4837": 4,
      "4838": 20,
      "4839": 49,
      "4840": 0,
      "4841": 33,
      "4842": 12,
      "4843": 8,
      "4844": 5,
      "4845": 18,
      "4846": 9,
      "4847": 12,
      "4848": 8,
      "4849": 11,
      "4850": 8,
      "4851": 4,
      "4852": 21,
      "4853": 5,
      "4854": 35,
      "4855": 11,
      "4856": 0,
      "4857": 1,
      "4858": 11,
      "4859": 3,
      "4860": 1,
      "4861": 11,
      "4862": 2,
      "4863": 1,
      "4864": 11,
      "4865": 4,
      "4866": 1,
      "4867": 11,
      "4868": 7,
      "4869": 1,
      "4870": 11,
      "4871": 5,
      "4872": 1,
      "4873": 7,
      "4874": 8,
      "4875": 39,
      "4876": 10,
      "4877": 2,
      "4878": 46,
      "4879": 56,
      "4880": 22,
      "4881": 10,
      "4882": 0,
      "4883": 55,
      "4884": 14,
      "4885": 20,
      "4886": 33,
      "4887": 4,
      "4888": 48,
      "4889": 14,
      "4890": 6,
      "4891": 17,
      "4892": 64,
      "4893": 32,
      "4894": 12,
      "4895": 9,
      "4896": 5,
      "4897": 50,
      "4898": 9,
      "4899": 12,
      "4900": 9,
      "4901": 11,
      "4902": 9,
      "4903": 4,
      "4904": 53,
      "4905": 5,
      "4906": 67,
      "4907": 11,
      "4908": 0,
      "4909": 1,
      "4910": 11,
      "4911": 3,
      "4912": 1,
      "4913": 11,
      "4914": 2,
      "4915": 1,
      "4916": 11,
      "4917": 4,
      "4918": 1,
      "4919": 11,
      "4920": 7,
      "4921": 1,
      "4922": 11,
      "4923": 5,
      "4924": 1,
      "4925": 7,
      "4926": 9,
      "4927": 39,
      "4928": 10,
      "4929": 2,
      "4930": 10,
      "4931": 3,
      "4932": 11,
      "4933": 4,
      "4934": 11,
      "4935": 5,
      "4936": 7,
      "4937": 1,
      "4938": 10,
      "4939": 6,
      "4940": 11,
      "4941": 7,
      "4942": 17,
      "4943": 42,
      "4944": 10,
      "4945": 2,
      "4946": 10,
      "4947": 3,
      "4948": 7,
      "4949": 1,
      "4950": 72,
      "4951": 1,
      "4952": 0,
      "4953": 7,
      "4954": 16,
      "4955": 17,
      "4956": 41,
      "4957": 11,
      "4958": 2,
      "4959": 11,
      "4960": 3,
      "4961": 7,
      "4962": 1,
      "4963": 72,
      "4964": 3,
      "4965": 0,
      "4966": 7,
      "4967": 16,
      "4968": 17,
      "4969": 41,
      "4970": 10,
      "4971": 6,
      "4972": 10,
      "4973": 0,
      "4974": 54,
      "4975": 12,
      "4976": 21,
      "4977": 8,
      "4978": 10,
      "4979": 0,
      "4980": 54,
      "4981": 6,
      "4982": 21,
      "4983": 11,
      "4984": 0,
      "4985": 46,
      "4986": 56,
      "4987": 18,
      "4988": 11,
      "4989": 6,
      "4990": 18,
      "4991": 7,
      "4992": 56,
      "4993": 23,
      "4994": 2,
      "4995": 0,
      "4996": 9,
      "4997": 0,
      "4998": 0,
      "4999": 0,
      "5000": 30,
      "5001": 52,
      "5002": 10,
      "5003": 0,
      "5004": 55,
      "5005": 0,
      "5006": 20,
      "5007": 7,
      "5008": 0,
      "5009": 33,
      "5010": 4,
      "5011": 7,
      "5012": 5,
      "5013": 13,
      "5014": 11,
      "5015": 0,
      "5016": 1,
      "5017": 11,
      "5018": 1,
      "5019": 1,
      "5020": 7,
      "5021": 14,
      "5022": 39,
      "5023": 10,
      "5024": 1,
      "5025": 56,
      "5026": 22,
      "5027": 10,
      "5028": 0,
      "5029": 55,
      "5030": 14,
      "5031": 20,
      "5032": 33,
      "5033": 4,
      "5034": 21,
      "5035": 5,
      "5036": 27,
      "5037": 11,
      "5038": 0,
      "5039": 1,
      "5040": 11,
      "5041": 1,
      "5042": 1,
      "5043": 7,
      "5044": 9,
      "5045": 39,
      "5046": 10,
      "5047": 0,
      "5048": 55,
      "5049": 6,
      "5050": 20,
      "5051": 4,
      "5052": 40,
      "5053": 11,
      "5054": 1,
      "5055": 7,
      "5056": 1,
      "5057": 17,
      "5058": 36,
      "5059": 11,
      "5060": 0,
      "5061": 55,
      "5062": 12,
      "5063": 20,
      "5064": 33,
      "5065": 12,
      "5066": 2,
      "5067": 5,
      "5068": 46,
      "5069": 11,
      "5070": 0,
      "5071": 1,
      "5072": 11,
      "5073": 1,
      "5074": 1,
      "5075": 9,
      "5076": 12,
      "5077": 2,
      "5078": 11,
      "5079": 2,
      "5080": 4,
      "5081": 49,
      "5082": 5,
      "5083": 51,
      "5084": 7,
      "5085": 10,
      "5086": 39,
      "5087": 2,
      "5088": 0,
      "5089": 10,
      "5090": 1,
      "5091": 0,
      "5092": 0,
      "5093": 68,
      "5094": 48,
      "5095": 10,
      "5096": 0,
      "5097": 46,
      "5098": 10,
      "5099": 1,
      "5100": 56,
      "5101": 24,
      "5102": 11,
      "5103": 1,
      "5104": 10,
      "5105": 0,
      "5106": 55,
      "5107": 13,
      "5108": 11,
      "5109": 2,
      "5110": 17,
      "5111": 37,
      "5112": 17,
      "5113": 30,
      "5114": 12,
      "5115": 6,
      "5116": 1,
      "5117": 1,
      "5118": 12,
      "5119": 4,
      "5120": 1,
      "5121": 1,
      "5122": 12,
      "5123": 5,
      "5124": 7,
      "5125": 1,
      "5126": 33,
      "5127": 4,
      "5128": 33,
      "5129": 11,
      "5130": 5,
      "5131": 10,
      "5132": 0,
      "5133": 55,
      "5134": 12,
      "5135": 20,
      "5136": 33,
      "5137": 4,
      "5138": 30,
      "5139": 14,
      "5140": 6,
      "5141": 56,
      "5142": 25,
      "5143": 12,
      "5144": 3,
      "5145": 5,
      "5146": 35,
      "5147": 9,
      "5148": 12,
      "5149": 3,
      "5150": 5,
      "5151": 35,
      "5152": 9,
      "5153": 12,
      "5154": 3,
      "5155": 11,
      "5156": 3,
      "5157": 4,
      "5158": 38,
      "5159": 5,
      "5160": 42,
      "5161": 11,
      "5162": 0,
      "5163": 1,
      "5164": 7,
      "5165": 10,
      "5166": 39,
      "5167": 11,
      "5168": 6,
      "5169": 56,
      "5170": 26,
      "5171": 11,
      "5172": 0,
      "5173": 14,
      "5174": 4,
      "5175": 56,
      "5176": 27,
      "5177": 2,
      "5178": 0,
      "5179": 11,
      "5180": 0,
      "5181": 0,
      "5182": 0,
      "5183": 73,
      "5184": 244,
      "5185": 1,
      "5186": 11,
      "5187": 1,
      "5188": 17,
      "5189": 31,
      "5190": 12,
      "5191": 14,
      "5192": 12,
      "5193": 15,
      "5194": 12,
      "5195": 11,
      "5196": 12,
      "5197": 13,
      "5198": 12,
      "5199": 16,
      "5200": 12,
      "5201": 12,
      "5202": 10,
      "5203": 12,
      "5204": 49,
      "5205": 2,
      "5206": 33,
      "5207": 4,
      "5208": 15,
      "5209": 8,
      "5210": 12,
      "5211": 3,
      "5212": 5,
      "5213": 19,
      "5214": 10,
      "5215": 12,
      "5216": 49,
      "5217": 4,
      "5218": 33,
      "5219": 12,
      "5220": 3,
      "5221": 11,
      "5222": 3,
      "5223": 4,
      "5224": 46,
      "5225": 11,
      "5226": 16,
      "5227": 10,
      "5228": 0,
      "5229": 55,
      "5230": 15,
      "5231": 20,
      "5232": 33,
      "5233": 4,
      "5234": 43,
      "5235": 11,
      "5236": 13,
      "5237": 10,
      "5238": 0,
      "5239": 55,
      "5240": 2,
      "5241": 20,
      "5242": 33,
      "5243": 4,
      "5244": 40,
      "5245": 10,
      "5246": 11,
      "5247": 10,
      "5248": 0,
      "5249": 55,
      "5250": 7,
      "5251": 20,
      "5252": 33,
      "5253": 12,
      "5254": 2,
      "5255": 5,
      "5256": 48,
      "5257": 9,
      "5258": 12,
      "5259": 2,
      "5260": 5,
      "5261": 48,
      "5262": 9,
      "5263": 12,
      "5264": 2,
      "5265": 5,
      "5266": 48,
      "5267": 9,
      "5268": 12,
      "5269": 2,
      "5270": 11,
      "5271": 2,
      "5272": 4,
      "5273": 51,
      "5274": 5,
      "5275": 55,
      "5276": 11,
      "5277": 0,
      "5278": 1,
      "5279": 7,
      "5280": 11,
      "5281": 39,
      "5282": 10,
      "5283": 0,
      "5284": 55,
      "5285": 8,
      "5286": 20,
      "5287": 4,
      "5288": 60,
      "5289": 5,
      "5290": 64,
      "5291": 11,
      "5292": 0,
      "5293": 1,
      "5294": 7,
      "5295": 8,
      "5296": 39,
      "5297": 14,
      "5298": 15,
      "5299": 17,
      "5300": 64,
      "5301": 32,
      "5302": 4,
      "5303": 73,
      "5304": 14,
      "5305": 14,
      "5306": 17,
      "5307": 64,
      "5308": 32,
      "5309": 12,
      "5310": 4,
      "5311": 5,
      "5312": 75,
      "5313": 9,
      "5314": 12,
      "5315": 4,
      "5316": 11,
      "5317": 4,
      "5318": 4,
      "5319": 78,
      "5320": 5,
      "5321": 82,
      "5322": 11,
      "5323": 0,
      "5324": 1,
      "5325": 7,
      "5326": 11,
      "5327": 39,
      "5328": 11,
      "5329": 12,
      "5330": 49,
      "5331": 4,
      "5332": 33,
      "5333": 4,
      "5334": 158,
      "5335": 1,
      "5336": 10,
      "5337": 0,
      "5338": 55,
      "5339": 4,
      "5340": 20,
      "5341": 49,
      "5342": 2,
      "5343": 33,
      "5344": 4,
      "5345": 95,
      "5346": 8,
      "5347": 12,
      "5348": 6,
      "5349": 5,
      "5350": 101,
      "5351": 10,
      "5352": 0,
      "5353": 55,
      "5354": 4,
      "5355": 20,
      "5356": 49,
      "5357": 3,
      "5358": 33,
      "5359": 12,
      "5360": 6,
      "5361": 11,
      "5362": 6,
      "5363": 4,
      "5364": 115,
      "5365": 10,
      "5366": 0,
      "5367": 55,
      "5368": 9,
      "5369": 20,
      "5370": 4,
      "5371": 112,
      "5372": 10,
      "5373": 0,
      "5374": 55,
      "5375": 5,
      "5376": 56,
      "5377": 15,
      "5378": 12,
      "5379": 5,
      "5380": 5,
      "5381": 117,
      "5382": 9,
      "5383": 12,
      "5384": 5,
      "5385": 5,
      "5386": 117,
      "5387": 9,
      "5388": 12,
      "5389": 5,
      "5390": 11,
      "5391": 5,
      "5392": 4,
      "5393": 120,
      "5394": 5,
      "5395": 124,
      "5396": 11,
      "5397": 0,
      "5398": 1,
      "5399": 7,
      "5400": 8,
      "5401": 39,
      "5402": 10,
      "5403": 15,
      "5404": 10,
      "5405": 0,
      "5406": 55,
      "5407": 10,
      "5408": 20,
      "5409": 33,
      "5410": 4,
      "5411": 137,
      "5412": 1,
      "5413": 11,
      "5414": 14,
      "5415": 10,
      "5416": 0,
      "5417": 55,
      "5418": 11,
      "5419": 20,
      "5420": 33,
      "5421": 12,
      "5422": 7,
      "5423": 5,
      "5424": 139,
      "5425": 1,
      "5426": 9,
      "5427": 12,
      "5428": 7,
      "5429": 11,
      "5430": 7,
      "5431": 4,
      "5432": 142,
      "5433": 1,
      "5434": 5,
      "5435": 146,
      "5436": 1,
      "5437": 11,
      "5438": 0,
      "5439": 1,
      "5440": 7,
      "5441": 12,
      "5442": 39,
      "5443": 49,
      "5444": 3,
      "5445": 10,
      "5446": 0,
      "5447": 54,
      "5448": 4,
      "5449": 21,
      "5450": 11,
      "5451": 0,
      "5452": 46,
      "5453": 56,
      "5454": 18,
      "5455": 11,
      "5456": 11,
      "5457": 11,
      "5458": 15,
      "5459": 18,
      "5460": 6,
      "5461": 56,
      "5462": 28,
      "5463": 2,
      "5464": 10,
      "5465": 0,
      "5466": 55,
      "5467": 4,
      "5468": 20,
      "5469": 49,
      "5470": 2,
      "5471": 33,
      "5472": 4,
      "5473": 167,
      "5474": 1,
      "5475": 8,
      "5476": 12,
      "5477": 8,
      "5478": 5,
      "5479": 173,
      "5480": 1,
      "5481": 10,
      "5482": 0,
      "5483": 55,
      "5484": 4,
      "5485": 20,
      "5486": 49,
      "5487": 3,
      "5488": 33,
      "5489": 12,
      "5490": 8,
      "5491": 11,
      "5492": 8,
      "5493": 4,
      "5494": 197,
      "5495": 1,
      "5496": 10,
      "5497": 15,
      "5498": 10,
      "5499": 0,
      "5500": 55,
      "5501": 10,
      "5502": 20,
      "5503": 33,
      "5504": 4,
      "5505": 188,
      "5506": 1,
      "5507": 10,
      "5508": 14,
      "5509": 10,
      "5510": 0,
      "5511": 55,
      "5512": 11,
      "5513": 20,
      "5514": 33,
      "5515": 12,
      "5516": 9,
      "5517": 5,
      "5518": 190,
      "5519": 1,
      "5520": 9,
      "5521": 12,
      "5522": 9,
      "5523": 11,
      "5524": 9,
      "5525": 4,
      "5526": 193,
      "5527": 1,
      "5528": 5,
      "5529": 235,
      "5530": 1,
      "5531": 11,
      "5532": 0,
      "5533": 1,
      "5534": 7,
      "5535": 12,
      "5536": 39,
      "5537": 10,
      "5538": 0,
      "5539": 55,
      "5540": 4,
      "5541": 20,
      "5542": 49,
      "5543": 1,
      "5544": 33,
      "5545": 4,
      "5546": 208,
      "5547": 1,
      "5548": 10,
      "5549": 0,
      "5550": 55,
      "5551": 5,
      "5552": 56,
      "5553": 29,
      "5554": 12,
      "5555": 10,
      "5556": 5,
      "5557": 210,
      "5558": 1,
      "5559": 9,
      "5560": 12,
      "5561": 10,
      "5562": 11,
      "5563": 10,
      "5564": 4,
      "5565": 213,
      "5566": 1,
      "5567": 5,
      "5568": 217,
      "5569": 1,
      "5570": 11,
      "5571": 0,
      "5572": 1,
      "5573": 7,
      "5574": 8,
      "5575": 39,
      "5576": 49,
      "5577": 2,
      "5578": 10,
      "5579": 0,
      "5580": 54,
      "5581": 4,
      "5582": 21,
      "5583": 10,
      "5584": 15,
      "5585": 10,
      "5586": 0,
      "5587": 54,
      "5588": 10,
      "5589": 21,
      "5590": 10,
      "5591": 14,
      "5592": 10,
      "5593": 0,
      "5594": 54,
      "5595": 11,
      "5596": 21,
      "5597": 10,
      "5598": 0,
      "5599": 54,
      "5600": 5,
      "5601": 56,
      "5602": 30,
      "5603": 14,
      "5604": 14,
      "5605": 17,
      "5606": 65,
      "5607": 56,
      "5608": 31,
      "5609": 11,
      "5610": 0,
      "5611": 46,
      "5612": 56,
      "5613": 18,
      "5614": 11,
      "5615": 11,
      "5616": 11,
      "5617": 15,
      "5618": 11,
      "5619": 14,
      "5620": 18,
      "5621": 9,
      "5622": 56,
      "5623": 32,
      "5624": 2,
      "5625": 0,
      "5626": 12,
      "5627": 0,
      "5628": 0,
      "5629": 0,
      "5630": 78,
      "5631": 107,
      "5632": 10,
      "5633": 1,
      "5634": 49,
      "5635": 1,
      "5636": 33,
      "5637": 4,
      "5638": 49,
      "5639": 10,
      "5640": 0,
      "5641": 55,
      "5642": 3,
      "5643": 20,
      "5644": 32,
      "5645": 4,
      "5646": 10,
      "5647": 5,
      "5648": 14,
      "5649": 11,
      "5650": 0,
      "5651": 1,
      "5652": 7,
      "5653": 13,
      "5654": 39,
      "5655": 10,
      "5656": 0,
      "5657": 55,
      "5658": 4,
      "5659": 20,
      "5660": 49,
      "5661": 1,
      "5662": 33,
      "5663": 4,
      "5664": 25,
      "5665": 10,
      "5666": 0,
      "5667": 55,
      "5668": 5,
      "5669": 56,
      "5670": 29,
      "5671": 12,
      "5672": 2,
      "5673": 5,
      "5674": 27,
      "5675": 9,
      "5676": 12,
      "5677": 2,
      "5678": 11,
      "5679": 2,
      "5680": 4,
      "5681": 30,
      "5682": 5,
      "5683": 34,
      "5684": 11,
      "5685": 0,
      "5686": 1,
      "5687": 7,
      "5688": 8,
      "5689": 39,
      "5690": 49,
      "5691": 1,
      "5692": 10,
      "5693": 0,
      "5694": 55,
      "5695": 15,
      "5696": 20,
      "5697": 10,
      "5698": 0,
      "5699": 55,
      "5700": 2,
      "5701": 20,
      "5702": 11,
      "5703": 0,
      "5704": 55,
      "5705": 7,
      "5706": 20,
      "5707": 17,
      "5708": 66,
      "5709": 17,
      "5710": 66,
      "5711": 17,
      "5712": 32,
      "5713": 12,
      "5714": 5,
      "5715": 5,
      "5716": 105,
      "5717": 11,
      "5718": 1,
      "5719": 49,
      "5720": 3,
      "5721": 33,
      "5722": 4,
      "5723": 78,
      "5724": 10,
      "5725": 0,
      "5726": 55,
      "5727": 4,
      "5728": 20,
      "5729": 49,
      "5730": 2,
      "5731": 33,
      "5732": 4,
      "5733": 62,
      "5734": 8,
      "5735": 12,
      "5736": 4,
      "5737": 5,
      "5738": 68,
      "5739": 10,
      "5740": 0,
      "5741": 55,
      "5742": 4,
      "5743": 20,
      "5744": 49,
      "5745": 3,
      "5746": 33,
      "5747": 12,
      "5748": 4,
      "5749": 11,
      "5750": 4,
      "5751": 4,
      "5752": 75,
      "5753": 10,
      "5754": 0,
      "5755": 55,
      "5756": 5,
      "5757": 56,
      "5758": 15,
      "5759": 12,
      "5760": 3,
      "5761": 5,
      "5762": 80,
      "5763": 9,
      "5764": 12,
      "5765": 3,
      "5766": 5,
      "5767": 80,
      "5768": 9,
      "5769": 12,
      "5770": 3,
      "5771": 11,
      "5772": 3,
      "5773": 4,
      "5774": 83,
      "5775": 5,
      "5776": 87,
      "5777": 11,
      "5778": 0,
      "5779": 1,
      "5780": 7,
      "5781": 8,
      "5782": 39,
      "5783": 49,
      "5784": 3,
      "5785": 10,
      "5786": 0,
      "5787": 55,
      "5788": 15,
      "5789": 20,
      "5790": 10,
      "5791": 0,
      "5792": 55,
      "5793": 2,
      "5794": 20,
      "5795": 10,
      "5796": 0,
      "5797": 55,
      "5798": 7,
      "5799": 20,
      "5800": 10,
      "5801": 0,
      "5802": 55,
      "5803": 10,
      "5804": 20,
      "5805": 11,
      "5806": 0,
      "5807": 55,
      "5808": 11,
      "5809": 20,
      "5810": 17,
      "5811": 32,
      "5812": 12,
      "5813": 5,
      "5814": 11,
      "5815": 5,
      "5816": 2,
      "5817": 0,
      "5818": 13,
      "5819": 0,
      "5820": 0,
      "5821": 0,
      "5822": 79,
      "5823": 220,
      "5824": 1,
      "5825": 11,
      "5826": 1,
      "5827": 49,
      "5828": 1,
      "5829": 33,
      "5830": 4,
      "5831": 7,
      "5832": 72,
      "5833": 1,
      "5834": 0,
      "5835": 12,
      "5836": 3,
      "5837": 5,
      "5838": 9,
      "5839": 72,
      "5840": 3,
      "5841": 0,
      "5842": 12,
      "5843": 3,
      "5844": 11,
      "5845": 3,
      "5846": 12,
      "5847": 12,
      "5848": 10,
      "5849": 0,
      "5850": 7,
      "5851": 1,
      "5852": 10,
      "5853": 12,
      "5854": 7,
      "5855": 17,
      "5856": 17,
      "5857": 33,
      "5858": 12,
      "5859": 4,
      "5860": 14,
      "5861": 4,
      "5862": 65,
      "5863": 27,
      "5864": 6,
      "5865": 2,
      "5866": 0,
      "5867": 0,
      "5868": 0,
      "5869": 0,
      "5870": 0,
      "5871": 0,
      "5872": 0,
      "5873": 36,
      "5874": 4,
      "5875": 23,
      "5876": 5,
      "5877": 27,
      "5878": 11,
      "5879": 0,
      "5880": 1,
      "5881": 7,
      "5882": 15,
      "5883": 39,
      "5884": 11,
      "5885": 0,
      "5886": 7,
      "5887": 1,
      "5888": 11,
      "5889": 12,
      "5890": 11,
      "5891": 2,
      "5892": 17,
      "5893": 33,
      "5894": 12,
      "5895": 9,
      "5896": 14,
      "5897": 9,
      "5898": 65,
      "5899": 27,
      "5900": 6,
      "5901": 22,
      "5902": 0,
      "5903": 0,
      "5904": 0,
      "5905": 0,
      "5906": 0,
      "5907": 0,
      "5908": 0,
      "5909": 38,
      "5910": 4,
      "5911": 56,
      "5912": 14,
      "5913": 9,
      "5914": 6,
      "5915": 0,
      "5916": 0,
      "5917": 0,
      "5918": 0,
      "5919": 0,
      "5920": 0,
      "5921": 0,
      "5922": 0,
      "5923": 66,
      "5924": 27,
      "5925": 20,
      "5926": 49,
      "5927": 0,
      "5928": 33,
      "5929": 4,
      "5930": 53,
      "5931": 14,
      "5932": 9,
      "5933": 6,
      "5934": 1,
      "5935": 0,
      "5936": 0,
      "5937": 0,
      "5938": 0,
      "5939": 0,
      "5940": 0,
      "5941": 0,
      "5942": 66,
      "5943": 27,
      "5944": 20,
      "5945": 49,
      "5946": 3,
      "5947": 33,
      "5948": 12,
      "5949": 5,
      "5950": 5,
      "5951": 58,
      "5952": 9,
      "5953": 12,
      "5954": 5,
      "5955": 5,
      "5956": 58,
      "5957": 9,
      "5958": 12,
      "5959": 5,
      "5960": 11,
      "5961": 5,
      "5962": 4,
      "5963": 61,
      "5964": 5,
      "5965": 63,
      "5966": 7,
      "5967": 15,
      "5968": 39,
      "5969": 6,
      "5970": 2,
      "5971": 0,
      "5972": 0,
      "5973": 0,
      "5974": 0,
      "5975": 0,
      "5976": 0,
      "5977": 0,
      "5978": 12,
      "5979": 13,
      "5980": 50,
      "5981": 0,
      "5982": 0,
      "5983": 0,
      "5984": 0,
      "5985": 0,
      "5986": 0,
      "5987": 0,
      "5988": 0,
      "5989": 0,
      "5990": 0,
      "5991": 0,
      "5992": 0,
      "5993": 0,
      "5994": 0,
      "5995": 0,
      "5996": 0,
      "5997": 12,
      "5998": 15,
      "5999": 10,
      "6000": 13,
      "6001": 14,
      "6002": 9,
      "6003": 65,
      "6004": 27,
      "6005": 35,
      "6006": 4,
      "6007": 211,
      "6008": 1,
      "6009": 10,
      "6010": 13,
      "6011": 6,
      "6012": 4,
      "6013": 0,
      "6014": 0,
      "6015": 0,
      "6016": 0,
      "6017": 0,
      "6018": 0,
      "6019": 0,
      "6020": 22,
      "6021": 14,
      "6022": 9,
      "6023": 65,
      "6024": 27,
      "6025": 37,
      "6026": 4,
      "6027": 80,
      "6028": 5,
      "6029": 82,
      "6030": 7,
      "6031": 15,
      "6032": 39,
      "6033": 14,
      "6034": 9,
      "6035": 10,
      "6036": 13,
      "6037": 6,
      "6038": 1,
      "6039": 0,
      "6040": 0,
      "6041": 0,
      "6042": 0,
      "6043": 0,
      "6044": 0,
      "6045": 0,
      "6046": 22,
      "6047": 66,
      "6048": 27,
      "6049": 20,
      "6050": 52,
      "6051": 6,
      "6052": 0,
      "6053": 1,
      "6054": 0,
      "6055": 0,
      "6056": 0,
      "6057": 0,
      "6058": 0,
      "6059": 0,
      "6060": 24,
      "6061": 14,
      "6062": 9,
      "6063": 10,
      "6064": 13,
      "6065": 6,
      "6066": 2,
      "6067": 0,
      "6068": 0,
      "6069": 0,
      "6070": 0,
      "6071": 0,
      "6072": 0,
      "6073": 0,
      "6074": 22,
      "6075": 66,
      "6076": 27,
      "6077": 20,
      "6078": 52,
      "6079": 22,
      "6080": 12,
      "6081": 14,
      "6082": 14,
      "6083": 9,
      "6084": 10,
      "6085": 13,
      "6086": 66,
      "6087": 27,
      "6088": 20,
      "6089": 49,
      "6090": 1,
      "6091": 33,
      "6092": 4,
      "6093": 118,
      "6094": 5,
      "6095": 108,
      "6096": 14,
      "6097": 9,
      "6098": 10,
      "6099": 13,
      "6100": 6,
      "6101": 3,
      "6102": 0,
      "6103": 0,
      "6104": 0,
      "6105": 0,
      "6106": 0,
      "6107": 0,
      "6108": 0,
      "6109": 22,
      "6110": 66,
      "6111": 27,
      "6112": 20,
      "6113": 49,
      "6114": 1,
      "6115": 33,
      "6116": 12,
      "6117": 6,
      "6118": 5,
      "6119": 120,
      "6120": 9,
      "6121": 12,
      "6122": 6,
      "6123": 11,
      "6124": 6,
      "6125": 4,
      "6126": 123,
      "6127": 5,
      "6128": 125,
      "6129": 7,
      "6130": 15,
      "6131": 39,
      "6132": 10,
      "6133": 14,
      "6134": 6,
      "6135": 17,
      "6136": 0,
      "6137": 0,
      "6138": 0,
      "6139": 0,
      "6140": 0,
      "6141": 0,
      "6142": 0,
      "6143": 33,
      "6144": 4,
      "6145": 132,
      "6146": 1,
      "6147": 8,
      "6148": 12,
      "6149": 8,
      "6150": 5,
      "6151": 136,
      "6152": 1,
      "6153": 10,
      "6154": 14,
      "6155": 6,
      "6156": 33,
      "6157": 0,
      "6158": 0,
      "6159": 0,
      "6160": 0,
      "6161": 0,
      "6162": 0,
      "6163": 0,
      "6164": 33,
      "6165": 12,
      "6166": 8,
      "6167": 11,
      "6168": 8,
      "6169": 4,
      "6170": 148,
      "6171": 1,
      "6172": 10,
      "6173": 13,
      "6174": 6,
      "6175": 3,
      "6176": 0,
      "6177": 0,
      "6178": 0,
      "6179": 0,
      "6180": 0,
      "6181": 0,
      "6182": 0,
      "6183": 22,
      "6184": 10,
      "6185": 14,
      "6186": 22,
      "6187": 14,
      "6188": 9,
      "6189": 65,
      "6190": 27,
      "6191": 37,
      "6192": 12,
      "6193": 7,
      "6194": 5,
      "6195": 150,
      "6196": 1,
      "6197": 9,
      "6198": 12,
      "6199": 7,
      "6200": 11,
      "6201": 7,
      "6202": 4,
      "6203": 153,
      "6204": 1,
      "6205": 5,
      "6206": 155,
      "6207": 1,
      "6208": 7,
      "6209": 15,
      "6210": 39,
      "6211": 50,
      "6212": 0,
      "6213": 0,
      "6214": 0,
      "6215": 0,
      "6216": 0,
      "6217": 0,
      "6218": 0,
      "6219": 0,
      "6220": 0,
      "6221": 0,
      "6222": 0,
      "6223": 0,
      "6224": 0,
      "6225": 0,
      "6226": 0,
      "6227": 0,
      "6228": 12,
      "6229": 10,
      "6230": 6,
      "6231": 0,
      "6232": 0,
      "6233": 0,
      "6234": 0,
      "6235": 0,
      "6236": 0,
      "6237": 0,
      "6238": 0,
      "6239": 12,
      "6240": 11,
      "6241": 10,
      "6242": 11,
      "6243": 6,
      "6244": 16,
      "6245": 0,
      "6246": 0,
      "6247": 0,
      "6248": 0,
      "6249": 0,
      "6250": 0,
      "6251": 0,
      "6252": 35,
      "6253": 4,
      "6254": 200,
      "6255": 1,
      "6256": 11,
      "6257": 10,
      "6258": 49,
      "6259": 8,
      "6260": 47,
      "6261": 14,
      "6262": 9,
      "6263": 10,
      "6264": 13,
      "6265": 6,
      "6266": 4,
      "6267": 0,
      "6268": 0,
      "6269": 0,
      "6270": 0,
      "6271": 0,
      "6272": 0,
      "6273": 0,
      "6274": 22,
      "6275": 10,
      "6276": 11,
      "6277": 22,
      "6278": 66,
      "6279": 27,
      "6280": 20,
      "6281": 53,
      "6282": 27,
      "6283": 12,
      "6284": 10,
      "6285": 10,
      "6286": 14,
      "6287": 6,
      "6288": 33,
      "6289": 0,
      "6290": 0,
      "6291": 0,
      "6292": 0,
      "6293": 0,
      "6294": 0,
      "6295": 0,
      "6296": 33,
      "6297": 4,
      "6298": 195,
      "6299": 1,
      "6300": 14,
      "6301": 9,
      "6302": 10,
      "6303": 13,
      "6304": 6,
      "6305": 20,
      "6306": 0,
      "6307": 0,
      "6308": 0,
      "6309": 0,
      "6310": 0,
      "6311": 0,
      "6312": 0,
      "6313": 22,
      "6314": 10,
      "6315": 11,
      "6316": 22,
      "6317": 66,
      "6318": 27,
      "6319": 20,
      "6320": 49,
      "6321": 0,
      "6322": 33,
      "6323": 4,
      "6324": 193,
      "6325": 1,
      "6326": 5,
      "6327": 195,
      "6328": 1,
      "6329": 7,
      "6330": 15,
      "6331": 39,
      "6332": 11,
      "6333": 11,
      "6334": 6,
      "6335": 1,
      "6336": 0,
      "6337": 0,
      "6338": 0,
      "6339": 0,
      "6340": 0,
      "6341": 0,
      "6342": 0,
      "6343": 22,
      "6344": 12,
      "6345": 11,
      "6346": 5,
      "6347": 159,
      "6348": 1,
      "6349": 11,
      "6350": 15,
      "6351": 11,
      "6352": 10,
      "6353": 22,
      "6354": 12,
      "6355": 15,
      "6356": 11,
      "6357": 13,
      "6358": 6,
      "6359": 3,
      "6360": 0,
      "6361": 0,
      "6362": 0,
      "6363": 0,
      "6364": 0,
      "6365": 0,
      "6366": 0,
      "6367": 22,
      "6368": 11,
      "6369": 14,
      "6370": 22,
      "6371": 12,
      "6372": 13,
      "6373": 5,
      "6374": 67,
      "6375": 11,
      "6376": 15,
      "6377": 50,
      "6378": 64,
      "6379": 13,
      "6380": 3,
      "6381": 0,
      "6382": 0,
      "6383": 0,
      "6384": 0,
      "6385": 0,
      "6386": 0,
      "6387": 0,
      "6388": 0,
      "6389": 0,
      "6390": 0,
      "6391": 0,
      "6392": 0,
      "6393": 0,
      "6394": 38,
      "6395": 4,
      "6396": 216,
      "6397": 1,
      "6398": 5,
      "6399": 218,
      "6400": 1,
      "6401": 7,
      "6402": 15,
      "6403": 39,
      "6404": 11,
      "6405": 9,
      "6406": 2,
      "6407": 0,
      "6408": 14,
      "6409": 1,
      "6410": 0,
      "6411": 0,
      "6412": 81,
      "6413": 22,
      "6414": 10,
      "6415": 0,
      "6416": 10,
      "6417": 1,
      "6418": 56,
      "6419": 24,
      "6420": 10,
      "6421": 0,
      "6422": 10,
      "6423": 2,
      "6424": 56,
      "6425": 33,
      "6426": 12,
      "6427": 5,
      "6428": 10,
      "6429": 1,
      "6430": 11,
      "6431": 2,
      "6432": 11,
      "6433": 3,
      "6434": 17,
      "6435": 13,
      "6436": 12,
      "6437": 6,
      "6438": 11,
      "6439": 1,
      "6440": 11,
      "6441": 0,
      "6442": 55,
      "6443": 13,
      "6444": 7,
      "6445": 1,
      "6446": 11,
      "6447": 5,
      "6448": 11,
      "6449": 6,
      "6450": 9,
      "6451": 11,
      "6452": 4,
      "6453": 17,
      "6454": 40,
      "6455": 2,
      "6456": 0,
      "6457": 15,
      "6458": 1,
      "6459": 0,
      "6460": 0,
      "6461": 81,
      "6462": 44,
      "6463": 10,
      "6464": 0,
      "6465": 46,
      "6466": 10,
      "6467": 1,
      "6468": 46,
      "6469": 56,
      "6470": 24,
      "6471": 10,
      "6472": 0,
      "6473": 46,
      "6474": 10,
      "6475": 2,
      "6476": 56,
      "6477": 33,
      "6478": 12,
      "6479": 6,
      "6480": 10,
      "6481": 1,
      "6482": 46,
      "6483": 10,
      "6484": 2,
      "6485": 11,
      "6486": 3,
      "6487": 17,
      "6488": 13,
      "6489": 12,
      "6490": 7,
      "6491": 11,
      "6492": 2,
      "6493": 49,
      "6494": 1,
      "6495": 33,
      "6496": 4,
      "6497": 25,
      "6498": 8,
      "6499": 10,
      "6500": 0,
      "6501": 54,
      "6502": 8,
      "6503": 21,
      "6504": 5,
      "6505": 29,
      "6506": 8,
      "6507": 10,
      "6508": 0,
      "6509": 54,
      "6510": 9,
      "6511": 21,
      "6512": 11,
      "6513": 1,
      "6514": 11,
      "6515": 0,
      "6516": 55,
      "6517": 13,
      "6518": 7,
      "6519": 1,
      "6520": 11,
      "6521": 6,
      "6522": 11,
      "6523": 7,
      "6524": 11,
      "6525": 4,
      "6526": 56,
      "6527": 34,
      "6528": 10,
      "6529": 5,
      "6530": 46,
      "6531": 17,
      "6532": 61,
      "6533": 56,
      "6534": 35,
      "6535": 11,
      "6536": 5,
      "6537": 17,
      "6538": 38,
      "6539": 2,
      "6540": 0,
      "6541": 16,
      "6542": 1,
      "6543": 0,
      "6544": 0,
      "6545": 1,
      "6546": 10,
      "6547": 10,
      "6548": 0,
      "6549": 10,
      "6550": 1,
      "6551": 46,
      "6552": 56,
      "6553": 24,
      "6554": 11,
      "6555": 1,
      "6556": 11,
      "6557": 0,
      "6558": 55,
      "6559": 13,
      "6560": 11,
      "6561": 2,
      "6562": 17,
      "6563": 34,
      "6564": 2,
      "6565": 0,
      "6566": 17,
      "6567": 1,
      "6568": 0,
      "6569": 0,
      "6570": 1,
      "6571": 9,
      "6572": 10,
      "6573": 0,
      "6574": 10,
      "6575": 1,
      "6576": 56,
      "6577": 24,
      "6578": 11,
      "6579": 1,
      "6580": 11,
      "6581": 0,
      "6582": 55,
      "6583": 13,
      "6584": 11,
      "6585": 2,
      "6586": 17,
      "6587": 35,
      "6588": 2,
      "6589": 0,
      "6590": 18,
      "6591": 1,
      "6592": 0,
      "6593": 0,
      "6594": 1,
      "6595": 4,
      "6596": 11,
      "6597": 0,
      "6598": 55,
      "6599": 4,
      "6600": 20,
      "6601": 2,
      "6602": 0,
      "6603": 19,
      "6604": 1,
      "6605": 0,
      "6606": 0,
      "6607": 1,
      "6608": 4,
      "6609": 11,
      "6610": 0,
      "6611": 55,
      "6612": 15,
      "6613": 20,
      "6614": 2,
      "6615": 0,
      "6616": 20,
      "6617": 1,
      "6618": 0,
      "6619": 0,
      "6620": 1,
      "6621": 4,
      "6622": 11,
      "6623": 0,
      "6624": 55,
      "6625": 2,
      "6626": 20,
      "6627": 2,
      "6628": 0,
      "6629": 21,
      "6630": 1,
      "6631": 0,
      "6632": 0,
      "6633": 1,
      "6634": 4,
      "6635": 11,
      "6636": 0,
      "6637": 11,
      "6638": 1,
      "6639": 56,
      "6640": 33,
      "6641": 2,
      "6642": 0,
      "6643": 22,
      "6644": 1,
      "6645": 0,
      "6646": 0,
      "6647": 1,
      "6648": 4,
      "6649": 11,
      "6650": 0,
      "6651": 55,
      "6652": 7,
      "6653": 20,
      "6654": 2,
      "6655": 0,
      "6656": 23,
      "6657": 1,
      "6658": 0,
      "6659": 0,
      "6660": 30,
      "6661": 19,
      "6662": 10,
      "6663": 0,
      "6664": 55,
      "6665": 4,
      "6666": 20,
      "6667": 49,
      "6668": 1,
      "6669": 33,
      "6670": 4,
      "6671": 11,
      "6672": 11,
      "6673": 0,
      "6674": 1,
      "6675": 8,
      "6676": 12,
      "6677": 1,
      "6678": 5,
      "6679": 17,
      "6680": 11,
      "6681": 0,
      "6682": 55,
      "6683": 4,
      "6684": 20,
      "6685": 49,
      "6686": 2,
      "6687": 33,
      "6688": 12,
      "6689": 1,
      "6690": 11,
      "6691": 1,
      "6692": 2,
      "6693": 0,
      "6694": 24,
      "6695": 1,
      "6696": 0,
      "6697": 0,
      "6698": 1,
      "6699": 4,
      "6700": 11,
      "6701": 0,
      "6702": 55,
      "6703": 5,
      "6704": 56,
      "6705": 29,
      "6706": 2,
      "6707": 0,
      "6708": 25,
      "6709": 1,
      "6710": 0,
      "6711": 0,
      "6712": 1,
      "6713": 4,
      "6714": 11,
      "6715": 0,
      "6716": 55,
      "6717": 1,
      "6718": 20,
      "6719": 2,
      "6720": 0,
      "6721": 26,
      "6722": 1,
      "6723": 0,
      "6724": 0,
      "6725": 1,
      "6726": 4,
      "6727": 11,
      "6728": 0,
      "6729": 16,
      "6730": 5,
      "6731": 20,
      "6732": 2,
      "6733": 0,
      "6734": 27,
      "6735": 1,
      "6736": 0,
      "6737": 0,
      "6738": 1,
      "6739": 2,
      "6740": 7,
      "6741": 1,
      "6742": 2,
      "6743": 0,
      "6744": 28,
      "6745": 1,
      "6746": 0,
      "6747": 0,
      "6748": 1,
      "6749": 4,
      "6750": 11,
      "6751": 0,
      "6752": 55,
      "6753": 12,
      "6754": 20,
      "6755": 2,
      "6756": 0,
      "6757": 2,
      "6758": 1,
      "6759": 1,
      "6760": 1,
      "6761": 3,
      "6762": 1,
      "6763": 3,
      "6764": 2,
      "6765": 2,
      "6766": 6,
      "6767": 2,
      "6768": 4,
      "6769": 2,
      "6770": 2,
      "6771": 2,
      "6772": 3,
      "6773": 2,
      "6774": 5,
      "6775": 3,
      "6776": 6,
      "6777": 3,
      "6778": 10,
      "6779": 3,
      "6780": 11,
      "6781": 3,
      "6782": 5,
      "6783": 3,
      "6784": 9,
      "6785": 3,
      "6786": 12,
      "6787": 3,
      "6788": 13,
      "6789": 3,
      "6790": 14,
      "6791": 3,
      "6792": 15,
      "6793": 3,
      "6794": 16,
      "6795": 3,
      "6796": 8,
      "6797": 3,
      "6798": 3,
      "6799": 3,
      "6800": 4,
      "6801": 3,
      "6802": 7,
      "6803": 2,
      "6804": 46,
      "6805": 3,
      "6806": 46,
      "6807": 9,
      "6808": 46,
      "6809": 10,
      "6810": 46,
      "6811": 11,
      "6812": 46,
      "6813": 12,
      "6814": 46,
      "6815": 13,
      "6816": 46,
      "6817": 14,
      "6818": 46,
      "6819": 15,
      "6820": 46,
      "6821": 16,
      "6822": 46,
      "6823": 17,
      "6824": 46,
      "6825": 18,
      "6826": 46,
      "6827": 19,
      "6828": 46,
      "6829": 20,
      "6830": 46,
      "6831": 21,
      "6832": 46,
      "6833": 22,
      "6834": 46,
      "6835": 0,
      "6836": 7,
      "6837": 0,
      "6838": 0,
      "6839": 0,
      "6840": 0,
      "6841": 0,
      "6842": 0,
      "6843": 0,
      "6844": 0,
      "6845": 0,
      "6846": 0,
      "6847": 0,
      "6848": 0,
      "6849": 0,
      "6850": 0,
      "6851": 0,
      "6852": 0,
      "6853": 0,
      "6854": 0,
      "6855": 0,
      "6856": 0,
      "6857": 0,
      "6858": 0,
      "6859": 0,
      "6860": 0,
      "6861": 0,
      "6862": 0,
      "6863": 0,
      "6864": 0,
      "6865": 0,
      "6866": 0,
      "6867": 0,
      "6868": 1,
      "6869": 0,
      "6870": 0,
      "6871": 0,
      "6872": 0,
      "6873": 0,
      "6874": 0,
      "6875": 0,
      "6876": 0,
      "6877": 0,
      "6878": 0,
      "6879": 0,
      "6880": 0,
      "6881": 0,
      "6882": 0,
      "6883": 0,
      "6884": 0,
      "6885": 0,
      "6886": 0,
      "6887": 0,
      "6888": 0,
      "6889": 0,
      "6890": 0,
      "6891": 0,
      "6892": 0,
      "6893": 0,
      "6894": 0,
      "6895": 0,
      "6896": 0,
      "6897": 0,
      "6898": 0,
      "6899": 0,
      "6900": 2,
      "6901": 40,
      "6902": 222,
      "6903": 158,
      "6904": 142,
      "6905": 8,
      "6906": 122,
      "6907": 99,
      "6908": 71,
      "6909": 0,
      "6910": 25,
      "6911": 7,
      "6912": 251,
      "6913": 105,
      "6914": 143,
      "6915": 223,
      "6916": 138,
      "6917": 176,
      "6918": 70,
      "6919": 123,
      "6920": 52,
      "6921": 34,
      "6922": 41,
      "6923": 183,
      "6924": 75,
      "6925": 25,
      "6926": 38,
      "6927": 64,
      "6928": 103,
      "6929": 174,
      "6930": 188,
      "6931": 74,
      "6932": 233,
      "6933": 49,
      "6934": 190,
      "6935": 174,
      "6936": 248,
      "6937": 137,
      "6938": 176,
      "6939": 139,
      "6940": 156,
      "6941": 59,
      "6942": 55,
      "6943": 209,
      "6944": 146,
      "6945": 128,
      "6946": 252,
      "6947": 31,
      "6948": 139,
      "6949": 117,
      "6950": 186,
      "6951": 229,
      "6952": 178,
      "6953": 222,
      "6954": 36,
      "6955": 16,
      "6956": 252,
      "6957": 49,
      "6958": 32,
      "6959": 244,
      "6960": 3,
      "6961": 233,
      "6962": 163,
      "6963": 109,
      "6964": 172,
      "6965": 253,
      "6966": 194,
      "6967": 138,
      "6968": 252,
      "6969": 1,
      "6970": 16,
      "6971": 203,
      "6972": 46,
      "6973": 219,
      "6974": 148,
      "6975": 227,
      "6976": 229,
      "6977": 127,
      "6978": 43,
      "6979": 28,
      "6980": 230,
      "6981": 155,
      "6982": 90,
      "6983": 153,
      "6984": 197,
      "6985": 3,
      "6986": 176,
      "6987": 109,
      "6988": 21,
      "6989": 229,
      "6990": 28,
      "6991": 250,
      "6992": 33,
      "6993": 45,
      "6994": 229,
      "6995": 110,
      "6996": 36,
      "6997": 0,
      "6998": 36,
      "6999": 91,
      "7000": 163,
      "7001": 111,
      "7002": 122,
      "7003": 28,
      "7004": 198,
      "7005": 67,
      "7006": 162,
      "7007": 176,
      "7008": 55,
      "7009": 69,
      "7010": 13,
      "7011": 255,
      "7012": 30,
      "7013": 67,
      "7014": 153,
      "7015": 225,
      "7016": 128,
      "7017": 105,
      "7018": 198,
      "7019": 84,
      "7020": 95,
      "7021": 181,
      "7022": 252,
      "7023": 170,
      "7024": 243,
      "7025": 125,
      "7026": 57,
      "7027": 215,
      "7028": 220,
      "7029": 61,
      "7030": 225,
      "7031": 80,
      "7032": 76,
      "7033": 243,
      "7034": 253,
      "7035": 117,
      "7036": 118,
      "7037": 39,
      "7038": 89,
      "7039": 227,
      "7040": 83,
      "7041": 217,
      "7042": 217,
      "7043": 83,
      "7044": 137,
      "7045": 97,
      "7046": 142,
      "7047": 85,
      "7048": 125,
      "7049": 5,
      "7050": 82,
      "7051": 105,
      "7052": 127,
      "7053": 25,
      "7054": 181,
      "7055": 46,
      "7056": 78,
      "7057": 146,
      "7058": 124,
      "7059": 29,
      "7060": 238,
      "7061": 1,
      "7062": 1,
      "7063": 3,
      "7064": 0,
      "7065": 0,
      "7066": 0,
      "7067": 0,
      "7068": 1,
      "7069": 0,
      "7070": 0,
      "7071": 72,
      "7072": 89,
      "7073": 83,
      "7074": 226,
      "7075": 234,
      "7076": 223,
      "7077": 74,
      "7078": 160,
      "7079": 42,
      "7080": 249,
      "7081": 80,
      "7082": 207,
      "7083": 142,
      "7084": 145,
      "7085": 79,
      "7086": 189,
      "7087": 43,
      "7088": 103,
      "7089": 82,
      "7090": 51,
      "7091": 133,
      "7092": 231,
      "7093": 60,
      "7094": 54,
      "7095": 17,
      "7096": 131,
      "7097": 65,
      "7098": 69,
      "7099": 157,
      "7100": 141,
      "7101": 69,
      "7102": 196,
      "7103": 0,
      "7104": 72,
      "7105": 89,
      "7106": 83,
      "7107": 226,
      "7108": 234,
      "7109": 223,
      "7110": 74,
      "7111": 160,
      "7112": 42,
      "7113": 249,
      "7114": 80,
      "7115": 207,
      "7116": 142,
      "7117": 145,
      "7118": 79,
      "7119": 189,
      "7120": 43,
      "7121": 103,
      "7122": 82,
      "7123": 51,
      "7124": 133,
      "7125": 231,
      "7126": 60,
      "7127": 54,
      "7128": 17,
      "7129": 131,
      "7130": 65,
      "7131": 69,
      "7132": 157,
      "7133": 141,
      "7134": 69,
      "7135": 196,
      "7136": 100,
      "7137": 0,
      "7138": 0,
      "7139": 0,
      "7140": 0,
      "7141": 0,
      "7142": 0,
      "7143": 0,
      "7144": 0,
      "7145": 225,
      "7146": 245,
      "7147": 5,
      "7148": 0,
      "7149": 0,
      "7150": 0,
      "7151": 0,
      "7152": 2,
      "7153": 1,
      "7154": 39,
      "7155": 5,
      "7156": 0,
      "7157": 0,
      "7158": 0,
      "7159": 0,
      "7160": 0,
      "7161": 0,
      "7162": 1,
      "7163": 40,
      "7164": 5,
      "7165": 0,
      "7166": 0,
      "7167": 0,
      "7168": 0,
      "7169": 0,
      "7170": 0,
      "7171": 0,
      "7172": 0,
      "7173": 32,
      "7174": 53,
      "7175": 131,
      "7176": 74,
      "7177": 138,
      "7178": 193,
      "7179": 124,
      "7180": 164,
      "7181": 143,
      "7182": 177,
      "7183": 74,
      "7184": 200,
      "7185": 249,
      "7186": 156,
      "7187": 23,
      "7188": 201,
      "7189": 135,
      "7190": 71,
      "7191": 233,
      "7192": 93,
      "7193": 208,
      "7194": 114,
      "7195": 148,
      "7196": 174,
      "7197": 65,
      "7198": 164,
      "7199": 107,
      "7200": 56,
      "7201": 34,
      "7202": 70,
      "7203": 164,
      "7204": 73,
      "7205": 155,
      "7206": 64,
      "7207": 71,
      "7208": 30,
      "7209": 146
    },
    signatures: [
      "AINUnzqYI72qjs+Sm4q87yY6Cp+a6Uxn7VdTi2n6jfP87iitrW4lHOep5zgOavqs/ze7bcZahlPcLM93SYVDkwY5Eyp9HYcN7eE/Ygf0KNkaywNx3Yut8Z6Xh98ETskKOQ=="
    ],
    balanceChanges: [
      {
        coinType: "0x0000000000000000000000000000000000000000000000000000000000000002::sui::SUI",
        address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
        amount: "-69723600"
      }
    ],
    events: []
  }
};

// docs/multichain/generation-milestone/published/objects.json
var objects_default = {
  data: {
    chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
    checkpoint: {
      sequenceNumber: 348094265,
      timestamp: "2026-11-22T19:32:20.797Z"
    },
    o0: {
      address: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
      version: 1,
      digest: "7LeHSzqW2xxEA7QrcimgN8c7ZKaAJUL3fwvjNy9wnoar",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::OApp"
          },
          json: {
            id: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            oapp_cap: {
              id: "0x6b7c66d2135ce12efa6a23037bff2e5ca1b499db24bc200592d08c2595cf5a3a",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            admin_cap: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
            peer: {
              peers: {
                id: "0x984eb93d6713b0909152e249bcfa465a6661e7403c5b01266353b97ff2318966",
                size: "0"
              }
            },
            enforced_options: {
              options: {
                id: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
                size: "0"
              }
            },
            sending_call: null
          }
        }
      }
    },
    o1: {
      address: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
      version: 1,
      digest: "C8HbQXjdhJTwpjy4aNx7PaYJp3oikopu9QwNgC5kdPaM",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Registry"
          },
          json: {
            id: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
            version: "1",
            cap: {
              id: "0x1711b6b0e442e8299ea3aceb30286234520c8f1c4d2294aa7d031308a3d7bcff",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            slot: null,
            backing: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
            nft_type: "ZjZjNmQ0MzllYTBkYTJmM2U5YmE3OWU0OTkyYTdhNGMxMTMyMTVmYmY1NGM0NDJhYzkwMjBjMzE1Zjk1MzcwNTo6Y29sbGVjdGlvbjo6TkZU"
          }
        }
      }
    },
    o2: {
      address: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
      version: 1,
      digest: "CXYbjFxRkbB7SDn82yNUgTdRGbjvNPpE8dBsyq13genK",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::AdminCap"
          },
          json: {
            id: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
            registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210"
          }
        }
      }
    },
    o3: {
      address: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
      version: 1,
      digest: "CRHN2g1UWgQYiN9TVWbRf8CcTd9FMtr2ky2jnfx79VVB",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::AdminCap"
          },
          json: {
            id: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d"
          }
        }
      }
    },
    o4: {
      address: "0xb70e2cdc18d562247bc34bf47efee620a05ec1f059cff5e812a8d433a722999d",
      version: 1,
      digest: "5SaYRBQ1KG5DD1bbYMLkDAPMmvfxkv6Q254Hm41cVrGR",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x0000000000000000000000000000000000000000000000000000000000000002::package::UpgradeCap"
          },
          json: {
            id: "0xb70e2cdc18d562247bc34bf47efee620a05ec1f059cff5e812a8d433a722999d",
            package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            version: "1",
            policy: 0
          }
        }
      }
    }
  }
};

// docs/multichain/generation-milestone/published/package.json
var package_default = {
  data: {
    object: {
      address: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
      version: 1,
      digest: "ABfRdTrhPgxDcLyZqRq7vyRyBSfaWcifjfsEcrE9i89N",
      previousTransaction: {
        digest: "DVoQj1tPzfASPesS1bdEsEBQnQ7AhzNS4kxeuEiQVq6S"
      },
      asMovePackage: {
        modules: {
          nodes: [
            {
              name: "codec",
              bytes: "oRzrCwcAAAUJAQAGAgYEAwofBCkCBSs+B2lLCLQBYAaUAg4MogLrAwADAQgCAgIABwAABQABAAAEAgAAAAkDBAABAQkHAQACBgEEAAIHCAEAAwYGAggACAADCAAIAAEKAgEGCgICBgoCAwEIAAMBAgoCAQIAAQYIAAIHCgkACgkABQEBAwMCBgIHCgIDAwMKAgdCeXRlczMyBmFwcGVuZAdieXRlczMyBWNvZGVjBmRlY29kZQZlbmNvZGUKZnJvbV9ieXRlcwh0b19ieXRlcwZ2ZWN0b3IEd29yZMRFUZvx1u2KtgAtIK1+2Bqa0l4xmQ35tyID0K2G/S6SAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAJFujb3ocxkOisDdFDf8eQ5nhgGnGVF+1/KrzfTnX3AMIZAAAAAAAAAAKAgEAAAEAAAVCCgAxASYEEAoAMQQlBA0KAwYAAAAAAAAAACQMBgUSCQwGBRIJDAYLBgQVBRcHACcxAwsAQAYCAAAAAAAAAAwIDQgOAREFOAANCA4CEQU4ADEIDAcKBzEAJAQ4CwcxARcMBw0ICgMKBzEIGDAG/wAAAAAAAAAcM0QGBSUNCA4EEQU4AA0IDgURBTgACwgCAAEBAAAKXAoAQQYGigAAAAAAAAAhBA0KAAYAAAAAAAAAAEIGFDEDIQwBBQ8JDAELAQQSBRYLAAEHACcKAAYBAAAAAAAAAEIGFAwFCgUxASYEJAoFMQQlDAIFJgkMAgsCBCkFLQsAAQcAJwYAAAAAAAAAAAwDBkIAAAAAAAAADAQKBAZKAAAAAAAAACMERAsDMQgvCgAKBEIGFDQbDAMLBAYBAAAAAAAAABYMBAUxCgMGAAAAAAAAAAAkBEkFTQsAAQcAJwsFCgAGAgAAAAAAAAARAgoABiIAAAAAAAAAEQILAwoABkoAAAAAAAAAEQILAAZqAAAAAAAAABECAgACAAAACyIHAQwHBgAAAAAAAAAADAYKBgYgAAAAAAAAACMEHQoGDAQNBwwDCwQMBQoACgELBRZCBhQMAgsDCwJEBgsGBgEAAAAAAAAAFgwGBQQLAAELBxEEAgAA"
            },
            {
              name: "vault",
              bytes: "oRzrCwcAAAUNAQAuAi6KAQO4AfUCBK0ESAX1BLQFB6kKmwkIxBOAAgbEFbUCCvkXoAELmRkCDJsZpRQNwC0uDu4tIAB6BCgEKQU5BToFOwVOBVAFUQVSACsHWAEjAVoBdwIsAjwCWQJzAnUCdgMnBn8AGwIAAAAIAAASCAAAHAgBDAAAFgMAAAgDAAAGAwAAAQMAABADAAATAwABAwACAAAAAAEdBwACBAwAAxEHAAQVAAAFBwgABgoAAAcLCAAIDAcACQ0HAAsADAALDggADBcHAA0PBwEAAA4ZBwAPBQwBAAERCQcAERoEABIUAgAUGAIAFQIHABYeAgAASAABAABUAgMAAGcEAQAAewUBAQwAMQYBAQwAQgcBAQwAbggBAQwAZAkKAQwAJQsBAQwAeQwBAQwATg0BAQwAYA4BAQwAXA8QAQwAPREQAABiEhMBDABrFBUBDAAwFhcBDAAvGBkBDABfGhsBDABqGhwBDAAkGhwBDABdDxABDABDGh0BDAAhGh4BDABFGh4BDABoGh8BDABxICEAADMBIgAAXhocAQwFZT0KAAY0RkcACjJKSwAKOEsQAAstUBAACy5VFwALL1YZAAtEQxwAC05FRgALT1QVAAtTJicBAgtiUhMAC21BAQALb0ABAAxJMxAADTUwAQEADT42LgEADT83AQEADUs0HgEADUw0HgEADVcBMAEADXIuMAEADkoyMwAOfQEyAQAQNy4BAQMRRiofAQgRRyoKAQgRUygpABF4NR8AE2EsAQEME3AuAQEIE3UsAQEIFGwkCgAVQAocABVBHxwAFU0/HgAVdD8KABV+ARwAJyU2AzorPC07AzIvMR80Li8fMC8tLzEuLh81ODs5Ly42Li4uNjk1OwMuNTw3PjVCCS4vSCxICy41TDAuLS46LjVNDC4xUzIKAggABwgdAAUIDAUFCgIHCB0BCAICBggCBggBAgYLAwEJAAYIAQMHCAIGCAEHCB0CBwsDAQkACQADBwsDAQkABggBAQUGCwMBCQAGCAEHCA8KAgcIHQEFCAcLAwEJAAYIAQcIFQYIFAYIDwcIEQgeBwgdAgYLAwEJAAYIFQMHCwMBCQAGCBULCgIIEAgLAgcLAwEJAAYKAgIGCwMBCQACAQoCAwYIFQIKAgUGCwMBCQAGCBUCCgIHCB0BCwoCCA0IEgYHCwMBCQAHCBUCCgILGQEIHAcIHQELCgIIDggTAwYLAwEJAAcIFQsKAggOCBMCCA4IEwMGCwMBCQAGCBULCgIIDQgSAggNCBIBBgsDAQkAAQIBCB4BAwEBAQgaAQYIAgELFwEIGgEOBAgBBQgUCAIBBggdAQgAAgYJAAcIHQMIDAgUBQEHCB0BCBsBBgkAAQgUAgkABQEIAQEJAAEIDAELFwEJAAQBCBsLAwEJAAgaAQgYAQgWAQYLFwEJAAEGCBsBBwsXAQkAAgcLFwEJAAkAAQgEAQsDAQkAAgEBAQgFAQgIBAcIDwYIDAoCBwgdAQgVAQYIHgcHCBUGCBQGCA8HCBEOCB4HCB0FBwgVBggUDg0KAgEIBwIGCBUOBAEKAggeCxcBCxkBCBwDBggVBggMCwoCCBAICwEIEAgOCB4DCB4KAgUKAgsXAQsZAQgcAQsZAQgcDwEBAQEBAQEBAQMCCB4IHggeCB4BBgoCBgIIHggeAwgeCB4BCAYBCAkEAQEBCgINDQoCAQEBAQoCBAMNAwMEBAYIFQ4NCgICCgIKAgcGCBUGCAwOCgIKAgEHCB0BCxkBCB8JBwgVBggMDgoCCgILGQEIHAsXAQsZAQgfCxcBBQcIHQMHCBUGCAwLCgIIDggTAwYIFQYIDAsKAggNCBIIQWRtaW5DYXAFQm91bmQHQnl0ZXMzMgRDYWxsB0NhbGxDYXAEQ29pbglDb21wbGV0ZWQKRW5kcG9pbnRWMgZGdW5kZWQCSUQOTHpSZWNlaXZlUGFyYW0QTWVzc2FnaW5nQ2hhbm5lbAxNZXNzYWdpbmdGZWUQTWVzc2FnaW5nUmVjZWlwdARPQXBwBk9wdGlvbgxQYXVzZUNoYW5nZWQKUXVvdGVQYXJhbQhSZWdpc3RyeQhSZWxlYXNlZANTVUkJU2VuZFBhcmFtC1Nsb3RDcmVhdGVkBlN0cmluZwlUeENvbnRleHQIVHlwZU5hbWUDVUlEBVZBVUxUBVZhdWx0BFZvaWQDWlJPCGFja19zZW50B2FkYXB0ZXIJYWxsb2NhdGVkCWFubm91bmNlZAVhc2NpaQdiYWNraW5nBGJpbmQFYm91bmQHYnl0ZXMzMgRjYWxsCGNhbGxfY2FwA2NhcAVjb2RlYwRjb2luD2NvbWJpbmVfb3B0aW9ucw9jb25maXJtX2x6X3NlbmQNY29uZmlybV9xdW90ZQxjb25maXJtX3NlbmQLY3JlYXRlX3Nsb3QGZGVjb2RlC2Rlc3RpbmF0aW9uB2Rlc3Ryb3kMZGVzdHJveV9ub25lC2R1bW15X2ZpZWxkBGVtaXQGZW5jb2RlDmVuZHBvaW50X3F1b3RlDWVuZHBvaW50X3NlbmQLZW5kcG9pbnRfdjIFZXZlbnQRZXhlY3V0aW9uX29wdGlvbnMHZXh0cmFjdARmaWxsDGZyb21fYWRkcmVzcwdmcm9tX2lkBGZ1bmQKZ2VuZXJhdGlvbghnZXRfcGVlcgRoZWxkAmlkCmlkX2FkZHJlc3MEaW5pdAppbnRvX2J5dGVzC2ludG9fc3RyaW5nB2lzX25vbmUHaXNfc29tZQdpc196ZXJvCmx6X3JlY2VpdmUHbHpfc2VuZBFtZXNzYWdpbmdfY2hhbm5lbA1tZXNzYWdpbmdfZmVlEW1lc3NhZ2luZ19yZWNlaXB0A25ldwxuZXdfcmVnaXN0cnkDbmZ0CG5mdF90eXBlBG5vbmUEb2FwcAZvYmplY3QGb3B0aW9uBnBhdXNlZAdwYXlsb2FkEnBheWxvYWRfZm9yX3JldmlldwRwZWVyBXBoYXNlB3Byb2Nlc3MPcHVibGljX3RyYW5zZmVyBXF1b3RlCXJlY2lwaWVudAhyZWdpc3Rlcg1yZWdpc3Rlcl9vYXBwCHJlZ2lzdHJ5DnJlZ2lzdHJ5X2FkbWluC3JlZ2lzdHJ5X2lkB3JlcXVlc3QFcm91dGUEc2VuZAZzZW5kZXIUc2V0X2VuZm9yY2VkX29wdGlvbnMKc2V0X3BhdXNlZAhzZXRfcGVlcgxzaGFyZV9vYmplY3QEc2xvdARzb21lA3N1aQp0b19hZGRyZXNzCHRyYW5zZmVyCnR4X2NvbnRleHQJdHlwZV9uYW1lDHVpZF90b19pbm5lcgh2YWxpZGF0ZQV2YXVsdAt2YXVsdF9hZG1pbgd2ZXJzaW9uEXdpdGhfb3JpZ2luYWxfaWRzDHplcm9fYnl0ZXMzMgN6cm/ERVGb8dbtirYALSCtftgamtJeMZkN+bciA9Cthv0ukgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAJFujb3ocxkOisDdFDf8eQ5nhgGnGVF+1/KrzfTnX3Cjeno4IemNHABkH+2mP34qwRns0Iim3SxkmQGeuvErpMb6u+Imwi5w7N9GSgPwfi3W65bLeJBD8MSD0A+mjbaw94VBM8/11didZ41PZ2VOJYY5VfQVSaX8ZtS5Oknwd7v3CivwBEMsu25Tj5X8rHOabWpnFA7BtFeUc+iEt5W4kAwgBAAAAAAAAAA4ElnUAAAUgBG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWproFIEhZU+Lq30qgKvlQz46RT70rZ1Izhec8NhGDQUWdjUXECgJSUWY2YzZkNDM5ZWEwZGEyZjNlOWJhNzllNDk5MmE3YTRjMTEzMjE1ZmJmNTRjNDQyYWM5MDIwYzMxNWY5NTM3MDU6OmNvbGxlY3Rpb246Ok5GVAMIAgAAAAAAAAADCAMAAAAAAAAAAwgEAAAAAAAAAAMIBQAAAAAAAAADCAYAAAAAAAAAAwgHAAAAAAAAAAMICAAAAAAAAAADCAkAAAAAAAAAAwgKAAAAAAAAAAMICwAAAAAAAAADCAwAAAAAAAAACgIXFgADAQARAQAAAAAAAAAAAAAAAAADDUAKAgEAAAIBNgEBAgJGCBtmCBoCAgdGCBt8AyoLFwEIDFgFcQsXAQgaJAVWCgIDAhFGCBt8A2YIGioIDFgFVQsXAQkAJAgeaggeXggeJgFbAV8CQwMiAR8BaQgeYwgeBAIDZggaeggaVQgeBQIFeggaVQgeQwMzDiAIHgYCA3oIGkMDaQgeBwICeggaXggeCAICeggaWwEJAgR6CBpDA2kIHmMIHgMuAAAAACMpCgEuET0HAyEEBwULCwEBBwAnDgAKATgADAMMBAsDBwIHBAoBEQEMBQoBETgOBTgBEgEMAgsECgEuET04AgsCCwEuET04AwsFOAQCAAEAAAABCwsEETgHAAsAOAULATgGCwILAxICAgACAAAAARgKABAAFAcAIQQHBQ0LAAELAQEHDicLARABFAsAOAEhBBUFFwcAJwIAAwAAAAEZCgA3ABQHACEEBwUNCwABCwEBBw4nCwEQARQLADcBFCEEFgUYBwAnAgAEAQAAMVoKAC4LARECOAcRMxErCgAQBBQhBA0FEwsAAQsCAQcFJwoAEAU4CAQcCgAQBjgJDAMFHgkMAwsDBCEFJwsAAQsCAQcGJwsCETgMBA4EETkMBgsEBwAKAC44AQoADwY4CgoAEAcUOAsKABAIFBE+CgYRPxFCCQkxAAYAAAAAAAAAAAkJEUIRQjkADAUKAA8FCgY4DAsALjgBCwYOBTcCFBIEOA0LBTgOAgAFAQAAOngKADcAFAcAIQQHBQsLAAEHDicKADcDFCAEEQUVCwABBw0nCgA3BBQxACEEHggMAwUkCgA3BBQxAyEMAwsDBDIKADcFOA8ELwoANwYUDAIFNAkMAgU0CQwCCwIENwU7CwABBwgnDgE4EBE/CgA3AhQhBEQFSAsAAQcHJwoANwcUBgEAAAAAAAAAFgoANgcVCgA2BQsBOBExAQoANgQVCQoANggVCQoANgkVEUIKADYKFRFCCgA2CxUKAC44EgoANwIUCgA3BxQHAQsANwwUEgU4EwIABgEAAAEPCgAuCwE4FAoCCgA2AxULAC44EgsCEgg4FQIABwEAAAEKCgALATgUCwILADcNCwMLBBEdAgAIAQAAOmYKAC4LATgUCgA3BhQgBBAKADcEFDEAIQwIBRIJDAgLCAQVBSMLAAELAwELAgELBAELBwELBQEHCCcKAi44FgoANw4UIQQwDgYRQCAMCQUyCQwJCwkENQVDCwABCwMBCwIBCwQBCwcBCwUBBwknCgIKAwsECwUHAQoGCwcRKgoCCgMHAUgBAAcQESkLAgsDBwFIAwAHEBEpCgYKADYMFQgKADYGFQsALjgSCwYSBzgXAgAJAAAAHjQKADcAFAcAIQQHBQ0LAAELAQEHDicKATgWCgA3DhQhBBUFGwsAAQsBAQcJJwoANwYUBCgLAQcBESQLADcMFCEMAgUuCwABCwEBCQwCCwIEMQUzBwonAgAKAQAARDAKAC4KATgYCwEKADcNCwIRJREeDAYBAQwEAQEMBQcBIQQhCwUKADcMFCEEHg4GOBkMAwUjCQwDBSMJDAMLAwQmBSoLAAEHCicLBjgaCwAOBDgbAgALAAAASfQBCwERHwwODA8MCwwNDBAMDAoMMQIhBA8IDAMFEwoMMQQhDAMLAwQuCxAKADcPFCEEKwsNCgA3AhQhBCgKCwoANwcUIQwCBTAJDAIFMAkMAgUwCQwCCwIEMwU3CwABBwsnCgA3CBQEPAVACwABBwgnDg8RQCAESQ4OEUAgDAQFSwkMBAsEBE4FUgsAAQcLJwsMMQQhBJ4BCgA3BBQxAiEEXwgMBgVlCgA3BBQxAyEMBgsGBHMKADcJFARwCgA3BTgPDAUFdQkMBQV1CQwFCwUEeAV8CwABBwgnCg8KADcKFCEEiQELDgoANwsUIQwHBYsBCQwHCwcEjgEFkgELAAEHDCcxAwoANgQVCwAuOBILCwsPEgY4HAIKADcEFDECIQSnAQgMCAWtAQoANwQUMQMhDAgLCATFAQoPCgA3ChQhBLwBCg4KADcLFCEMCQW+AQkMCQsJBMEBBesBCwABBwwnCgA3BBQxASEE0AEKADcFOB0MCgXSAQkMCgsKBNUBBdkBCwABBwgnMQIKADYEFQoPCgA2ChUKDgoANgsVCgA2BTgeDg4RQTgfCwAuOBILCwsPCw4SCTggAgAMAAAATmsKATEBIQQxCgA3AxQgBAoFDgsAAQcNJwoANwQUMQEhBBkKADcFOB0MAgUbCQwCCwIEHgUiCwABBwgnMQEKADcPFAoANwIUCwA3BxQRQhFCESAMBQVpCwExAyEETgoANwQUMQIhBD4IDAQFRAoANwQUMQMhDAQLBARLCgA3BTgPDAMFUAkMAwVQCQwDCwMEUwVXCwABBwgnMQMKADcPFAoANwIUCgA3BxQKADcKFAsANwsUESAMBQsFAgANAAAAT9wBCwExASEEB0gBAAwDBQlIAwAMAwsDDAwKAAcBCgwHEREhDAQOBEEbBgIAAAAAAAAAJAQXBRsLAAEHDycLAAcBCwwLAhEhDAkOCUEbBhYAAAAAAAAAJgQ4DgkGAAAAAAAAAABCGxQxACEENQ4JBgEAAAAAAAAAQhsUMQMhDAUFOgkMBQU6CQwFCwUEPQU/Bw8nBgIAAAAAAAAADA0yAAAAAAAAAAAAAAAAAAAAAAwPCg0OCUEbIwTTAQoNBgQAAAAAAAAAFg4JQRslBFAFUgcPJw4JCg0GAQAAAAAAAAAWQhsUNAYAAQAAAAAAABgOCQoNBgIAAAAAAAAAFkIbFDQWDA4OCQoNQhsUMQEhBHYFbA4JCg0GAwAAAAAAAAAWQhsUMQEhDAYFeAkMBgsGBHsFfQcPJwoOBhEAAAAAAAAAIQSEAQgMCAWIAQoOBiEAAAAAAAAAIQwICwgElAEKDQYDAAAAAAAAABYKDhYOCUEbJQwHBZYBCQwHCwcEmQEFmwEHDycyAAAAAAAAAAAAAAAAAAAAAAwKBgAAAAAAAAAADAsKCwYQAAAAAAAAACMEyAELCjEILw4JCg0GBAAAAAAAAAAWCgsWQhsUNRsMCgoOBiEAAAAAAAAAIQTDAQ4JCg0GFAAAAAAAAAAWCgsWQhsUMQAhBMEBBcMBBw8nCwsGAQAAAAAAAAAWDAsFnwELDwsKFgwPCw0GAwAAAAAAAAAWCw4WDA0FQwsPMkANAwAAAAAAAAAAAAAAAAAmBNgBBdoBBw8nCwkCAA4BAABRFgoACgE4GAoACgI4IQwFCgELAgsDEQ0MBgsBCwA3DQcBCwULBgkLBBEoAgAPAQAAUSwKAC4KAS44GAoALgoCOCEMBgoBLgoCCwMRDQwHCwIxASEEGQgKADYIFQUdCAoANgkVCwELADcNBwELBgsHCwQ4IgoFLhE9OCMLBREmAgAQAQAAAQoKAAoBLjgYCwELADcNCwIRIgIAEQEAAAEJCgAKATgYCwELADcNCwIRIwIAEgEAAAEECwA3BBQCABMBAAABBAsANw8UAgAUAQAAAQQLADcCFAIAFQEAAAEECwALATghAgAWAQAAAQQLADcHFAIAFwEAAB4TCgA3BBQxASEECwsAAQgMAQURCwA3BBQxAiEMAQsBAgAYAQAAAQQLADcFOB0CABkBAAABBAsANwEUAgAaAQAAAQQLABAFFAIAGwEAAAECBwECABwBAAABBAsANwwUAgACAQEBAwEDAgIGAgQCAgIDAgUDBgMKAwsDBQMJAwwDDQMOAw8DEAMIAwMDBAMHAi4DLgkuCi4LLgwuDS4OLg8uEC4RLhIuEy4ULhUuFi4A"
            }
          ],
          pageInfo: {
            hasNextPage: false
          }
        }
      }
    }
  }
};

// docs/multichain/generation-milestone/published/candidate.json
var candidate_default = {
  chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
  checkpoint: {
    sequenceNumber: 348094135,
    timestamp: "2026-11-22T19:31:49.042Z"
  },
  nft: {
    address: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
    version: 1100579540,
    digest: "4kUybSr2UuXay8xoJrQqsqTLqbmbaBB3nP3pjrAfQXxr",
    owner: {
      __typename: "AddressOwner",
      address: {
        address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
      }
    },
    asMoveObject: {
      contents: {
        type: {
          repr: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
        },
        json: {
          id: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
          number: "2720",
          name: "Tree NFT #2720",
          description: "A unique tree from the Tree NFT collection. Rarity: Common",
          image_url: "https://black-persistent-capybara-279.mypinata.cloud/ipfs/bafybeieozgvnr7qc4ghsq36zwssuhj7xahuznjlmu6g63clnyt37hjsi4m/2720.jpg",
          rarity: "Common"
        }
      }
    }
  }
};

// contracts/nftree-generation/scripts/slot-review.mjs
var saved = { transaction: transaction_default, objects: objects_default, package: package_default, candidate: candidate_default };
var REGISTRY = saved.objects.data.o1.address;
var ADMIN = saved.objects.data.o2.address;
var GAS_BUDGET = 2e7;
function slotTransaction() {
  const tx = new Transaction3();
  tx.setSender(C.sender);
  tx.setGasBudget(GAS_BUDGET);
  tx.setGasPayment([]);
  tx.moveCall({ target: PACKAGE + "::vault::create_slot", typeArguments: [C.nftType], arguments: [tx.object(REGISTRY), tx.object(ADMIN)] });
  return tx;
}
async function readState(client) {
  const fields2 = saved.objects.data;
  const selections = Object.entries(fields2).filter(([, v]) => v?.address).map(([alias, v]) => `${alias}:object(address:"${v.address}"){address version digest owner{__typename ...on AddressOwner{address{address}} ...on Shared{initialSharedVersion}} asMoveObject{contents{type{repr} json}}}`);
  const objects = await client.query({ query: `query {chainIdentifier checkpoint{sequenceNumber timestamp} ${selections.join(" ")}}`, signal: AbortSignal.timeout(2e4) });
  const candidate = await readCandidate(client);
  verifyPublished({ ...saved, objects, candidate });
  assert3(Math.abs(Date.now() - Date.parse(objects.data.checkpoint.timestamp)) < 12e4, "Stale registry read");
  return { objects, candidate };
}
function verifySlotSimulation(result) {
  assert3.equal(result.$kind, "Transaction");
  const t = result.Transaction;
  assert3.equal(t.status.success, true);
  assert3.equal(t.transaction.sender, C.sender);
  const tx = t.transaction;
  assert3.equal(tx.commands.length, 1);
  const call = tx.commands[0].MoveCall;
  assert3.equal(call.package, PACKAGE);
  assert3.equal(call.module, "vault");
  assert3.equal(call.function, "create_slot");
  assert3.deepEqual(call.typeArguments, [C.nftType]);
  assert3.deepEqual(call.arguments.map((x) => x.Input), [0, 1]);
  assert3.equal(tx.inputs.length, 2);
  assert3.equal(tx.inputs[0].Object.SharedObject.objectId, REGISTRY);
  assert3.equal(tx.inputs[0].Object.SharedObject.mutable, true);
  assert3.equal(tx.inputs[0].Object.SharedObject.initialSharedVersion, "1");
  assert3.equal(tx.inputs[1].Object.ImmOrOwnedObject.objectId, ADMIN);
  assert3.equal(tx.inputs[1].Object.ImmOrOwnedObject.version, "1");
  assert3.equal(tx.inputs[1].Object.ImmOrOwnedObject.digest, saved.objects.data.o2.digest);
  assert3.equal(tx.gasData.owner, C.sender);
  assert3.equal(tx.gasData.budget, String(GAS_BUDGET));
  assert3.deepEqual(tx.gasData.payment, []);
  const changes = t.effects.changedObjects;
  assert3(!changes.some((x) => x.objectId === C.nft), "NFT unexpectedly touched");
  const created = changes.filter((x) => x.inputState === "DoesNotExist" && x.outputState === "ObjectWrite");
  assert3.equal(created.length, 1);
  const vault = created[0];
  assert3.equal(t.objectTypes[vault.objectId], PACKAGE + "::vault::Vault<" + C.nftType + ">");
  assert3(vault.outputOwner?.Shared);
  assert3.equal(vault.idOperation, "Created");
  for (const x of changes) {
    if (x === vault) continue;
    if (x.inputState === "Exists") {
      assert3([REGISTRY, ADMIN].includes(x.objectId), "Unexpected mutation");
      assert3.equal(x.outputState, "ObjectWrite");
      assert3.equal(x.idOperation, "None");
      if (x.objectId === ADMIN) assert3.equal(x.outputOwner?.AddressOwner, C.sender);
      else assert3(x.outputOwner?.Shared);
    } else assert3(x.inputState === "DoesNotExist" && x.outputState === "AccumulatorWriteV1" && x.idOperation === "None" && x.outputOwner === null, "Unexpected effect");
  }
  assert3(changes.some((x) => x.objectId === REGISTRY && x.inputState === "Exists"));
  assert3.equal(t.events.length, 1);
  const event = t.events[0];
  assert3.equal(event.eventType, PACKAGE + "::vault::SlotCreated");
  assert3.equal(event.packageId, PACKAGE);
  assert3.equal(event.sender, C.sender);
  assert3.equal(event.module, "vault");
  assert3.equal(event.json.registry, REGISTRY);
  assert3.equal(event.json.vault, vault.objectId);
  assert3.equal(Buffer.from(event.json.nft.bytes, "base64").toString("hex"), C.nft.slice(2));
  const validity = tx.expiration?.ValidDuring;
  assert3(validity);
  assert3.equal(validity.chain, C.chain);
  assert3.equal(BigInt(validity.maxEpoch) - BigInt(validity.minEpoch), 1n);
  const epoch = BigInt(t.epoch);
  assert3(epoch >= BigInt(validity.minEpoch) && epoch <= BigInt(validity.maxEpoch));
  const gas = t.effects.gasUsed;
  const net = BigInt(gas.computationCost) + BigInt(gas.storageCost) - BigInt(gas.storageRebate);
  assert3(net > 0n && net < BigInt(GAS_BUDGET));
  assert3.equal(t.balanceChanges.length, 1);
  const balance = t.balanceChanges[0];
  assert3.equal(balance.address, C.sender);
  assert3(/^0x0*2::sui::SUI$/.test(balance.coinType));
  assert3.equal(BigInt(balance.amount), -net);
  return { estimatedNetGasMist: String(net), simulatedVaultId: vault.objectId };
}
async function prepareSlot(client = newClient()) {
  const before = await readState(client);
  const tx = slotTransaction();
  const bytes = await tx.build({ client });
  const simulation = await client.core.simulateTransaction({ transaction: bytes, doGasSelection: false, checksEnabled: true, include: { effects: true, events: true, transaction: true, balanceChanges: true, objectTypes: true, bcs: true }, signal: AbortSignal.timeout(45e3) });
  const after = await readState(client);
  assert3.deepEqual(before.objects.data.o1, after.objects.data.o1);
  assert3.deepEqual(before.candidate.nft, after.candidate.nft);
  assert3.deepEqual(Uint8Array.from(Object.values(simulation.Transaction.bcs)), bytes);
  const proof = verifySlotSimulation(simulation);
  return { schema: "tree-empty-slot-review-v1", preparedAt: (/* @__PURE__ */ new Date()).toISOString(), authorized: false, submitted: false, ...proof, gasBudgetMist: String(GAS_BUDGET), transactionBase64: Buffer.from(bytes).toString("base64"), transactionSha256: createHash3("sha256").update(bytes).digest("hex"), before, after, simulation, warning: "Unsigned simulation only. Simulated Vault ID is not deployed. Refresh state and transaction before any separately approved signature. No NFT deposit or peer configuration." };
}
if (process.argv[1]?.endsWith("/slot-review.mjs")) {
  const dest = process.argv[2];
  assert3(dest, "Provide a new output filename");
  assert3(!fs2.existsSync(dest), "Do not overwrite prior evidence");
  const packet2 = await prepareSlot();
  fs2.writeFileSync(dest, JSON.stringify(packet2, null, 2) + "\n");
  console.log(JSON.stringify({ output: dest, gas: packet2.estimatedNetGasMist, submitted: false }));
}

// tools/generation-slot/core.mjs
import { Transaction as Transaction5 } from "@mysten/sui/transactions";

// tools/generation-publication/core.mjs
import { Transaction as Transaction4 } from "@mysten/sui/transactions";

// contracts/nftree-generation/scripts/registration-review.mjs
var C3 = Object.freeze({
  ...C,
  package: pinned_build_default.peer,
  vault: pinned_build_default.route,
  registry: pinned_build_default.registry,
  admin: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
  oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
  oappAdmin: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
  upgrade: "0xb70e2cdc18d562247bc34bf47efee620a05ec1f059cff5e812a8d433a722999d",
  endpoint: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
  endpointPackage: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
  endpointRegistry: "0x720fc2300c05bb7ad68aefec00a9796b4451c4d1df78bc72cd8c98e774220bec",
  maxGasMist: 20000000n
});

// contracts/nftree-generation/scripts/registration-handoff.mjs
import { Transaction as Transaction7 } from "@mysten/sui/transactions";

// contracts/nftree-generation/scripts/registration-bnb.mjs
import assert4 from "node:assert/strict";
import { keccak256, encodeFunctionData, decodeFunctionResult, parseAbi } from "viem";

// docs/multichain/generation-milestone/registration-handoff/bnb-code-hashes.json
var bnb_code_hashes_default = {
  "0x1a44076050125825900e736c501f859c50fe728c": "0x5ed1f4ec5f4d6bd5eac1fa92e0fb7474be2607dfc5f3eb82ced1c183b64fbeb9",
  "0x55d398326f99059ff775485246999027b3197955": "0x97a48aa4c129657440dafdacd4c836389734d28cc4a0ca7403e68da660a74a59",
  "0x418cc337fc19d8cf3b41a9c6e3138a60e34eb9b5": "0xa2fb16a830bce8f5c1e173915fb3f7ad7016be1ff9f0891b92a2921dc3ab1ef4",
  "0x74c20deb476dca58459956b1acd65771197900c9": "0x6efff3014469a796f571b62eb85981489aa5c17103595fa4557ce7c72f1e2e1b"
};

// docs/multichain/generation-milestone/bnb-deployed/user-receipt.json
var user_receipt_default = {
  chainId: 56,
  admin: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789",
  adapterAddress: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
  passAddress: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
  suiPeer: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
  route: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
  transactionHashes: [
    "0x016aa9570de26f1d25d3db2137fa1ef7dbac8e3a2efa1cab45c2e872deafee98",
    "0x9dd9e68b4c1d226e79f788d009a42cf47d4c7662ddc58b16670b4583226192b3",
    "0x6304ed426f3653eb73f6eade845c5ef1e8b2e34be5270e1ac7b3b8a4431e8ebe"
  ],
  totalGasFeeWei: "174054200000000",
  purchasesPaused: true,
  state: "Unconfirmed",
  generation: 0,
  receipts: [
    {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xc5c903",
      logs: [
        {
          address: "0x1a44076050125825900e736c501f859c50fe728c",
          topics: [
            "0x6ee10e9ed4d6ce9742703a498707862f4b00f1396a87195eb93267b3d7983981"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c9000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
          blockHash: "0x199bd9d02bef559f2fe46cb7371783009bff749d259c3ebf40337687add29236",
          blockNumber: "0x80eebfb",
          blockTimestamp: "0x6b03acce",
          transactionHash: "0x016aa9570de26f1d25d3db2137fa1ef7dbac8e3a2efa1cab45c2e872deafee98",
          transactionIndex: "0x39",
          logIndex: "0x146",
          removed: false
        }
      ],
      logsBloom: "0x00000000000000000000000000000000000000000000000000800000001000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000",
      transactionHash: "0x016aa9570de26f1d25d3db2137fa1ef7dbac8e3a2efa1cab45c2e872deafee98",
      transactionIndex: "0x39",
      blockHash: "0x199bd9d02bef559f2fe46cb7371783009bff749d259c3ebf40337687add29236",
      blockNumber: "0x80eebfb",
      gasUsed: "0x1843f6",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: null,
      contractAddress: "0x74c20deb476dca58459956b1acd65771197900c9"
    },
    {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xb74c54",
      logs: [],
      logsBloom: "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
      transactionHash: "0x9dd9e68b4c1d226e79f788d009a42cf47d4c7662ddc58b16670b4583226192b3",
      transactionIndex: "0x3d",
      blockHash: "0x0bfb4b4b76bf2933c6a302caa02af57dc5ae09c68b228cf1b520d8b3653a321e",
      blockNumber: "0x80ef3cc",
      gasUsed: "0x1c0d84",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: null,
      contractAddress: "0x418cc337fc19d8cf3b41a9c6e3138a60e34eb9b5"
    },
    {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0x1e00727",
      logs: [
        {
          address: "0x74c20deb476dca58459956b1acd65771197900c9",
          topics: [
            "0x3916d079df018feca66a550908f671cff67410227b4a8c24f13531847e12b9c8",
            "0x000000000000000000000000418cc337fc19d8cf3b41a9c6e3138a60e34eb9b5"
          ],
          data: "0x",
          blockHash: "0xc889b5f36070a5ab76f384b4283bd16e1a04651df7bdabb062777876622fe229",
          blockNumber: "0x80ef472",
          blockTimestamp: "0x6b03b09d",
          transactionHash: "0x6304ed426f3653eb73f6eade845c5ef1e8b2e34be5270e1ac7b3b8a4431e8ebe",
          transactionIndex: "0x75",
          logIndex: "0x60b",
          removed: false
        }
      ],
      logsBloom: "0x00000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000100000000000000040000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000000000000004000000",
      transactionHash: "0x6304ed426f3653eb73f6eade845c5ef1e8b2e34be5270e1ac7b3b8a4431e8ebe",
      transactionIndex: "0x75",
      blockHash: "0xc889b5f36070a5ab76f384b4283bd16e1a04651df7bdabb062777876622fe229",
      blockNumber: "0x80ef472",
      gasUsed: "0xcc82",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: "0x74c20deb476dca58459956b1acd65771197900c9",
      contractAddress: null
    }
  ]
};

// contracts/nftree-generation/scripts/registration-bnb.mjs
var EP = "0x1a44076050125825900e736c501f859c50fE728c";
async function verifyInactiveBnb(fetcher = fetch) {
  const allowed = /* @__PURE__ */ new Set(["eth_chainId", "eth_blockNumber", "eth_getCode", "eth_call", "eth_getTransactionReceipt"]);
  let id = 0;
  async function rpc(method, params = []) {
    assert4(allowed.has(method));
    const r = await fetcher("https://bsc-rpc.publicnode.com", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: ++id, method, params }), signal: AbortSignal.timeout(15e3) });
    assert4(r.ok, "BNB read HTTP " + r.status);
    const j = await r.json();
    assert4(!j.error, JSON.stringify(j.error));
    return j.result;
  }
  assert4.equal(BigInt(await rpc("eth_chainId")), 56n);
  const block = await rpc("eth_blockNumber");
  for (const [address, hash2] of Object.entries(bnb_code_hashes_default)) assert4.equal(keccak256(await rpc("eth_getCode", [address, block])), hash2, "BNB code changed");
  for (let i = 0; i < 3; i++) {
    const r = await rpc("eth_getTransactionReceipt", [user_receipt_default.transactionHashes[i]]);
    assert4(r && r.status === "0x1", "BNB receipt unavailable");
    for (const k of ["transactionHash", "blockHash", "contractAddress", "from", "to"]) assert4.equal(r[k]?.toLowerCase() ?? null, user_receipt_default.receipts[i][k]?.toLowerCase() ?? null, "BNB receipt changed");
  }
  const call = async (address, abi, functionName, args = []) => decodeFunctionResult({ abi, functionName, data: await rpc("eth_call", [{ to: address, data: encodeFunctionData({ abi, functionName, args }) }, block]) });
  assert4.equal((await call(pinned_build_default.addresses.adapter, pinned_build_default.adapter.abi, "pass")).toLowerCase(), pinned_build_default.addresses.pass.toLowerCase());
  assert4.equal((await call(pinned_build_default.addresses.pass, pinned_build_default.pass.abi, "adapter")).toLowerCase(), pinned_build_default.addresses.adapter.toLowerCase());
  assert4.equal((await call(EP, parseAbi(["function delegates(address) view returns(address)"]), "delegates", [pinned_build_default.addresses.adapter])).toLowerCase(), pinned_build_default.admin.toLowerCase());
  assert4.equal(await call(pinned_build_default.addresses.pass, pinned_build_default.pass.abi, "purchasesPaused"), true);
  assert4.equal(await call(pinned_build_default.addresses.pass, pinned_build_default.pass.abi, "state"), 0);
  assert4.equal(await call(pinned_build_default.addresses.pass, pinned_build_default.pass.abi, "generation"), 0n);
  assert4.equal(await call(pinned_build_default.addresses.pass, pinned_build_default.pass.abi, "canPlay", [pinned_build_default.admin]), false);
  return { chainId: 56, block, adapter: pinned_build_default.addresses.adapter, pass: pinned_build_default.addresses.pass, purchasesPaused: true, state: "Unconfirmed", generation: 0, canPlay: false };
}

// contracts/nftree-generation/scripts/configuration-post-state.mjs
import assert6 from "node:assert/strict";

// contracts/nftree-generation/scripts/binding-review.mjs
import { Transaction as Transaction8 } from "@mysten/sui/transactions";
var assert5 = Object.assign((v, m = "Binding validation failed") => {
  if (!v) throw Error(m);
}, { equal: (a, b, m) => {
  if (a !== b) throw Error(m || "Binding value differs");
}, deepEqual: (a, b) => {
  if (canonical(a) !== canonical(b)) throw Error("Binding structure differs");
} });
var peer = "0x" + pinned_build_default.addresses.adapter.slice(2).toLowerCase().padStart(64, "0");
var options = "00030100110100000000000000000000000000030d40";
var json2 = (o) => o.asMoveObject.contents.json;
var base64 = (h) => btoa(String.fromCharCode(...Uint8Array.from(h.replace(/^0x/, "").match(/../g), (x) => parseInt(x, 16))));
var norm = (x) => JSON.parse(JSON.stringify(x, (k, v) => k === "$kind" || k === "type" ? void 0 : ["initialSharedVersion", "version"].includes(k) ? String(v) : v));
function binding(state) {
  const v = json2(state.vault);
  assert5.equal(state.vault.address, C2.vault);
  assert5.equal(v.nft, null);
  assert5.equal(v.bound, false);
  assert5.equal(v.phase, 0);
  assert5.equal(v.generation, "0");
  for (const [name, id] of [["vaultAdmin", C2.vaultAdmin], ["admin", C2.admin]]) {
    assert5.equal(state[name].address, id);
    assert5.equal(state[name].owner.address.address, C2.sender);
  }
  assert5.equal(state.channel.address, C2.channel);
  assert5.equal(json2(state.channel).oapp, C2.package);
  assert5.equal(json2(state.channel).channels.size, "0");
  assert5.equal(String(state.channel.owner.initialSharedVersion), C2.channelVersion);
  assert5.equal(state.oapp.address, C2.oapp);
  assert5.equal(json2(state.oapp).oapp_cap.cap_type.pos0, C2.package);
  assert5.equal(json2(state.oapp).admin_cap, C2.admin);
  const t = new Transaction8();
  t.setSender(C2.sender);
  t.setGasBudget(1e8);
  t.setGasPayment([]);
  const p = t.moveCall({ target: "0x00245ba36f7a1cc643a2b037450dff1e4399e18069c6545fb5fcaaf37d39d7dc::bytes32::from_address", arguments: [t.pure.address(peer)] });
  const shared = (name, mutable) => t.sharedObjectRef({ objectId: state[name].address, initialSharedVersion: String(state[name].owner.initialSharedVersion), mutable });
  const owned = (name) => t.objectRef({ objectId: state[name].address, version: String(state[name].version), digest: state[name].digest });
  t.moveCall({ target: C2.package + "::vault::bind", typeArguments: [C2.nftType], arguments: [shared("vault", true), owned("vaultAdmin"), shared("oapp", true), owned("admin"), shared("endpoint", false), shared("channel", true), p] });
  return t;
}
function verifyBinding(result, state) {
  assert5.equal(result.$kind, "Transaction");
  const t = result.Transaction;
  assert5.equal(t.status.success, true);
  assert5.equal(t.transaction.sender, C2.sender);
  assert5.equal(t.transaction.gasData.owner, C2.sender);
  assert5(BigInt(t.transaction.gasData.budget) <= 100000000n);
  const expected = binding(state).getData();
  for (const k of ["inputs", "commands"]) assert5.equal(canonical(norm(t.transaction[k])), canonical(norm(expected[k])), k);
  const events = [
    [C2.endpointPackage + "::messaging_channel::ChannelInitializedEvent", { local_oapp: C2.package, remote_eid: 30102, remote_oapp: { bytes: base64(peer) } }],
    [C2.oappPackage + "::oapp_peer::PeerSetEvent", { oapp: C2.package, eid: 30102, peer: { bytes: base64(peer) } }],
    ...[1, 3].map((msg_type) => [C2.oappPackage + "::enforced_options::EnforcedOptionSetEvent", { oapp: C2.package, eid: 30102, msg_type, options: base64(options) }]),
    [C2.package + "::vault::Bound", { vault: C2.vault, peer: { bytes: base64(peer) } }]
  ];
  assert5.deepEqual(t.events.map((e) => [e.eventType, e.json]), events);
  const changes = t.effects.changedObjects, ids = [C2.vault, C2.vaultAdmin, C2.oapp, C2.admin, C2.channel], gasIds = /* @__PURE__ */ new Set([t.effects.gasObject?.objectId, ...t.transaction.gasData.payment.map((x) => x.objectId)]);
  for (const x of changes) {
    if (x.inputState === "Exists") {
      assert5(ids.includes(x.objectId) || gasIds.has(x.objectId), "Unexpected existing mutation");
      assert5.equal(x.outputState, "ObjectWrite");
      assert5.deepEqual(x.inputOwner, x.outputOwner);
    }
  }
  for (const [id, version] of [[C2.vault, "2"], [C2.oapp, "1"], [C2.channel, C2.channelVersion]]) assert5.equal(String(changes.find((x) => x.objectId === id)?.outputOwner?.Shared?.initialSharedVersion), version);
  for (const id of [C2.admin, C2.vaultAdmin]) assert5.equal(changes.find((x) => x.objectId === id)?.outputOwner?.AddressOwner, C2.sender);
  const parents = [json2(state.oapp).peer.peers.id, json2(state.channel).channels.id, ...Array(2).fill(json2(state.oapp).enforced_options.options.id)].sort();
  const created = changes.filter((x) => x.inputState === "DoesNotExist" && x.outputState === "ObjectWrite");
  assert5.equal(created.length, 4);
  assert5.deepEqual(created.map((x) => x.outputOwner.ObjectOwner).sort(), parents);
  for (const x of created) assert5.equal(x.idOperation, "Created");
  for (const x of changes.filter((x2) => x2.inputState === "DoesNotExist" && x2.outputState !== "ObjectWrite")) assert5(x.outputOwner === null && (x.outputState === "AccumulatorWriteV1" && x.idOperation === "None" || x.outputState === "DoesNotExist" && x.idOperation === "Created"));
  const g = t.effects.gasUsed, fee = BigInt(g.computationCost) + BigInt(g.storageCost) - BigInt(g.storageRebate);
  assert5(fee > 0n && fee <= 100000000n);
  assert5.equal(t.balanceChanges.length, 1);
  assert5.equal(t.balanceChanges[0].address, C2.sender);
  assert5(/^0x0*2::sui::SUI$/.test(t.balanceChanges[0].coinType));
  assert5.equal(BigInt(t.balanceChanges[0].amount), -fee);
  return { gasMist: String(fee), channel: C2.channel, peer, empty: true, generation: 0 };
}

// contracts/nftree-generation/scripts/configuration-post-state.mjs
var json3 = (o) => o.asMoveObject.contents.json;
var POST_QUERY = "query($tx:JSON!){simulateTransaction(transaction:$tx,checksEnabled:true,doGasSelection:false){effects{status objectChanges(first:50){pageInfo{hasNextPage} nodes{address outputState{asMoveObject{contents{type{repr} json}}}}}}}}";
function verifyPostState(kind, post, state) {
  assert6(!post.errors);
  const effects = post.data.simulateTransaction.effects;
  assert6.equal(effects.status, "SUCCESS");
  assert6.equal(effects.objectChanges.pageInfo.hasNextPage, false);
  const nodes = effects.objectChanges.nodes, objects = Object.fromEntries(nodes.filter((n) => n.outputState?.asMoveObject).map((n) => [n.address, json3(n.outputState)]));
  if (kind === "configuration") {
    const values = { appLibraries: { send_lib: C2.ulnPackage, receive_lib: C2.ulnPackage, receive_lib_timeout: null }, appExecutor: { max_message_size: "10000", executor: C2.executor }, appSend: ulnValue(5), appReceive: ulnValue(20) };
    for (const [n, e] of Object.entries(entries)) assert6.deepEqual(objects[e.id].value, values[n]);
    const registration2 = structuredClone(json3(state.registration));
    registration2.value.oapp_info = metadataBase64();
    assert6.deepEqual(objects[C2.registration], registration2);
  } else {
    assert6.equal(kind, "binding");
    const v = structuredClone(json3(state.vault));
    v.bound = true;
    v.peer = { bytes: Buffer.from(peer.slice(2), "hex").toString("base64") };
    assert6.deepEqual(objects[C2.vault], v);
    const o = structuredClone(json3(state.oapp));
    o.peer.peers.size = "1";
    o.enforced_options.options.size = "2";
    assert6.deepEqual(objects[C2.oapp], o);
    const channel = structuredClone(json3(state.channel));
    channel.channels.size = "1";
    assert6.deepEqual(objects[C2.channel], channel);
    const fields2 = Object.values(objects).filter((x) => Object.hasOwn(x, "name"));
    assert6.equal(fields2.length, 4);
    const p = fields2.find((x) => x.name === 30102);
    assert6.deepEqual(p.value, v.peer);
    for (const msg_type of [1, 3]) assert6.equal(fields2.find((x) => x.name.eid === 30102 && x.name.msg_type === msg_type).value, Buffer.from(options, "hex").toString("base64"));
    const ch = fields2.find((x) => x.name.remote_eid === 30102);
    assert6.deepEqual(ch.name.remote_oapp, v.peer);
    assert6.equal(ch.value.outbound_nonce, "0");
    assert6.equal(ch.value.lazy_inbound_nonce, "0");
    assert6.equal(ch.value.inbound_payload_hashes.size, "0");
  }
  return { postStateVerified: true };
}

// contracts/nftree-generation/scripts/binding-bnb.mjs
import assert7 from "node:assert/strict";

// docs/multichain/generation-milestone/bnb-configuration-completed/verified/rpc-reads.json
var rpc_reads_default = [
  {
    method: "eth_chainId",
    params: [],
    result: "0x38"
  },
  {
    method: "eth_getCode",
    params: [
      "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789",
      "latest"
    ],
    result: "0x"
  },
  {
    method: "eth_getCode",
    params: [
      "0x1a44076050125825900e736c501f859c50fE728c",
      "latest"
    ],
    result: "0x6080604052600436106103605760003560e01c80639132e5c3116101c6578063c9fc7bcd116100f7578063ddc28c5811610095578063e8964e811161006f578063e8964e8114610bc0578063ef667aa114610be0578063f2fde38b14610c2b578063f64be4c714610c4b57600080fd5b8063ddc28c5814610b5f578063e1758bd814610b8c578063e4fe1d9414610ba057600080fd5b8063d4b4ec8f116100d1578063d4b4ec8f14610aa3578063d70b890214610ac3578063dc706a6214610ae3578063dc93c8a214610b1357600080fd5b8063c9fc7bcd14610a27578063ca5eb5e114610a6e578063cb5026b914610a8e57600080fd5b8063a7229fd911610164578063aafea3121161013e578063aafea312146109a7578063b96a277f146109c7578063c28e0eed146109e7578063c9a54a9914610a0757600080fd5b8063a7229fd914610947578063a825d74714610967578063aafe5e071461098757600080fd5b80639c6d7340116101a05780639c6d73401461089f5780639d7f9775146108e7578063a0dd43fc14610907578063a718531b1461092757600080fd5b80639132e5c31461084a57806391d20fa11461086c5780639535ff301461087f57600080fd5b80635b17bb70116102a05780636f50a8031161023e57806379624ca91161021857806379624ca9146107d35780637cb59012146107ec578063861e1ca51461080c5780638da5cb5b1461082c57600080fd5b80636f50a80314610754578063715018a61461078a578063733180911461079f57600080fd5b80636a14d7151161027a5780636a14d715146106955780636bf73fa3146106b55780636dbd9f90146106d55780636e83f5bb146106f557600080fd5b80635b17bb70146105e45780636750cd4c14610645578063697fe6b61461067557600080fd5b80632baf0be71161030d578063402f8468116102e7578063402f8468146104ee57806340f806831461052d578063416ecebf1461054d578063587cde1e1461059657600080fd5b80632baf0be7146104455780632e80fbf31461048757806335d330b0146104a757600080fd5b80632637a4501161033e5780632637a450146103d85780632a56c1b0146103f85780632b3197b91461041857600080fd5b80630c0c389e1461036557806314f651a91461037a578063183c834f146103b8575b600080fd5b610378610373366004614bce565b610c81565b005b34801561038657600080fd5b5061038f610d98565b6040805163ffffffff90931683526001600160a01b039091166020830152015b60405180910390f35b3480156103c457600080fd5b506103786103d3366004614c7e565b610dca565b6103eb6103e6366004614cc9565b611155565b6040516103af9190614d1c565b34801561040457600080fd5b50610378610413366004614d5f565b6112be565b34801561042457600080fd5b50610438610433366004614dcf565b61137c565b6040516103af9190614e91565b34801561045157600080fd5b506104797fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff81565b6040519081526020016103af565b34801561049357600080fd5b506103786104a2366004614ebc565b611497565b3480156104b357600080fd5b506104796104c2366004614f23565b600c60209081526000948552604080862082529385528385208152918452828420909152825290205481565b3480156104fa57600080fd5b5061050e610509366004614f65565b61166e565b604080516001600160a01b0390931683529015156020830152016103af565b34801561053957600080fd5b50610378610548366004614ebc565b611705565b34801561055957600080fd5b506105817f000000000000000000000000000000000000000000000000000000000000759681565b60405163ffffffff90911681526020016103af565b3480156105a257600080fd5b506105cc6105b1366004614f8f565b600f602052600090815260409020546001600160a01b031681565b6040516001600160a01b0390911681526020016103af565b3480156105f057600080fd5b5061062c6105ff366004614faa565b600160209081526000938452604080852082529284528284209052825290205467ffffffffffffffff1681565b60405167ffffffffffffffff90911681526020016103af565b34801561065157600080fd5b50610665610660366004614fe6565b6118b5565b60405190151581526020016103af565b34801561068157600080fd5b50610378610690366004615001565b611905565b3480156106a157600080fd5b506103786106b0366004614c7e565b61197a565b3480156106c157600080fd5b506103786106d03660046150ff565b611e7a565b3480156106e157600080fd5b506103786106f03660046151e3565b611ee4565b34801561070157600080fd5b50610735610710366004614fe6565b600b60205260009081526040902080546001909101546001600160a01b039091169082565b604080516001600160a01b0390931683526020830191909152016103af565b34801561076057600080fd5b506105cc61076f366004614fe6565b600a602052600090815260409020546001600160a01b031681565b34801561079657600080fd5b50610378611fb8565b3480156107ab57600080fd5b506105cc7f0000000000000000000000001ccbf0db9c192d969de57e25b3ff09a25bb1d86281565b3480156107df57600080fd5b50600d5460011415610665565b3480156107f857600080fd5b50610378610807366004615274565b611fcc565b34801561081857600080fd5b506106656108273660046152c6565b6120d1565b34801561083857600080fd5b506000546001600160a01b03166105cc565b34801561085657600080fd5b5061085f61213e565b6040516103af91906152f1565b61037861087a36600461533e565b6121a0565b34801561088b57600080fd5b5061037861089a3660046153e9565b612362565b3480156108ab57600080fd5b5061062c6108ba366004614faa565b600360209081526000938452604080852082529284528284209052825290205467ffffffffffffffff1681565b3480156108f357600080fd5b506106656109023660046153e9565b61265b565b34801561091357600080fd5b5061062c610922366004614faa565b612735565b34801561093357600080fd5b5061037861094236600461542c565b6127ce565b34801561095357600080fd5b50610378610962366004615458565b612bd7565b34801561097357600080fd5b50610378610982366004615476565b612bef565b34801561099357600080fd5b506104796109a2366004614faa565b612d87565b3480156109b357600080fd5b506103786109c23660046154b3565b612e96565b3480156109d357600080fd5b506105cc6109e2366004614f65565b613154565b3480156109f357600080fd5b50610378610a02366004614f8f565b6131dc565b348015610a1357600080fd5b50610665610a223660046152c6565b613251565b348015610a3357600080fd5b50610479610a423660046154cf565b600260209081526000948552604080862082529385528385208152918452828420909152825290205481565b348015610a7a57600080fd5b50610378610a89366004614f8f565b6132b7565b348015610a9a57600080fd5b50610479600081565b348015610aaf57600080fd5b50610378610abe36600461542c565b61332f565b348015610acf57600080fd5b50610378610ade3660046154cf565b613633565b348015610aef57600080fd5b50610665610afe366004614f8f565b60056020526000908152604090205460ff1681565b348015610b1f57600080fd5b50610665610b2e366004614f65565b6001600160a01b03918216600090815260066020908152604080832063ffffffff9490941683529290522054161590565b348015610b6b57600080fd5b50610b7f610b7a366004614cc9565b613756565b6040516103af9190615511565b348015610b9857600080fd5b5060006105cc565b348015610bac57600080fd5b50600e546105cc906001600160a01b031681565b348015610bcc57600080fd5b50610378610bdb366004614f8f565b613a81565b348015610bec57600080fd5b50610735610bfb366004614f65565b6008602090815260009283526040808420909152908252902080546001909101546001600160a01b039091169082565b348015610c3757600080fd5b50610378610c46366004614f8f565b613c7f565b348015610c5757600080fd5b506105cc610c66366004614fe6565b6009602052600090815260409020546001600160a01b031681565b610cd086610c9260208a018a614fe6565b60208a0135610ca760608c0160408d01615528565b898989604051602001610cbc93929190615543565b604051602081830303815290604052613d29565b506040517f13137d650000000000000000000000000000000000000000000000000000000081526001600160a01b038716906313137d65903490610d24908b908a908a908a9033908b908b906004016155e0565b6000604051808303818588803b158015610d3d57600080fd5b505af1158015610d51573d6000803e3d6000fd5b50505050507f3cd5e48f9730b129dc7550f0fcea9c767b7be37837cd10e55eb35f734f4bca048787604051610d87929190615637565b60405180910390a150505050505050565b600080610da8600d546001141590565b610db457600080610dc2565b610dc2600d5460a081901c91565b915091509091565b6001600160a01b038216600090815260056020526040902054829060ff16610e1e576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b826001600160a01b03811615610eda576000816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa158015610e6e573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190610e92919061568a565b6002811115610ea357610ea361565b565b03610eda576040517f84ead63600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b83856001600160a01b03821615610fa8576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa158015610f4e573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190610f7291906156b9565b610fa8576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610fb188613f6c565b6000610fbd898961166e565b9150508015610ff8576040517f3c075f7500000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b85600003611058576001600160a01b038916600090815260086020908152604080832063ffffffff8c168452909152812080547fffffffffffffffffffffffff0000000000000000000000000000000000000000168155600101556110ef565b438611611091576040517f05df9f2200000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03898116600090815260086020908152604080832063ffffffff8d168452909152902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000169189169190911781556001018690555b604080516001600160a01b03808c16825263ffffffff8b166020830152891691810191909152606081018790527f4e0a5bbfa0c11a64effb1ada324b5437a17272e1aed9320398715ef71bb20928906080015b60405180910390a1505050505050505050565b61115d614b15565b61116a6020840184614fe6565b336001600d54146111a7576040517fee120b0900000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b77ffffffff000000000000000000000000000000000000000060a083811b919091166001600160a01b03831617600d556111e6908601608087016156d6565b80156111fb5750600e546001600160a01b0316155b15611232576040517f5af6d2aa00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60008061123f3388613fd6565b91509150600061124c3490565b9050600061126861126360a08b0160808c016156d6565b6142ba565b905061127984604001518383614388565b600e5460408501516020015161129b916001600160a01b03169083868c6143ef565b6040840151516112ad9083858b61441c565b50506001600d555095945050505050565b6112c785613f6c565b60008383836040516020016112de93929190615543565b604080517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0818403018152919052905061133a8661131f6020880188614fe6565b602088013561133460608a0160408b01615528565b85613d29565b507f3cd5e48f9730b129dc7550f0fcea9c767b7be37837cd10e55eb35f734f4bca04858760405161136c929190615637565b60405180910390a1505050505050565b6001600160a01b038316600090815260056020526040902054606090849060ff166113d3576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040517f9c33abf700000000000000000000000000000000000000000000000000000000815263ffffffff80861660048301526001600160a01b0388811660248401529085166044830152861690639c33abf790606401600060405180830381865afa158015611447573d6000803e3d6000fd5b505050506040513d6000823e601f3d9081017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe016820160405261148d91908101906157be565b9695505050505050565b6114a085613f6c565b6001600160a01b038516600090815260026020908152604080832063ffffffff881684528252808320868452825280832067ffffffffffffffff8616845290915290205481811461152c576040517f7182306f00000000000000000000000000000000000000000000000000000000815260048101829052602481018390526044015b60405180910390fd5b6001600160a01b038616600090815260016020908152604080832063ffffffff89168452825280832087845290915290205467ffffffffffffffff90811690841611801590611579575080155b156115bc576040517fc09b635000000000000000000000000000000000000000000000000000000000815267ffffffffffffffff84166004820152602401611523565b6001600160a01b038616600081815260026020908152604080832063ffffffff8a16808552908352818420898552835281842067ffffffffffffffff8916808652908452938290207fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff905581519081529182018890528101929092526060820152608081018390527faf0450c392c4f702515a457a362328c8aa21916048ca6d0419e248b30cb552929060a00161136c565b6001600160a01b03808316600090815260076020908152604080832063ffffffff8616845290915281205490911690816116fe5763ffffffff83166000908152600a60205260409020546001600160a01b03169150816116fa576040517f78e84d0600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b5060015b9250929050565b61170e85613f6c565b6001600160a01b038516600090815260026020908152604080832063ffffffff881684528252808320868452825280832067ffffffffffffffff86168452909152902054818114611795576040517f7182306f0000000000000000000000000000000000000000000000000000000081526004810182905260248101839052604401611523565b8015806117e057506001600160a01b038616600090815260016020908152604080832063ffffffff89168452825280832087845290915290205467ffffffffffffffff908116908416115b15611823576040517fc09b635000000000000000000000000000000000000000000000000000000000815267ffffffffffffffff84166004820152602401611523565b6001600160a01b038616600081815260026020908152604080832063ffffffff8a16808552908352818420898552835281842067ffffffffffffffff89168086529084528285209490945581519081529182018890528101929092526060820152608081018390527f7f68a37a6e69a0de35024a234558f9efe4b33b58657753d21eaaa82d51c3510e9060a00161136c565b63ffffffff81166000908152600960205260408120546001600160a01b0316158015906118ff575063ffffffff82166000908152600a60205260409020546001600160a01b031615155b92915050565b336001600160a01b03168b6001600160a01b03168d6001600160a01b03167f8a0b1dce321c5c5fb42349bce46d18087c04140de520917661fb923e44a904b98d8d8d8d8d8d8d8d8d8d6040516119649a999897969594939291906157f3565b60405180910390a4505050505050505050505050565b6001600160a01b038216600090815260056020526040902054829060ff161580156119ad57506001600160a01b03811615155b156119e4576040517fa4ff2ec300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b826001600160a01b03811615611aa0576000816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa158015611a34573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190611a58919061568a565b6002811115611a6957611a6961565b565b03611aa0576040517f84ead63600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b83856001600160a01b03821615611b6e576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa158015611b14573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190611b3891906156b9565b611b6e576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b611b7788613f6c565b6001600160a01b03808916600090815260076020908152604080832063ffffffff8c16845290915290205481169087168103611bdf576040517fd0ecb66b00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03898116600081815260076020908152604080832063ffffffff8e168085529083529281902080547fffffffffffffffffffffffff000000000000000000000000000000000000000016958d1695861790558051938452908301919091528101919091527fcd6f92f5ac6185a5acfa02c92090746cec64d777269cbcd0ed031e396657a1c29060600160405180910390a18515611dcf576001600160a01b0381161580611c9a57506001600160a01b038716155b15611cd1576040517f3c075f7500000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60006040518060400160405280836001600160a01b031681526020018843611cf9919061588b565b90526001600160a01b03808c16600090815260086020908152604080832063ffffffff8f1684528252918290208451815494167fffffffffffffffffffffffff00000000000000000000000000000000000000009094169390931783558301516001909201829055519192507f4e0a5bbfa0c11a64effb1ada324b5437a17272e1aed9320398715ef71bb2092891611dc1918d918d9187916001600160a01b03948516815263ffffffff93909316602084015292166040820152606081019190915260800190565b60405180910390a150611e6f565b6001600160a01b03898116600081815260086020908152604080832063ffffffff8e1680855290835281842080547fffffffffffffffffffffffff00000000000000000000000000000000000000001681556001018490558151948552918401919091529284169282019290925260608101919091527f4e0a5bbfa0c11a64effb1ada324b5437a17272e1aed9320398715ef71bb2092890608001611142565b505050505050505050565b336001600160a01b03168a6001600160a01b03167f7edfa10fe10193301ad8a8bea7e968c7bcabcc64981f368e3aeada40ce26ae2c8d8c8c8c8c8c8c8c8c8c604051611ecf9a9998979695949392919061589e565b60405180910390a35050505050505050505050565b6001600160a01b038316600090815260056020526040902054839060ff16611f38576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b611f4185613f6c565b6040517f20efd7220000000000000000000000000000000000000000000000000000000081526001600160a01b038516906320efd72290611f8a908890879087906004016158fd565b600060405180830381600087803b158015611fa457600080fd5b505af1158015611e6f573d6000803e3d6000fd5b611fc0614446565b611fca60006144ba565b565b336000908152600c602090815260408083206001600160a01b03891684528252808320878452825280832061ffff871684529091529020541561203b576040517f1508219400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b818160405161204b929190615a4e565b60408051918290038220336000818152600c60209081528482206001600160a01b038c16835281528482208a8352815284822061ffff8a168352905292909220557f3d52ff888d033fd3dd1d8057da59e850c91d91a72c41dfa445b247dfedeb6dc1916120c2919088908890889088908890615a5e565b60405180910390a15050505050565b6001600160a01b038116600090815260016020908152604082206121379185918591859061210190850185614fe6565b63ffffffff1681526020808201929092526040908101600090812089840135825290925290205467ffffffffffffffff16614522565b9392505050565b6060600480548060200260200160405190810160405280929190818152602001828054801561219657602002820191906000526020600020905b81546001600160a01b03168152600190910190602001808311612178575b5050505050905090565b6001600160a01b038089166000908152600c60209081526040808320938b168352928152828220898352815282822061ffff8916835290528181205491516121eb9087908790615a4e565b60405180910390209050808214612238576040517f35ca595f0000000000000000000000000000000000000000000000000000000081526004810183905260248101829052604401611523565b6001600160a01b03808b166000908152600c60209081526040808320938d168084529382528083208c8452825280832061ffff8c1684529091529081902060019055517fd0a1026000000000000000000000000000000000000000000000000000000000815263d0a102609034906122c0908e908d908c908c9033908d908d90600401615aa7565b6000604051808303818588803b1580156122d957600080fd5b505af11580156122ed573d6000803e3d6000fd5b50505050507e36c98efcf9e6641dfbc9051f66f405253e8e0c2ab4a24dccda15595b7378c88a8a8a8a60405161234e94939291906001600160a01b039485168152929093166020830152604082015261ffff91909116606082015260800190565b60405180910390a150505050505050505050565b6001600160a01b038116600090815260056020526040902054819060ff1615801561239557506001600160a01b03811615155b156123cc576040517fa4ff2ec300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b816001600160a01b03811615612488576001816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa15801561241c573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190612440919061568a565b60028111156124515761245161565b565b03612488576040517f7a01ede200000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b82846001600160a01b03821615612556576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa1580156124fc573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061252091906156b9565b612556576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b61255f87613f6c565b6001600160a01b03878116600090815260066020908152604080832063ffffffff8b1684529091529020548187169116036125c6576040517fd0ecb66b00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03878116600081815260066020908152604080832063ffffffff8c168085529083529281902080547fffffffffffffffffffffffff000000000000000000000000000000000000000016958b1695861790558051938452908301919091528101919091527f4cff966ebee29a156dcb34cf72c1d06231fb1777f6bdf6e8089819232f002b1c90606001610d87565b600080600061266a868661166e565b91509150816001600160a01b0316846001600160a01b03160361269257600192505050612137565b6000816126c7576001600160a01b038716600090815260086020908152604080832063ffffffff8a16845290915290206126dd565b63ffffffff86166000908152600b602052604090205b6040805180820190915281546001600160a01b03908116808352600190930154602083015290925086161480156127175750438160200151115b156127285760019350505050612137565b5060009695505050505050565b6001600160a01b038316600090815260016020908152604080832063ffffffff86168452825280832084845290915281205467ffffffffffffffff165b6001600160a01b038516600090815260026020908152604080832063ffffffff881684528252808320868452825280832067ffffffffffffffff60018601168452909152902054156127c657600101612772565b949350505050565b6127d6614446565b6001600160a01b038216600090815260056020526040902054829060ff1661282a576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b826001600160a01b038116156128e6576000816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa15801561287a573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061289e919061568a565b60028111156128af576128af61565b565b036128e6576040517f84ead63600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b83856001600160a01b038216156129b4576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa15801561295a573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061297e91906156b9565b6129b4576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b63ffffffff87166000908152600a60205260409020546001600160a01b039081169087168103612a10576040517fd0ecb66b00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b63ffffffff88166000818152600a602090815260409182902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b038c169081179091558251938452908301527fc16891855cffb4a5ac51ac11864a3f3c96ba816cc45fe686c987ae36277de5ec910160405180910390a18515612b425763ffffffff88166000908152600b6020526040902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b038316178155612ae7874361588b565b600182018190556040805163ffffffff8c1681526001600160a01b038516602082015280820192909252517f55b28633cdb29709386f555dfc54418592ad475ce7a65a78ac5928af60ffb8f89181900360600190a150612bcd565b63ffffffff88166000818152600b6020908152604080832080547fffffffffffffffffffffffff000000000000000000000000000000000000000016815560010183905580519384526001600160a01b038516918401919091528201527f55b28633cdb29709386f555dfc54418592ad475ce7a65a78ac5928af60ffb8f89060600160405180910390a15b5050505050505050565b612bdf614446565b612bea8383836145bd565b505050565b612c0682612c006020860186614fe6565b3361265b565b612c3c576040517f4fa6ecac00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03821660009081526001602090815260408220908290612c6590870187614fe6565b63ffffffff1681526020808201929092526040908101600090812087840135825290925290205467ffffffffffffffff169050612ca3848483614522565b612cd9576040517f751cb20f00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b612ce48484836145e0565b612d1a576040517f0177e1ca00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b612d4683612d2b6020870187614fe6565b6020870135612d406060890160408a01615528565b866146a0565b7f0d87345f3d1c929caba93e1c3821b54ff3512e12b66aa3cfe54b6bcbc17e59b4848484604051612d7993929190615afb565b60405180910390a150505050565b6001600160a01b038316600090815260036020908152604080832063ffffffff8616845282528083208484529091528120548190612dd09067ffffffffffffffff166001615b23565b604080517fffffffffffffffff00000000000000000000000000000000000000000000000060c084901b166020808301919091527fffffffff000000000000000000000000000000000000000000000000000000007f000000000000000000000000000000000000000000000000000000000000759660e090811b821660288501526001600160a01b038b16602c85015289901b16604c830152605080830188905283518084039091018152607090920190925280519101209091505b95945050505050565b612e9e614446565b6001600160a01b038116600090815260056020526040902054819060ff16612ef2576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b816001600160a01b03811615612fae576001816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa158015612f42573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190612f66919061568a565b6002811115612f7757612f7761565b565b03612fae576040517f7a01ede200000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b82846001600160a01b0382161561307c576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa158015613022573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061304691906156b9565b61307c576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b63ffffffff86166000908152600960205260409020546001600160a01b038087169116036130d6576040517fd0ecb66b00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b63ffffffff861660008181526009602090815260409182902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b038a169081179091558251938452908301527f16aa0f528038ab41019e95bae5b418a50ba8532c5800e3b7ea2f517d3fa625f5910161136c565b6001600160a01b03808316600090815260066020908152604080832063ffffffff8616845290915290205416806118ff575063ffffffff81166000908152600960205260409020546001600160a01b0316806118ff576040517f6c1ccdb500000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6131e4614446565b600e80547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b0383169081179091556040519081527fd476ec5ec1ac11cec3714d41e7ea49419471aceb9bd0dff1becfc3e363a62396906020015b60405180910390a150565b6001600160a01b038116600090815260016020908152604082206121379185918591859061328190850185614fe6565b63ffffffff1681526020808201929092526040908101600090812089840135825290925290205467ffffffffffffffff166145e0565b336000818152600f602090815260409182902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b0386169081179091558251938452908301527f6ee10e9ed4d6ce9742703a498707862f4b00f1396a87195eb93267b3d79839819101613246565b6001600160a01b038216600090815260056020526040902054829060ff16613383576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b826001600160a01b0381161561343f576000816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156133d3573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906133f7919061568a565b60028111156134085761340861565b565b0361343f576040517f84ead63600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b83856001600160a01b0382161561350d576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa1580156134b3573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906134d791906156b9565b61350d576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b613515614446565b846000036135615763ffffffff87166000908152600b6020526040812080547fffffffffffffffffffffffff0000000000000000000000000000000000000000168155600101556135e7565b43851161359a576040517f05df9f2200000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b63ffffffff87166000908152600b6020526040902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b0388161781556001018590555b6040805163ffffffff891681526001600160a01b03881660208201529081018690527f55b28633cdb29709386f555dfc54418592ad475ce7a65a78ac5928af60ffb8f890606001610d87565b61363c84613f6c565b613647848484612735565b613652906001615b23565b67ffffffffffffffff168167ffffffffffffffff16146136aa576040517fc09b635000000000000000000000000000000000000000000000000000000000815267ffffffffffffffff82166004820152602401611523565b6001600160a01b038416600081815260016020908152604080832063ffffffff881680855290835281842087855283529281902080547fffffffffffffffffffffffffffffffffffffffffffffffff00000000000000001667ffffffffffffffff8716908117909155815193845291830186905282019290925260608101919091527f28f40053783033ef755556a0c3315379141f51a33aed8334174ffbadd90bde4890608001612d79565b604080518082019091526000808252602082015261377a60a08401608085016156d6565b801561378f5750600e546001600160a01b0316155b156137c6576040517f5af6d2aa00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b038216600090815260036020908152604082209082906137ef90870187614fe6565b63ffffffff1681526020808201929092526040908101600090812087840135825290925290205461382b9067ffffffffffffffff166001615b23565b905060006040518060e001604052808367ffffffffffffffff1681526020017f000000000000000000000000000000000000000000000000000000000000759663ffffffff168152602001856001600160a01b031681526020018660000160208101906138989190614fe6565b63ffffffff16815260200186602001358152602001613994847f0000000000000000000000000000000000000000000000000000000000007596888a60000160208101906138e69190614fe6565b8b60200135600085856001600160a01b03861660405160c09390931b7fffffffffffffffff00000000000000000000000000000000000000000000000016602084015260e091821b7fffffffff000000000000000000000000000000000000000000000000000000009081166028850152602c8401919091529085901b16604c8201526050810183905260700160405160208183030381529060405280519060200120905095945050505050565b81526020016139a66040880188615b44565b8080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920182905250939094525092935091506139f39050856109e26020890189614fe6565b90506001600160a01b03811663d80e9bd983613a1260608a018a615b44565b613a2260a08c0160808d016156d6565b6040518563ffffffff1660e01b8152600401613a419493929190615ba9565b6040805180830381865afa158015613a5d573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061148d9190615ca0565b613a89614446565b6040517f01ffc9a70000000000000000000000000000000000000000000000000000000081527f97f025840000000000000000000000000000000000000000000000000000000060048201526001600160a01b038216906301ffc9a790602401602060405180830381865afa158015613b06573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190613b2a91906156b9565b613b60576040517feb64f35d00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03811660009081526005602052604090205460ff1615613bb3576040517f8aea2fe600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b038116600081815260056020908152604080832080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff001660019081179091556004805491820181559093527f8a35acfbc15ff81a39ae7d344fd709f28e8600b4aa8c65c6b64bfe7fe36bd19b90920180547fffffffffffffffffffffffff0000000000000000000000000000000000000000168417905590519182527f6b374d56679ca9463f27c85c6311e2bb7fde69bf201d3da39d53f10bd9d78af59101613246565b613c87614446565b6001600160a01b038116613d1d576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602660248201527f4f776e61626c653a206e6577206f776e657220697320746865207a65726f206160448201527f64647265737300000000000000000000000000000000000000000000000000006064820152608401611523565b613d26816144ba565b50565b6001600160a01b038516600090815260016020908152604080832063ffffffff88168452825280832086845290915281205467ffffffffffffffff908116908416811015613e8457600181015b8467ffffffffffffffff168167ffffffffffffffff1611613e1f576001600160a01b038816600090815260026020908152604080832063ffffffff8b1684528252808320898452825280832067ffffffffffffffff85168452909152902054613e17576040517fc09b635000000000000000000000000000000000000000000000000000000000815267ffffffffffffffff82166004820152602401611523565b600101613d76565b506001600160a01b038716600090815260016020908152604080832063ffffffff8a1684528252808320888452909152902080547fffffffffffffffffffffffffffffffffffffffffffffffff00000000000000001667ffffffffffffffff86161790555b82516020808501919091206001600160a01b038916600090815260028352604080822063ffffffff8b1683528452808220898352845280822067ffffffffffffffff891683529093529190912054909250808314613f18576040517f7182306f0000000000000000000000000000000000000000000000000000000081526004810182905260248101849052604401611523565b50506001600160a01b03909516600090815260026020908152604080832063ffffffff909716835295815285822094825293845284812067ffffffffffffffff909316815291909252918220919091555090565b336001600160a01b03821614801590613f9f57506001600160a01b038181166000908152600f6020526040902054163314155b15613d26576040517fc4c5259300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b613fde614b15565b60008061406785613ff26020870187614fe6565b6001600160a01b0391909116600090815260036020908152604080832063ffffffff94909416835292815282822081890135835290522080547fffffffffffffffffffffffffffffffffffffffffffffffff00000000000000008116600167ffffffffffffffff928316019182161790915590565b905060006040518060e001604052808367ffffffffffffffff1681526020017f000000000000000000000000000000000000000000000000000000000000759663ffffffff168152602001876001600160a01b031681526020018660000160208101906140d49190614fe6565b63ffffffff16815260200186602001358152602001614122847f00000000000000000000000000000000000000000000000000000000000075968a8a60000160208101906138e69190614fe6565b81526020016141346040880188615b44565b8080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920182905250939094525092935091506141819050876109e26020890189614fe6565b90506000806001600160a01b038316634389e58f856141a360608c018c615b44565b6141b360a08e0160808f016156d6565b6040518563ffffffff1660e01b81526004016141d29493929190615ba9565b6000604051808303816000875af11580156141f1573d6000803e3d6000fd5b505050506040513d6000823e601f3d9081017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe01682016040526142379190810190615cbc565b90925090507f1ab700d4ced0c005b164c0f789fd09fcbb0156d4c2041b8a3bfbcd961cd1567f8161426b60608b018b615b44565b8660405161427c9493929190615d0b565b60405180910390a1506040805160608101825260a090940151845267ffffffffffffffff909416602084015292820192909252925090509250929050565b6000811561438357600e546040517f70a082310000000000000000000000000000000000000000000000000000000081523060048201526001600160a01b03909116906370a0823190602401602060405180830381865afa158015614323573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906143479190615d4c565b905080600003614383576040517f1775123700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b919050565b825182108061439a5750808360200151115b15612bea57825160208401516040517f4f3ec0d3000000000000000000000000000000000000000000000000000000008152600481019290925260248201849052604482015260648101829052608401611523565b831561440057614400858386614720565b82841015614415576144158582868603614720565b5050505050565b831561442c5761442c8285614774565b828410156144405761444081858503614774565b50505050565b6000546001600160a01b03163314611fca576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820181905260248201527f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e65726044820152606401611523565b600080546001600160a01b038381167fffffffffffffffffffffffff0000000000000000000000000000000000000000831681178455604051919092169283917f8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e09190a35050565b6000808267ffffffffffffffff1611806127c657506040517fff7bd03d0000000000000000000000000000000000000000000000000000000081526001600160a01b0384169063ff7bd03d9061457c908790600401615d65565b602060405180830381865afa158015614599573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906127c691906156b9565b6001600160a01b0383166145d557612bea8282614774565b612bea838383614720565b600067ffffffffffffffff82166145fd6060860160408701615528565b67ffffffffffffffff1611806127c657506001600160a01b0383166000908152600260209081526040822090829061463790880188614fe6565b63ffffffff1663ffffffff168152602001908152602001600020600086602001358152602001908152602001600020600086604001602081019061467b9190615528565b67ffffffffffffffff1681526020810191909152604001600020541415949350505050565b806146d7576040517f09beffb600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03909416600090815260026020908152604080832063ffffffff909616835294815284822093825292835283812067ffffffffffffffff909216815291522055565b6001600160a01b038216614760576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b612bea6001600160a01b0384168383614853565b6001600160a01b0382166147b4576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6000826001600160a01b03168260405160006040518083038185875af1925050503d8060008114614801576040519150601f19603f3d011682016040523d82523d6000602084013e614806565b606091505b5050905080612bea576040517f465bc8340000000000000000000000000000000000000000000000000000000081526001600160a01b038416600482015260248101839052604401611523565b604080516001600160a01b03848116602483015260448083018590528351808403909101815260649092018352602080830180517bffffffffffffffffffffffffffffffffffffffffffffffffffffffff167fa9059cbb0000000000000000000000000000000000000000000000000000000017905283518085019094528084527f5361666545524332303a206c6f772d6c6576656c2063616c6c206661696c656490840152612bea928692916000916149119185169084906149be565b905080516000148061493257508080602001905181019061493291906156b9565b612bea576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602a60248201527f5361666545524332303a204552433230206f7065726174696f6e20646964206e60448201527f6f742073756363656564000000000000000000000000000000000000000000006064820152608401611523565b60606127c6848460008585600080866001600160a01b031685876040516149e59190615d73565b60006040518083038185875af1925050503d8060008114614a22576040519150601f19603f3d011682016040523d82523d6000602084013e614a27565b606091505b5091509150614a3887838387614a43565b979650505050505050565b60608315614acc578251600003614ac5576001600160a01b0385163b614ac5576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601d60248201527f416464726573733a2063616c6c20746f206e6f6e2d636f6e74726163740000006044820152606401611523565b50816127c6565b6127c68383815115614ae15781518083602001fd5b806040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016115239190614e91565b604051806060016040528060008019168152602001600067ffffffffffffffff168152602001614b58604051806040016040528060008152602001600081525090565b905290565b600060608284031215614b6f57600080fd5b50919050565b80356001600160a01b038116811461438357600080fd5b60008083601f840112614b9e57600080fd5b50813567ffffffffffffffff811115614bb657600080fd5b6020830191508360208285010111156116fe57600080fd5b600080600080600080600060e0888a031215614be957600080fd5b614bf38989614b5d565b9650614c0160608901614b75565b95506080880135945060a088013567ffffffffffffffff80821115614c2557600080fd5b614c318b838c01614b8c565b909650945060c08a0135915080821115614c4a57600080fd5b50614c578a828b01614b8c565b989b979a50959850939692959293505050565b803563ffffffff8116811461438357600080fd5b60008060008060808587031215614c9457600080fd5b614c9d85614b75565b9350614cab60208601614c6a565b9250614cb960408601614b75565b9396929550929360600135925050565b60008060408385031215614cdc57600080fd5b823567ffffffffffffffff811115614cf357600080fd5b830160a08186031215614d0557600080fd5b9150614d1360208401614b75565b90509250929050565b60006080820190508251825267ffffffffffffffff60208401511660208301526040830151614d58604084018280518252602090810151910152565b5092915050565b600080600080600060c08688031215614d7757600080fd5b614d8086614b75565b9450614d8f8760208801614b5d565b93506080860135925060a086013567ffffffffffffffff811115614db257600080fd5b614dbe88828901614b8c565b969995985093965092949392505050565b60008060008060808587031215614de557600080fd5b614dee85614b75565b9350614dfc60208601614b75565b9250614e0a60408601614c6a565b9150614e1860608601614c6a565b905092959194509250565b60005b83811015614e3e578181015183820152602001614e26565b50506000910152565b60008151808452614e5f816020860160208601614e23565b601f017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0169290920160200192915050565b6020815260006121376020830184614e47565b803567ffffffffffffffff8116811461438357600080fd5b600080600080600060a08688031215614ed457600080fd5b614edd86614b75565b9450614eeb60208701614c6a565b935060408601359250614f0060608701614ea4565b949793965091946080013592915050565b803561ffff8116811461438357600080fd5b60008060008060808587031215614f3957600080fd5b614f4285614b75565b9350614f5060208601614b75565b925060408501359150614e1860608601614f11565b60008060408385031215614f7857600080fd5b614f8183614b75565b9150614d1360208401614c6a565b600060208284031215614fa157600080fd5b61213782614b75565b600080600060608486031215614fbf57600080fd5b614fc884614b75565b9250614fd660208501614c6a565b9150604084013590509250925092565b600060208284031215614ff857600080fd5b61213782614c6a565b6000806000806000806000806000806000806101208d8f03121561502457600080fd5b61502d8d614b75565b9b5061503b60208e01614b75565b9a5060408d0135995061505060608e01614f11565b985060808d0135975060a08d0135965067ffffffffffffffff60c08e0135111561507957600080fd5b6150898e60c08f01358f01614b8c565b909650945067ffffffffffffffff60e08e013511156150a757600080fd5b6150b78e60e08f01358f01614b8c565b909450925067ffffffffffffffff6101008e013511156150d657600080fd5b6150e78e6101008f01358f01614b8c565b81935080925050509295989b509295989b509295989b565b60008060008060008060008060008060006101408c8e03121561512157600080fd5b61512b8d8d614b5d565b9a5061513960608d01614b75565b995060808c0135985060a08c0135975060c08c0135965067ffffffffffffffff8060e08e0135111561516a57600080fd5b61517a8e60e08f01358f01614b8c565b90975095506101008d013581101561519157600080fd5b6151a28e6101008f01358f01614b8c565b90955093506101208d01358110156151b957600080fd5b506151cb8d6101208e01358e01614b8c565b81935080925050509295989b509295989b9093969950565b600080600080606085870312156151f957600080fd5b61520285614b75565b935061521060208601614b75565b9250604085013567ffffffffffffffff8082111561522d57600080fd5b818701915087601f83011261524157600080fd5b81358181111561525057600080fd5b8860208260051b850101111561526557600080fd5b95989497505060200194505050565b60008060008060006080868803121561528c57600080fd5b61529586614b75565b9450602086013593506152aa60408701614f11565b9250606086013567ffffffffffffffff811115614db257600080fd5b600080608083850312156152d957600080fd5b6152e38484614b5d565b9150614d1360608401614b75565b6020808252825182820181905260009190848201906040850190845b818110156153325783516001600160a01b03168352928401929184019160010161530d565b50909695505050505050565b60008060008060008060008060c0898b03121561535a57600080fd5b61536389614b75565b975061537160208a01614b75565b96506040890135955061538660608a01614f11565b9450608089013567ffffffffffffffff808211156153a357600080fd5b6153af8c838d01614b8c565b909650945060a08b01359150808211156153c857600080fd5b506153d58b828c01614b8c565b999c989b5096995094979396929594505050565b6000806000606084860312156153fe57600080fd5b61540784614b75565b925061541560208501614c6a565b915061542360408501614b75565b90509250925092565b60008060006060848603121561544157600080fd5b61544a84614c6a565b9250614fd660208501614b75565b60008060006060848603121561546d57600080fd5b61544a84614b75565b600080600060a0848603121561548b57600080fd5b6154958585614b5d565b92506154a360608501614b75565b9150608084013590509250925092565b600080604083850312156154c657600080fd5b614d0583614c6a565b600080600080608085870312156154e557600080fd5b6154ee85614b75565b93506154fc60208601614c6a565b925060408501359150614e1860608601614ea4565b8151815260208083015190820152604081016118ff565b60006020828403121561553a57600080fd5b61213782614ea4565b838152818360208301376000910160200190815292915050565b63ffffffff61556b82614c6a565b1682526020810135602083015267ffffffffffffffff61558d60408301614ea4565b1660408301525050565b8183528181602085013750600060208284010152600060207fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0601f840116840101905092915050565b6155ea818961555d565b86606082015260e06080820152600061560760e083018789615597565b6001600160a01b03861660a084015282810360c0840152615629818587615597565b9a9950505050505050505050565b60808101615645828561555d565b6001600160a01b03831660608301529392505050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602160045260246000fd5b60006020828403121561569c57600080fd5b81516003811061213757600080fd5b8015158114613d2657600080fd5b6000602082840312156156cb57600080fd5b8151612137816156ab565b6000602082840312156156e857600080fd5b8135612137816156ab565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b600082601f83011261573357600080fd5b815167ffffffffffffffff8082111561574e5761574e6156f3565b604051601f83017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0908116603f01168101908282118183101715615794576157946156f3565b816040528381528660208588010111156157ad57600080fd5b61148d846020830160208901614e23565b6000602082840312156157d057600080fd5b815167ffffffffffffffff8111156157e757600080fd5b6127c684828501615722565b8a815261ffff8a16602082015288604082015287606082015260e06080820152600061582360e08301888a615597565b82810360a0840152615836818789615597565b905082810360c084015261584b818587615597565b9d9c50505050505050505050505050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b808201808211156118ff576118ff61585c565b60006101206158ad838e61555d565b8b60608401528a60808401528960a08401528060c08401526158d2818401898b615597565b905082810360e08401526158e7818789615597565b905082810361010084015261584b818587615597565b600060408083016001600160a01b03871684526020604081860152818683526060925060608601905060608760051b8701018860005b89811015615a3e577fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa089840301845281357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa18c360301811261599457600080fd5b8b0163ffffffff806159a583614c6a565b168552806159b4888401614c6a565b168786015250878101357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe18236030181126159ee57600080fd5b01858101903567ffffffffffffffff811115615a0957600080fd5b803603821315615a1857600080fd5b8789860152615a2a8886018284615597565b958701959450505090840190600101615933565b50909a9950505050505050505050565b8183823760009101908152919050565b60006001600160a01b03808916835280881660208401525085604083015261ffff8516606083015260a06080830152615a9b60a083018486615597565b98975050505050505050565b60006001600160a01b03808a16835288602084015260a06040840152615ad160a08401888a615597565b81871660608501528381036080850152615aec818688615597565b9b9a5050505050505050505050565b60a08101615b09828661555d565b6001600160a01b0393909316606082015260800152919050565b67ffffffffffffffff818116838216019080821115614d5857614d5861585c565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe1843603018112615b7957600080fd5b83018035915067ffffffffffffffff821115615b9457600080fd5b6020019150368190038213156116fe57600080fd5b6060815267ffffffffffffffff855116606082015263ffffffff60208601511660808201526001600160a01b0360408601511660a082015260006060860151615bfa60c084018263ffffffff169052565b50608086015160e083015260a086015161010083015260c086015160e0610120840152615c2b610140840182614e47565b90508281036020840152615c40818688615597565b915050612e8d604083018415159052565b600060408284031215615c6357600080fd5b6040516040810181811067ffffffffffffffff82111715615c8657615c866156f3565b604052825181526020928301519281019290925250919050565b600060408284031215615cb257600080fd5b6121378383615c51565b60008060608385031215615ccf57600080fd5b615cd98484615c51565b9150604083015167ffffffffffffffff811115615cf557600080fd5b615d0185828601615722565b9150509250929050565b606081526000615d1e6060830187614e47565b8281036020840152615d31818688615597565b9150506001600160a01b038316604083015295945050505050565b600060208284031215615d5e57600080fd5b5051919050565b606081016118ff828461555d565b60008251615d85818460208701614e23565b919091019291505056fea2646970667358221220fbeacb9e09f521d9b83b94a56dbd81b62f43beb282a6a4281738d9f94234e59364736f6c63430008160033"
  },
  {
    method: "eth_getCode",
    params: [
      "0x55d398326f99059fF775485246999027B3197955",
      "latest"
    ],
    result: "0x608060405234801561001057600080fd5b506004361061012c5760003560e01c8063893d20e8116100ad578063a9059cbb11610071578063a9059cbb1461035a578063b09f126614610386578063d28d88521461038e578063dd62ed3e14610396578063f2fde38b146103c45761012c565b8063893d20e8146102dd5780638da5cb5b1461030157806395d89b4114610309578063a0712d6814610311578063a457c2d71461032e5761012c565b806332424aa3116100f457806332424aa31461025c578063395093511461026457806342966c681461029057806370a08231146102ad578063715018a6146102d35761012c565b806306fdde0314610131578063095ea7b3146101ae57806318160ddd146101ee57806323b872dd14610208578063313ce5671461023e575b600080fd5b6101396103ea565b6040805160208082528351818301528351919283929083019185019080838360005b8381101561017357818101518382015260200161015b565b50505050905090810190601f1680156101a05780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b6101da600480360360408110156101c457600080fd5b506001600160a01b038135169060200135610480565b604080519115158252519081900360200190f35b6101f661049d565b60408051918252519081900360200190f35b6101da6004803603606081101561021e57600080fd5b506001600160a01b038135811691602081013590911690604001356104a3565b610246610530565b6040805160ff9092168252519081900360200190f35b610246610539565b6101da6004803603604081101561027a57600080fd5b506001600160a01b038135169060200135610542565b6101da600480360360208110156102a657600080fd5b5035610596565b6101f6600480360360208110156102c357600080fd5b50356001600160a01b03166105b1565b6102db6105cc565b005b6102e5610680565b604080516001600160a01b039092168252519081900360200190f35b6102e561068f565b61013961069e565b6101da6004803603602081101561032757600080fd5b50356106ff565b6101da6004803603604081101561034457600080fd5b506001600160a01b03813516906020013561077c565b6101da6004803603604081101561037057600080fd5b506001600160a01b0381351690602001356107ea565b6101396107fe565b61013961088c565b6101f6600480360360408110156103ac57600080fd5b506001600160a01b03813581169160200135166108e7565b6102db600480360360208110156103da57600080fd5b50356001600160a01b0316610912565b60068054604080516020601f60026000196101006001881615020190951694909404938401819004810282018101909252828152606093909290918301828280156104765780601f1061044b57610100808354040283529160200191610476565b820191906000526020600020905b81548152906001019060200180831161045957829003601f168201915b5050505050905090565b600061049461048d610988565b848461098c565b50600192915050565b60035490565b60006104b0848484610a78565b610526846104bc610988565b6105218560405180606001604052806028815260200161100e602891396001600160a01b038a166000908152600260205260408120906104fa610988565b6001600160a01b03168152602081019190915260400160002054919063ffffffff610bd616565b61098c565b5060019392505050565b60045460ff1690565b60045460ff1681565b600061049461054f610988565b846105218560026000610560610988565b6001600160a01b03908116825260208083019390935260409182016000908120918c16815292529020549063ffffffff610c6d16565b60006105a96105a3610988565b83610cce565b506001919050565b6001600160a01b031660009081526001602052604090205490565b6105d4610988565b6000546001600160a01b03908116911614610636576040805162461bcd60e51b815260206004820181905260248201527f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e6572604482015290519081900360640190fd5b600080546040516001600160a01b03909116907f8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0908390a3600080546001600160a01b0319169055565b600061068a61068f565b905090565b6000546001600160a01b031690565b60058054604080516020601f60026000196101006001881615020190951694909404938401819004810282018101909252828152606093909290918301828280156104765780601f1061044b57610100808354040283529160200191610476565b6000610709610988565b6000546001600160a01b0390811691161461076b576040805162461bcd60e51b815260206004820181905260248201527f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e6572604482015290519081900360640190fd5b6105a9610776610988565b83610dca565b6000610494610789610988565b846105218560405180606001604052806025815260200161107f60259139600260006107b3610988565b6001600160a01b03908116825260208083019390935260409182016000908120918d1681529252902054919063ffffffff610bd616565b60006104946107f7610988565b8484610a78565b6005805460408051602060026001851615610100026000190190941693909304601f810184900484028201840190925281815292918301828280156108845780601f1061085957610100808354040283529160200191610884565b820191906000526020600020905b81548152906001019060200180831161086757829003601f168201915b505050505081565b6006805460408051602060026001851615610100026000190190941693909304601f810184900484028201840190925281815292918301828280156108845780601f1061085957610100808354040283529160200191610884565b6001600160a01b03918216600090815260026020908152604080832093909416825291909152205490565b61091a610988565b6000546001600160a01b0390811691161461097c576040805162461bcd60e51b815260206004820181905260248201527f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e6572604482015290519081900360640190fd5b61098581610ebc565b50565b3390565b6001600160a01b0383166109d15760405162461bcd60e51b8152600401808060200182810382526024815260200180610fc46024913960400191505060405180910390fd5b6001600160a01b038216610a165760405162461bcd60e51b81526004018080602001828103825260228152602001806110e76022913960400191505060405180910390fd5b6001600160a01b03808416600081815260026020908152604080832094871680845294825291829020859055815185815291517f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b9259281900390910190a3505050565b6001600160a01b038316610abd5760405162461bcd60e51b8152600401808060200182810382526025815260200180610f9f6025913960400191505060405180910390fd5b6001600160a01b038216610b025760405162461bcd60e51b815260040180806020018281038252602381526020018061105c6023913960400191505060405180910390fd5b610b4581604051806060016040528060268152602001611036602691396001600160a01b038616600090815260016020526040902054919063ffffffff610bd616565b6001600160a01b038085166000908152600160205260408082209390935590841681522054610b7a908263ffffffff610c6d16565b6001600160a01b0380841660008181526001602090815260409182902094909455805185815290519193928716927fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef92918290030190a3505050565b60008184841115610c655760405162461bcd60e51b81526004018080602001828103825283818151815260200191508051906020019080838360005b83811015610c2a578181015183820152602001610c12565b50505050905090810190601f168015610c575780820380516001836020036101000a031916815260200191505b509250505060405180910390fd5b505050900390565b600082820183811015610cc7576040805162461bcd60e51b815260206004820152601b60248201527f536166654d6174683a206164646974696f6e206f766572666c6f770000000000604482015290519081900360640190fd5b9392505050565b6001600160a01b038216610d135760405162461bcd60e51b81526004018080602001828103825260218152602001806110a46021913960400191505060405180910390fd5b610d56816040518060600160405280602281526020016110c5602291396001600160a01b038516600090815260016020526040902054919063ffffffff610bd616565b6001600160a01b038316600090815260016020526040902055600354610d82908263ffffffff610f5c16565b6003556040805182815290516000916001600160a01b038516917fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef9181900360200190a35050565b6001600160a01b038216610e25576040805162461bcd60e51b815260206004820152601f60248201527f42455032303a206d696e7420746f20746865207a65726f206164647265737300604482015290519081900360640190fd5b600354610e38908263ffffffff610c6d16565b6003556001600160a01b038216600090815260016020526040902054610e64908263ffffffff610c6d16565b6001600160a01b03831660008181526001602090815260408083209490945583518581529351929391927fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef9281900390910190a35050565b6001600160a01b038116610f015760405162461bcd60e51b8152600401808060200182810382526026815260200180610fe86026913960400191505060405180910390fd5b600080546040516001600160a01b03808516939216917f8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e091a3600080546001600160a01b0319166001600160a01b0392909216919091179055565b6000610cc783836040518060400160405280601e81526020017f536166654d6174683a207375627472616374696f6e206f766572666c6f770000815250610bd656fe42455032303a207472616e736665722066726f6d20746865207a65726f206164647265737342455032303a20617070726f76652066726f6d20746865207a65726f20616464726573734f776e61626c653a206e6577206f776e657220697320746865207a65726f206164647265737342455032303a207472616e7366657220616d6f756e74206578636565647320616c6c6f77616e636542455032303a207472616e7366657220616d6f756e7420657863656564732062616c616e636542455032303a207472616e7366657220746f20746865207a65726f206164647265737342455032303a2064656372656173656420616c6c6f77616e63652062656c6f77207a65726f42455032303a206275726e2066726f6d20746865207a65726f206164647265737342455032303a206275726e20616d6f756e7420657863656564732062616c616e636542455032303a20617070726f766520746f20746865207a65726f2061646472657373a265627a7a72315820cbbd570ae478f6b7abf9c9a5c8c6884cf3f64dded74f7ec3e9b6d0b41122eaff64736f6c63430005100032"
  },
  {
    method: "eth_getTransactionByHash",
    params: [
      "0x016aa9570de26f1d25d3db2137fa1ef7dbac8e3a2efa1cab45c2e872deafee98"
    ],
    result: {
      type: "0x2",
      chainId: "0x38",
      nonce: "0x1283",
      gas: "0x1e54f4",
      maxFeePerGas: "0x2faf080",
      maxPriorityFeePerGas: "0x2faf080",
      to: null,
      value: "0x0",
      accessList: [],
      input: "0x60e0604052600280546001600160801b0319166301c9c380179055348015610025575f5ffd5b50604051611cb7380380611cb78339810160408190526100449161019f565b60015f5546603814158061006b5750731a44076050125825900e736c501f859c50fe728c3b155b80610074575081155b8061007d575080155b80610109575061759663ffffffff16731a44076050125825900e736c501f859c50fe728c6001600160a01b031663416ecebf6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156100dc573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061010091906101c1565b63ffffffff1614155b1561012757604051636dac6a0960e01b815260040160405180910390fd5b608082905260a08190523360c081905260405163ca5eb5e160e01b81526004810191909152731a44076050125825900e736c501f859c50fe728c9063ca5eb5e1906024015f604051808303815f87803b158015610182575f5ffd5b505af1158015610194573d5f5f3e3d5ffd5b5050505050506101eb565b5f5f604083850312156101b0575f5ffd5b505080516020909101519092909150565b5f602082840312156101d1575f5ffd5b815163ffffffff811681146101e4575f5ffd5b9392505050565b60805160a05160c051611a5c61025b5f395f818161031901528181610413015281816107930152610a8401525f818161038c0152818161086101528181610d43015261109c01525f8181610196015281816104e101528181610bc6015281816112f901526114100152611a5c5ff3fe608060405260043610610105575f3560e01c80637d25a05e11610092578063b1f8671711610062578063b1f867171461033b578063c13bd9361461034f578063d96661ef1461037b578063e495f1d4146103ae578063ff7bd03d146103d9575f5ffd5b80637d25a05e1461028857806383d5f21d146102bf578063a7a1ed72146102e9578063acba7b4214610308575f5ffd5b806315aff54e116100d857806315aff54e146101855780634922eec1146101c65780634cedb60f146101f25780635e280f111461022957806378360c8814610268575f5ffd5b80630200e86b1461010957806307f53ee71461012a57806310265fa51461015357806313137d6514610172575b5f5ffd5b348015610114575f5ffd5b506101286101233660046114b9565b610408565b005b61013d6101383660046114e6565b6104c0565b60405161014a9190611506565b60405180910390f35b34801561015e575f5ffd5b5061012861016d36600461155e565b610788565b6101286101803660046115d3565b610b7f565b348015610190575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b60405190815260200161014a565b3480156101d1575f5ffd5b506101e56101e03660046114e6565b610f8e565b60405161014a91906116b0565b3480156101fd575f5ffd5b50600254610211906001600160801b031681565b6040516001600160801b03909116815260200161014a565b348015610234575f5ffd5b50610250731a44076050125825900e736c501f859c50fe728c81565b6040516001600160a01b03909116815260200161014a565b348015610273575f5ffd5b506101b85f516020611a075f395f51905f5281565b348015610293575f5ffd5b506102a76102a23660046116d5565b611273565b6040516001600160401b03909116815260200161014a565b3480156102ca575f5ffd5b506102d46176aa81565b60405163ffffffff909116815260200161014a565b3480156102f4575f5ffd5b50600154610250906001600160a01b031681565b348015610313575f5ffd5b506102507f000000000000000000000000000000000000000000000000000000000000000081565b348015610346575f5ffd5b506101e561127b565b34801561035a575f5ffd5b5061036e6103693660046114e6565b6112d5565b60405161014a91906116fd565b348015610386575f5ffd5b506101b87f000000000000000000000000000000000000000000000000000000000000000081565b3480156103b9575f5ffd5b506101b86103c8366004611714565b60036020525f908152604090205481565b3480156103e4575f5ffd5b506103f86103f336600461172b565b6113ef565b604051901515815260200161014a565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614158061044e57506002546001600160801b03908116908216105b1561046c57604051636dac6a0960e01b815260040160405180910390fd5b600280546001600160801b0319166001600160801b0383169081179091556040519081527f4bbad5fe035af81686d3e8380dfd61d879211cbe2c4e6e05f86ad07cdec099b09060200160405180910390a150565b6104c8611479565b6104d0611451565b6040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91810161051285610f8e565b815260200161051f61127b565b81525f6020909101819052604051631bb8518b60e31b815291925090731a44076050125825900e736c501f859c50fe728c9063ddc28c58906105679085903090600401611745565b6040805180830381865afa158015610581573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906105a59190611815565b805190915015806105b95750602081015115155b806105c5575080513414155b156105e357604051636dac6a0960e01b815260040160405180910390fd5b6040516302637a4560e41b8152731a44076050125825900e736c501f859c50fe728c90632637a45090349061061e9086903390600401611745565b60806040518083038185885af115801561063a573d5f5f3e3d5ffd5b50505050506040513d601f19601f8201168201806040525081019061065f9190611843565b8051909350158061067b575060208301516001600160401b0316155b8061068d575060408301516020015115155b8061069c575060408301515134105b156106ba57604051636dac6a0960e01b815260040160405180910390fd5b825f01517f6d23cdaef17712141c7441cf202389c6ddc063fb5c14788d5c4479b62096d13f8560015f9054906101000a90046001600160a01b03166001600160a01b031663172195226040518163ffffffff1660e01b8152600401602060405180830381865afa158015610730573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061075491906118b6565b6040805160ff90931683526001600160401b0390911660208301520160405180910390a2505061078360015f55565b919050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161415806107ca57506001546001600160a01b031615155b806107dd57506001600160a01b0381163b155b806108595750306001600160a01b0316816001600160a01b03166303eadcfc6040518163ffffffff1660e01b8152600401602060405180830381865afa158015610829573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061084d91906118d1565b6001600160a01b031614155b806108e357507f0000000000000000000000000000000000000000000000000000000000000000816001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156108bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906108e091906118ec565b14155b8061095c57505f516020611a075f395f51905f525f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa158015610935573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061095991906118ec565b14155b806109ec57507355d398326f99059ff775485246999027b31979556001600160a01b0316816001600160a01b031663e5a6b10f6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156109bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906109e091906118d1565b6001600160a01b031614155b80610a7c575073c440f06bbc7e58b0d055815f915447e4ae0e37206001600160a01b0316816001600160a01b03166361d027b36040518163ffffffff1660e01b8152600401602060405180830381865afa158015610a4c573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610a7091906118d1565b6001600160a01b031614155b80610b1857507f00000000000000000000000000000000000000000000000000000000000000006001600160a01b0316816001600160a01b031663f77c47916040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ae8573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610b0c91906118d1565b6001600160a01b031614155b15610b3657604051636dac6a0960e01b815260040160405180910390fd5b600180546001600160a01b0319166001600160a01b0383169081179091556040517f3916d079df018feca66a550908f671cff67410227b4a8c24f13531847e12b9c8905f90a250565b610b87611451565b33731a44076050125825900e736c501f859c50fe728c141580610bbe57506176aa610bb56020890189611903565b63ffffffff1614155b80610bed57507f0000000000000000000000000000000000000000000000000000000000000000876020013514155b80610c0157506001546001600160a01b0316155b80610c0a575085155b80610c2b5750610c20606088016040890161191c565b6001600160401b0316155b80610c3557503415155b15610c5357604051636dac6a0960e01b815260040160405180910390fd5b608a84141580610c7e575084845f818110610c7057610c70611937565b9091013560f81c6003141590505b15610c9c57604051636dac6a0960e01b815260040160405180910390fd5b5f85856001818110610cb057610cb0611937565b919091013560f81c91505f9050610ccb60226002888a61194b565b610cd491611972565b90505f610ce560426022898b61194b565b610cee91611972565b90505f610cff604a60428a8c61194b565b610d089161198f565b60c01c90505f610d1c606a604a8b8d61194b565b610d2591611972565b90505f610d36608a606a8c8e61194b565b610d3f91611972565b90507f000000000000000000000000000000000000000000000000000000000000000085141580610d7d57505f516020611a075f395f51905f528414155b80610d8f57506001600160401b038316155b15610dad57604051636dac6a0960e01b815260040160405180910390fd5b5f8b8b604051610dbe9291906119c5565b60408051918290039091205f8f81526003602052919091205490915015801590610df557505f8d8152600360205260409020548114155b15610e1357604051636dac6a0960e01b815260040160405180910390fd5b8660ff16600103610eb05782151580610e2b57508115155b15610e4957604051636dac6a0960e01b815260040160405180910390fd5b60015460405163579c848360e11b81526001600160401b03861660048201526001600160a01b039091169063af390906906024015b5f604051808303815f87803b158015610e95575f5ffd5b505af1158015610ea7573d5f5f3e3d5ffd5b50505050610f1b565b8660ff16600303610f025760015460405163367938c560e21b81526001600160401b038616600482015260248101859052604481018490526001600160a01b039091169063d9e4e31490606401610e7e565b604051636dac6a0960e01b815260040160405180910390fd5b5f8d815260036020908152604091829020839055815160ff8a1681526001600160401b038716918101919091528e917f37949e68c9d0a4e5f5474ddb8654f999a5dc4b58a8aa1aef313516586e9b320a910160405180910390a250505050505050610f8560015f55565b50505050505050565b6001546060906001600160a01b0316610fba57604051636dac6a0960e01b815260040160405180910390fd5b8160ff166002036110705760035b60015f9054906101000a90046001600160a01b03166001600160a01b031663c19d93fb6040518163ffffffff1660e01b8152600401602060405180830381865afa158015611018573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061103c91906119e8565b600481111561104d5761104d6119d4565b1461106b57604051636dac6a0960e01b815260040160405180910390fd5b611082565b8160ff16600403610f02576004610fc8565b60015460408051630b90ca9160e11b8152905160039285927f0000000000000000000000000000000000000000000000000000000000000000925f516020611a075f395f51905f52926001600160a01b03169163172195229160048083019260209291908290030181865afa1580156110fd573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061112191906118b6565b60015f9054906101000a90046001600160a01b03166001600160a01b0316635467e0a76040518163ffffffff1660e01b8152600401602060405180830381865afa158015611171573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061119591906118ec565b60015f9054906101000a90046001600160a01b03166001600160a01b03166366d003ac6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156111e5573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061120991906118ec565b60405160f897881b6001600160f81b031990811660208301529690971b90951660218701526022860193909352604285019190915260c01b6001600160c01b0319166062840152606a830152608a82015260aa016040516020818303038152906040529050919050565b5f5b92915050565b600254604051600360f01b6020820152600160f81b60228201819052601160f01b6023830152602582015260809190911b6001600160801b0319166026820152606090603601604051602081830303815290604052905090565b604080518082019091525f80825260208201526040805160a0810182526176aa81527f000000000000000000000000000000000000000000000000000000000000000060208201525f91731a44076050125825900e736c501f859c50fe728c9163ddc28c5891810161134687610f8e565b815260200161135361127b565b81525f6020909101526040516001600160e01b031960e084901b16815261137f91903090600401611745565b6040805180830381865afa158015611399573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906113bd9190611815565b805190915015806113d15750602081015115155b1561127557604051636dac6a0960e01b815260040160405180910390fd5b5f6176aa6114006020840184611903565b63ffffffff1614801561143657507f00000000000000000000000000000000000000000000000000000000000000008260200135145b801561127557506001546001600160a01b0316151592915050565b60025f540361147357604051633ee5aeb560e01b815260040160405180910390fd5b60025f55565b60405180606001604052805f81526020015f6001600160401b031681526020016114b460405180604001604052805f81526020015f81525090565b905290565b5f602082840312156114c9575f5ffd5b81356001600160801b03811681146114df575f5ffd5b9392505050565b5f602082840312156114f6575f5ffd5b813560ff811681146114df575f5ffd5b5f608082019050825182526001600160401b0360208401511660208301526040830151611540604084018280518252602090810151910152565b5092915050565b6001600160a01b038116811461155b575f5ffd5b50565b5f6020828403121561156e575f5ffd5b81356114df81611547565b5f60608284031215611589575f5ffd5b50919050565b5f5f83601f84011261159f575f5ffd5b5081356001600160401b038111156115b5575f5ffd5b6020830191508360208285010111156115cc575f5ffd5b9250929050565b5f5f5f5f5f5f5f60e0888a0312156115e9575f5ffd5b6115f38989611579565b96506060880135955060808801356001600160401b03811115611614575f5ffd5b6116208a828b0161158f565b90965094505060a088013561163481611547565b925060c08801356001600160401b0381111561164e575f5ffd5b61165a8a828b0161158f565b989b979a50959850939692959293505050565b5f81518084525f5b8181101561169157602081850181015186830182015201611675565b505f602082860101526020601f19601f83011685010191505092915050565b602081525f6114df602083018461166d565b803563ffffffff81168114610783575f5ffd5b5f5f604083850312156116e6575f5ffd5b6116ef836116c2565b946020939093013593505050565b815181526020808301519082015260408101611275565b5f60208284031215611724575f5ffd5b5035919050565b5f6060828403121561173b575f5ffd5b6114df8383611579565b6040815263ffffffff8351166040820152602083015160608201525f604084015160a0608084015261177a60e084018261166d565b90506060850151603f198483030160a0850152611797828261166d565b60809690960151151560c08501525050506001600160a01b039190911660209091015290565b5f604082840312156117cd575f5ffd5b604080519081016001600160401b03811182821017156117fb57634e487b7160e01b5f52604160045260245ffd5b604052825181526020928301519281019290925250919050565b5f60408284031215611825575f5ffd5b6114df83836117bd565b6001600160401b038116811461155b575f5ffd5b5f6080828403128015611854575f5ffd5b50604051606081016001600160401b038111828210171561188357634e487b7160e01b5f52604160045260245ffd5b6040528251815260208301516118988161182f565b60208201526118aa84604085016117bd565b60408201529392505050565b5f602082840312156118c6575f5ffd5b81516114df8161182f565b5f602082840312156118e1575f5ffd5b81516114df81611547565b5f602082840312156118fc575f5ffd5b5051919050565b5f60208284031215611913575f5ffd5b6114df826116c2565b5f6020828403121561192c575f5ffd5b81356114df8161182f565b634e487b7160e01b5f52603260045260245ffd5b5f5f85851115611959575f5ffd5b83861115611965575f5ffd5b5050820193919092039150565b80356020831015611275575f19602084900360031b1b1692915050565b80356001600160c01b03198116906008841015611540576001600160c01b031960089490940360031b84901b1690921692915050565b818382375f9101908152919050565b634e487b7160e01b5f52602160045260245ffd5b5f602082840312156119f8575f5ffd5b8151600581106114df575f5ffdfe046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6baa2646970667358221220d5e0a008fcf934cc781ad8e21c7865f692e69e850ec3b05743fb3e9c2c69c09a64736f6c634300081e0033c445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92f5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
      r: "0xec167fe50bc42d478d825180116055ec52433f243cf51f4bcec060cbe4674334",
      s: "0x42d31082f3b9da2aa43802430eca929e779b2747484bf5e7c142397d443c7b3e",
      yParity: "0x0",
      v: "0x0",
      hash: "0x016aa9570de26f1d25d3db2137fa1ef7dbac8e3a2efa1cab45c2e872deafee98",
      blockHash: "0x199bd9d02bef559f2fe46cb7371783009bff749d259c3ebf40337687add29236",
      blockNumber: "0x80eebfb",
      transactionIndex: "0x39",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      gasPrice: "0x2faf080",
      blockTimestamp: "0x6b03acce"
    }
  },
  {
    method: "eth_getTransactionReceipt",
    params: [
      "0x016aa9570de26f1d25d3db2137fa1ef7dbac8e3a2efa1cab45c2e872deafee98"
    ],
    result: {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xc5c903",
      logs: [
        {
          address: "0x1a44076050125825900e736c501f859c50fe728c",
          topics: [
            "0x6ee10e9ed4d6ce9742703a498707862f4b00f1396a87195eb93267b3d7983981"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c9000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
          blockHash: "0x199bd9d02bef559f2fe46cb7371783009bff749d259c3ebf40337687add29236",
          blockNumber: "0x80eebfb",
          blockTimestamp: "0x6b03acce",
          transactionHash: "0x016aa9570de26f1d25d3db2137fa1ef7dbac8e3a2efa1cab45c2e872deafee98",
          transactionIndex: "0x39",
          logIndex: "0x146",
          removed: false
        }
      ],
      logsBloom: "0x00000000000000000000000000000000000000000000000000800000001000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000",
      transactionHash: "0x016aa9570de26f1d25d3db2137fa1ef7dbac8e3a2efa1cab45c2e872deafee98",
      transactionIndex: "0x39",
      blockHash: "0x199bd9d02bef559f2fe46cb7371783009bff749d259c3ebf40337687add29236",
      blockNumber: "0x80eebfb",
      gasUsed: "0x1843f6",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: null,
      contractAddress: "0x74c20deb476dca58459956b1acd65771197900c9"
    }
  },
  {
    method: "eth_getTransactionByHash",
    params: [
      "0x9dd9e68b4c1d226e79f788d009a42cf47d4c7662ddc58b16670b4583226192b3"
    ],
    result: {
      type: "0x2",
      chainId: "0x38",
      nonce: "0x1284",
      gas: "0x2310e5",
      maxFeePerGas: "0x2faf080",
      maxPriorityFeePerGas: "0x2faf080",
      to: null,
      value: "0x0",
      accessList: [],
      input: "0x610120604052600a805460ff1916600117905534801561001d575f5ffd5b506040516124c33803806124c383398101604081905261003c916104aa565b6040518060400160405280601c81526020017f4e46547265652053756974652047656e65726174696f6e205061737300000000815250604051806040016040528060078152602001662a2922a2a3a2a760c91b815250815f90816100a0919061056f565b5060016100ad828261056f565b50506001600655504660381415806100d857507355d398326f99059ff775485246999027b31979553b155b806100eb57506001600160a01b0381163b155b8061016d57507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610141573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906101659190610629565b60ff16601214155b1561018b57604051636dac6a0960e01b815260040160405180910390fd5b5f819050336001600160a01b0316816001600160a01b031663acba7b426040518163ffffffff1660e01b8152600401602060405180830381865afa1580156101d5573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906101f991906104aa565b6001600160a01b03161415806102945750731a44076050125825900e736c501f859c50fe728c6001600160a01b0316816001600160a01b0316635e280f116040518163ffffffff1660e01b8152600401602060405180830381865afa158015610264573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061028891906104aa565b6001600160a01b031614155b806102fc5750806001600160a01b03166315aff54e6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156102d6573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906102fa9190610649565b155b806103645750806001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa15801561033e573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906103629190610649565b155b806103f057507f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba5f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa1580156103c9573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906103ed9190610649565b14155b1561040e57604051636dac6a0960e01b815260040160405180910390fd5b6001600160a01b038083166080523360a081905260c0526040805163d96661ef60e01b815290519183169163d96661ef916004808201926020929091908290030181865afa158015610462573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906104869190610649565b60e05250507355d398326f99059ff775485246999027b31979553f61010052610660565b5f602082840312156104ba575f5ffd5b81516001600160a01b03811681146104d0575f5ffd5b9392505050565b634e487b7160e01b5f52604160045260245ffd5b600181811c908216806104ff57607f821691505b60208210810361051d57634e487b7160e01b5f52602260045260245ffd5b50919050565b601f82111561056a57805f5260205f20601f840160051c810160208510156105485750805b601f840160051c820191505b81811015610567575f8155600101610554565b50505b505050565b81516001600160401b03811115610588576105886104d7565b61059c8161059684546104eb565b84610523565b6020601f8211600181146105ce575f83156105b75750848201515b5f19600385901b1c1916600184901b178455610567565b5f84815260208120601f198516915b828110156105fd57878501518255602094850194600190920191016105dd565b508482101561061a57868401515f19600387901b60f8161c191681555b50505050600190811b01905550565b5f60208284031215610639575f5ffd5b815160ff811681146104d0575f5ffd5b5f60208284031215610659575f5ffd5b5051919050565b60805160a05160c05160e05161010051611dfc6106c75f395f81816102620152610a5101525f818161049701526108e101525f81816104ff015261073701525f81816103900152610a1001525f818161022301528181610d200152610f3c0152611dfc5ff3fe608060405234801561000f575f5ffd5b50600436106101f2575f3560e01c806370a0823111610114578063b88d4fde116100a9578063d96661ef11610079578063d96661ef14610492578063d9e4e314146104b9578063e5a6b10f146104cc578063e985e9c5146104e7578063f77c4791146104fa575f5ffd5b8063b88d4fde14610445578063c19d93fb14610458578063c87b56dd14610472578063c9f2071514610485575f5ffd5b806397579dd3116100e457806397579dd314610404578063a22cb46514610417578063a6f2ae3a1461042a578063af39090614610432575f5ffd5b806370a08231146103b257806378360c88146103c55780638d859f3e146103ec57806395d89b41146103fc575f5ffd5b806323b872dd1161018a57806361d027b31161015a57806361d027b3146103545780636352211e1461036f57806366d003ac146103825780636af7f9f51461038b575f5ffd5b806323b872dd14610312578063325832ac1461032557806342842e0e146103385780635467e0a71461034b575f5ffd5b8063081812fc116101c5578063081812fc146102a75780630823d5f3146102ba578063095ea7b3146102cd57806317219522146102e2575f5ffd5b806301ffc9a7146101f657806303eadcfc1461021e57806306f660a71461025d57806306fdde0314610292575b5f5ffd5b610209610204366004611962565b610521565b60405190151581526020015b60405180910390f35b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6040516001600160a01b039091168152602001610215565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b604051908152602001610215565b61029a610572565b60405161021591906119ca565b6102456102b53660046119dc565b610601565b6102096102c8366004611a09565b610628565b6102e06102db366004611a22565b61068f565b005b6007546102fa9061010090046001600160401b031681565b6040516001600160401b039091168152602001610215565b6102e0610320366004611a4a565b61069e565b6102e0610333366004611a93565b61072c565b6102e0610346366004611a4a565b6107bc565b61028460085481565b61024573c440f06bbc7e58b0d055815f915447e4ae0e372081565b61024561037d3660046119dc565b6107db565b61028460095481565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b6102846103c0366004611a09565b6107e5565b6102847f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba81565b61028468015af1d78b58c4000081565b61029a61082a565b6102846104123660046119dc565b610839565b6102e0610425366004611aac565b6109c4565b6102e06109cf565b6102e0610440366004611af3565b610d15565b6102e0610453366004611b20565b610ea8565b6007546104659060ff1681565b6040516102159190611c0e565b61029a6104803660046119dc565b610ec0565b600a546102099060ff1681565b6102847f000000000000000000000000000000000000000000000000000000000000000081565b6102e06104c7366004611c34565b610f31565b6102457355d398326f99059ff775485246999027b319795581565b6102096104f5366004611c64565b61109d565b6102457f000000000000000000000000000000000000000000000000000000000000000081565b5f6001600160e01b031982166380ac58cd60e01b148061055157506001600160e01b03198216635b5e139f60e01b145b8061056c57506301ffc9a760e01b6001600160e01b03198316145b92915050565b60605f805461058090611c8c565b80601f01602080910402602001604051908101604052809291908181526020018280546105ac90611c8c565b80156105f75780601f106105ce576101008083540402835291602001916105f7565b820191905f5260205f20905b8154815290600101906020018083116105da57829003601f168201915b5050505050905090565b5f61060b826110ca565b505f828152600460205260409020546001600160a01b031661056c565b5f600260075460ff16600481111561064257610642611bfa565b14801561065757506001600160a01b03821615155b801561056c57505060075461010090046001600160401b03165f908152600260205260409020546001600160a01b0391821691161490565b61069a828233611102565b5050565b6001600160a01b0382166106cc57604051633250574960e11b81525f60048201526024015b60405180910390fd5b5f6106d883833361110f565b9050836001600160a01b0316816001600160a01b031614610726576040516364283d7b60e01b81526001600160a01b03808616600483015260248201849052821660448201526064016106c3565b50505050565b336001600160a01b037f0000000000000000000000000000000000000000000000000000000000000000161461077557604051636dac6a0960e01b815260040160405180910390fd5b600a805460ff19168215159081179091556040519081527fd6d0fdd597c17a0211f0324826035a55dec84b1e6196f3585be220b46767fbb99060200160405180910390a150565b6107d683838360405180602001604052805f815250610ea8565b505050565b5f61056c826110ca565b5f6001600160a01b03821661080f576040516322718ad960e21b81525f60048201526024016106c3565b506001600160a01b03165f9081526003602052604090205490565b60606001805461058090611c8c565b5f6108426111ad565b600260075460ff16600481111561085b5761085b611bfa565b14158061088b5750600754339061087f9061010090046001600160401b03166107db565b6001600160a01b031614155b80610894575081155b156108b257604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff1916600390811791829055600984905560408051602081019290925246908201523060608201527f000000000000000000000000000000000000000000000000000000000000000060808201527f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba60a08201526001600160401b03610100928390041660c08201523360e08201529081018390526101200160408051808303601f19018152908290528051602091820120600881905560075485845290926101009091046001600160401b0316917f5852bd51fa2990e2712a8f82286a04ca0750a7646a7950235ffefdb10585cefe910160405180910390a3506008546109bf6001600655565b919050565b61069a3383836111d7565b6109d76111ad565b600160075460ff1660048111156109f0576109f0611bfa565b1415806109ff5750600a5460ff165b80610a335750336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614155b80610a7357507355d398326f99059ff775485246999027b31979553f7f000000000000000000000000000000000000000000000000000000000000000014155b80610af557507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ac9573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610aed9190611cc4565b60ff16601214155b15610b1357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660021790556040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201525f907355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610b83573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610ba79190611ce4565b9050610be67355d398326f99059ff775485246999027b31979553373c440f06bbc7e58b0d055815f915447e4ae0e372068015af1d78b58c40000611275565b610bf968015af1d78b58c4000082611d0f565b6040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201527355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610c5a573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610c7e9190611ce4565b14610c9c57604051636dac6a0960e01b815260040160405180910390fd5b600754610cb890339061010090046001600160401b03166112cf565b60075460405168015af1d78b58c400008152339161010090046001600160401b0316907f266845010576f42f87c2d262b76328c22b6797abd6c81b34f59fc1b2da1c487e9060200160405180910390a350610d136001600655565b565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610d5e57604051636dac6a0960e01b815260040160405180910390fd5b806001600160401b03165f03610d8757604051636dac6a0960e01b815260040160405180910390fd5b6007546001600160401b038281166101009092041614610ea557600754610dbd9061010090046001600160401b03166001611d22565b6001600160401b0316816001600160401b0316141580610e1557505f60075460ff166004811115610df057610df0611bfa565b14158015610e155750600460075460ff166004811115610e1257610e12611bfa565b14155b15610e3357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff196001600160401b0384166101008102821668ffffffffffffffffff199093169290921760019081179093555f60088190556009819055600a8054909216909317905560405190917ff48a2acdce0f4a30c2d32425d8827b030bbdff66b7694573d92cdd52b818fd1691a25b50565b610eb384848461069e565b61072633858585856112e8565b6060610ecb826110ca565b505f610ee160408051602081019091525f815290565b90505f815111610eff5760405180602001604052805f815250610f2a565b80610f0984611410565b604051602001610f1a929190611d41565b6040516020818303038152906040525b9392505050565b336001600160a01b037f00000000000000000000000000000000000000000000000000000000000000001614610f7a57604051636dac6a0960e01b815260040160405180910390fd5b610f826111ad565b6007546001600160401b0384811661010090920416141580610fa2575081155b80610faf57506008548214155b80610fbc57506009548114155b15610fda57604051636dac6a0960e01b815260040160405180910390fd5b600460075460ff166004811115610ff357610ff3611bfa565b1461109357600360075460ff16600481111561101157611011611bfa565b1461102f57604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660041790819055611056906001600160401b036101009091041661149f565b600754604051839161010090046001600160401b0316907f4baa52424160077091b85a05340629c1a44cfac77a87274fad62a384fe6193f0905f90a35b6107d66001600655565b6001600160a01b039182165f90815260056020908152604080832093909416825291909152205460ff1690565b5f818152600260205260408120546001600160a01b03168061056c57604051637e27328960e01b8152600481018490526024016106c3565b6107d683838360016114d7565b6007545f9061010090046001600160401b03168314158061117c5750600260075460ff16600481111561114457611144611bfa565b1415801561117c5750600460075460ff16600481111561116657611166611bfa565b14801561117a57506001600160a01b038416155b155b1561119a57604051636dac6a0960e01b815260040160405180910390fd5b6111a58484846115db565b949350505050565b6002600654036111d057604051633ee5aeb560e01b815260040160405180910390fd5b6002600655565b6001600160a01b03821661120957604051630b61174360e31b81526001600160a01b03831660048201526024016106c3565b6001600160a01b038381165f81815260056020908152604080832094871680845294825291829020805460ff191686151590811790915591519182527f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31910160405180910390a3505050565b604080516001600160a01b0385811660248301528416604482015260648082018490528251808303909101815260849091019091526020810180516001600160e01b03166323b872dd60e01b1790526107269085906116cd565b61069a828260405180602001604052805f815250611739565b6001600160a01b0383163b1561140957604051630a85bd0160e11b81526001600160a01b0384169063150b7a029061132a908890889087908790600401611d6f565b6020604051808303815f875af1925050508015611364575060408051601f3d908101601f1916820190925261136191810190611dab565b60015b6113cb573d808015611391576040519150601f19603f3d011682016040523d82523d5f602084013e611396565b606091505b5080515f036113c357604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b805160208201fd5b6001600160e01b03198116630a85bd0160e11b1461140757604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b505b5050505050565b60605f61141c83611750565b60010190505f816001600160401b0381111561143a5761143a611b0c565b6040519080825280601f01601f191660200182016040528015611464576020820181803683370190505b5090508181016020015b5f19016f181899199a1a9b1b9c1cb0b131b232b360811b600a86061a8153600a850494508461146e57509392505050565b5f6114ab5f835f61110f565b90506001600160a01b03811661069a57604051637e27328960e01b8152600481018390526024016106c3565b80806114eb57506001600160a01b03821615155b156115ac575f6114fa846110ca565b90506001600160a01b038316158015906115265750826001600160a01b0316816001600160a01b031614155b80156115395750611537818461109d565b155b156115625760405163a9fbf51f60e01b81526001600160a01b03841660048201526024016106c3565b81156115aa5783856001600160a01b0316826001600160a01b03167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45b505b50505f90815260046020526040902080546001600160a01b0319166001600160a01b0392909216919091179055565b5f828152600260205260408120546001600160a01b039081169083161561160757611607818486611827565b6001600160a01b03811615611641576116225f855f5f6114d7565b6001600160a01b0381165f90815260036020526040902080545f190190555b6001600160a01b0385161561166f576001600160a01b0385165f908152600360205260409020805460010190555b5f8481526002602052604080822080546001600160a01b0319166001600160a01b0389811691821790925591518793918516917fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef91a4949350505050565b5f5f60205f8451602086015f885af1806116ec576040513d5f823e3d81fd5b50505f513d91508115611703578060011415611710565b6001600160a01b0384163b155b1561072657604051635274afe760e01b81526001600160a01b03851660048201526024016106c3565b611743838361188b565b6107d6335f8585856112e8565b5f8072184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b831061178e5772184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b830492506040015b6d04ee2d6d415b85acef810000000083106117ba576d04ee2d6d415b85acef8100000000830492506020015b662386f26fc1000083106117d857662386f26fc10000830492506010015b6305f5e10083106117f0576305f5e100830492506008015b612710831061180457612710830492506004015b60648310611816576064830492506002015b600a831061056c5760010192915050565b6118328383836118ec565b6107d6576001600160a01b03831661186057604051637e27328960e01b8152600481018290526024016106c3565b60405163177e802f60e01b81526001600160a01b0383166004820152602481018290526044016106c3565b6001600160a01b0382166118b457604051633250574960e11b81525f60048201526024016106c3565b5f6118c083835f61110f565b90506001600160a01b038116156107d6576040516339e3563760e11b81525f60048201526024016106c3565b5f6001600160a01b038316158015906111a55750826001600160a01b0316846001600160a01b031614806119255750611925848461109d565b806111a55750505f908152600460205260409020546001600160a01b03908116911614919050565b6001600160e01b031981168114610ea5575f5ffd5b5f60208284031215611972575f5ffd5b8135610f2a8161194d565b5f5b8381101561199757818101518382015260200161197f565b50505f910152565b5f81518084526119b681602086016020860161197d565b601f01601f19169290920160200192915050565b602081525f610f2a602083018461199f565b5f602082840312156119ec575f5ffd5b5035919050565b80356001600160a01b03811681146109bf575f5ffd5b5f60208284031215611a19575f5ffd5b610f2a826119f3565b5f5f60408385031215611a33575f5ffd5b611a3c836119f3565b946020939093013593505050565b5f5f5f60608486031215611a5c575f5ffd5b611a65846119f3565b9250611a73602085016119f3565b929592945050506040919091013590565b803580151581146109bf575f5ffd5b5f60208284031215611aa3575f5ffd5b610f2a82611a84565b5f5f60408385031215611abd575f5ffd5b611ac6836119f3565b9150611ad460208401611a84565b90509250929050565b80356001600160401b03811681146109bf575f5ffd5b5f60208284031215611b03575f5ffd5b610f2a82611add565b634e487b7160e01b5f52604160045260245ffd5b5f5f5f5f60808587031215611b33575f5ffd5b611b3c856119f3565b9350611b4a602086016119f3565b92506040850135915060608501356001600160401b03811115611b6b575f5ffd5b8501601f81018713611b7b575f5ffd5b80356001600160401b03811115611b9457611b94611b0c565b604051601f8201601f19908116603f011681016001600160401b0381118282101715611bc257611bc2611b0c565b604052818152828201602001891015611bd9575f5ffd5b816020840160208301375f6020838301015280935050505092959194509250565b634e487b7160e01b5f52602160045260245ffd5b6020810160058310611c2e57634e487b7160e01b5f52602160045260245ffd5b91905290565b5f5f5f60608486031215611c46575f5ffd5b611c4f84611add565b95602085013595506040909401359392505050565b5f5f60408385031215611c75575f5ffd5b611c7e836119f3565b9150611ad4602084016119f3565b600181811c90821680611ca057607f821691505b602082108103611cbe57634e487b7160e01b5f52602260045260245ffd5b50919050565b5f60208284031215611cd4575f5ffd5b815160ff81168114610f2a575f5ffd5b5f60208284031215611cf4575f5ffd5b5051919050565b634e487b7160e01b5f52601160045260245ffd5b8082018082111561056c5761056c611cfb565b6001600160401b03818116838216019081111561056c5761056c611cfb565b5f8351611d5281846020880161197d565b835190830190611d6681836020880161197d565b01949350505050565b6001600160a01b03858116825284166020820152604081018390526080606082018190525f90611da19083018461199f565b9695505050505050565b5f60208284031215611dbb575f5ffd5b8151610f2a8161194d56fea26469706673582212205cd0600d0bc59401f6362a6ffeeddd9fccccd322ad458bc4283018628c84b01f64736f6c634300081e003300000000000000000000000074c20deb476dca58459956b1acd65771197900c9",
      r: "0x9bdb228012d60f3f52d59d32bdccd1d8401ef7737fb862cd5adb8348d1af7c23",
      s: "0x55851c7c2fc4f75341ff424accee9bb8ba3d0e79075fd364d66d007d3e10babe",
      yParity: "0x0",
      v: "0x0",
      hash: "0x9dd9e68b4c1d226e79f788d009a42cf47d4c7662ddc58b16670b4583226192b3",
      blockHash: "0x0bfb4b4b76bf2933c6a302caa02af57dc5ae09c68b228cf1b520d8b3653a321e",
      blockNumber: "0x80ef3cc",
      transactionIndex: "0x3d",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      gasPrice: "0x2faf080",
      blockTimestamp: "0x6b03b053"
    }
  },
  {
    method: "eth_getTransactionReceipt",
    params: [
      "0x9dd9e68b4c1d226e79f788d009a42cf47d4c7662ddc58b16670b4583226192b3"
    ],
    result: {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xb74c54",
      logs: [],
      logsBloom: "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
      transactionHash: "0x9dd9e68b4c1d226e79f788d009a42cf47d4c7662ddc58b16670b4583226192b3",
      transactionIndex: "0x3d",
      blockHash: "0x0bfb4b4b76bf2933c6a302caa02af57dc5ae09c68b228cf1b520d8b3653a321e",
      blockNumber: "0x80ef3cc",
      gasUsed: "0x1c0d84",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: null,
      contractAddress: "0x418cc337fc19d8cf3b41a9c6e3138a60e34eb9b5"
    }
  },
  {
    method: "eth_getTransactionByHash",
    params: [
      "0x6304ed426f3653eb73f6eade845c5ef1e8b2e34be5270e1ac7b3b8a4431e8ebe"
    ],
    result: {
      type: "0x2",
      chainId: "0x38",
      nonce: "0x1285",
      gas: "0xffa3",
      maxFeePerGas: "0x2faf080",
      maxPriorityFeePerGas: "0x2faf080",
      to: "0x74c20deb476dca58459956b1acd65771197900c9",
      value: "0x0",
      accessList: [],
      input: "0x10265fa5000000000000000000000000418cc337fc19d8cf3b41a9c6e3138a60e34eb9b5",
      r: "0x24b81ba00b056850fc724bc9c96c33391757bae0d46b979511490fe40c67ff91",
      s: "0x652b55c6f178612ad9eeed2f8bd2dd57d84aa6b2ac9fd58db762c5e7938ab5a5",
      yParity: "0x1",
      v: "0x1",
      hash: "0x6304ed426f3653eb73f6eade845c5ef1e8b2e34be5270e1ac7b3b8a4431e8ebe",
      blockHash: "0xc889b5f36070a5ab76f384b4283bd16e1a04651df7bdabb062777876622fe229",
      blockNumber: "0x80ef472",
      transactionIndex: "0x75",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      gasPrice: "0x2faf080",
      blockTimestamp: "0x6b03b09d"
    }
  },
  {
    method: "eth_getTransactionReceipt",
    params: [
      "0x6304ed426f3653eb73f6eade845c5ef1e8b2e34be5270e1ac7b3b8a4431e8ebe"
    ],
    result: {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0x1e00727",
      logs: [
        {
          address: "0x74c20deb476dca58459956b1acd65771197900c9",
          topics: [
            "0x3916d079df018feca66a550908f671cff67410227b4a8c24f13531847e12b9c8",
            "0x000000000000000000000000418cc337fc19d8cf3b41a9c6e3138a60e34eb9b5"
          ],
          data: "0x",
          blockHash: "0xc889b5f36070a5ab76f384b4283bd16e1a04651df7bdabb062777876622fe229",
          blockNumber: "0x80ef472",
          blockTimestamp: "0x6b03b09d",
          transactionHash: "0x6304ed426f3653eb73f6eade845c5ef1e8b2e34be5270e1ac7b3b8a4431e8ebe",
          transactionIndex: "0x75",
          logIndex: "0x60b",
          removed: false
        }
      ],
      logsBloom: "0x00000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000100000000000000040000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000000000000004000000",
      transactionHash: "0x6304ed426f3653eb73f6eade845c5ef1e8b2e34be5270e1ac7b3b8a4431e8ebe",
      transactionIndex: "0x75",
      blockHash: "0xc889b5f36070a5ab76f384b4283bd16e1a04651df7bdabb062777876622fe229",
      blockNumber: "0x80ef472",
      gasUsed: "0xcc82",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: "0x74c20deb476dca58459956b1acd65771197900c9",
      contractAddress: null
    }
  },
  {
    method: "eth_getCode",
    params: [
      "0x74c20dEB476Dca58459956b1AcD65771197900C9",
      "latest"
    ],
    result: "0x608060405260043610610105575f3560e01c80637d25a05e11610092578063b1f8671711610062578063b1f867171461033b578063c13bd9361461034f578063d96661ef1461037b578063e495f1d4146103ae578063ff7bd03d146103d9575f5ffd5b80637d25a05e1461028857806383d5f21d146102bf578063a7a1ed72146102e9578063acba7b4214610308575f5ffd5b806315aff54e116100d857806315aff54e146101855780634922eec1146101c65780634cedb60f146101f25780635e280f111461022957806378360c8814610268575f5ffd5b80630200e86b1461010957806307f53ee71461012a57806310265fa51461015357806313137d6514610172575b5f5ffd5b348015610114575f5ffd5b506101286101233660046114b9565b610408565b005b61013d6101383660046114e6565b6104c0565b60405161014a9190611506565b60405180910390f35b34801561015e575f5ffd5b5061012861016d36600461155e565b610788565b6101286101803660046115d3565b610b7f565b348015610190575f5ffd5b506101b87fc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e9281565b60405190815260200161014a565b3480156101d1575f5ffd5b506101e56101e03660046114e6565b610f8e565b60405161014a91906116b0565b3480156101fd575f5ffd5b50600254610211906001600160801b031681565b6040516001600160801b03909116815260200161014a565b348015610234575f5ffd5b50610250731a44076050125825900e736c501f859c50fe728c81565b6040516001600160a01b03909116815260200161014a565b348015610273575f5ffd5b506101b85f516020611a075f395f51905f5281565b348015610293575f5ffd5b506102a76102a23660046116d5565b611273565b6040516001600160401b03909116815260200161014a565b3480156102ca575f5ffd5b506102d46176aa81565b60405163ffffffff909116815260200161014a565b3480156102f4575f5ffd5b50600154610250906001600160a01b031681565b348015610313575f5ffd5b506102507f000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a878981565b348015610346575f5ffd5b506101e561127b565b34801561035a575f5ffd5b5061036e6103693660046114e6565b6112d5565b60405161014a91906116fd565b348015610386575f5ffd5b506101b87ff5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb81565b3480156103b9575f5ffd5b506101b86103c8366004611714565b60036020525f908152604090205481565b3480156103e4575f5ffd5b506103f86103f336600461172b565b6113ef565b604051901515815260200161014a565b336001600160a01b037f000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a87891614158061044e57506002546001600160801b03908116908216105b1561046c57604051636dac6a0960e01b815260040160405180910390fd5b600280546001600160801b0319166001600160801b0383169081179091556040519081527f4bbad5fe035af81686d3e8380dfd61d879211cbe2c4e6e05f86ad07cdec099b09060200160405180910390a150565b6104c8611479565b6104d0611451565b6040805160a0810182526176aa81527fc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e9260208201525f91810161051285610f8e565b815260200161051f61127b565b81525f6020909101819052604051631bb8518b60e31b815291925090731a44076050125825900e736c501f859c50fe728c9063ddc28c58906105679085903090600401611745565b6040805180830381865afa158015610581573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906105a59190611815565b805190915015806105b95750602081015115155b806105c5575080513414155b156105e357604051636dac6a0960e01b815260040160405180910390fd5b6040516302637a4560e41b8152731a44076050125825900e736c501f859c50fe728c90632637a45090349061061e9086903390600401611745565b60806040518083038185885af115801561063a573d5f5f3e3d5ffd5b50505050506040513d601f19601f8201168201806040525081019061065f9190611843565b8051909350158061067b575060208301516001600160401b0316155b8061068d575060408301516020015115155b8061069c575060408301515134105b156106ba57604051636dac6a0960e01b815260040160405180910390fd5b825f01517f6d23cdaef17712141c7441cf202389c6ddc063fb5c14788d5c4479b62096d13f8560015f9054906101000a90046001600160a01b03166001600160a01b031663172195226040518163ffffffff1660e01b8152600401602060405180830381865afa158015610730573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061075491906118b6565b6040805160ff90931683526001600160401b0390911660208301520160405180910390a2505061078360015f55565b919050565b336001600160a01b037f000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a8789161415806107ca57506001546001600160a01b031615155b806107dd57506001600160a01b0381163b155b806108595750306001600160a01b0316816001600160a01b03166303eadcfc6040518163ffffffff1660e01b8152600401602060405180830381865afa158015610829573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061084d91906118d1565b6001600160a01b031614155b806108e357507ff5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb816001600160a01b031663d96661ef6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156108bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906108e091906118ec565b14155b8061095c57505f516020611a075f395f51905f525f1b816001600160a01b03166378360c886040518163ffffffff1660e01b8152600401602060405180830381865afa158015610935573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061095991906118ec565b14155b806109ec57507355d398326f99059ff775485246999027b31979556001600160a01b0316816001600160a01b031663e5a6b10f6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156109bc573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906109e091906118d1565b6001600160a01b031614155b80610a7c575073c440f06bbc7e58b0d055815f915447e4ae0e37206001600160a01b0316816001600160a01b03166361d027b36040518163ffffffff1660e01b8152600401602060405180830381865afa158015610a4c573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610a7091906118d1565b6001600160a01b031614155b80610b1857507f000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a87896001600160a01b0316816001600160a01b031663f77c47916040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ae8573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610b0c91906118d1565b6001600160a01b031614155b15610b3657604051636dac6a0960e01b815260040160405180910390fd5b600180546001600160a01b0319166001600160a01b0383169081179091556040517f3916d079df018feca66a550908f671cff67410227b4a8c24f13531847e12b9c8905f90a250565b610b87611451565b33731a44076050125825900e736c501f859c50fe728c141580610bbe57506176aa610bb56020890189611903565b63ffffffff1614155b80610bed57507fc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92876020013514155b80610c0157506001546001600160a01b0316155b80610c0a575085155b80610c2b5750610c20606088016040890161191c565b6001600160401b0316155b80610c3557503415155b15610c5357604051636dac6a0960e01b815260040160405180910390fd5b608a84141580610c7e575084845f818110610c7057610c70611937565b9091013560f81c6003141590505b15610c9c57604051636dac6a0960e01b815260040160405180910390fd5b5f85856001818110610cb057610cb0611937565b919091013560f81c91505f9050610ccb60226002888a61194b565b610cd491611972565b90505f610ce560426022898b61194b565b610cee91611972565b90505f610cff604a60428a8c61194b565b610d089161198f565b60c01c90505f610d1c606a604a8b8d61194b565b610d2591611972565b90505f610d36608a606a8c8e61194b565b610d3f91611972565b90507ff5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb85141580610d7d57505f516020611a075f395f51905f528414155b80610d8f57506001600160401b038316155b15610dad57604051636dac6a0960e01b815260040160405180910390fd5b5f8b8b604051610dbe9291906119c5565b60408051918290039091205f8f81526003602052919091205490915015801590610df557505f8d8152600360205260409020548114155b15610e1357604051636dac6a0960e01b815260040160405180910390fd5b8660ff16600103610eb05782151580610e2b57508115155b15610e4957604051636dac6a0960e01b815260040160405180910390fd5b60015460405163579c848360e11b81526001600160401b03861660048201526001600160a01b039091169063af390906906024015b5f604051808303815f87803b158015610e95575f5ffd5b505af1158015610ea7573d5f5f3e3d5ffd5b50505050610f1b565b8660ff16600303610f025760015460405163367938c560e21b81526001600160401b038616600482015260248101859052604481018490526001600160a01b039091169063d9e4e31490606401610e7e565b604051636dac6a0960e01b815260040160405180910390fd5b5f8d815260036020908152604091829020839055815160ff8a1681526001600160401b038716918101919091528e917f37949e68c9d0a4e5f5474ddb8654f999a5dc4b58a8aa1aef313516586e9b320a910160405180910390a250505050505050610f8560015f55565b50505050505050565b6001546060906001600160a01b0316610fba57604051636dac6a0960e01b815260040160405180910390fd5b8160ff166002036110705760035b60015f9054906101000a90046001600160a01b03166001600160a01b031663c19d93fb6040518163ffffffff1660e01b8152600401602060405180830381865afa158015611018573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061103c91906119e8565b600481111561104d5761104d6119d4565b1461106b57604051636dac6a0960e01b815260040160405180910390fd5b611082565b8160ff16600403610f02576004610fc8565b60015460408051630b90ca9160e11b8152905160039285927ff5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb925f516020611a075f395f51905f52926001600160a01b03169163172195229160048083019260209291908290030181865afa1580156110fd573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061112191906118b6565b60015f9054906101000a90046001600160a01b03166001600160a01b0316635467e0a76040518163ffffffff1660e01b8152600401602060405180830381865afa158015611171573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061119591906118ec565b60015f9054906101000a90046001600160a01b03166001600160a01b03166366d003ac6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156111e5573d5f5f3e3d5ffd5b505050506040513d601f19601f8201168201806040525081019061120991906118ec565b60405160f897881b6001600160f81b031990811660208301529690971b90951660218701526022860193909352604285019190915260c01b6001600160c01b0319166062840152606a830152608a82015260aa016040516020818303038152906040529050919050565b5f5b92915050565b600254604051600360f01b6020820152600160f81b60228201819052601160f01b6023830152602582015260809190911b6001600160801b0319166026820152606090603601604051602081830303815290604052905090565b604080518082019091525f80825260208201526040805160a0810182526176aa81527fc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e9260208201525f91731a44076050125825900e736c501f859c50fe728c9163ddc28c5891810161134687610f8e565b815260200161135361127b565b81525f6020909101526040516001600160e01b031960e084901b16815261137f91903090600401611745565b6040805180830381865afa158015611399573d5f5f3e3d5ffd5b505050506040513d601f19601f820116820180604052508101906113bd9190611815565b805190915015806113d15750602081015115155b1561127557604051636dac6a0960e01b815260040160405180910390fd5b5f6176aa6114006020840184611903565b63ffffffff1614801561143657507fc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e928260200135145b801561127557506001546001600160a01b0316151592915050565b60025f540361147357604051633ee5aeb560e01b815260040160405180910390fd5b60025f55565b60405180606001604052805f81526020015f6001600160401b031681526020016114b460405180604001604052805f81526020015f81525090565b905290565b5f602082840312156114c9575f5ffd5b81356001600160801b03811681146114df575f5ffd5b9392505050565b5f602082840312156114f6575f5ffd5b813560ff811681146114df575f5ffd5b5f608082019050825182526001600160401b0360208401511660208301526040830151611540604084018280518252602090810151910152565b5092915050565b6001600160a01b038116811461155b575f5ffd5b50565b5f6020828403121561156e575f5ffd5b81356114df81611547565b5f60608284031215611589575f5ffd5b50919050565b5f5f83601f84011261159f575f5ffd5b5081356001600160401b038111156115b5575f5ffd5b6020830191508360208285010111156115cc575f5ffd5b9250929050565b5f5f5f5f5f5f5f60e0888a0312156115e9575f5ffd5b6115f38989611579565b96506060880135955060808801356001600160401b03811115611614575f5ffd5b6116208a828b0161158f565b90965094505060a088013561163481611547565b925060c08801356001600160401b0381111561164e575f5ffd5b61165a8a828b0161158f565b989b979a50959850939692959293505050565b5f81518084525f5b8181101561169157602081850181015186830182015201611675565b505f602082860101526020601f19601f83011685010191505092915050565b602081525f6114df602083018461166d565b803563ffffffff81168114610783575f5ffd5b5f5f604083850312156116e6575f5ffd5b6116ef836116c2565b946020939093013593505050565b815181526020808301519082015260408101611275565b5f60208284031215611724575f5ffd5b5035919050565b5f6060828403121561173b575f5ffd5b6114df8383611579565b6040815263ffffffff8351166040820152602083015160608201525f604084015160a0608084015261177a60e084018261166d565b90506060850151603f198483030160a0850152611797828261166d565b60809690960151151560c08501525050506001600160a01b039190911660209091015290565b5f604082840312156117cd575f5ffd5b604080519081016001600160401b03811182821017156117fb57634e487b7160e01b5f52604160045260245ffd5b604052825181526020928301519281019290925250919050565b5f60408284031215611825575f5ffd5b6114df83836117bd565b6001600160401b038116811461155b575f5ffd5b5f6080828403128015611854575f5ffd5b50604051606081016001600160401b038111828210171561188357634e487b7160e01b5f52604160045260245ffd5b6040528251815260208301516118988161182f565b60208201526118aa84604085016117bd565b60408201529392505050565b5f602082840312156118c6575f5ffd5b81516114df8161182f565b5f602082840312156118e1575f5ffd5b81516114df81611547565b5f602082840312156118fc575f5ffd5b5051919050565b5f60208284031215611913575f5ffd5b6114df826116c2565b5f6020828403121561192c575f5ffd5b81356114df8161182f565b634e487b7160e01b5f52603260045260245ffd5b5f5f85851115611959575f5ffd5b83861115611965575f5ffd5b5050820193919092039150565b80356020831015611275575f19602084900360031b1b1692915050565b80356001600160c01b03198116906008841015611540576001600160c01b031960089490940360031b84901b1690921692915050565b818382375f9101908152919050565b634e487b7160e01b5f52602160045260245ffd5b5f602082840312156119f8575f5ffd5b8151600581106114df575f5ffdfe046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6baa2646970667358221220d5e0a008fcf934cc781ad8e21c7865f692e69e850ec3b05743fb3e9c2c69c09a64736f6c634300081e0033"
  },
  {
    method: "eth_getCode",
    params: [
      "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
      "latest"
    ],
    result: "0x608060405234801561000f575f5ffd5b50600436106101f2575f3560e01c806370a0823111610114578063b88d4fde116100a9578063d96661ef11610079578063d96661ef14610492578063d9e4e314146104b9578063e5a6b10f146104cc578063e985e9c5146104e7578063f77c4791146104fa575f5ffd5b8063b88d4fde14610445578063c19d93fb14610458578063c87b56dd14610472578063c9f2071514610485575f5ffd5b806397579dd3116100e457806397579dd314610404578063a22cb46514610417578063a6f2ae3a1461042a578063af39090614610432575f5ffd5b806370a08231146103b257806378360c88146103c55780638d859f3e146103ec57806395d89b41146103fc575f5ffd5b806323b872dd1161018a57806361d027b31161015a57806361d027b3146103545780636352211e1461036f57806366d003ac146103825780636af7f9f51461038b575f5ffd5b806323b872dd14610312578063325832ac1461032557806342842e0e146103385780635467e0a71461034b575f5ffd5b8063081812fc116101c5578063081812fc146102a75780630823d5f3146102ba578063095ea7b3146102cd57806317219522146102e2575f5ffd5b806301ffc9a7146101f657806303eadcfc1461021e57806306f660a71461025d57806306fdde0314610292575b5f5ffd5b610209610204366004611962565b610521565b60405190151581526020015b60405180910390f35b6102457f00000000000000000000000074c20deb476dca58459956b1acd65771197900c981565b6040516001600160a01b039091168152602001610215565b6102847f97a48aa4c129657440dafdacd4c836389734d28cc4a0ca7403e68da660a74a5981565b604051908152602001610215565b61029a610572565b60405161021591906119ca565b6102456102b53660046119dc565b610601565b6102096102c8366004611a09565b610628565b6102e06102db366004611a22565b61068f565b005b6007546102fa9061010090046001600160401b031681565b6040516001600160401b039091168152602001610215565b6102e0610320366004611a4a565b61069e565b6102e0610333366004611a93565b61072c565b6102e0610346366004611a4a565b6107bc565b61028460085481565b61024573c440f06bbc7e58b0d055815f915447e4ae0e372081565b61024561037d3660046119dc565b6107db565b61028460095481565b6102457f000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a878981565b6102846103c0366004611a09565b6107e5565b6102847f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba81565b61028468015af1d78b58c4000081565b61029a61082a565b6102846104123660046119dc565b610839565b6102e0610425366004611aac565b6109c4565b6102e06109cf565b6102e0610440366004611af3565b610d15565b6102e0610453366004611b20565b610ea8565b6007546104659060ff1681565b6040516102159190611c0e565b61029a6104803660046119dc565b610ec0565b600a546102099060ff1681565b6102847ff5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb81565b6102e06104c7366004611c34565b610f31565b6102457355d398326f99059ff775485246999027b319795581565b6102096104f5366004611c64565b61109d565b6102457f000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a878981565b5f6001600160e01b031982166380ac58cd60e01b148061055157506001600160e01b03198216635b5e139f60e01b145b8061056c57506301ffc9a760e01b6001600160e01b03198316145b92915050565b60605f805461058090611c8c565b80601f01602080910402602001604051908101604052809291908181526020018280546105ac90611c8c565b80156105f75780601f106105ce576101008083540402835291602001916105f7565b820191905f5260205f20905b8154815290600101906020018083116105da57829003601f168201915b5050505050905090565b5f61060b826110ca565b505f828152600460205260409020546001600160a01b031661056c565b5f600260075460ff16600481111561064257610642611bfa565b14801561065757506001600160a01b03821615155b801561056c57505060075461010090046001600160401b03165f908152600260205260409020546001600160a01b0391821691161490565b61069a828233611102565b5050565b6001600160a01b0382166106cc57604051633250574960e11b81525f60048201526024015b60405180910390fd5b5f6106d883833361110f565b9050836001600160a01b0316816001600160a01b031614610726576040516364283d7b60e01b81526001600160a01b03808616600483015260248201849052821660448201526064016106c3565b50505050565b336001600160a01b037f000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a8789161461077557604051636dac6a0960e01b815260040160405180910390fd5b600a805460ff19168215159081179091556040519081527fd6d0fdd597c17a0211f0324826035a55dec84b1e6196f3585be220b46767fbb99060200160405180910390a150565b6107d683838360405180602001604052805f815250610ea8565b505050565b5f61056c826110ca565b5f6001600160a01b03821661080f576040516322718ad960e21b81525f60048201526024016106c3565b506001600160a01b03165f9081526003602052604090205490565b60606001805461058090611c8c565b5f6108426111ad565b600260075460ff16600481111561085b5761085b611bfa565b14158061088b5750600754339061087f9061010090046001600160401b03166107db565b6001600160a01b031614155b80610894575081155b156108b257604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff1916600390811791829055600984905560408051602081019290925246908201523060608201527ff5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb60808201527f046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba60a08201526001600160401b03610100928390041660c08201523360e08201529081018390526101200160408051808303601f19018152908290528051602091820120600881905560075485845290926101009091046001600160401b0316917f5852bd51fa2990e2712a8f82286a04ca0750a7646a7950235ffefdb10585cefe910160405180910390a3506008546109bf6001600655565b919050565b61069a3383836111d7565b6109d76111ad565b600160075460ff1660048111156109f0576109f0611bfa565b1415806109ff5750600a5460ff165b80610a335750336001600160a01b037f000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a87891614155b80610a7357507355d398326f99059ff775485246999027b31979553f7f97a48aa4c129657440dafdacd4c836389734d28cc4a0ca7403e68da660a74a5914155b80610af557507355d398326f99059ff775485246999027b31979556001600160a01b031663313ce5676040518163ffffffff1660e01b8152600401602060405180830381865afa158015610ac9573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610aed9190611cc4565b60ff16601214155b15610b1357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660021790556040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201525f907355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610b83573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610ba79190611ce4565b9050610be67355d398326f99059ff775485246999027b31979553373c440f06bbc7e58b0d055815f915447e4ae0e372068015af1d78b58c40000611275565b610bf968015af1d78b58c4000082611d0f565b6040516370a0823160e01b815273c440f06bbc7e58b0d055815f915447e4ae0e372060048201527355d398326f99059ff775485246999027b3197955906370a0823190602401602060405180830381865afa158015610c5a573d5f5f3e3d5ffd5b505050506040513d601f19601f82011682018060405250810190610c7e9190611ce4565b14610c9c57604051636dac6a0960e01b815260040160405180910390fd5b600754610cb890339061010090046001600160401b03166112cf565b60075460405168015af1d78b58c400008152339161010090046001600160401b0316907f266845010576f42f87c2d262b76328c22b6797abd6c81b34f59fc1b2da1c487e9060200160405180910390a350610d136001600655565b565b336001600160a01b037f00000000000000000000000074c20deb476dca58459956b1acd65771197900c91614610d5e57604051636dac6a0960e01b815260040160405180910390fd5b806001600160401b03165f03610d8757604051636dac6a0960e01b815260040160405180910390fd5b6007546001600160401b038281166101009092041614610ea557600754610dbd9061010090046001600160401b03166001611d22565b6001600160401b0316816001600160401b0316141580610e1557505f60075460ff166004811115610df057610df0611bfa565b14158015610e155750600460075460ff166004811115610e1257610e12611bfa565b14155b15610e3357604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff196001600160401b0384166101008102821668ffffffffffffffffff199093169290921760019081179093555f60088190556009819055600a8054909216909317905560405190917ff48a2acdce0f4a30c2d32425d8827b030bbdff66b7694573d92cdd52b818fd1691a25b50565b610eb384848461069e565b61072633858585856112e8565b6060610ecb826110ca565b505f610ee160408051602081019091525f815290565b90505f815111610eff5760405180602001604052805f815250610f2a565b80610f0984611410565b604051602001610f1a929190611d41565b6040516020818303038152906040525b9392505050565b336001600160a01b037f00000000000000000000000074c20deb476dca58459956b1acd65771197900c91614610f7a57604051636dac6a0960e01b815260040160405180910390fd5b610f826111ad565b6007546001600160401b0384811661010090920416141580610fa2575081155b80610faf57506008548214155b80610fbc57506009548114155b15610fda57604051636dac6a0960e01b815260040160405180910390fd5b600460075460ff166004811115610ff357610ff3611bfa565b1461109357600360075460ff16600481111561101157611011611bfa565b1461102f57604051636dac6a0960e01b815260040160405180910390fd5b6007805460ff191660041790819055611056906001600160401b036101009091041661149f565b600754604051839161010090046001600160401b0316907f4baa52424160077091b85a05340629c1a44cfac77a87274fad62a384fe6193f0905f90a35b6107d66001600655565b6001600160a01b039182165f90815260056020908152604080832093909416825291909152205460ff1690565b5f818152600260205260408120546001600160a01b03168061056c57604051637e27328960e01b8152600481018490526024016106c3565b6107d683838360016114d7565b6007545f9061010090046001600160401b03168314158061117c5750600260075460ff16600481111561114457611144611bfa565b1415801561117c5750600460075460ff16600481111561116657611166611bfa565b14801561117a57506001600160a01b038416155b155b1561119a57604051636dac6a0960e01b815260040160405180910390fd5b6111a58484846115db565b949350505050565b6002600654036111d057604051633ee5aeb560e01b815260040160405180910390fd5b6002600655565b6001600160a01b03821661120957604051630b61174360e31b81526001600160a01b03831660048201526024016106c3565b6001600160a01b038381165f81815260056020908152604080832094871680845294825291829020805460ff191686151590811790915591519182527f17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31910160405180910390a3505050565b604080516001600160a01b0385811660248301528416604482015260648082018490528251808303909101815260849091019091526020810180516001600160e01b03166323b872dd60e01b1790526107269085906116cd565b61069a828260405180602001604052805f815250611739565b6001600160a01b0383163b1561140957604051630a85bd0160e11b81526001600160a01b0384169063150b7a029061132a908890889087908790600401611d6f565b6020604051808303815f875af1925050508015611364575060408051601f3d908101601f1916820190925261136191810190611dab565b60015b6113cb573d808015611391576040519150601f19603f3d011682016040523d82523d5f602084013e611396565b606091505b5080515f036113c357604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b805160208201fd5b6001600160e01b03198116630a85bd0160e11b1461140757604051633250574960e11b81526001600160a01b03851660048201526024016106c3565b505b5050505050565b60605f61141c83611750565b60010190505f816001600160401b0381111561143a5761143a611b0c565b6040519080825280601f01601f191660200182016040528015611464576020820181803683370190505b5090508181016020015b5f19016f181899199a1a9b1b9c1cb0b131b232b360811b600a86061a8153600a850494508461146e57509392505050565b5f6114ab5f835f61110f565b90506001600160a01b03811661069a57604051637e27328960e01b8152600481018390526024016106c3565b80806114eb57506001600160a01b03821615155b156115ac575f6114fa846110ca565b90506001600160a01b038316158015906115265750826001600160a01b0316816001600160a01b031614155b80156115395750611537818461109d565b155b156115625760405163a9fbf51f60e01b81526001600160a01b03841660048201526024016106c3565b81156115aa5783856001600160a01b0316826001600160a01b03167f8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b92560405160405180910390a45b505b50505f90815260046020526040902080546001600160a01b0319166001600160a01b0392909216919091179055565b5f828152600260205260408120546001600160a01b039081169083161561160757611607818486611827565b6001600160a01b03811615611641576116225f855f5f6114d7565b6001600160a01b0381165f90815260036020526040902080545f190190555b6001600160a01b0385161561166f576001600160a01b0385165f908152600360205260409020805460010190555b5f8481526002602052604080822080546001600160a01b0319166001600160a01b0389811691821790925591518793918516917fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef91a4949350505050565b5f5f60205f8451602086015f885af1806116ec576040513d5f823e3d81fd5b50505f513d91508115611703578060011415611710565b6001600160a01b0384163b155b1561072657604051635274afe760e01b81526001600160a01b03851660048201526024016106c3565b611743838361188b565b6107d6335f8585856112e8565b5f8072184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b831061178e5772184f03e93ff9f4daa797ed6e38ed64bf6a1f0160401b830492506040015b6d04ee2d6d415b85acef810000000083106117ba576d04ee2d6d415b85acef8100000000830492506020015b662386f26fc1000083106117d857662386f26fc10000830492506010015b6305f5e10083106117f0576305f5e100830492506008015b612710831061180457612710830492506004015b60648310611816576064830492506002015b600a831061056c5760010192915050565b6118328383836118ec565b6107d6576001600160a01b03831661186057604051637e27328960e01b8152600481018290526024016106c3565b60405163177e802f60e01b81526001600160a01b0383166004820152602481018290526044016106c3565b6001600160a01b0382166118b457604051633250574960e11b81525f60048201526024016106c3565b5f6118c083835f61110f565b90506001600160a01b038116156107d6576040516339e3563760e11b81525f60048201526024016106c3565b5f6001600160a01b038316158015906111a55750826001600160a01b0316846001600160a01b031614806119255750611925848461109d565b806111a55750505f908152600460205260409020546001600160a01b03908116911614919050565b6001600160e01b031981168114610ea5575f5ffd5b5f60208284031215611972575f5ffd5b8135610f2a8161194d565b5f5b8381101561199757818101518382015260200161197f565b50505f910152565b5f81518084526119b681602086016020860161197d565b601f01601f19169290920160200192915050565b602081525f610f2a602083018461199f565b5f602082840312156119ec575f5ffd5b5035919050565b80356001600160a01b03811681146109bf575f5ffd5b5f60208284031215611a19575f5ffd5b610f2a826119f3565b5f5f60408385031215611a33575f5ffd5b611a3c836119f3565b946020939093013593505050565b5f5f5f60608486031215611a5c575f5ffd5b611a65846119f3565b9250611a73602085016119f3565b929592945050506040919091013590565b803580151581146109bf575f5ffd5b5f60208284031215611aa3575f5ffd5b610f2a82611a84565b5f5f60408385031215611abd575f5ffd5b611ac6836119f3565b9150611ad460208401611a84565b90509250929050565b80356001600160401b03811681146109bf575f5ffd5b5f60208284031215611b03575f5ffd5b610f2a82611add565b634e487b7160e01b5f52604160045260245ffd5b5f5f5f5f60808587031215611b33575f5ffd5b611b3c856119f3565b9350611b4a602086016119f3565b92506040850135915060608501356001600160401b03811115611b6b575f5ffd5b8501601f81018713611b7b575f5ffd5b80356001600160401b03811115611b9457611b94611b0c565b604051601f8201601f19908116603f011681016001600160401b0381118282101715611bc257611bc2611b0c565b604052818152828201602001891015611bd9575f5ffd5b816020840160208301375f6020838301015280935050505092959194509250565b634e487b7160e01b5f52602160045260245ffd5b6020810160058310611c2e57634e487b7160e01b5f52602160045260245ffd5b91905290565b5f5f5f60608486031215611c46575f5ffd5b611c4f84611add565b95602085013595506040909401359392505050565b5f5f60408385031215611c75575f5ffd5b611c7e836119f3565b9150611ad4602084016119f3565b600181811c90821680611ca057607f821691505b602082108103611cbe57634e487b7160e01b5f52602260045260245ffd5b50919050565b5f60208284031215611cd4575f5ffd5b815160ff81168114610f2a575f5ffd5b5f60208284031215611cf4575f5ffd5b5051919050565b634e487b7160e01b5f52601160045260245ffd5b8082018082111561056c5761056c611cfb565b6001600160401b03818116838216019081111561056c5761056c611cfb565b5f8351611d5281846020880161197d565b835190830190611d6681836020880161197d565b01949350505050565b6001600160a01b03858116825284166020820152604081018390526080606082018190525f90611da19083018461199f565b9695505050505050565b5f60208284031215611dbb575f5ffd5b8151610f2a8161194d56fea26469706673582212205cd0600d0bc59401f6362a6ffeeddd9fccccd322ad458bc4283018628c84b01f64736f6c634300081e0033"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
        data: "0x15aff54e"
      },
      "latest"
    ],
    result: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
        data: "0xd96661ef"
      },
      "latest"
    ],
    result: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
        data: "0xacba7b42"
      },
      "latest"
    ],
    result: "0x000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a8789"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
        data: "0x5e280f11"
      },
      "latest"
    ],
    result: "0x0000000000000000000000001a44076050125825900e736c501f859c50fe728c"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
        data: "0x78360c88"
      },
      "latest"
    ],
    result: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
        data: "0xa7a1ed72"
      },
      "latest"
    ],
    result: "0x000000000000000000000000418cc337fc19d8cf3b41a9c6e3138a60e34eb9b5"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x1a44076050125825900e736c501f859c50fE728c",
        data: "0x587cde1e00000000000000000000000074c20deb476dca58459956b1acd65771197900c9"
      },
      "latest"
    ],
    result: "0x000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a8789"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
        data: "0x03eadcfc"
      },
      "latest"
    ],
    result: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c9"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
        data: "0xf77c4791"
      },
      "latest"
    ],
    result: "0x000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a8789"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
        data: "0x6af7f9f5"
      },
      "latest"
    ],
    result: "0x000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a8789"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
        data: "0x61d027b3"
      },
      "latest"
    ],
    result: "0x000000000000000000000000c440f06bbc7e58b0d055815f915447e4ae0e3720"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
        data: "0xe5a6b10f"
      },
      "latest"
    ],
    result: "0x00000000000000000000000055d398326f99059ff775485246999027b3197955"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
        data: "0xd96661ef"
      },
      "latest"
    ],
    result: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
        data: "0x06f660a7"
      },
      "latest"
    ],
    result: "0x97a48aa4c129657440dafdacd4c836389734d28cc4a0ca7403e68da660a74a59"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
        data: "0xc9f20715"
      },
      "latest"
    ],
    result: "0x0000000000000000000000000000000000000000000000000000000000000001"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
        data: "0xc19d93fb"
      },
      "latest"
    ],
    result: "0x0000000000000000000000000000000000000000000000000000000000000000"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
        data: "0x17219522"
      },
      "latest"
    ],
    result: "0x0000000000000000000000000000000000000000000000000000000000000000"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
        data: "0x0823d5f3000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a8789"
      },
      "latest"
    ],
    result: "0x0000000000000000000000000000000000000000000000000000000000000000"
  },
  {
    method: "eth_getTransactionByHash",
    params: [
      "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733"
    ],
    result: {
      type: "0x2",
      chainId: "0x38",
      nonce: "0x1286",
      gas: "0x1d4c0",
      maxFeePerGas: "0x2faf080",
      maxPriorityFeePerGas: "0x2faf080",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      value: "0x0",
      accessList: [],
      input: "0x9535ff3000000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa0000000000000000000000009f8c645f2d0b2159767bd6e0839de4be49e823de",
      r: "0xdd148b0015b676a5c586a56db39fb7d2c39017050a19b00e0b83f584ea8a1ab7",
      s: "0x1ff19042528fb5ceac692f040022d3766d260ce88a7016dcf7def293abc06692",
      yParity: "0x1",
      v: "0x1",
      hash: "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733",
      blockHash: "0x32c2401f1aeefe07a6f0677c12f9773f7111a7c9864494576c6fc90e6783e06e",
      blockNumber: "0x80f284f",
      transactionIndex: "0x48",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      gasPrice: "0x2faf080",
      blockTimestamp: "0x6b03c7f6"
    }
  },
  {
    method: "eth_getTransactionReceipt",
    params: [
      "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733"
    ],
    result: {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xb7bc22",
      logs: [
        {
          address: "0x1a44076050125825900e736c501f859c50fe728c",
          topics: [
            "0x4cff966ebee29a156dcb34cf72c1d06231fb1777f6bdf6e8089819232f002b1c"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa0000000000000000000000009f8c645f2d0b2159767bd6e0839de4be49e823de",
          blockHash: "0x32c2401f1aeefe07a6f0677c12f9773f7111a7c9864494576c6fc90e6783e06e",
          blockNumber: "0x80f284f",
          blockTimestamp: "0x6b03c7f6",
          transactionHash: "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733",
          transactionIndex: "0x48",
          logIndex: "0x278",
          removed: false
        }
      ],
      logsBloom: "0x00000000000000000000000000000000000200000000000000000000001000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000010000000000000000000000",
      transactionHash: "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733",
      transactionIndex: "0x48",
      blockHash: "0x32c2401f1aeefe07a6f0677c12f9773f7111a7c9864494576c6fc90e6783e06e",
      blockNumber: "0x80f284f",
      gasUsed: "0xe182",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      contractAddress: null
    }
  },
  {
    method: "eth_getBlockByNumber",
    params: [
      "0x80f284f",
      false
    ],
    result: {
      baseFeePerGas: "0x0",
      blobGasUsed: "0x0",
      difficulty: "0x2",
      excessBlobGas: "0x0",
      extraData: "0xda8301080288653733306664346488676f312e32372e34836c696e0023d35e07f8b5831fffffb8609110584ac43ae767f487aa93150de60870994175362918beb61ed1f655c7f198ddbce19b2fe24c702ae516668d6381da077358857355d6e1eae60eb2311b4f3e9c7b5cbb78dc9054990e1d19aad29222d9e8628c848ddf44e9bc3d95464c4545f84c84080f284da0eba6c3af9eed015de6f09f1343062089c1d1208f235fce94d1e56c33f66efc9884080f284ea0ab84762ccba73b117b9be815d213231932efdf0cb627f819f636201c19c9fe8f80c841db025d1c5d1c74d3785f1818e2a93cb8f0ccb86100d99e867e821210e40759f53a6cbf8bd5f4bb292d98c465d4d56a1508aaf9604dd13dc9767c41ce600801",
      gasLimit: "0x4c4b400",
      gasUsed: "0xc1064b",
      hash: "0x32c2401f1aeefe07a6f0677c12f9773f7111a7c9864494576c6fc90e6783e06e",
      logsBloom: "0x23f6d7975ffef51272e6d3df8421fdffdfdfdb7b775fe7ef7d7bdeac4cfeffffbfaed17f27f8ebf953bfeefdc73bf9b1fe7fdaff37bfe4df6ffff9bf37fdf7dfcdadefdbedefaf33b9bd2fdbf3f8dfef77b3bff7ffefef63abbf7f6abffbfddf5fab21f8cbdffe33affefcfbf6dfff77ae79eaa7ebbfe77fff2b6efeffd5977ca7ebd7ffc7bb4fdffbdfacfafffbff2adf7f1dbf3bff47fddbbaff7bff9f27bc5ea6dfffef2fbdb6fbb7dfbfffaf2fedf4de1cf66fd8dfffbd02747e5d5fa5f7fabcfdffff15d83f5dccf3fffffef7eebee6c0f6d23b6fff57dffbdf5ffffffefbdfe9fbf5efd98ef7ffbbfefdefa1dbff7aeaadf7fbeffff3713f6f9fb78f5b",
      milliTimestamp: "0x1a206c51a1c",
      miner: "0xca503a7ed99eca485da2e875aedf7758472c378c",
      mixHash: "0x000000000000000000000000000000000000000000000000000000000000012c",
      nonce: "0x0000000000000000",
      number: "0x80f284f",
      parentBeaconBlockRoot: "0x0000000000000000000000000000000000000000000000000000000000000000",
      parentHash: "0xab84762ccba73b117b9be815d213231932efdf0cb627f819f636201c19c9fe8f",
      receiptsRoot: "0x931336b78f5375bc53a95fb91d85449a8c5b050ce8f46b9f19b403739acde67a",
      requestsHash: "0x00000000000000000000000248265f91f542dce47abe5e6683bb086c0f36bb48",
      sha3Uncles: "0x1dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347",
      size: "0xe7af",
      stateRoot: "0x5e266829e7ce21139e06a53756c0036e30fb6396fa5e70dab51c17ae9aa853a5",
      timestamp: "0x6b03c7f6",
      totalDifficulty: "0x10155f96",
      transactions: [
        "0x2a5d2333052ae9f2ce9ea1d7ba361c823598278ffb3f9a4ccac93d3186ee18ad",
        "0x93e0d11bc5f8c5b1b814e8240239484434028ba77eab3fa94bca6f140787da32",
        "0xd305338f9a51e36ba99d3d9adb0eca9914c0a8ce389f008117cc5e20e61009d6",
        "0x9be4e474195c8dcdffafecc1ff4490a3a511a8fcdb2fc4eb0fc1cbebe452efb7",
        "0xcd57f3c670a77c92bcf6a8abfcd7de70c147fe870f76451e2227080a980be11c",
        "0x343d44f148771b42b3953fe6b9de355ced518b5dc5aa084777c9eef8a2ced7c9",
        "0x45fd652f4a28e33f76ae2665a524c78f01b263cf5ea917316e826065aa5b63de",
        "0xf93ba9cebf6a5b9578a3bace3e3769861c74380fc5420e4689d72c79330b6505",
        "0x735a189497e32f51c5295cd64237acf338d02e273bf05f39d0099d050e352f32",
        "0xedaf5d50ffff8564ea753af4d3e5356be02c3e50f619ea831aaa1106491732e2",
        "0x60606c5a962b95dcce5da19320e3288ae32d65fd1dfdbbb9321e15fe301727d5",
        "0x79c66eb7991ea18503a9fd81e04ad2657431f8e3c866037ef7d7c8de155ffdc0",
        "0x821778d82a107e25b13a40122f7ce1cf8659cc4a6db9dda7661a3b99e952f916",
        "0xf9f52f24db196e17173832b204c555ce0dfe1fbd396edd5ef19cb731cd95bf7e",
        "0x086d874e41ed6e08508d2913b957aec643516225f30d5e28111305e088fa08ae",
        "0x4d8cc9fc12fdc0843a7b0543032de0f8a6e9e8371a3c2dc0211f0395d02208c6",
        "0xf8b99c1301836c15eb5c7979a3512f434d18d98088ddb44fdb6317380ffc3319",
        "0x922546ab5dabe351a49e41c4bfda4ba0dba4d29cd5294014d9900a3fb1db65f1",
        "0x0e494505bb5f63720e7b56e6d72bc8e341f778c93e6c486573113cf29c8d448e",
        "0x0a1ed63ee426f71dd4c846d6428c29f22c1122790c91ac4a2735d4ef86458c0f",
        "0xf1484cc1155b4b82330ddd32aee3afaa576b2fc0a21615479e7c2b3beef40eb1",
        "0xe60e2bb8365c89ddc6714123bf29b80601807beb7fd528b1b01a2cdf275e43fc",
        "0xf5e6632d3455f280d11cdf1ffd4ab2b2abcb27dc27a3d1c048e50b3b7e312e69",
        "0x9cd345908e9ee50fd9759bafed7e5d30429f26f1be8513961da4b026f3760a35",
        "0x0aa2627f847105204f568d91b6180f206918ff90b2dd99724cdc25277a1af7fa",
        "0x4e8b3a0c83013c1463626c8afb82a5cbb96c0d9afe01762377d9e01eafbf54a9",
        "0x51fa3af777d00265c2308e7d2f85e4615ba4f0c387c03fefd3433146826c2d73",
        "0x27fbe7c2fdf270f74b7281806c5917d54fdda8fd3b550210350e2dd6d870dcfa",
        "0xccf0c0fadfc928eb225852e50ce1c997d205456aa4177105c0f2b51e05c812ff",
        "0x114f6f753832b675fff0af437f04be18ad180c164d558fd7afbc23be4c19c2bc",
        "0x82ca6f9a56e7067d4fedee5f32b4cc85226ff5cb13ed9b1e9ac689ab33078eb6",
        "0x68ade1acd52cdc7c44fb37b41b2f474059462db8054ace6a1d5acfa20f0af4ab",
        "0x35edba3944de71f55c610fe95be1d6fc8a8657ce95db296879605daded4bf367",
        "0x0dcd25d1dc29a17849d299027e3f46eec9692eb2648ad84a7acf4bc25e1186e7",
        "0xc1b73e32e121f6141e3e6f0eb5504d18d6c7e2b41667b4769743acb8209205ff",
        "0x1d02a8b20c7ff942f823d0b48bdd317e429ddacaaddd93ad676f2b571282d654",
        "0xb9141e4f67da2af237b34914a1c28342254734fd88b7d0da19e9f4478958274a",
        "0xc7e592895404767ecf935ee86da255b2870b8f966872781e579bb32a5e07569f",
        "0x16f65112b3e967cbd2d1479db2aaad0aadd0b704c40405950c8955ed83ab4234",
        "0xb902a3c730f84c427006dda433dbc57debd406eebbc495b0a5e93fe1b3f1aa39",
        "0x7105e127e5e7b1df3fe6c18d9323937866d2ebb89bf64fcb2fbcd517d0c479f7",
        "0x274e06e15ebb2b1b75e58aee010313cf965c570c4237f1b326ab8bfdf4f4ba54",
        "0xa5dbb1d26760a810aa1d2dbaec8b26591969f01188e24cf42bb2808511eee73b",
        "0xbed46235c0a1942662ebf4026fc049ead17c854b3228d9c887e9963b15104ad6",
        "0x0cdd5c56f5787d997f2bf1b5ab5bc1b191accce81955be630c8baf28cfb11541",
        "0x1d5febae6267bb51705605ac26161e6f5707cd4025e23b95528edb079fc2c6d5",
        "0x57969606d389c782b29c278d12ba6d3bef0aa7c5d993cc7b4a9ab5f6ffe2841d",
        "0xbc4c468f7fa141f69e089a0ac191c5ea883af44302a3811e004a209b747187a3",
        "0xf9556c7d4d83d3ebfe82f1745be632d9c6e1a0b29e03e0617fe0dc59e11769dc",
        "0x534e1b547422fa175e7ebc70864c364f75b3ea3a2271f04f166a1f22e06e1283",
        "0x826f4fecd4f371777484dd16bae1a74dc264713dce0ba3ba0e4cfda6edbecd55",
        "0x1c775d9a04556e1d642f0c271f4e5b1180298c2aa82fd17be57c698a4d40bac0",
        "0x4c20aa0717ced31cb3c8001460e7d0cba5b2b4a27438d91bf0906684d1f895b3",
        "0x7f00b638d6054f952f0fcc01f4ae8f76048211abd43aaf991a73cac0a9c5bbbc",
        "0x35368cfc143d326badac27999602331b525917ba8e12b0b29d9c7f61b1870ee1",
        "0xeaeed71d4e12428f70ab84d7973ed07f53e5e528457a9abb5d56d8d3d909280c",
        "0x54b3da2799eb4477dca5864fef2a856fb0e8412833b43d804fbe8e5e1adb19ff",
        "0xca701441f2744ed559099575e34098f4d1cd9f80f99981ffb195ee6b332421ac",
        "0x3a6ccf6627b82735e451aead65cbe6dabe89558029af72d2ecf129117b3c7a07",
        "0x84cfd09b6161ed77f78c5f46e84f1bbb25f6a210957022d375ea89d2dedbc920",
        "0x7fd9d672bcc7b4b2f947c2428afd9a99790a0fddb784d46271adc8c34989c226",
        "0x4b0dd3b6e0309bfddda905d86642c8674fe0388d4626e374f3ee55dc0640033c",
        "0x3afe54197b4af27970a07309e271d7c4fcd632c19e23c082aefa459d1dc1f35c",
        "0xf1b4766e3fdaf6009f28baa63832e3c30f80a4eb89eb99311e0d75edb8adc456",
        "0x0428aa7b2460c7a78026a39a1b93039cba611e352d9e504f69a514f390d6617b",
        "0x6493c120399033f175f490ae90e73c1765b9f0cbde0d464b77f734743c02bf49",
        "0xc9412dbf5ca92074a444cf0944e6bed4bdbb2a28fd5deefb50a58dc9978709b2",
        "0xbc5a396e7aa02d60495e466302ed72a6aabc0fb6596b91db6bc15c09c821c64d",
        "0x39dfea94013cf6467f32efe634d0591a79f3041b0ebf6d7050fbf9479d14a749",
        "0x832e21741a0506fdd3886ae88db6f8844dfd36e39f71692a0b62f3eef87db916",
        "0x7a1540b08bba11ec6fa0c2bb8003e36f725e0013b400802a450561aa741c24ca",
        "0x632fb1816c2e4186576acc7024c53e92b5b2cbf8c4fe81239c51f2f383a321d3",
        "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733",
        "0x5af4b5e44dac5c501dabc92b083531bea1bf297bdd183a95761765f490f3f324",
        "0x0d2d8ee2682bdfadc4d5bcbfafa26ac6fd40f9fc426ef27c63704442c1b6ffc8",
        "0x0e2b6a7c669de076229527391c633a6c7eb796eb2a0613306f1c87f38567ae03",
        "0xebfdef4991ed5512ffa1513a7298fdf277028a25680a06b38c43a2a6779ea939",
        "0x7078dcf93a4e5b49590b5b3593fa101adb6e8db1d40e2e9e062bfe21da6663a5"
      ],
      transactionsRoot: "0x20ebc2b3280a68e40454a2877f840e951e4299c3e8d6971ceb86218bd4764022",
      uncles: [],
      withdrawals: [],
      withdrawalsRoot: "0x56e81f171bcc55a6ff8345e692c0f86e5b48e01b996cadc001622fb5e363b421"
    }
  },
  {
    method: "eth_getTransactionByHash",
    params: [
      "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b"
    ],
    result: {
      type: "0x2",
      chainId: "0x38",
      nonce: "0x1287",
      gas: "0x222e0",
      maxFeePerGas: "0x2faf080",
      maxPriorityFeePerGas: "0x2faf080",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      value: "0x0",
      accessList: [],
      input: "0x6a14d71500000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa000000000000000000000000b217266c3a98c8b2709ee26836c98cf12f6ccec10000000000000000000000000000000000000000000000000000000000000000",
      r: "0xf4ea7946d22c6fe8886cb6e4dc24fbd36d56d8620bef62f582091c245005a84e",
      s: "0x1857ec842de54b98aa80d2489b05fe8cc7aec4413166b4bb4d8884be7e82430",
      yParity: "0x1",
      v: "0x1",
      hash: "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
      blockHash: "0x01d61db291f2a96de861f0456be9ebe65d7e1024813935ee80dc371e5930b9ec",
      blockNumber: "0x80f28b4",
      transactionIndex: "0x4a",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      gasPrice: "0x2faf080",
      blockTimestamp: "0x6b03c823"
    }
  },
  {
    method: "eth_getTransactionReceipt",
    params: [
      "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b"
    ],
    result: {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xdd31b4",
      logs: [
        {
          address: "0x1a44076050125825900e736c501f859c50fe728c",
          topics: [
            "0xcd6f92f5ac6185a5acfa02c92090746cec64d777269cbcd0ed031e396657a1c2"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa000000000000000000000000b217266c3a98c8b2709ee26836c98cf12f6ccec1",
          blockHash: "0x01d61db291f2a96de861f0456be9ebe65d7e1024813935ee80dc371e5930b9ec",
          blockNumber: "0x80f28b4",
          blockTimestamp: "0x6b03c823",
          transactionHash: "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
          transactionIndex: "0x4a",
          logIndex: "0x397",
          removed: false
        },
        {
          address: "0x1a44076050125825900e736c501f859c50fe728c",
          topics: [
            "0x4e0a5bbfa0c11a64effb1ada324b5437a17272e1aed9320398715ef71bb20928"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
          blockHash: "0x01d61db291f2a96de861f0456be9ebe65d7e1024813935ee80dc371e5930b9ec",
          blockNumber: "0x80f28b4",
          blockTimestamp: "0x6b03c823",
          transactionHash: "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
          transactionIndex: "0x4a",
          logIndex: "0x398",
          removed: false
        }
      ],
      logsBloom: "0x00000000000000000000020800000000000000000000000000000000001000020400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000010000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000",
      transactionHash: "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
      transactionIndex: "0x4a",
      blockHash: "0x01d61db291f2a96de861f0456be9ebe65d7e1024813935ee80dc371e5930b9ec",
      blockNumber: "0x80f28b4",
      gasUsed: "0xfb95",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      contractAddress: null
    }
  },
  {
    method: "eth_getBlockByNumber",
    params: [
      "0x80f28b4",
      false
    ],
    result: {
      baseFeePerGas: "0x0",
      blobGasUsed: "0x0",
      difficulty: "0x2",
      excessBlobGas: "0x0",
      extraData: "0xda8301080288346437376537393888676f312e32372e32836c696e0023d35e07f8b5831fffffb860a970d41ecde677c867cd81240daba8c982d3b67b02b6a305ea84f8315bfbad8a2883ee5a4dbd243ba9d9d2bf8705ff1d16ab9ec5ef8c7be7fd95f5b37a7662343a4b2227b7bd1b2e5d01ccd012a15373380588e5fd1e62c02eaf9ec61e66a955f84c84080f28b2a009940c40929f22421cb52dcbb0fb369ddc5a1a583216652a3b61778eaa1c491284080f28b3a0b22b2bd6462b13e468280f0d94292889e6ad7f6777d5d2b74356a40d17626e7e802682074318517aaae7bbeb5510ed95b2880287e724a9a4c8e24e0fb1396d3ab2513dbe50e5f4fdabe64b7d3a3afa61aff80d96da00b6da865b1d9ec2b84f93f400",
      gasLimit: "0x4bebec1",
      gasUsed: "0xf3d047",
      hash: "0x01d61db291f2a96de861f0456be9ebe65d7e1024813935ee80dc371e5930b9ec",
      logsBloom: "0x767fdfbdfde2ffbf7b7adadf9cfffed2f7ffafbeefdccffffbc1afbfbff79cffdfbfffffd2d7fddbdf7ff5d7bbfb3efcefcfef6ffffdfdffbfe57bf39ffff7aef7ffff576ff7a7ffbf9ee7ffddfbfbfeff7dbff5faffedeff3f7ff9ffeff7beffdbceef7ffef3fffffeffef17ffbdaffdedff79f7bb6effddfdcf7feffb3c5be7eff6f7ffbfb99fffbbf6fffedeffdfffffffeffefdffbfee7feb9febdf9a3bbdeeffebdff7ffe7ffffffff7fbffbfdffffed7bffaffd7e3edfeffd9ff57fe3efbeffbef7f3ffdfdef5ddf4de9ffdfbaf7fffefbfedfffdd7bfddebfedd7efd7fd7f7fbf6bcbe6faffdfffefff6fdfffed37ffcf7fffeffde3feffcfdbfd9b32",
      milliTimestamp: "0x1a206c5cba6",
      miner: "0x8a239732871adc8829ea2f47e94087c5fbad47b6",
      mixHash: "0x00000000000000000000000000000000000000000000000000000000000002ee",
      nonce: "0x0000000000000000",
      number: "0x80f28b4",
      parentBeaconBlockRoot: "0x0000000000000000000000000000000000000000000000000000000000000000",
      parentHash: "0xb22b2bd6462b13e468280f0d94292889e6ad7f6777d5d2b74356a40d17626e7e",
      receiptsRoot: "0xb1cbe52cbba442ac7026d43e39821ab77ed3d5fd6e11cb1cc08cc053253a0c8d",
      requestsHash: "0x00000000000000000000000248a5ed9abc1a8fbe86cec4900483f43a7f2dbb48",
      sha3Uncles: "0x1dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347",
      size: "0x17426",
      stateRoot: "0x515252c411a79636b6daa81e33a3d3c3493d183105a597f2ed66f5fc213ca19d",
      timestamp: "0x6b03c823",
      totalDifficulty: "0x10156060",
      transactions: [
        "0x799ceb65c4fd82bf42d8dbfd416d119a147e0c5300750c32f328f3c1fa05635b",
        "0x275ddf4b04557dc94d2438b4749f8e98ccfb07d03e028066a8c49848af89a6a3",
        "0xe497bf6ca57fd18097bf3b1c7988e08ee26e13891def386c590e24bb871b0339",
        "0xf1a7da866c8b2e016e788ac499137dc91b378c07714e55d16b636c86e8c5b5d6",
        "0xbcb5d2e9b390bd8e0c2e15d052ffb37c7eed107b4728f8de4ba393b0a057f770",
        "0xd33947c0bac419f875bdd9edabb45dea43c26bff8f7f200aad2925a8f6544073",
        "0x083a6167fba7a053df37431a48bdb4549a7e9796a7160bdfc072c43ddd219013",
        "0x57826713346cbfd5423454c54950c5b267be6b8172de0ce2d3a8268304a7434b",
        "0xbc83acba853a839c705f21dd5319ea81b145c7644ba278e594165dbe2b80f0bb",
        "0x7678a8ddaf1d549305dc3edda0607f82700086ee1abcd210deab3edbfeb3c34b",
        "0x2b17af36cafe5700b2bfb810404aecb7957a6473a957527569e968e5be569b2b",
        "0x579f668a7e5474de3b43c7d7710a44efbceeb329dfcb8d60d9e84dddc9ef0b61",
        "0x92e6bb925815248eebe6f5e7d93b1000a069fd483597af364ec1e757bd86a38a",
        "0xc6a0145a697f6da6a876a8a6a05e3b5bba013ae66a1f025fc4bfc9a823db6c75",
        "0x24ee22f024dac017d1f2c6b4249a3b589b9e81865409d13a1c8634e3316439ca",
        "0x78464ed0b9c808194ec33761058738423d10e38b91557c7eba6d8a9c6b1ce532",
        "0x3602f5e4e0e1bba23f8017f6b5882ea9e08e14e7a471e42ba75dee1462b64131",
        "0x17126a43b2a8c7ada5c0d9bd4d90130c4c4a9fc0c0a4b20ecf4a3ffbaffab415",
        "0x25a1ad4bfd6a6435acbd44d11f90d6fe55717dd0820a57f59ae652b3e4f9ca17",
        "0xfe2c6fced4dc53209c9eb3eebcb4c6946375607610dda052c46d696b7d866d64",
        "0xca48b96ae051b9173a999a8d3a081cdef7a74604902ac69d25c1adc462a36bff",
        "0x78e34166555170f5d254b94532648593679d115766aad6dae7141b0c49f5fd22",
        "0xbf221afddc5e058bb0b151cf49cffd5fc6b8a73500bee69c5c3042817c90990e",
        "0x66dc34a75cea167291b2705053613a762a40dc7e362b19c9ff0997aa8f7f7335",
        "0xc5c06453b639b3effdfdb6e56d4ee3b1f246375fe8a80ba9874dcaa38e65b5dc",
        "0x87473b64a2ca6b2b5cb2b814fdaeb0f5f87edc7dd6bd879ebabc8cafdc481b5a",
        "0x8fba08f2266868e077081a780b3d7d89df3093ccce964c33cb8a497975f73cb0",
        "0x7e3636352a821753ccfda3bb0b36482b607355b9a2f259b8811a8088916df270",
        "0xac115c0c96b4cfa9139026de4042bb9adfa142756cb288a40032a3c8d786559e",
        "0x0378ad12c263e4ab425f44a096fbedded6a52422980830337a321898b8afb4fa",
        "0x19a390f8981711acd192094c8515536fc7d61468cb024c03a8227ffea4131b1b",
        "0x3512a2655c3afdfcf4f0bf004bc6d5ff8406134bbc9ddca053e83e8725c91460",
        "0x3256214e884271be582cc5d3190e5edb1fca8149429610fcd9464cf4643d6d25",
        "0x3792b95b75fb49faf06e53ca265270b5a7c0177037f73a761deb23ee91ae8539",
        "0x489707fd6b1afe0da8913bb5620eb816504f7e6d9ed1ae554080396d4f6233d7",
        "0x369b9491cec93f528048b17e58fd3d4b0a92526df59751664d92c7f3736b2525",
        "0x18ce30c0ea731bff7960c5b39b8783ce9a0773a308011fe9826ebe76daad760e",
        "0xe772dd3629f712e70160ea7564478393223a43c6b34c3224ad4f0ff3cdfa2be8",
        "0xe8cf7168c956ce282782ff6bb48c7429fa399a5e3895baed43bfbe75f088029e",
        "0x8a39f5a2e161ad8082401430203255a5711fc6fa7ba167670c82360076b3e587",
        "0x12c77bdb5690cc355b07ea8a59af9e6b5403bad06ffdfd35c50d8fe0834213fd",
        "0x02b5f2e24c9a920eebb61394559d829fd03627a155a033f2b6d57e118b03ea67",
        "0xbf841218cf466f566a45aa88ea69ccb6af030c3b5589d1ee2c1e416ec1f485d0",
        "0x35b42534b98ce6962cf2758bece234b0727db8993c0c3e9de294936d4b038fbc",
        "0x7881275cc7b9604a2d8dbfc86a0b301760b7e1d2bad123bdfd52edef4fa8ff76",
        "0xc5dccb449b1bd81788121b75299faccc9a4af0be6a5eeb18ac82990f93c0a78c",
        "0x77bb3df453031b55fb089ad3b56198849ea9cf5321cccfe0bc161bef537791f3",
        "0x1db58610b3f527daa8b9fb3ce9e680e5b50259213495c4fca5aabb8eb42b3fa9",
        "0x4d81bbceb62d289e1bf8700403a6d85a0d3d637b6020115d29f0750559f7a614",
        "0xae46fe670fa2c95fa7d5da6d940ca88e43378a4cb95d32309ad2ce970faee180",
        "0x546a8ca2f6bc0910314b51a10c638fa5a4dd884261318d7d09f4332d647cd203",
        "0x912085af5654d30f9d8a041b631236cb17c380e77b229d99b13739d2ac33e615",
        "0x524e5a389ab69260f4a0356f30e9c8f2b86acadfce642794c1260d26d712d7a3",
        "0xb5e0eedfef21b6bd17b3189de6f60f5958755c8b025d0379b8d7068e80a1147c",
        "0xe369ee758a26dda992157efc93509e678b991cefbfa1fb95a13ae420697adb58",
        "0xd75427432caa4e5fc9666588d9da666accd1c10722f9c8b3f5c8f35d2fbdf744",
        "0x143e11f030fa690b65ad7b3b40ee8d0b2dde727a61e8594f47b0fee06cb46eee",
        "0xce60a98cba6020da2928f9c319118ca71858bf687633ed4fd047d2e5d07e8a86",
        "0x80c10eca8805142aeb2c6a367b0b6e11ac95367eba48a2d85b275afd46526bbe",
        "0x8222613ab0eb215a17490c735744ae3b73d34b80be62461ba839e48259a0481c",
        "0xa4d45316473f26528c681c63a6f376c698195bd8803730642529c7f1b5dac7bd",
        "0xa4499df670ec85805ef3f889b7c341e8603d32b0bf217cda723938138ac72b95",
        "0x1a70f01675eeb792f74418ee588c857e9d65eea1e6b9fd9c3168e4af8d472942",
        "0x809a744fcfbef8439159faa1a1349a85d58ac57e064ef151d2af2a67fcbbe378",
        "0xa8322d32ad52c02f32a4c35527205aa4d87a54d795098b0515c69512d00eb901",
        "0x42a87db45ee20d50790f8f665a6bc49b8878752c6f64bbafc6297c695bbcaac9",
        "0xa5890da4f41f88e83f42e34ff31c3bdd3c10407ca34aef191d5c1e723b13147e",
        "0xab082164dd141be0767a55ad02521f998449ebfa7279e075b852a4d7ebeefc14",
        "0x00061c0aa97c5ab701174c1fdb5ada458ba080140ad9154a370e4cc54bcbdfca",
        "0x1f83c79f69ebf4cabe2329bc4258857aea406cc97a1d54e0b77b8309563881bf",
        "0xae0fcc9acafd588df2d975ebfcd0e4af4baef7bfef6686a44545700e7908847b",
        "0xe2bdd8e047714c268bf719df7a8306c9e8159fa4cd9ec58a8e0c2a6d97b96f96",
        "0xb60c3b810ad4f501cd06fc359c8b33f88b3f5d0057fb61006135d70f312ce5a5",
        "0x67c7fac4a706bd1920e2e55146350776208db8e81aca7f6590d7040e2dc2f860",
        "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
        "0x46668474ddfc6a2391653d9f5036e31ae300a9f8e211f4bee696160ac253cfd0",
        "0x8c301c4d54a2feb68e8f4589450a356f22695b7f69cbf8990d266946d11d9695",
        "0x3b09d4addb9aa9a3753c9cdd3dd744d0a73be2a13d0fca6bc1480a290a80dc93",
        "0xa62626d784254a3a428f231d00032229d1f9c84ad1611ba18b60893d121405f4",
        "0xedcde3876a431cb8094a1775521f5306bf56b6f74a6739d933f754ef8ee585b2",
        "0x0f39c42043f1a1966fb6eb92d1d85911a76213d8e7e69e200a5ea323bcc71259",
        "0xede1ac83d337189872851946cedc83ae3bf1ecfb378c1a2513d51d1dfd8ea7c6",
        "0x068e80b631e7dea31241a19d6dba5ea3796d8f908e03ad3137a14f5f07d5a4ed",
        "0xde5882d94720b2b26c409f4722ec0c01fe90662672b2ca97831e8945fe8cfa72"
      ],
      transactionsRoot: "0x74e195f35b7dcc0543e990a44ed4aeefafa30fcb19888f6a3c3d89889e3dfa24",
      uncles: [],
      withdrawals: [],
      withdrawalsRoot: "0x56e81f171bcc55a6ff8345e692c0f86e5b48e01b996cadc001622fb5e363b421"
    }
  },
  {
    method: "eth_getTransactionByHash",
    params: [
      "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a"
    ],
    result: {
      type: "0x2",
      chainId: "0x38",
      nonce: "0x1288",
      gas: "0x61a80",
      maxFeePerGas: "0x2faf080",
      maxPriorityFeePerGas: "0x2faf080",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      value: "0x0",
      accessList: [],
      input: "0x6dbd9f9000000000000000000000000074c20deb476dca58459956b1acd65771197900c90000000000000000000000009f8c645f2d0b2159767bd6e0839de4be49e823de000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000027100000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d58485900000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000",
      r: "0xfd500f18c8134d66020fc4ff0fa3755c33de7d559ade402b2ae93d03e4c67ba8",
      s: "0x11027d9cd4684711b8324242be630d98bcee352c4bc31c90a42f77dadfec3fcc",
      yParity: "0x0",
      v: "0x0",
      hash: "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
      blockHash: "0x7adc0bd86b3ae8d76fd931a3cb0ed6de5dfdb06592f7ca58ddf5fe7bcdd1eaf1",
      blockNumber: "0x80f28fd",
      transactionIndex: "0x40",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      gasPrice: "0x2faf080",
      blockTimestamp: "0x6b03c844"
    }
  },
  {
    method: "eth_getTransactionReceipt",
    params: [
      "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a"
    ],
    result: {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xd70964",
      logs: [
        {
          address: "0x9f8c645f2d0b2159767bd6e0839de4be49e823de",
          topics: [
            "0x779cb2dd9d2bb1be1737d05435d744facbfb84a2a4912e21379d39beddcdc805"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000027100000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d584859",
          blockHash: "0x7adc0bd86b3ae8d76fd931a3cb0ed6de5dfdb06592f7ca58ddf5fe7bcdd1eaf1",
          blockNumber: "0x80f28fd",
          blockTimestamp: "0x6b03c844",
          transactionHash: "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
          transactionIndex: "0x40",
          logIndex: "0x16d",
          removed: false
        },
        {
          address: "0x9f8c645f2d0b2159767bd6e0839de4be49e823de",
          topics: [
            "0x82118522aa536ac0e96cc5c689407ae42b89d592aa133890a01f1509842f5081"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000",
          blockHash: "0x7adc0bd86b3ae8d76fd931a3cb0ed6de5dfdb06592f7ca58ddf5fe7bcdd1eaf1",
          blockNumber: "0x80f28fd",
          blockTimestamp: "0x6b03c844",
          transactionHash: "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
          transactionIndex: "0x40",
          logIndex: "0x16e",
          removed: false
        }
      ],
      logsBloom: "0x00000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000004000000000200000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000010",
      transactionHash: "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
      transactionIndex: "0x40",
      blockHash: "0x7adc0bd86b3ae8d76fd931a3cb0ed6de5dfdb06592f7ca58ddf5fe7bcdd1eaf1",
      blockNumber: "0x80f28fd",
      gasUsed: "0x2e6d7",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      contractAddress: null
    }
  },
  {
    method: "eth_getBlockByNumber",
    params: [
      "0x80f28fd",
      false
    ],
    result: {
      baseFeePerGas: "0x0",
      blobGasUsed: "0x0",
      difficulty: "0x2",
      excessBlobGas: "0x0",
      extraData: "0xdb8301080288353461666166663489676f312e32352e3134836c696e23d35e07f8b5831ffffeb860b58e2042bf8b71e0676b25543f189611afb8f4ef82fe72004431be4c3f2e545470c58d12de0eaff2bbdd7ddfc317102a00987586fd7a4482d42efc71d95e82d7f4a6786d7113d1ddc0624b3dd6d81b12da7edda41c935283702806f9f15e8d01f84c84080f28fba02f1bf5de936f3a6370a8f03891ce8155b008f85cee62d5e4ca56758fbc01f57884080f28fca0992da5c8d823f494a445ca71eaf067969686ec84a27371aeb3b9579efab11c36803933ec846ad411a29e5735cfc105e35c2108148377b237a20ef3cd950ff20a9646cf38ba8d9f6a5dd8d3acbd3e50e488368b11ba5746e85bc019d119fea27c1700",
      gasLimit: "0x4c2502b",
      gasUsed: "0xf2f653",
      hash: "0x7adc0bd86b3ae8d76fd931a3cb0ed6de5dfdb06592f7ca58ddf5fe7bcdd1eaf1",
      logsBloom: "0x46ef570824543f540c2614eda280d74512ae27241aec664888b4f4244919389787021810f14e44dadb3ecdbca1ba0640cacf407a2b03a11c24d5e84b0e3ef2de4533a2765743b96989b114f9f28c13622434c9ac7c754c4001750a1bd4e934cdfcf83260024ae0a3db29aa01dd434a75ba5fca95a815e9b3df40367a31d99ba2e8e8b42f1419191c4bb91c7ff96dfd8feda44d016a6f411e48d2c9460f9215ff02969d1793446434887225d34394a4f4f09684c28bc84ac0a5a4756509716c56d2407dfb363f092a15ea2c26b79341c1ef2f16c1b098279ff0d04a0a1dade2c5ea5e6cc17c36dc94318bc79ef9a9877dcc028b0193b15c4b45172f284335c51a",
      milliTimestamp: "0x1a206c64bf8",
      miner: "0xf8de5e61322302b2c6e0a525cc842f10332811bf",
      mixHash: "0x0000000000000000000000000000000000000000000000000000000000000258",
      nonce: "0x0000000000000000",
      number: "0x80f28fd",
      parentBeaconBlockRoot: "0x0000000000000000000000000000000000000000000000000000000000000000",
      parentHash: "0x992da5c8d823f494a445ca71eaf067969686ec84a27371aeb3b9579efab11c36",
      receiptsRoot: "0x78cbf20612505c8ac45d60964932cbbed4bb3902798d047ae59d79eb2230c018",
      requestsHash: "0x00000000000000000000000248a5ed9abc1a8fbe86cec4900483f43a7f2dbb48",
      sha3Uncles: "0x1dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347",
      size: "0xd50d",
      stateRoot: "0x6562387aa21cbc070c2ffef712fc9bfa09ff4b55f5015d990dffd0da65081bd3",
      timestamp: "0x6b03c844",
      totalDifficulty: "0x101560f2",
      transactions: [
        "0x1f6da71b8c9243f283f6270682fcda8541018aae33522a21387b488bb33138fd",
        "0xb7c9330430665c93a3e78c6913f2fafc677a6550c18e7395d446408b6edc0056",
        "0x9bdfa0c58c7d9006b78f12512acddf872cbacf7ba0054f081f613c8e062eaa0a",
        "0xe1efb7179ec55f09799d29b7da35ab8e1fc764e8584edb99cfcb1815b2dad88e",
        "0xabef94cba972a60426ddb5695779f67da959a53d66eedaee60eaec30e3880bdb",
        "0x8856da81996855bb4ed6eb0e6bd1d68a1c18901056fafeb022c8320d94ed7ce4",
        "0xff29aaa0f3128ad9871eab3a4d2138b5b16a1b8b5cebe77d949e792c674d6f41",
        "0xa99a37f68619875359a9822245b89c86ec8b8e94adb2950aad08de55c439a007",
        "0x5a6fd9992e4cbc0067f8cfffcb0fce06b0e0341162e31c475f1222885b7c39b9",
        "0x697e1161d6931f0f300f6e8375b1741aa25a44e6d34d2c1862966d983b41bf49",
        "0xba1b2f528407796ce65b4dae24870346f3225bccac07d26e87b8a16d74d93613",
        "0x38ed620b2a9dd716e821665d77f385ba69716daf13626736472dc0235d8dfe2f",
        "0xb3b25de3a1600574963ed43d4e1da66774dc52a41b3b6c1c42301ab15c65d828",
        "0xd7b423d78a5479f02110db6c8d41d639d3048f5f3f2811de6aaedca0d7513d13",
        "0x1205747bedde31c6f930e33c0ee5d62b645253067c8480108d29a3cc07d4538e",
        "0x2322c7d9aac44fbfc5b2848e83f0f5bd89bc4dd8b1cdf4048b3de231f51704f8",
        "0xe98c38eb3831c3c624caab55b670b9d2969c5c5a225773917f8b7fdf4e6dda81",
        "0x1b5b5f1677b113805be6538409913bb25d49f0871f4caf80e1b8cdd6667028ab",
        "0xd64ecd0781011f62206535304ea797bd1e4d8cd0fc2919c087f039111494d6df",
        "0xadaeedd15701d8f61bd46c327d067d3561d43920ac322c1794f2d3be462262d9",
        "0xb9b63cab13b197fab1b494ff6a668216208115915c80bf4bab7e92c76de17c1f",
        "0x060521b78fbe145c78eb3071120b45bc00795a08eee2b19ca8ea75109ce15f4a",
        "0xe44d15ec8778b74144f01c41d934bf015ce6cbd559e8fcdde7b35232e32dc2d1",
        "0xef8d123cd1cb1493f1c1c51c89bdd4a14eb156ec58ca91e9882b21a83ebb70e9",
        "0xcfe4becd5e11a588bcefaed0b9ed8e7df5c2155690ff29c79e7cd688cb93602f",
        "0xd187711baaa9a9bbf28475904392ca94ebccad96901f1187fb9b9c56cd2bf641",
        "0x9d777498195a93cf5af26063731869df34a2e107b3e4e039f7d808934f15b382",
        "0xe498d181254b0a200ac0cd4ce8e7354fa3835475936ffe1c76c03db25487ac01",
        "0x0e8a45493042c02d7643cfe034b3aa4d0a1c708b10275d9b1493cecbc3d0d0cb",
        "0x65f08eb99105185d3469baad8e5d98e642f5f111c01ce3d856ef972d358aa131",
        "0xc86bd2913d2aa250825c482db2228accfbcc7b238827fc9acf2839fcf55711d8",
        "0xe01f96f0342adff3fd04ece1e17afaeec50f12c3f769d474e145df8f2ce65eb2",
        "0xca113390155a40c9ea84f467779cef4bad6d23751353990e4012aae5e9a5e66a",
        "0x149d91854cd553869e9ffc8a358819431a79257f9dba974d9721f0f061f86496",
        "0xad039dbaa6f632167627347c1ba8dcad0e39de481be2dd51b1fbabd7907957e0",
        "0x28947ea1a15b16514b0e7d52e177f9a6bcf396ab57c989445db786a966f0169e",
        "0xef7154a8ba92f6703462538e3fc9fef932c98d262768112b55071ae9f7543097",
        "0x584bba68840ff65b34b1a5479b161e11ae4984b66cbd19575c02c8e78d43ad15",
        "0x0163864d480aec48ea6875b8275471c47fb48839d76ab5fc0acbe5981c5b9dc8",
        "0x262e46bec487a92132784ad2a446ffcf97739e7033ffdb0213b7faab1b05d35d",
        "0x2334dbb7a2a22d1c1b4006acd0321509f5a2a006eebd10e005e353d00faf2b51",
        "0x48eddf0cab827cbf863ce916768726cb5e7af5737f3af728e31f91574e3f4fb3",
        "0x84753888cd5e6d40f4328ccb7f94a272c69798da28dab3b573bf5b7e304027f8",
        "0x5ba4e0e7cbcbabeb5c1c9992c9ea7a82ad80919131ff1900a8fdb13dc7f737e0",
        "0xe5cd735aa3445bc8355cacab6cf9f99112459793ef951fda515a3f9f58f337a6",
        "0x11b395b83ac83187040cf8bd9ea4de5f6fc8cfdaa8de74a20244581cd58cc5bf",
        "0xaab5a2fadf5e0604e7a2b27d4b37860412b0b825b0b915286c9cacc819522ebf",
        "0xfc3684ce8a8c304a9dca38cd90146742973f77b92de32f320c28f4eb37b26a8d",
        "0x367261dd9f8749a517754981e5af9519b00d6d5a33ae4ce70cc625264760fbf8",
        "0xc747ef8127c9d8bae08753e99f86bed37a7e57e3814a0d732cac6fda2fd6e4bb",
        "0x1e4f135031457d01a867bfbcfb61a10ca7625087dcbbc6545fb92550a4ba1686",
        "0x7647b11126790bd11986b7bac1b6be6aa28783a8de9f85ed987bbc11c6f35f3e",
        "0x8d43aa9fd315be241a86687012523aa99208d760948c75dec86f0ae8cd742e28",
        "0xd725125f9f2391a0aa3a95a2105568bcdcef4d8c1e73c499979703746587617a",
        "0x244f3b038b313e167e241e5a3ceefcfdfcd6af8431e120c8be4e7c9492e40c32",
        "0x601837b830cc961bef28dd88c698a1c02a5e9b4af304ed218ed1d994b0fa5324",
        "0xfc3184ca5c93f4b34696c55aa680725799d1709525a80b23a6fc8a478d2b5181",
        "0xbbf011ce5e49898e4adf447e050dc451fb3c9998103332420197726e1e3f72d3",
        "0xd7273a0b6e34b179ab2c308388de4fe72fdfcb07683a9e0eaadcb4f6359bbb2f",
        "0x6715ec30abfee3e0d4bd17f00b154ad47adc578665afdd3fd06815a2cee099de",
        "0x7044904c8f6b90c0adf7c23882e74111b1995d1cc05eeb2cf2e2b36f931ff9b7",
        "0xbaf8e662ea6954307065af285b379b9d26427be76830f770e86b7864d18f9b9e",
        "0x2a3088fedfd724cae4ba90579cfd6bf874d48ac6f2d856575b8c5f195de5c547",
        "0x5ce3d9e501e54353dd14053ddc47113ea42f42a57ca449abce50895ed9fdb1af",
        "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
        "0xb416fd3622ea456b36cf67fafce12879b4325fd8dd185ad457e1339d664d3077",
        "0xf4041a6232034a6b67e557233a970c79b6dfb38a8b0e43b1c7282272f8df0266",
        "0x095a162ae5bcd95eaf45412afa80d27166fa8392dbcae86cdb0cbc79606a3c53",
        "0x5a3694753065cccc7286dd2c92657b0a2259b7f8b19b76daa4817108a03c6876",
        "0x8da6ddb251de9bf61e368bd6edb8f40f7f2cd95c6a87bc54d265cc1fac1152e5",
        "0x74e56ba24500c9edd594e438b3e0a04ca74a82bb9078a0a10958f7b3ad8409b1",
        "0xf5ae06e99465d6a69f1eaad14a88d5eabf2d2e4369471a4a3b14542eb4c3faf1",
        "0xd455ba62d189a8a543e1daf31d9a691ea95be61a26e3fe8030db32ca3b1d9d69",
        "0x15f5864c6cd58d4802341dea420e0648e48cee58f778dba17effaece0f654811",
        "0xc004fadaf21f6c5bd49f8ae1251b82cdca7854fb08bb5c8fa1e026ce7e661ab0",
        "0x98458c4dea0cb3924cb0bafb344e15d3a49eee5433f94df8644b2661e0fbe5dc",
        "0x4e9cfc85967630d6ecefcafc7a65bdf70ce2a86bca9ce3799131c8f0e6545ebe",
        "0x5d7900e7d1b4455441089e7121ae971c7eca9cbdd96fd762b7a28ed00222453d",
        "0x5a62ab183ebaa86ce13973a3b42abf090b41394e1017c25fbbf2d9a6599c6a57"
      ],
      transactionsRoot: "0xd3056ef6e127a03c915192d68b6ce6620bcbc84068d8376e43b52c92dee3a06e",
      uncles: [],
      withdrawals: [],
      withdrawalsRoot: "0x56e81f171bcc55a6ff8345e692c0f86e5b48e01b996cadc001622fb5e363b421"
    }
  },
  {
    method: "eth_getTransactionByHash",
    params: [
      "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b"
    ],
    result: {
      type: "0x2",
      chainId: "0x38",
      nonce: "0x1289",
      gas: "0x55730",
      maxFeePerGas: "0x2faf080",
      maxPriorityFeePerGas: "0x2faf080",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      value: "0x0",
      accessList: [],
      input: "0x6dbd9f9000000000000000000000000074c20deb476dca58459956b1acd65771197900c9000000000000000000000000b217266c3a98c8b2709ee26836c98cf12f6ccec100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000",
      r: "0x9bd0e5b09898171e931ea98a7cbb5da379e766ad9f571f49fda466f6f90a5fc",
      s: "0x7b3062d90c45a7cd0966b02092253b15b735049ebeb76727d806ff8a8e9f9bb5",
      yParity: "0x1",
      v: "0x1",
      hash: "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b",
      blockHash: "0xefdbd3dae7b5381ca1f0d85cad46718451319872283f5683c44930be1a67de4d",
      blockNumber: "0x80f293f",
      transactionIndex: "0x40",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      gasPrice: "0x2faf080",
      blockTimestamp: "0x6b03c862"
    }
  },
  {
    method: "eth_getTransactionReceipt",
    params: [
      "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b"
    ],
    result: {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xd33a33",
      logs: [
        {
          address: "0xb217266c3a98c8b2709ee26836c98cf12f6ccec1",
          topics: [
            "0x82118522aa536ac0e96cc5c689407ae42b89d592aa133890a01f1509842f5081"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000",
          blockHash: "0xefdbd3dae7b5381ca1f0d85cad46718451319872283f5683c44930be1a67de4d",
          blockNumber: "0x80f293f",
          blockTimestamp: "0x6b03c862",
          transactionHash: "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b",
          transactionIndex: "0x40",
          logIndex: "0x1f4",
          removed: false
        }
      ],
      logsBloom: "0x00002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000000000000010",
      transactionHash: "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b",
      transactionIndex: "0x40",
      blockHash: "0xefdbd3dae7b5381ca1f0d85cad46718451319872283f5683c44930be1a67de4d",
      blockNumber: "0x80f293f",
      gasUsed: "0x279bd",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      contractAddress: null
    }
  },
  {
    method: "eth_getBlockByNumber",
    params: [
      "0x80f293f",
      false
    ],
    result: {
      baseFeePerGas: "0x0",
      blobGasUsed: "0x0",
      difficulty: "0x2",
      excessBlobGas: "0x0",
      extraData: "0xdb8301080288353461666166663489676f312e32352e3134836c696e23d35e07f8b5831fffffb86084fc346e221a7f5fc1836c5d42a949813d2d870a19ccdc0e50ff4a225636e86da6d103634138b7f24d97bfe3ccc1d297144f926fab3bb5276b030bc6d946a686c85151c85c6b2ff30d88cc3fd2954b09136f351bbef1fec83acd67a300c50db2f84c84080f293da0d628538b1c22c1dae52ed9510e887cd5161db14f25c075cdc43244944203ee0d84080f293ea0f49885636bc6298c26cfe61eed5ca24bee93f1fc4ff094041ef48020d922664d80c37fdd3165b348fe5d06d3adce6349000baa90769c5923ba5f306f6113d21e8104996e2b6a51afe3e5236f12e0f74ad66e5c126f59e5a32b3e5f458e5d2dd0cb01",
      gasLimit: "0x4c4b400",
      gasUsed: "0x157c9d8",
      hash: "0xefdbd3dae7b5381ca1f0d85cad46718451319872283f5683c44930be1a67de4d",
      logsBloom: "0x7ffebbacbde63eeefda2fdc593d2b75536fd11fb9efeea5489c7ba8f4ac67fafb75593d6153945df6b3fcfb57c2387cc8bcffa713541a376a2a61adbd7773bffcd96eb7fffe787bbbb5deeb9e72f9db2aff7cba65dc7a36f81f5dfbeae631fe9d1fce6f61bbbaac7fead5dc9962defdf9e09c157f83cbcd19f30be7ef7dbae2677d1c109e57dc9d0cfbda475ffec3fbf65adff171a3f9f4c5654c9c8dfa68ca72af7974ea71f60feffb3e7f26b1bfdb2867f98fe5389c2e6b3fafce7bdd4b463fe3e6fd3be698d7cb7f37765fadae3f037f6cab58d7de5dd7e70ebcb1dcfeab5cf32f6ff1c6f79ed6fee7bceb9c643e731f0ef9596dc5fd9737eba6a6ef96f3b",
      milliTimestamp: "0x1a206c6bffc",
      miner: "0x502aecfe253e6aa0e8d2a06e12438ffed0fe16a0",
      mixHash: "0x000000000000000000000000000000000000000000000000000000000000012c",
      nonce: "0x0000000000000000",
      number: "0x80f293f",
      parentBeaconBlockRoot: "0x0000000000000000000000000000000000000000000000000000000000000000",
      parentHash: "0xf49885636bc6298c26cfe61eed5ca24bee93f1fc4ff094041ef48020d922664d",
      receiptsRoot: "0x3175d795ceb112b7fa71e23e25e95d2e0eabd5756a6641b1dd89eb35bc0fe704",
      requestsHash: "0x00000000000000000000000248a5ed9abc1a8fbe86cec4900483f43a7f2dbb48",
      sha3Uncles: "0x1dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347",
      size: "0x1326a",
      stateRoot: "0x5d75a868397f59bfa176ca1e54dc030ae930f9d3d8cbe73fb56c5c70230f5e10",
      timestamp: "0x6b03c862",
      totalDifficulty: "0x10156176",
      transactions: [
        "0x5b0e90292b5923700445f59336071ddf8c390fd258c3ba3c992cafe8bd9ced28",
        "0x2d173377a5a0aba19eee160d506af395d484476cb319e4541777ca7d78513636",
        "0x767dfb9ed51c81bc335504da0962903f3992d3439730ffa6d2d8a8f7a7c3b647",
        "0xeff35fd16f325e7e1d84430a504e00c071763a2a351d83185aeef767ee617adf",
        "0x0ac23aae0a3301dcc8db3d5ed9db1acb81c584fdf7bbb9c5e1e1ce8c31805f36",
        "0x2f38ed75fa73567904b6565ae91d4da6e8d287fd32bd8b45f2fe304ed29268b0",
        "0x73a1e5ae67cf2b2b4f547f9a05d1caabfe58446336e6788a0e1f3cc7e92961e4",
        "0x77acaa4537897165795b29f9ee7c0b3eee9a963942501d0d0520b28075cf8da2",
        "0xa8456834cf24a94c867cd56ea2cca75dd7ddea9dca70f9f8532a36161573f8a4",
        "0x8ee95107e384c2e536c871ae6bc95daa0282f61065ef631c9153c551bf69bafe",
        "0xcacb6b6e041499c7a0f9ea2a0b88d065a5ae93683df91a33eaca77ebb31970f1",
        "0x308e6370a9907e0d02a650bf1d68aa89eb44fbac7510b62eb4c59c3bad0b6b85",
        "0x47a111397fc938eae4efd47a567e0766b6f9611ad4b9a60799a5afbf805cd688",
        "0xc66c8f970a6e4cd6ebcc5328a8e1c097cfdd1dac9f486acce36fd4272352b053",
        "0x3f2ba236ba0e8b029a613a7cc72d00dc3d2100c4d1bc4ae556c192cc4c5b3217",
        "0x7cbdbda1d53218afa43465ed0ec7bc9afc8f513ce56cf0051cbba266b1eaf011",
        "0x749055c23ca5bed22faa8a1c5cea86f5279bebe9969eebb1579ddf72773ea481",
        "0x1e7b419dc699555338b04fb4ba268ac2555ea92470c2ecaeffed9a9e8ea80426",
        "0x9e8e3a5b0bb01d7c5973b7b3cc9df25dbcdaaad2dd204423a272628f60be2fa5",
        "0x78a49b110c9dc9cd991af856097c8a75d2b492e79f906b3064601317e54d73d2",
        "0x3cb3dcab90c09b8a3e0bf39530144b6d2e415586ba18b019190246c8921ba906",
        "0xfc2a928c421c2ddda883853177068d7516901afa684939e87bd0212b662ae94d",
        "0x6026356499b1a558ae63d352ae6054c2f9bba8c35304267da044f88e9efa0d1f",
        "0xe098a0ca19fb24506107132b3868ae6168f8bf29abab5f01f6e0ba4b7f0409b4",
        "0xdce1f32fd0cc9b10076849a8e142c68808ae4facefae7a4d0207010b129b635b",
        "0x8d0e46d33590edd33b6ce6c4e7672a914b7395ae08bf356aa72ce753d18b1dc6",
        "0x6541fea8c73c439ed3eb1473f77fa9fb83bfd1721e449350ce98c5c272f60cef",
        "0x29ee0f0d3528fb293cb4d55938d4575f6620acb9b7827f8c6ccd32d9ffff201b",
        "0xcb9bceda6750e167bfa5a20643c17ea3ad31729c4cb92f4cd67ca653947d0f34",
        "0xd70e1bb62f0544f69ec219897a426c83bf9ad67d2eaae96d8172a721f0d6efbc",
        "0x5361ddb5065333fb3e2371c4dac9671bccc91f344777603fced920e2065a4327",
        "0x6a622ff81ef7d3c547e495728cb2de933745cebf66ce3d2543ea3ad13afaa623",
        "0x385d463f8ee031541685aa9b8efbcff762def49cad664f27a4440e7eeab9e4c9",
        "0xb5a310253fb86f3a7f70240d1eb36d3f4b4331b7148d4757c47e0ba77dc6ed41",
        "0x4711990e4c0c8573c2bde30ada51caa577aa038fb62e90ee3060a3a0fbee8692",
        "0x0f3c4cd47d8e7d94ac5776258a17e3f09d12bc90e6cab46a784628c2423e32a7",
        "0xf692769180970f507c89d54b121ed2a77970ef3928d14aa182df9911c23ab860",
        "0x9bd26ca28d27db62eac67a040fe84677c0ca9aa484fcdc755e078d2cb5f545fd",
        "0xcd6bb58363f8e8499940be5709a1911f6c68eb19410e46c0a68e1e88d3c8e398",
        "0x57d75bbd7fb429a59bb20299679bd026606e7c9927b4df34b9a5cd8b07265f68",
        "0x3611b75aea0461b7bb12b7f2d2b40f342bf7746e52548c192ac1466464d73db1",
        "0x1ab1e9f1ce486495d7830bb3afe6c4799565894c2eea7a02dcae2edb4e412319",
        "0xc106aa562335522340522d8444d3d9aa9b7cd3df6d5d80c835328949d2846046",
        "0x056ebcc53de62e5e207511fd114618b59493b36468005eacc22ff0100d7dd0c7",
        "0xa3416769b090e065be92daa1cc2cc0f04f4664ccb9ef0648443042c61be39db8",
        "0x50e03a603f4c6b6e43d66c0fca289d7656ab6b8c1c9b8640127a6fde74317477",
        "0x6673fee2e35e2fc9050532bc8f6a3b7a14aa54cff2ea9d32db67f2552c4e135f",
        "0xda399c1ccf65ecc56636501db15f7bd548222937fa7a2afedaa4b99e03771c5b",
        "0x0b969c0688b9f68bb1d29daab687acfe119ca59d33dc0da4d91227fb16e85fc0",
        "0xe2eda5ae6f677feaaf928d34d3ee51e05ad303a123c7b3ef468d9f6d91f65395",
        "0xeff4a14b000821315fa629074313f11da340bf5140d06ce6a8939de20e0c120d",
        "0xc0abda982f52cc4f57ba4b9ebe43b86bc1f0f49516803de8a953d11e047dad9c",
        "0xa65ad51a8126aa29cb4f11162215016db3dea633f9cafbf8c76820babac7492d",
        "0x6d1b30f6923413c0c86675ab5eff54dd3461ccc82d32cd04d2f3c2c761251bce",
        "0x3460cb7168f42f5b59d23cc7419d01df72d6535275c1d84a64c3f1df02abfd3f",
        "0x00b3591e0be39460d390925fa08b26a2db21eba09931f5ebc74c829064fc48e4",
        "0xc2bcd74844856f90067e612b0474e54931e783caf444abcc5a346ddaae57977e",
        "0x5963b92728d34e595bf5696304f8dd5b47f7ef50ebce799ee9b47ab5f2083fbf",
        "0x2932999402b19ce13af7df610fd631663dbfdee70ce6e505eeee35672f6a6521",
        "0x2e44f84da442d073157a8bd754d3e55dc42227008b68c7e751ade43585e632c7",
        "0x0470080db02286da68896afc938e183364318e99de4eb52f8ba44e5deb67e5e1",
        "0x2ca26bbec9e996750f7d24619d50a8b80c5c2cea60690dcb8fef68c84b8ba5d3",
        "0x135905489b6ed19055c59976e7cfde5c3e0d37be2e49be50129eb3cee504cb05",
        "0x2078730ce9d01c39895b0e3aa7c5505287e18ce08a19e736cf7cb3da3dffa24d",
        "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b",
        "0x36f084266889914d9b43e2b686c83daa477c12d0d0277b625da5b52cb13e89f2",
        "0xdebada4f6ec7741fc3e8e9ed28a31bee4b27c98ad22020e780f3996788d6940c",
        "0xf5696dde4ff0b9a90845fd97b9653518e6d088d59bc2e14fb0ba6b3ffaa7815e",
        "0x62ce29487c90f05b75e0684ce9da1448572516818896f1ac69c58b30f05d4bff",
        "0x695e201cc9e8152178c7d701f2f1e90005c0546e599eb15c336a12ce7d3e6d7a",
        "0xb2f9d68bde33cafd76e96fdd714be7d678b784a1eb0f2ee1f838337502294328",
        "0x31705343f962bf260082cdf46b35be6029440ba9a9b7d83a2373326107c4100c",
        "0x28e8112c48f08a92e7831a9f6b47e8bedd64ea1034caaeccd8ef2856052caec2",
        "0x469b50388a8415685ec5223393c4560753fc9ad53e14fa4b3ccb42557a4c4eff",
        "0xf83661c30e9ac28f155fe9bb17e8138e34077f8bc39dd7f74a0908eadb26dca0",
        "0xe38a7ee6120dfb9ff6eaa9b45fbebc4779afa1beea0a9ef9b9a614df5d99329b",
        "0x11dad0c8f18a56585068512f042a8e8546844e5e3f056b734f0c105fe100b471",
        "0x567f507a668c04e25864ba3f166b19be42c4ef2569cbddce49cb57731a9a5349",
        "0x533c52c3c02b7d2d2ae8c84b86971e62f96752da2ff635adf2a99fe8aac7c586",
        "0x432cc4d8a181b7837e5d978e47f064ab4e36afa959ac9d3f40be1851756de5ec",
        "0x2bf5908c92262cbe960d55072c1ef9d34937d60312437f427dd7cd759e9adc12",
        "0x6e5a6b437582ffb46f1dff50ae23803d33dc2d0736599968e07129a7b431a19d",
        "0x0de0f0d062687d38da5fd78517f89df4b8794533721ea8588a8371aab6db4d87",
        "0xba685c29e4c7725c7597cce8bd110899bb22d637fdae1b6751ffd02727eed72e",
        "0x1534ac53d37010882bd229a88bf708556f27ef73979fd4a665df9c7bdf56fb57",
        "0x19af8dd008cfdacd0a739db5aa27a95c12c6cec179e20d371e30b246e68f48cf",
        "0x56ccc87f339c98d3ac45d5dd7b51d488aad2eaffce8133bc4b30fe0aab569ab5",
        "0x739e53f8206dec65572b8c0a9f261316b1b8e79fd92135ccb5961ad6be57e551",
        "0x433b126a5e17fc987c25d0e27bdd876117d624b21fea071e2f36c0deb30dc0ee",
        "0xeb540c2fb4be59ab88c31cc86597baf9adcc9c637e2f7f0f1f9d32ba34af1b1d",
        "0xfdeef1e2f4102104d99ff6670410938d5c2e3f0481a44fc8899422190a4086ee",
        "0x74a403a9d9d995d7423574254bf28baa469ab7da9441ddfd80a7a938ec82d723",
        "0x0b62e6a5178f030d35526b292e5f76939a8f5da37d6ee6a5c0eaecaca74230a1",
        "0x4333323038eb0d968627123ca72353a33ade9134f1079c147f913dcad5ec4698",
        "0x272f86def5d8f7697c43cbbac26d7bb583a5abfa061faaaeca25d7726d2569b5",
        "0x7d8732261cc9341282f17a6626255fa3b59a99833a7dc00c665ba45a514134e7",
        "0x54e78ca5442fdcbbc759429c5fb5715b48203f994b9406ffefab931605840a21",
        "0x7053106cebd7856eee9ed31492d43f4762e325c534ebbcd941f5585545f2612d",
        "0xbfbc39dcca07a9b575ac8788b9f8a98234d201a63c08583efc468ccad04ba3ee",
        "0x10514577f43d0893628e9690e061d4c61f91f98187bc5ef015f76ed0c410e84e",
        "0x20baaa73f2c964f78369f6cc239ff82751c78999523a37009d42c11b55afabdd",
        "0xc2afa1aee450df826b8520640542b9db662216d8d72c693f339a55d98d7ea0d3",
        "0xc21fc586f52fb369d5786252dc514153169cac8851f5c43c7421131eff2b8411",
        "0xd039bbcbe3611a5ea5a6d4f7d87a105d0b9c903d9c33ce6e1e2193417013e7e5",
        "0xaad0317c41944a5bce96ab573cb124916959173f4fe80eef3e36aeaec5336ce0"
      ],
      transactionsRoot: "0x0e9b971df726594cdcc07755d89ce5b6e9b6ef48699c839fd4c049a183811839",
      uncles: [],
      withdrawals: [],
      withdrawalsRoot: "0x56e81f171bcc55a6ff8345e692c0f86e5b48e01b996cadc001622fb5e363b421"
    }
  },
  {
    method: "eth_chainId",
    params: [],
    result: "0x38"
  },
  {
    method: "eth_blockNumber",
    params: [],
    result: "0x80f2a08"
  },
  {
    method: "eth_getCode",
    params: [
      "0x1a44076050125825900e736c501f859c50fe728c",
      "0x80f2a08"
    ],
    result: "0x6080604052600436106103605760003560e01c80639132e5c3116101c6578063c9fc7bcd116100f7578063ddc28c5811610095578063e8964e811161006f578063e8964e8114610bc0578063ef667aa114610be0578063f2fde38b14610c2b578063f64be4c714610c4b57600080fd5b8063ddc28c5814610b5f578063e1758bd814610b8c578063e4fe1d9414610ba057600080fd5b8063d4b4ec8f116100d1578063d4b4ec8f14610aa3578063d70b890214610ac3578063dc706a6214610ae3578063dc93c8a214610b1357600080fd5b8063c9fc7bcd14610a27578063ca5eb5e114610a6e578063cb5026b914610a8e57600080fd5b8063a7229fd911610164578063aafea3121161013e578063aafea312146109a7578063b96a277f146109c7578063c28e0eed146109e7578063c9a54a9914610a0757600080fd5b8063a7229fd914610947578063a825d74714610967578063aafe5e071461098757600080fd5b80639c6d7340116101a05780639c6d73401461089f5780639d7f9775146108e7578063a0dd43fc14610907578063a718531b1461092757600080fd5b80639132e5c31461084a57806391d20fa11461086c5780639535ff301461087f57600080fd5b80635b17bb70116102a05780636f50a8031161023e57806379624ca91161021857806379624ca9146107d35780637cb59012146107ec578063861e1ca51461080c5780638da5cb5b1461082c57600080fd5b80636f50a80314610754578063715018a61461078a578063733180911461079f57600080fd5b80636a14d7151161027a5780636a14d715146106955780636bf73fa3146106b55780636dbd9f90146106d55780636e83f5bb146106f557600080fd5b80635b17bb70146105e45780636750cd4c14610645578063697fe6b61461067557600080fd5b80632baf0be71161030d578063402f8468116102e7578063402f8468146104ee57806340f806831461052d578063416ecebf1461054d578063587cde1e1461059657600080fd5b80632baf0be7146104455780632e80fbf31461048757806335d330b0146104a757600080fd5b80632637a4501161033e5780632637a450146103d85780632a56c1b0146103f85780632b3197b91461041857600080fd5b80630c0c389e1461036557806314f651a91461037a578063183c834f146103b8575b600080fd5b610378610373366004614bce565b610c81565b005b34801561038657600080fd5b5061038f610d98565b6040805163ffffffff90931683526001600160a01b039091166020830152015b60405180910390f35b3480156103c457600080fd5b506103786103d3366004614c7e565b610dca565b6103eb6103e6366004614cc9565b611155565b6040516103af9190614d1c565b34801561040457600080fd5b50610378610413366004614d5f565b6112be565b34801561042457600080fd5b50610438610433366004614dcf565b61137c565b6040516103af9190614e91565b34801561045157600080fd5b506104797fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff81565b6040519081526020016103af565b34801561049357600080fd5b506103786104a2366004614ebc565b611497565b3480156104b357600080fd5b506104796104c2366004614f23565b600c60209081526000948552604080862082529385528385208152918452828420909152825290205481565b3480156104fa57600080fd5b5061050e610509366004614f65565b61166e565b604080516001600160a01b0390931683529015156020830152016103af565b34801561053957600080fd5b50610378610548366004614ebc565b611705565b34801561055957600080fd5b506105817f000000000000000000000000000000000000000000000000000000000000759681565b60405163ffffffff90911681526020016103af565b3480156105a257600080fd5b506105cc6105b1366004614f8f565b600f602052600090815260409020546001600160a01b031681565b6040516001600160a01b0390911681526020016103af565b3480156105f057600080fd5b5061062c6105ff366004614faa565b600160209081526000938452604080852082529284528284209052825290205467ffffffffffffffff1681565b60405167ffffffffffffffff90911681526020016103af565b34801561065157600080fd5b50610665610660366004614fe6565b6118b5565b60405190151581526020016103af565b34801561068157600080fd5b50610378610690366004615001565b611905565b3480156106a157600080fd5b506103786106b0366004614c7e565b61197a565b3480156106c157600080fd5b506103786106d03660046150ff565b611e7a565b3480156106e157600080fd5b506103786106f03660046151e3565b611ee4565b34801561070157600080fd5b50610735610710366004614fe6565b600b60205260009081526040902080546001909101546001600160a01b039091169082565b604080516001600160a01b0390931683526020830191909152016103af565b34801561076057600080fd5b506105cc61076f366004614fe6565b600a602052600090815260409020546001600160a01b031681565b34801561079657600080fd5b50610378611fb8565b3480156107ab57600080fd5b506105cc7f0000000000000000000000001ccbf0db9c192d969de57e25b3ff09a25bb1d86281565b3480156107df57600080fd5b50600d5460011415610665565b3480156107f857600080fd5b50610378610807366004615274565b611fcc565b34801561081857600080fd5b506106656108273660046152c6565b6120d1565b34801561083857600080fd5b506000546001600160a01b03166105cc565b34801561085657600080fd5b5061085f61213e565b6040516103af91906152f1565b61037861087a36600461533e565b6121a0565b34801561088b57600080fd5b5061037861089a3660046153e9565b612362565b3480156108ab57600080fd5b5061062c6108ba366004614faa565b600360209081526000938452604080852082529284528284209052825290205467ffffffffffffffff1681565b3480156108f357600080fd5b506106656109023660046153e9565b61265b565b34801561091357600080fd5b5061062c610922366004614faa565b612735565b34801561093357600080fd5b5061037861094236600461542c565b6127ce565b34801561095357600080fd5b50610378610962366004615458565b612bd7565b34801561097357600080fd5b50610378610982366004615476565b612bef565b34801561099357600080fd5b506104796109a2366004614faa565b612d87565b3480156109b357600080fd5b506103786109c23660046154b3565b612e96565b3480156109d357600080fd5b506105cc6109e2366004614f65565b613154565b3480156109f357600080fd5b50610378610a02366004614f8f565b6131dc565b348015610a1357600080fd5b50610665610a223660046152c6565b613251565b348015610a3357600080fd5b50610479610a423660046154cf565b600260209081526000948552604080862082529385528385208152918452828420909152825290205481565b348015610a7a57600080fd5b50610378610a89366004614f8f565b6132b7565b348015610a9a57600080fd5b50610479600081565b348015610aaf57600080fd5b50610378610abe36600461542c565b61332f565b348015610acf57600080fd5b50610378610ade3660046154cf565b613633565b348015610aef57600080fd5b50610665610afe366004614f8f565b60056020526000908152604090205460ff1681565b348015610b1f57600080fd5b50610665610b2e366004614f65565b6001600160a01b03918216600090815260066020908152604080832063ffffffff9490941683529290522054161590565b348015610b6b57600080fd5b50610b7f610b7a366004614cc9565b613756565b6040516103af9190615511565b348015610b9857600080fd5b5060006105cc565b348015610bac57600080fd5b50600e546105cc906001600160a01b031681565b348015610bcc57600080fd5b50610378610bdb366004614f8f565b613a81565b348015610bec57600080fd5b50610735610bfb366004614f65565b6008602090815260009283526040808420909152908252902080546001909101546001600160a01b039091169082565b348015610c3757600080fd5b50610378610c46366004614f8f565b613c7f565b348015610c5757600080fd5b506105cc610c66366004614fe6565b6009602052600090815260409020546001600160a01b031681565b610cd086610c9260208a018a614fe6565b60208a0135610ca760608c0160408d01615528565b898989604051602001610cbc93929190615543565b604051602081830303815290604052613d29565b506040517f13137d650000000000000000000000000000000000000000000000000000000081526001600160a01b038716906313137d65903490610d24908b908a908a908a9033908b908b906004016155e0565b6000604051808303818588803b158015610d3d57600080fd5b505af1158015610d51573d6000803e3d6000fd5b50505050507f3cd5e48f9730b129dc7550f0fcea9c767b7be37837cd10e55eb35f734f4bca048787604051610d87929190615637565b60405180910390a150505050505050565b600080610da8600d546001141590565b610db457600080610dc2565b610dc2600d5460a081901c91565b915091509091565b6001600160a01b038216600090815260056020526040902054829060ff16610e1e576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b826001600160a01b03811615610eda576000816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa158015610e6e573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190610e92919061568a565b6002811115610ea357610ea361565b565b03610eda576040517f84ead63600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b83856001600160a01b03821615610fa8576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa158015610f4e573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190610f7291906156b9565b610fa8576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610fb188613f6c565b6000610fbd898961166e565b9150508015610ff8576040517f3c075f7500000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b85600003611058576001600160a01b038916600090815260086020908152604080832063ffffffff8c168452909152812080547fffffffffffffffffffffffff0000000000000000000000000000000000000000168155600101556110ef565b438611611091576040517f05df9f2200000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03898116600090815260086020908152604080832063ffffffff8d168452909152902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000169189169190911781556001018690555b604080516001600160a01b03808c16825263ffffffff8b166020830152891691810191909152606081018790527f4e0a5bbfa0c11a64effb1ada324b5437a17272e1aed9320398715ef71bb20928906080015b60405180910390a1505050505050505050565b61115d614b15565b61116a6020840184614fe6565b336001600d54146111a7576040517fee120b0900000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b77ffffffff000000000000000000000000000000000000000060a083811b919091166001600160a01b03831617600d556111e6908601608087016156d6565b80156111fb5750600e546001600160a01b0316155b15611232576040517f5af6d2aa00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60008061123f3388613fd6565b91509150600061124c3490565b9050600061126861126360a08b0160808c016156d6565b6142ba565b905061127984604001518383614388565b600e5460408501516020015161129b916001600160a01b03169083868c6143ef565b6040840151516112ad9083858b61441c565b50506001600d555095945050505050565b6112c785613f6c565b60008383836040516020016112de93929190615543565b604080517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0818403018152919052905061133a8661131f6020880188614fe6565b602088013561133460608a0160408b01615528565b85613d29565b507f3cd5e48f9730b129dc7550f0fcea9c767b7be37837cd10e55eb35f734f4bca04858760405161136c929190615637565b60405180910390a1505050505050565b6001600160a01b038316600090815260056020526040902054606090849060ff166113d3576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040517f9c33abf700000000000000000000000000000000000000000000000000000000815263ffffffff80861660048301526001600160a01b0388811660248401529085166044830152861690639c33abf790606401600060405180830381865afa158015611447573d6000803e3d6000fd5b505050506040513d6000823e601f3d9081017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe016820160405261148d91908101906157be565b9695505050505050565b6114a085613f6c565b6001600160a01b038516600090815260026020908152604080832063ffffffff881684528252808320868452825280832067ffffffffffffffff8616845290915290205481811461152c576040517f7182306f00000000000000000000000000000000000000000000000000000000815260048101829052602481018390526044015b60405180910390fd5b6001600160a01b038616600090815260016020908152604080832063ffffffff89168452825280832087845290915290205467ffffffffffffffff90811690841611801590611579575080155b156115bc576040517fc09b635000000000000000000000000000000000000000000000000000000000815267ffffffffffffffff84166004820152602401611523565b6001600160a01b038616600081815260026020908152604080832063ffffffff8a16808552908352818420898552835281842067ffffffffffffffff8916808652908452938290207fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff905581519081529182018890528101929092526060820152608081018390527faf0450c392c4f702515a457a362328c8aa21916048ca6d0419e248b30cb552929060a00161136c565b6001600160a01b03808316600090815260076020908152604080832063ffffffff8616845290915281205490911690816116fe5763ffffffff83166000908152600a60205260409020546001600160a01b03169150816116fa576040517f78e84d0600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b5060015b9250929050565b61170e85613f6c565b6001600160a01b038516600090815260026020908152604080832063ffffffff881684528252808320868452825280832067ffffffffffffffff86168452909152902054818114611795576040517f7182306f0000000000000000000000000000000000000000000000000000000081526004810182905260248101839052604401611523565b8015806117e057506001600160a01b038616600090815260016020908152604080832063ffffffff89168452825280832087845290915290205467ffffffffffffffff908116908416115b15611823576040517fc09b635000000000000000000000000000000000000000000000000000000000815267ffffffffffffffff84166004820152602401611523565b6001600160a01b038616600081815260026020908152604080832063ffffffff8a16808552908352818420898552835281842067ffffffffffffffff89168086529084528285209490945581519081529182018890528101929092526060820152608081018390527f7f68a37a6e69a0de35024a234558f9efe4b33b58657753d21eaaa82d51c3510e9060a00161136c565b63ffffffff81166000908152600960205260408120546001600160a01b0316158015906118ff575063ffffffff82166000908152600a60205260409020546001600160a01b031615155b92915050565b336001600160a01b03168b6001600160a01b03168d6001600160a01b03167f8a0b1dce321c5c5fb42349bce46d18087c04140de520917661fb923e44a904b98d8d8d8d8d8d8d8d8d8d6040516119649a999897969594939291906157f3565b60405180910390a4505050505050505050505050565b6001600160a01b038216600090815260056020526040902054829060ff161580156119ad57506001600160a01b03811615155b156119e4576040517fa4ff2ec300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b826001600160a01b03811615611aa0576000816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa158015611a34573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190611a58919061568a565b6002811115611a6957611a6961565b565b03611aa0576040517f84ead63600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b83856001600160a01b03821615611b6e576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa158015611b14573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190611b3891906156b9565b611b6e576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b611b7788613f6c565b6001600160a01b03808916600090815260076020908152604080832063ffffffff8c16845290915290205481169087168103611bdf576040517fd0ecb66b00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03898116600081815260076020908152604080832063ffffffff8e168085529083529281902080547fffffffffffffffffffffffff000000000000000000000000000000000000000016958d1695861790558051938452908301919091528101919091527fcd6f92f5ac6185a5acfa02c92090746cec64d777269cbcd0ed031e396657a1c29060600160405180910390a18515611dcf576001600160a01b0381161580611c9a57506001600160a01b038716155b15611cd1576040517f3c075f7500000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60006040518060400160405280836001600160a01b031681526020018843611cf9919061588b565b90526001600160a01b03808c16600090815260086020908152604080832063ffffffff8f1684528252918290208451815494167fffffffffffffffffffffffff00000000000000000000000000000000000000009094169390931783558301516001909201829055519192507f4e0a5bbfa0c11a64effb1ada324b5437a17272e1aed9320398715ef71bb2092891611dc1918d918d9187916001600160a01b03948516815263ffffffff93909316602084015292166040820152606081019190915260800190565b60405180910390a150611e6f565b6001600160a01b03898116600081815260086020908152604080832063ffffffff8e1680855290835281842080547fffffffffffffffffffffffff00000000000000000000000000000000000000001681556001018490558151948552918401919091529284169282019290925260608101919091527f4e0a5bbfa0c11a64effb1ada324b5437a17272e1aed9320398715ef71bb2092890608001611142565b505050505050505050565b336001600160a01b03168a6001600160a01b03167f7edfa10fe10193301ad8a8bea7e968c7bcabcc64981f368e3aeada40ce26ae2c8d8c8c8c8c8c8c8c8c8c604051611ecf9a9998979695949392919061589e565b60405180910390a35050505050505050505050565b6001600160a01b038316600090815260056020526040902054839060ff16611f38576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b611f4185613f6c565b6040517f20efd7220000000000000000000000000000000000000000000000000000000081526001600160a01b038516906320efd72290611f8a908890879087906004016158fd565b600060405180830381600087803b158015611fa457600080fd5b505af1158015611e6f573d6000803e3d6000fd5b611fc0614446565b611fca60006144ba565b565b336000908152600c602090815260408083206001600160a01b03891684528252808320878452825280832061ffff871684529091529020541561203b576040517f1508219400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b818160405161204b929190615a4e565b60408051918290038220336000818152600c60209081528482206001600160a01b038c16835281528482208a8352815284822061ffff8a168352905292909220557f3d52ff888d033fd3dd1d8057da59e850c91d91a72c41dfa445b247dfedeb6dc1916120c2919088908890889088908890615a5e565b60405180910390a15050505050565b6001600160a01b038116600090815260016020908152604082206121379185918591859061210190850185614fe6565b63ffffffff1681526020808201929092526040908101600090812089840135825290925290205467ffffffffffffffff16614522565b9392505050565b6060600480548060200260200160405190810160405280929190818152602001828054801561219657602002820191906000526020600020905b81546001600160a01b03168152600190910190602001808311612178575b5050505050905090565b6001600160a01b038089166000908152600c60209081526040808320938b168352928152828220898352815282822061ffff8916835290528181205491516121eb9087908790615a4e565b60405180910390209050808214612238576040517f35ca595f0000000000000000000000000000000000000000000000000000000081526004810183905260248101829052604401611523565b6001600160a01b03808b166000908152600c60209081526040808320938d168084529382528083208c8452825280832061ffff8c1684529091529081902060019055517fd0a1026000000000000000000000000000000000000000000000000000000000815263d0a102609034906122c0908e908d908c908c9033908d908d90600401615aa7565b6000604051808303818588803b1580156122d957600080fd5b505af11580156122ed573d6000803e3d6000fd5b50505050507e36c98efcf9e6641dfbc9051f66f405253e8e0c2ab4a24dccda15595b7378c88a8a8a8a60405161234e94939291906001600160a01b039485168152929093166020830152604082015261ffff91909116606082015260800190565b60405180910390a150505050505050505050565b6001600160a01b038116600090815260056020526040902054819060ff1615801561239557506001600160a01b03811615155b156123cc576040517fa4ff2ec300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b816001600160a01b03811615612488576001816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa15801561241c573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190612440919061568a565b60028111156124515761245161565b565b03612488576040517f7a01ede200000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b82846001600160a01b03821615612556576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa1580156124fc573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061252091906156b9565b612556576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b61255f87613f6c565b6001600160a01b03878116600090815260066020908152604080832063ffffffff8b1684529091529020548187169116036125c6576040517fd0ecb66b00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03878116600081815260066020908152604080832063ffffffff8c168085529083529281902080547fffffffffffffffffffffffff000000000000000000000000000000000000000016958b1695861790558051938452908301919091528101919091527f4cff966ebee29a156dcb34cf72c1d06231fb1777f6bdf6e8089819232f002b1c90606001610d87565b600080600061266a868661166e565b91509150816001600160a01b0316846001600160a01b03160361269257600192505050612137565b6000816126c7576001600160a01b038716600090815260086020908152604080832063ffffffff8a16845290915290206126dd565b63ffffffff86166000908152600b602052604090205b6040805180820190915281546001600160a01b03908116808352600190930154602083015290925086161480156127175750438160200151115b156127285760019350505050612137565b5060009695505050505050565b6001600160a01b038316600090815260016020908152604080832063ffffffff86168452825280832084845290915281205467ffffffffffffffff165b6001600160a01b038516600090815260026020908152604080832063ffffffff881684528252808320868452825280832067ffffffffffffffff60018601168452909152902054156127c657600101612772565b949350505050565b6127d6614446565b6001600160a01b038216600090815260056020526040902054829060ff1661282a576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b826001600160a01b038116156128e6576000816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa15801561287a573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061289e919061568a565b60028111156128af576128af61565b565b036128e6576040517f84ead63600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b83856001600160a01b038216156129b4576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa15801561295a573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061297e91906156b9565b6129b4576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b63ffffffff87166000908152600a60205260409020546001600160a01b039081169087168103612a10576040517fd0ecb66b00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b63ffffffff88166000818152600a602090815260409182902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b038c169081179091558251938452908301527fc16891855cffb4a5ac51ac11864a3f3c96ba816cc45fe686c987ae36277de5ec910160405180910390a18515612b425763ffffffff88166000908152600b6020526040902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b038316178155612ae7874361588b565b600182018190556040805163ffffffff8c1681526001600160a01b038516602082015280820192909252517f55b28633cdb29709386f555dfc54418592ad475ce7a65a78ac5928af60ffb8f89181900360600190a150612bcd565b63ffffffff88166000818152600b6020908152604080832080547fffffffffffffffffffffffff000000000000000000000000000000000000000016815560010183905580519384526001600160a01b038516918401919091528201527f55b28633cdb29709386f555dfc54418592ad475ce7a65a78ac5928af60ffb8f89060600160405180910390a15b5050505050505050565b612bdf614446565b612bea8383836145bd565b505050565b612c0682612c006020860186614fe6565b3361265b565b612c3c576040517f4fa6ecac00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03821660009081526001602090815260408220908290612c6590870187614fe6565b63ffffffff1681526020808201929092526040908101600090812087840135825290925290205467ffffffffffffffff169050612ca3848483614522565b612cd9576040517f751cb20f00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b612ce48484836145e0565b612d1a576040517f0177e1ca00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b612d4683612d2b6020870187614fe6565b6020870135612d406060890160408a01615528565b866146a0565b7f0d87345f3d1c929caba93e1c3821b54ff3512e12b66aa3cfe54b6bcbc17e59b4848484604051612d7993929190615afb565b60405180910390a150505050565b6001600160a01b038316600090815260036020908152604080832063ffffffff8616845282528083208484529091528120548190612dd09067ffffffffffffffff166001615b23565b604080517fffffffffffffffff00000000000000000000000000000000000000000000000060c084901b166020808301919091527fffffffff000000000000000000000000000000000000000000000000000000007f000000000000000000000000000000000000000000000000000000000000759660e090811b821660288501526001600160a01b038b16602c85015289901b16604c830152605080830188905283518084039091018152607090920190925280519101209091505b95945050505050565b612e9e614446565b6001600160a01b038116600090815260056020526040902054819060ff16612ef2576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b816001600160a01b03811615612fae576001816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa158015612f42573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190612f66919061568a565b6002811115612f7757612f7761565b565b03612fae576040517f7a01ede200000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b82846001600160a01b0382161561307c576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa158015613022573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061304691906156b9565b61307c576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b63ffffffff86166000908152600960205260409020546001600160a01b038087169116036130d6576040517fd0ecb66b00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b63ffffffff861660008181526009602090815260409182902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b038a169081179091558251938452908301527f16aa0f528038ab41019e95bae5b418a50ba8532c5800e3b7ea2f517d3fa625f5910161136c565b6001600160a01b03808316600090815260066020908152604080832063ffffffff8616845290915290205416806118ff575063ffffffff81166000908152600960205260409020546001600160a01b0316806118ff576040517f6c1ccdb500000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6131e4614446565b600e80547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b0383169081179091556040519081527fd476ec5ec1ac11cec3714d41e7ea49419471aceb9bd0dff1becfc3e363a62396906020015b60405180910390a150565b6001600160a01b038116600090815260016020908152604082206121379185918591859061328190850185614fe6565b63ffffffff1681526020808201929092526040908101600090812089840135825290925290205467ffffffffffffffff166145e0565b336000818152600f602090815260409182902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b0386169081179091558251938452908301527f6ee10e9ed4d6ce9742703a498707862f4b00f1396a87195eb93267b3d79839819101613246565b6001600160a01b038216600090815260056020526040902054829060ff16613383576040517f378b1de600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b826001600160a01b0381161561343f576000816001600160a01b0316631881d94d6040518163ffffffff1660e01b8152600401602060405180830381865afa1580156133d3573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906133f7919061568a565b60028111156134085761340861565b565b0361343f576040517f84ead63600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b83856001600160a01b0382161561350d576040517f6750cd4c00000000000000000000000000000000000000000000000000000000815263ffffffff821660048201526001600160a01b03831690636750cd4c90602401602060405180830381865afa1580156134b3573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906134d791906156b9565b61350d576040517f391daaa400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b613515614446565b846000036135615763ffffffff87166000908152600b6020526040812080547fffffffffffffffffffffffff0000000000000000000000000000000000000000168155600101556135e7565b43851161359a576040517f05df9f2200000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b63ffffffff87166000908152600b6020526040902080547fffffffffffffffffffffffff0000000000000000000000000000000000000000166001600160a01b0388161781556001018590555b6040805163ffffffff891681526001600160a01b03881660208201529081018690527f55b28633cdb29709386f555dfc54418592ad475ce7a65a78ac5928af60ffb8f890606001610d87565b61363c84613f6c565b613647848484612735565b613652906001615b23565b67ffffffffffffffff168167ffffffffffffffff16146136aa576040517fc09b635000000000000000000000000000000000000000000000000000000000815267ffffffffffffffff82166004820152602401611523565b6001600160a01b038416600081815260016020908152604080832063ffffffff881680855290835281842087855283529281902080547fffffffffffffffffffffffffffffffffffffffffffffffff00000000000000001667ffffffffffffffff8716908117909155815193845291830186905282019290925260608101919091527f28f40053783033ef755556a0c3315379141f51a33aed8334174ffbadd90bde4890608001612d79565b604080518082019091526000808252602082015261377a60a08401608085016156d6565b801561378f5750600e546001600160a01b0316155b156137c6576040517f5af6d2aa00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b038216600090815260036020908152604082209082906137ef90870187614fe6565b63ffffffff1681526020808201929092526040908101600090812087840135825290925290205461382b9067ffffffffffffffff166001615b23565b905060006040518060e001604052808367ffffffffffffffff1681526020017f000000000000000000000000000000000000000000000000000000000000759663ffffffff168152602001856001600160a01b031681526020018660000160208101906138989190614fe6565b63ffffffff16815260200186602001358152602001613994847f0000000000000000000000000000000000000000000000000000000000007596888a60000160208101906138e69190614fe6565b8b60200135600085856001600160a01b03861660405160c09390931b7fffffffffffffffff00000000000000000000000000000000000000000000000016602084015260e091821b7fffffffff000000000000000000000000000000000000000000000000000000009081166028850152602c8401919091529085901b16604c8201526050810183905260700160405160208183030381529060405280519060200120905095945050505050565b81526020016139a66040880188615b44565b8080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920182905250939094525092935091506139f39050856109e26020890189614fe6565b90506001600160a01b03811663d80e9bd983613a1260608a018a615b44565b613a2260a08c0160808d016156d6565b6040518563ffffffff1660e01b8152600401613a419493929190615ba9565b6040805180830381865afa158015613a5d573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061148d9190615ca0565b613a89614446565b6040517f01ffc9a70000000000000000000000000000000000000000000000000000000081527f97f025840000000000000000000000000000000000000000000000000000000060048201526001600160a01b038216906301ffc9a790602401602060405180830381865afa158015613b06573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190613b2a91906156b9565b613b60576040517feb64f35d00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03811660009081526005602052604090205460ff1615613bb3576040517f8aea2fe600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b038116600081815260056020908152604080832080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff001660019081179091556004805491820181559093527f8a35acfbc15ff81a39ae7d344fd709f28e8600b4aa8c65c6b64bfe7fe36bd19b90920180547fffffffffffffffffffffffff0000000000000000000000000000000000000000168417905590519182527f6b374d56679ca9463f27c85c6311e2bb7fde69bf201d3da39d53f10bd9d78af59101613246565b613c87614446565b6001600160a01b038116613d1d576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602660248201527f4f776e61626c653a206e6577206f776e657220697320746865207a65726f206160448201527f64647265737300000000000000000000000000000000000000000000000000006064820152608401611523565b613d26816144ba565b50565b6001600160a01b038516600090815260016020908152604080832063ffffffff88168452825280832086845290915281205467ffffffffffffffff908116908416811015613e8457600181015b8467ffffffffffffffff168167ffffffffffffffff1611613e1f576001600160a01b038816600090815260026020908152604080832063ffffffff8b1684528252808320898452825280832067ffffffffffffffff85168452909152902054613e17576040517fc09b635000000000000000000000000000000000000000000000000000000000815267ffffffffffffffff82166004820152602401611523565b600101613d76565b506001600160a01b038716600090815260016020908152604080832063ffffffff8a1684528252808320888452909152902080547fffffffffffffffffffffffffffffffffffffffffffffffff00000000000000001667ffffffffffffffff86161790555b82516020808501919091206001600160a01b038916600090815260028352604080822063ffffffff8b1683528452808220898352845280822067ffffffffffffffff891683529093529190912054909250808314613f18576040517f7182306f0000000000000000000000000000000000000000000000000000000081526004810182905260248101849052604401611523565b50506001600160a01b03909516600090815260026020908152604080832063ffffffff909716835295815285822094825293845284812067ffffffffffffffff909316815291909252918220919091555090565b336001600160a01b03821614801590613f9f57506001600160a01b038181166000908152600f6020526040902054163314155b15613d26576040517fc4c5259300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b613fde614b15565b60008061406785613ff26020870187614fe6565b6001600160a01b0391909116600090815260036020908152604080832063ffffffff94909416835292815282822081890135835290522080547fffffffffffffffffffffffffffffffffffffffffffffffff00000000000000008116600167ffffffffffffffff928316019182161790915590565b905060006040518060e001604052808367ffffffffffffffff1681526020017f000000000000000000000000000000000000000000000000000000000000759663ffffffff168152602001876001600160a01b031681526020018660000160208101906140d49190614fe6565b63ffffffff16815260200186602001358152602001614122847f00000000000000000000000000000000000000000000000000000000000075968a8a60000160208101906138e69190614fe6565b81526020016141346040880188615b44565b8080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920182905250939094525092935091506141819050876109e26020890189614fe6565b90506000806001600160a01b038316634389e58f856141a360608c018c615b44565b6141b360a08e0160808f016156d6565b6040518563ffffffff1660e01b81526004016141d29493929190615ba9565b6000604051808303816000875af11580156141f1573d6000803e3d6000fd5b505050506040513d6000823e601f3d9081017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe01682016040526142379190810190615cbc565b90925090507f1ab700d4ced0c005b164c0f789fd09fcbb0156d4c2041b8a3bfbcd961cd1567f8161426b60608b018b615b44565b8660405161427c9493929190615d0b565b60405180910390a1506040805160608101825260a090940151845267ffffffffffffffff909416602084015292820192909252925090509250929050565b6000811561438357600e546040517f70a082310000000000000000000000000000000000000000000000000000000081523060048201526001600160a01b03909116906370a0823190602401602060405180830381865afa158015614323573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906143479190615d4c565b905080600003614383576040517f1775123700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b919050565b825182108061439a5750808360200151115b15612bea57825160208401516040517f4f3ec0d3000000000000000000000000000000000000000000000000000000008152600481019290925260248201849052604482015260648101829052608401611523565b831561440057614400858386614720565b82841015614415576144158582868603614720565b5050505050565b831561442c5761442c8285614774565b828410156144405761444081858503614774565b50505050565b6000546001600160a01b03163314611fca576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820181905260248201527f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e65726044820152606401611523565b600080546001600160a01b038381167fffffffffffffffffffffffff0000000000000000000000000000000000000000831681178455604051919092169283917f8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e09190a35050565b6000808267ffffffffffffffff1611806127c657506040517fff7bd03d0000000000000000000000000000000000000000000000000000000081526001600160a01b0384169063ff7bd03d9061457c908790600401615d65565b602060405180830381865afa158015614599573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906127c691906156b9565b6001600160a01b0383166145d557612bea8282614774565b612bea838383614720565b600067ffffffffffffffff82166145fd6060860160408701615528565b67ffffffffffffffff1611806127c657506001600160a01b0383166000908152600260209081526040822090829061463790880188614fe6565b63ffffffff1663ffffffff168152602001908152602001600020600086602001358152602001908152602001600020600086604001602081019061467b9190615528565b67ffffffffffffffff1681526020810191909152604001600020541415949350505050565b806146d7576040517f09beffb600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6001600160a01b03909416600090815260026020908152604080832063ffffffff909616835294815284822093825292835283812067ffffffffffffffff909216815291522055565b6001600160a01b038216614760576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b612bea6001600160a01b0384168383614853565b6001600160a01b0382166147b4576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6000826001600160a01b03168260405160006040518083038185875af1925050503d8060008114614801576040519150601f19603f3d011682016040523d82523d6000602084013e614806565b606091505b5050905080612bea576040517f465bc8340000000000000000000000000000000000000000000000000000000081526001600160a01b038416600482015260248101839052604401611523565b604080516001600160a01b03848116602483015260448083018590528351808403909101815260649092018352602080830180517bffffffffffffffffffffffffffffffffffffffffffffffffffffffff167fa9059cbb0000000000000000000000000000000000000000000000000000000017905283518085019094528084527f5361666545524332303a206c6f772d6c6576656c2063616c6c206661696c656490840152612bea928692916000916149119185169084906149be565b905080516000148061493257508080602001905181019061493291906156b9565b612bea576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602a60248201527f5361666545524332303a204552433230206f7065726174696f6e20646964206e60448201527f6f742073756363656564000000000000000000000000000000000000000000006064820152608401611523565b60606127c6848460008585600080866001600160a01b031685876040516149e59190615d73565b60006040518083038185875af1925050503d8060008114614a22576040519150601f19603f3d011682016040523d82523d6000602084013e614a27565b606091505b5091509150614a3887838387614a43565b979650505050505050565b60608315614acc578251600003614ac5576001600160a01b0385163b614ac5576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601d60248201527f416464726573733a2063616c6c20746f206e6f6e2d636f6e74726163740000006044820152606401611523565b50816127c6565b6127c68383815115614ae15781518083602001fd5b806040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016115239190614e91565b604051806060016040528060008019168152602001600067ffffffffffffffff168152602001614b58604051806040016040528060008152602001600081525090565b905290565b600060608284031215614b6f57600080fd5b50919050565b80356001600160a01b038116811461438357600080fd5b60008083601f840112614b9e57600080fd5b50813567ffffffffffffffff811115614bb657600080fd5b6020830191508360208285010111156116fe57600080fd5b600080600080600080600060e0888a031215614be957600080fd5b614bf38989614b5d565b9650614c0160608901614b75565b95506080880135945060a088013567ffffffffffffffff80821115614c2557600080fd5b614c318b838c01614b8c565b909650945060c08a0135915080821115614c4a57600080fd5b50614c578a828b01614b8c565b989b979a50959850939692959293505050565b803563ffffffff8116811461438357600080fd5b60008060008060808587031215614c9457600080fd5b614c9d85614b75565b9350614cab60208601614c6a565b9250614cb960408601614b75565b9396929550929360600135925050565b60008060408385031215614cdc57600080fd5b823567ffffffffffffffff811115614cf357600080fd5b830160a08186031215614d0557600080fd5b9150614d1360208401614b75565b90509250929050565b60006080820190508251825267ffffffffffffffff60208401511660208301526040830151614d58604084018280518252602090810151910152565b5092915050565b600080600080600060c08688031215614d7757600080fd5b614d8086614b75565b9450614d8f8760208801614b5d565b93506080860135925060a086013567ffffffffffffffff811115614db257600080fd5b614dbe88828901614b8c565b969995985093965092949392505050565b60008060008060808587031215614de557600080fd5b614dee85614b75565b9350614dfc60208601614b75565b9250614e0a60408601614c6a565b9150614e1860608601614c6a565b905092959194509250565b60005b83811015614e3e578181015183820152602001614e26565b50506000910152565b60008151808452614e5f816020860160208601614e23565b601f017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0169290920160200192915050565b6020815260006121376020830184614e47565b803567ffffffffffffffff8116811461438357600080fd5b600080600080600060a08688031215614ed457600080fd5b614edd86614b75565b9450614eeb60208701614c6a565b935060408601359250614f0060608701614ea4565b949793965091946080013592915050565b803561ffff8116811461438357600080fd5b60008060008060808587031215614f3957600080fd5b614f4285614b75565b9350614f5060208601614b75565b925060408501359150614e1860608601614f11565b60008060408385031215614f7857600080fd5b614f8183614b75565b9150614d1360208401614c6a565b600060208284031215614fa157600080fd5b61213782614b75565b600080600060608486031215614fbf57600080fd5b614fc884614b75565b9250614fd660208501614c6a565b9150604084013590509250925092565b600060208284031215614ff857600080fd5b61213782614c6a565b6000806000806000806000806000806000806101208d8f03121561502457600080fd5b61502d8d614b75565b9b5061503b60208e01614b75565b9a5060408d0135995061505060608e01614f11565b985060808d0135975060a08d0135965067ffffffffffffffff60c08e0135111561507957600080fd5b6150898e60c08f01358f01614b8c565b909650945067ffffffffffffffff60e08e013511156150a757600080fd5b6150b78e60e08f01358f01614b8c565b909450925067ffffffffffffffff6101008e013511156150d657600080fd5b6150e78e6101008f01358f01614b8c565b81935080925050509295989b509295989b509295989b565b60008060008060008060008060008060006101408c8e03121561512157600080fd5b61512b8d8d614b5d565b9a5061513960608d01614b75565b995060808c0135985060a08c0135975060c08c0135965067ffffffffffffffff8060e08e0135111561516a57600080fd5b61517a8e60e08f01358f01614b8c565b90975095506101008d013581101561519157600080fd5b6151a28e6101008f01358f01614b8c565b90955093506101208d01358110156151b957600080fd5b506151cb8d6101208e01358e01614b8c565b81935080925050509295989b509295989b9093969950565b600080600080606085870312156151f957600080fd5b61520285614b75565b935061521060208601614b75565b9250604085013567ffffffffffffffff8082111561522d57600080fd5b818701915087601f83011261524157600080fd5b81358181111561525057600080fd5b8860208260051b850101111561526557600080fd5b95989497505060200194505050565b60008060008060006080868803121561528c57600080fd5b61529586614b75565b9450602086013593506152aa60408701614f11565b9250606086013567ffffffffffffffff811115614db257600080fd5b600080608083850312156152d957600080fd5b6152e38484614b5d565b9150614d1360608401614b75565b6020808252825182820181905260009190848201906040850190845b818110156153325783516001600160a01b03168352928401929184019160010161530d565b50909695505050505050565b60008060008060008060008060c0898b03121561535a57600080fd5b61536389614b75565b975061537160208a01614b75565b96506040890135955061538660608a01614f11565b9450608089013567ffffffffffffffff808211156153a357600080fd5b6153af8c838d01614b8c565b909650945060a08b01359150808211156153c857600080fd5b506153d58b828c01614b8c565b999c989b5096995094979396929594505050565b6000806000606084860312156153fe57600080fd5b61540784614b75565b925061541560208501614c6a565b915061542360408501614b75565b90509250925092565b60008060006060848603121561544157600080fd5b61544a84614c6a565b9250614fd660208501614b75565b60008060006060848603121561546d57600080fd5b61544a84614b75565b600080600060a0848603121561548b57600080fd5b6154958585614b5d565b92506154a360608501614b75565b9150608084013590509250925092565b600080604083850312156154c657600080fd5b614d0583614c6a565b600080600080608085870312156154e557600080fd5b6154ee85614b75565b93506154fc60208601614c6a565b925060408501359150614e1860608601614ea4565b8151815260208083015190820152604081016118ff565b60006020828403121561553a57600080fd5b61213782614ea4565b838152818360208301376000910160200190815292915050565b63ffffffff61556b82614c6a565b1682526020810135602083015267ffffffffffffffff61558d60408301614ea4565b1660408301525050565b8183528181602085013750600060208284010152600060207fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0601f840116840101905092915050565b6155ea818961555d565b86606082015260e06080820152600061560760e083018789615597565b6001600160a01b03861660a084015282810360c0840152615629818587615597565b9a9950505050505050505050565b60808101615645828561555d565b6001600160a01b03831660608301529392505050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602160045260246000fd5b60006020828403121561569c57600080fd5b81516003811061213757600080fd5b8015158114613d2657600080fd5b6000602082840312156156cb57600080fd5b8151612137816156ab565b6000602082840312156156e857600080fd5b8135612137816156ab565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b600082601f83011261573357600080fd5b815167ffffffffffffffff8082111561574e5761574e6156f3565b604051601f83017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0908116603f01168101908282118183101715615794576157946156f3565b816040528381528660208588010111156157ad57600080fd5b61148d846020830160208901614e23565b6000602082840312156157d057600080fd5b815167ffffffffffffffff8111156157e757600080fd5b6127c684828501615722565b8a815261ffff8a16602082015288604082015287606082015260e06080820152600061582360e08301888a615597565b82810360a0840152615836818789615597565b905082810360c084015261584b818587615597565b9d9c50505050505050505050505050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b808201808211156118ff576118ff61585c565b60006101206158ad838e61555d565b8b60608401528a60808401528960a08401528060c08401526158d2818401898b615597565b905082810360e08401526158e7818789615597565b905082810361010084015261584b818587615597565b600060408083016001600160a01b03871684526020604081860152818683526060925060608601905060608760051b8701018860005b89811015615a3e577fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa089840301845281357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa18c360301811261599457600080fd5b8b0163ffffffff806159a583614c6a565b168552806159b4888401614c6a565b168786015250878101357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe18236030181126159ee57600080fd5b01858101903567ffffffffffffffff811115615a0957600080fd5b803603821315615a1857600080fd5b8789860152615a2a8886018284615597565b958701959450505090840190600101615933565b50909a9950505050505050505050565b8183823760009101908152919050565b60006001600160a01b03808916835280881660208401525085604083015261ffff8516606083015260a06080830152615a9b60a083018486615597565b98975050505050505050565b60006001600160a01b03808a16835288602084015260a06040840152615ad160a08401888a615597565b81871660608501528381036080850152615aec818688615597565b9b9a5050505050505050505050565b60a08101615b09828661555d565b6001600160a01b0393909316606082015260800152919050565b67ffffffffffffffff818116838216019080821115614d5857614d5861585c565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe1843603018112615b7957600080fd5b83018035915067ffffffffffffffff821115615b9457600080fd5b6020019150368190038213156116fe57600080fd5b6060815267ffffffffffffffff855116606082015263ffffffff60208601511660808201526001600160a01b0360408601511660a082015260006060860151615bfa60c084018263ffffffff169052565b50608086015160e083015260a086015161010083015260c086015160e0610120840152615c2b610140840182614e47565b90508281036020840152615c40818688615597565b915050612e8d604083018415159052565b600060408284031215615c6357600080fd5b6040516040810181811067ffffffffffffffff82111715615c8657615c866156f3565b604052825181526020928301519281019290925250919050565b600060408284031215615cb257600080fd5b6121378383615c51565b60008060608385031215615ccf57600080fd5b615cd98484615c51565b9150604083015167ffffffffffffffff811115615cf557600080fd5b615d0185828601615722565b9150509250929050565b606081526000615d1e6060830187614e47565b8281036020840152615d31818688615597565b9150506001600160a01b038316604083015295945050505050565b600060208284031215615d5e57600080fd5b5051919050565b606081016118ff828461555d565b60008251615d85818460208701614e23565b919091019291505056fea2646970667358221220fbeacb9e09f521d9b83b94a56dbd81b62f43beb282a6a4281738d9f94234e59364736f6c63430008160033"
  },
  {
    method: "eth_getCode",
    params: [
      "0x9f8c645f2d0b2159767bd6e0839de4be49e823de",
      "0x80f2a08"
    ],
    result: "0x6080604052600436106101845760003560e01c806361d027b3116100d6578063d15b0d491161007f578063f2fde38b11610059578063f2fde38b14610513578063faaebd2114610533578063fd9be5221461056e57600080fd5b8063d15b0d49146104a6578063d80e9bd9146104c6578063f0f44260146104f357600080fd5b80638da5cb5b116100b05780638da5cb5b1461042e5780639c33abf714610459578063c14c43491461048657600080fd5b806361d027b3146103a75780636750cd4c146103f9578063715018a61461041957600080fd5b806329460b0b1161013857806343ea4fa91161011257806343ea4fa9146102cb5780634d963200146102eb57806354fd4d501461037a57600080fd5b806329460b0b1461025057806339e3f938146102705780634389e58f1461029d57600080fd5b80631881d94d116101695780631881d94d146101f2578063200175f71461020e57806320efd7221461023057600080fd5b806301ffc9a714610190578063188183f4146101c557600080fd5b3661018b57005b600080fd5b34801561019c57600080fd5b506101b06101ab36600461453b565b61058e565b60405190151581526020015b60405180910390f35b3480156101d157600080fd5b506101e56101e03660046145cc565b610673565b6040516101bc9190614605565b3480156101fe57600080fd5b5060006040516101bc9190614638565b34801561021a57600080fd5b5061022e610229366004614679565b610780565b005b34801561023c57600080fd5b5061022e61024b3660046146ff565b61092d565b34801561025c57600080fd5b5061022e61026b366004614754565b610ae1565b34801561027c57600080fd5b5061029061028b3660046145cc565b610cc6565b6040516101bc919061485a565b3480156102a957600080fd5b506102bd6102b8366004614886565b610e67565b6040516101bc9291906149a4565b3480156102d757600080fd5b506102906102e63660046145cc565b610f61565b3480156102f757600080fd5b506103496103063660046145cc565b600460209081526000928352604080842090915290825290205463ffffffff811690640100000000900473ffffffffffffffffffffffffffffffffffffffff1682565b6040805163ffffffff909316835273ffffffffffffffffffffffffffffffffffffffff9091166020830152016101bc565b34801561038657600080fd5b506040805160038152600060208201526002918101919091526060016101bc565b3480156103b357600080fd5b506003546103d49073ffffffffffffffffffffffffffffffffffffffff1681565b60405173ffffffffffffffffffffffffffffffffffffffff90911681526020016101bc565b34801561040557600080fd5b506101b06104143660046149c8565b61131b565b34801561042557600080fd5b5061022e611326565b34801561043a57600080fd5b5060005473ffffffffffffffffffffffffffffffffffffffff166103d4565b34801561046557600080fd5b506104796104743660046149e5565b61133a565b6040516101bc9190614a30565b34801561049257600080fd5b5061022e6104a1366004614a43565b611421565b3480156104b257600080fd5b5061022e6104c1366004614ab8565b611599565b3480156104d257600080fd5b506104e66104e1366004614886565b611627565b6040516101bc9190614ad1565b3480156104ff57600080fd5b5061022e61050e366004614ae8565b611697565b34801561051f57600080fd5b5061022e61052e366004614ae8565b6116ab565b34801561053f57600080fd5b5061056061054e366004614ae8565b60056020526000908152604090205481565b6040519081526020016101bc565b34801561057a57600080fd5b5061022e610589366004614b05565b61175f565b60007fffffffff0000000000000000000000000000000000000000000000000000000082167f97f0258400000000000000000000000000000000000000000000000000000000148061062157507fffffffff0000000000000000000000000000000000000000000000000000000082167fb6e9ace300000000000000000000000000000000000000000000000000000000145b8061066d57507f01ffc9a7000000000000000000000000000000000000000000000000000000007fffffffff000000000000000000000000000000000000000000000000000000008316145b92915050565b604080518082019091526000808252602082015263ffffffff80831660008181527f17ef568e3e12ab5b9c7254a8d58478811de00f9e6eb34345acd53bf8fd09d3ec6020908152604080832073ffffffffffffffffffffffffffffffffffffffff8916845260048352818420948452939091528120805492939092169081900361070457825463ffffffff16610706565b805b63ffffffff1684528154640100000000900473ffffffffffffffffffffffffffffffffffffffff1680610758578354640100000000900473ffffffffffffffffffffffffffffffffffffffff1661075a565b805b73ffffffffffffffffffffffffffffffffffffffff166020860152509295945050505050565b60035473ffffffffffffffffffffffffffffffffffffffff1633146107d1576040517f885762a700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b8273ffffffffffffffffffffffffffffffffffffffff167f0000000000000000000000001a44076050125825900e736c501f859c50fe728c73ffffffffffffffffffffffffffffffffffffffff1663e1758bd86040518163ffffffff1660e01b8152600401602060405180830381865afa158015610853573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906108779190614b31565b73ffffffffffffffffffffffffffffffffffffffff16036108c4576040517fe695d04400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6108cf838383611859565b6040805173ffffffffffffffffffffffffffffffffffffffff8086168252841660208201529081018290527fe081464b7278501267de69fa85b7b9560b0ae05d5fbfaab9b1986c70356e2efe906060015b60405180910390a1505050565b7f0000000000000000000000001a44076050125825900e736c501f859c50fe728c73ffffffffffffffffffffffffffffffffffffffff16331461099c576040517f467409c300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60005b81811015610adb57368383838181106109ba576109ba614b4e565b90506020028101906109cc9190614b7d565b90506109e36109de60208301836149c8565b6118cc565b60016109f560408301602084016149c8565b63ffffffff1603610a3557610a30610a1060208301836149c8565b86610a1e6040850185614bbb565b810190610a2b9190614cea565b611913565b610ad2565b6002610a4760408301602084016149c8565b63ffffffff1603610a8257610a30610a6260208301836149c8565b86610a706040850185614bbb565b810190610a7d9190614ea3565b6119c0565b610a9260408201602083016149c8565b6040517fba97c1fa00000000000000000000000000000000000000000000000000000000815263ffffffff90911660048201526024015b60405180910390fd5b5060010161099f565b50505050565b610ae9611a09565b60005b81811015610c885736838383818110610b0757610b07614b4e565b9050602002810190610b199190614ed8565b905060ff610b2a6020830183614f0c565b610b3b906040810190602001614f40565b60ff1603610b75576040517f83aa17da00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60ff610b846020830183614f0c565b610b95906060810190604001614f40565b60ff1603610bcf576040517f4221136600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b67ffffffffffffffff610be56020830183614f0c565b610bf3906020810190614f5b565b67ffffffffffffffff1603610c34576040517f503667ae00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610c52610c446020830183614f0c565b610c4d90614f76565b611a8a565b610c7f6000610c6460208401846149c8565b610c716020850185614f0c565b610c7a90614f76565b611adb565b50600101610aec565b507faaf3aaa0c11056e86ac56eb653e25b005ca1a7d4dcd21ba24647f7ab63f3b5608282604051610cba929190615034565b60405180910390a15050565b6040805160c0810182526000808252602082018190529181018290526060808201929092526080810182905260a081019190915273ffffffffffffffffffffffffffffffffffffffff8316600090815260016020818152604080842063ffffffff87168552825292839020835160c081018552815467ffffffffffffffff8116825260ff680100000000000000008204811683860152690100000000000000000082048116838801526a01000000000000000000009091041660608201529281018054855181850281018501909652808652939491936080860193830182828015610de757602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff168152600190910190602001808311610dbc575b5050505050815260200160028201805480602002602001604051908101604052809291908181526020018280548015610e5657602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff168152600190910190602001808311610e2b575b505050505081525050905092915050565b604080518082019091526000808252602082015260607f0000000000000000000000001a44076050125825900e736c501f859c50fe728c73ffffffffffffffffffffffffffffffffffffffff163314610eec576040517f467409c300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b600080610efa888888611e6f565b9092509050600080610f2c610f1560608c0160408d01614ae8565b610f2560808d0160608e016149c8565b858a611f3c565b9092509050610f3b8284615203565b604080518082019091529081526020810191909152945091925050505b94509492505050565b6040805160c0810182526000808252602080830182905282840182905260608084018390526080840181905260a084015263ffffffff85168083527fa6eef7e35abe7026729641147f7915573c7e97b47efa546f5f6e3230263bcb49825284832073ffffffffffffffffffffffffffffffffffffffff88168452600183528584209184529152929020805491929167ffffffffffffffff168061101157825467ffffffffffffffff168452611030565b67ffffffffffffffff818116146110305767ffffffffffffffff811684525b815468010000000000000000900460ff166110e657825468010000000000000000900460ff16156110e157826001018054806020026020016040519081016040528092919081815260200182805480156110c057602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff168152600190910190602001808311611095575b50505050506080850152825468010000000000000000900460ff1660208501525b611184565b815468010000000000000000900460ff90811614611184578160010180548060200260200160405190810160405280929190818152602001828054801561116357602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff168152600190910190602001808311611138575b50505050506080850152815468010000000000000000900460ff1660208501525b81546901000000000000000000900460ff166112535782546901000000000000000000900460ff161561124e578260020180548060200260200160405190810160405280929190818152602001828054801561121657602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff1681526001909101906020018083116111eb575b505050505060a0850152825460ff69010000000000000000008204811660408701526a01000000000000000000009091041660608501525b611309565b81546901000000000000000000900460ff9081161461130957816002018054806020026020016040519081016040528092919081815260200182805480156112d157602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff1681526001909101906020018083116112a6575b505050505060a0850152815460ff69010000000000000000008204811660408701526a01000000000000000000009091041660608501525b61131284611a8a565b50505092915050565b600061066d826120ca565b61132e611a09565b6113386000612131565b565b60607fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff63ffffffff831601611399576113738385610673565b6040516020016113839190614605565b604051602081830303815290604052905061141a565b7ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe63ffffffff8316016113e0576113d08385610f61565b604051602001611383919061485a565b6040517fba97c1fa00000000000000000000000000000000000000000000000000000000815263ffffffff83166004820152602401610ac9565b9392505050565b611429611a09565b60005b81811015611567573683838381811061144757611447614b4e565b60609081029290920192506000916114659150830160408401614ae8565b73ffffffffffffffffffffffffffffffffffffffff16036114b2576040517f20e9d05a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6114c260408201602083016149c8565b63ffffffff16600003611501576040517f49cfac4300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6000808052600460209081528201907f17ef568e3e12ab5b9c7254a8d58478811de00f9e6eb34345acd53bf8fd09d3ec9061153c83856149c8565b63ffffffff168152602081019190915260400160002061155c8282615216565b50505060010161142c565b507f2b001e1c6683bf79cc52891bd7215b204c787d18134fc7f3d21b4f32a49e47de8282604051610cba9291906152ae565b6115a1611a09565b6002548111156115eb576002546040517f34084fb8000000000000000000000000000000000000000000000000000000008152610ac9918391600401918252602082015260400190565b60028190556040518181527f491ff913b5444f4136b0d4075f020cfe3a5f60de926ec0b091612401a22b7842906020015b60405180910390a150565b60408051808201909152600080825260208201526000806116786116516060890160408a01614ae8565b61166160808a0160608b016149c8565b61166e60c08b018b614bbb565b9050878a8a6121a6565b604080518082019091529182526020820152925050505b949350505050565b61169f611a09565b6116a8816122ac565b50565b6116b3611a09565b73ffffffffffffffffffffffffffffffffffffffff8116611756576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602660248201527f4f776e61626c653a206e6577206f776e657220697320746865207a65726f206160448201527f64647265737300000000000000000000000000000000000000000000000000006064820152608401610ac9565b6116a881612131565b6117688161231f565b60007f0000000000000000000000001a44076050125825900e736c501f859c50fe728c73ffffffffffffffffffffffffffffffffffffffff1663e1758bd86040518163ffffffff1660e01b8152600401602060405180830381865afa1580156117d5573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906117f99190614b31565b9050611806818484612389565b6040805133815273ffffffffffffffffffffffffffffffffffffffff851660208201529081018390527f820b7fd51bf79c54350bab98400651b3314ff6e79b33528821871d94a666988390606001610920565b73ffffffffffffffffffffffffffffffffffffffff82166118a6576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6118c773ffffffffffffffffffffffffffffffffffffffff841683836123b9565b505050565b6118d5816120ca565b6116a8576040517ff0c10d0400000000000000000000000000000000000000000000000000000000815263ffffffff82166004820152602401610ac9565b73ffffffffffffffffffffffffffffffffffffffff808316600090815260046020908152604080832063ffffffff8089168552908352928190208551815493870151909516640100000000027fffffffffffffffff0000000000000000000000000000000000000000000000009093169490931693909317179055517f779cb2dd9d2bb1be1737d05435d744facbfb84a2a4912e21379d39beddcdc805906109209084908690859061533b565b6119cb828483611adb565b6119d58284610f61565b507f82118522aa536ac0e96cc5c689407ae42b89d592aa133890a01f1509842f508182848360405161092093929190615397565b60005473ffffffffffffffffffffffffffffffffffffffff163314611338576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820181905260248201527f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e65726044820152606401610ac9565b602081015160ff16158015611aa45750606081015160ff16155b156116a8576040517fce2c375100000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b602081015160ff9081161480611af65750602081015160ff16155b15611b3d5760808101515115611b38576040517f83aa17da00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b611bbc565b806020015160ff16816080015151141580611b7857506002611b61600160ff6153d2565b611b6b91906153eb565b60ff16816020015160ff16115b15611baf576040517f83aa17da00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b611bbc8160800151612446565b604081015160ff9081161480611bd75750604081015160ff16155b15611c5d5760a08101515115611c19576040517f4221136600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b606081015160ff1615611c58576040517f38682fa900000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b611d34565b806040015160ff168160a0015151141580611c9857506002611c81600160ff6153d2565b611c8b91906153eb565b60ff16816040015160ff16115b15611ccf576040517f4221136600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b606081015160ff161580611cf05750806040015160ff16816060015160ff16115b15611d27576040517f38682fa900000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b611d348160a00151612446565b73ffffffffffffffffffffffffffffffffffffffff8316600090815260016020818152604080842063ffffffff87168552825292839020845181548684015195870151606088015167ffffffffffffffff9093167fffffffffffffffffffffffffffffffffffffffffffffff000000000000000000909216919091176801000000000000000060ff97881602177fffffffffffffffffffffffffffffffffffffffffff0000ffffffffffffffffff166901000000000000000000918716919091027fffffffffffffffffffffffffffffffffffffffffff00ffffffffffffffffffff16176a0100000000000000000000959091169490940293909317835560808401518051859493611e4b939085019201906144a5565b5060a08201518051611e679160028401916020909101906144a5565b505050505050565b60606000806000611e8086866124e0565b90925090506000611eaa611e9a60608a0160408b01614ae8565b6101e060808b0160608c016149c8565b90506000611ebb60c08a018a614bbb565b90509050611ed381836000015163ffffffff166124f9565b6020820151611f0390611eec60808c0160608d016149c8565b611efc60608d0160408e01614ae8565b8488612541565b611f0d9086615203565b9450600080611f1c8b8661267a565b9092509050611f2b8288615203565b909b909a5098505050505050505050565b600354600090819073ffffffffffffffffffffffffffffffffffffffff1615610f585760405173ffffffffffffffffffffffffffffffffffffffff8716602482015263ffffffff8616604482015260648101859052831515608482015260009060a401604080517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0818403018152919052602080820180517bffffffffffffffffffffffffffffffffffffffffffffffffffffffff167fd51c54860000000000000000000000000000000000000000000000000000000017905260035491925060009182916120669173ffffffffffffffffffffffffffffffffffffffff16907f0000000000000000000000000000000000000000000000000000000000030d409084908761269d565b915091506120768787848461274e565b909550935084156120be5760035473ffffffffffffffffffffffffffffffffffffffff16600090815260056020526040812080548792906120b8908490615203565b90915550505b50505094509492505050565b63ffffffff811660009081527fa6eef7e35abe7026729641147f7915573c7e97b47efa546f5f6e3230263bcb4960205260408120805468010000000000000000900460ff1615158061141a5750546a0100000000000000000000900460ff16151592915050565b6000805473ffffffffffffffffffffffffffffffffffffffff8381167fffffffffffffffffffffffff0000000000000000000000000000000000000000831681178455604051919092169283917f8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e09190a35050565b6000806000806121b686866124e0565b9150915060006121c78b8b846127c9565b905060006121d58c8c610673565b90506121eb8a826000015163ffffffff166124f9565b806020015173ffffffffffffffffffffffffffffffffffffffff1663709eb6648c8e8d886040518563ffffffff1660e01b815260040161222e9493929190615434565b602060405180830381865afa15801561224b573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061226f919061547f565b6122799083615203565b915060008061228a8e8e868e6127d6565b90925090506122998285615203565b9e909d509b505050505050505050505050565b600380547fffffffffffffffffffffffff00000000000000000000000000000000000000001673ffffffffffffffffffffffffffffffffffffffff83169081179091556040519081527f3c864541ef71378c6229510ed90f376565ee42d9c5e0904a984a9e863e6db44f9060200161161c565b3360009081526005602052604090205480821115612373576040517f34084fb80000000000000000000000000000000000000000000000000000000081526004810183905260248101829052604401610ac9565b3360009081526005602052604090209190039055565b73ffffffffffffffffffffffffffffffffffffffff83166123ae576118c7828261291a565b6118c7838383611859565b6040805173ffffffffffffffffffffffffffffffffffffffff8416602482015260448082018490528251808303909101815260649091019091526020810180517bffffffffffffffffffffffffffffffffffffffffffffffffffffffff167fa9059cbb000000000000000000000000000000000000000000000000000000001790526118c7908490612a20565b6000805b82518110156118c757600083828151811061246757612467614b4e565b602002602001015190508273ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff16116124d6576040517f447516e100000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b915060010161244a565b6060806124ed8484612b2f565b915091505b9250929050565b8082111561253d576040517fc667af3e0000000000000000000000000000000000000000000000000000000081526004810183905260248101829052604401610ac9565b5050565b6040517f717e8a4200000000000000000000000000000000000000000000000000000000815260009073ffffffffffffffffffffffffffffffffffffffff87169063717e8a429061259c908890889088908890600401615434565b6020604051808303816000875af11580156125bb573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906125df919061547f565b905080156126225773ffffffffffffffffffffffffffffffffffffffff86166000908152600560205260408120805483929061261c908490615203565b90915550505b6040805173ffffffffffffffffffffffffffffffffffffffff88168152602081018390527f61ed099e74a97a1d7f8bb0952a88ca8b7b8ebd00c126ea04671f92a81213318a910160405180910390a195945050505050565b60006060612692600561268c86615526565b85612c1c565b909590945092505050565b60006060863b8083036126c457604080516000808252602082019092529250925050612744565b60008060008761ffff1667ffffffffffffffff8111156126e6576126e6614c20565b6040519080825280601f01601f191660200182016040528015612710576020820181803683370190505b509050600080885160208a018c8f8ff191503d925087831115612731578792505b828152826000602083013e909450925050505b9550959350505050565b60008083158061275f575082516020115b1561276f57506000905080610f58565b600083806020019051810190612785919061547f565b90508515612795578091506127bf565b600060025488116127a8576002546127aa565b875b90508082116127b957816127bb565b805b9350505b5094509492505050565b600061168f848484612d78565b600354600090819073ffffffffffffffffffffffffffffffffffffffff1615610f585760405173ffffffffffffffffffffffffffffffffffffffff8716602482015263ffffffff8616604482015260648101859052831515608482015260009060a401604080517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0818403018152919052602080820180517bffffffffffffffffffffffffffffffffffffffffffffffffffffffff167fd42442210000000000000000000000000000000000000000000000000000000017905260035491925060009182916128fe9173ffffffffffffffffffffffffffffffffffffffff16907f0000000000000000000000000000000000000000000000000000000000030d409086612df2565b9150915061290e8787848461274e565b94509450505050610f58565b73ffffffffffffffffffffffffffffffffffffffff8216612967576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60008273ffffffffffffffffffffffffffffffffffffffff168260405160006040518083038185875af1925050503d80600081146129c1576040519150601f19603f3d011682016040523d82523d6000602084013e6129c6565b606091505b50509050806118c7576040517f465bc83400000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff8416600482015260248101839052604401610ac9565b6000612a82826040518060400160405280602081526020017f5361666545524332303a206c6f772d6c6576656c2063616c6c206661696c65648152508573ffffffffffffffffffffffffffffffffffffffff16612e9f9092919063ffffffff16565b9050805160001480612aa3575080806020019051810190612aa391906155c4565b6118c7576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602a60248201527f5361666545524332303a204552433230206f7065726174696f6e20646964206e60448201527f6f742073756363656564000000000000000000000000000000000000000000006064820152608401610ac9565b606080600080612b3f8686612eae565b915091508051600003612b9757604080516000808252602082019092528391612b8b565b604080518082019091526000815260606020820152815260200190600190039081612b635790505b509350935050506124f2565b604080516001808252818301909252600091816020015b604080518082019091526000815260606020820152815260200190600190039081612bae5790505090506040518060400160405280600260ff1681526020018381525081600081518110612c0457612c04614b4e565b60209081029190910101529196919550909350505050565b600060606000612c2b856130ef565b90506000612c38866131d5565b805160208201206060880151604089015192935090916000612c5a8284610f61565b905060008951600014612c8b5789600081518110612c7a57612c7a614b4e565b602002602001015160200151612c9c565b604051806020016040528060008152505b90506060612cfc8d846040518060a001604052808963ffffffff1681526020018c81526020018a8152602001876000015167ffffffffffffffff1681526020018873ffffffffffffffffffffffffffffffffffffffff16815250856131f2565b604051919b509150612d1490899089906020016155e1565b60405160208183030381529060405298507f07ea52d82345d6e838192107d8fd7123d9c2ec8e916cd0aad13fd2b60db2464483608001518460a0015183604051612d6093929190615610565b60405180910390a15050505050505050935093915050565b600080612d858585610f61565b905060008351600014612db65783600081518110612da557612da5614b4e565b602002602001015160200151612dc7565b604051806020016040528060008152505b9050600080612dd5836134de565b91509150612de684888a8585613782565b98975050505050505050565b60006060853b808303612e1957604080516000808252602082019092529250925050610f58565b60008060008761ffff1667ffffffffffffffff811115612e3b57612e3b614c20565b6040519080825280601f01601f191660200182016040528015612e65576020820181803683370190505b509050600080885160208a018d8dfa91503d925087831115612e85578792505b828152826000602083013e90999098509650505050505050565b606061168f8484600085613940565b6060806002831015612eef576040517f6592671c00000000000000000000000000000000000000000000000000000000815260006004820152602401610ac9565b6000612efe600282868861566e565b612f0791615698565b60f01c905060027ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffd82016130d8578060005b86831015613064576000612f5260018501858a8c61566e565b612f5b916156e0565b60f81c90506000819003612f9e576040517f6780cfaf00000000000000000000000000000000000000000000000000000000815260006004820152602401610ac9565b8160ff16600003612fb157809150612fee565b8160ff168160ff1614612fee57366000612fcd86868c8e61566e565b91509150612fde8989868585613a59565b9099509750859450919250829150505b600184019360009061300590600301868b8d61566e565b61300e91615698565b60f01c90506000819003613051576040517f6592671c00000000000000000000000000000000000000000000000000000000815260048101869052602401610ac9565b8060020161ffff16850194505050612f39565b8287146130a0576040517f6592671c00000000000000000000000000000000000000000000000000000000815260048101849052602401610ac9565b60028711156130d1573660006130b885858b8d61566e565b915091506130c98888858585613a59565b909850965050505b50506130e6565b6130e3828787613bce565b93505b50509250929050565b8051602080830151604080850151606080870151608088015193517f01000000000000000000000000000000000000000000000000000000000000009681019690965260c09690961b7fffffffffffffffff00000000000000000000000000000000000000000000000016602186015260e093841b7fffffffff00000000000000000000000000000000000000000000000000000000908116602987015273ffffffffffffffffffffffffffffffffffffffff909216602d8601529490921b909116604d83015260518201526071015b6040516020818303038152906040529050919050565b60608160a001518260c001516040516020016131bf929190615726565b60006060600080613202856134de565b9150915060008760400151886020015161321c919061574c565b90508060ff1667ffffffffffffffff81111561323a5761323a614c20565b604051908082528060200260200182016040528015613263578160200160208202803683370190505b50935060005b8160ff168160ff1610156134d1576000896020015160ff168260ff16106132be5760a08a015160208b015161329e90846153d2565b60ff16815181106132b1576132b1614b4e565b60200260200101516132e0565b89608001518260ff16815181106132d7576132d7614b4e565b60200260200101515b60408051602081019091526000808252919250905b855181101561334d578360ff1686828151811061331457613314614b4e565b602002602001015160ff16036133455786818151811061333657613336614b4e565b6020026020010151915061334d565b6001016132f5565b506040517f95d376d700000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff8316906395d376d7906133a2908d908590600401615765565b6020604051808303816000875af11580156133c1573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906133e5919061547f565b878460ff16815181106133fa576133fa614b4e565b6020026020010181815250506000878460ff168151811061341d5761341d614b4e565b602002602001015111156134c757868360ff168151811061344057613440614b4e565b60200260200101518c60008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060008282546134959190615203565b92505081905550868360ff16815181106134b1576134b1614b4e565b6020026020010151886134c49190615203565b97505b5050600101613269565b5050505094509492505050565b60608082516000036134ef57915091565b60006134fa84613e4d565b90508060ff166001036135ac5760408051600180825281830190925290816020015b606081526020019060019003908161351c579050509250838360008151811061354757613547614b4e565b60209081029190910101526040805160018082528183019092529081602001602082028036833701905050915061357f846003613f72565b8260008151811061359257613592614b4e565b602002602001019060ff16908160ff168152505050915091565b8060ff1667ffffffffffffffff8111156135c8576135c8614c20565b6040519080825280602002602001820160405280156135f1578160200160208202803683370190505b5091508060ff1667ffffffffffffffff81111561361057613610614c20565b60405190808252806020026020018201604052801561364357816020015b606081526020019060019003908161362e5790505b50925060008060ff5b86518310156136f75760019092019160006136678885613ff2565b600294909401939050600061367c8986613f72565b90508260ff1660ff03613691578092506136e8565b8260ff168160ff16146136e8577ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffd8486030160006136d08b8784614072565b90506136de8a8a87846141ec565b5093909301929150815b5061ffff16929092019161364c565b8183036000613707898584614072565b9050613715888885846141ec565b60005b8660ff168160ff16101561377657878160ff168151811061373b5761373b614b4e565b6020908102919091010180517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0160ff169052600101613718565b50505050505050915091565b60008086604001518760200151613799919061574c565b905060005b8160ff168160ff161015613935576000886020015160ff168260ff16106137f35760a089015160208a01516137d390846153d2565b60ff16815181106137e6576137e6614b4e565b6020026020010151613815565b88608001518260ff168151811061380c5761380c614b4e565b60200260200101515b60408051602081019091526000808252919250905b8651811015613882578360ff1687828151811061384957613849614b4e565b602002602001015160ff160361387a5787818151811061386b5761386b614b4e565b60200260200101519150613882565b60010161382a565b5089516040517f30bb3aac00000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff8416916330bb3aac916138db918d918d9087906004016157e3565b602060405180830381865afa1580156138f8573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061391c919061547f565b6139269086615203565b9450505080600101905061379e565b505095945050505050565b6060824710156139d2576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602660248201527f416464726573733a20696e73756666696369656e742062616c616e636520666f60448201527f722063616c6c00000000000000000000000000000000000000000000000000006064820152608401610ac9565b6000808673ffffffffffffffffffffffffffffffffffffffff1685876040516139fb919061582e565b60006040518083038185875af1925050503d8060008114613a38576040519150601f19603f3d011682016040523d82523d6000602084013e613a3d565b606091505b5091509150613a4e8783838761431b565b979650505050505050565b6060807fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff60ff861601613af457865115613ab657868484604051602001613aa293929190615840565b604051602081830303815290604052613aed565b83838080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920191909152505050505b9650613bc3565b7ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe60ff861601613b8c57855115613b4e57858484604051602001613b3a93929190615840565b604051602081830303815290604052613b85565b83838080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920191909152505050505b9550613bc3565b6040517f6780cfaf00000000000000000000000000000000000000000000000000000000815260ff86166004820152602401610ac9565b509495939450505050565b60607fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff61ffff851601613cf45760228214613c35576040517f0dc652a800000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6000613c56613c4860226002868861566e565b613c5191615868565b6143bb565b6040517f0100000000000000000000000000000000000000000000000000000000000000602082018190527e11000000000000000000000000000000000000000000000000000000000000602183015260238201527fffffffffffffffffffffffffffffffff00000000000000000000000000000000608083901b16602482015290915060340160405160208183030381529060405291505061141a565b7ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe61ffff851601613e1557604282111580613d2f5750606282115b15613d66576040517fc0927c5600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6000613d79613c4860226002868861566e565b90506000613d8e613c4860426022878961566e565b905060007fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffbe8501613dc2866042818a61566e565b613dcb91615868565b60405160086020938403029190911c9250613dfc916001916011918391889183916031916002918b918b91016158a4565b604051602081830303815290604052935050505061141a565b6040517f4170513000000000000000000000000000000000000000000000000000000000815261ffff85166004820152602401610ac9565b600080805b8351821015613f2e576001909101906000613e6d8584613ff2565b905060028301925060028161ffff161015613eb7576040517f04eb6e0c00000000000000000000000000000000000000000000000000000000815260048101849052602401610ac9565b6000613ec38685613f72565b90508060ff1660ff03613f02576040517fd3d3d9bc00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b600160ff82161b8316613f1f5760019485019460ff82161b831792505b5061ffff169190910190613e52565b83518214613f6b576040517f04eb6e0c00000000000000000000000000000000000000000000000000000000815260048101839052602401610ac9565b5050919050565b6000613f7f826001615203565b83511015613fe9576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601360248201527f746f55696e74385f6f75744f66426f756e6473000000000000000000000000006044820152606401610ac9565b50016001015190565b6000613fff826002615203565b83511015614069576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601460248201527f746f55696e7431365f6f75744f66426f756e64730000000000000000000000006044820152606401610ac9565b50016002015190565b60608161408081601f615203565b10156140e8576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152600e60248201527f736c6963655f6f766572666c6f770000000000000000000000000000000000006044820152606401610ac9565b6140f28284615203565b8451101561415c576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601160248201527f736c6963655f6f75744f66426f756e64730000000000000000000000000000006044820152606401610ac9565b60608215801561417b57604051915060008252602082016040526141e3565b6040519150601f8416801560200281840101858101878315602002848b0101015b818310156141b457805183526020928301920161419c565b5050858452601f017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe016604052505b50949350505050565b8160ff1660ff03614229576040517fd3d3d9bc00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b600061423683600161574c565b905060005b8451811015611e6757600085828151811061425857614258614b4e565b602002602001015190508060ff168360ff16036142cd5786828151811061428157614281614b4e565b60200260200101518460405160200161429b9291906155e1565b6040516020818303038152906040528783815181106142bc576142bc614b4e565b602002602001018190525050611e67565b8060ff1660000361431257828683815181106142eb576142eb614b4e565b602002602001019060ff16908160ff1681525050838783815181106142bc576142bc614b4e565b5060010161423b565b606083156143b15782516000036143aa5773ffffffffffffffffffffffffffffffffffffffff85163b6143aa576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601d60248201527f416464726573733a2063616c6c20746f206e6f6e2d636f6e74726163740000006044820152606401610ac9565b508161168f565b61168f8383614461565b60006fffffffffffffffffffffffffffffffff82111561445d576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602760248201527f53616665436173743a2076616c756520646f65736e27742066697420696e203160448201527f32382062697473000000000000000000000000000000000000000000000000006064820152608401610ac9565b5090565b8151156144715781518083602001fd5b806040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610ac99190614a30565b82805482825590600052602060002090810192821561451f579160200282015b8281111561451f57825182547fffffffffffffffffffffffff00000000000000000000000000000000000000001673ffffffffffffffffffffffffffffffffffffffff9091161782556020909201916001909101906144c5565b5061445d9291505b8082111561445d5760008155600101614527565b60006020828403121561454d57600080fd5b81357fffffffff000000000000000000000000000000000000000000000000000000008116811461141a57600080fd5b73ffffffffffffffffffffffffffffffffffffffff811681146116a857600080fd5b80356145aa8161457d565b919050565b63ffffffff811681146116a857600080fd5b80356145aa816145af565b600080604083850312156145df57600080fd5b82356145ea8161457d565b915060208301356145fa816145af565b809150509250929050565b815163ffffffff16815260208083015173ffffffffffffffffffffffffffffffffffffffff16908201526040810161066d565b6020810160038310614673577f4e487b7100000000000000000000000000000000000000000000000000000000600052602160045260246000fd5b91905290565b60008060006060848603121561468e57600080fd5b83356146998161457d565b925060208401356146a98161457d565b929592945050506040919091013590565b60008083601f8401126146cc57600080fd5b50813567ffffffffffffffff8111156146e457600080fd5b6020830191508360208260051b85010111156124f257600080fd5b60008060006040848603121561471457600080fd5b833561471f8161457d565b9250602084013567ffffffffffffffff81111561473b57600080fd5b614747868287016146ba565b9497909650939450505050565b6000806020838503121561476757600080fd5b823567ffffffffffffffff81111561477e57600080fd5b61478a858286016146ba565b90969095509350505050565b60008151808452602080850194506020840160005b838110156147dd57815173ffffffffffffffffffffffffffffffffffffffff16875295820195908201906001016147ab565b509495945050505050565b67ffffffffffffffff815116825260ff602082015116602083015260ff604082015116604083015260ff60608201511660608301526000608082015160c0608085015261483860c0850182614796565b905060a083015184820360a08601526148518282614796565b95945050505050565b60208152600061141a60208301846147e8565b80151581146116a857600080fd5b80356145aa8161486d565b6000806000806060858703121561489c57600080fd5b843567ffffffffffffffff808211156148b457600080fd5b9086019060e082890312156148c857600080fd5b909450602086013590808211156148de57600080fd5b818701915087601f8301126148f257600080fd5b81358181111561490157600080fd5b88602082850101111561491357600080fd5b60208301955080945050505061492b6040860161487b565b905092959194509250565b60005b83811015614951578181015183820152602001614939565b50506000910152565b60008151808452614972816020860160208601614936565b601f017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0169290920160200192915050565b825181526020808401519082015260606040820152600061168f606083018461495a565b6000602082840312156149da57600080fd5b813561141a816145af565b6000806000606084860312156149fa57600080fd5b8335614a05816145af565b92506020840135614a158161457d565b91506040840135614a25816145af565b809150509250925092565b60208152600061141a602083018461495a565b60008060208385031215614a5657600080fd5b823567ffffffffffffffff80821115614a6e57600080fd5b818501915085601f830112614a8257600080fd5b813581811115614a9157600080fd5b866020606083028501011115614aa657600080fd5b60209290920196919550909350505050565b600060208284031215614aca57600080fd5b5035919050565b81518152602080830151908201526040810161066d565b600060208284031215614afa57600080fd5b813561141a8161457d565b60008060408385031215614b1857600080fd5b8235614b238161457d565b946020939093013593505050565b600060208284031215614b4357600080fd5b815161141a8161457d565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052603260045260246000fd5b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa1833603018112614bb157600080fd5b9190910192915050565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe1843603018112614bf057600080fd5b83018035915067ffffffffffffffff821115614c0b57600080fd5b6020019150368190038213156124f257600080fd5b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b60405160c0810167ffffffffffffffff81118282101715614c7257614c72614c20565b60405290565b60405160e0810167ffffffffffffffff81118282101715614c7257614c72614c20565b604051601f82017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe016810167ffffffffffffffff81118282101715614ce257614ce2614c20565b604052919050565b600060408284031215614cfc57600080fd5b6040516040810181811067ffffffffffffffff82111715614d1f57614d1f614c20565b6040528235614d2d816145af565b81526020830135614d3d8161457d565b60208201529392505050565b803567ffffffffffffffff811681146145aa57600080fd5b803560ff811681146145aa57600080fd5b600082601f830112614d8357600080fd5b8135602067ffffffffffffffff821115614d9f57614d9f614c20565b8160051b614dae828201614c9b565b9283528481018201928281019087851115614dc857600080fd5b83870192505b84831015613a4e578235614de18161457d565b82529183019190830190614dce565b600060c08284031215614e0257600080fd5b614e0a614c4f565b9050614e1582614d49565b8152614e2360208301614d61565b6020820152614e3460408301614d61565b6040820152614e4560608301614d61565b6060820152608082013567ffffffffffffffff80821115614e6557600080fd5b614e7185838601614d72565b608084015260a0840135915080821115614e8a57600080fd5b50614e9784828501614d72565b60a08301525092915050565b600060208284031215614eb557600080fd5b813567ffffffffffffffff811115614ecc57600080fd5b61168f84828501614df0565b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc1833603018112614bb157600080fd5b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff41833603018112614bb157600080fd5b600060208284031215614f5257600080fd5b61141a82614d61565b600060208284031215614f6d57600080fd5b61141a82614d49565b600061066d3683614df0565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe1843603018112614fb757600080fd5b830160208101925035905067ffffffffffffffff811115614fd757600080fd5b8060051b36038213156124f257600080fd5b8183526000602080850194508260005b858110156147dd57813561500c8161457d565b73ffffffffffffffffffffffffffffffffffffffff1687529582019590820190600101614ff9565b60208082528181018390526000906040808401600586901b8501820187855b888110156151c6577fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc08089850301855282357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc18c36030181126150b557600080fd5b8b0180356150c2816145af565b63ffffffff16855280880135368290037fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff410181126150ff57600080fd5b8589018890520167ffffffffffffffff61511882614d49565b1687860152615128888201614d61565b606060ff8083168289015261513e8a8501614d61565b92506080818416818a0152615154838601614d61565b935060a09250818416838a015261516d81860186614f82565b60c08b81015294509150615188905061010089018483614fe9565b92505061519781840184614f82565b93509050838783030160e08801526151b0828483614fe9565b978a019796505050928701925050600101615053565b509098975050505050505050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b8082018082111561066d5761066d6151d4565b8135615221816145af565b63ffffffff811690508154817fffffffffffffffffffffffffffffffffffffffffffffffffffffffff00000000821617835560208401356152618161457d565b77ffffffffffffffffffffffffffffffffffffffff000000008160201b16837fffffffffffffffff0000000000000000000000000000000000000000000000008416171784555050505050565b6020808252818101839052600090604080840186845b8781101561532e5781356152d7816145af565b63ffffffff908116845282860135906152ef826145af565b1683860152818401356153018161457d565b73ffffffffffffffffffffffffffffffffffffffff168385015260609283019291909101906001016152c4565b5090979650505050505050565b73ffffffffffffffffffffffffffffffffffffffff8416815263ffffffff831660208201526080810161168f6040830184805163ffffffff16825260209081015173ffffffffffffffffffffffffffffffffffffffff16910152565b73ffffffffffffffffffffffffffffffffffffffff8416815263ffffffff8316602082015260606040820152600061485160608301846147e8565b60ff828116828216039081111561066d5761066d6151d4565b600060ff831680615425577f4e487b7100000000000000000000000000000000000000000000000000000000600052601260045260246000fd5b8060ff84160491505092915050565b63ffffffff8516815273ffffffffffffffffffffffffffffffffffffffff84166020820152826040820152608060608201526000615475608083018461495a565b9695505050505050565b60006020828403121561549157600080fd5b5051919050565b600082601f8301126154a957600080fd5b813567ffffffffffffffff8111156154c3576154c3614c20565b6154f460207fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0601f84011601614c9b565b81815284602083860101111561550957600080fd5b816020850160208301376000918101602001919091529392505050565b600060e0823603121561553857600080fd5b615540614c78565b61554983614d49565b8152615557602084016145c1565b60208201526155686040840161459f565b6040820152615579606084016145c1565b60608201526080830135608082015260a083013560a082015260c083013567ffffffffffffffff8111156155ac57600080fd5b6155b836828601615498565b60c08301525092915050565b6000602082840312156155d657600080fd5b815161141a8161486d565b600083516155f3818460208801614936565b835190830190615607818360208801614936565b01949350505050565b6060815260006156236060830186614796565b602083820360208501526156378287614796565b84810360408601528551808252602080880194509091019060005b818110156151c657845183529383019391830191600101615652565b6000808585111561567e57600080fd5b8386111561568b57600080fd5b5050820193919092039150565b7fffff00000000000000000000000000000000000000000000000000000000000081358181169160028510156156d85780818660020360031b1b83161692505b505092915050565b7fff0000000000000000000000000000000000000000000000000000000000000081358181169160018510156156d85760019490940360031b84901b1690921692915050565b8281526000825161573e816020850160208701614936565b919091016020019392505050565b60ff818116838216019081111561066d5761066d6151d4565b6040815263ffffffff83511660408201526000602084015160a0606084015261579160e084018261495a565b90506040850151608084015267ffffffffffffffff60608601511660a084015273ffffffffffffffffffffffffffffffffffffffff60808601511660c08401528281036020840152614851818561495a565b63ffffffff8516815267ffffffffffffffff8416602082015273ffffffffffffffffffffffffffffffffffffffff83166040820152608060608201526000615475608083018461495a565b60008251614bb1818460208701614936565b60008451615852818460208901614936565b8201838582376000930192835250909392505050565b8035602083101561066d577fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff602084900360031b1b1692915050565b60007fff00000000000000000000000000000000000000000000000000000000000000808c60f81b1683527fffff000000000000000000000000000000000000000000000000000000000000808c60f01b166001850152818b60f81b1660038501527fffffffffffffffffffffffffffffffff000000000000000000000000000000008a60801b166004850152818960f81b166014850152808860f01b16601585015250808660f81b16601784015250615985601883018560801b7fffffffffffffffffffffffffffffffff00000000000000000000000000000000169052565b5060288101919091526048019897505050505050505056fea2646970667358221220841ae22f8575fab1ed29ade9f317bee38a367043c3c362cf75f35a1a1b2ab5fd64736f6c63430008160033"
  },
  {
    method: "eth_getCode",
    params: [
      "0xb217266c3a98c8b2709ee26836c98cf12f6ccec1",
      "0x80f2a08"
    ],
    result: "0x608060405234801561001057600080fd5b506004361061011b5760003560e01c806343ea4fa9116100b25780638da5cb5b11610081578063c40ff83511610066578063c40ff835146102c0578063e084d952146102d3578063f2fde38b146102e657600080fd5b80638da5cb5b146102785780639c33abf7146102a057600080fd5b806343ea4fa91461022a57806354fd4d501461023d5780636750cd4c1461025d578063715018a61461027057600080fd5b806320efd722116100ee57806320efd7221461017f57806329460b0b1461019257806339e3f938146101a55780633c782a52146101c557600080fd5b806301ffc9a7146101205780630223536e146101485780630894edf11461015d5780631881d94d14610170575b600080fd5b61013361012e366004611cc0565b6102f9565b60405190151581526020015b60405180910390f35b61015b610156366004611d68565b610355565b005b61015b61016b366004611dc5565b610367565b600160405161013f9190611e11565b61015b61018d366004611ebb565b6104f9565b61015b6101a0366004611f0e565b61065a565b6101b86101b3366004611f64565b61083f565b60405161013f919061205b565b61020a6101d336600461206e565b600260209081526000938452604080852082529284528284209052825290205460ff811690610100900467ffffffffffffffff1682565b60408051921515835267ffffffffffffffff90911660208301520161013f565b6101b8610238366004611f64565b6109e0565b60408051600381526000602082015260029181019190915260600161013f565b61013361026b3660046120a3565b610d9a565b61015b610da5565b60005460405173ffffffffffffffffffffffffffffffffffffffff909116815260200161013f565b6102b36102ae3660046120be565b610db9565b60405161013f91906120f8565b61015b6102ce366004612165565b610e59565b6101336102e136600461238f565b610e69565b61015b6102f43660046123dd565b610e7e565b60007fffffffff0000000000000000000000000000000000000000000000000000000082167f0ab7be9f00000000000000000000000000000000000000000000000000000000148061034f575061034f82610f35565b92915050565b61036184848484610fcc565b50505050565b61039283837f00000000000000000000000000000000000000000000000000000000000075966110e0565b600061039e84846111ae565b905060006103ac85856111c0565b905060006103ba83836109e0565b90506103de8187876040516103d09291906123f8565b6040518091039020866111e3565b600060405180606001604052808463ffffffff1681526020016104018989611392565b815260200161041089896113ab565b67ffffffffffffffff908116909152604080517fa825d747000000000000000000000000000000000000000000000000000000008152835163ffffffff1660048201526020840151602482015290830151909116604482015273ffffffffffffffffffffffffffffffffffffffff8681166064830152608482018890529192507f0000000000000000000000001a44076050125825900e736c501f859c50fe728c9091169063a825d7479060a401600060405180830381600087803b1580156104d857600080fd5b505af11580156104ec573d6000803e3d6000fd5b5050505050505050505050565b7f0000000000000000000000001a44076050125825900e736c501f859c50fe728c73ffffffffffffffffffffffffffffffffffffffff163314610568576040517f467409c300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60005b81811015610361573683838381811061058657610586612408565b90506020028101906105989190612437565b90506105af6105aa60208301836120a3565b6113ce565b60026105c160408301602084016120a3565b63ffffffff1603610601576105fc6105dc60208301836120a3565b866105ea6040850185612475565b8101906105f791906124da565b611415565b610651565b61061160408201602083016120a3565b6040517fba97c1fa00000000000000000000000000000000000000000000000000000000815263ffffffff90911660048201526024015b60405180910390fd5b5060010161056b565b61066261146b565b60005b81811015610801573683838381811061068057610680612408565b9050602002810190610692919061250f565b905060ff6106a36020830183612543565b6106b4906040810190602001612577565b60ff16036106ee576040517f83aa17da00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60ff6106fd6020830183612543565b61070e906060810190604001612577565b60ff1603610748576040517f4221136600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b67ffffffffffffffff61075e6020830183612543565b61076c906020810190612592565b67ffffffffffffffff16036107ad576040517f503667ae00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6107cb6107bd6020830183612543565b6107c6906125ad565b6114ec565b6107f860006107dd60208401846120a3565b6107ea6020850185612543565b6107f3906125ad565b61153d565b50600101610665565b507faaf3aaa0c11056e86ac56eb653e25b005ca1a7d4dcd21ba24647f7ab63f3b5608282604051610833929190612669565b60405180910390a15050565b6040805160c0810182526000808252602082018190529181018290526060808201929092526080810182905260a081019190915273ffffffffffffffffffffffffffffffffffffffff8316600090815260016020818152604080842063ffffffff87168552825292839020835160c081018552815467ffffffffffffffff8116825260ff680100000000000000008204811683860152690100000000000000000082048116838801526a0100000000000000000000909104166060820152928101805485518185028101850190965280865293949193608086019383018282801561096057602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff168152600190910190602001808311610935575b50505050508152602001600282018054806020026020016040519081016040528092919081815260200182805480156109cf57602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff1681526001909101906020018083116109a4575b505050505081525050905092915050565b6040805160c0810182526000808252602080830182905282840182905260608084018390526080840181905260a084015263ffffffff85168083527fa6eef7e35abe7026729641147f7915573c7e97b47efa546f5f6e3230263bcb49825284832073ffffffffffffffffffffffffffffffffffffffff88168452600183528584209184529152929020805491929167ffffffffffffffff1680610a9057825467ffffffffffffffff168452610aaf565b67ffffffffffffffff81811614610aaf5767ffffffffffffffff811684525b815468010000000000000000900460ff16610b6557825468010000000000000000900460ff1615610b605782600101805480602002602001604051908101604052809291908181526020018280548015610b3f57602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff168152600190910190602001808311610b14575b50505050506080850152825468010000000000000000900460ff1660208501525b610c03565b815468010000000000000000900460ff90811614610c035781600101805480602002602001604051908101604052809291908181526020018280548015610be257602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff168152600190910190602001808311610bb7575b50505050506080850152815468010000000000000000900460ff1660208501525b81546901000000000000000000900460ff16610cd25782546901000000000000000000900460ff1615610ccd5782600201805480602002602001604051908101604052809291908181526020018280548015610c9557602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff168152600190910190602001808311610c6a575b505050505060a0850152825460ff69010000000000000000008204811660408701526a01000000000000000000009091041660608501525b610d88565b81546901000000000000000000900460ff90811614610d885781600201805480602002602001604051908101604052809291908181526020018280548015610d5057602002820191906000526020600020905b815473ffffffffffffffffffffffffffffffffffffffff168152600190910190602001808311610d25575b505050505060a0850152815460ff69010000000000000000008204811660408701526a01000000000000000000009091041660608501525b610d91846114ec565b50505092915050565b600061034f826118d1565b610dad61146b565b610db76000611938565b565b60607ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe63ffffffff831601610e1857610df283856109e0565b604051602001610e02919061205b565b6040516020818303038152906040529050610e52565b6040517fba97c1fa00000000000000000000000000000000000000000000000000000000815263ffffffff83166004820152602401610648565b9392505050565b610e648383836110e0565b505050565b6000610e768484846119ad565b949350505050565b610e8661146b565b73ffffffffffffffffffffffffffffffffffffffff8116610f29576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602660248201527f4f776e61626c653a206e6577206f776e657220697320746865207a65726f206160448201527f64647265737300000000000000000000000000000000000000000000000000006064820152608401610648565b610f3281611938565b50565b60007fffffffff0000000000000000000000000000000000000000000000000000000082167f97f0258400000000000000000000000000000000000000000000000000000000148061034f57507f01ffc9a7000000000000000000000000000000000000000000000000000000007fffffffff0000000000000000000000000000000000000000000000000000000083161461034f565b6040805180820182526001815267ffffffffffffffff831660208201529051600290600090610ffe90889088906123f8565b6040805191829003909120825260208083019390935290810160009081208682528352818120338083529084529082902084518154959094015167ffffffffffffffff16610100027fffffffffffffffffffffffffffffffffffffffffffffff0000000000000000ff941515949094167fffffffffffffffffffffffffffffffffffffffffffffff000000000000000000909516949094179290921790925590517f2cb0eed7538baeae4c6fde038c0fd0384d27de0dd55a228c65847bda6aa1ab56916110d2918790879086908890612806565b60405180910390a150505050565b6051821461111a576040517fc9bf37b700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60016111268484611ab6565b60ff1614611160576040517f3a9ae7b900000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b8063ffffffff166111718484611ad8565b63ffffffff1614610e64576040517f42d2c97e00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6000610e526111bd8484611ae8565b90565b60006111d0600d6009848661288b565b6111d9916128b5565b60e01c9392505050565b6111ee8383836119ad565b611224576040517f4c3118d400000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b602083015160ff16156112dc5760005b836020015160ff168160ff1610156112da57600083815260026020908152604080832085845290915281206080860151805191929160ff851690811061127c5761127c612408565b60209081029190910181015173ffffffffffffffffffffffffffffffffffffffff16825281019190915260400160002080547fffffffffffffffffffffffffffffffffffffffffffffff000000000000000000169055600101611234565b505b604083015160ff1615610e645760005b836040015160ff168160ff161015610361576000838152600260209081526040808320858452909152812060a0860151805191929160ff851690811061133457611334612408565b60209081029190910181015173ffffffffffffffffffffffffffffffffffffffff16825281019190915260400160002080547fffffffffffffffffffffffffffffffffffffffffffffff0000000000000000001690556001016112ec565b60006113a2602d600d848661288b565b610e52916128fd565b60006113bb60096001848661288b565b6113c491612939565b60c01c9392505050565b6113d7816118d1565b610f32576040517ff0c10d0400000000000000000000000000000000000000000000000000000000815263ffffffff82166004820152602401610648565b61142082848361153d565b61142a82846109e0565b507f82118522aa536ac0e96cc5c689407ae42b89d592aa133890a01f1509842f508182848360405161145e9392919061297f565b60405180910390a1505050565b60005473ffffffffffffffffffffffffffffffffffffffff163314610db7576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820181905260248201527f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e65726044820152606401610648565b602081015160ff161580156115065750606081015160ff16155b15610f32576040517fce2c375100000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b602081015160ff90811614806115585750602081015160ff16155b1561159f576080810151511561159a576040517f83aa17da00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b61161e565b806020015160ff168160800151511415806115da575060026115c3600160ff6129e9565b6115cd9190612a02565b60ff16816020015160ff16115b15611611576040517f83aa17da00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b61161e8160800151611af8565b604081015160ff90811614806116395750604081015160ff16155b156116bf5760a0810151511561167b576040517f4221136600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b606081015160ff16156116ba576040517f38682fa900000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b611796565b806040015160ff168160a00151511415806116fa575060026116e3600160ff6129e9565b6116ed9190612a02565b60ff16816040015160ff16115b15611731576040517f4221136600000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b606081015160ff1615806117525750806040015160ff16816060015160ff16115b15611789576040517f38682fa900000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6117968160a00151611af8565b73ffffffffffffffffffffffffffffffffffffffff8316600090815260016020818152604080842063ffffffff87168552825292839020845181548684015195870151606088015167ffffffffffffffff9093167fffffffffffffffffffffffffffffffffffffffffffffff000000000000000000909216919091176801000000000000000060ff97881602177fffffffffffffffffffffffffffffffffffffffffff0000ffffffffffffffffff166901000000000000000000918716919091027fffffffffffffffffffffffffffffffffffffffffff00ffffffffffffffffffff16176a01000000000000000000009590911694909402939093178355608084015180518594936118ad93908501920190611c21565b5060a082015180516118c9916002840191602090910190611c21565b505050505050565b63ffffffff811660009081527fa6eef7e35abe7026729641147f7915573c7e97b47efa546f5f6e3230263bcb4960205260408120805468010000000000000000900460ff16151580610e525750546a0100000000000000000000900460ff16151592915050565b6000805473ffffffffffffffffffffffffffffffffffffffff8381167fffffffffffffffffffffffff0000000000000000000000000000000000000000831681178455604051919092169283917f8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e09190a35050565b602083015160009060ff1615611a305760005b846020015160ff168160ff161015611a1857611a0285608001518260ff16815181106119ee576119ee612408565b602002602001015185858860000151611b92565b611a10576000915050610e52565b6001016119c0565b50836040015160ff16600003611a3057506001610e52565b606084015160005b856040015160ff168160ff161015611aaa57611a7a8660a001518260ff1681518110611a6657611a66612408565b602002602001015186868960000151611b92565b15611aa25781611a8981612a4b565b9250508160ff16600003611aa257600192505050610e52565b600101611a38565b50600095945050505050565b6000611ac5600182848661288b565b611ace91612a86565b60f81c9392505050565b60006111d06031602d848661288b565b60006113a260516031848661288b565b6000805b8251811015610e64576000838281518110611b1957611b19612408565b602002602001015190508273ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff1611611b88576040517f447516e100000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b9150600101611afc565b6000838152600260209081526040808320858452825280832073ffffffffffffffffffffffffffffffffffffffff88168452825280832081518083019092525460ff811615801580845261010090920467ffffffffffffffff16938301939093529091611c1757508267ffffffffffffffff16816020015167ffffffffffffffff1610155b9695505050505050565b828054828255906000526020600020908101928215611c9b579160200282015b82811115611c9b57825182547fffffffffffffffffffffffff00000000000000000000000000000000000000001673ffffffffffffffffffffffffffffffffffffffff909116178255602090920191600190910190611c41565b50611ca7929150611cab565b5090565b5b80821115611ca75760008155600101611cac565b600060208284031215611cd257600080fd5b81357fffffffff0000000000000000000000000000000000000000000000000000000081168114610e5257600080fd5b60008083601f840112611d1457600080fd5b50813567ffffffffffffffff811115611d2c57600080fd5b602083019150836020828501011115611d4457600080fd5b9250929050565b803567ffffffffffffffff81168114611d6357600080fd5b919050565b60008060008060608587031215611d7e57600080fd5b843567ffffffffffffffff811115611d9557600080fd5b611da187828801611d02565b90955093505060208501359150611dba60408601611d4b565b905092959194509250565b600080600060408486031215611dda57600080fd5b833567ffffffffffffffff811115611df157600080fd5b611dfd86828701611d02565b909790965060209590950135949350505050565b6020810160038310611e4c577f4e487b7100000000000000000000000000000000000000000000000000000000600052602160045260246000fd5b91905290565b803573ffffffffffffffffffffffffffffffffffffffff81168114611d6357600080fd5b60008083601f840112611e8857600080fd5b50813567ffffffffffffffff811115611ea057600080fd5b6020830191508360208260051b8501011115611d4457600080fd5b600080600060408486031215611ed057600080fd5b611ed984611e52565b9250602084013567ffffffffffffffff811115611ef557600080fd5b611f0186828701611e76565b9497909650939450505050565b60008060208385031215611f2157600080fd5b823567ffffffffffffffff811115611f3857600080fd5b611f4485828601611e76565b90969095509350505050565b803563ffffffff81168114611d6357600080fd5b60008060408385031215611f7757600080fd5b611f8083611e52565b9150611f8e60208401611f50565b90509250929050565b60008151808452602080850194506020840160005b83811015611fde57815173ffffffffffffffffffffffffffffffffffffffff1687529582019590820190600101611fac565b509495945050505050565b67ffffffffffffffff815116825260ff602082015116602083015260ff604082015116604083015260ff60608201511660608301526000608082015160c0608085015261203960c0850182611f97565b905060a083015184820360a08601526120528282611f97565b95945050505050565b602081526000610e526020830184611fe9565b60008060006060848603121561208357600080fd5b833592506020840135915061209a60408501611e52565b90509250925092565b6000602082840312156120b557600080fd5b610e5282611f50565b6000806000606084860312156120d357600080fd5b6120dc84611f50565b92506120ea60208501611e52565b915061209a60408501611f50565b60006020808352835180602085015260005b818110156121265785810183015185820160400152820161210a565b5060006040828601015260407fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0601f8301168501019250505092915050565b60008060006040848603121561217a57600080fd5b833567ffffffffffffffff81111561219157600080fd5b61219d86828701611d02565b909450925061209a905060208501611f50565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b60405160c0810167ffffffffffffffff81118282101715612202576122026121b0565b60405290565b803560ff81168114611d6357600080fd5b600082601f83011261222a57600080fd5b8135602067ffffffffffffffff80831115612247576122476121b0565b8260051b6040517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0603f8301168101818110848211171561228a5761228a6121b0565b60405293845260208187018101949081019250878511156122aa57600080fd5b6020870191505b848210156122d1576122c282611e52565b835291830191908301906122b1565b979650505050505050565b600060c082840312156122ee57600080fd5b6122f66121df565b905061230182611d4b565b815261230f60208301612208565b602082015261232060408301612208565b604082015261233160608301612208565b6060820152608082013567ffffffffffffffff8082111561235157600080fd5b61235d85838601612219565b608084015260a084013591508082111561237657600080fd5b5061238384828501612219565b60a08301525092915050565b6000806000606084860312156123a457600080fd5b833567ffffffffffffffff8111156123bb57600080fd5b6123c7868287016122dc565b9660208601359650604090950135949350505050565b6000602082840312156123ef57600080fd5b610e5282611e52565b8183823760009101908152919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052603260045260246000fd5b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa183360301811261246b57600080fd5b9190910192915050565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe18436030181126124aa57600080fd5b83018035915067ffffffffffffffff8211156124c557600080fd5b602001915036819003821315611d4457600080fd5b6000602082840312156124ec57600080fd5b813567ffffffffffffffff81111561250357600080fd5b610e76848285016122dc565b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc183360301811261246b57600080fd5b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff4183360301811261246b57600080fd5b60006020828403121561258957600080fd5b610e5282612208565b6000602082840312156125a457600080fd5b610e5282611d4b565b600061034f36836122dc565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe18436030181126125ee57600080fd5b830160208101925035905067ffffffffffffffff81111561260e57600080fd5b8060051b3603821315611d4457600080fd5b8183526000602080850194508260005b85811015611fde5773ffffffffffffffffffffffffffffffffffffffff61265683611e52565b1687529582019590820190600101612630565b60208082528181018390526000906040808401600586901b8501820187855b888110156127f8577fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc08089850301855282357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc18c36030181126126ea57600080fd5b8b0163ffffffff6126fa82611f50565b168552878101357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff4182360301811261273157600080fd5b8589018890520167ffffffffffffffff61274a82611d4b565b168786015261275a888201612208565b606060ff808316828901526127708a8501612208565b92506080818416818a0152612786838601612208565b935060a09250818416838a015261279f818601866125b9565b60c08b810152945091506127ba905061010089018483612620565b9250506127c9818401846125b9565b93509050838783030160e08801526127e2828483612620565b978a019796505050928701925050600101612688565b509098975050505050505050565b73ffffffffffffffffffffffffffffffffffffffff8616815260806020820152836080820152838560a0830137600060a08583010152600060a07fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0601f870116830101905067ffffffffffffffff841660408301528260608301529695505050505050565b6000808585111561289b57600080fd5b838611156128a857600080fd5b5050820193919092039150565b7fffffffff0000000000000000000000000000000000000000000000000000000081358181169160048510156128f55780818660040360031b1b83161692505b505092915050565b8035602083101561034f577fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff602084900360031b1b1692915050565b7fffffffffffffffff00000000000000000000000000000000000000000000000081358181169160088510156128f55760089490940360031b84901b1690921692915050565b73ffffffffffffffffffffffffffffffffffffffff8416815263ffffffff831660208201526060604082015260006120526060830184611fe9565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b60ff828116828216039081111561034f5761034f6129ba565b600060ff831680612a3c577f4e487b7100000000000000000000000000000000000000000000000000000000600052601260045260246000fd5b8060ff84160491505092915050565b600060ff821680612a5e57612a5e6129ba565b7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0192915050565b7fff0000000000000000000000000000000000000000000000000000000000000081358181169160018510156128f55760019490940360031b84901b169092169291505056fea264697066735822122089779ddf355286c32eeb3fc47b72cbbd5c19a6abb67086e252341f8d077313bc64736f6c63430008160033"
  },
  {
    method: "eth_getCode",
    params: [
      "0x3ebd570ed38b1b3b4bc886999fcf507e9d584859",
      "0x80f2a08"
    ],
    result: "0x6080604052600436106100435760003560e01c80633659cfe61461005a5780634f1ef2861461007a5780635c60da1b1461008d578063f851a440146100cb57610052565b36610052576100506100e0565b005b6100506100e0565b34801561006657600080fd5b5061005061007536600461076c565b6100fa565b610050610088366004610787565b61015e565b34801561009957600080fd5b506100a26101ec565b60405173ffffffffffffffffffffffffffffffffffffffff909116815260200160405180910390f35b3480156100d757600080fd5b506100a2610244565b6100e86102f1565b6100f86100f36103e2565b610422565b565b3373ffffffffffffffffffffffffffffffffffffffff7f000000000000000000000000a3802e7599409e709edccf63fe5ea4a5a02a2d571614156101565761015381604051806020016040528060008152506000610446565b50565b6101536100e0565b3373ffffffffffffffffffffffffffffffffffffffff7f000000000000000000000000a3802e7599409e709edccf63fe5ea4a5a02a2d571614156101e4576101df8383838080601f01602080910402602001604051908101604052809392919081815260200183838082843760009201919091525060019250610446915050565b505050565b6101df6100e0565b60003373ffffffffffffffffffffffffffffffffffffffff7f000000000000000000000000a3802e7599409e709edccf63fe5ea4a5a02a2d57161415610239576102346103e2565b905090565b6102416100e0565b90565b60003373ffffffffffffffffffffffffffffffffffffffff7f000000000000000000000000a3802e7599409e709edccf63fe5ea4a5a02a2d5716141561023957507f000000000000000000000000a3802e7599409e709edccf63fe5ea4a5a02a2d5790565b60606102ce83836040518060600160405280602781526020016108a460279139610471565b9392505050565b73ffffffffffffffffffffffffffffffffffffffff163b151590565b3373ffffffffffffffffffffffffffffffffffffffff7f000000000000000000000000a3802e7599409e709edccf63fe5ea4a5a02a2d571614156100f8576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152604260248201527f5472616e73706172656e745570677261646561626c6550726f78793a2061646d60448201527f696e2063616e6e6f742066616c6c6261636b20746f2070726f7879207461726760648201527f6574000000000000000000000000000000000000000000000000000000000000608482015260a4015b60405180910390fd5b60006102347f360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc5473ffffffffffffffffffffffffffffffffffffffff1690565b3660008037600080366000845af43d6000803e808015610441573d6000f35b3d6000fd5b61044f83610599565b60008251118061045c5750805b156101df5761046b83836102a9565b50505050565b606073ffffffffffffffffffffffffffffffffffffffff84163b610517576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602660248201527f416464726573733a2064656c65676174652063616c6c20746f206e6f6e2d636f60448201527f6e7472616374000000000000000000000000000000000000000000000000000060648201526084016103d9565b6000808573ffffffffffffffffffffffffffffffffffffffff168560405161053f9190610836565b600060405180830381855af49150503d806000811461057a576040519150601f19603f3d011682016040523d82523d6000602084013e61057f565b606091505b509150915061058f8282866105e6565b9695505050505050565b6105a281610639565b60405173ffffffffffffffffffffffffffffffffffffffff8216907fbc7cd75a20ee27fd9adebab32041f755214dbc6bffa90cc0225b39da2e5c2d3b90600090a250565b606083156105f55750816102ce565b8251156106055782518084602001fd5b816040517f08c379a00000000000000000000000000000000000000000000000000000000081526004016103d99190610852565b73ffffffffffffffffffffffffffffffffffffffff81163b6106dd576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602d60248201527f455243313936373a206e657720696d706c656d656e746174696f6e206973206e60448201527f6f74206120636f6e74726163740000000000000000000000000000000000000060648201526084016103d9565b7f360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc80547fffffffffffffffffffffffff00000000000000000000000000000000000000001673ffffffffffffffffffffffffffffffffffffffff92909216919091179055565b803573ffffffffffffffffffffffffffffffffffffffff8116811461076757600080fd5b919050565b60006020828403121561077e57600080fd5b6102ce82610743565b60008060006040848603121561079c57600080fd5b6107a584610743565b9250602084013567ffffffffffffffff808211156107c257600080fd5b818601915086601f8301126107d657600080fd5b8135818111156107e557600080fd5b8760208285010111156107f757600080fd5b6020830194508093505050509250925092565b60005b8381101561082557818101518382015260200161080d565b8381111561046b5750506000910152565b6000825161084881846020870161080a565b9190910192915050565b602081526000825180602084015261087181604085016020870161080a565b601f017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe016919091016040019291505056fe416464726573733a206c6f772d6c6576656c2064656c65676174652063616c6c206661696c6564a26469706673582212206f70214c51cdd41c05ba0ffeb72b309ca3c8be178fd6e73c12162330799984f364736f6c634300080a0033"
  },
  {
    method: "eth_getCode",
    params: [
      "0x247624e2143504730aec22912ed41f092498bef2",
      "0x80f2a08"
    ],
    result: "0x60806040526004361061029f5760003560e01c80638585c9451161016e578063c7a823e0116100cb578063d547741f1161007f578063f010cb2311610064578063f010cb2314610906578063f3b4ebd014610926578063fd62e7501461094657600080fd5b8063d547741f146108c6578063dafe0ccc146108e657600080fd5b8063cd88b903116100b0578063cd88b90314610823578063cf34c76814610843578063d2ae21041461088c57600080fd5b8063c7a823e0146107d5578063c7b2370b1461080357600080fd5b8063aef18bf711610122578063c358de0a11610107578063c358de0a14610763578063c416aa5114610783578063c5e193cd146107b557600080fd5b8063aef18bf714610713578063b143044b1461074357600080fd5b806395d376d71161015357806395d376d7146106465780639e94496514610659578063a217fddf146106fe57600080fd5b80638585c945146105d557806391d14854146105f557600080fd5b80632f2ff15d1161021c5780635553fb8e116101d0578063724e78da116101b5578063724e78da14610533578063736c0d5b14610553578063741bef1a1461058357600080fd5b80635553fb8e146104fb5780635c975abb1461051b57600080fd5b806331cb61051161020157806331cb61051461049b57806336568abe146104bb57806352d3b871146104db57600080fd5b80632f2ff15d1461045b57806330bb3aac1461047b57600080fd5b806316c38b3c11610273578063248a9ca311610258578063248a9ca3146103d057806326e67a371461040e5780632de113761461043b57600080fd5b806316c38b3c1461036a5780631703a0181461038a57600080fd5b8062bf2e80146102a457806301e33667146102f857806301ffc9a71461031a5780631095b6d71461034a575b600080fd5b3480156102b057600080fd5b506001546102e0907d010000000000000000000000000000000000000000000000000000000000900461ffff1681565b60405161ffff90911681526020015b60405180910390f35b34801561030457600080fd5b50610318610313366004613732565b610967565b005b34801561032657600080fd5b5061033a610335366004613773565b6109a2565b60405190151581526020016102ef565b34801561035657600080fd5b50610318610365366004613732565b610a3b565b34801561037657600080fd5b506103186103853660046137c3565b610bcb565b34801561039657600080fd5b506005546103b79068010000000000000000900467ffffffffffffffff1681565b60405167ffffffffffffffff90911681526020016102ef565b3480156103dc57600080fd5b506104006103eb3660046137e0565b60009081526020819052604090206001015490565b6040519081526020016102ef565b34801561041a57600080fd5b5061042e61042936600461380d565b610bf0565b6040516102ef9190613828565b34801561044757600080fd5b5061033a61045636600461386f565b610c77565b34801561046757600080fd5b5061031861047636600461388c565b610d5c565b34801561048757600080fd5b50610400610496366004613916565b610eb0565b3480156104a757600080fd5b506103186104b636600461398e565b611027565b3480156104c757600080fd5b506103186104d636600461388c565b61106a565b3480156104e757600080fd5b506103186104f63660046139bc565b61109c565b34801561050757600080fd5b50610400610516366004613a43565b611268565b34801561052757600080fd5b5060015460ff1661033a565b34801561053f57600080fd5b5061031861054e36600461386f565b6113df565b34801561055f57600080fd5b5061033a61056e36600461386f565b60046020526000908152604090205460ff1681565b34801561058f57600080fd5b506002546105b09073ffffffffffffffffffffffffffffffffffffffff1681565b60405173ffffffffffffffffffffffffffffffffffffffff90911681526020016102ef565b3480156105e157600080fd5b506103186105f0366004613a99565b611484565b34801561060157600080fd5b5061033a61061036600461388c565b60009182526020828152604080842073ffffffffffffffffffffffffffffffffffffffff93909316845291905290205460ff1690565b610400610654366004613acc565b6114c9565b34801561066557600080fd5b506106c361067436600461380d565b60066020526000908152604090205467ffffffffffffffff81169068010000000000000000810461ffff16906a010000000000000000000090046fffffffffffffffffffffffffffffffff1683565b6040805167ffffffffffffffff909416845261ffff90921660208401526fffffffffffffffffffffffffffffffff16908201526060016102ef565b34801561070a57600080fd5b50610400600081565b34801561071f57600080fd5b5061033a61072e3660046137e0565b60076020526000908152604090205460ff1681565b34801561074f57600080fd5b5061031861075e366004613b7a565b6116a5565b34801561076f57600080fd5b5061031861077e366004613bbc565b6119b5565b34801561078f57600080fd5b506001546105b090610100900473ffffffffffffffffffffffffffffffffffffffff1681565b3480156107c157600080fd5b506104006107d0366004613a43565b611a63565b3480156107e157600080fd5b506107f56107f0366004613bd7565b611c41565b6040516102ef929190613c45565b34801561080f57600080fd5b5061031861081e36600461386f565b611e51565b34801561082f57600080fd5b5061031861083e366004613c92565b611ef5565b34801561084f57600080fd5b506108777f000000000000000000000000000000000000000000000000000000000000006681565b60405163ffffffff90911681526020016102ef565b34801561089857600080fd5b506001546103b7907501000000000000000000000000000000000000000000900467ffffffffffffffff1681565b3480156108d257600080fd5b506103186108e136600461388c565b611f46565b3480156108f257600080fd5b50610318610901366004613732565b61205b565b34801561091257600080fd5b50610400610921366004613cd8565b612191565b34801561093257600080fd5b50610318610941366004613d43565b6121cd565b34801561095257600080fd5b506005546103b79067ffffffffffffffff1681565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c2177561099181612442565b61099c84848461244c565b50505050565b60007fffffffff0000000000000000000000000000000000000000000000000000000082167f7965db0b000000000000000000000000000000000000000000000000000000001480610a3557507f01ffc9a7000000000000000000000000000000000000000000000000000000007fffffffff000000000000000000000000000000000000000000000000000000008316145b92915050565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775610a6581612442565b73ffffffffffffffffffffffffffffffffffffffff841660009081527f9b50f4667d2d24216ccbf0dce3a90c0f620fa4d895e7b069d80ff6247fd25620602052604090205460ff16610ae3576040517f5ee08b9700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040517ffd9be52200000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff84811660048301526024820184905285169063fd9be52290604401600060405180830381600087803b158015610b5357600080fd5b505af1158015610b67573d6000803e3d6000fd5b50506040805173ffffffffffffffffffffffffffffffffffffffff8089168252871660208201529081018590527f9b1bfa7fa9ee420a16e124f794c35ac9f90472acc99140eb2f6447c714cad8eb925060600190505b60405180910390a150505050565b6000610bd681612442565b8115610be857610be461247c565b5050565b610be46124fb565b63ffffffff8116600090815260036020908152604091829020805483518184028101840190945280845260609392830182828015610c6b57602002820191906000526020600020906000905b825461010083900a900460ff16815260206001928301818104948501949093039092029101808411610c3c5790505b50505050509050919050565b73ffffffffffffffffffffffffffffffffffffffff811660009081527f93c430521711328044ae92d0f1f1286cf040bc4a382f1642bd89984e86630553602052604081205460ff1615610ccc57506000919050565b6001547501000000000000000000000000000000000000000000900467ffffffffffffffff161580610d42575073ffffffffffffffffffffffffffffffffffffffff821660009081527f4ac82e3087b7dedf7f532cbc6915c722df8c1e31f1388c318a617b52760eaf8b602052604090205460ff165b15610d4f57506001919050565b506000919050565b919050565b817f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca811480610daa57507f4270fae16c6d150d00e80b689daca99e8073b1838ff2b6063a37be9d851283e481145b80610dd457507f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de81145b15610e1757303314610e12576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610ea1565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217758103610e6757610e127fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775612442565b6040517f94fdc372000000000000000000000000000000000000000000000000000000008152600481018290526024015b60405180910390fd5b610eab8383612552565b505050565b600083610ebc81610c77565b610ef2576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c08101825260025473ffffffffffffffffffffffffffffffffffffffff908116825263ffffffff8a16602080840182905267ffffffffffffffff808c16858701528a8416606086015260055468010000000000000000900416608085015260015461ffff7d01000000000000000000000000000000000000000000000000000000000082041660a0860152600092835260069091529084902093517f7bfa20a9000000000000000000000000000000000000000000000000000000008152929361010090910490911691637bfa20a991610fda918591908a908a90600401613dc1565b602060405180830381865afa158015610ff7573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061101b9190613e8e565b98975050505050505050565b303314611060576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610be48282612618565b6040517fdec9f03100000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217756110c681612442565b60005b8281101561122957368484838181106110e4576110e4613ea7565b9050608002019050604051806060016040528082602001602081019061110a9190613a99565b67ffffffffffffffff1681526020016111296060840160408501613bbc565b61ffff1681526020016111426080840160608501613ef6565b6fffffffffffffffffffffffffffffffff16905260066000611167602085018561380d565b63ffffffff1681526020808201929092526040908101600020835181549385015194909201516fffffffffffffffffffffffffffffffff166a0100000000000000000000027fffffffffffff00000000000000000000000000000000ffffffffffffffffffff61ffff90951668010000000000000000027fffffffffffffffffffffffffffffffffffffffffffff0000000000000000000090941667ffffffffffffffff909316929092179290921792909216919091179055506001016110c9565b507f7dd21e42791b013d1929e86f0c59085e4fca24251f0f1aa81917b3b1611766e0838360405161125b929190613f11565b60405180910390a1505050565b60008161127481610c77565b6112aa576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c08101825260025473ffffffffffffffffffffffffffffffffffffffff908116825261ffff808a16602080850182905267ffffffffffffffff808b168688015289851660608701526005546801000000000000000090041660808601526001547d010000000000000000000000000000000000000000000000000000000000810490931660a08601526000918252600681528582208651918201875291815294517f7bfa20a9000000000000000000000000000000000000000000000000000000008152939461010090920490921692637bfa20a99261139392869260040161401d565b602060405180830381865afa1580156113b0573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906113d49190613e8e565b979650505050505050565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c2177561140981612442565b600280547fffffffffffffffffffffffff00000000000000000000000000000000000000001673ffffffffffffffffffffffffffffffffffffffff84169081179091556040519081527ff724a45d041687842411f2b977ef22ab8f43c8f1104f4592b42a00f9b34a643d906020015b60405180910390a15050565b3033146114bd576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6114c681612818565b50565b60007f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de6114f581612442565b61150560a086016080870161386f565b61150e81610c77565b611544576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c0810190915260025473ffffffffffffffffffffffffffffffffffffffff16815260009060208082019061157f908a018a61380d565b63ffffffff16815260200161159a60808a0160608b01613a99565b67ffffffffffffffff1681526020016115b960a08a0160808b0161386f565b73ffffffffffffffffffffffffffffffffffffffff908116825260055468010000000000000000900467ffffffffffffffff166020808401919091526001547d010000000000000000000000000000000000000000000000000000000000810461ffff16604090940193909352929350610100909104169063df2b057e90839060069060009061164b908d018d61380d565b63ffffffff1663ffffffff16815260200190815260200160002089896040518563ffffffff1660e01b81526004016116869493929190613dc1565b6020604051808303816000875af11580156113b0573d6000803e3d6000fd5b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217756116cf81612442565b60005b8281101561099c57368484838181106116ed576116ed613ea7565b90506020028101906116ff91906140f3565b905063ffffffff7f000000000000000000000000000000000000000000000000000000000000006616611735602083018361380d565b63ffffffff161461174657506119ad565b4281606001351161175757506119ad565b6000611790611769602084018461380d565b611779604085016020860161386f565b6117866040860186614131565b8660600135612191565b905060006117a5826107f06080860186614131565b509050806117e8576040518481527fd6d90193101048cc1b6edcdc2348f5acf7a4a4a97d3e7b668b74cb7602ab3ebc9060200160405180910390a15050506119ad565b60006118086117fa6040860186614131565b61180391614196565b612930565b905080156118a15760008381526007602052604090205460ff1615611869577f9bb9bddbdf537a2104255307230b323d7982f4512ee8e5bd15df62ddca50ab978484604051611858929190614242565b60405180910390a1505050506119ad565b600083815260076020526040902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff001660011790555b6000806118b4604087016020880161386f565b73ffffffffffffffffffffffffffffffffffffffff166118d76040880188614131565b6040516118e5929190614308565b6000604051808303816000865af19150503d8060008114611922576040519150601f19603f3d011682016040523d82523d6000602084013e611927565b606091505b5091509150816119a657821561196c57600085815260076020526040902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff001690555b7fdc8cdd96296241bbefda4a8e18ad2e0985a8da6495b34d409cfc4c886ee3b0cf878260405161199d929190614318565b60405180910390a15b5050505050505b6001016116d2565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217756119df81612442565b600180547fff0000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffff167d01000000000000000000000000000000000000000000000000000000000061ffff8516908102919091179091556040519081527f7af0ac740036ffb1c97b03697859d729e80a44ae5030543d64971c313565ab4d90602001611478565b60007f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de611a8f81612442565b82611a9981610c77565b611acf576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c08101825260025473ffffffffffffffffffffffffffffffffffffffff908116825261ffff808b16602080850182905267ffffffffffffffff808c16868801528a851660608701526005546801000000000000000090041660808601526001547d010000000000000000000000000000000000000000000000000000000000810490931660a08601526000918252600681528582208651918201875291815294517fdf2b057e00000000000000000000000000000000000000000000000000000000815293946101009092049092169263df2b057e92611bb892869260040161401d565b6020604051808303816000875af1158015611bd7573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190611bfb9190613e8e565b93507f87e46b0a6199bc734632187269a103c05714ee0adae5b28f30723955724f37ef84604051611c2e91815260200190565b60405180910390a1505050949350505050565b6005546000908190611c6a9068010000000000000000900467ffffffffffffffff166041614360565b8314611c7c5750600090506001611e49565b6000611cd5866040517f19457468657265756d205369676e6564204d6573736167653a0a3332000000006020820152603c8101829052600090605c01604051602081830303815290604052805190602001209050919050565b90506000805b60055468010000000000000000900467ffffffffffffffff16811015611e3d573660008888611d0b856041614360565b90611d17866001614377565b611d22906041614360565b92611d2f9392919061438a565b91509150600080611d768785858080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920191909152506129cb92505050565b90925090506000816004811115611d8f57611d8f613c16565b14611da857600060019850985050505050505050611e49565b8573ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1611611def57600060029850985050505050505050611e49565b73ffffffffffffffffffffffffffffffffffffffff821660009081526004602052604090205460ff16611e3057600060039850985050505050505050611e49565b5093505050600101611cdb565b50600160009350935050505b935093915050565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775611e7b81612442565b600180547fffffffffffffffffffffff0000000000000000000000000000000000000000ff1661010073ffffffffffffffffffffffffffffffffffffffff8516908102919091179091556040519081527f1399be28223800f8669b3ba5f8721d9fc16fc4e8d0bbf98378791c8c5a3015e090602001611478565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775611f1f81612442565b63ffffffff84166000908152600360205260409020611f3f908484613652565b5050505050565b817f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca811480611f9457507f4270fae16c6d150d00e80b689daca99e8073b1838ff2b6063a37be9d851283e481145b80611fbe57507f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de81145b1561200157303314611ffc576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b612051565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217758103610e6757611ffc7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775612442565b610eab8383612a10565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c2177561208581612442565b73ffffffffffffffffffffffffffffffffffffffff841660009081527f9b50f4667d2d24216ccbf0dce3a90c0f620fa4d895e7b069d80ff6247fd25620602052604090205460ff16612103576040517f5ee08b9700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040517f07b18bde00000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff8481166004830152602482018490528516906307b18bde90604401600060405180830381600087803b15801561217357600080fd5b505af1158015612187573d6000803e3d6000fd5b5050505050505050565b600085858386866040516020016121ac9594939291906143b4565b60405160208183030381529060405280519060200120905095945050505050565b4281606001351161220a576040517f0bbaf26300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b3061221b604083016020840161386f565b73ffffffffffffffffffffffffffffffffffffffff161461229157612246604082016020830161386f565b6040517f1ce0bfcd00000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff9091166004820152602401610e98565b63ffffffff7f0000000000000000000000000000000000000000000000000000000000000066166122c5602083018361380d565b63ffffffff1614612318576122dd602082018261380d565b6040517f2697e1c200000000000000000000000000000000000000000000000000000000815263ffffffff9091166004820152602401610e98565b600061232a611769602084018461380d565b9050600061233f826107f06080860186614131565b50905080612379576040517f15ecadee00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60008281526007602052604090205460ff16156123c5576040517f9d6a45a600000000000000000000000000000000000000000000000000000000815260048101839052602401610e98565b6000828152600760205260409081902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00166001179055610eab907fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217759061243090860186614131565b81019061243d919061386f565b612552565b6114c68133612ad5565b73ffffffffffffffffffffffffffffffffffffffff831661247157610eab8282612b8d565b610eab838383612c93565b612484612d01565b600180547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0016811790557f62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258335b60405173ffffffffffffffffffffffffffffffffffffffff909116815260200160405180910390a1565b612503612d70565b600180547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff001690557f5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa336124d1565b7f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca821480156125af575060008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff16155b1561260e57600180546015906125e7907501000000000000000000000000000000000000000000900467ffffffffffffffff16614426565b91906101000a81548167ffffffffffffffff021916908367ffffffffffffffff1602179055505b610be48282612ddc565b73ffffffffffffffffffffffffffffffffffffffff821660009081526004602052604090205481151560ff90911615150361269f576040517f58c8d2a000000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff831660048201528115156024820152604401610e98565b73ffffffffffffffffffffffffffffffffffffffff8216600090815260046020526040812080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0016831515179055816127115760055461270c9060019067ffffffffffffffff1661444d565b612729565b6005546127299067ffffffffffffffff166001614475565b60055490915067ffffffffffffffff680100000000000000009091048116908216811115612797576040517ff1c582ae00000000000000000000000000000000000000000000000000000000815267ffffffffffffffff808416600483015282166024820152604401610e98565b600580547fffffffffffffffffffffffffffffffffffffffffffffffff00000000000000001667ffffffffffffffff84161790556040805173ffffffffffffffffffffffffffffffffffffffff8616815284151560208201527f863d338cad74814b108a06288ad5e0e80d56495e0332238b1d2cdcfa0ca8e5ce9101610bbd565b8067ffffffffffffffff1660000361285c576040517f5f86e17700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60055467ffffffffffffffff9081169082168110156128bb576040517ff1c582ae00000000000000000000000000000000000000000000000000000000815267ffffffffffffffff808316600483015283166024820152604401610e98565b600580547fffffffffffffffffffffffffffffffff0000000000000000ffffffffffffffff166801000000000000000067ffffffffffffffff8516908102919091179091556040519081527fb600f3cf7f38a4b49bb0c75f722ef69f7e3e39ef3bb4aa8207fd86e724a2324990602001611478565b60007fffffffff0000000000000000000000000000000000000000000000000000000082167f0223536e0000000000000000000000000000000000000000000000000000000014801590610a3557507fffffffff0000000000000000000000000000000000000000000000000000000082167f704316e500000000000000000000000000000000000000000000000000000000141592915050565b6000808251604103612a015760208301516040840151606085015160001a6129f587828585612ecc565b94509450505050612a09565b506000905060025b9250929050565b7f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca82148015612a6c575060008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff165b15612acb5760018054601590612aa4907501000000000000000000000000000000000000000000900467ffffffffffffffff16614496565b91906101000a81548167ffffffffffffffff021916908367ffffffffffffffff1602179055505b610be48282612fbb565b60008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff16610be457612b1381613072565b612b1e836020613091565b604051602001612b2f9291906144d8565b604080517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0818403018152908290527f08c379a0000000000000000000000000000000000000000000000000000000008252610e9891600401614559565b73ffffffffffffffffffffffffffffffffffffffff8216612bda576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60008273ffffffffffffffffffffffffffffffffffffffff168260405160006040518083038185875af1925050503d8060008114612c34576040519150601f19603f3d011682016040523d82523d6000602084013e612c39565b606091505b5050905080610eab576040517f465bc83400000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff8416600482015260248101839052604401610e98565b73ffffffffffffffffffffffffffffffffffffffff8216612ce0576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610eab73ffffffffffffffffffffffffffffffffffffffff841683836132db565b60015460ff1615612d6e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601060248201527f5061757361626c653a20706175736564000000000000000000000000000000006044820152606401610e98565b565b60015460ff16612d6e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601460248201527f5061757361626c653a206e6f74207061757365640000000000000000000000006044820152606401610e98565b60008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff16610be45760008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff85168452909152902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00166001179055612e6e3390565b73ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff16837f2f8788117e7eff1d82e926ec794901d17c78024a50270940304540a733656f0d60405160405180910390a45050565b6000807f7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a0831115612f035750600090506003612fb2565b6040805160008082526020820180845289905260ff881692820192909252606081018690526080810185905260019060a0016020604051602081039080840390855afa158015612f57573d6000803e3d6000fd5b50506040517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0015191505073ffffffffffffffffffffffffffffffffffffffff8116612fab57600060019250925050612fb2565b9150600090505b94509492505050565b60008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff1615610be45760008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516808552925280832080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0016905551339285917ff6391f5c32d9c69d2a47ea670b442974b53935d1edc7fd64eb21e047a839171b9190a45050565b6060610a3573ffffffffffffffffffffffffffffffffffffffff831660145b606060006130a0836002614360565b6130ab906002614377565b67ffffffffffffffff8111156130c3576130c361456c565b6040519080825280601f01601f1916602001820160405280156130ed576020820181803683370190505b5090507f30000000000000000000000000000000000000000000000000000000000000008160008151811061312457613124613ea7565b60200101907effffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916908160001a9053507f78000000000000000000000000000000000000000000000000000000000000008160018151811061318757613187613ea7565b60200101907effffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916908160001a90535060006131c3846002614360565b6131ce906001614377565b90505b600181111561326b577f303132333435363738396162636465660000000000000000000000000000000085600f166010811061320f5761320f613ea7565b1a60f81b82828151811061322557613225613ea7565b60200101907effffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916908160001a90535060049490941c936132648161459b565b90506131d1565b5083156132d4576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820181905260248201527f537472696e67733a20686578206c656e67746820696e73756666696369656e746044820152606401610e98565b9392505050565b6040805173ffffffffffffffffffffffffffffffffffffffff848116602483015260448083018590528351808403909101815260649092018352602080830180517bffffffffffffffffffffffffffffffffffffffffffffffffffffffff167fa9059cbb0000000000000000000000000000000000000000000000000000000017905283518085019094528084527f5361666545524332303a206c6f772d6c6576656c2063616c6c206661696c656490840152610eab928692916000916133a6918516908490613453565b90508051600014806133c75750808060200190518101906133c791906145d0565b610eab576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602a60248201527f5361666545524332303a204552433230206f7065726174696f6e20646964206e60448201527f6f742073756363656564000000000000000000000000000000000000000000006064820152608401610e98565b6060613462848460008561346a565b949350505050565b6060824710156134fc576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602660248201527f416464726573733a20696e73756666696369656e742062616c616e636520666f60448201527f722063616c6c00000000000000000000000000000000000000000000000000006064820152608401610e98565b6000808673ffffffffffffffffffffffffffffffffffffffff16858760405161352591906145ed565b60006040518083038185875af1925050503d8060008114613562576040519150601f19603f3d011682016040523d82523d6000602084013e613567565b606091505b50915091506113d487838387606083156136095782516000036136025773ffffffffffffffffffffffffffffffffffffffff85163b613602576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601d60248201527f416464726573733a2063616c6c20746f206e6f6e2d636f6e74726163740000006044820152606401610e98565b5081613462565b613462838381511561361e5781518083602001fd5b806040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610e989190614559565b82805482825590600052602060002090601f016020900481019282156136eb5791602002820160005b838211156136bc57833560ff1683826101000a81548160ff021916908360ff160217905550926020019260010160208160000104928301926001030261367b565b80156136e95782816101000a81549060ff02191690556001016020816000010492830192600103026136bc565b505b506136f79291506136fb565b5090565b5b808211156136f757600081556001016136fc565b73ffffffffffffffffffffffffffffffffffffffff811681146114c657600080fd5b60008060006060848603121561374757600080fd5b833561375281613710565b9250602084013561376281613710565b929592945050506040919091013590565b60006020828403121561378557600080fd5b81357fffffffff00000000000000000000000000000000000000000000000000000000811681146132d457600080fd5b80151581146114c657600080fd5b6000602082840312156137d557600080fd5b81356132d4816137b5565b6000602082840312156137f257600080fd5b5035919050565b803563ffffffff81168114610d5757600080fd5b60006020828403121561381f57600080fd5b6132d4826137f9565b6020808252825182820181905260009190848201906040850190845b8181101561386357835160ff1683529284019291840191600101613844565b50909695505050505050565b60006020828403121561388157600080fd5b81356132d481613710565b6000806040838503121561389f57600080fd5b8235915060208301356138b181613710565b809150509250929050565b803567ffffffffffffffff81168114610d5757600080fd5b60008083601f8401126138e657600080fd5b50813567ffffffffffffffff8111156138fe57600080fd5b602083019150836020828501011115612a0957600080fd5b60008060008060006080868803121561392e57600080fd5b613937866137f9565b9450613945602087016138bc565b9350604086013561395581613710565b9250606086013567ffffffffffffffff81111561397157600080fd5b61397d888289016138d4565b969995985093965092949392505050565b600080604083850312156139a157600080fd5b82356139ac81613710565b915060208301356138b1816137b5565b600080602083850312156139cf57600080fd5b823567ffffffffffffffff808211156139e757600080fd5b818501915085601f8301126139fb57600080fd5b813581811115613a0a57600080fd5b8660208260071b8501011115613a1f57600080fd5b60209290920196919550909350505050565b803561ffff81168114610d5757600080fd5b60008060008060808587031215613a5957600080fd5b613a6285613a31565b9350613a7060208601613a31565b9250613a7e604086016138bc565b91506060850135613a8e81613710565b939692955090935050565b600060208284031215613aab57600080fd5b6132d4826138bc565b600060a08284031215613ac657600080fd5b50919050565b600080600060408486031215613ae157600080fd5b833567ffffffffffffffff80821115613af957600080fd5b613b0587838801613ab4565b94506020860135915080821115613b1b57600080fd5b50613b28868287016138d4565b9497909650939450505050565b60008083601f840112613b4757600080fd5b50813567ffffffffffffffff811115613b5f57600080fd5b6020830191508360208260051b8501011115612a0957600080fd5b60008060208385031215613b8d57600080fd5b823567ffffffffffffffff811115613ba457600080fd5b613bb085828601613b35565b90969095509350505050565b600060208284031215613bce57600080fd5b6132d482613a31565b600080600060408486031215613bec57600080fd5b83359250602084013567ffffffffffffffff811115613c0a57600080fd5b613b28868287016138d4565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602160045260246000fd5b82151581526040810160048310613c85577f4e487b7100000000000000000000000000000000000000000000000000000000600052602160045260246000fd5b8260208301529392505050565b600080600060408486031215613ca757600080fd5b613cb0846137f9565b9250602084013567ffffffffffffffff811115613ccc57600080fd5b613b2886828701613b35565b600080600080600060808688031215613cf057600080fd5b613cf9866137f9565b94506020860135613d0981613710565b9350604086013567ffffffffffffffff811115613d2557600080fd5b613d31888289016138d4565b96999598509660600135949350505050565b600060208284031215613d5557600080fd5b813567ffffffffffffffff811115613d6c57600080fd5b61346284828501613ab4565b8183528181602085013750600060208284010152600060207fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0601f840116840101905092915050565b6000610140613e39838873ffffffffffffffffffffffffffffffffffffffff80825116835263ffffffff6020830151166020840152604082015167ffffffffffffffff808216604086015282606085015116606086015280608085015116608086015250505061ffff60a08201511660a08301525050565b613e7a60c08401875467ffffffffffffffff81168252604081811c61ffff16602084015260509190911c6fffffffffffffffffffffffffffffffff16910152565b806101208401526113d48184018587613d78565b600060208284031215613ea057600080fd5b5051919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052603260045260246000fd5b80356fffffffffffffffffffffffffffffffff81168114610d5757600080fd5b600060208284031215613f0857600080fd5b6132d482613ed6565b6020808252818101839052600090604080840186845b87811015613fa25763ffffffff613f3d836137f9565b16835267ffffffffffffffff613f548684016138bc565b168584015261ffff613f67858401613a31565b168484015260606fffffffffffffffffffffffffffffffff613f8a828501613ed6565b16908401526080928301929190910190600101613f27565b5090979650505050505050565b60005b83811015613fca578181015183820152602001613fb2565b50506000910152565b60008151808452613feb816020860160208601613faf565b601f017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0169290920160200192915050565b6000610140614095838773ffffffffffffffffffffffffffffffffffffffff80825116835263ffffffff6020830151166020840152604082015167ffffffffffffffff808216604086015282606085015116606086015280608085015116608086015250505061ffff60a08201511660a08301525050565b6140d660c08401865467ffffffffffffffff81168252604081811c61ffff16602084015260509190911c6fffffffffffffffffffffffffffffffff16910152565b806101208401526140e981840185613fd3565b9695505050505050565b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff6183360301811261412757600080fd5b9190910192915050565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe184360301811261416657600080fd5b83018035915067ffffffffffffffff82111561418157600080fd5b602001915036819003821315612a0957600080fd5b7fffffffff0000000000000000000000000000000000000000000000000000000081358181169160048510156141d65780818660040360031b1b83161692505b505092915050565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe184360301811261421357600080fd5b830160208101925035905067ffffffffffffffff81111561423357600080fd5b803603821315612a0957600080fd5b6040815263ffffffff614254846137f9565b1660408201526000602084013561426a81613710565b73ffffffffffffffffffffffffffffffffffffffff16606083015261429260408501856141de565b60a060808501526142a760e085018284613d78565b915050606085013560a08401526142c160808601866141de565b7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc08584030160c08601526142f6838284613d78565b93505050508260208301529392505050565b8183823760009101908152919050565b8281526040602082015260006134626040830184613fd3565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b8082028115828204841417610a3557610a35614331565b80820180821115610a3557610a35614331565b6000808585111561439a57600080fd5b838611156143a757600080fd5b5050820193919092039150565b7fffffffff000000000000000000000000000000000000000000000000000000008660e01b1681527fffffffffffffffffffffffffffffffffffffffff0000000000000000000000008560601b1660048201528360188201528183603883013760009101603801908152949350505050565b600067ffffffffffffffff80831681810361444357614443614331565b6001019392505050565b67ffffffffffffffff82811682821603908082111561446e5761446e614331565b5092915050565b67ffffffffffffffff81811683821601908082111561446e5761446e614331565b600067ffffffffffffffff8216806144b0576144b0614331565b7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0192915050565b7f416363657373436f6e74726f6c3a206163636f756e7420000000000000000000815260008351614510816017850160208801613faf565b7f206973206d697373696e6720726f6c6520000000000000000000000000000000601791840191820152835161454d816028840160208801613faf565b01602801949350505050565b6020815260006132d46020830184613fd3565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b6000816145aa576145aa614331565b507fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0190565b6000602082840312156145e257600080fd5b81516132d4816137b5565b60008251614127818460208701613faf56fea2646970667358221220b69fbeb30e38ef1b4b202031c8b88e5d5b004563c7ff42713ed413ed4f4901a664736f6c63430008160033"
  },
  {
    method: "eth_getCode",
    params: [
      "0x31f748a368a893bdb5abb67ec95f232507601a73",
      "0x80f2a08"
    ],
    result: "0x60806040526004361061029f5760003560e01c80638585c9451161016e578063c7a823e0116100cb578063d547741f1161007f578063f010cb2311610064578063f010cb2314610906578063f3b4ebd014610926578063fd62e7501461094657600080fd5b8063d547741f146108c6578063dafe0ccc146108e657600080fd5b8063cd88b903116100b0578063cd88b90314610823578063cf34c76814610843578063d2ae21041461088c57600080fd5b8063c7a823e0146107d5578063c7b2370b1461080357600080fd5b8063aef18bf711610122578063c358de0a11610107578063c358de0a14610763578063c416aa5114610783578063c5e193cd146107b557600080fd5b8063aef18bf714610713578063b143044b1461074357600080fd5b806395d376d71161015357806395d376d7146106465780639e94496514610659578063a217fddf146106fe57600080fd5b80638585c945146105d557806391d14854146105f557600080fd5b80632f2ff15d1161021c5780635553fb8e116101d0578063724e78da116101b5578063724e78da14610533578063736c0d5b14610553578063741bef1a1461058357600080fd5b80635553fb8e146104fb5780635c975abb1461051b57600080fd5b806331cb61051161020157806331cb61051461049b57806336568abe146104bb57806352d3b871146104db57600080fd5b80632f2ff15d1461045b57806330bb3aac1461047b57600080fd5b806316c38b3c11610273578063248a9ca311610258578063248a9ca3146103d057806326e67a371461040e5780632de113761461043b57600080fd5b806316c38b3c1461036a5780631703a0181461038a57600080fd5b8062bf2e80146102a457806301e33667146102f857806301ffc9a71461031a5780631095b6d71461034a575b600080fd5b3480156102b057600080fd5b506001546102e0907d010000000000000000000000000000000000000000000000000000000000900461ffff1681565b60405161ffff90911681526020015b60405180910390f35b34801561030457600080fd5b50610318610313366004613732565b610967565b005b34801561032657600080fd5b5061033a610335366004613773565b6109a2565b60405190151581526020016102ef565b34801561035657600080fd5b50610318610365366004613732565b610a3b565b34801561037657600080fd5b506103186103853660046137c3565b610bcb565b34801561039657600080fd5b506005546103b79068010000000000000000900467ffffffffffffffff1681565b60405167ffffffffffffffff90911681526020016102ef565b3480156103dc57600080fd5b506104006103eb3660046137e0565b60009081526020819052604090206001015490565b6040519081526020016102ef565b34801561041a57600080fd5b5061042e61042936600461380d565b610bf0565b6040516102ef9190613828565b34801561044757600080fd5b5061033a61045636600461386f565b610c77565b34801561046757600080fd5b5061031861047636600461388c565b610d5c565b34801561048757600080fd5b50610400610496366004613916565b610eb0565b3480156104a757600080fd5b506103186104b636600461398e565b611027565b3480156104c757600080fd5b506103186104d636600461388c565b61106a565b3480156104e757600080fd5b506103186104f63660046139bc565b61109c565b34801561050757600080fd5b50610400610516366004613a43565b611268565b34801561052757600080fd5b5060015460ff1661033a565b34801561053f57600080fd5b5061031861054e36600461386f565b6113df565b34801561055f57600080fd5b5061033a61056e36600461386f565b60046020526000908152604090205460ff1681565b34801561058f57600080fd5b506002546105b09073ffffffffffffffffffffffffffffffffffffffff1681565b60405173ffffffffffffffffffffffffffffffffffffffff90911681526020016102ef565b3480156105e157600080fd5b506103186105f0366004613a99565b611484565b34801561060157600080fd5b5061033a61061036600461388c565b60009182526020828152604080842073ffffffffffffffffffffffffffffffffffffffff93909316845291905290205460ff1690565b610400610654366004613acc565b6114c9565b34801561066557600080fd5b506106c361067436600461380d565b60066020526000908152604090205467ffffffffffffffff81169068010000000000000000810461ffff16906a010000000000000000000090046fffffffffffffffffffffffffffffffff1683565b6040805167ffffffffffffffff909416845261ffff90921660208401526fffffffffffffffffffffffffffffffff16908201526060016102ef565b34801561070a57600080fd5b50610400600081565b34801561071f57600080fd5b5061033a61072e3660046137e0565b60076020526000908152604090205460ff1681565b34801561074f57600080fd5b5061031861075e366004613b7a565b6116a5565b34801561076f57600080fd5b5061031861077e366004613bbc565b6119b5565b34801561078f57600080fd5b506001546105b090610100900473ffffffffffffffffffffffffffffffffffffffff1681565b3480156107c157600080fd5b506104006107d0366004613a43565b611a63565b3480156107e157600080fd5b506107f56107f0366004613bd7565b611c41565b6040516102ef929190613c45565b34801561080f57600080fd5b5061031861081e36600461386f565b611e51565b34801561082f57600080fd5b5061031861083e366004613c92565b611ef5565b34801561084f57600080fd5b506108777f000000000000000000000000000000000000000000000000000000000000006681565b60405163ffffffff90911681526020016102ef565b34801561089857600080fd5b506001546103b7907501000000000000000000000000000000000000000000900467ffffffffffffffff1681565b3480156108d257600080fd5b506103186108e136600461388c565b611f46565b3480156108f257600080fd5b50610318610901366004613732565b61205b565b34801561091257600080fd5b50610400610921366004613cd8565b612191565b34801561093257600080fd5b50610318610941366004613d43565b6121cd565b34801561095257600080fd5b506005546103b79067ffffffffffffffff1681565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c2177561099181612442565b61099c84848461244c565b50505050565b60007fffffffff0000000000000000000000000000000000000000000000000000000082167f7965db0b000000000000000000000000000000000000000000000000000000001480610a3557507f01ffc9a7000000000000000000000000000000000000000000000000000000007fffffffff000000000000000000000000000000000000000000000000000000008316145b92915050565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775610a6581612442565b73ffffffffffffffffffffffffffffffffffffffff841660009081527f9b50f4667d2d24216ccbf0dce3a90c0f620fa4d895e7b069d80ff6247fd25620602052604090205460ff16610ae3576040517f5ee08b9700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040517ffd9be52200000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff84811660048301526024820184905285169063fd9be52290604401600060405180830381600087803b158015610b5357600080fd5b505af1158015610b67573d6000803e3d6000fd5b50506040805173ffffffffffffffffffffffffffffffffffffffff8089168252871660208201529081018590527f9b1bfa7fa9ee420a16e124f794c35ac9f90472acc99140eb2f6447c714cad8eb925060600190505b60405180910390a150505050565b6000610bd681612442565b8115610be857610be461247c565b5050565b610be46124fb565b63ffffffff8116600090815260036020908152604091829020805483518184028101840190945280845260609392830182828015610c6b57602002820191906000526020600020906000905b825461010083900a900460ff16815260206001928301818104948501949093039092029101808411610c3c5790505b50505050509050919050565b73ffffffffffffffffffffffffffffffffffffffff811660009081527f93c430521711328044ae92d0f1f1286cf040bc4a382f1642bd89984e86630553602052604081205460ff1615610ccc57506000919050565b6001547501000000000000000000000000000000000000000000900467ffffffffffffffff161580610d42575073ffffffffffffffffffffffffffffffffffffffff821660009081527f4ac82e3087b7dedf7f532cbc6915c722df8c1e31f1388c318a617b52760eaf8b602052604090205460ff165b15610d4f57506001919050565b506000919050565b919050565b817f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca811480610daa57507f4270fae16c6d150d00e80b689daca99e8073b1838ff2b6063a37be9d851283e481145b80610dd457507f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de81145b15610e1757303314610e12576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610ea1565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217758103610e6757610e127fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775612442565b6040517f94fdc372000000000000000000000000000000000000000000000000000000008152600481018290526024015b60405180910390fd5b610eab8383612552565b505050565b600083610ebc81610c77565b610ef2576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c08101825260025473ffffffffffffffffffffffffffffffffffffffff908116825263ffffffff8a16602080840182905267ffffffffffffffff808c16858701528a8416606086015260055468010000000000000000900416608085015260015461ffff7d01000000000000000000000000000000000000000000000000000000000082041660a0860152600092835260069091529084902093517f7bfa20a9000000000000000000000000000000000000000000000000000000008152929361010090910490911691637bfa20a991610fda918591908a908a90600401613dc1565b602060405180830381865afa158015610ff7573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061101b9190613e8e565b98975050505050505050565b303314611060576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610be48282612618565b6040517fdec9f03100000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217756110c681612442565b60005b8281101561122957368484838181106110e4576110e4613ea7565b9050608002019050604051806060016040528082602001602081019061110a9190613a99565b67ffffffffffffffff1681526020016111296060840160408501613bbc565b61ffff1681526020016111426080840160608501613ef6565b6fffffffffffffffffffffffffffffffff16905260066000611167602085018561380d565b63ffffffff1681526020808201929092526040908101600020835181549385015194909201516fffffffffffffffffffffffffffffffff166a0100000000000000000000027fffffffffffff00000000000000000000000000000000ffffffffffffffffffff61ffff90951668010000000000000000027fffffffffffffffffffffffffffffffffffffffffffff0000000000000000000090941667ffffffffffffffff909316929092179290921792909216919091179055506001016110c9565b507f7dd21e42791b013d1929e86f0c59085e4fca24251f0f1aa81917b3b1611766e0838360405161125b929190613f11565b60405180910390a1505050565b60008161127481610c77565b6112aa576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c08101825260025473ffffffffffffffffffffffffffffffffffffffff908116825261ffff808a16602080850182905267ffffffffffffffff808b168688015289851660608701526005546801000000000000000090041660808601526001547d010000000000000000000000000000000000000000000000000000000000810490931660a08601526000918252600681528582208651918201875291815294517f7bfa20a9000000000000000000000000000000000000000000000000000000008152939461010090920490921692637bfa20a99261139392869260040161401d565b602060405180830381865afa1580156113b0573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906113d49190613e8e565b979650505050505050565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c2177561140981612442565b600280547fffffffffffffffffffffffff00000000000000000000000000000000000000001673ffffffffffffffffffffffffffffffffffffffff84169081179091556040519081527ff724a45d041687842411f2b977ef22ab8f43c8f1104f4592b42a00f9b34a643d906020015b60405180910390a15050565b3033146114bd576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6114c681612818565b50565b60007f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de6114f581612442565b61150560a086016080870161386f565b61150e81610c77565b611544576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c0810190915260025473ffffffffffffffffffffffffffffffffffffffff16815260009060208082019061157f908a018a61380d565b63ffffffff16815260200161159a60808a0160608b01613a99565b67ffffffffffffffff1681526020016115b960a08a0160808b0161386f565b73ffffffffffffffffffffffffffffffffffffffff908116825260055468010000000000000000900467ffffffffffffffff166020808401919091526001547d010000000000000000000000000000000000000000000000000000000000810461ffff16604090940193909352929350610100909104169063df2b057e90839060069060009061164b908d018d61380d565b63ffffffff1663ffffffff16815260200190815260200160002089896040518563ffffffff1660e01b81526004016116869493929190613dc1565b6020604051808303816000875af11580156113b0573d6000803e3d6000fd5b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217756116cf81612442565b60005b8281101561099c57368484838181106116ed576116ed613ea7565b90506020028101906116ff91906140f3565b905063ffffffff7f000000000000000000000000000000000000000000000000000000000000006616611735602083018361380d565b63ffffffff161461174657506119ad565b4281606001351161175757506119ad565b6000611790611769602084018461380d565b611779604085016020860161386f565b6117866040860186614131565b8660600135612191565b905060006117a5826107f06080860186614131565b509050806117e8576040518481527fd6d90193101048cc1b6edcdc2348f5acf7a4a4a97d3e7b668b74cb7602ab3ebc9060200160405180910390a15050506119ad565b60006118086117fa6040860186614131565b61180391614196565b612930565b905080156118a15760008381526007602052604090205460ff1615611869577f9bb9bddbdf537a2104255307230b323d7982f4512ee8e5bd15df62ddca50ab978484604051611858929190614242565b60405180910390a1505050506119ad565b600083815260076020526040902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff001660011790555b6000806118b4604087016020880161386f565b73ffffffffffffffffffffffffffffffffffffffff166118d76040880188614131565b6040516118e5929190614308565b6000604051808303816000865af19150503d8060008114611922576040519150601f19603f3d011682016040523d82523d6000602084013e611927565b606091505b5091509150816119a657821561196c57600085815260076020526040902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff001690555b7fdc8cdd96296241bbefda4a8e18ad2e0985a8da6495b34d409cfc4c886ee3b0cf878260405161199d929190614318565b60405180910390a15b5050505050505b6001016116d2565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217756119df81612442565b600180547fff0000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffff167d01000000000000000000000000000000000000000000000000000000000061ffff8516908102919091179091556040519081527f7af0ac740036ffb1c97b03697859d729e80a44ae5030543d64971c313565ab4d90602001611478565b60007f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de611a8f81612442565b82611a9981610c77565b611acf576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c08101825260025473ffffffffffffffffffffffffffffffffffffffff908116825261ffff808b16602080850182905267ffffffffffffffff808c16868801528a851660608701526005546801000000000000000090041660808601526001547d010000000000000000000000000000000000000000000000000000000000810490931660a08601526000918252600681528582208651918201875291815294517fdf2b057e00000000000000000000000000000000000000000000000000000000815293946101009092049092169263df2b057e92611bb892869260040161401d565b6020604051808303816000875af1158015611bd7573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190611bfb9190613e8e565b93507f87e46b0a6199bc734632187269a103c05714ee0adae5b28f30723955724f37ef84604051611c2e91815260200190565b60405180910390a1505050949350505050565b6005546000908190611c6a9068010000000000000000900467ffffffffffffffff166041614360565b8314611c7c5750600090506001611e49565b6000611cd5866040517f19457468657265756d205369676e6564204d6573736167653a0a3332000000006020820152603c8101829052600090605c01604051602081830303815290604052805190602001209050919050565b90506000805b60055468010000000000000000900467ffffffffffffffff16811015611e3d573660008888611d0b856041614360565b90611d17866001614377565b611d22906041614360565b92611d2f9392919061438a565b91509150600080611d768785858080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920191909152506129cb92505050565b90925090506000816004811115611d8f57611d8f613c16565b14611da857600060019850985050505050505050611e49565b8573ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1611611def57600060029850985050505050505050611e49565b73ffffffffffffffffffffffffffffffffffffffff821660009081526004602052604090205460ff16611e3057600060039850985050505050505050611e49565b5093505050600101611cdb565b50600160009350935050505b935093915050565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775611e7b81612442565b600180547fffffffffffffffffffffff0000000000000000000000000000000000000000ff1661010073ffffffffffffffffffffffffffffffffffffffff8516908102919091179091556040519081527f1399be28223800f8669b3ba5f8721d9fc16fc4e8d0bbf98378791c8c5a3015e090602001611478565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775611f1f81612442565b63ffffffff84166000908152600360205260409020611f3f908484613652565b5050505050565b817f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca811480611f9457507f4270fae16c6d150d00e80b689daca99e8073b1838ff2b6063a37be9d851283e481145b80611fbe57507f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de81145b1561200157303314611ffc576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b612051565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217758103610e6757611ffc7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775612442565b610eab8383612a10565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c2177561208581612442565b73ffffffffffffffffffffffffffffffffffffffff841660009081527f9b50f4667d2d24216ccbf0dce3a90c0f620fa4d895e7b069d80ff6247fd25620602052604090205460ff16612103576040517f5ee08b9700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040517f07b18bde00000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff8481166004830152602482018490528516906307b18bde90604401600060405180830381600087803b15801561217357600080fd5b505af1158015612187573d6000803e3d6000fd5b5050505050505050565b600085858386866040516020016121ac9594939291906143b4565b60405160208183030381529060405280519060200120905095945050505050565b4281606001351161220a576040517f0bbaf26300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b3061221b604083016020840161386f565b73ffffffffffffffffffffffffffffffffffffffff161461229157612246604082016020830161386f565b6040517f1ce0bfcd00000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff9091166004820152602401610e98565b63ffffffff7f0000000000000000000000000000000000000000000000000000000000000066166122c5602083018361380d565b63ffffffff1614612318576122dd602082018261380d565b6040517f2697e1c200000000000000000000000000000000000000000000000000000000815263ffffffff9091166004820152602401610e98565b600061232a611769602084018461380d565b9050600061233f826107f06080860186614131565b50905080612379576040517f15ecadee00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60008281526007602052604090205460ff16156123c5576040517f9d6a45a600000000000000000000000000000000000000000000000000000000815260048101839052602401610e98565b6000828152600760205260409081902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00166001179055610eab907fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217759061243090860186614131565b81019061243d919061386f565b612552565b6114c68133612ad5565b73ffffffffffffffffffffffffffffffffffffffff831661247157610eab8282612b8d565b610eab838383612c93565b612484612d01565b600180547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0016811790557f62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258335b60405173ffffffffffffffffffffffffffffffffffffffff909116815260200160405180910390a1565b612503612d70565b600180547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff001690557f5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa336124d1565b7f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca821480156125af575060008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff16155b1561260e57600180546015906125e7907501000000000000000000000000000000000000000000900467ffffffffffffffff16614426565b91906101000a81548167ffffffffffffffff021916908367ffffffffffffffff1602179055505b610be48282612ddc565b73ffffffffffffffffffffffffffffffffffffffff821660009081526004602052604090205481151560ff90911615150361269f576040517f58c8d2a000000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff831660048201528115156024820152604401610e98565b73ffffffffffffffffffffffffffffffffffffffff8216600090815260046020526040812080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0016831515179055816127115760055461270c9060019067ffffffffffffffff1661444d565b612729565b6005546127299067ffffffffffffffff166001614475565b60055490915067ffffffffffffffff680100000000000000009091048116908216811115612797576040517ff1c582ae00000000000000000000000000000000000000000000000000000000815267ffffffffffffffff808416600483015282166024820152604401610e98565b600580547fffffffffffffffffffffffffffffffffffffffffffffffff00000000000000001667ffffffffffffffff84161790556040805173ffffffffffffffffffffffffffffffffffffffff8616815284151560208201527f863d338cad74814b108a06288ad5e0e80d56495e0332238b1d2cdcfa0ca8e5ce9101610bbd565b8067ffffffffffffffff1660000361285c576040517f5f86e17700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60055467ffffffffffffffff9081169082168110156128bb576040517ff1c582ae00000000000000000000000000000000000000000000000000000000815267ffffffffffffffff808316600483015283166024820152604401610e98565b600580547fffffffffffffffffffffffffffffffff0000000000000000ffffffffffffffff166801000000000000000067ffffffffffffffff8516908102919091179091556040519081527fb600f3cf7f38a4b49bb0c75f722ef69f7e3e39ef3bb4aa8207fd86e724a2324990602001611478565b60007fffffffff0000000000000000000000000000000000000000000000000000000082167f0223536e0000000000000000000000000000000000000000000000000000000014801590610a3557507fffffffff0000000000000000000000000000000000000000000000000000000082167f704316e500000000000000000000000000000000000000000000000000000000141592915050565b6000808251604103612a015760208301516040840151606085015160001a6129f587828585612ecc565b94509450505050612a09565b506000905060025b9250929050565b7f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca82148015612a6c575060008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff165b15612acb5760018054601590612aa4907501000000000000000000000000000000000000000000900467ffffffffffffffff16614496565b91906101000a81548167ffffffffffffffff021916908367ffffffffffffffff1602179055505b610be48282612fbb565b60008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff16610be457612b1381613072565b612b1e836020613091565b604051602001612b2f9291906144d8565b604080517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0818403018152908290527f08c379a0000000000000000000000000000000000000000000000000000000008252610e9891600401614559565b73ffffffffffffffffffffffffffffffffffffffff8216612bda576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60008273ffffffffffffffffffffffffffffffffffffffff168260405160006040518083038185875af1925050503d8060008114612c34576040519150601f19603f3d011682016040523d82523d6000602084013e612c39565b606091505b5050905080610eab576040517f465bc83400000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff8416600482015260248101839052604401610e98565b73ffffffffffffffffffffffffffffffffffffffff8216612ce0576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610eab73ffffffffffffffffffffffffffffffffffffffff841683836132db565b60015460ff1615612d6e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601060248201527f5061757361626c653a20706175736564000000000000000000000000000000006044820152606401610e98565b565b60015460ff16612d6e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601460248201527f5061757361626c653a206e6f74207061757365640000000000000000000000006044820152606401610e98565b60008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff16610be45760008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff85168452909152902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00166001179055612e6e3390565b73ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff16837f2f8788117e7eff1d82e926ec794901d17c78024a50270940304540a733656f0d60405160405180910390a45050565b6000807f7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a0831115612f035750600090506003612fb2565b6040805160008082526020820180845289905260ff881692820192909252606081018690526080810185905260019060a0016020604051602081039080840390855afa158015612f57573d6000803e3d6000fd5b50506040517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0015191505073ffffffffffffffffffffffffffffffffffffffff8116612fab57600060019250925050612fb2565b9150600090505b94509492505050565b60008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff1615610be45760008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516808552925280832080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0016905551339285917ff6391f5c32d9c69d2a47ea670b442974b53935d1edc7fd64eb21e047a839171b9190a45050565b6060610a3573ffffffffffffffffffffffffffffffffffffffff831660145b606060006130a0836002614360565b6130ab906002614377565b67ffffffffffffffff8111156130c3576130c361456c565b6040519080825280601f01601f1916602001820160405280156130ed576020820181803683370190505b5090507f30000000000000000000000000000000000000000000000000000000000000008160008151811061312457613124613ea7565b60200101907effffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916908160001a9053507f78000000000000000000000000000000000000000000000000000000000000008160018151811061318757613187613ea7565b60200101907effffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916908160001a90535060006131c3846002614360565b6131ce906001614377565b90505b600181111561326b577f303132333435363738396162636465660000000000000000000000000000000085600f166010811061320f5761320f613ea7565b1a60f81b82828151811061322557613225613ea7565b60200101907effffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916908160001a90535060049490941c936132648161459b565b90506131d1565b5083156132d4576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820181905260248201527f537472696e67733a20686578206c656e67746820696e73756666696369656e746044820152606401610e98565b9392505050565b6040805173ffffffffffffffffffffffffffffffffffffffff848116602483015260448083018590528351808403909101815260649092018352602080830180517bffffffffffffffffffffffffffffffffffffffffffffffffffffffff167fa9059cbb0000000000000000000000000000000000000000000000000000000017905283518085019094528084527f5361666545524332303a206c6f772d6c6576656c2063616c6c206661696c656490840152610eab928692916000916133a6918516908490613453565b90508051600014806133c75750808060200190518101906133c791906145d0565b610eab576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602a60248201527f5361666545524332303a204552433230206f7065726174696f6e20646964206e60448201527f6f742073756363656564000000000000000000000000000000000000000000006064820152608401610e98565b6060613462848460008561346a565b949350505050565b6060824710156134fc576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602660248201527f416464726573733a20696e73756666696369656e742062616c616e636520666f60448201527f722063616c6c00000000000000000000000000000000000000000000000000006064820152608401610e98565b6000808673ffffffffffffffffffffffffffffffffffffffff16858760405161352591906145ed565b60006040518083038185875af1925050503d8060008114613562576040519150601f19603f3d011682016040523d82523d6000602084013e613567565b606091505b50915091506113d487838387606083156136095782516000036136025773ffffffffffffffffffffffffffffffffffffffff85163b613602576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601d60248201527f416464726573733a2063616c6c20746f206e6f6e2d636f6e74726163740000006044820152606401610e98565b5081613462565b613462838381511561361e5781518083602001fd5b806040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610e989190614559565b82805482825590600052602060002090601f016020900481019282156136eb5791602002820160005b838211156136bc57833560ff1683826101000a81548160ff021916908360ff160217905550926020019260010160208160000104928301926001030261367b565b80156136e95782816101000a81549060ff02191690556001016020816000010492830192600103026136bc565b505b506136f79291506136fb565b5090565b5b808211156136f757600081556001016136fc565b73ffffffffffffffffffffffffffffffffffffffff811681146114c657600080fd5b60008060006060848603121561374757600080fd5b833561375281613710565b9250602084013561376281613710565b929592945050506040919091013590565b60006020828403121561378557600080fd5b81357fffffffff00000000000000000000000000000000000000000000000000000000811681146132d457600080fd5b80151581146114c657600080fd5b6000602082840312156137d557600080fd5b81356132d4816137b5565b6000602082840312156137f257600080fd5b5035919050565b803563ffffffff81168114610d5757600080fd5b60006020828403121561381f57600080fd5b6132d4826137f9565b6020808252825182820181905260009190848201906040850190845b8181101561386357835160ff1683529284019291840191600101613844565b50909695505050505050565b60006020828403121561388157600080fd5b81356132d481613710565b6000806040838503121561389f57600080fd5b8235915060208301356138b181613710565b809150509250929050565b803567ffffffffffffffff81168114610d5757600080fd5b60008083601f8401126138e657600080fd5b50813567ffffffffffffffff8111156138fe57600080fd5b602083019150836020828501011115612a0957600080fd5b60008060008060006080868803121561392e57600080fd5b613937866137f9565b9450613945602087016138bc565b9350604086013561395581613710565b9250606086013567ffffffffffffffff81111561397157600080fd5b61397d888289016138d4565b969995985093965092949392505050565b600080604083850312156139a157600080fd5b82356139ac81613710565b915060208301356138b1816137b5565b600080602083850312156139cf57600080fd5b823567ffffffffffffffff808211156139e757600080fd5b818501915085601f8301126139fb57600080fd5b813581811115613a0a57600080fd5b8660208260071b8501011115613a1f57600080fd5b60209290920196919550909350505050565b803561ffff81168114610d5757600080fd5b60008060008060808587031215613a5957600080fd5b613a6285613a31565b9350613a7060208601613a31565b9250613a7e604086016138bc565b91506060850135613a8e81613710565b939692955090935050565b600060208284031215613aab57600080fd5b6132d4826138bc565b600060a08284031215613ac657600080fd5b50919050565b600080600060408486031215613ae157600080fd5b833567ffffffffffffffff80821115613af957600080fd5b613b0587838801613ab4565b94506020860135915080821115613b1b57600080fd5b50613b28868287016138d4565b9497909650939450505050565b60008083601f840112613b4757600080fd5b50813567ffffffffffffffff811115613b5f57600080fd5b6020830191508360208260051b8501011115612a0957600080fd5b60008060208385031215613b8d57600080fd5b823567ffffffffffffffff811115613ba457600080fd5b613bb085828601613b35565b90969095509350505050565b600060208284031215613bce57600080fd5b6132d482613a31565b600080600060408486031215613bec57600080fd5b83359250602084013567ffffffffffffffff811115613c0a57600080fd5b613b28868287016138d4565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602160045260246000fd5b82151581526040810160048310613c85577f4e487b7100000000000000000000000000000000000000000000000000000000600052602160045260246000fd5b8260208301529392505050565b600080600060408486031215613ca757600080fd5b613cb0846137f9565b9250602084013567ffffffffffffffff811115613ccc57600080fd5b613b2886828701613b35565b600080600080600060808688031215613cf057600080fd5b613cf9866137f9565b94506020860135613d0981613710565b9350604086013567ffffffffffffffff811115613d2557600080fd5b613d31888289016138d4565b96999598509660600135949350505050565b600060208284031215613d5557600080fd5b813567ffffffffffffffff811115613d6c57600080fd5b61346284828501613ab4565b8183528181602085013750600060208284010152600060207fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0601f840116840101905092915050565b6000610140613e39838873ffffffffffffffffffffffffffffffffffffffff80825116835263ffffffff6020830151166020840152604082015167ffffffffffffffff808216604086015282606085015116606086015280608085015116608086015250505061ffff60a08201511660a08301525050565b613e7a60c08401875467ffffffffffffffff81168252604081811c61ffff16602084015260509190911c6fffffffffffffffffffffffffffffffff16910152565b806101208401526113d48184018587613d78565b600060208284031215613ea057600080fd5b5051919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052603260045260246000fd5b80356fffffffffffffffffffffffffffffffff81168114610d5757600080fd5b600060208284031215613f0857600080fd5b6132d482613ed6565b6020808252818101839052600090604080840186845b87811015613fa25763ffffffff613f3d836137f9565b16835267ffffffffffffffff613f548684016138bc565b168584015261ffff613f67858401613a31565b168484015260606fffffffffffffffffffffffffffffffff613f8a828501613ed6565b16908401526080928301929190910190600101613f27565b5090979650505050505050565b60005b83811015613fca578181015183820152602001613fb2565b50506000910152565b60008151808452613feb816020860160208601613faf565b601f017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0169290920160200192915050565b6000610140614095838773ffffffffffffffffffffffffffffffffffffffff80825116835263ffffffff6020830151166020840152604082015167ffffffffffffffff808216604086015282606085015116606086015280608085015116608086015250505061ffff60a08201511660a08301525050565b6140d660c08401865467ffffffffffffffff81168252604081811c61ffff16602084015260509190911c6fffffffffffffffffffffffffffffffff16910152565b806101208401526140e981840185613fd3565b9695505050505050565b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff6183360301811261412757600080fd5b9190910192915050565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe184360301811261416657600080fd5b83018035915067ffffffffffffffff82111561418157600080fd5b602001915036819003821315612a0957600080fd5b7fffffffff0000000000000000000000000000000000000000000000000000000081358181169160048510156141d65780818660040360031b1b83161692505b505092915050565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe184360301811261421357600080fd5b830160208101925035905067ffffffffffffffff81111561423357600080fd5b803603821315612a0957600080fd5b6040815263ffffffff614254846137f9565b1660408201526000602084013561426a81613710565b73ffffffffffffffffffffffffffffffffffffffff16606083015261429260408501856141de565b60a060808501526142a760e085018284613d78565b915050606085013560a08401526142c160808601866141de565b7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc08584030160c08601526142f6838284613d78565b93505050508260208301529392505050565b8183823760009101908152919050565b8281526040602082015260006134626040830184613fd3565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b8082028115828204841417610a3557610a35614331565b80820180821115610a3557610a35614331565b6000808585111561439a57600080fd5b838611156143a757600080fd5b5050820193919092039150565b7fffffffff000000000000000000000000000000000000000000000000000000008660e01b1681527fffffffffffffffffffffffffffffffffffffffff0000000000000000000000008560601b1660048201528360188201528183603883013760009101603801908152949350505050565b600067ffffffffffffffff80831681810361444357614443614331565b6001019392505050565b67ffffffffffffffff82811682821603908082111561446e5761446e614331565b5092915050565b67ffffffffffffffff81811683821601908082111561446e5761446e614331565b600067ffffffffffffffff8216806144b0576144b0614331565b7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0192915050565b7f416363657373436f6e74726f6c3a206163636f756e7420000000000000000000815260008351614510816017850160208801613faf565b7f206973206d697373696e6720726f6c6520000000000000000000000000000000601791840191820152835161454d816028840160208801613faf565b01602801949350505050565b6020815260006132d46020830184613fd3565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b6000816145aa576145aa614331565b507fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0190565b6000602082840312156145e257600080fd5b81516132d4816137b5565b60008251614127818460208701613faf56fea2646970667358221220b69fbeb30e38ef1b4b202031c8b88e5d5b004563c7ff42713ed413ed4f4901a664736f6c63430008160033"
  },
  {
    method: "eth_getCode",
    params: [
      "0xfd6865c841c2d64565562fcc7e05e619a30615f0",
      "0x80f2a08"
    ],
    result: "0x60806040526004361061029f5760003560e01c80638585c9451161016e578063c7a823e0116100cb578063d547741f1161007f578063f010cb2311610064578063f010cb2314610906578063f3b4ebd014610926578063fd62e7501461094657600080fd5b8063d547741f146108c6578063dafe0ccc146108e657600080fd5b8063cd88b903116100b0578063cd88b90314610823578063cf34c76814610843578063d2ae21041461088c57600080fd5b8063c7a823e0146107d5578063c7b2370b1461080357600080fd5b8063aef18bf711610122578063c358de0a11610107578063c358de0a14610763578063c416aa5114610783578063c5e193cd146107b557600080fd5b8063aef18bf714610713578063b143044b1461074357600080fd5b806395d376d71161015357806395d376d7146106465780639e94496514610659578063a217fddf146106fe57600080fd5b80638585c945146105d557806391d14854146105f557600080fd5b80632f2ff15d1161021c5780635553fb8e116101d0578063724e78da116101b5578063724e78da14610533578063736c0d5b14610553578063741bef1a1461058357600080fd5b80635553fb8e146104fb5780635c975abb1461051b57600080fd5b806331cb61051161020157806331cb61051461049b57806336568abe146104bb57806352d3b871146104db57600080fd5b80632f2ff15d1461045b57806330bb3aac1461047b57600080fd5b806316c38b3c11610273578063248a9ca311610258578063248a9ca3146103d057806326e67a371461040e5780632de113761461043b57600080fd5b806316c38b3c1461036a5780631703a0181461038a57600080fd5b8062bf2e80146102a457806301e33667146102f857806301ffc9a71461031a5780631095b6d71461034a575b600080fd5b3480156102b057600080fd5b506001546102e0907d010000000000000000000000000000000000000000000000000000000000900461ffff1681565b60405161ffff90911681526020015b60405180910390f35b34801561030457600080fd5b50610318610313366004613732565b610967565b005b34801561032657600080fd5b5061033a610335366004613773565b6109a2565b60405190151581526020016102ef565b34801561035657600080fd5b50610318610365366004613732565b610a3b565b34801561037657600080fd5b506103186103853660046137c3565b610bcb565b34801561039657600080fd5b506005546103b79068010000000000000000900467ffffffffffffffff1681565b60405167ffffffffffffffff90911681526020016102ef565b3480156103dc57600080fd5b506104006103eb3660046137e0565b60009081526020819052604090206001015490565b6040519081526020016102ef565b34801561041a57600080fd5b5061042e61042936600461380d565b610bf0565b6040516102ef9190613828565b34801561044757600080fd5b5061033a61045636600461386f565b610c77565b34801561046757600080fd5b5061031861047636600461388c565b610d5c565b34801561048757600080fd5b50610400610496366004613916565b610eb0565b3480156104a757600080fd5b506103186104b636600461398e565b611027565b3480156104c757600080fd5b506103186104d636600461388c565b61106a565b3480156104e757600080fd5b506103186104f63660046139bc565b61109c565b34801561050757600080fd5b50610400610516366004613a43565b611268565b34801561052757600080fd5b5060015460ff1661033a565b34801561053f57600080fd5b5061031861054e36600461386f565b6113df565b34801561055f57600080fd5b5061033a61056e36600461386f565b60046020526000908152604090205460ff1681565b34801561058f57600080fd5b506002546105b09073ffffffffffffffffffffffffffffffffffffffff1681565b60405173ffffffffffffffffffffffffffffffffffffffff90911681526020016102ef565b3480156105e157600080fd5b506103186105f0366004613a99565b611484565b34801561060157600080fd5b5061033a61061036600461388c565b60009182526020828152604080842073ffffffffffffffffffffffffffffffffffffffff93909316845291905290205460ff1690565b610400610654366004613acc565b6114c9565b34801561066557600080fd5b506106c361067436600461380d565b60066020526000908152604090205467ffffffffffffffff81169068010000000000000000810461ffff16906a010000000000000000000090046fffffffffffffffffffffffffffffffff1683565b6040805167ffffffffffffffff909416845261ffff90921660208401526fffffffffffffffffffffffffffffffff16908201526060016102ef565b34801561070a57600080fd5b50610400600081565b34801561071f57600080fd5b5061033a61072e3660046137e0565b60076020526000908152604090205460ff1681565b34801561074f57600080fd5b5061031861075e366004613b7a565b6116a5565b34801561076f57600080fd5b5061031861077e366004613bbc565b6119b5565b34801561078f57600080fd5b506001546105b090610100900473ffffffffffffffffffffffffffffffffffffffff1681565b3480156107c157600080fd5b506104006107d0366004613a43565b611a63565b3480156107e157600080fd5b506107f56107f0366004613bd7565b611c41565b6040516102ef929190613c45565b34801561080f57600080fd5b5061031861081e36600461386f565b611e51565b34801561082f57600080fd5b5061031861083e366004613c92565b611ef5565b34801561084f57600080fd5b506108777f000000000000000000000000000000000000000000000000000000000000006681565b60405163ffffffff90911681526020016102ef565b34801561089857600080fd5b506001546103b7907501000000000000000000000000000000000000000000900467ffffffffffffffff1681565b3480156108d257600080fd5b506103186108e136600461388c565b611f46565b3480156108f257600080fd5b50610318610901366004613732565b61205b565b34801561091257600080fd5b50610400610921366004613cd8565b612191565b34801561093257600080fd5b50610318610941366004613d43565b6121cd565b34801561095257600080fd5b506005546103b79067ffffffffffffffff1681565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c2177561099181612442565b61099c84848461244c565b50505050565b60007fffffffff0000000000000000000000000000000000000000000000000000000082167f7965db0b000000000000000000000000000000000000000000000000000000001480610a3557507f01ffc9a7000000000000000000000000000000000000000000000000000000007fffffffff000000000000000000000000000000000000000000000000000000008316145b92915050565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775610a6581612442565b73ffffffffffffffffffffffffffffffffffffffff841660009081527f9b50f4667d2d24216ccbf0dce3a90c0f620fa4d895e7b069d80ff6247fd25620602052604090205460ff16610ae3576040517f5ee08b9700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040517ffd9be52200000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff84811660048301526024820184905285169063fd9be52290604401600060405180830381600087803b158015610b5357600080fd5b505af1158015610b67573d6000803e3d6000fd5b50506040805173ffffffffffffffffffffffffffffffffffffffff8089168252871660208201529081018590527f9b1bfa7fa9ee420a16e124f794c35ac9f90472acc99140eb2f6447c714cad8eb925060600190505b60405180910390a150505050565b6000610bd681612442565b8115610be857610be461247c565b5050565b610be46124fb565b63ffffffff8116600090815260036020908152604091829020805483518184028101840190945280845260609392830182828015610c6b57602002820191906000526020600020906000905b825461010083900a900460ff16815260206001928301818104948501949093039092029101808411610c3c5790505b50505050509050919050565b73ffffffffffffffffffffffffffffffffffffffff811660009081527f93c430521711328044ae92d0f1f1286cf040bc4a382f1642bd89984e86630553602052604081205460ff1615610ccc57506000919050565b6001547501000000000000000000000000000000000000000000900467ffffffffffffffff161580610d42575073ffffffffffffffffffffffffffffffffffffffff821660009081527f4ac82e3087b7dedf7f532cbc6915c722df8c1e31f1388c318a617b52760eaf8b602052604090205460ff165b15610d4f57506001919050565b506000919050565b919050565b817f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca811480610daa57507f4270fae16c6d150d00e80b689daca99e8073b1838ff2b6063a37be9d851283e481145b80610dd457507f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de81145b15610e1757303314610e12576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610ea1565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217758103610e6757610e127fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775612442565b6040517f94fdc372000000000000000000000000000000000000000000000000000000008152600481018290526024015b60405180910390fd5b610eab8383612552565b505050565b600083610ebc81610c77565b610ef2576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c08101825260025473ffffffffffffffffffffffffffffffffffffffff908116825263ffffffff8a16602080840182905267ffffffffffffffff808c16858701528a8416606086015260055468010000000000000000900416608085015260015461ffff7d01000000000000000000000000000000000000000000000000000000000082041660a0860152600092835260069091529084902093517f7bfa20a9000000000000000000000000000000000000000000000000000000008152929361010090910490911691637bfa20a991610fda918591908a908a90600401613dc1565b602060405180830381865afa158015610ff7573d6000803e3d6000fd5b505050506040513d601f19601f8201168201806040525081019061101b9190613e8e565b98975050505050505050565b303314611060576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610be48282612618565b6040517fdec9f03100000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217756110c681612442565b60005b8281101561122957368484838181106110e4576110e4613ea7565b9050608002019050604051806060016040528082602001602081019061110a9190613a99565b67ffffffffffffffff1681526020016111296060840160408501613bbc565b61ffff1681526020016111426080840160608501613ef6565b6fffffffffffffffffffffffffffffffff16905260066000611167602085018561380d565b63ffffffff1681526020808201929092526040908101600020835181549385015194909201516fffffffffffffffffffffffffffffffff166a0100000000000000000000027fffffffffffff00000000000000000000000000000000ffffffffffffffffffff61ffff90951668010000000000000000027fffffffffffffffffffffffffffffffffffffffffffff0000000000000000000090941667ffffffffffffffff909316929092179290921792909216919091179055506001016110c9565b507f7dd21e42791b013d1929e86f0c59085e4fca24251f0f1aa81917b3b1611766e0838360405161125b929190613f11565b60405180910390a1505050565b60008161127481610c77565b6112aa576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c08101825260025473ffffffffffffffffffffffffffffffffffffffff908116825261ffff808a16602080850182905267ffffffffffffffff808b168688015289851660608701526005546801000000000000000090041660808601526001547d010000000000000000000000000000000000000000000000000000000000810490931660a08601526000918252600681528582208651918201875291815294517f7bfa20a9000000000000000000000000000000000000000000000000000000008152939461010090920490921692637bfa20a99261139392869260040161401d565b602060405180830381865afa1580156113b0573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052508101906113d49190613e8e565b979650505050505050565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c2177561140981612442565b600280547fffffffffffffffffffffffff00000000000000000000000000000000000000001673ffffffffffffffffffffffffffffffffffffffff84169081179091556040519081527ff724a45d041687842411f2b977ef22ab8f43c8f1104f4592b42a00f9b34a643d906020015b60405180910390a15050565b3033146114bd576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6114c681612818565b50565b60007f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de6114f581612442565b61150560a086016080870161386f565b61150e81610c77565b611544576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c0810190915260025473ffffffffffffffffffffffffffffffffffffffff16815260009060208082019061157f908a018a61380d565b63ffffffff16815260200161159a60808a0160608b01613a99565b67ffffffffffffffff1681526020016115b960a08a0160808b0161386f565b73ffffffffffffffffffffffffffffffffffffffff908116825260055468010000000000000000900467ffffffffffffffff166020808401919091526001547d010000000000000000000000000000000000000000000000000000000000810461ffff16604090940193909352929350610100909104169063df2b057e90839060069060009061164b908d018d61380d565b63ffffffff1663ffffffff16815260200190815260200160002089896040518563ffffffff1660e01b81526004016116869493929190613dc1565b6020604051808303816000875af11580156113b0573d6000803e3d6000fd5b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217756116cf81612442565b60005b8281101561099c57368484838181106116ed576116ed613ea7565b90506020028101906116ff91906140f3565b905063ffffffff7f000000000000000000000000000000000000000000000000000000000000006616611735602083018361380d565b63ffffffff161461174657506119ad565b4281606001351161175757506119ad565b6000611790611769602084018461380d565b611779604085016020860161386f565b6117866040860186614131565b8660600135612191565b905060006117a5826107f06080860186614131565b509050806117e8576040518481527fd6d90193101048cc1b6edcdc2348f5acf7a4a4a97d3e7b668b74cb7602ab3ebc9060200160405180910390a15050506119ad565b60006118086117fa6040860186614131565b61180391614196565b612930565b905080156118a15760008381526007602052604090205460ff1615611869577f9bb9bddbdf537a2104255307230b323d7982f4512ee8e5bd15df62ddca50ab978484604051611858929190614242565b60405180910390a1505050506119ad565b600083815260076020526040902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff001660011790555b6000806118b4604087016020880161386f565b73ffffffffffffffffffffffffffffffffffffffff166118d76040880188614131565b6040516118e5929190614308565b6000604051808303816000865af19150503d8060008114611922576040519150601f19603f3d011682016040523d82523d6000602084013e611927565b606091505b5091509150816119a657821561196c57600085815260076020526040902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff001690555b7fdc8cdd96296241bbefda4a8e18ad2e0985a8da6495b34d409cfc4c886ee3b0cf878260405161199d929190614318565b60405180910390a15b5050505050505b6001016116d2565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217756119df81612442565b600180547fff0000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffff167d01000000000000000000000000000000000000000000000000000000000061ffff8516908102919091179091556040519081527f7af0ac740036ffb1c97b03697859d729e80a44ae5030543d64971c313565ab4d90602001611478565b60007f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de611a8f81612442565b82611a9981610c77565b611acf576040517f4ab5ebcd00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040805160c08101825260025473ffffffffffffffffffffffffffffffffffffffff908116825261ffff808b16602080850182905267ffffffffffffffff808c16868801528a851660608701526005546801000000000000000090041660808601526001547d010000000000000000000000000000000000000000000000000000000000810490931660a08601526000918252600681528582208651918201875291815294517fdf2b057e00000000000000000000000000000000000000000000000000000000815293946101009092049092169263df2b057e92611bb892869260040161401d565b6020604051808303816000875af1158015611bd7573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250810190611bfb9190613e8e565b93507f87e46b0a6199bc734632187269a103c05714ee0adae5b28f30723955724f37ef84604051611c2e91815260200190565b60405180910390a1505050949350505050565b6005546000908190611c6a9068010000000000000000900467ffffffffffffffff166041614360565b8314611c7c5750600090506001611e49565b6000611cd5866040517f19457468657265756d205369676e6564204d6573736167653a0a3332000000006020820152603c8101829052600090605c01604051602081830303815290604052805190602001209050919050565b90506000805b60055468010000000000000000900467ffffffffffffffff16811015611e3d573660008888611d0b856041614360565b90611d17866001614377565b611d22906041614360565b92611d2f9392919061438a565b91509150600080611d768785858080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920191909152506129cb92505050565b90925090506000816004811115611d8f57611d8f613c16565b14611da857600060019850985050505050505050611e49565b8573ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1611611def57600060029850985050505050505050611e49565b73ffffffffffffffffffffffffffffffffffffffff821660009081526004602052604090205460ff16611e3057600060039850985050505050505050611e49565b5093505050600101611cdb565b50600160009350935050505b935093915050565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775611e7b81612442565b600180547fffffffffffffffffffffff0000000000000000000000000000000000000000ff1661010073ffffffffffffffffffffffffffffffffffffffff8516908102919091179091556040519081527f1399be28223800f8669b3ba5f8721d9fc16fc4e8d0bbf98378791c8c5a3015e090602001611478565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775611f1f81612442565b63ffffffff84166000908152600360205260409020611f3f908484613652565b5050505050565b817f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca811480611f9457507f4270fae16c6d150d00e80b689daca99e8073b1838ff2b6063a37be9d851283e481145b80611fbe57507f724aface199fe5bed93ae8508474576a9adf3dc443b2c451842a2242919f19de81145b1561200157303314611ffc576040517ffaba723a00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b612051565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217758103610e6757611ffc7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c21775612442565b610eab8383612a10565b7fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c2177561208581612442565b73ffffffffffffffffffffffffffffffffffffffff841660009081527f9b50f4667d2d24216ccbf0dce3a90c0f620fa4d895e7b069d80ff6247fd25620602052604090205460ff16612103576040517f5ee08b9700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b6040517f07b18bde00000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff8481166004830152602482018490528516906307b18bde90604401600060405180830381600087803b15801561217357600080fd5b505af1158015612187573d6000803e3d6000fd5b5050505050505050565b600085858386866040516020016121ac9594939291906143b4565b60405160208183030381529060405280519060200120905095945050505050565b4281606001351161220a576040517f0bbaf26300000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b3061221b604083016020840161386f565b73ffffffffffffffffffffffffffffffffffffffff161461229157612246604082016020830161386f565b6040517f1ce0bfcd00000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff9091166004820152602401610e98565b63ffffffff7f0000000000000000000000000000000000000000000000000000000000000066166122c5602083018361380d565b63ffffffff1614612318576122dd602082018261380d565b6040517f2697e1c200000000000000000000000000000000000000000000000000000000815263ffffffff9091166004820152602401610e98565b600061232a611769602084018461380d565b9050600061233f826107f06080860186614131565b50905080612379576040517f15ecadee00000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60008281526007602052604090205460ff16156123c5576040517f9d6a45a600000000000000000000000000000000000000000000000000000000815260048101839052602401610e98565b6000828152600760205260409081902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00166001179055610eab907fa49807205ce4d355092ef5a8a18f56e8913cf4a201fbe287825b095693c217759061243090860186614131565b81019061243d919061386f565b612552565b6114c68133612ad5565b73ffffffffffffffffffffffffffffffffffffffff831661247157610eab8282612b8d565b610eab838383612c93565b612484612d01565b600180547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0016811790557f62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258335b60405173ffffffffffffffffffffffffffffffffffffffff909116815260200160405180910390a1565b612503612d70565b600180547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff001690557f5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa336124d1565b7f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca821480156125af575060008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff16155b1561260e57600180546015906125e7907501000000000000000000000000000000000000000000900467ffffffffffffffff16614426565b91906101000a81548167ffffffffffffffff021916908367ffffffffffffffff1602179055505b610be48282612ddc565b73ffffffffffffffffffffffffffffffffffffffff821660009081526004602052604090205481151560ff90911615150361269f576040517f58c8d2a000000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff831660048201528115156024820152604401610e98565b73ffffffffffffffffffffffffffffffffffffffff8216600090815260046020526040812080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0016831515179055816127115760055461270c9060019067ffffffffffffffff1661444d565b612729565b6005546127299067ffffffffffffffff166001614475565b60055490915067ffffffffffffffff680100000000000000009091048116908216811115612797576040517ff1c582ae00000000000000000000000000000000000000000000000000000000815267ffffffffffffffff808416600483015282166024820152604401610e98565b600580547fffffffffffffffffffffffffffffffffffffffffffffffff00000000000000001667ffffffffffffffff84161790556040805173ffffffffffffffffffffffffffffffffffffffff8616815284151560208201527f863d338cad74814b108a06288ad5e0e80d56495e0332238b1d2cdcfa0ca8e5ce9101610bbd565b8067ffffffffffffffff1660000361285c576040517f5f86e17700000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60055467ffffffffffffffff9081169082168110156128bb576040517ff1c582ae00000000000000000000000000000000000000000000000000000000815267ffffffffffffffff808316600483015283166024820152604401610e98565b600580547fffffffffffffffffffffffffffffffff0000000000000000ffffffffffffffff166801000000000000000067ffffffffffffffff8516908102919091179091556040519081527fb600f3cf7f38a4b49bb0c75f722ef69f7e3e39ef3bb4aa8207fd86e724a2324990602001611478565b60007fffffffff0000000000000000000000000000000000000000000000000000000082167f0223536e0000000000000000000000000000000000000000000000000000000014801590610a3557507fffffffff0000000000000000000000000000000000000000000000000000000082167f704316e500000000000000000000000000000000000000000000000000000000141592915050565b6000808251604103612a015760208301516040840151606085015160001a6129f587828585612ecc565b94509450505050612a09565b506000905060025b9250929050565b7f74845de37cfabd357633214b47fa91ccd19b05b7c5a08ac22c187f811fb62bca82148015612a6c575060008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff165b15612acb5760018054601590612aa4907501000000000000000000000000000000000000000000900467ffffffffffffffff16614496565b91906101000a81548167ffffffffffffffff021916908367ffffffffffffffff1602179055505b610be48282612fbb565b60008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff16610be457612b1381613072565b612b1e836020613091565b604051602001612b2f9291906144d8565b604080517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0818403018152908290527f08c379a0000000000000000000000000000000000000000000000000000000008252610e9891600401614559565b73ffffffffffffffffffffffffffffffffffffffff8216612bda576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b60008273ffffffffffffffffffffffffffffffffffffffff168260405160006040518083038185875af1925050503d8060008114612c34576040519150601f19603f3d011682016040523d82523d6000602084013e612c39565b606091505b5050905080610eab576040517f465bc83400000000000000000000000000000000000000000000000000000000815273ffffffffffffffffffffffffffffffffffffffff8416600482015260248101839052604401610e98565b73ffffffffffffffffffffffffffffffffffffffff8216612ce0576040517f6b7a931000000000000000000000000000000000000000000000000000000000815260040160405180910390fd5b610eab73ffffffffffffffffffffffffffffffffffffffff841683836132db565b60015460ff1615612d6e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601060248201527f5061757361626c653a20706175736564000000000000000000000000000000006044820152606401610e98565b565b60015460ff16612d6e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601460248201527f5061757361626c653a206e6f74207061757365640000000000000000000000006044820152606401610e98565b60008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff16610be45760008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff85168452909152902080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00166001179055612e6e3390565b73ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff16837f2f8788117e7eff1d82e926ec794901d17c78024a50270940304540a733656f0d60405160405180910390a45050565b6000807f7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a0831115612f035750600090506003612fb2565b6040805160008082526020820180845289905260ff881692820192909252606081018690526080810185905260019060a0016020604051602081039080840390855afa158015612f57573d6000803e3d6000fd5b50506040517fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0015191505073ffffffffffffffffffffffffffffffffffffffff8116612fab57600060019250925050612fb2565b9150600090505b94509492505050565b60008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516845290915290205460ff1615610be45760008281526020818152604080832073ffffffffffffffffffffffffffffffffffffffff8516808552925280832080547fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0016905551339285917ff6391f5c32d9c69d2a47ea670b442974b53935d1edc7fd64eb21e047a839171b9190a45050565b6060610a3573ffffffffffffffffffffffffffffffffffffffff831660145b606060006130a0836002614360565b6130ab906002614377565b67ffffffffffffffff8111156130c3576130c361456c565b6040519080825280601f01601f1916602001820160405280156130ed576020820181803683370190505b5090507f30000000000000000000000000000000000000000000000000000000000000008160008151811061312457613124613ea7565b60200101907effffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916908160001a9053507f78000000000000000000000000000000000000000000000000000000000000008160018151811061318757613187613ea7565b60200101907effffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916908160001a90535060006131c3846002614360565b6131ce906001614377565b90505b600181111561326b577f303132333435363738396162636465660000000000000000000000000000000085600f166010811061320f5761320f613ea7565b1a60f81b82828151811061322557613225613ea7565b60200101907effffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916908160001a90535060049490941c936132648161459b565b90506131d1565b5083156132d4576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820181905260248201527f537472696e67733a20686578206c656e67746820696e73756666696369656e746044820152606401610e98565b9392505050565b6040805173ffffffffffffffffffffffffffffffffffffffff848116602483015260448083018590528351808403909101815260649092018352602080830180517bffffffffffffffffffffffffffffffffffffffffffffffffffffffff167fa9059cbb0000000000000000000000000000000000000000000000000000000017905283518085019094528084527f5361666545524332303a206c6f772d6c6576656c2063616c6c206661696c656490840152610eab928692916000916133a6918516908490613453565b90508051600014806133c75750808060200190518101906133c791906145d0565b610eab576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602a60248201527f5361666545524332303a204552433230206f7065726174696f6e20646964206e60448201527f6f742073756363656564000000000000000000000000000000000000000000006064820152608401610e98565b6060613462848460008561346a565b949350505050565b6060824710156134fc576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152602660248201527f416464726573733a20696e73756666696369656e742062616c616e636520666f60448201527f722063616c6c00000000000000000000000000000000000000000000000000006064820152608401610e98565b6000808673ffffffffffffffffffffffffffffffffffffffff16858760405161352591906145ed565b60006040518083038185875af1925050503d8060008114613562576040519150601f19603f3d011682016040523d82523d6000602084013e613567565b606091505b50915091506113d487838387606083156136095782516000036136025773ffffffffffffffffffffffffffffffffffffffff85163b613602576040517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601d60248201527f416464726573733a2063616c6c20746f206e6f6e2d636f6e74726163740000006044820152606401610e98565b5081613462565b613462838381511561361e5781518083602001fd5b806040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610e989190614559565b82805482825590600052602060002090601f016020900481019282156136eb5791602002820160005b838211156136bc57833560ff1683826101000a81548160ff021916908360ff160217905550926020019260010160208160000104928301926001030261367b565b80156136e95782816101000a81549060ff02191690556001016020816000010492830192600103026136bc565b505b506136f79291506136fb565b5090565b5b808211156136f757600081556001016136fc565b73ffffffffffffffffffffffffffffffffffffffff811681146114c657600080fd5b60008060006060848603121561374757600080fd5b833561375281613710565b9250602084013561376281613710565b929592945050506040919091013590565b60006020828403121561378557600080fd5b81357fffffffff00000000000000000000000000000000000000000000000000000000811681146132d457600080fd5b80151581146114c657600080fd5b6000602082840312156137d557600080fd5b81356132d4816137b5565b6000602082840312156137f257600080fd5b5035919050565b803563ffffffff81168114610d5757600080fd5b60006020828403121561381f57600080fd5b6132d4826137f9565b6020808252825182820181905260009190848201906040850190845b8181101561386357835160ff1683529284019291840191600101613844565b50909695505050505050565b60006020828403121561388157600080fd5b81356132d481613710565b6000806040838503121561389f57600080fd5b8235915060208301356138b181613710565b809150509250929050565b803567ffffffffffffffff81168114610d5757600080fd5b60008083601f8401126138e657600080fd5b50813567ffffffffffffffff8111156138fe57600080fd5b602083019150836020828501011115612a0957600080fd5b60008060008060006080868803121561392e57600080fd5b613937866137f9565b9450613945602087016138bc565b9350604086013561395581613710565b9250606086013567ffffffffffffffff81111561397157600080fd5b61397d888289016138d4565b969995985093965092949392505050565b600080604083850312156139a157600080fd5b82356139ac81613710565b915060208301356138b1816137b5565b600080602083850312156139cf57600080fd5b823567ffffffffffffffff808211156139e757600080fd5b818501915085601f8301126139fb57600080fd5b813581811115613a0a57600080fd5b8660208260071b8501011115613a1f57600080fd5b60209290920196919550909350505050565b803561ffff81168114610d5757600080fd5b60008060008060808587031215613a5957600080fd5b613a6285613a31565b9350613a7060208601613a31565b9250613a7e604086016138bc565b91506060850135613a8e81613710565b939692955090935050565b600060208284031215613aab57600080fd5b6132d4826138bc565b600060a08284031215613ac657600080fd5b50919050565b600080600060408486031215613ae157600080fd5b833567ffffffffffffffff80821115613af957600080fd5b613b0587838801613ab4565b94506020860135915080821115613b1b57600080fd5b50613b28868287016138d4565b9497909650939450505050565b60008083601f840112613b4757600080fd5b50813567ffffffffffffffff811115613b5f57600080fd5b6020830191508360208260051b8501011115612a0957600080fd5b60008060208385031215613b8d57600080fd5b823567ffffffffffffffff811115613ba457600080fd5b613bb085828601613b35565b90969095509350505050565b600060208284031215613bce57600080fd5b6132d482613a31565b600080600060408486031215613bec57600080fd5b83359250602084013567ffffffffffffffff811115613c0a57600080fd5b613b28868287016138d4565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052602160045260246000fd5b82151581526040810160048310613c85577f4e487b7100000000000000000000000000000000000000000000000000000000600052602160045260246000fd5b8260208301529392505050565b600080600060408486031215613ca757600080fd5b613cb0846137f9565b9250602084013567ffffffffffffffff811115613ccc57600080fd5b613b2886828701613b35565b600080600080600060808688031215613cf057600080fd5b613cf9866137f9565b94506020860135613d0981613710565b9350604086013567ffffffffffffffff811115613d2557600080fd5b613d31888289016138d4565b96999598509660600135949350505050565b600060208284031215613d5557600080fd5b813567ffffffffffffffff811115613d6c57600080fd5b61346284828501613ab4565b8183528181602085013750600060208284010152600060207fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0601f840116840101905092915050565b6000610140613e39838873ffffffffffffffffffffffffffffffffffffffff80825116835263ffffffff6020830151166020840152604082015167ffffffffffffffff808216604086015282606085015116606086015280608085015116608086015250505061ffff60a08201511660a08301525050565b613e7a60c08401875467ffffffffffffffff81168252604081811c61ffff16602084015260509190911c6fffffffffffffffffffffffffffffffff16910152565b806101208401526113d48184018587613d78565b600060208284031215613ea057600080fd5b5051919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052603260045260246000fd5b80356fffffffffffffffffffffffffffffffff81168114610d5757600080fd5b600060208284031215613f0857600080fd5b6132d482613ed6565b6020808252818101839052600090604080840186845b87811015613fa25763ffffffff613f3d836137f9565b16835267ffffffffffffffff613f548684016138bc565b168584015261ffff613f67858401613a31565b168484015260606fffffffffffffffffffffffffffffffff613f8a828501613ed6565b16908401526080928301929190910190600101613f27565b5090979650505050505050565b60005b83811015613fca578181015183820152602001613fb2565b50506000910152565b60008151808452613feb816020860160208601613faf565b601f017fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe0169290920160200192915050565b6000610140614095838773ffffffffffffffffffffffffffffffffffffffff80825116835263ffffffff6020830151166020840152604082015167ffffffffffffffff808216604086015282606085015116606086015280608085015116608086015250505061ffff60a08201511660a08301525050565b6140d660c08401865467ffffffffffffffff81168252604081811c61ffff16602084015260509190911c6fffffffffffffffffffffffffffffffff16910152565b806101208401526140e981840185613fd3565b9695505050505050565b600082357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff6183360301811261412757600080fd5b9190910192915050565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe184360301811261416657600080fd5b83018035915067ffffffffffffffff82111561418157600080fd5b602001915036819003821315612a0957600080fd5b7fffffffff0000000000000000000000000000000000000000000000000000000081358181169160048510156141d65780818660040360031b1b83161692505b505092915050565b60008083357fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe184360301811261421357600080fd5b830160208101925035905067ffffffffffffffff81111561423357600080fd5b803603821315612a0957600080fd5b6040815263ffffffff614254846137f9565b1660408201526000602084013561426a81613710565b73ffffffffffffffffffffffffffffffffffffffff16606083015261429260408501856141de565b60a060808501526142a760e085018284613d78565b915050606085013560a08401526142c160808601866141de565b7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffc08584030160c08601526142f6838284613d78565b93505050508260208301529392505050565b8183823760009101908152919050565b8281526040602082015260006134626040830184613fd3565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052601160045260246000fd5b8082028115828204841417610a3557610a35614331565b80820180821115610a3557610a35614331565b6000808585111561439a57600080fd5b838611156143a757600080fd5b5050820193919092039150565b7fffffffff000000000000000000000000000000000000000000000000000000008660e01b1681527fffffffffffffffffffffffffffffffffffffffff0000000000000000000000008560601b1660048201528360188201528183603883013760009101603801908152949350505050565b600067ffffffffffffffff80831681810361444357614443614331565b6001019392505050565b67ffffffffffffffff82811682821603908082111561446e5761446e614331565b5092915050565b67ffffffffffffffff81811683821601908082111561446e5761446e614331565b600067ffffffffffffffff8216806144b0576144b0614331565b7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0192915050565b7f416363657373436f6e74726f6c3a206163636f756e7420000000000000000000815260008351614510816017850160208801613faf565b7f206973206d697373696e6720726f6c6520000000000000000000000000000000601791840191820152835161454d816028840160208801613faf565b01602801949350505050565b6020815260006132d46020830184613fd3565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fd5b6000816145aa576145aa614331565b507fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0190565b6000602082840312156145e257600080fd5b81516132d4816137b5565b60008251614127818460208701613faf56fea2646970667358221220b69fbeb30e38ef1b4b202031c8b88e5d5b004563c7ff42713ed413ed4f4901a664736f6c63430008160033"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x1a44076050125825900e736c501f859c50fe728c",
        data: "0xdc93c8a200000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa"
      },
      "0x80f2a08"
    ],
    result: "0x0000000000000000000000000000000000000000000000000000000000000000"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x9f8c645f2d0b2159767bd6e0839de4be49e823de",
        data: "0x39e3f93800000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa"
      },
      "0x80f2a08"
    ],
    result: "0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0xb217266c3a98c8b2709ee26836c98cf12f6ccec1",
        data: "0x39e3f93800000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa"
      },
      "0x80f2a08"
    ],
    result: "0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x1a44076050125825900e736c501f859c50fe728c",
        data: "0xb96a277f00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa"
      },
      "0x80f2a08"
    ],
    result: "0x0000000000000000000000009f8c645f2d0b2159767bd6e0839de4be49e823de"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x1a44076050125825900e736c501f859c50fe728c",
        data: "0x402f846800000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa"
      },
      "0x80f2a08"
    ],
    result: "0x000000000000000000000000b217266c3a98c8b2709ee26836c98cf12f6ccec10000000000000000000000000000000000000000000000000000000000000000"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x1a44076050125825900e736c501f859c50fe728c",
        data: "0x587cde1e00000000000000000000000074c20deb476dca58459956b1acd65771197900c9"
      },
      "0x80f2a08"
    ],
    result: "0x000000000000000000000000f2ab1eebbecb4e315fe95d8b532d1ab00f1a8789"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x1a44076050125825900e736c501f859c50fe728c",
        data: "0x2b3197b900000000000000000000000074c20deb476dca58459956b1acd65771197900c90000000000000000000000009f8c645f2d0b2159767bd6e0839de4be49e823de00000000000000000000000000000000000000000000000000000000000076aa0000000000000000000000000000000000000000000000000000000000000001"
      },
      "0x80f2a08"
    ],
    result: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000027100000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d584859"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x1a44076050125825900e736c501f859c50fe728c",
        data: "0x2b3197b900000000000000000000000074c20deb476dca58459956b1acd65771197900c90000000000000000000000009f8c645f2d0b2159767bd6e0839de4be49e823de00000000000000000000000000000000000000000000000000000000000076aa0000000000000000000000000000000000000000000000000000000000000002"
      },
      "0x80f2a08"
    ],
    result: "0x000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000"
  },
  {
    method: "eth_call",
    params: [
      {
        to: "0x1a44076050125825900e736c501f859c50fe728c",
        data: "0x2b3197b900000000000000000000000074c20deb476dca58459956b1acd65771197900c9000000000000000000000000b217266c3a98c8b2709ee26836c98cf12f6ccec100000000000000000000000000000000000000000000000000000000000076aa0000000000000000000000000000000000000000000000000000000000000002"
      },
      "0x80f2a08"
    ],
    result: "0x000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000"
  }
];

// docs/multichain/generation-milestone/bnb-configuration-completed/user-receipt.json
var user_receipt_default2 = {
  chainId: 56,
  admin: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789",
  adapterAddress: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
  passAddress: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
  suiPeer: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
  route: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
  transactionHashes: [
    "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733",
    "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
    "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
    "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b"
  ],
  totalGasFeeWei: "23726950000000",
  purchasesPaused: true,
  state: "Unconfirmed",
  generation: 0,
  receipts: [
    {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xb7bc22",
      logs: [
        {
          address: "0x1a44076050125825900e736c501f859c50fe728c",
          topics: [
            "0x4cff966ebee29a156dcb34cf72c1d06231fb1777f6bdf6e8089819232f002b1c"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa0000000000000000000000009f8c645f2d0b2159767bd6e0839de4be49e823de",
          blockHash: "0x32c2401f1aeefe07a6f0677c12f9773f7111a7c9864494576c6fc90e6783e06e",
          blockNumber: "0x80f284f",
          blockTimestamp: "0x6b03c7f6",
          transactionHash: "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733",
          transactionIndex: "0x48",
          logIndex: "0x278",
          removed: false
        }
      ],
      logsBloom: "0x00000000000000000000000000000000000200000000000000000000001000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000010000000000000000000000",
      transactionHash: "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733",
      transactionIndex: "0x48",
      blockHash: "0x32c2401f1aeefe07a6f0677c12f9773f7111a7c9864494576c6fc90e6783e06e",
      blockNumber: "0x80f284f",
      gasUsed: "0xe182",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      contractAddress: null
    },
    {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xdd31b4",
      logs: [
        {
          address: "0x1a44076050125825900e736c501f859c50fe728c",
          topics: [
            "0xcd6f92f5ac6185a5acfa02c92090746cec64d777269cbcd0ed031e396657a1c2"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa000000000000000000000000b217266c3a98c8b2709ee26836c98cf12f6ccec1",
          blockHash: "0x01d61db291f2a96de861f0456be9ebe65d7e1024813935ee80dc371e5930b9ec",
          blockNumber: "0x80f28b4",
          blockTimestamp: "0x6b03c823",
          transactionHash: "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
          transactionIndex: "0x4a",
          logIndex: "0x397",
          removed: false
        },
        {
          address: "0x1a44076050125825900e736c501f859c50fe728c",
          topics: [
            "0x4e0a5bbfa0c11a64effb1ada324b5437a17272e1aed9320398715ef71bb20928"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
          blockHash: "0x01d61db291f2a96de861f0456be9ebe65d7e1024813935ee80dc371e5930b9ec",
          blockNumber: "0x80f28b4",
          blockTimestamp: "0x6b03c823",
          transactionHash: "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
          transactionIndex: "0x4a",
          logIndex: "0x398",
          removed: false
        }
      ],
      logsBloom: "0x00000000000000000000020800000000000000000000000000000000001000020400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000010000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000",
      transactionHash: "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
      transactionIndex: "0x4a",
      blockHash: "0x01d61db291f2a96de861f0456be9ebe65d7e1024813935ee80dc371e5930b9ec",
      blockNumber: "0x80f28b4",
      gasUsed: "0xfb95",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      contractAddress: null
    },
    {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xd70964",
      logs: [
        {
          address: "0x9f8c645f2d0b2159767bd6e0839de4be49e823de",
          topics: [
            "0x779cb2dd9d2bb1be1737d05435d744facbfb84a2a4912e21379d39beddcdc805"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000027100000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d584859",
          blockHash: "0x7adc0bd86b3ae8d76fd931a3cb0ed6de5dfdb06592f7ca58ddf5fe7bcdd1eaf1",
          blockNumber: "0x80f28fd",
          blockTimestamp: "0x6b03c844",
          transactionHash: "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
          transactionIndex: "0x40",
          logIndex: "0x16d",
          removed: false
        },
        {
          address: "0x9f8c645f2d0b2159767bd6e0839de4be49e823de",
          topics: [
            "0x82118522aa536ac0e96cc5c689407ae42b89d592aa133890a01f1509842f5081"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000",
          blockHash: "0x7adc0bd86b3ae8d76fd931a3cb0ed6de5dfdb06592f7ca58ddf5fe7bcdd1eaf1",
          blockNumber: "0x80f28fd",
          blockTimestamp: "0x6b03c844",
          transactionHash: "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
          transactionIndex: "0x40",
          logIndex: "0x16e",
          removed: false
        }
      ],
      logsBloom: "0x00000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000004000000000200000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000010",
      transactionHash: "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
      transactionIndex: "0x40",
      blockHash: "0x7adc0bd86b3ae8d76fd931a3cb0ed6de5dfdb06592f7ca58ddf5fe7bcdd1eaf1",
      blockNumber: "0x80f28fd",
      gasUsed: "0x2e6d7",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      contractAddress: null
    },
    {
      type: "0x2",
      status: "0x1",
      cumulativeGasUsed: "0xd33a33",
      logs: [
        {
          address: "0xb217266c3a98c8b2709ee26836c98cf12f6ccec1",
          topics: [
            "0x82118522aa536ac0e96cc5c689407ae42b89d592aa133890a01f1509842f5081"
          ],
          data: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c900000000000000000000000000000000000000000000000000000000000076aa00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000",
          blockHash: "0xefdbd3dae7b5381ca1f0d85cad46718451319872283f5683c44930be1a67de4d",
          blockNumber: "0x80f293f",
          blockTimestamp: "0x6b03c862",
          transactionHash: "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b",
          transactionIndex: "0x40",
          logIndex: "0x1f4",
          removed: false
        }
      ],
      logsBloom: "0x00002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000000000000010",
      transactionHash: "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b",
      transactionIndex: "0x40",
      blockHash: "0xefdbd3dae7b5381ca1f0d85cad46718451319872283f5683c44930be1a67de4d",
      blockNumber: "0x80f293f",
      gasUsed: "0x279bd",
      effectiveGasPrice: "0x2faf080",
      from: "0xf2ab1eebbecb4e315fe95d8b532d1ab00f1a8789",
      to: "0x1a44076050125825900e736c501f859c50fe728c",
      contractAddress: null
    }
  ],
  configurationSettings: {
    defaultSendLibrary: false,
    rawSendSecurity: "0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000",
    rawReceiveSecurity: "0x00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000ff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000",
    sendLibrary: "0x9F8C645f2D0b2159767Bd6E0839DE4BE49e823DE",
    receiveLibrary: [
      "0xB217266c3A98C8B2709Ee26836C98cf12f6cCEC1",
      false
    ],
    delegate: "0xF2Ab1eEBbEcb4E315FE95D8b532D1aB00F1A8789",
    executor: "0x00000000000000000000000000000000000000000000000000000000000027100000000000000000000000003ebd570ed38b1b3b4bc886999fcf507e9d584859",
    sendSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000",
    receiveSecurity: "0x0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000003000000000000000000000000247624e2143504730aec22912ed41f092498bef200000000000000000000000031f748a368a893bdb5abb67ec95f232507601a73000000000000000000000000fd6865c841c2d64565562fcc7e05e619a30615f00000000000000000000000000000000000000000000000000000000000000000"
  },
  suiConfigurationDigest: "6sbCjzYbNLWYBY8QuZjLyKeGnGZjtLUWktmrZZb1fRU8"
};

// contracts/nftree-generation/scripts/binding-bnb.mjs
async function verifyConfiguredBnb(fetcher = fetch) {
  let id = 0;
  const rpc = async (method, params = []) => {
    assert7(["eth_chainId", "eth_blockNumber", "eth_getCode", "eth_call", "eth_getTransactionByHash", "eth_getTransactionReceipt", "eth_getBlockByNumber"].includes(method));
    const n = ++id, r = await fetcher("https://bsc-rpc.publicnode.com", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: n, method, params }), signal: AbortSignal.timeout(15e3) });
    assert7(r.ok);
    const j = await r.json();
    assert7(!j.error && j.id === n);
    return j.result;
  };
  assert7.equal(await rpc("eth_chainId"), "0x38");
  const block = await rpc("eth_blockNumber");
  const rows = [...new Map(rpc_reads_default.filter((x) => !["eth_chainId", "eth_blockNumber"].includes(x.method)).map((x) => [JSON.stringify([x.method, x.params]), x])).values()];
  for (let i = 0; i < rows.length; i += 8) await Promise.all(rows.slice(i, i + 8).map(async (x) => {
    const params = structuredClone(x.params);
    if (["eth_getCode", "eth_call"].includes(x.method)) params[1] = block;
    const actual = await rpc(x.method, params);
    if (x.method === "eth_getBlockByNumber") assert7.equal(actual.hash, x.result.hash, "Receipt block changed");
    else assert7.deepEqual(actual, x.result, "BNB receipt/runtime/configuration changed: " + x.method);
  }));
  return { complete: true, stage: 4, block, hashes: user_receipt_default2.transactionHashes, totalGasFeeWei: user_receipt_default2.totalGasFeeWei };
}

// docs/multichain/generation-milestone/bnb-configuration-completed/binding-review/binding.json
var binding_default = {
  preparedAt: "2026-11-23T05:02:11.493Z",
  submitted: false,
  approvedGasBudgetMist: "100000000",
  state: {
    chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
    checkpoint: {
      sequenceNumber: 348235128,
      timestamp: "2026-11-23T05:02:09.262Z"
    },
    endpoint: {
      address: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
      version: 1096510922,
      digest: "9o4Ns6gwz7FmuGreY6LA1i1JokDsGsbuDksV9Kf9zSnJ",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 635685314
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::endpoint_v2::EndpointV2"
          },
          json: {
            id: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
            eid: 30378,
            call_cap: {
              id: "0x8de954b904b90f887ff2e81ff3362ca89e883da6529e55723758cd5093234b0d",
              cap_type: {
                "@variant": "Package",
                pos0: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac"
              }
            },
            oapp_registry: {
              oapps: {
                id: "0x720fc2300c05bb7ad68aefec00a9796b4451c4d1df78bc72cd8c98e774220bec",
                size: "143"
              }
            },
            composer_registry: {
              composers: {
                id: "0xb41ca35805177b946bebf5d339712b4e9bb562b068b33851001f9f0b66847814",
                size: "7"
              }
            },
            message_lib_manager: {
              registry: {
                libs: {
                  contents: {
                    id: "0x520bbc08883e22efb29f50283e25b4561ffa7c7b9d7774b14fc1c6272e593e03",
                    size: "2"
                  }
                },
                lib_to_type: {
                  id: "0xb136bb2fc780a76e636c10f10b10ab33754a3573efa5f1285bf2b35eaf73b50d",
                  size: "2"
                }
              },
              default_configs: {
                id: "0xa2371851318b3ba333270daf696dedbc7b89a1107ca362643798c1789ce05a01",
                size: "126"
              },
              oapp_configs: {
                id: "0x0e679b0fcc94fb07a5ec9a14712f8e35e0994b892e64a434e898450eb670e920",
                size: "101"
              }
            }
          }
        }
      }
    },
    uln: {
      address: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
      version: 1096510922,
      digest: "DZyejj6bY4E6EmLaw3kgsWXera1RVmgwL8xLDHrLVhCt",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 635685319
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0::uln_302::Uln302"
          },
          json: {
            id: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
            call_cap: {
              id: "0xfacd801d08e3a99c907148fa00ec5f17a0a3ac831dbc95bcd75e601006caafa9",
              cap_type: {
                "@variant": "Package",
                pos0: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0"
              }
            },
            send_uln: {
              default_executor_configs: {
                id: "0x346b468d90db8743673c7ed4fdbe1c40f6a587aac6acc730b3a9bb86cf0919f4",
                size: "126"
              },
              default_uln_configs: {
                id: "0x2bd7d044d837b718a7852959c701c04e842e648cf9047b442d55c838846a13e5",
                size: "126"
              },
              oapp_executor_configs: {
                id: "0x357a98886ef14de3d15e538a808b410cfe026f6b1f971bb2398978d56e4dc181",
                size: "55"
              },
              oapp_uln_configs: {
                id: "0xc53b8a5592cdeea1a7421d209ba5c70e6843d2911e5bb86ad9fb744d888eab60",
                size: "215"
              }
            },
            receive_uln: {
              default_uln_configs: {
                id: "0x5ddc28272722231ecef30237bb48715f128d6995b89a46db25cd9adae0140835",
                size: "126"
              },
              oapp_uln_configs: {
                id: "0x0d89da4d00f46c4b1dab465a867e60eacbf646e56f8816ae55cd7b9495c1bb09",
                size: "240"
              },
              verification: "0x950f66ed27ec0a01a52bda147d74165d4cc20165f0cee0ecae6aaacde13d7741"
            }
          }
        }
      }
    },
    oapp: {
      address: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
      version: 1,
      digest: "7LeHSzqW2xxEA7QrcimgN8c7ZKaAJUL3fwvjNy9wnoar",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::OApp"
          },
          json: {
            id: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            oapp_cap: {
              id: "0x6b7c66d2135ce12efa6a23037bff2e5ca1b499db24bc200592d08c2595cf5a3a",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            admin_cap: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
            peer: {
              peers: {
                id: "0x984eb93d6713b0909152e249bcfa465a6661e7403c5b01266353b97ff2318966",
                size: "0"
              }
            },
            enforced_options: {
              options: {
                id: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
                size: "0"
              }
            },
            sending_call: null
          }
        }
      }
    },
    admin: {
      address: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
      version: 1096510922,
      digest: "J7g5DCG1rmvRrFuVezwpPgrd1ReJLf3h1Wz8LWaRof7N",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::AdminCap"
          },
          json: {
            id: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d"
          }
        }
      }
    },
    vault: {
      address: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
      version: 2,
      digest: "EiVf4xEufWiA56rUMda9QJ7bSYtP6XDDdWHQcxyP1gJq",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 2
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Vault<0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT>"
          },
          json: {
            id: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
            version: "1",
            registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
            cap: {
              id: "0x1711b6b0e442e8299ea3aceb30286234520c8f1c4d2294aa7d031308a3d7bcff",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            nft: null,
            backing: {
              bytes: "BG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWpro="
            },
            route: {
              bytes: "9d/44syWgk+Jc1+hbAaO6BlPu36NaXruvl0TX4pZFus="
            },
            peer: {
              bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            },
            bound: false,
            paused: false,
            phase: 0,
            generation: "0",
            announced: false,
            ack_sent: false,
            request: {
              bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            },
            recipient: {
              bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            }
          }
        }
      }
    },
    channel: {
      address: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
      version: 1089269258,
      digest: "864jUfZhozh3q9nS2x8Pu7WmX8fQxL7iidcGXqp6nbUm",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1089269258
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::MessagingChannel"
          },
          json: {
            id: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
            oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            channels: {
              id: "0xc631f02da694ee43bc4923570de9f6d53cbccbdb72986cf63dc84e77744c0e95",
              size: "0"
            },
            is_sending: false
          }
        }
      }
    },
    registration: {
      address: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
      version: 1096510922,
      digest: "8fcLbkwf639cvZt7t54EXo4wypKhLcodVebYfKcCzBx7",
      owner: {
        __typename: "ObjectOwner"
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<address,0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::oapp_registry::OAppRegistration>"
          },
          json: {
            id: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
            name: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            value: {
              messaging_channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
              oapp_info: "AAENo9hF9KsYoKjS8GaXIqHZFhwuphrXFKvBTUFHIf0U5ADwAQABAcRFUZvx1u2KtgAtIK1+2Bqa0l4xmQ35tyID0K2G/S6SBXZhdWx0Cmx6X3JlY2VpdmUDAfXf+OLMloJPiXNfoWwGjugZT7t+jWl67r5dE1+KWRbrAQ2j2EX0qxigqNLwZpciodkWHC6mGtcUq8FNQUch/RTkACBkICYW91pWFKz6JkQYJYUhKZ62qJLu7qOS/u+JSMfrUwFTMHhmNmM2ZDQzOWVhMGRhMmYzZTliYTc5ZTQ5OTJhN2E0YzExMzIxNWZiZjU0YzQ0MmFjOTAyMGMzMTVmOTUzNzA1Ojpjb2xsZWN0aW9uOjpORlQAAAA=",
              delegate: "0x0000000000000000000000000000000000000000000000000000000000000000"
            }
          }
        }
      }
    },
    libraries: {
      dynamicField: {
        value: {
          json: {
            send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib_timeout: null
          }
        }
      }
    },
    send: {
      dynamicField: {
        value: {
          json: {
            confirmations: "5",
            required_dvns: [
              "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
              "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
              "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
              "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
            ],
            optional_dvns: [],
            optional_dvn_threshold: 0
          }
        }
      }
    },
    receive: {
      dynamicField: {
        value: {
          json: {
            confirmations: "20",
            required_dvns: [
              "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
              "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
              "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
              "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
            ],
            optional_dvns: [],
            optional_dvn_threshold: 0
          }
        }
      }
    },
    executor: {
      dynamicField: {
        value: {
          json: {
            max_message_size: "10000",
            executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
          }
        }
      }
    },
    appLibraries: {
      dynamicField: {
        value: {
          json: {
            send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib_timeout: null
          }
        }
      }
    },
    appSend: {
      dynamicField: {
        value: {
          json: {
            use_default_confirmations: false,
            use_default_required_dvns: false,
            use_default_optional_dvns: false,
            uln_config: {
              confirmations: "5",
              required_dvns: [
                "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
                "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
                "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
              ],
              optional_dvns: [],
              optional_dvn_threshold: 0
            }
          }
        }
      }
    },
    appReceive: {
      dynamicField: {
        value: {
          json: {
            use_default_confirmations: false,
            use_default_required_dvns: false,
            use_default_optional_dvns: false,
            uln_config: {
              confirmations: "20",
              required_dvns: [
                "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
                "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
                "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
              ],
              optional_dvns: [],
              optional_dvn_threshold: 0
            }
          }
        }
      }
    },
    appExecutor: {
      dynamicField: {
        value: {
          json: {
            max_message_size: "10000",
            executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
          }
        }
      }
    },
    vaultAdmin: {
      address: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
      version: 1089269258,
      digest: "AHLq258yMBD9Sm3K88zi35nmtLJpK4itLJSajaAX9gc8",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::AdminCap"
          },
          json: {
            id: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
            registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210"
          }
        }
      }
    }
  },
  transactionJSON: '{\n  "version": 2,\n  "sender": "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",\n  "expiration": {\n    "ValidDuring": {\n      "minEpoch": "1320",\n      "maxEpoch": "1321",\n      "minTimestamp": null,\n      "maxTimestamp": null,\n      "chain": "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",\n      "nonce": 2436838580\n    }\n  },\n  "gasData": {\n    "budget": "100000000",\n    "price": "100",\n    "owner": "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",\n    "payment": []\n  },\n  "inputs": [\n    {\n      "Pure": {\n        "bytes": "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="\n      }\n    },\n    {\n      "Object": {\n        "SharedObject": {\n          "objectId": "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",\n          "initialSharedVersion": "2",\n          "mutable": true\n        }\n      }\n    },\n    {\n      "Object": {\n        "ImmOrOwnedObject": {\n          "objectId": "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",\n          "version": "1089269258",\n          "digest": "AHLq258yMBD9Sm3K88zi35nmtLJpK4itLJSajaAX9gc8"\n        }\n      }\n    },\n    {\n      "Object": {\n        "SharedObject": {\n          "objectId": "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",\n          "initialSharedVersion": "1",\n          "mutable": true\n        }\n      }\n    },\n    {\n      "Object": {\n        "ImmOrOwnedObject": {\n          "objectId": "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",\n          "version": "1096510922",\n          "digest": "J7g5DCG1rmvRrFuVezwpPgrd1ReJLf3h1Wz8LWaRof7N"\n        }\n      }\n    },\n    {\n      "Object": {\n        "SharedObject": {\n          "objectId": "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",\n          "initialSharedVersion": "635685314",\n          "mutable": false\n        }\n      }\n    },\n    {\n      "Object": {\n        "SharedObject": {\n          "objectId": "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",\n          "initialSharedVersion": "1089269258",\n          "mutable": true\n        }\n      }\n    }\n  ],\n  "commands": [\n    {\n      "MoveCall": {\n        "package": "0x00245ba36f7a1cc643a2b037450dff1e4399e18069c6545fb5fcaaf37d39d7dc",\n        "module": "bytes32",\n        "function": "from_address",\n        "typeArguments": [],\n        "arguments": [\n          {\n            "Input": 0\n          }\n        ]\n      }\n    },\n    {\n      "MoveCall": {\n        "package": "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",\n        "module": "vault",\n        "function": "bind",\n        "typeArguments": [\n          "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"\n        ],\n        "arguments": [\n          {\n            "Input": 1\n          },\n          {\n            "Input": 2\n          },\n          {\n            "Input": 3\n          },\n          {\n            "Input": 4\n          },\n          {\n            "Input": 5\n          },\n          {\n            "Input": 6\n          },\n          {\n            "Result": 0\n          }\n        ]\n      }\n    }\n  ],\n  "digest": "FXRaXAsrVubw1DPVmqQN159iB6ZSGtv3QHfGPh5VKAYd"\n}',
  result: {
    $kind: "Transaction",
    Transaction: {
      digest: "FXRaXAsrVubw1DPVmqQN159iB6ZSGtv3QHfGPh5VKAYd",
      status: {
        success: true,
        error: null
      },
      effects: {
        bcs: {
          "0": 1,
          "1": 0,
          "2": 40,
          "3": 5,
          "4": 0,
          "5": 0,
          "6": 0,
          "7": 0,
          "8": 0,
          "9": 0,
          "10": 160,
          "11": 134,
          "12": 1,
          "13": 0,
          "14": 0,
          "15": 0,
          "16": 0,
          "17": 0,
          "18": 144,
          "19": 217,
          "20": 58,
          "21": 1,
          "22": 0,
          "23": 0,
          "24": 0,
          "25": 0,
          "26": 245,
          "27": 249,
          "28": 174,
          "29": 0,
          "30": 0,
          "31": 0,
          "32": 0,
          "33": 0,
          "34": 123,
          "35": 4,
          "36": 0,
          "37": 0,
          "38": 0,
          "39": 0,
          "40": 0,
          "41": 0,
          "42": 32,
          "43": 215,
          "44": 206,
          "45": 212,
          "46": 227,
          "47": 186,
          "48": 125,
          "49": 52,
          "50": 114,
          "51": 168,
          "52": 121,
          "53": 49,
          "54": 166,
          "55": 128,
          "56": 225,
          "57": 158,
          "58": 196,
          "59": 5,
          "60": 206,
          "61": 234,
          "62": 179,
          "63": 66,
          "64": 195,
          "65": 24,
          "66": 162,
          "67": 191,
          "68": 120,
          "69": 104,
          "70": 54,
          "71": 45,
          "72": 80,
          "73": 92,
          "74": 126,
          "75": 0,
          "76": 1,
          "77": 32,
          "78": 64,
          "79": 172,
          "80": 251,
          "81": 215,
          "82": 206,
          "83": 127,
          "84": 69,
          "85": 125,
          "86": 18,
          "87": 36,
          "88": 183,
          "89": 254,
          "90": 57,
          "91": 11,
          "92": 144,
          "93": 188,
          "94": 13,
          "95": 209,
          "96": 183,
          "97": 61,
          "98": 168,
          "99": 189,
          "100": 111,
          "101": 209,
          "102": 129,
          "103": 126,
          "104": 85,
          "105": 72,
          "106": 199,
          "107": 211,
          "108": 87,
          "109": 198,
          "110": 0,
          "111": 203,
          "112": 109,
          "113": 91,
          "114": 65,
          "115": 0,
          "116": 0,
          "117": 0,
          "118": 0,
          "119": 11,
          "120": 1,
          "121": 163,
          "122": 37,
          "123": 187,
          "124": 58,
          "125": 68,
          "126": 52,
          "127": 148,
          "128": 251,
          "129": 129,
          "130": 148,
          "131": 217,
          "132": 35,
          "133": 248,
          "134": 90,
          "135": 230,
          "136": 211,
          "137": 37,
          "138": 193,
          "139": 145,
          "140": 213,
          "141": 182,
          "142": 144,
          "143": 55,
          "144": 95,
          "145": 141,
          "146": 191,
          "147": 168,
          "148": 238,
          "149": 196,
          "150": 121,
          "151": 14,
          "152": 0,
          "153": 1,
          "154": 32,
          "155": 14,
          "156": 188,
          "157": 36,
          "158": 225,
          "159": 163,
          "160": 221,
          "161": 202,
          "162": 40,
          "163": 85,
          "164": 180,
          "165": 199,
          "166": 233,
          "167": 226,
          "168": 68,
          "169": 115,
          "170": 10,
          "171": 18,
          "172": 189,
          "173": 190,
          "174": 111,
          "175": 182,
          "176": 179,
          "177": 25,
          "178": 29,
          "179": 127,
          "180": 13,
          "181": 59,
          "182": 168,
          "183": 249,
          "184": 79,
          "185": 55,
          "186": 126,
          "187": 1,
          "188": 209,
          "189": 192,
          "190": 219,
          "191": 240,
          "192": 44,
          "193": 149,
          "194": 77,
          "195": 136,
          "196": 207,
          "197": 150,
          "198": 2,
          "199": 244,
          "200": 60,
          "201": 135,
          "202": 125,
          "203": 218,
          "204": 237,
          "205": 61,
          "206": 140,
          "207": 245,
          "208": 175,
          "209": 180,
          "210": 231,
          "211": 31,
          "212": 131,
          "213": 204,
          "214": 249,
          "215": 251,
          "216": 237,
          "217": 120,
          "218": 228,
          "219": 151,
          "220": 1,
          "221": 13,
          "222": 163,
          "223": 216,
          "224": 69,
          "225": 244,
          "226": 171,
          "227": 24,
          "228": 160,
          "229": 168,
          "230": 210,
          "231": 240,
          "232": 102,
          "233": 151,
          "234": 34,
          "235": 161,
          "236": 217,
          "237": 22,
          "238": 28,
          "239": 46,
          "240": 166,
          "241": 26,
          "242": 215,
          "243": 20,
          "244": 171,
          "245": 193,
          "246": 77,
          "247": 65,
          "248": 71,
          "249": 33,
          "250": 253,
          "251": 20,
          "252": 228,
          "253": 1,
          "254": 1,
          "255": 0,
          "256": 0,
          "257": 0,
          "258": 0,
          "259": 0,
          "260": 0,
          "261": 0,
          "262": 32,
          "263": 94,
          "264": 46,
          "265": 80,
          "266": 73,
          "267": 107,
          "268": 91,
          "269": 166,
          "270": 49,
          "271": 47,
          "272": 96,
          "273": 182,
          "274": 45,
          "275": 240,
          "276": 168,
          "277": 130,
          "278": 211,
          "279": 157,
          "280": 63,
          "281": 53,
          "282": 220,
          "283": 202,
          "284": 71,
          "285": 208,
          "286": 252,
          "287": 146,
          "288": 83,
          "289": 14,
          "290": 234,
          "291": 55,
          "292": 192,
          "293": 90,
          "294": 11,
          "295": 2,
          "296": 1,
          "297": 0,
          "298": 0,
          "299": 0,
          "300": 0,
          "301": 0,
          "302": 0,
          "303": 0,
          "304": 1,
          "305": 32,
          "306": 207,
          "307": 229,
          "308": 52,
          "309": 194,
          "310": 67,
          "311": 217,
          "312": 176,
          "313": 251,
          "314": 222,
          "315": 32,
          "316": 164,
          "317": 9,
          "318": 24,
          "319": 166,
          "320": 87,
          "321": 176,
          "322": 137,
          "323": 139,
          "324": 144,
          "325": 41,
          "326": 125,
          "327": 141,
          "328": 197,
          "329": 173,
          "330": 75,
          "331": 156,
          "332": 154,
          "333": 178,
          "334": 13,
          "335": 4,
          "336": 197,
          "337": 123,
          "338": 2,
          "339": 1,
          "340": 0,
          "341": 0,
          "342": 0,
          "343": 0,
          "344": 0,
          "345": 0,
          "346": 0,
          "347": 0,
          "348": 78,
          "349": 127,
          "350": 222,
          "351": 15,
          "352": 162,
          "353": 45,
          "354": 120,
          "355": 162,
          "356": 145,
          "357": 111,
          "358": 126,
          "359": 168,
          "360": 210,
          "361": 231,
          "362": 212,
          "363": 104,
          "364": 141,
          "365": 4,
          "366": 238,
          "367": 76,
          "368": 96,
          "369": 21,
          "370": 45,
          "371": 138,
          "372": 9,
          "373": 212,
          "374": 163,
          "375": 52,
          "376": 232,
          "377": 159,
          "378": 106,
          "379": 172,
          "380": 1,
          "381": 10,
          "382": 238,
          "383": 236,
          "384": 64,
          "385": 0,
          "386": 0,
          "387": 0,
          "388": 0,
          "389": 32,
          "390": 137,
          "391": 232,
          "392": 229,
          "393": 15,
          "394": 92,
          "395": 214,
          "396": 112,
          "397": 43,
          "398": 202,
          "399": 250,
          "400": 30,
          "401": 7,
          "402": 239,
          "403": 80,
          "404": 254,
          "405": 234,
          "406": 154,
          "407": 73,
          "408": 3,
          "409": 237,
          "410": 199,
          "411": 11,
          "412": 96,
          "413": 88,
          "414": 138,
          "415": 230,
          "416": 120,
          "417": 171,
          "418": 233,
          "419": 130,
          "420": 2,
          "421": 113,
          "422": 0,
          "423": 72,
          "424": 89,
          "425": 83,
          "426": 226,
          "427": 234,
          "428": 223,
          "429": 74,
          "430": 160,
          "431": 42,
          "432": 249,
          "433": 80,
          "434": 207,
          "435": 142,
          "436": 145,
          "437": 79,
          "438": 189,
          "439": 43,
          "440": 103,
          "441": 82,
          "442": 51,
          "443": 133,
          "444": 231,
          "445": 60,
          "446": 54,
          "447": 17,
          "448": 131,
          "449": 65,
          "450": 69,
          "451": 157,
          "452": 141,
          "453": 69,
          "454": 196,
          "455": 1,
          "456": 32,
          "457": 206,
          "458": 177,
          "459": 139,
          "460": 109,
          "461": 43,
          "462": 173,
          "463": 171,
          "464": 102,
          "465": 160,
          "466": 158,
          "467": 197,
          "468": 7,
          "469": 137,
          "470": 63,
          "471": 202,
          "472": 233,
          "473": 208,
          "474": 194,
          "475": 24,
          "476": 87,
          "477": 28,
          "478": 115,
          "479": 132,
          "480": 124,
          "481": 112,
          "482": 244,
          "483": 10,
          "484": 178,
          "485": 242,
          "486": 229,
          "487": 84,
          "488": 121,
          "489": 0,
          "490": 72,
          "491": 89,
          "492": 83,
          "493": 226,
          "494": 234,
          "495": 223,
          "496": 74,
          "497": 160,
          "498": 42,
          "499": 249,
          "500": 80,
          "501": 207,
          "502": 142,
          "503": 145,
          "504": 79,
          "505": 189,
          "506": 43,
          "507": 103,
          "508": 82,
          "509": 51,
          "510": 133,
          "511": 231,
          "512": 60,
          "513": 54,
          "514": 17,
          "515": 131,
          "516": 65,
          "517": 69,
          "518": 157,
          "519": 141,
          "520": 69,
          "521": 196,
          "522": 0,
          "523": 88,
          "524": 148,
          "525": 140,
          "526": 114,
          "527": 232,
          "528": 251,
          "529": 92,
          "530": 21,
          "531": 114,
          "532": 169,
          "533": 224,
          "534": 179,
          "535": 239,
          "536": 157,
          "537": 152,
          "538": 252,
          "539": 93,
          "540": 141,
          "541": 27,
          "542": 114,
          "543": 21,
          "544": 189,
          "545": 157,
          "546": 19,
          "547": 3,
          "548": 41,
          "549": 156,
          "550": 129,
          "551": 51,
          "552": 1,
          "553": 173,
          "554": 177,
          "555": 0,
          "556": 1,
          "557": 32,
          "558": 71,
          "559": 12,
          "560": 19,
          "561": 242,
          "562": 187,
          "563": 208,
          "564": 43,
          "565": 46,
          "566": 24,
          "567": 138,
          "568": 82,
          "569": 108,
          "570": 7,
          "571": 150,
          "572": 207,
          "573": 232,
          "574": 128,
          "575": 206,
          "576": 215,
          "577": 72,
          "578": 199,
          "579": 133,
          "580": 72,
          "581": 94,
          "582": 233,
          "583": 248,
          "584": 242,
          "585": 218,
          "586": 176,
          "587": 118,
          "588": 235,
          "589": 75,
          "590": 1,
          "591": 198,
          "592": 49,
          "593": 240,
          "594": 45,
          "595": 166,
          "596": 148,
          "597": 238,
          "598": 67,
          "599": 188,
          "600": 73,
          "601": 35,
          "602": 87,
          "603": 13,
          "604": 233,
          "605": 246,
          "606": 213,
          "607": 60,
          "608": 188,
          "609": 203,
          "610": 219,
          "611": 114,
          "612": 152,
          "613": 108,
          "614": 246,
          "615": 61,
          "616": 200,
          "617": 78,
          "618": 119,
          "619": 116,
          "620": 76,
          "621": 14,
          "622": 149,
          "623": 1,
          "624": 99,
          "625": 238,
          "626": 15,
          "627": 185,
          "628": 103,
          "629": 207,
          "630": 113,
          "631": 174,
          "632": 205,
          "633": 57,
          "634": 208,
          "635": 149,
          "636": 160,
          "637": 42,
          "638": 174,
          "639": 102,
          "640": 7,
          "641": 209,
          "642": 139,
          "643": 8,
          "644": 124,
          "645": 149,
          "646": 55,
          "647": 244,
          "648": 215,
          "649": 196,
          "650": 208,
          "651": 200,
          "652": 207,
          "653": 25,
          "654": 144,
          "655": 35,
          "656": 1,
          "657": 10,
          "658": 238,
          "659": 236,
          "660": 64,
          "661": 0,
          "662": 0,
          "663": 0,
          "664": 0,
          "665": 32,
          "666": 105,
          "667": 77,
          "668": 238,
          "669": 199,
          "670": 12,
          "671": 6,
          "672": 17,
          "673": 56,
          "674": 253,
          "675": 23,
          "676": 18,
          "677": 75,
          "678": 81,
          "679": 131,
          "680": 17,
          "681": 181,
          "682": 144,
          "683": 20,
          "684": 56,
          "685": 95,
          "686": 182,
          "687": 56,
          "688": 9,
          "689": 130,
          "690": 207,
          "691": 210,
          "692": 190,
          "693": 252,
          "694": 127,
          "695": 160,
          "696": 67,
          "697": 202,
          "698": 2,
          "699": 10,
          "700": 238,
          "701": 236,
          "702": 64,
          "703": 0,
          "704": 0,
          "705": 0,
          "706": 0,
          "707": 1,
          "708": 32,
          "709": 164,
          "710": 51,
          "711": 97,
          "712": 237,
          "713": 14,
          "714": 196,
          "715": 123,
          "716": 144,
          "717": 166,
          "718": 149,
          "719": 54,
          "720": 255,
          "721": 7,
          "722": 7,
          "723": 35,
          "724": 22,
          "725": 53,
          "726": 192,
          "727": 133,
          "728": 153,
          "729": 246,
          "730": 190,
          "731": 135,
          "732": 81,
          "733": 175,
          "734": 36,
          "735": 138,
          "736": 233,
          "737": 170,
          "738": 208,
          "739": 245,
          "740": 40,
          "741": 2,
          "742": 10,
          "743": 238,
          "744": 236,
          "745": 64,
          "746": 0,
          "747": 0,
          "748": 0,
          "749": 0,
          "750": 0,
          "751": 151,
          "752": 190,
          "753": 153,
          "754": 184,
          "755": 229,
          "756": 195,
          "757": 184,
          "758": 149,
          "759": 51,
          "760": 35,
          "761": 192,
          "762": 164,
          "763": 129,
          "764": 184,
          "765": 72,
          "766": 201,
          "767": 144,
          "768": 185,
          "769": 211,
          "770": 40,
          "771": 20,
          "772": 149,
          "773": 13,
          "774": 128,
          "775": 59,
          "776": 117,
          "777": 75,
          "778": 78,
          "779": 20,
          "780": 15,
          "781": 226,
          "782": 93,
          "783": 1,
          "784": 202,
          "785": 109,
          "786": 91,
          "787": 65,
          "788": 0,
          "789": 0,
          "790": 0,
          "791": 0,
          "792": 32,
          "793": 254,
          "794": 76,
          "795": 87,
          "796": 149,
          "797": 66,
          "798": 57,
          "799": 144,
          "800": 189,
          "801": 13,
          "802": 72,
          "803": 53,
          "804": 172,
          "805": 213,
          "806": 221,
          "807": 66,
          "808": 146,
          "809": 53,
          "810": 162,
          "811": 212,
          "812": 116,
          "813": 73,
          "814": 7,
          "815": 181,
          "816": 205,
          "817": 132,
          "818": 153,
          "819": 3,
          "820": 245,
          "821": 143,
          "822": 104,
          "823": 236,
          "824": 217,
          "825": 0,
          "826": 72,
          "827": 89,
          "828": 83,
          "829": 226,
          "830": 234,
          "831": 223,
          "832": 74,
          "833": 160,
          "834": 42,
          "835": 249,
          "836": 80,
          "837": 207,
          "838": 142,
          "839": 145,
          "840": 79,
          "841": 189,
          "842": 43,
          "843": 103,
          "844": 82,
          "845": 51,
          "846": 133,
          "847": 231,
          "848": 60,
          "849": 54,
          "850": 17,
          "851": 131,
          "852": 65,
          "853": 69,
          "854": 157,
          "855": 141,
          "856": 69,
          "857": 196,
          "858": 1,
          "859": 32,
          "860": 40,
          "861": 14,
          "862": 9,
          "863": 106,
          "864": 235,
          "865": 217,
          "866": 82,
          "867": 89,
          "868": 169,
          "869": 2,
          "870": 222,
          "871": 50,
          "872": 45,
          "873": 160,
          "874": 202,
          "875": 179,
          "876": 134,
          "877": 6,
          "878": 124,
          "879": 101,
          "880": 184,
          "881": 117,
          "882": 37,
          "883": 126,
          "884": 28,
          "885": 147,
          "886": 122,
          "887": 114,
          "888": 135,
          "889": 18,
          "890": 39,
          "891": 130,
          "892": 0,
          "893": 72,
          "894": 89,
          "895": 83,
          "896": 226,
          "897": 234,
          "898": 223,
          "899": 74,
          "900": 160,
          "901": 42,
          "902": 249,
          "903": 80,
          "904": 207,
          "905": 142,
          "906": 145,
          "907": 79,
          "908": 189,
          "909": 43,
          "910": 103,
          "911": 82,
          "912": 51,
          "913": 133,
          "914": 231,
          "915": 60,
          "916": 54,
          "917": 17,
          "918": 131,
          "919": 65,
          "920": 69,
          "921": 157,
          "922": 141,
          "923": 69,
          "924": 196,
          "925": 0,
          "926": 180,
          "927": 12,
          "928": 164,
          "929": 39,
          "930": 70,
          "931": 79,
          "932": 221,
          "933": 113,
          "934": 244,
          "935": 194,
          "936": 189,
          "937": 71,
          "938": 45,
          "939": 103,
          "940": 222,
          "941": 105,
          "942": 79,
          "943": 146,
          "944": 245,
          "945": 53,
          "946": 166,
          "947": 129,
          "948": 19,
          "949": 163,
          "950": 48,
          "951": 250,
          "952": 8,
          "953": 95,
          "954": 189,
          "955": 12,
          "956": 52,
          "957": 154,
          "958": 0,
          "959": 1,
          "960": 32,
          "961": 255,
          "962": 53,
          "963": 219,
          "964": 15,
          "965": 27,
          "966": 104,
          "967": 90,
          "968": 206,
          "969": 211,
          "970": 126,
          "971": 202,
          "972": 104,
          "973": 228,
          "974": 75,
          "975": 151,
          "976": 85,
          "977": 31,
          "978": 118,
          "979": 30,
          "980": 245,
          "981": 94,
          "982": 21,
          "983": 136,
          "984": 85,
          "985": 214,
          "986": 84,
          "987": 234,
          "988": 41,
          "989": 212,
          "990": 112,
          "991": 42,
          "992": 115,
          "993": 1,
          "994": 152,
          "995": 78,
          "996": 185,
          "997": 61,
          "998": 103,
          "999": 19,
          "1000": 176,
          "1001": 144,
          "1002": 145,
          "1003": 82,
          "1004": 226,
          "1005": 73,
          "1006": 188,
          "1007": 250,
          "1008": 70,
          "1009": 90,
          "1010": 102,
          "1011": 97,
          "1012": 231,
          "1013": 64,
          "1014": 60,
          "1015": 91,
          "1016": 1,
          "1017": 38,
          "1018": 99,
          "1019": 83,
          "1020": 185,
          "1021": 127,
          "1022": 242,
          "1023": 49,
          "1024": 137,
          "1025": 102,
          "1026": 1,
          "1027": 195,
          "1028": 138,
          "1029": 114,
          "1030": 14,
          "1031": 252,
          "1032": 168,
          "1033": 216,
          "1034": 219,
          "1035": 222,
          "1036": 193,
          "1037": 5,
          "1038": 21,
          "1039": 165,
          "1040": 229,
          "1041": 62,
          "1042": 215,
          "1043": 204,
          "1044": 17,
          "1045": 252,
          "1046": 137,
          "1047": 134,
          "1048": 41,
          "1049": 120,
          "1050": 70,
          "1051": 162,
          "1052": 131,
          "1053": 254,
          "1054": 173,
          "1055": 96,
          "1056": 154,
          "1057": 191,
          "1058": 180,
          "1059": 0,
          "1060": 0,
          "1061": 1,
          "1062": 224,
          "1063": 46,
          "1064": 254,
          "1065": 217,
          "1066": 34,
          "1067": 123,
          "1068": 81,
          "1069": 166,
          "1070": 167,
          "1071": 4,
          "1072": 37,
          "1073": 206,
          "1074": 14,
          "1075": 201,
          "1076": 83,
          "1077": 107,
          "1078": 32,
          "1079": 227,
          "1080": 195,
          "1081": 40,
          "1082": 59,
          "1083": 144,
          "1084": 120,
          "1085": 182,
          "1086": 233,
          "1087": 54,
          "1088": 130,
          "1089": 140,
          "1090": 104,
          "1091": 124,
          "1092": 50,
          "1093": 131,
          "1094": 0,
          "1095": 1,
          "1096": 32,
          "1097": 167,
          "1098": 251,
          "1099": 193,
          "1100": 101,
          "1101": 37,
          "1102": 83,
          "1103": 232,
          "1104": 191,
          "1105": 113,
          "1106": 42,
          "1107": 40,
          "1108": 190,
          "1109": 194,
          "1110": 137,
          "1111": 114,
          "1112": 195,
          "1113": 196,
          "1114": 211,
          "1115": 65,
          "1116": 125,
          "1117": 219,
          "1118": 60,
          "1119": 178,
          "1120": 167,
          "1121": 14,
          "1122": 235,
          "1123": 36,
          "1124": 230,
          "1125": 213,
          "1126": 210,
          "1127": 49,
          "1128": 232,
          "1129": 1,
          "1130": 209,
          "1131": 192,
          "1132": 219,
          "1133": 240,
          "1134": 44,
          "1135": 149,
          "1136": 77,
          "1137": 136,
          "1138": 207,
          "1139": 150,
          "1140": 2,
          "1141": 244,
          "1142": 60,
          "1143": 135,
          "1144": 125,
          "1145": 218,
          "1146": 237,
          "1147": 61,
          "1148": 140,
          "1149": 245,
          "1150": 175,
          "1151": 180,
          "1152": 231,
          "1153": 31,
          "1154": 131,
          "1155": 204,
          "1156": 249,
          "1157": 251,
          "1158": 237,
          "1159": 120,
          "1160": 228,
          "1161": 151,
          "1162": 1,
          "1163": 224,
          "1164": 125,
          "1165": 255,
          "1166": 18,
          "1167": 247,
          "1168": 144,
          "1169": 158,
          "1170": 232,
          "1171": 47,
          "1172": 125,
          "1173": 129,
          "1174": 239,
          "1175": 49,
          "1176": 95,
          "1177": 18,
          "1178": 245,
          "1179": 86,
          "1180": 254,
          "1181": 115,
          "1182": 103,
          "1183": 97,
          "1184": 57,
          "1185": 186,
          "1186": 133,
          "1187": 85,
          "1188": 17,
          "1189": 224,
          "1190": 91,
          "1191": 79,
          "1192": 112,
          "1193": 44,
          "1194": 240,
          "1195": 0,
          "1196": 3,
          "1197": 72,
          "1198": 89,
          "1199": 83,
          "1200": 226,
          "1201": 234,
          "1202": 223,
          "1203": 74,
          "1204": 160,
          "1205": 42,
          "1206": 249,
          "1207": 80,
          "1208": 207,
          "1209": 142,
          "1210": 145,
          "1211": 79,
          "1212": 189,
          "1213": 43,
          "1214": 103,
          "1215": 82,
          "1216": 51,
          "1217": 133,
          "1218": 231,
          "1219": 60,
          "1220": 54,
          "1221": 17,
          "1222": 131,
          "1223": 65,
          "1224": 69,
          "1225": 157,
          "1226": 141,
          "1227": 69,
          "1228": 196,
          "1229": 7,
          "1230": 0,
          "1231": 0,
          "1232": 0,
          "1233": 0,
          "1234": 0,
          "1235": 0,
          "1236": 0,
          "1237": 0,
          "1238": 0,
          "1239": 0,
          "1240": 0,
          "1241": 0,
          "1242": 0,
          "1243": 0,
          "1244": 0,
          "1245": 0,
          "1246": 0,
          "1247": 0,
          "1248": 0,
          "1249": 0,
          "1250": 0,
          "1251": 0,
          "1252": 0,
          "1253": 0,
          "1254": 0,
          "1255": 0,
          "1256": 0,
          "1257": 0,
          "1258": 0,
          "1259": 0,
          "1260": 0,
          "1261": 2,
          "1262": 7,
          "1263": 98,
          "1264": 97,
          "1265": 108,
          "1266": 97,
          "1267": 110,
          "1268": 99,
          "1269": 101,
          "1270": 7,
          "1271": 66,
          "1272": 97,
          "1273": 108,
          "1274": 97,
          "1275": 110,
          "1276": 99,
          "1277": 101,
          "1278": 1,
          "1279": 7,
          "1280": 0,
          "1281": 0,
          "1282": 0,
          "1283": 0,
          "1284": 0,
          "1285": 0,
          "1286": 0,
          "1287": 0,
          "1288": 0,
          "1289": 0,
          "1290": 0,
          "1291": 0,
          "1292": 0,
          "1293": 0,
          "1294": 0,
          "1295": 0,
          "1296": 0,
          "1297": 0,
          "1298": 0,
          "1299": 0,
          "1300": 0,
          "1301": 0,
          "1302": 0,
          "1303": 0,
          "1304": 0,
          "1305": 0,
          "1306": 0,
          "1307": 0,
          "1308": 0,
          "1309": 0,
          "1310": 0,
          "1311": 2,
          "1312": 3,
          "1313": 115,
          "1314": 117,
          "1315": 105,
          "1316": 3,
          "1317": 83,
          "1318": 85,
          "1319": 73,
          "1320": 0,
          "1321": 1,
          "1322": 0,
          "1323": 59,
          "1324": 102,
          "1325": 141,
          "1326": 0,
          "1327": 0,
          "1328": 0,
          "1329": 0,
          "1330": 0,
          "1331": 0,
          "1332": 245,
          "1333": 223,
          "1334": 248,
          "1335": 226,
          "1336": 204,
          "1337": 150,
          "1338": 130,
          "1339": 79,
          "1340": 137,
          "1341": 115,
          "1342": 95,
          "1343": 161,
          "1344": 108,
          "1345": 6,
          "1346": 142,
          "1347": 232,
          "1348": 25,
          "1349": 79,
          "1350": 187,
          "1351": 126,
          "1352": 141,
          "1353": 105,
          "1354": 122,
          "1355": 238,
          "1356": 190,
          "1357": 93,
          "1358": 19,
          "1359": 95,
          "1360": 138,
          "1361": 89,
          "1362": 22,
          "1363": 235,
          "1364": 1,
          "1365": 2,
          "1366": 0,
          "1367": 0,
          "1368": 0,
          "1369": 0,
          "1370": 0,
          "1371": 0,
          "1372": 0,
          "1373": 32,
          "1374": 203,
          "1375": 201,
          "1376": 37,
          "1377": 33,
          "1378": 253,
          "1379": 41,
          "1380": 137,
          "1381": 215,
          "1382": 20,
          "1383": 150,
          "1384": 117,
          "1385": 83,
          "1386": 213,
          "1387": 176,
          "1388": 200,
          "1389": 138,
          "1390": 154,
          "1391": 189,
          "1392": 91,
          "1393": 136,
          "1394": 95,
          "1395": 25,
          "1396": 248,
          "1397": 181,
          "1398": 218,
          "1399": 164,
          "1400": 240,
          "1401": 116,
          "1402": 133,
          "1403": 121,
          "1404": 177,
          "1405": 38,
          "1406": 2,
          "1407": 2,
          "1408": 0,
          "1409": 0,
          "1410": 0,
          "1411": 0,
          "1412": 0,
          "1413": 0,
          "1414": 0,
          "1415": 1,
          "1416": 32,
          "1417": 83,
          "1418": 222,
          "1419": 28,
          "1420": 50,
          "1421": 98,
          "1422": 71,
          "1423": 222,
          "1424": 230,
          "1425": 192,
          "1426": 107,
          "1427": 211,
          "1428": 1,
          "1429": 18,
          "1430": 112,
          "1431": 13,
          "1432": 5,
          "1433": 65,
          "1434": 121,
          "1435": 163,
          "1436": 216,
          "1437": 169,
          "1438": 29,
          "1439": 95,
          "1440": 231,
          "1441": 98,
          "1442": 9,
          "1443": 178,
          "1444": 229,
          "1445": 155,
          "1446": 212,
          "1447": 96,
          "1448": 1,
          "1449": 2,
          "1450": 2,
          "1451": 0,
          "1452": 0,
          "1453": 0,
          "1454": 0,
          "1455": 0,
          "1456": 0,
          "1457": 0,
          "1458": 0,
          "1459": 1,
          "1460": 212,
          "1461": 91,
          "1462": 104,
          "1463": 144,
          "1464": 250,
          "1465": 3,
          "1466": 11,
          "1467": 203,
          "1468": 67,
          "1469": 52,
          "1470": 124,
          "1471": 12,
          "1472": 105,
          "1473": 169,
          "1474": 229,
          "1475": 161,
          "1476": 162,
          "1477": 136,
          "1478": 209,
          "1479": 202,
          "1480": 123,
          "1481": 134,
          "1482": 180,
          "1483": 40,
          "1484": 1,
          "1485": 71,
          "1486": 82,
          "1487": 180,
          "1488": 114,
          "1489": 246,
          "1490": 191,
          "1491": 145,
          "1492": 0,
          "1493": 202,
          "1494": 109,
          "1495": 91,
          "1496": 65,
          "1497": 0,
          "1498": 0,
          "1499": 0,
          "1500": 0,
          "1501": 32,
          "1502": 130,
          "1503": 170,
          "1504": 7,
          "1505": 237,
          "1506": 177,
          "1507": 185,
          "1508": 151,
          "1509": 116,
          "1510": 205,
          "1511": 181,
          "1512": 212,
          "1513": 134,
          "1514": 100,
          "1515": 101,
          "1516": 47,
          "1517": 137,
          "1518": 30,
          "1519": 216,
          "1520": 17,
          "1521": 39,
          "1522": 137,
          "1523": 63,
          "1524": 29,
          "1525": 181,
          "1526": 224,
          "1527": 57,
          "1528": 62,
          "1529": 64,
          "1530": 67,
          "1531": 28,
          "1532": 196,
          "1533": 111,
          "1534": 0
        },
        version: 2,
        status: {
          success: true,
          error: null
        },
        gasUsed: {
          computationCost: "100000",
          storageCost: "20634000",
          storageRebate: "11467253",
          nonRefundableStorageFee: "1147"
        },
        transactionDigest: "FXRaXAsrVubw1DPVmqQN159iB6ZSGtv3QHfGPh5VKAYd",
        gasObject: null,
        eventsDigest: "5MU5fNdv42BKmhx28chnNMzLnpojH3zE5hY9dNz6A3Nd",
        dependencies: [],
        lamportVersion: "1096510923",
        changedObjects: [
          {
            objectId: "0x01a325bb3a443494fb8194d923f85ae6d325c191d5b690375f8dbfa8eec4790e",
            inputState: "DoesNotExist",
            inputVersion: null,
            inputDigest: null,
            inputOwner: null,
            outputState: "ObjectWrite",
            outputVersion: "1096510923",
            outputDigest: "zX6zd8JnRzMwpfpcmfrccb8Zrr4UqfAHHbZuENAKuBj",
            outputOwner: {
              ObjectOwner: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
              $kind: "ObjectOwner"
            },
            idOperation: "Created"
          },
          {
            objectId: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            inputState: "Exists",
            inputVersion: "1",
            inputDigest: "7LeHSzqW2xxEA7QrcimgN8c7ZKaAJUL3fwvjNy9wnoar",
            inputOwner: {
              Shared: {
                initialSharedVersion: "1"
              },
              $kind: "Shared"
            },
            outputState: "ObjectWrite",
            outputVersion: "1096510923",
            outputDigest: "EzY74R9fUwwMUZT3zEpVtZZecFcm39GTjhTj96kkmDK8",
            outputOwner: {
              Shared: {
                initialSharedVersion: "1"
              },
              $kind: "Shared"
            },
            idOperation: "None"
          },
          {
            objectId: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
            inputState: "Exists",
            inputVersion: "1089269258",
            inputDigest: "AHLq258yMBD9Sm3K88zi35nmtLJpK4itLJSajaAX9gc8",
            inputOwner: {
              AddressOwner: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
              $kind: "AddressOwner"
            },
            outputState: "ObjectWrite",
            outputVersion: "1096510923",
            outputDigest: "Eur1Qvxkpijvku4nkpo8b1Ftt5dZ3SNc9rtV1HHGUKSY",
            outputOwner: {
              AddressOwner: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
              $kind: "AddressOwner"
            },
            idOperation: "None"
          },
          {
            objectId: "0x58948c72e8fb5c1572a9e0b3ef9d98fc5d8d1b7215bd9d1303299c813301adb1",
            inputState: "DoesNotExist",
            inputVersion: null,
            inputDigest: null,
            inputOwner: null,
            outputState: "ObjectWrite",
            outputVersion: "1096510923",
            outputDigest: "5nLdSfBoNKFGJrY4rKnSnS3DSxAqq9i6jeiiuC4ubi6v",
            outputOwner: {
              ObjectOwner: "0xc631f02da694ee43bc4923570de9f6d53cbccbdb72986cf63dc84e77744c0e95",
              $kind: "ObjectOwner"
            },
            idOperation: "Created"
          },
          {
            objectId: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
            inputState: "Exists",
            inputVersion: "1089269258",
            inputDigest: "864jUfZhozh3q9nS2x8Pu7WmX8fQxL7iidcGXqp6nbUm",
            inputOwner: {
              Shared: {
                initialSharedVersion: "1089269258"
              },
              $kind: "Shared"
            },
            outputState: "ObjectWrite",
            outputVersion: "1096510923",
            outputDigest: "C3yJiMdksAAEJTwqsaLawu1684t6hxiPLH8y39it7L4F",
            outputOwner: {
              Shared: {
                initialSharedVersion: "1089269258"
              },
              $kind: "Shared"
            },
            idOperation: "None"
          },
          {
            objectId: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
            inputState: "Exists",
            inputVersion: "1096510922",
            inputDigest: "J7g5DCG1rmvRrFuVezwpPgrd1ReJLf3h1Wz8LWaRof7N",
            inputOwner: {
              AddressOwner: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
              $kind: "AddressOwner"
            },
            outputState: "ObjectWrite",
            outputVersion: "1096510923",
            outputDigest: "3hMitCda6SULkoM26KzxkDqJ3Z8Jf4tHGmHMUfzoKqsX",
            outputOwner: {
              AddressOwner: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
              $kind: "AddressOwner"
            },
            idOperation: "None"
          },
          {
            objectId: "0xb40ca427464fdd71f4c2bd472d67de694f92f535a68113a330fa085fbd0c349a",
            inputState: "DoesNotExist",
            inputVersion: null,
            inputDigest: null,
            inputOwner: null,
            outputState: "ObjectWrite",
            outputVersion: "1096510923",
            outputDigest: "JBEbQU37KmyfxcyxcmqAogm5rF5V22HvuHgwsW4Mo9k6",
            outputOwner: {
              ObjectOwner: "0x984eb93d6713b0909152e249bcfa465a6661e7403c5b01266353b97ff2318966",
              $kind: "ObjectOwner"
            },
            idOperation: "Created"
          },
          {
            objectId: "0xc38a720efca8d8dbdec10515a5e53ed7cc11fc8986297846a283fead609abfb4",
            inputState: "DoesNotExist",
            inputVersion: null,
            inputDigest: null,
            inputOwner: null,
            outputState: "DoesNotExist",
            outputVersion: null,
            outputDigest: null,
            outputOwner: null,
            idOperation: "Created"
          },
          {
            objectId: "0xe02efed9227b51a6a70425ce0ec9536b20e3c3283b9078b6e936828c687c3283",
            inputState: "DoesNotExist",
            inputVersion: null,
            inputDigest: null,
            inputOwner: null,
            outputState: "ObjectWrite",
            outputVersion: "1096510923",
            outputDigest: "CJjjt5bZu4Kw5b5Fv77pyuaXbtdstQhoFTwLXufosy3d",
            outputOwner: {
              ObjectOwner: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
              $kind: "ObjectOwner"
            },
            idOperation: "Created"
          },
          {
            objectId: "0xe07dff12f7909ee82f7d81ef315f12f556fe73676139ba855511e05b4f702cf0",
            inputState: "DoesNotExist",
            inputVersion: null,
            inputDigest: null,
            inputOwner: null,
            outputState: "AccumulatorWriteV1",
            outputVersion: null,
            outputDigest: null,
            outputOwner: null,
            idOperation: "None"
          },
          {
            objectId: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
            inputState: "Exists",
            inputVersion: "2",
            inputDigest: "EiVf4xEufWiA56rUMda9QJ7bSYtP6XDDdWHQcxyP1gJq",
            inputOwner: {
              Shared: {
                initialSharedVersion: "2"
              },
              $kind: "Shared"
            },
            outputState: "ObjectWrite",
            outputVersion: "1096510923",
            outputDigest: "6ePGuaixCSmkoi4fkEGYxVWUUQAvgc2FU3EpdTgsXkKr",
            outputOwner: {
              Shared: {
                initialSharedVersion: "2"
              },
              $kind: "Shared"
            },
            idOperation: "None"
          }
        ],
        unchangedConsensusObjects: [
          {
            kind: "ReadOnlyRoot",
            objectId: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
            version: "1096510922",
            digest: "9o4Ns6gwz7FmuGreY6LA1i1JokDsGsbuDksV9Kf9zSnJ"
          }
        ],
        auxiliaryDataDigest: null
      },
      epoch: "1320",
      objectTypes: {
        "0x01a325bb3a443494fb8194d923f85ae6d325c191d5b690375f8dbfa8eec4790e": "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::enforced_options::EnforcedOptionsKey,vector<u8>>",
        "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4": "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::OApp",
        "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac": "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::AdminCap",
        "0x58948c72e8fb5c1572a9e0b3ef9d98fc5d8d1b7215bd9d1303299c813301adb1": "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::ChannelKey,0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::Channel>",
        "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023": "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::MessagingChannel",
        "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d": "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::AdminCap",
        "0xb40ca427464fdd71f4c2bd472d67de694f92f535a68113a330fa085fbd0c349a": "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<u32,0x00245ba36f7a1cc643a2b037450dff1e4399e18069c6545fb5fcaaf37d39d7dc::bytes32::Bytes32>",
        "0xe02efed9227b51a6a70425ce0ec9536b20e3c3283b9078b6e936828c687c3283": "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::enforced_options::EnforcedOptionsKey,vector<u8>>",
        "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb": "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Vault<0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT>"
      },
      transaction: {
        gasData: {
          budget: "100000000",
          owner: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
          payment: [],
          price: "100"
        },
        sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
        expiration: {
          $kind: "ValidDuring",
          ValidDuring: {
            minEpoch: "1320",
            maxEpoch: "1321",
            minTimestamp: null,
            maxTimestamp: null,
            chain: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
            nonce: 2436838580
          }
        },
        commands: [
          {
            $kind: "MoveCall",
            MoveCall: {
              package: "0x00245ba36f7a1cc643a2b037450dff1e4399e18069c6545fb5fcaaf37d39d7dc",
              module: "bytes32",
              function: "from_address",
              typeArguments: [],
              arguments: [
                {
                  $kind: "Input",
                  Input: 0
                }
              ]
            }
          },
          {
            $kind: "MoveCall",
            MoveCall: {
              package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
              module: "vault",
              function: "bind",
              typeArguments: [
                "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
              ],
              arguments: [
                {
                  $kind: "Input",
                  Input: 1
                },
                {
                  $kind: "Input",
                  Input: 2
                },
                {
                  $kind: "Input",
                  Input: 3
                },
                {
                  $kind: "Input",
                  Input: 4
                },
                {
                  $kind: "Input",
                  Input: 5
                },
                {
                  $kind: "Input",
                  Input: 6
                },
                {
                  $kind: "Result",
                  Result: 0
                }
              ]
            }
          }
        ],
        inputs: [
          {
            $kind: "Pure",
            Pure: {
              bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
            }
          },
          {
            $kind: "Object",
            Object: {
              $kind: "SharedObject",
              SharedObject: {
                objectId: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
                initialSharedVersion: "2",
                mutable: true
              }
            }
          },
          {
            $kind: "Object",
            Object: {
              $kind: "ImmOrOwnedObject",
              ImmOrOwnedObject: {
                objectId: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
                version: "1089269258",
                digest: "AHLq258yMBD9Sm3K88zi35nmtLJpK4itLJSajaAX9gc8"
              }
            }
          },
          {
            $kind: "Object",
            Object: {
              $kind: "SharedObject",
              SharedObject: {
                objectId: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
                initialSharedVersion: "1",
                mutable: true
              }
            }
          },
          {
            $kind: "Object",
            Object: {
              $kind: "ImmOrOwnedObject",
              ImmOrOwnedObject: {
                objectId: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
                version: "1096510922",
                digest: "J7g5DCG1rmvRrFuVezwpPgrd1ReJLf3h1Wz8LWaRof7N"
              }
            }
          },
          {
            $kind: "Object",
            Object: {
              $kind: "SharedObject",
              SharedObject: {
                objectId: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
                initialSharedVersion: "635685314",
                mutable: false
              }
            }
          },
          {
            $kind: "Object",
            Object: {
              $kind: "SharedObject",
              SharedObject: {
                objectId: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
                initialSharedVersion: "1089269258",
                mutable: true
              }
            }
          }
        ],
        version: 2
      },
      bcs: {
        "0": 0,
        "1": 0,
        "2": 7,
        "3": 0,
        "4": 32,
        "5": 0,
        "6": 0,
        "7": 0,
        "8": 0,
        "9": 0,
        "10": 0,
        "11": 0,
        "12": 0,
        "13": 0,
        "14": 0,
        "15": 0,
        "16": 0,
        "17": 116,
        "18": 194,
        "19": 13,
        "20": 235,
        "21": 71,
        "22": 109,
        "23": 202,
        "24": 88,
        "25": 69,
        "26": 153,
        "27": 86,
        "28": 177,
        "29": 172,
        "30": 214,
        "31": 87,
        "32": 113,
        "33": 25,
        "34": 121,
        "35": 0,
        "36": 201,
        "37": 1,
        "38": 1,
        "39": 245,
        "40": 223,
        "41": 248,
        "42": 226,
        "43": 204,
        "44": 150,
        "45": 130,
        "46": 79,
        "47": 137,
        "48": 115,
        "49": 95,
        "50": 161,
        "51": 108,
        "52": 6,
        "53": 142,
        "54": 232,
        "55": 25,
        "56": 79,
        "57": 187,
        "58": 126,
        "59": 141,
        "60": 105,
        "61": 122,
        "62": 238,
        "63": 190,
        "64": 93,
        "65": 19,
        "66": 95,
        "67": 138,
        "68": 89,
        "69": 22,
        "70": 235,
        "71": 2,
        "72": 0,
        "73": 0,
        "74": 0,
        "75": 0,
        "76": 0,
        "77": 0,
        "78": 0,
        "79": 1,
        "80": 1,
        "81": 0,
        "82": 78,
        "83": 127,
        "84": 222,
        "85": 15,
        "86": 162,
        "87": 45,
        "88": 120,
        "89": 162,
        "90": 145,
        "91": 111,
        "92": 126,
        "93": 168,
        "94": 210,
        "95": 231,
        "96": 212,
        "97": 104,
        "98": 141,
        "99": 4,
        "100": 238,
        "101": 76,
        "102": 96,
        "103": 21,
        "104": 45,
        "105": 138,
        "106": 9,
        "107": 212,
        "108": 163,
        "109": 52,
        "110": 232,
        "111": 159,
        "112": 106,
        "113": 172,
        "114": 10,
        "115": 238,
        "116": 236,
        "117": 64,
        "118": 0,
        "119": 0,
        "120": 0,
        "121": 0,
        "122": 32,
        "123": 137,
        "124": 232,
        "125": 229,
        "126": 15,
        "127": 92,
        "128": 214,
        "129": 112,
        "130": 43,
        "131": 202,
        "132": 250,
        "133": 30,
        "134": 7,
        "135": 239,
        "136": 80,
        "137": 254,
        "138": 234,
        "139": 154,
        "140": 73,
        "141": 3,
        "142": 237,
        "143": 199,
        "144": 11,
        "145": 96,
        "146": 88,
        "147": 138,
        "148": 230,
        "149": 120,
        "150": 171,
        "151": 233,
        "152": 130,
        "153": 2,
        "154": 113,
        "155": 1,
        "156": 1,
        "157": 13,
        "158": 163,
        "159": 216,
        "160": 69,
        "161": 244,
        "162": 171,
        "163": 24,
        "164": 160,
        "165": 168,
        "166": 210,
        "167": 240,
        "168": 102,
        "169": 151,
        "170": 34,
        "171": 161,
        "172": 217,
        "173": 22,
        "174": 28,
        "175": 46,
        "176": 166,
        "177": 26,
        "178": 215,
        "179": 20,
        "180": 171,
        "181": 193,
        "182": 77,
        "183": 65,
        "184": 71,
        "185": 33,
        "186": 253,
        "187": 20,
        "188": 228,
        "189": 1,
        "190": 0,
        "191": 0,
        "192": 0,
        "193": 0,
        "194": 0,
        "195": 0,
        "196": 0,
        "197": 1,
        "198": 1,
        "199": 0,
        "200": 151,
        "201": 190,
        "202": 153,
        "203": 184,
        "204": 229,
        "205": 195,
        "206": 184,
        "207": 149,
        "208": 51,
        "209": 35,
        "210": 192,
        "211": 164,
        "212": 129,
        "213": 184,
        "214": 72,
        "215": 201,
        "216": 144,
        "217": 185,
        "218": 211,
        "219": 40,
        "220": 20,
        "221": 149,
        "222": 13,
        "223": 128,
        "224": 59,
        "225": 117,
        "226": 75,
        "227": 78,
        "228": 20,
        "229": 15,
        "230": 226,
        "231": 93,
        "232": 202,
        "233": 109,
        "234": 91,
        "235": 65,
        "236": 0,
        "237": 0,
        "238": 0,
        "239": 0,
        "240": 32,
        "241": 254,
        "242": 76,
        "243": 87,
        "244": 149,
        "245": 66,
        "246": 57,
        "247": 144,
        "248": 189,
        "249": 13,
        "250": 72,
        "251": 53,
        "252": 172,
        "253": 213,
        "254": 221,
        "255": 66,
        "256": 146,
        "257": 53,
        "258": 162,
        "259": 212,
        "260": 116,
        "261": 73,
        "262": 7,
        "263": 181,
        "264": 205,
        "265": 132,
        "266": 153,
        "267": 3,
        "268": 245,
        "269": 143,
        "270": 104,
        "271": 236,
        "272": 217,
        "273": 1,
        "274": 1,
        "275": 212,
        "276": 91,
        "277": 104,
        "278": 144,
        "279": 250,
        "280": 3,
        "281": 11,
        "282": 203,
        "283": 67,
        "284": 52,
        "285": 124,
        "286": 12,
        "287": 105,
        "288": 169,
        "289": 229,
        "290": 161,
        "291": 162,
        "292": 136,
        "293": 209,
        "294": 202,
        "295": 123,
        "296": 134,
        "297": 180,
        "298": 40,
        "299": 1,
        "300": 71,
        "301": 82,
        "302": 180,
        "303": 114,
        "304": 246,
        "305": 191,
        "306": 145,
        "307": 194,
        "308": 201,
        "309": 227,
        "310": 37,
        "311": 0,
        "312": 0,
        "313": 0,
        "314": 0,
        "315": 0,
        "316": 1,
        "317": 1,
        "318": 99,
        "319": 238,
        "320": 15,
        "321": 185,
        "322": 103,
        "323": 207,
        "324": 113,
        "325": 174,
        "326": 205,
        "327": 57,
        "328": 208,
        "329": 149,
        "330": 160,
        "331": 42,
        "332": 174,
        "333": 102,
        "334": 7,
        "335": 209,
        "336": 139,
        "337": 8,
        "338": 124,
        "339": 149,
        "340": 55,
        "341": 244,
        "342": 215,
        "343": 196,
        "344": 208,
        "345": 200,
        "346": 207,
        "347": 25,
        "348": 144,
        "349": 35,
        "350": 10,
        "351": 238,
        "352": 236,
        "353": 64,
        "354": 0,
        "355": 0,
        "356": 0,
        "357": 0,
        "358": 1,
        "359": 2,
        "360": 0,
        "361": 0,
        "362": 36,
        "363": 91,
        "364": 163,
        "365": 111,
        "366": 122,
        "367": 28,
        "368": 198,
        "369": 67,
        "370": 162,
        "371": 176,
        "372": 55,
        "373": 69,
        "374": 13,
        "375": 255,
        "376": 30,
        "377": 67,
        "378": 153,
        "379": 225,
        "380": 128,
        "381": 105,
        "382": 198,
        "383": 84,
        "384": 95,
        "385": 181,
        "386": 252,
        "387": 170,
        "388": 243,
        "389": 125,
        "390": 57,
        "391": 215,
        "392": 220,
        "393": 7,
        "394": 98,
        "395": 121,
        "396": 116,
        "397": 101,
        "398": 115,
        "399": 51,
        "400": 50,
        "401": 12,
        "402": 102,
        "403": 114,
        "404": 111,
        "405": 109,
        "406": 95,
        "407": 97,
        "408": 100,
        "409": 100,
        "410": 114,
        "411": 101,
        "412": 115,
        "413": 115,
        "414": 0,
        "415": 1,
        "416": 1,
        "417": 0,
        "418": 0,
        "419": 0,
        "420": 196,
        "421": 69,
        "422": 81,
        "423": 155,
        "424": 241,
        "425": 214,
        "426": 237,
        "427": 138,
        "428": 182,
        "429": 0,
        "430": 45,
        "431": 32,
        "432": 173,
        "433": 126,
        "434": 216,
        "435": 26,
        "436": 154,
        "437": 210,
        "438": 94,
        "439": 49,
        "440": 153,
        "441": 13,
        "442": 249,
        "443": 183,
        "444": 34,
        "445": 3,
        "446": 208,
        "447": 173,
        "448": 134,
        "449": 253,
        "450": 46,
        "451": 146,
        "452": 5,
        "453": 118,
        "454": 97,
        "455": 117,
        "456": 108,
        "457": 116,
        "458": 4,
        "459": 98,
        "460": 105,
        "461": 110,
        "462": 100,
        "463": 1,
        "464": 7,
        "465": 246,
        "466": 198,
        "467": 212,
        "468": 57,
        "469": 234,
        "470": 13,
        "471": 162,
        "472": 243,
        "473": 233,
        "474": 186,
        "475": 121,
        "476": 228,
        "477": 153,
        "478": 42,
        "479": 122,
        "480": 76,
        "481": 17,
        "482": 50,
        "483": 21,
        "484": 251,
        "485": 245,
        "486": 76,
        "487": 68,
        "488": 42,
        "489": 201,
        "490": 2,
        "491": 12,
        "492": 49,
        "493": 95,
        "494": 149,
        "495": 55,
        "496": 5,
        "497": 10,
        "498": 99,
        "499": 111,
        "500": 108,
        "501": 108,
        "502": 101,
        "503": 99,
        "504": 116,
        "505": 105,
        "506": 111,
        "507": 110,
        "508": 3,
        "509": 78,
        "510": 70,
        "511": 84,
        "512": 0,
        "513": 7,
        "514": 1,
        "515": 1,
        "516": 0,
        "517": 1,
        "518": 2,
        "519": 0,
        "520": 1,
        "521": 3,
        "522": 0,
        "523": 1,
        "524": 4,
        "525": 0,
        "526": 1,
        "527": 5,
        "528": 0,
        "529": 1,
        "530": 6,
        "531": 0,
        "532": 2,
        "533": 0,
        "534": 0,
        "535": 72,
        "536": 89,
        "537": 83,
        "538": 226,
        "539": 234,
        "540": 223,
        "541": 74,
        "542": 160,
        "543": 42,
        "544": 249,
        "545": 80,
        "546": 207,
        "547": 142,
        "548": 145,
        "549": 79,
        "550": 189,
        "551": 43,
        "552": 103,
        "553": 82,
        "554": 51,
        "555": 133,
        "556": 231,
        "557": 60,
        "558": 54,
        "559": 17,
        "560": 131,
        "561": 65,
        "562": 69,
        "563": 157,
        "564": 141,
        "565": 69,
        "566": 196,
        "567": 0,
        "568": 72,
        "569": 89,
        "570": 83,
        "571": 226,
        "572": 234,
        "573": 223,
        "574": 74,
        "575": 160,
        "576": 42,
        "577": 249,
        "578": 80,
        "579": 207,
        "580": 142,
        "581": 145,
        "582": 79,
        "583": 189,
        "584": 43,
        "585": 103,
        "586": 82,
        "587": 51,
        "588": 133,
        "589": 231,
        "590": 60,
        "591": 54,
        "592": 17,
        "593": 131,
        "594": 65,
        "595": 69,
        "596": 157,
        "597": 141,
        "598": 69,
        "599": 196,
        "600": 100,
        "601": 0,
        "602": 0,
        "603": 0,
        "604": 0,
        "605": 0,
        "606": 0,
        "607": 0,
        "608": 0,
        "609": 225,
        "610": 245,
        "611": 5,
        "612": 0,
        "613": 0,
        "614": 0,
        "615": 0,
        "616": 2,
        "617": 1,
        "618": 40,
        "619": 5,
        "620": 0,
        "621": 0,
        "622": 0,
        "623": 0,
        "624": 0,
        "625": 0,
        "626": 1,
        "627": 41,
        "628": 5,
        "629": 0,
        "630": 0,
        "631": 0,
        "632": 0,
        "633": 0,
        "634": 0,
        "635": 0,
        "636": 0,
        "637": 32,
        "638": 53,
        "639": 131,
        "640": 74,
        "641": 138,
        "642": 193,
        "643": 124,
        "644": 164,
        "645": 143,
        "646": 177,
        "647": 74,
        "648": 200,
        "649": 249,
        "650": 156,
        "651": 23,
        "652": 201,
        "653": 135,
        "654": 71,
        "655": 233,
        "656": 93,
        "657": 208,
        "658": 114,
        "659": 148,
        "660": 174,
        "661": 65,
        "662": 164,
        "663": 107,
        "664": 56,
        "665": 34,
        "666": 70,
        "667": 164,
        "668": 73,
        "669": 155,
        "670": 180,
        "671": 52,
        "672": 63,
        "673": 145
      },
      signatures: [],
      balanceChanges: [
        {
          coinType: "0x0000000000000000000000000000000000000000000000000000000000000002::sui::SUI",
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
          amount: "-9266747"
        }
      ],
      events: [
        {
          packageId: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
          module: "messaging_channel",
          sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
          eventType: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::ChannelInitializedEvent",
          bcs: {
            "0": 196,
            "1": 69,
            "2": 81,
            "3": 155,
            "4": 241,
            "5": 214,
            "6": 237,
            "7": 138,
            "8": 182,
            "9": 0,
            "10": 45,
            "11": 32,
            "12": 173,
            "13": 126,
            "14": 216,
            "15": 26,
            "16": 154,
            "17": 210,
            "18": 94,
            "19": 49,
            "20": 153,
            "21": 13,
            "22": 249,
            "23": 183,
            "24": 34,
            "25": 3,
            "26": 208,
            "27": 173,
            "28": 134,
            "29": 253,
            "30": 46,
            "31": 146,
            "32": 150,
            "33": 117,
            "34": 0,
            "35": 0,
            "36": 32,
            "37": 0,
            "38": 0,
            "39": 0,
            "40": 0,
            "41": 0,
            "42": 0,
            "43": 0,
            "44": 0,
            "45": 0,
            "46": 0,
            "47": 0,
            "48": 0,
            "49": 116,
            "50": 194,
            "51": 13,
            "52": 235,
            "53": 71,
            "54": 109,
            "55": 202,
            "56": 88,
            "57": 69,
            "58": 153,
            "59": 86,
            "60": 177,
            "61": 172,
            "62": 214,
            "63": 87,
            "64": 113,
            "65": 25,
            "66": 121,
            "67": 0,
            "68": 201
          },
          json: {
            local_oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            remote_eid: 30102,
            remote_oapp: {
              bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
            }
          }
        },
        {
          packageId: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24",
          module: "oapp_peer",
          sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
          eventType: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp_peer::PeerSetEvent",
          bcs: {
            "0": 196,
            "1": 69,
            "2": 81,
            "3": 155,
            "4": 241,
            "5": 214,
            "6": 237,
            "7": 138,
            "8": 182,
            "9": 0,
            "10": 45,
            "11": 32,
            "12": 173,
            "13": 126,
            "14": 216,
            "15": 26,
            "16": 154,
            "17": 210,
            "18": 94,
            "19": 49,
            "20": 153,
            "21": 13,
            "22": 249,
            "23": 183,
            "24": 34,
            "25": 3,
            "26": 208,
            "27": 173,
            "28": 134,
            "29": 253,
            "30": 46,
            "31": 146,
            "32": 150,
            "33": 117,
            "34": 0,
            "35": 0,
            "36": 32,
            "37": 0,
            "38": 0,
            "39": 0,
            "40": 0,
            "41": 0,
            "42": 0,
            "43": 0,
            "44": 0,
            "45": 0,
            "46": 0,
            "47": 0,
            "48": 0,
            "49": 116,
            "50": 194,
            "51": 13,
            "52": 235,
            "53": 71,
            "54": 109,
            "55": 202,
            "56": 88,
            "57": 69,
            "58": 153,
            "59": 86,
            "60": 177,
            "61": 172,
            "62": 214,
            "63": 87,
            "64": 113,
            "65": 25,
            "66": 121,
            "67": 0,
            "68": 201
          },
          json: {
            oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            eid: 30102,
            peer: {
              bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
            }
          }
        },
        {
          packageId: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24",
          module: "enforced_options",
          sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
          eventType: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::enforced_options::EnforcedOptionSetEvent",
          bcs: {
            "0": 196,
            "1": 69,
            "2": 81,
            "3": 155,
            "4": 241,
            "5": 214,
            "6": 237,
            "7": 138,
            "8": 182,
            "9": 0,
            "10": 45,
            "11": 32,
            "12": 173,
            "13": 126,
            "14": 216,
            "15": 26,
            "16": 154,
            "17": 210,
            "18": 94,
            "19": 49,
            "20": 153,
            "21": 13,
            "22": 249,
            "23": 183,
            "24": 34,
            "25": 3,
            "26": 208,
            "27": 173,
            "28": 134,
            "29": 253,
            "30": 46,
            "31": 146,
            "32": 150,
            "33": 117,
            "34": 0,
            "35": 0,
            "36": 1,
            "37": 0,
            "38": 22,
            "39": 0,
            "40": 3,
            "41": 1,
            "42": 0,
            "43": 17,
            "44": 1,
            "45": 0,
            "46": 0,
            "47": 0,
            "48": 0,
            "49": 0,
            "50": 0,
            "51": 0,
            "52": 0,
            "53": 0,
            "54": 0,
            "55": 0,
            "56": 0,
            "57": 0,
            "58": 3,
            "59": 13,
            "60": 64
          },
          json: {
            oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            eid: 30102,
            msg_type: 1,
            options: "AAMBABEBAAAAAAAAAAAAAAAAAAMNQA=="
          }
        },
        {
          packageId: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24",
          module: "enforced_options",
          sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
          eventType: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::enforced_options::EnforcedOptionSetEvent",
          bcs: {
            "0": 196,
            "1": 69,
            "2": 81,
            "3": 155,
            "4": 241,
            "5": 214,
            "6": 237,
            "7": 138,
            "8": 182,
            "9": 0,
            "10": 45,
            "11": 32,
            "12": 173,
            "13": 126,
            "14": 216,
            "15": 26,
            "16": 154,
            "17": 210,
            "18": 94,
            "19": 49,
            "20": 153,
            "21": 13,
            "22": 249,
            "23": 183,
            "24": 34,
            "25": 3,
            "26": 208,
            "27": 173,
            "28": 134,
            "29": 253,
            "30": 46,
            "31": 146,
            "32": 150,
            "33": 117,
            "34": 0,
            "35": 0,
            "36": 3,
            "37": 0,
            "38": 22,
            "39": 0,
            "40": 3,
            "41": 1,
            "42": 0,
            "43": 17,
            "44": 1,
            "45": 0,
            "46": 0,
            "47": 0,
            "48": 0,
            "49": 0,
            "50": 0,
            "51": 0,
            "52": 0,
            "53": 0,
            "54": 0,
            "55": 0,
            "56": 0,
            "57": 0,
            "58": 3,
            "59": 13,
            "60": 64
          },
          json: {
            oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            eid: 30102,
            msg_type: 3,
            options: "AAMBABEBAAAAAAAAAAAAAAAAAAMNQA=="
          }
        },
        {
          packageId: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
          module: "vault",
          sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
          eventType: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Bound",
          bcs: {
            "0": 245,
            "1": 223,
            "2": 248,
            "3": 226,
            "4": 204,
            "5": 150,
            "6": 130,
            "7": 79,
            "8": 137,
            "9": 115,
            "10": 95,
            "11": 161,
            "12": 108,
            "13": 6,
            "14": 142,
            "15": 232,
            "16": 25,
            "17": 79,
            "18": 187,
            "19": 126,
            "20": 141,
            "21": 105,
            "22": 122,
            "23": 238,
            "24": 190,
            "25": 93,
            "26": 19,
            "27": 95,
            "28": 138,
            "29": 89,
            "30": 22,
            "31": 235,
            "32": 32,
            "33": 0,
            "34": 0,
            "35": 0,
            "36": 0,
            "37": 0,
            "38": 0,
            "39": 0,
            "40": 0,
            "41": 0,
            "42": 0,
            "43": 0,
            "44": 0,
            "45": 116,
            "46": 194,
            "47": 13,
            "48": 235,
            "49": 71,
            "50": 109,
            "51": 202,
            "52": 88,
            "53": 69,
            "54": 153,
            "55": 86,
            "56": 177,
            "57": 172,
            "58": 214,
            "59": 87,
            "60": 113,
            "61": 25,
            "62": 121,
            "63": 0,
            "64": 201
          },
          json: {
            vault: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
            peer: {
              bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
            }
          }
        }
      ]
    }
  },
  post: {
    data: {
      simulateTransaction: {
        effects: {
          status: "SUCCESS",
          objectChanges: {
            pageInfo: {
              hasNextPage: false
            },
            nodes: [
              {
                address: "0x01a325bb3a443494fb8194d923f85ae6d325c191d5b690375f8dbfa8eec4790e",
                outputState: {
                  asMoveObject: {
                    contents: {
                      type: {
                        repr: "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::enforced_options::EnforcedOptionsKey,vector<u8>>"
                      },
                      json: {
                        id: "0x01a325bb3a443494fb8194d923f85ae6d325c191d5b690375f8dbfa8eec4790e",
                        name: {
                          eid: 30102,
                          msg_type: 1
                        },
                        value: "AAMBABEBAAAAAAAAAAAAAAAAAAMNQA=="
                      }
                    }
                  }
                }
              },
              {
                address: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
                outputState: {
                  asMoveObject: {
                    contents: {
                      type: {
                        repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::OApp"
                      },
                      json: {
                        id: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
                        oapp_cap: {
                          id: "0x6b7c66d2135ce12efa6a23037bff2e5ca1b499db24bc200592d08c2595cf5a3a",
                          cap_type: {
                            "@variant": "Package",
                            pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
                          }
                        },
                        admin_cap: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
                        peer: {
                          peers: {
                            id: "0x984eb93d6713b0909152e249bcfa465a6661e7403c5b01266353b97ff2318966",
                            size: "1"
                          }
                        },
                        enforced_options: {
                          options: {
                            id: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
                            size: "2"
                          }
                        },
                        sending_call: null
                      }
                    }
                  }
                }
              },
              {
                address: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
                outputState: {
                  asMoveObject: {
                    contents: {
                      type: {
                        repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::AdminCap"
                      },
                      json: {
                        id: "0x4e7fde0fa22d78a2916f7ea8d2e7d4688d04ee4c60152d8a09d4a334e89f6aac",
                        registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210"
                      }
                    }
                  }
                }
              },
              {
                address: "0x58948c72e8fb5c1572a9e0b3ef9d98fc5d8d1b7215bd9d1303299c813301adb1",
                outputState: {
                  asMoveObject: {
                    contents: {
                      type: {
                        repr: "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::ChannelKey,0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::Channel>"
                      },
                      json: {
                        id: "0x58948c72e8fb5c1572a9e0b3ef9d98fc5d8d1b7215bd9d1303299c813301adb1",
                        name: {
                          remote_eid: 30102,
                          remote_oapp: {
                            bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
                          }
                        },
                        value: {
                          outbound_nonce: "0",
                          lazy_inbound_nonce: "0",
                          inbound_payload_hashes: {
                            id: "0xc38a720efca8d8dbdec10515a5e53ed7cc11fc8986297846a283fead609abfb4",
                            size: "0"
                          }
                        }
                      }
                    }
                  }
                }
              },
              {
                address: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
                outputState: {
                  asMoveObject: {
                    contents: {
                      type: {
                        repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::MessagingChannel"
                      },
                      json: {
                        id: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
                        oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
                        channels: {
                          id: "0xc631f02da694ee43bc4923570de9f6d53cbccbdb72986cf63dc84e77744c0e95",
                          size: "1"
                        },
                        is_sending: false
                      }
                    }
                  }
                }
              },
              {
                address: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
                outputState: {
                  asMoveObject: {
                    contents: {
                      type: {
                        repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::AdminCap"
                      },
                      json: {
                        id: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d"
                      }
                    }
                  }
                }
              },
              {
                address: "0xb40ca427464fdd71f4c2bd472d67de694f92f535a68113a330fa085fbd0c349a",
                outputState: {
                  asMoveObject: {
                    contents: {
                      type: {
                        repr: "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<u32,0x00245ba36f7a1cc643a2b037450dff1e4399e18069c6545fb5fcaaf37d39d7dc::bytes32::Bytes32>"
                      },
                      json: {
                        id: "0xb40ca427464fdd71f4c2bd472d67de694f92f535a68113a330fa085fbd0c349a",
                        name: 30102,
                        value: {
                          bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
                        }
                      }
                    }
                  }
                }
              },
              {
                address: "0xc38a720efca8d8dbdec10515a5e53ed7cc11fc8986297846a283fead609abfb4",
                outputState: null
              },
              {
                address: "0xe02efed9227b51a6a70425ce0ec9536b20e3c3283b9078b6e936828c687c3283",
                outputState: {
                  asMoveObject: {
                    contents: {
                      type: {
                        repr: "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::enforced_options::EnforcedOptionsKey,vector<u8>>"
                      },
                      json: {
                        id: "0xe02efed9227b51a6a70425ce0ec9536b20e3c3283b9078b6e936828c687c3283",
                        name: {
                          eid: 30102,
                          msg_type: 3
                        },
                        value: "AAMBABEBAAAAAAAAAAAAAAAAAAMNQA=="
                      }
                    }
                  }
                }
              },
              {
                address: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
                outputState: {
                  asMoveObject: {
                    contents: {
                      type: {
                        repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Vault<0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT>"
                      },
                      json: {
                        id: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
                        version: "1",
                        registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
                        cap: {
                          id: "0x1711b6b0e442e8299ea3aceb30286234520c8f1c4d2294aa7d031308a3d7bcff",
                          cap_type: {
                            "@variant": "Package",
                            pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
                          }
                        },
                        oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
                        nft: null,
                        backing: {
                          bytes: "BG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWpro="
                        },
                        route: {
                          bytes: "9d/44syWgk+Jc1+hbAaO6BlPu36NaXruvl0TX4pZFus="
                        },
                        peer: {
                          bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
                        },
                        bound: true,
                        paused: false,
                        phase: 0,
                        generation: "0",
                        announced: false,
                        ack_sent: false,
                        request: {
                          bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
                        },
                        recipient: {
                          bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
                        }
                      }
                    }
                  }
                }
              }
            ]
          }
        }
      }
    }
  },
  proof: {
    gasMist: "9266747",
    channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
    peer: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c9",
    empty: true,
    generation: 0
  }
};

// contracts/nftree-generation/scripts/binding-handoff.mjs
async function verifyBindingReceipt(digest2, client = newClient()) {
  const result = await client.core.getTransaction({ digest: digest2, include: { effects: true, events: true, transaction: true, balanceChanges: true, objectTypes: true, bcs: true } });
  assert8.equal(result.Transaction?.digest, digest2);
  const before = structuredClone(binding_default.state);
  for (const name of ["admin", "vaultAdmin"]) {
    const ref = result.Transaction.transaction.inputs.flatMap((x) => x.Object?.ImmOrOwnedObject ? [x.Object.ImmOrOwnedObject] : []).find((x) => x.objectId === before[name].address);
    assert8(ref);
    Object.assign(before[name], { version: String(ref.version), digest: ref.digest });
  }
  const proof = verifyBinding(result, before), r = await client.query({ query: STATE_QUERY });
  assert8(!r.errors && r.data);
  const current = r.data;
  assert8.equal(current.chainIdentifier, C2.chain);
  assert8(Date.now() - Date.parse(current.checkpoint.timestamp) < 12e4);
  const normalized = structuredClone(current);
  for (const n of ["vault", "oapp", "channel"]) normalized[n].asMoveObject.contents.json = structuredClone(before[n].asMoveObject.contents.json);
  validateConfigState(normalized, 1);
  const ids = result.Transaction.effects.changedObjects.filter((x) => x.outputState === "ObjectWrite").map((x) => x.objectId);
  const objects = await client.query({ query: "query{" + ids.map((id, i) => "o" + i + ':object(address:"' + id + '"){' + fields + "}").join(" ") + "}" });
  assert8(!objects.errors);
  const nodes = Object.values(objects.data).map((o) => ({ address: o.address, outputState: { asMoveObject: o.asMoveObject } }));
  verifyPostState("binding", { data: { simulateTransaction: { effects: { status: "SUCCESS", objectChanges: { pageInfo: { hasNextPage: false }, nodes } } } } }, before);
  for (const [name, id] of [["admin", C2.admin], ["vaultAdmin", C2.vaultAdmin]]) assert8.equal(Object.values(objects.data).find((x) => x.address === id).owner.address.address, C2.sender);
  const candidate = await readCandidate(client), bnb = await verifyInactiveBnb(), bnbConfiguration = await verifyConfiguredBnb();
  return { digest: digest2, packageId: C2.package, vaultId: C2.vault, ...proof, step: 6, empty: true, bound: true, current, candidate, bnb, bnbConfiguration };
}

// contracts/nftree-generation/scripts/reserve-transaction.mjs
import { Transaction as Transaction9 } from "@mysten/sui/transactions";

// docs/multichain/generation-milestone/binding-completed/user-receipt.json
var user_receipt_default3 = {
  digest: "EkZHu7fFx93QkttEekqXuqHrnQnfS6pNbZLUmeCcVf1a",
  packageId: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
  vaultId: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
  gasMist: "9266747",
  channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
  peer: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c9",
  empty: true,
  generation: 0,
  step: 6,
  bound: true,
  current: {
    chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
    checkpoint: {
      sequenceNumber: 348240446,
      timestamp: "2026-11-23T05:23:36.524Z"
    },
    endpoint: {
      address: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
      version: 1096510922,
      digest: "9o4Ns6gwz7FmuGreY6LA1i1JokDsGsbuDksV9Kf9zSnJ",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 635685314
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::endpoint_v2::EndpointV2"
          },
          json: {
            id: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
            eid: 30378,
            call_cap: {
              id: "0x8de954b904b90f887ff2e81ff3362ca89e883da6529e55723758cd5093234b0d",
              cap_type: {
                "@variant": "Package",
                pos0: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac"
              }
            },
            oapp_registry: {
              oapps: {
                id: "0x720fc2300c05bb7ad68aefec00a9796b4451c4d1df78bc72cd8c98e774220bec",
                size: "143"
              }
            },
            composer_registry: {
              composers: {
                id: "0xb41ca35805177b946bebf5d339712b4e9bb562b068b33851001f9f0b66847814",
                size: "7"
              }
            },
            message_lib_manager: {
              registry: {
                libs: {
                  contents: {
                    id: "0x520bbc08883e22efb29f50283e25b4561ffa7c7b9d7774b14fc1c6272e593e03",
                    size: "2"
                  }
                },
                lib_to_type: {
                  id: "0xb136bb2fc780a76e636c10f10b10ab33754a3573efa5f1285bf2b35eaf73b50d",
                  size: "2"
                }
              },
              default_configs: {
                id: "0xa2371851318b3ba333270daf696dedbc7b89a1107ca362643798c1789ce05a01",
                size: "126"
              },
              oapp_configs: {
                id: "0x0e679b0fcc94fb07a5ec9a14712f8e35e0994b892e64a434e898450eb670e920",
                size: "101"
              }
            }
          }
        }
      }
    },
    uln: {
      address: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
      version: 1096510922,
      digest: "DZyejj6bY4E6EmLaw3kgsWXera1RVmgwL8xLDHrLVhCt",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 635685319
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0::uln_302::Uln302"
          },
          json: {
            id: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
            call_cap: {
              id: "0xfacd801d08e3a99c907148fa00ec5f17a0a3ac831dbc95bcd75e601006caafa9",
              cap_type: {
                "@variant": "Package",
                pos0: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0"
              }
            },
            send_uln: {
              default_executor_configs: {
                id: "0x346b468d90db8743673c7ed4fdbe1c40f6a587aac6acc730b3a9bb86cf0919f4",
                size: "126"
              },
              default_uln_configs: {
                id: "0x2bd7d044d837b718a7852959c701c04e842e648cf9047b442d55c838846a13e5",
                size: "126"
              },
              oapp_executor_configs: {
                id: "0x357a98886ef14de3d15e538a808b410cfe026f6b1f971bb2398978d56e4dc181",
                size: "55"
              },
              oapp_uln_configs: {
                id: "0xc53b8a5592cdeea1a7421d209ba5c70e6843d2911e5bb86ad9fb744d888eab60",
                size: "215"
              }
            },
            receive_uln: {
              default_uln_configs: {
                id: "0x5ddc28272722231ecef30237bb48715f128d6995b89a46db25cd9adae0140835",
                size: "126"
              },
              oapp_uln_configs: {
                id: "0x0d89da4d00f46c4b1dab465a867e60eacbf646e56f8816ae55cd7b9495c1bb09",
                size: "240"
              },
              verification: "0x950f66ed27ec0a01a52bda147d74165d4cc20165f0cee0ecae6aaacde13d7741"
            }
          }
        }
      }
    },
    oapp: {
      address: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
      version: 1096510923,
      digest: "F72w92xHUVa8J2fHAmVkWjyhpmmZubUxTufqNCPKeZ2H",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::OApp"
          },
          json: {
            id: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            oapp_cap: {
              id: "0x6b7c66d2135ce12efa6a23037bff2e5ca1b499db24bc200592d08c2595cf5a3a",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            admin_cap: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
            peer: {
              peers: {
                id: "0x984eb93d6713b0909152e249bcfa465a6661e7403c5b01266353b97ff2318966",
                size: "1"
              }
            },
            enforced_options: {
              options: {
                id: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
                size: "2"
              }
            },
            sending_call: null
          }
        }
      }
    },
    admin: {
      address: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
      version: 1096510923,
      digest: "CXbdvybk5zVFVkPzd7imMGpj85r974bT5B1dMhCybeWo",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::AdminCap"
          },
          json: {
            id: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d"
          }
        }
      }
    },
    vault: {
      address: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
      version: 1096510923,
      digest: "7Ws7gNQy9yg7nmwRQH3XbZYifNLavknAgvLJYg6W1fEz",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 2
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Vault<0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT>"
          },
          json: {
            id: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
            version: "1",
            registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
            cap: {
              id: "0x1711b6b0e442e8299ea3aceb30286234520c8f1c4d2294aa7d031308a3d7bcff",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            nft: null,
            backing: {
              bytes: "BG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWpro="
            },
            route: {
              bytes: "9d/44syWgk+Jc1+hbAaO6BlPu36NaXruvl0TX4pZFus="
            },
            peer: {
              bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
            },
            bound: true,
            paused: false,
            phase: 0,
            generation: "0",
            announced: false,
            ack_sent: false,
            request: {
              bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            },
            recipient: {
              bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            }
          }
        }
      }
    },
    channel: {
      address: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
      version: 1096510923,
      digest: "6YArcujgwcw7YughAQ8GidRijkHX38LpNzSSQ3cnVs8t",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1089269258
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::MessagingChannel"
          },
          json: {
            id: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
            oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            channels: {
              id: "0xc631f02da694ee43bc4923570de9f6d53cbccbdb72986cf63dc84e77744c0e95",
              size: "1"
            },
            is_sending: false
          }
        }
      }
    },
    registration: {
      address: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
      version: 1096510922,
      digest: "8fcLbkwf639cvZt7t54EXo4wypKhLcodVebYfKcCzBx7",
      owner: {
        __typename: "ObjectOwner"
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<address,0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::oapp_registry::OAppRegistration>"
          },
          json: {
            id: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
            name: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            value: {
              messaging_channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
              oapp_info: "AAENo9hF9KsYoKjS8GaXIqHZFhwuphrXFKvBTUFHIf0U5ADwAQABAcRFUZvx1u2KtgAtIK1+2Bqa0l4xmQ35tyID0K2G/S6SBXZhdWx0Cmx6X3JlY2VpdmUDAfXf+OLMloJPiXNfoWwGjugZT7t+jWl67r5dE1+KWRbrAQ2j2EX0qxigqNLwZpciodkWHC6mGtcUq8FNQUch/RTkACBkICYW91pWFKz6JkQYJYUhKZ62qJLu7qOS/u+JSMfrUwFTMHhmNmM2ZDQzOWVhMGRhMmYzZTliYTc5ZTQ5OTJhN2E0YzExMzIxNWZiZjU0YzQ0MmFjOTAyMGMzMTVmOTUzNzA1Ojpjb2xsZWN0aW9uOjpORlQAAAA=",
              delegate: "0x0000000000000000000000000000000000000000000000000000000000000000"
            }
          }
        }
      }
    },
    libraries: {
      dynamicField: {
        value: {
          json: {
            send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib_timeout: null
          }
        }
      }
    },
    send: {
      dynamicField: {
        value: {
          json: {
            confirmations: "5",
            required_dvns: [
              "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
              "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
              "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
              "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
            ],
            optional_dvns: [],
            optional_dvn_threshold: 0
          }
        }
      }
    },
    receive: {
      dynamicField: {
        value: {
          json: {
            confirmations: "20",
            required_dvns: [
              "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
              "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
              "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
              "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
            ],
            optional_dvns: [],
            optional_dvn_threshold: 0
          }
        }
      }
    },
    executor: {
      dynamicField: {
        value: {
          json: {
            max_message_size: "10000",
            executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
          }
        }
      }
    },
    appLibraries: {
      dynamicField: {
        value: {
          json: {
            send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib_timeout: null
          }
        }
      }
    },
    appSend: {
      dynamicField: {
        value: {
          json: {
            use_default_confirmations: false,
            use_default_required_dvns: false,
            use_default_optional_dvns: false,
            uln_config: {
              confirmations: "5",
              required_dvns: [
                "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
                "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
                "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
              ],
              optional_dvns: [],
              optional_dvn_threshold: 0
            }
          }
        }
      }
    },
    appReceive: {
      dynamicField: {
        value: {
          json: {
            use_default_confirmations: false,
            use_default_required_dvns: false,
            use_default_optional_dvns: false,
            uln_config: {
              confirmations: "20",
              required_dvns: [
                "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
                "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
                "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
              ],
              optional_dvns: [],
              optional_dvn_threshold: 0
            }
          }
        }
      }
    },
    appExecutor: {
      dynamicField: {
        value: {
          json: {
            max_message_size: "10000",
            executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
          }
        }
      }
    }
  },
  candidate: {
    chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
    checkpoint: {
      sequenceNumber: 348240446,
      timestamp: "2026-11-23T05:23:36.524Z"
    },
    nft: {
      address: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
      version: 1100579540,
      digest: "4kUybSr2UuXay8xoJrQqsqTLqbmbaBB3nP3pjrAfQXxr",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
          },
          json: {
            id: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
            number: "2720",
            name: "Tree NFT #2720",
            description: "A unique tree from the Tree NFT collection. Rarity: Common",
            image_url: "https://black-persistent-capybara-279.mypinata.cloud/ipfs/bafybeieozgvnr7qc4ghsq36zwssuhj7xahuznjlmu6g63clnyt37hjsi4m/2720.jpg",
            rarity: "Common"
          }
        }
      }
    }
  },
  bnb: {
    chainId: 56,
    block: "0x80f3565",
    adapter: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
    pass: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
    purchasesPaused: true,
    state: "Unconfirmed",
    generation: 0,
    canPlay: false
  },
  bnbConfiguration: {
    complete: true,
    stage: 4,
    block: "0x80f3566",
    hashes: [
      "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733",
      "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
      "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
      "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b"
    ],
    totalGasFeeWei: "23726950000000"
  }
};

// docs/multichain/generation-milestone/reserve-review/quote-protocol-template.json
var quote_protocol_template_default = {
  version: 2,
  sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
  expiration: null,
  gasData: {
    budget: null,
    price: null,
    owner: null,
    payment: null
  },
  inputs: [
    {
      Object: {
        SharedObject: {
          objectId: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
          initialSharedVersion: "2",
          mutable: true
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
          initialSharedVersion: "1",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
          initialSharedVersion: "635685314",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
          initialSharedVersion: "635685319",
          mutable: false
        }
      }
    },
    {
      Pure: {
        bytes: "AQ=="
      }
    },
    {
      Pure: {
        bytes: "AA=="
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
          initialSharedVersion: "1089269258",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x52e0e092bf361557c68bd3b1c370b9c102dc834d874624d910e1656ebc08bedc",
          initialSharedVersion: "635685308",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x5f24ef7da5e93ca930bf3270468bc2268e84cc83e52c129ea3311b0d5df50c8e",
          initialSharedVersion: "635685317",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x05195518fab7b80e60bc7df11cf791d8658c614e7ed401fc768db77e744e70b3",
          initialSharedVersion: "635685318",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x492ac62cfb43eb1e858a877cf7a0cf396bf38bc1420c727c747ecc19cf9f4e5c",
          initialSharedVersion: "635685308",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xb6c5e08243222eb0bf95e98c66d26c628f7e0752b7272165d9e7867ff69c36a4",
          initialSharedVersion: "641876028",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x7f7ded52a6073633f8d642458b7899b0eaa7cd1ed7fb8098bd61730853afd3f7",
          initialSharedVersion: "635685317",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xff718d782c8881e9bcdca063c1e7999c77ee22d7cc6b34c84d5f6f4c2654f7da",
          initialSharedVersion: "635685316",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x1ab2f88e12bece2a39addc97cef895e48e0ed97d03eaa9bd2fa943ab4dd7300e",
          initialSharedVersion: "641875710",
          mutable: false
        }
      }
    }
  ],
  commands: [
    {
      MoveCall: {
        package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
        module: "vault",
        function: "quote",
        typeArguments: [
          "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
        ],
        arguments: [
          {
            Input: 0
          },
          {
            Input: 1
          },
          {
            Input: 4
          },
          {
            Input: 5
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "endpoint_v2",
        function: "quote",
        typeArguments: [],
        arguments: [
          {
            Input: 2
          },
          {
            Input: 6
          },
          {
            Result: 0
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
        module: "uln_302",
        function: "quote",
        typeArguments: [],
        arguments: [
          {
            Input: 3
          },
          {
            NestedResult: [
              1,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x011da80425fb389d1090743a2a33a48c479f4fd218a25db2cdc072b768a47ce5",
        module: "executor_worker",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 8
          },
          {
            NestedResult: [
              2,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x63e8c59b39720d833bffca2f50e51e48ef426ac0c6ab8e92cf6475c42f5bd24e",
        module: "executor_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 9
          },
          {
            NestedResult: [
              3,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              4,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x63e8c59b39720d833bffca2f50e51e48ef426ac0c6ab8e92cf6475c42f5bd24e",
        module: "executor_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 9
          },
          {
            NestedResult: [
              3,
              0
            ]
          },
          {
            NestedResult: [
              4,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x011da80425fb389d1090743a2a33a48c479f4fd218a25db2cdc072b768a47ce5",
        module: "executor_worker",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 8
          },
          {
            NestedResult: [
              2,
              0
            ]
          },
          {
            NestedResult: [
              3,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              2,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              8,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              9,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              8,
              0
            ]
          },
          {
            NestedResult: [
              9,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              2,
              1
            ]
          },
          {
            NestedResult: [
              8,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              2,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              13,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              14,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              13,
              0
            ]
          },
          {
            NestedResult: [
              14,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              2,
              1
            ]
          },
          {
            NestedResult: [
              13,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 14
          },
          {
            NestedResult: [
              2,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              18,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              19,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              18,
              0
            ]
          },
          {
            NestedResult: [
              19,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 14
          },
          {
            NestedResult: [
              2,
              1
            ]
          },
          {
            NestedResult: [
              18,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
        module: "uln_302",
        function: "confirm_quote",
        typeArguments: [],
        arguments: [
          {
            Input: 3
          },
          {
            Input: 7
          },
          {
            NestedResult: [
              1,
              0
            ]
          },
          {
            NestedResult: [
              2,
              0
            ]
          },
          {
            NestedResult: [
              2,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "endpoint_v2",
        function: "confirm_quote",
        typeArguments: [],
        arguments: [
          {
            Input: 2
          },
          {
            Result: 0
          },
          {
            NestedResult: [
              1,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
        module: "vault",
        function: "confirm_quote",
        typeArguments: [
          "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
        ],
        arguments: [
          {
            Input: 0
          },
          {
            Input: 1
          },
          {
            Result: 0
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "messaging_fee",
        function: "native_fee",
        typeArguments: [],
        arguments: [
          {
            NestedResult: [
              25,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "messaging_fee",
        function: "zro_fee",
        typeArguments: [],
        arguments: [
          {
            NestedResult: [
              25,
              1
            ]
          }
        ]
      }
    }
  ]
};

// docs/multichain/generation-milestone/reserve-review/send-protocol-template.json
var send_protocol_template_default = {
  version: 2,
  sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
  expiration: null,
  gasData: {
    budget: null,
    price: null,
    owner: null,
    payment: null
  },
  inputs: [
    {
      Object: {
        SharedObject: {
          objectId: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
          initialSharedVersion: "2",
          mutable: true
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
          initialSharedVersion: "1",
          mutable: true
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
          initialSharedVersion: "635685314",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
          initialSharedVersion: "635685319",
          mutable: false
        }
      }
    },
    {
      Pure: {
        bytes: "QSVZBAAAAAA="
      }
    },
    {
      Pure: {
        bytes: "AQ=="
      }
    },
    {
      Pure: {
        bytes: "AA=="
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
          initialSharedVersion: "1089269258",
          mutable: true
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x52e0e092bf361557c68bd3b1c370b9c102dc834d874624d910e1656ebc08bedc",
          initialSharedVersion: "635685308",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x5f24ef7da5e93ca930bf3270468bc2268e84cc83e52c129ea3311b0d5df50c8e",
          initialSharedVersion: "635685317",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x05195518fab7b80e60bc7df11cf791d8658c614e7ed401fc768db77e744e70b3",
          initialSharedVersion: "635685318",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x492ac62cfb43eb1e858a877cf7a0cf396bf38bc1420c727c747ecc19cf9f4e5c",
          initialSharedVersion: "635685308",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xb6c5e08243222eb0bf95e98c66d26c628f7e0752b7272165d9e7867ff69c36a4",
          initialSharedVersion: "641876028",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x7f7ded52a6073633f8d642458b7899b0eaa7cd1ed7fb8098bd61730853afd3f7",
          initialSharedVersion: "635685317",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0xff718d782c8881e9bcdca063c1e7999c77ee22d7cc6b34c84d5f6f4c2654f7da",
          initialSharedVersion: "635685316",
          mutable: false
        }
      }
    },
    {
      Object: {
        SharedObject: {
          objectId: "0x1ab2f88e12bece2a39addc97cef895e48e0ed97d03eaa9bd2fa943ab4dd7300e",
          initialSharedVersion: "641875710",
          mutable: false
        }
      }
    },
    {
      Pure: {
        bytes: "SFlT4urfSqAq+VDPjpFPvStnUjOF5zw2EYNBRZ2NRcQ="
      }
    }
  ],
  commands: [
    {
      SplitCoins: {
        coin: {
          GasCoin: true
        },
        amounts: [
          {
            Input: 4
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
        module: "vault",
        function: "send",
        typeArguments: [
          "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
        ],
        arguments: [
          {
            Input: 0
          },
          {
            Input: 1
          },
          {
            Input: 5
          },
          {
            Input: 6
          },
          {
            NestedResult: [
              0,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "endpoint_v2",
        function: "send",
        typeArguments: [],
        arguments: [
          {
            Input: 2
          },
          {
            Input: 7
          },
          {
            Result: 1
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
        module: "uln_302",
        function: "send",
        typeArguments: [],
        arguments: [
          {
            Input: 3
          },
          {
            NestedResult: [
              2,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x011da80425fb389d1090743a2a33a48c479f4fd218a25db2cdc072b768a47ce5",
        module: "executor_worker",
        function: "assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 9
          },
          {
            NestedResult: [
              3,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x63e8c59b39720d833bffca2f50e51e48ef426ac0c6ab8e92cf6475c42f5bd24e",
        module: "executor_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              4,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              5,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x63e8c59b39720d833bffca2f50e51e48ef426ac0c6ab8e92cf6475c42f5bd24e",
        module: "executor_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 10
          },
          {
            NestedResult: [
              4,
              0
            ]
          },
          {
            NestedResult: [
              5,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x011da80425fb389d1090743a2a33a48c479f4fd218a25db2cdc072b768a47ce5",
        module: "executor_worker",
        function: "confirm_assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 9
          },
          {
            NestedResult: [
              3,
              0
            ]
          },
          {
            NestedResult: [
              4,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              3,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              9,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              10,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              9,
              0
            ]
          },
          {
            NestedResult: [
              10,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 12
          },
          {
            NestedResult: [
              3,
              1
            ]
          },
          {
            NestedResult: [
              9,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 14
          },
          {
            NestedResult: [
              3,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              14,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              15,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              14,
              0
            ]
          },
          {
            NestedResult: [
              15,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 14
          },
          {
            NestedResult: [
              3,
              1
            ]
          },
          {
            NestedResult: [
              14,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 15
          },
          {
            NestedResult: [
              3,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              19,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xea932d79771b24103a1cda8e87a65068d6116c047f9dccc3e487cf8316625576",
        module: "price_feed",
        function: "estimate_fee_by_eid",
        typeArguments: [],
        arguments: [
          {
            Input: 11
          },
          {
            NestedResult: [
              20,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc3213e769e222f573edb14c63bf11b6481f3d3b66f2206f5911be07032390883",
        module: "dvn_fee_lib",
        function: "confirm_get_fee",
        typeArguments: [],
        arguments: [
          {
            Input: 13
          },
          {
            NestedResult: [
              19,
              0
            ]
          },
          {
            NestedResult: [
              20,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x60d4ef2e0e057d19e947406ccec3ac4d0208adc8e1981964ab2552166a30f461",
        module: "dvn",
        function: "confirm_assign_job",
        typeArguments: [],
        arguments: [
          {
            Input: 15
          },
          {
            NestedResult: [
              3,
              1
            ]
          },
          {
            NestedResult: [
              19,
              0
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
        module: "uln_302",
        function: "confirm_send",
        typeArguments: [],
        arguments: [
          {
            Input: 3
          },
          {
            Input: 2
          },
          {
            Input: 8
          },
          {
            Input: 7
          },
          {
            Result: 1
          },
          {
            NestedResult: [
              2,
              0
            ]
          },
          {
            NestedResult: [
              3,
              0
            ]
          },
          {
            NestedResult: [
              3,
              1
            ]
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
        module: "vault",
        function: "confirm_send",
        typeArguments: [
          "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
        ],
        arguments: [
          {
            Input: 0
          },
          {
            Input: 1
          },
          {
            Result: 1
          }
        ]
      }
    },
    {
      MoveCall: {
        package: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac",
        module: "endpoint_send",
        function: "destroy",
        typeArguments: [],
        arguments: [
          {
            NestedResult: [
              25,
              0
            ]
          }
        ]
      }
    },
    {
      TransferObjects: {
        objects: [
          {
            NestedResult: [
              26,
              0
            ]
          }
        ],
        address: {
          Input: 16
        }
      }
    },
    {
      MoveCall: {
        package: "0x0000000000000000000000000000000000000000000000000000000000000001",
        module: "option",
        function: "destroy_none",
        typeArguments: [
          "0x0000000000000000000000000000000000000000000000000000000000000002::coin::Coin<0x3de1504cf3fd75762759e353d9d95389618e557d0552697f19b52e4e927c1dee::zro::ZRO>"
        ],
        arguments: [
          {
            NestedResult: [
              26,
              1
            ]
          }
        ]
      }
    }
  ]
};

// contracts/nftree-generation/scripts/reserve-transaction.mjs
var check4 = (v, m) => {
  if (!v) throw Error(m);
};
function validateEmptyBound(p) {
  const s = p.current;
  check4(s.chainIdentifier === C2.chain, "Wrong Sui chain");
  const normalized = structuredClone(s);
  for (const n of ["vault", "oapp", "channel"]) {
    check4(canonical(s[n].asMoveObject.contents.json) === canonical(user_receipt_default3.current[n].asMoveObject.contents.json), "Bound " + n + " changed");
    normalized[n].asMoveObject.contents.json = structuredClone(baseline_default[n].asMoveObject.contents.json);
  }
  validateConfigState(normalized, 1);
  const nft = p.candidate.nft;
  check4(nft.address === C2.nft && nft.owner.address.address === C2.sender && nft.asMoveObject.contents.type.repr === C2.nftType && nft.asMoveObject.contents.json.number === "2720", "Original NFT identity/ownership changed");
  check4(p.bnb.purchasesPaused && p.bnb.state === "Unconfirmed" && p.bnb.generation === 0 && !p.bnb.canPlay && p.bnbConfiguration.complete && p.bnbConfiguration.stage === 4 && canonical(p.bnbConfiguration.hashes) === canonical(user_receipt_default2.transactionHashes), "BNB readiness changed");
}
function reserveTransaction(kind, before, fee = 0n) {
  check4(["quote", "send"].includes(kind), "Invalid action");
  validateEmptyBound(before);
  const d = structuredClone(kind === "quote" ? quote_protocol_template_default : send_protocol_template_default);
  if (kind === "send") {
    check4(BigInt(fee) > 0n && BigInt(fee) <= 250000000n, "Message fee exceeds approved limit");
    d.inputs[4] = { FundsWithdrawal: { reservation: { MaxAmountU64: String(fee) }, typeArg: { Balance: "0x0000000000000000000000000000000000000000000000000000000000000002::sui::SUI" }, withdrawFrom: { Sender: true } } };
    d.commands[0] = { MoveCall: { package: "0x0000000000000000000000000000000000000000000000000000000000000002", module: "coin", function: "redeem_funds", typeArguments: ["0x0000000000000000000000000000000000000000000000000000000000000002::sui::SUI"], arguments: [{ Input: 4 }] } };
  }
  const n = before.candidate.nft, index = d.inputs.length;
  d.inputs.push({ Object: { ImmOrOwnedObject: { objectId: n.address, version: String(n.version), digest: n.digest } } });
  const shift = (x) => Array.isArray(x) ? x.map(shift) : x && typeof x === "object" ? Object.fromEntries(Object.entries(x).map(([k, v]) => [k, k === "Result" ? v + 1 : k === "NestedResult" ? [v[0] + 1, v[1]] : shift(v)])) : x;
  d.commands = d.commands.map(shift);
  d.commands.unshift({ MoveCall: { package: C2.package, module: "vault", function: "fund", typeArguments: [C2.nftType], arguments: [{ Input: 0 }, { Input: index }] } });
  const tx = Transaction9.from(JSON.stringify(d));
  tx.setGasBudget(1e8);
  tx.setGasPayment([]);
  return tx;
}

// contracts/nftree-generation/scripts/reserve-review.mjs
import { encodePacked, keccak256 as keccak2562, concatHex } from "viem";
var assert9 = Object.assign((v, m = "Reserve validation failed") => {
  if (!v) throw Error(m);
}, { equal: (a, b, m) => {
  if (a !== b) throw Error(m || "Reserve value differs");
}, deepEqual: (a, b) => {
  if (canonical(a) !== canonical(b)) throw Error("Reserve structure differs");
} });
var executorPayee = "0xf99b445ae678d3f28fe7acb91e5d7ee8ab538d7e231a837b12c593fb624ad630";
var dvnPayee = "0x9004e1e4c6dcc42d1b73269db48d510192665677fcad2079a3c7d1e9e971d34e";
var guid = keccak2562(encodePacked(["uint64", "uint32", "bytes32", "uint32", "bytes32"], [1n, 30378, C2.package, 30102, peer]));
var payload = "0x0301" + C2.vault.slice(2) + C2.nft.slice(2) + "0000000000000001" + "00".repeat(64);
var packet = concatHex([encodePacked(["uint8", "uint64", "uint32", "bytes32", "uint32", "bytes32"], [1, 1n, 30378, C2.package, 30102, peer]), guid, payload]);
var b64 = (h) => btoa(String.fromCharCode(...Uint8Array.from(h.replace(/^0x/, "").match(/../g), (x) => parseInt(x, 16))));
var json4 = (o) => o.asMoveObject.contents.json;
var norm2 = (x) => JSON.parse(JSON.stringify(x, (k, v) => k === "$kind" || k === "type" ? void 0 : ["initialSharedVersion", "version"].includes(k) ? String(v) : v));
function verifyReserve(result, unsigned, before, post, fee) {
  assert9.equal(result.$kind, "Transaction");
  const t = result.Transaction;
  assert9.equal(t.status.success, true);
  assert9.equal(t.transaction.sender, C2.sender);
  assert9.equal(t.transaction.gasData.owner, C2.sender);
  assert9.equal(t.transaction.gasData.budget, "100000000");
  assert9(BigInt(fee) > 0n && BigInt(fee) <= 250000000n);
  for (const k of ["inputs", "commands"]) assert9.equal(canonical(norm2(t.transaction[k])), canonical(norm2(unsigned[k])), "Exact " + k);
  const [fund, ex, dvn, sent] = t.events;
  assert9.equal(t.events.length, 4);
  assert9.equal(fund.eventType, C2.package + "::vault::Funded");
  assert9.deepEqual(fund.json, { vault: C2.vault, nft: { bytes: b64(C2.nft) }, generation: "1", destination: 30102, adapter: { bytes: b64(peer) } });
  assert9.equal(ex.eventType, C2.ulnPackage + "::send_uln::ExecutorFeePaidEvent");
  assert9.equal(ex.json.executor, C2.executor);
  assert9.deepEqual(ex.json.guid, { bytes: b64(guid) });
  assert9.equal(ex.json.fee.recipient, executorPayee);
  assert9.equal(dvn.eventType, C2.ulnPackage + "::send_uln::DVNFeePaidEvent");
  assert9.deepEqual(dvn.json.guid, ex.json.guid);
  assert9.deepEqual(dvn.json.dvns, C2.dvns);
  assert9.equal(dvn.json.fees.length, 3);
  for (const f of dvn.json.fees) assert9.equal(f.recipient, dvnPayee);
  assert9.equal(sent.eventType, C2.endpointPackage + "::messaging_channel::PacketSentEvent");
  assert9.deepEqual(sent.json, { encoded_packet: b64(packet), options: b64(options), send_library: C2.ulnPackage });
  const fees = [ex.json.fee, ...dvn.json.fees];
  assert9(fees.every((x) => BigInt(x.fee) > 0n));
  assert9.equal(fees.reduce((n, x) => n + BigInt(x.fee), 0n), BigInt(fee));
  const g = t.effects.gasUsed, gross = BigInt(g.computationCost) + BigInt(g.storageCost), net = gross - BigInt(g.storageRebate);
  assert9(gross > 0n && gross <= 100000000n && net >= 0n);
  const balances = /* @__PURE__ */ new Map([[C2.sender, -BigInt(fee) - net]]);
  for (const x of fees) balances.set(x.recipient, (balances.get(x.recipient) || 0n) + BigInt(x.fee));
  assert9.equal(t.balanceChanges.length, balances.size);
  for (const x of t.balanceChanges) {
    assert9(/^0x0*2::sui::SUI$/.test(x.coinType));
    assert9.equal(BigInt(x.amount), balances.get(x.address));
    balances.delete(x.address);
  }
  assert9.equal(balances.size, 0);
  assert9(!post.errors);
  const effects = post.data.simulateTransaction.effects;
  assert9.equal(effects.status, "SUCCESS");
  assert9.equal(effects.objectChanges.pageInfo.hasNextPage, false);
  const nodes = effects.objectChanges.nodes, at = (id) => nodes.find((x) => x.address === id)?.outputState;
  const v = structuredClone(json4(before.current.vault));
  v.nft = before.candidate.nft.asMoveObject.contents.json;
  v.phase = 1;
  v.generation = "1";
  v.announced = true;
  assert9.deepEqual(json4(at(C2.vault)), v);
  for (const n of ["oapp", "channel"]) assert9.deepEqual(json4(at(C2[n])), json4(before.current[n]));
  const path = nodes.filter((x) => x.outputState?.asMoveObject?.contents?.json?.name?.remote_eid === 30102);
  assert9.equal(path.length, 1);
  const pathJson = json4(path[0].outputState);
  assert9.deepEqual(pathJson.name, { remote_eid: 30102, remote_oapp: { bytes: b64(peer) } });
  assert9.equal(pathJson.value.outbound_nonce, "1");
  assert9.equal(pathJson.value.lazy_inbound_nonce, "0");
  assert9.equal(pathJson.value.inbound_payload_hashes.size, "0");
  const shared = /* @__PURE__ */ new Map([[C2.vault, "2"], [C2.oapp, "1"], [C2.channel, C2.channelVersion]]), gasIds = /* @__PURE__ */ new Set([t.effects.gasObject?.objectId, ...t.transaction.gasData.payment.map((x) => x.objectId)]);
  let writes = /* @__PURE__ */ new Set();
  for (const x of t.effects.changedObjects) {
    if (x.inputState === "Exists") {
      if (gasIds.has(x.objectId)) {
        assert9.equal(x.inputOwner.AddressOwner, C2.sender);
        assert9(!x.outputOwner || x.outputOwner.AddressOwner === C2.sender);
        continue;
      }
      writes.add(x.objectId);
      assert9.equal(x.idOperation, "None");
      if (x.objectId === C2.nft) {
        assert9.equal(x.inputOwner.AddressOwner, C2.sender);
        assert9.equal(x.outputState, "DoesNotExist");
        assert9.equal(x.outputOwner, null);
      } else {
        assert9.equal(x.outputState, "ObjectWrite");
        assert9.deepEqual(x.inputOwner, x.outputOwner);
        if (shared.has(x.objectId)) assert9.equal(String(x.outputOwner.Shared.initialSharedVersion), shared.get(x.objectId));
        else {
          assert9.equal(x.objectId, path[0].address);
          assert9.equal(x.outputOwner.ObjectOwner, json4(before.current.channel).channels.id);
        }
      }
    } else if (x.outputState === "ObjectWrite") {
      assert9.equal(x.idOperation, "Created");
      assert9(/^0x0*2::coin::Coin<0x0*2::sui::SUI>$/.test(t.objectTypes[x.objectId]));
      assert9([C2.sender, executorPayee, dvnPayee].includes(x.outputOwner.AddressOwner));
    } else assert9(x.inputState === "DoesNotExist" && x.outputOwner === null && (x.outputState === "DoesNotExist" && x.idOperation === "Created" || x.outputState === "AccumulatorWriteV1" && x.idOperation === "None"));
  }
  assert9.deepEqual([...writes].sort(), [C2.nft, C2.vault, C2.oapp, C2.channel, path[0].address].sort());
  return { guid, payload, messageFeeMist: String(fee), netGasMist: String(net), grossGasMist: String(gross), estimatedTotalMist: String(BigInt(fee) + net), fees, atomicDepositAndSend: true, submitted: false };
}

// contracts/nftree-generation/scripts/reserve-bnb.mjs
import { encodeFunctionData as encodeFunctionData2, decodeFunctionResult as decodeFunctionResult2, parseAbi as parseAbi2, keccak256 as keccak2563 } from "viem";
import assert10 from "node:assert/strict";
async function verifyReserveBnb(fetcher = fetch) {
  let id = 0;
  const rpc = async (method, params = []) => {
    assert10(["eth_chainId", "eth_blockNumber", "eth_getCode", "eth_call", "eth_getTransactionByHash", "eth_getTransactionReceipt", "eth_getBlockByNumber"].includes(method));
    const n = ++id, r = await fetcher("https://bsc-rpc.publicnode.com", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: n, method, params }), signal: AbortSignal.timeout(15e3) });
    assert10(r.ok);
    const j = await r.json();
    assert10(!j.error && j.id === n);
    return j.result;
  };
  assert10.equal(await rpc("eth_chainId"), "0x38");
  const block = await rpc("eth_blockNumber");
  const abi = parseAbi2(["function state() view returns(uint8)", "function generation() view returns(uint64)", "function delivered(bytes32) view returns(bytes32)"]);
  const stateData = encodeFunctionData2({ abi, functionName: "state" }), genData = encodeFunctionData2({ abi, functionName: "generation" });
  const rows = [...new Map(rpc_reads_default.filter((x) => !["eth_chainId", "eth_blockNumber"].includes(x.method) && !(x.method === "eth_call" && x.params[0].to.toLowerCase() === pinned_build_default.addresses.pass.toLowerCase() && [stateData, genData].includes(x.params[0].data))).map((x) => [JSON.stringify([x.method, x.params]), x])).values()];
  for (let i = 0; i < rows.length; i += 8) await Promise.all(rows.slice(i, i + 8).map(async (x) => {
    const params = structuredClone(x.params);
    if (["eth_getCode", "eth_call"].includes(x.method)) params[1] = block;
    const actual = await rpc(x.method, params);
    if (x.method === "eth_getBlockByNumber") assert10.equal(actual.hash, x.result.hash, "Receipt block changed");
    else assert10.deepEqual(actual, x.result, "BNB receipt/runtime/configuration changed: " + x.method);
  }));
  const call = async (to, name, args = []) => decodeFunctionResult2({ abi, functionName: name, data: await rpc("eth_call", [{ to, data: encodeFunctionData2({ abi, functionName: name, args }) }, block]) });
  const state = Number(await call(pinned_build_default.addresses.pass, "state")), generation = Number(await call(pinned_build_default.addresses.pass, "generation")), delivered = await call(pinned_build_default.addresses.adapter, "delivered", [guid]);
  assert10(state === 0 && generation === 0 && delivered === "0x" + "0".repeat(64) || state === 1 && generation === 1 && delivered === keccak2563(payload), "Unexpected destination lifecycle or message hash");
  return { complete: true, block, guid, payloadHash: delivered, destinationVerified: state === 1, state: state === 1 ? "Ready" : "Unconfirmed", generation, purchasesPaused: true, canPlay: false, hashes: user_receipt_default2.transactionHashes };
}

// docs/multichain/generation-milestone/binding-completed/verified/verification.json
var verification_default = {
  checkedAt: "2026-11-23T05:24:38.200Z",
  submitted: false,
  digest: "EkZHu7fFx93QkttEekqXuqHrnQnfS6pNbZLUmeCcVf1a",
  packageId: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
  vaultId: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
  gasMist: "9266747",
  channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
  peer: "0x00000000000000000000000074c20deb476dca58459956b1acd65771197900c9",
  empty: true,
  generation: 0,
  step: 6,
  bound: true,
  current: {
    chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
    checkpoint: {
      sequenceNumber: 348240675,
      timestamp: "2026-11-23T05:24:32.805Z"
    },
    endpoint: {
      address: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
      version: 1096510922,
      digest: "9o4Ns6gwz7FmuGreY6LA1i1JokDsGsbuDksV9Kf9zSnJ",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 635685314
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::endpoint_v2::EndpointV2"
          },
          json: {
            id: "0xd45b6890fa030bcb43347c0c69a9e5a1a288d1ca7b86b428014752b472f6bf91",
            eid: 30378,
            call_cap: {
              id: "0x8de954b904b90f887ff2e81ff3362ca89e883da6529e55723758cd5093234b0d",
              cap_type: {
                "@variant": "Package",
                pos0: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac"
              }
            },
            oapp_registry: {
              oapps: {
                id: "0x720fc2300c05bb7ad68aefec00a9796b4451c4d1df78bc72cd8c98e774220bec",
                size: "143"
              }
            },
            composer_registry: {
              composers: {
                id: "0xb41ca35805177b946bebf5d339712b4e9bb562b068b33851001f9f0b66847814",
                size: "7"
              }
            },
            message_lib_manager: {
              registry: {
                libs: {
                  contents: {
                    id: "0x520bbc08883e22efb29f50283e25b4561ffa7c7b9d7774b14fc1c6272e593e03",
                    size: "2"
                  }
                },
                lib_to_type: {
                  id: "0xb136bb2fc780a76e636c10f10b10ab33754a3573efa5f1285bf2b35eaf73b50d",
                  size: "2"
                }
              },
              default_configs: {
                id: "0xa2371851318b3ba333270daf696dedbc7b89a1107ca362643798c1789ce05a01",
                size: "126"
              },
              oapp_configs: {
                id: "0x0e679b0fcc94fb07a5ec9a14712f8e35e0994b892e64a434e898450eb670e920",
                size: "101"
              }
            }
          }
        }
      }
    },
    uln: {
      address: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
      version: 1096510922,
      digest: "DZyejj6bY4E6EmLaw3kgsWXera1RVmgwL8xLDHrLVhCt",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 635685319
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0::uln_302::Uln302"
          },
          json: {
            id: "0x8ebd7a0b102a5f7a3d4a08d84dd853fecc4ae0093be6eb02cf0d11dce7d4861f",
            call_cap: {
              id: "0xfacd801d08e3a99c907148fa00ec5f17a0a3ac831dbc95bcd75e601006caafa9",
              cap_type: {
                "@variant": "Package",
                pos0: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0"
              }
            },
            send_uln: {
              default_executor_configs: {
                id: "0x346b468d90db8743673c7ed4fdbe1c40f6a587aac6acc730b3a9bb86cf0919f4",
                size: "126"
              },
              default_uln_configs: {
                id: "0x2bd7d044d837b718a7852959c701c04e842e648cf9047b442d55c838846a13e5",
                size: "126"
              },
              oapp_executor_configs: {
                id: "0x357a98886ef14de3d15e538a808b410cfe026f6b1f971bb2398978d56e4dc181",
                size: "55"
              },
              oapp_uln_configs: {
                id: "0xc53b8a5592cdeea1a7421d209ba5c70e6843d2911e5bb86ad9fb744d888eab60",
                size: "215"
              }
            },
            receive_uln: {
              default_uln_configs: {
                id: "0x5ddc28272722231ecef30237bb48715f128d6995b89a46db25cd9adae0140835",
                size: "126"
              },
              oapp_uln_configs: {
                id: "0x0d89da4d00f46c4b1dab465a867e60eacbf646e56f8816ae55cd7b9495c1bb09",
                size: "240"
              },
              verification: "0x950f66ed27ec0a01a52bda147d74165d4cc20165f0cee0ecae6aaacde13d7741"
            }
          }
        }
      }
    },
    oapp: {
      address: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
      version: 1096510923,
      digest: "F72w92xHUVa8J2fHAmVkWjyhpmmZubUxTufqNCPKeZ2H",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::OApp"
          },
          json: {
            id: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            oapp_cap: {
              id: "0x6b7c66d2135ce12efa6a23037bff2e5ca1b499db24bc200592d08c2595cf5a3a",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            admin_cap: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
            peer: {
              peers: {
                id: "0x984eb93d6713b0909152e249bcfa465a6661e7403c5b01266353b97ff2318966",
                size: "1"
              }
            },
            enforced_options: {
              options: {
                id: "0xd1c0dbf02c954d88cf9602f43c877ddaed3d8cf5afb4e71f83ccf9fbed78e497",
                size: "2"
              }
            },
            sending_call: null
          }
        }
      }
    },
    admin: {
      address: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d",
      version: 1096510923,
      digest: "CXbdvybk5zVFVkPzd7imMGpj85r974bT5B1dMhCybeWo",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24::oapp::AdminCap"
          },
          json: {
            id: "0x97be99b8e5c3b8953323c0a481b848c990b9d32814950d803b754b4e140fe25d"
          }
        }
      }
    },
    vault: {
      address: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
      version: 1096510923,
      digest: "7Ws7gNQy9yg7nmwRQH3XbZYifNLavknAgvLJYg6W1fEz",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 2
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92::vault::Vault<0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT>"
          },
          json: {
            id: "0xf5dff8e2cc96824f89735fa16c068ee8194fbb7e8d697aeebe5d135f8a5916eb",
            version: "1",
            registry: "0x298204d60d1a886e72f1ece18de179065d487a76420f93b19bf7f61c7275c210",
            cap: {
              id: "0x1711b6b0e442e8299ea3aceb30286234520c8f1c4d2294aa7d031308a3d7bcff",
              cap_type: {
                "@variant": "Package",
                pos0: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92"
              }
            },
            oapp: "0x0da3d845f4ab18a0a8d2f0669722a1d9161c2ea61ad714abc14d414721fd14e4",
            nft: null,
            backing: {
              bytes: "BG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWpro="
            },
            route: {
              bytes: "9d/44syWgk+Jc1+hbAaO6BlPu36NaXruvl0TX4pZFus="
            },
            peer: {
              bytes: "AAAAAAAAAAAAAAAAdMIN60dtylhFmVaxrNZXcRl5AMk="
            },
            bound: true,
            paused: false,
            phase: 0,
            generation: "0",
            announced: false,
            ack_sent: false,
            request: {
              bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            },
            recipient: {
              bytes: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            }
          }
        }
      }
    },
    channel: {
      address: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
      version: 1096510923,
      digest: "6YArcujgwcw7YughAQ8GidRijkHX38LpNzSSQ3cnVs8t",
      owner: {
        __typename: "Shared",
        initialSharedVersion: 1089269258
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::messaging_channel::MessagingChannel"
          },
          json: {
            id: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
            oapp: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            channels: {
              id: "0xc631f02da694ee43bc4923570de9f6d53cbccbdb72986cf63dc84e77744c0e95",
              size: "1"
            },
            is_sending: false
          }
        }
      }
    },
    registration: {
      address: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
      version: 1096510922,
      digest: "8fcLbkwf639cvZt7t54EXo4wypKhLcodVebYfKcCzBx7",
      owner: {
        __typename: "ObjectOwner"
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0x0000000000000000000000000000000000000000000000000000000000000002::dynamic_field::Field<address,0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac::oapp_registry::OAppRegistration>"
          },
          json: {
            id: "0x6e8f3156b67d9e5f35c4874604b868bdecf9df52d61a6be90a87b5033ecd9d3a",
            name: "0xc445519bf1d6ed8ab6002d20ad7ed81a9ad25e31990df9b72203d0ad86fd2e92",
            value: {
              messaging_channel: "0x63ee0fb967cf71aecd39d095a02aae6607d18b087c9537f4d7c4d0c8cf199023",
              oapp_info: "AAENo9hF9KsYoKjS8GaXIqHZFhwuphrXFKvBTUFHIf0U5ADwAQABAcRFUZvx1u2KtgAtIK1+2Bqa0l4xmQ35tyID0K2G/S6SBXZhdWx0Cmx6X3JlY2VpdmUDAfXf+OLMloJPiXNfoWwGjugZT7t+jWl67r5dE1+KWRbrAQ2j2EX0qxigqNLwZpciodkWHC6mGtcUq8FNQUch/RTkACBkICYW91pWFKz6JkQYJYUhKZ62qJLu7qOS/u+JSMfrUwFTMHhmNmM2ZDQzOWVhMGRhMmYzZTliYTc5ZTQ5OTJhN2E0YzExMzIxNWZiZjU0YzQ0MmFjOTAyMGMzMTVmOTUzNzA1Ojpjb2xsZWN0aW9uOjpORlQAAAA=",
              delegate: "0x0000000000000000000000000000000000000000000000000000000000000000"
            }
          }
        }
      }
    },
    libraries: {
      dynamicField: {
        value: {
          json: {
            send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib_timeout: null
          }
        }
      }
    },
    send: {
      dynamicField: {
        value: {
          json: {
            confirmations: "5",
            required_dvns: [
              "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
              "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
              "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
              "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
            ],
            optional_dvns: [],
            optional_dvn_threshold: 0
          }
        }
      }
    },
    receive: {
      dynamicField: {
        value: {
          json: {
            confirmations: "20",
            required_dvns: [
              "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
              "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
              "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91",
              "0xfa35508c624925c6f341113f8f9397e5f41750b833af87d0c945a6f5682887f0"
            ],
            optional_dvns: [],
            optional_dvn_threshold: 0
          }
        }
      }
    },
    executor: {
      dynamicField: {
        value: {
          json: {
            max_message_size: "10000",
            executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
          }
        }
      }
    },
    appLibraries: {
      dynamicField: {
        value: {
          json: {
            send_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib: "0x3ce7457bed48ad23ee5d611dd3172ae4fbd0a22ea0e846782a7af224d905dbb0",
            receive_lib_timeout: null
          }
        }
      }
    },
    appSend: {
      dynamicField: {
        value: {
          json: {
            use_default_confirmations: false,
            use_default_required_dvns: false,
            use_default_optional_dvns: false,
            uln_config: {
              confirmations: "5",
              required_dvns: [
                "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
                "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
                "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
              ],
              optional_dvns: [],
              optional_dvn_threshold: 0
            }
          }
        }
      }
    },
    appReceive: {
      dynamicField: {
        value: {
          json: {
            use_default_confirmations: false,
            use_default_required_dvns: false,
            use_default_optional_dvns: false,
            uln_config: {
              confirmations: "20",
              required_dvns: [
                "0x0c12321ebe562b8fb8a74e6d29f144ea199a8f31a4cea3a417ce72477f6dfebb",
                "0x52aa129049de845353484868d1be6e2df6878b0ed2213d94d3c827309aeae685",
                "0x92128a5edf4a0f696464de66d00986ef41b37faf705ceb3d9d9a4e5c306fbf91"
              ],
              optional_dvns: [],
              optional_dvn_threshold: 0
            }
          }
        }
      }
    },
    appExecutor: {
      dynamicField: {
        value: {
          json: {
            max_message_size: "10000",
            executor: "0xde7fe1a6648d587fcc991f124f3aa5b6389340610804108094d5c5fbf61d1989"
          }
        }
      }
    }
  },
  candidate: {
    chainIdentifier: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
    checkpoint: {
      sequenceNumber: 348240677,
      timestamp: "2026-11-23T05:24:33.287Z"
    },
    nft: {
      address: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
      version: 1100579540,
      digest: "4kUybSr2UuXay8xoJrQqsqTLqbmbaBB3nP3pjrAfQXxr",
      owner: {
        __typename: "AddressOwner",
        address: {
          address: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4"
        }
      },
      asMoveObject: {
        contents: {
          type: {
            repr: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT"
          },
          json: {
            id: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
            number: "2720",
            name: "Tree NFT #2720",
            description: "A unique tree from the Tree NFT collection. Rarity: Common",
            image_url: "https://black-persistent-capybara-279.mypinata.cloud/ipfs/bafybeieozgvnr7qc4ghsq36zwssuhj7xahuznjlmu6g63clnyt37hjsi4m/2720.jpg",
            rarity: "Common"
          }
        }
      }
    }
  },
  bnb: {
    chainId: 56,
    block: "0x80f35e3",
    adapter: "0x74c20dEB476Dca58459956b1AcD65771197900C9",
    pass: "0x418cC337FC19D8cf3b41a9C6E3138a60E34Eb9b5",
    purchasesPaused: true,
    state: "Unconfirmed",
    generation: 0,
    canPlay: false
  },
  bnbConfiguration: {
    complete: true,
    stage: 4,
    block: "0x80f35e8",
    hashes: [
      "0x6a9ae80a8d3745ea00b4447417bd2e786b74f37174a80564e9f3f6c3c42dd733",
      "0x2d0ccd98cc44f8f3a4bffdfb791ae3800e3180920aa141778b1e7e0a15537a2b",
      "0x033aa1f377e6e670c1d8fe11ba328f773b339557e6890b798ba3f7f6ec832d5a",
      "0x1fbbdd74254b902908ccbcd7821536738e7d5c1d20f64ec0d9a1f1a226f19b8b"
    ],
    totalGasFeeWei: "23726950000000"
  }
};

// contracts/nftree-generation/scripts/reserve-handoff.mjs
var digest = "EkZHu7fFx93QkttEekqXuqHrnQnfS6pNbZLUmeCcVf1a";
async function prepareReserveHandoff(client = newClient()) {
  const before = await verifyBindingReceipt(digest, client);
  validateEmptyBound(before);
  const q = reserveTransaction("quote", before), qb = await q.build({ client }), qr = await client.core.simulateTransaction({ transaction: qb, checksEnabled: true, doGasSelection: false, include: { commandResults: true } });
  assert11(qr.Transaction.status.success);
  const cr = qr.commandResults, fee = BigInt(bcs3.u64().parse(Uint8Array.from(cr.at(-2).returnValues[0].bcs)));
  assert11.equal(BigInt(bcs3.u64().parse(Uint8Array.from(cr.at(-1).returnValues[0].bcs))), 0n);
  assert11(fee > 0n && fee <= 250000000n);
  const balance = await client.core.getBalance({ owner: C2.sender });
  assert11(BigInt(balance.balance.addressBalance) >= fee + 100000000n, "Insufficient address balance for fee plus gas maximum");
  const tx = reserveTransaction("send", before, fee), bytes = await tx.build({ client }), simulation = await client.core.simulateTransaction({ transaction: bytes, checksEnabled: true, doGasSelection: false, include: { effects: true, events: true, transaction: true, balanceChanges: true, objectTypes: true, bcs: true } });
  assert11.deepEqual(Buffer.from(Object.values(simulation.Transaction.bcs)), Buffer.from(bytes));
  const post = await client.query({ query: POST_QUERY, variables: { tx: { bcs: { value: Buffer.from(bytes).toString("base64") } } } });
  const proof = verifyReserve(simulation, JSON.parse(await tx.toJSON()), before, post, fee);
  const after = await verifyBindingReceipt(digest, client);
  for (const n of ["vault", "oapp", "channel", "admin", "registration", "appSend", "appReceive", "appLibraries", "appExecutor"]) assert11.equal(canonical(before.current[n]), canonical(after.current[n]));
  assert11.deepEqual(before.candidate.nft, after.candidate.nft);
  return { schema: "tree-generation-reserve-handoff-v1", preparedAt: Date.now(), transactionBase64: Buffer.from(bytes).toString("base64"), messageFeeMist: String(fee), estimatedNetGasMist: proof.netGasMist, estimatedTotalMist: proof.estimatedTotalMist, before, after, simulation, post, proof };
}
async function verifyReserveReceipt(digest2, client = newClient(), bnbVerifier = verifyReserveBnb) {
  const result = await client.core.getTransaction({ digest: digest2, include: { effects: true, events: true, transaction: true, balanceChanges: true, objectTypes: true, bcs: true } });
  assert11.equal(result.Transaction?.digest, digest2);
  const t = result.Transaction, before = structuredClone(verification_default);
  const nftRef = t.transaction.inputs.flatMap((x) => x.Object?.ImmOrOwnedObject ? [x.Object.ImmOrOwnedObject] : []);
  assert11.equal(nftRef.length, 1);
  assert11.equal(nftRef[0].objectId, C2.nft);
  Object.assign(before.candidate.nft, { version: String(nftRef[0].version), digest: nftRef[0].digest });
  const fee = BigInt(t.transaction.inputs[4].FundsWithdrawal.reservation.MaxAmountU64), expected = reserveTransaction("send", before, fee);
  const ids = t.effects.changedObjects.filter((x) => x.outputState === "ObjectWrite").map((x) => x.objectId), r = await client.query({ query: "query{checkpoint{sequenceNumber timestamp} " + ids.map((id, i) => "o" + i + ':object(address:"' + id + '"){' + fields + "}").join(" ") + "}" });
  assert11(!r.errors && r.data);
  assert11(Date.now() - Date.parse(r.data.checkpoint.timestamp) >= -3e4 && Date.now() - Date.parse(r.data.checkpoint.timestamp) < 12e4);
  const objects = Object.entries(r.data).filter(([k]) => k !== "checkpoint").map(([, o]) => o);
  const post = { data: { simulateTransaction: { effects: { status: "SUCCESS", objectChanges: { pageInfo: { hasNextPage: false }, nodes: objects.map((o) => ({ address: o.address, outputState: { asMoveObject: o.asMoveObject } })) } } } } };
  const proof = verifyReserve(result, JSON.parse(await expected.toJSON()), before, post, fee);
  const state = await client.query({ query: STATE_QUERY });
  assert11(!state.errors);
  const age = Date.now() - Date.parse(state.data.checkpoint.timestamp);
  assert11(age >= -3e4 && age < 12e4, "Stale security state");
  const normalized = structuredClone(state.data);
  for (const n of ["vault", "oapp", "channel"]) normalized[n].asMoveObject.contents.json = structuredClone(baseline_default[n].asMoveObject.contents.json);
  validateConfigState(normalized, 1);
  assert11.equal(normalized.chainIdentifier, C2.chain);
  const bnb = await bnbVerifier();
  return { digest: digest2, packageId: C2.package, vaultId: C2.vault, originalNft: C2.nft, ...proof, submitted: true, sourceVerified: true, nftHeld: true, phase: 1, generation: 1, announced: true, checkpoint: r.data.checkpoint, bnb, destinationVerified: bnb.destinationVerified };
}

// netlify/preview-functions/generation-reserve.mjs
var config = { path: "/api/generation-reserve" };
async function handler(request) {
  const headers = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };
  if (request.method !== "GET") return new Response("Read-only endpoint", { status: 405, headers });
  try {
    const url = new URL(request.url), digest2 = url.searchParams.get("digest");
    if (digest2) {
      if (!/^[1-9A-HJ-NP-Za-km-z]{43,44}$/.test(digest2) || [...url.searchParams].length !== 1) throw Error("Invalid receipt request");
      return Response.json(await verifyReserveReceipt(digest2), { headers });
    }
    if (url.search) throw Error("Unexpected parameters");
    return Response.json(await prepareReserveHandoff(), { headers });
  } catch (e) {
    return Response.json({ error: String(e.message) }, { status: 502, headers });
  }
}
export {
  config,
  handler as default
};
