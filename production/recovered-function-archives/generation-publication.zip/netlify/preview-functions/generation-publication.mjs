
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// contracts/nftree-generation/scripts/wallet-handoff.mjs
import assert2 from "node:assert/strict";
import { createHash as createHash2 } from "node:crypto";
import { Transaction as Transaction3 } from "@mysten/sui/transactions";

// contracts/nftree-generation/scripts/readiness.mjs
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { Transaction } from "@mysten/sui/transactions";
import { SuiGraphQLClient } from "@mysten/sui/graphql";
import { bcs } from "@mysten/sui/bcs";

// docs/multichain/generation-milestone/publication-bytecode.json
var publication_bytecode_default = { modules: ["oRzrCwcAAAUJAQAGAgYEAwofBCkCBSs+B2lLCLQBYAaUAg4MogLrAwADAQgCAgIABwAABQABAAAEAgAAAAkDBAABAQkHAQACBgEEAAIHCAEAAwYGAggACAADCAAIAAEKAgEGCgICBgoCAwEIAAMBAgoCAQIAAQYIAAIHCgkACgkABQEBAwMCBgIHCgIDAwMKAgdCeXRlczMyBmFwcGVuZAdieXRlczMyBWNvZGVjBmRlY29kZQZlbmNvZGUKZnJvbV9ieXRlcwh0b19ieXRlcwZ2ZWN0b3IEd29yZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAJFujb3ocxkOisDdFDf8eQ5nhgGnGVF+1/KrzfTnX3AMIZAAAAAAAAAAKAgEAAAEAAAVCCgAxASYEEAoAMQQlBA0KAwYAAAAAAAAAACQMBgUSCQwGBRIJDAYLBgQVBRcHACcxAwsAQAYCAAAAAAAAAAwIDQgOAREFOAANCA4CEQU4ADEIDAcKBzEAJAQ4CwcxARcMBw0ICgMKBzEIGDAG/wAAAAAAAAAcM0QGBSUNCA4EEQU4AA0IDgURBTgACwgCAAEBAAAKXAoAQQYGigAAAAAAAAAhBA0KAAYAAAAAAAAAAEIGFDEDIQwBBQ8JDAELAQQSBRYLAAEHACcKAAYBAAAAAAAAAEIGFAwFCgUxASYEJAoFMQQlDAIFJgkMAgsCBCkFLQsAAQcAJwYAAAAAAAAAAAwDBkIAAAAAAAAADAQKBAZKAAAAAAAAACMERAsDMQgvCgAKBEIGFDQbDAMLBAYBAAAAAAAAABYMBAUxCgMGAAAAAAAAAAAkBEkFTQsAAQcAJwsFCgAGAgAAAAAAAAARAgoABiIAAAAAAAAAEQILAwoABkoAAAAAAAAAEQILAAZqAAAAAAAAABECAgACAAAACyIHAQwHBgAAAAAAAAAADAYKBgYgAAAAAAAAACMEHQoGDAQNBwwDCwQMBQoACgELBRZCBhQMAgsDCwJEBgsGBgEAAAAAAAAAFgwGBQQLAAELBxEEAgAA", "oRzrCwcAAAUNAQAuAi6KAQO4AfUCBK0ESAX1BLQFB6kKmwkIxBOAAgbEFbUCCvkXoAELmRkCDJsZpRQNwC0uDu4tIAB6BCgEKQU5BToFOwVOBVAFUQVSACsHWAEjAVoBdwIsAjwCWQJzAnUCdgMnBn8AGwIAAAAIAAASCAAAHAgBDAAAFgMAAAgDAAAGAwAAAQMAABADAAATAwABAwACAAAAAAEdBwACBAwAAxEHAAQVAAAFBwgABgoAAAcLCAAIDAcACQ0HAAsADAALDggADBcHAA0PBwEAAA4ZBwAPBQwBAAERCQcAERoEABIUAgAUGAIAFQIHABYeAgAASAABAABUAgMAAGcEAQAAewUBAQwAMQYBAQwAQgcBAQwAbggBAQwAZAkKAQwAJQsBAQwAeQwBAQwATg0BAQwAYA4BAQwAXA8QAQwAPREQAABiEhMBDABrFBUBDAAwFhcBDAAvGBkBDABfGhsBDABqGhwBDAAkGhwBDABdDxABDABDGh0BDAAhGh4BDABFGh4BDABoGh8BDABxICEAADMBIgAAXhocAQwFZT0KAAY0RkcACjJKSwAKOEsQAAstUBAACy5VFwALL1YZAAtEQxwAC05FRgALT1QVAAtTJicBAgtiUhMAC21BAQALb0ABAAxJMxAADTUwAQEADT42LgEADT83AQEADUs0HgEADUw0HgEADVcBMAEADXIuMAEADkoyMwAOfQEyAQAQNy4BAQMRRiofAQgRRyoKAQgRUygpABF4NR8AE2EsAQEME3AuAQEIE3UsAQEIFGwkCgAVQAocABVBHxwAFU0/HgAVdD8KABV+ARwAJyU2AzorPC07AzIvMR80Li8fMC8tLzEuLh81ODs5Ly42Li4uNjk1OwMuNTw3PjVCCS4vSCxICy41TDAuLS46LjVNDC4xUzIKAggABwgdAAUIDAUFCgIHCB0BCAICBggCBggBAgYLAwEJAAYIAQMHCAIGCAEHCB0CBwsDAQkACQADBwsDAQkABggBAQUGCwMBCQAGCAEHCA8KAgcIHQEFCAcLAwEJAAYIAQcIFQYIFAYIDwcIEQgeBwgdAgYLAwEJAAYIFQMHCwMBCQAGCBULCgIIEAgLAgcLAwEJAAYKAgIGCwMBCQACAQoCAwYIFQIKAgUGCwMBCQAGCBUCCgIHCB0BCwoCCA0IEgYHCwMBCQAHCBUCCgILGQEIHAcIHQELCgIIDggTAwYLAwEJAAcIFQsKAggOCBMCCA4IEwMGCwMBCQAGCBULCgIIDQgSAggNCBIBBgsDAQkAAQIBCB4BAwEBAQgaAQYIAgELFwEIGgEOBAgBBQgUCAIBBggdAQgAAgYJAAcIHQMIDAgUBQEHCB0BCBsBBgkAAQgUAgkABQEIAQEJAAEIDAELFwEJAAQBCBsLAwEJAAgaAQgYAQgWAQYLFwEJAAEGCBsBBwsXAQkAAgcLFwEJAAkAAQgEAQsDAQkAAgEBAQgFAQgIBAcIDwYIDAoCBwgdAQgVAQYIHgcHCBUGCBQGCA8HCBEOCB4HCB0FBwgVBggUDg0KAgEIBwIGCBUOBAEKAggeCxcBCxkBCBwDBggVBggMCwoCCBAICwEIEAgOCB4DCB4KAgUKAgsXAQsZAQgcAQsZAQgcDwEBAQEBAQEBAQMCCB4IHggeCB4BBgoCBgIIHggeAwgeCB4BCAYBCAkEAQEBCgINDQoCAQEBAQoCBAMNAwMEBAYIFQ4NCgICCgIKAgcGCBUGCAwOCgIKAgEHCB0BCxkBCB8JBwgVBggMDgoCCgILGQEIHAsXAQsZAQgfCxcBBQcIHQMHCBUGCAwLCgIIDggTAwYIFQYIDAsKAggNCBIIQWRtaW5DYXAFQm91bmQHQnl0ZXMzMgRDYWxsB0NhbGxDYXAEQ29pbglDb21wbGV0ZWQKRW5kcG9pbnRWMgZGdW5kZWQCSUQOTHpSZWNlaXZlUGFyYW0QTWVzc2FnaW5nQ2hhbm5lbAxNZXNzYWdpbmdGZWUQTWVzc2FnaW5nUmVjZWlwdARPQXBwBk9wdGlvbgxQYXVzZUNoYW5nZWQKUXVvdGVQYXJhbQhSZWdpc3RyeQhSZWxlYXNlZANTVUkJU2VuZFBhcmFtC1Nsb3RDcmVhdGVkBlN0cmluZwlUeENvbnRleHQIVHlwZU5hbWUDVUlEBVZBVUxUBVZhdWx0BFZvaWQDWlJPCGFja19zZW50B2FkYXB0ZXIJYWxsb2NhdGVkCWFubm91bmNlZAVhc2NpaQdiYWNraW5nBGJpbmQFYm91bmQHYnl0ZXMzMgRjYWxsCGNhbGxfY2FwA2NhcAVjb2RlYwRjb2luD2NvbWJpbmVfb3B0aW9ucw9jb25maXJtX2x6X3NlbmQNY29uZmlybV9xdW90ZQxjb25maXJtX3NlbmQLY3JlYXRlX3Nsb3QGZGVjb2RlC2Rlc3RpbmF0aW9uB2Rlc3Ryb3kMZGVzdHJveV9ub25lC2R1bW15X2ZpZWxkBGVtaXQGZW5jb2RlDmVuZHBvaW50X3F1b3RlDWVuZHBvaW50X3NlbmQLZW5kcG9pbnRfdjIFZXZlbnQRZXhlY3V0aW9uX29wdGlvbnMHZXh0cmFjdARmaWxsDGZyb21fYWRkcmVzcwdmcm9tX2lkBGZ1bmQKZ2VuZXJhdGlvbghnZXRfcGVlcgRoZWxkAmlkCmlkX2FkZHJlc3MEaW5pdAppbnRvX2J5dGVzC2ludG9fc3RyaW5nB2lzX25vbmUHaXNfc29tZQdpc196ZXJvCmx6X3JlY2VpdmUHbHpfc2VuZBFtZXNzYWdpbmdfY2hhbm5lbA1tZXNzYWdpbmdfZmVlEW1lc3NhZ2luZ19yZWNlaXB0A25ldwxuZXdfcmVnaXN0cnkDbmZ0CG5mdF90eXBlBG5vbmUEb2FwcAZvYmplY3QGb3B0aW9uBnBhdXNlZAdwYXlsb2FkEnBheWxvYWRfZm9yX3JldmlldwRwZWVyBXBoYXNlB3Byb2Nlc3MPcHVibGljX3RyYW5zZmVyBXF1b3RlCXJlY2lwaWVudAhyZWdpc3Rlcg1yZWdpc3Rlcl9vYXBwCHJlZ2lzdHJ5DnJlZ2lzdHJ5X2FkbWluC3JlZ2lzdHJ5X2lkB3JlcXVlc3QFcm91dGUEc2VuZAZzZW5kZXIUc2V0X2VuZm9yY2VkX29wdGlvbnMKc2V0X3BhdXNlZAhzZXRfcGVlcgxzaGFyZV9vYmplY3QEc2xvdARzb21lA3N1aQp0b19hZGRyZXNzCHRyYW5zZmVyCnR4X2NvbnRleHQJdHlwZV9uYW1lDHVpZF90b19pbm5lcgh2YWxpZGF0ZQV2YXVsdAt2YXVsdF9hZG1pbgd2ZXJzaW9uEXdpdGhfb3JpZ2luYWxfaWRzDHplcm9fYnl0ZXMzMgN6cm8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAJFujb3ocxkOisDdFDf8eQ5nhgGnGVF+1/KrzfTnX3Cjeno4IemNHABkH+2mP34qwRns0Iim3SxkmQGeuvErpMb6u+Imwi5w7N9GSgPwfi3W65bLeJBD8MSD0A+mjbaw94VBM8/11didZ41PZ2VOJYY5VfQVSaX8ZtS5Oknwd7v3CivwBEMsu25Tj5X8rHOabWpnFA7BtFeUc+iEt5W4kAwgBAAAAAAAAAA4ElnUAAAUgBG2iqeFb2CK6BJHZeJR8wb+x/TDm+BOl+xC5srHWproFIEhZU+Lq30qgKvlQz46RT70rZ1Izhec8NhGDQUWdjUXECgJSUWY2YzZkNDM5ZWEwZGEyZjNlOWJhNzllNDk5MmE3YTRjMTEzMjE1ZmJmNTRjNDQyYWM5MDIwYzMxNWY5NTM3MDU6OmNvbGxlY3Rpb246Ok5GVAMIAgAAAAAAAAADCAMAAAAAAAAAAwgEAAAAAAAAAAMIBQAAAAAAAAADCAYAAAAAAAAAAwgHAAAAAAAAAAMICAAAAAAAAAADCAkAAAAAAAAAAwgKAAAAAAAAAAMICwAAAAAAAAADCAwAAAAAAAAACgIXFgADAQARAQAAAAAAAAAAAAAAAAADDUAKAgEAAAIBNgEBAgJGCBtmCBoCAgdGCBt8AyoLFwEIDFgFcQsXAQgaJAVWCgIDAhFGCBt8A2YIGioIDFgFVQsXAQkAJAgeaggeXggeJgFbAV8CQwMiAR8BaQgeYwgeBAIDZggaeggaVQgeBQIFeggaVQgeQwMzDiAIHgYCA3oIGkMDaQgeBwICeggaXggeCAICeggaWwEJAgR6CBpDA2kIHmMIHgMuAAAAACMpCgEuET0HAyEEBwULCwEBBwAnDgAKATgADAMMBAsDBwIHBAoBEQEMBQoBETgOBTgBEgEMAgsECgEuET04AgsCCwEuET04AwsFOAQCAAEAAAABCwsEETgHAAsAOAULATgGCwILAxICAgACAAAAARgKABAAFAcAIQQHBQ0LAAELAQEHDicLARABFAsAOAEhBBUFFwcAJwIAAwAAAAEZCgA3ABQHACEEBwUNCwABCwEBBw4nCwEQARQLADcBFCEEFgUYBwAnAgAEAQAAMVoKAC4LARECOAcRMxErCgAQBBQhBA0FEwsAAQsCAQcFJwoAEAU4CAQcCgAQBjgJDAMFHgkMAwsDBCEFJwsAAQsCAQcGJwsCETgMBA4EETkMBgsEBwAKAC44AQoADwY4CgoAEAcUOAsKABAIFBE+CgYRPxFCCQkxAAYAAAAAAAAAAAkJEUIRQjkADAUKAA8FCgY4DAsALjgBCwYOBTcCFBIEOA0LBTgOAgAFAQAAOngKADcAFAcAIQQHBQsLAAEHDicKADcDFCAEEQUVCwABBw0nCgA3BBQxACEEHggMAwUkCgA3BBQxAyEMAwsDBDIKADcFOA8ELwoANwYUDAIFNAkMAgU0CQwCCwIENwU7CwABBwgnDgE4EBE/CgA3AhQhBEQFSAsAAQcHJwoANwcUBgEAAAAAAAAAFgoANgcVCgA2BQsBOBExAQoANgQVCQoANggVCQoANgkVEUIKADYKFRFCCgA2CxUKAC44EgoANwIUCgA3BxQHAQsANwwUEgU4EwIABgEAAAEPCgAuCwE4FAoCCgA2AxULAC44EgsCEgg4FQIABwEAAAEKCgALATgUCwILADcNCwMLBBEdAgAIAQAAOmYKAC4LATgUCgA3BhQgBBAKADcEFDEAIQwIBRIJDAgLCAQVBSMLAAELAwELAgELBAELBwELBQEHCCcKAi44FgoANw4UIQQwDgYRQCAMCQUyCQwJCwkENQVDCwABCwMBCwIBCwQBCwcBCwUBBwknCgIKAwsECwUHAQoGCwcRKgoCCgMHAUgBAAcQESkLAgsDBwFIAwAHEBEpCgYKADYMFQgKADYGFQsALjgSCwYSBzgXAgAJAAAAHjQKADcAFAcAIQQHBQ0LAAELAQEHDicKATgWCgA3DhQhBBUFGwsAAQsBAQcJJwoANwYUBCgLAQcBESQLADcMFCEMAgUuCwABCwEBCQwCCwIEMQUzBwonAgAKAQAARDAKAC4KATgYCwEKADcNCwIRJREeDAYBAQwEAQEMBQcBIQQhCwUKADcMFCEEHg4GOBkMAwUjCQwDBSMJDAMLAwQmBSoLAAEHCicLBjgaCwAOBDgbAgALAAAASfQBCwERHwwODA8MCwwNDBAMDAoMMQIhBA8IDAMFEwoMMQQhDAMLAwQuCxAKADcPFCEEKwsNCgA3AhQhBCgKCwoANwcUIQwCBTAJDAIFMAkMAgUwCQwCCwIEMwU3CwABBwsnCgA3CBQEPAVACwABBwgnDg8RQCAESQ4OEUAgDAQFSwkMBAsEBE4FUgsAAQcLJwsMMQQhBJ4BCgA3BBQxAiEEXwgMBgVlCgA3BBQxAyEMBgsGBHMKADcJFARwCgA3BTgPDAUFdQkMBQV1CQwFCwUEeAV8CwABBwgnCg8KADcKFCEEiQELDgoANwsUIQwHBYsBCQwHCwcEjgEFkgELAAEHDCcxAwoANgQVCwAuOBILCwsPEgY4HAIKADcEFDECIQSnAQgMCAWtAQoANwQUMQMhDAgLCATFAQoPCgA3ChQhBLwBCg4KADcLFCEMCQW+AQkMCQsJBMEBBesBCwABBwwnCgA3BBQxASEE0AEKADcFOB0MCgXSAQkMCgsKBNUBBdkBCwABBwgnMQIKADYEFQoPCgA2ChUKDgoANgsVCgA2BTgeDg4RQTgfCwAuOBILCwsPCw4SCTggAgAMAAAATmsKATEBIQQxCgA3AxQgBAoFDgsAAQcNJwoANwQUMQEhBBkKADcFOB0MAgUbCQwCCwIEHgUiCwABBwgnMQEKADcPFAoANwIUCwA3BxQRQhFCESAMBQVpCwExAyEETgoANwQUMQIhBD4IDAQFRAoANwQUMQMhDAQLBARLCgA3BTgPDAMFUAkMAwVQCQwDCwMEUwVXCwABBwgnMQMKADcPFAoANwIUCgA3BxQKADcKFAsANwsUESAMBQsFAgANAAAAT9wBCwExASEEB0gBAAwDBQlIAwAMAwsDDAwKAAcBCgwHEREhDAQOBEEbBgIAAAAAAAAAJAQXBRsLAAEHDycLAAcBCwwLAhEhDAkOCUEbBhYAAAAAAAAAJgQ4DgkGAAAAAAAAAABCGxQxACEENQ4JBgEAAAAAAAAAQhsUMQMhDAUFOgkMBQU6CQwFCwUEPQU/Bw8nBgIAAAAAAAAADA0yAAAAAAAAAAAAAAAAAAAAAAwPCg0OCUEbIwTTAQoNBgQAAAAAAAAAFg4JQRslBFAFUgcPJw4JCg0GAQAAAAAAAAAWQhsUNAYAAQAAAAAAABgOCQoNBgIAAAAAAAAAFkIbFDQWDA4OCQoNQhsUMQEhBHYFbA4JCg0GAwAAAAAAAAAWQhsUMQEhDAYFeAkMBgsGBHsFfQcPJwoOBhEAAAAAAAAAIQSEAQgMCAWIAQoOBiEAAAAAAAAAIQwICwgElAEKDQYDAAAAAAAAABYKDhYOCUEbJQwHBZYBCQwHCwcEmQEFmwEHDycyAAAAAAAAAAAAAAAAAAAAAAwKBgAAAAAAAAAADAsKCwYQAAAAAAAAACMEyAELCjEILw4JCg0GBAAAAAAAAAAWCgsWQhsUNRsMCgoOBiEAAAAAAAAAIQTDAQ4JCg0GFAAAAAAAAAAWCgsWQhsUMQAhBMEBBcMBBw8nCwsGAQAAAAAAAAAWDAsFnwELDwsKFgwPCw0GAwAAAAAAAAAWCw4WDA0FQwsPMkANAwAAAAAAAAAAAAAAAAAmBNgBBdoBBw8nCwkCAA4BAABRFgoACgE4GAoACgI4IQwFCgELAgsDEQ0MBgsBCwA3DQcBCwULBgkLBBEoAgAPAQAAUSwKAC4KAS44GAoALgoCOCEMBgoBLgoCCwMRDQwHCwIxASEEGQgKADYIFQUdCAoANgkVCwELADcNBwELBgsHCwQ4IgoFLhE9OCMLBREmAgAQAQAAAQoKAAoBLjgYCwELADcNCwIRIgIAEQEAAAEJCgAKATgYCwELADcNCwIRIwIAEgEAAAEECwA3BBQCABMBAAABBAsANw8UAgAUAQAAAQQLADcCFAIAFQEAAAEECwALATghAgAWAQAAAQQLADcHFAIAFwEAAB4TCgA3BBQxASEECwsAAQgMAQURCwA3BBQxAiEMAQsBAgAYAQAAAQQLADcFOB0CABkBAAABBAsANwEUAgAaAQAAAQQLABAFFAIAGwEAAAECBwECABwBAAABBAsANwwUAgACAQEBAwEDAgIGAgQCAgIDAgUDBgMKAwsDBQMJAwwDDQMOAw8DEAMIAwMDBAMHAi4DLgkuCi4LLgwuDS4OLg8uEC4RLhIuEy4ULhUuFi4A"], dependencies: ["0x0000000000000000000000000000000000000000000000000000000000000001", "0x0000000000000000000000000000000000000000000000000000000000000002", "0x28de9e8e087a6347001907fb698fdf8ab0467b342229b74b19264067aebc4ae9", "0x31beaef889b08b9c3b37d19280fc1f8b75bae5b2de2410fc3120f403e9a36dac", "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24", "0x00245ba36f7a1cc643a2b037450dff1e4399e18069c6545fb5fcaaf37d39d7dc", "0x3de1504cf3fd75762759e353d9d95389618e557d0552697f19b52e4e927c1dee"], digest: [189, 19, 105, 36, 114, 65, 94, 95, 188, 46, 70, 250, 68, 72, 20, 4, 79, 129, 126, 120, 249, 13, 203, 109, 11, 186, 205, 87, 164, 221, 203, 28] };

// docs/multichain/generation-milestone/validation.json
var validation_default = {
  baseline: "462ff86a7b120f3c89bc9a24eccc46fbac8a491f",
  baselineTrackedFilesPreserved: 1785,
  moveReleaseModuleCount: 2,
  moveReleaseBuildSha256: "75255e5a7721f244580d206fe98a528968a07795d52eba1635cacf5b15b6d473",
  moveTests: 52,
  evmTests: 16,
  compiler: "sui 1.83.1-6a567faf6de1",
  solc: "0.8.30",
  deployment: false,
  gameplayEnabled: false
};

// contracts/nftree-generation/scripts/readiness.mjs
var C = Object.freeze({
  sender: "0x485953e2eadf4aa02af950cf8e914fbd2b67523385e73c36118341459d8d45c4",
  nft: "0x046da2a9e15bd822ba0491d978947cc1bfb1fd30e6f813a5fb10b9b2b1d6a6ba",
  nftType: "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT",
  oappPackage: "0xfdc28afc0110cb2edb94e3e57f2b1ce69b5a99c503b06d15e51cfa212de56e24",
  graphql: "https://graphql.mainnet.sui.io/graphql",
  chain: "4btiuiMPvEENsttpZC7CZ53DruC3MAgfznDbASZ7DR6S",
  maxGasMist: 200000000n
});
var check = (condition, message) => assert(condition, message);
var equal = (a, b, message) => assert.deepEqual(a, b, message);
function verifyBuild() {
  const bytes = JSON.stringify(publication_bytecode_default) + "\n";
  assert.equal(createHash("sha256").update(bytes).digest("hex"), validation_default.moveReleaseBuildSha256);
  assert.equal(publication_bytecode_default.modules.length, 2);
}
function publication() {
  verifyBuild();
  const tx = new Transaction();
  tx.setSender(C.sender);
  const [cap] = tx.publish({ modules: publication_bytecode_default.modules, dependencies: publication_bytecode_default.dependencies });
  tx.transferObjects([cap], tx.pure.address(C.sender));
  return tx;
}
function readOnlyFetch(fetcher = globalThis.fetch) {
  return async (url, options) => {
    assert.equal(String(url), C.graphql, "Unexpected endpoint");
    assert.equal(options?.method, "POST");
    const body = JSON.parse(options.body);
    assert.equal(typeof body.query, "string");
    assert(!/\b(mutation|executeTransaction)\b/.test(body.query), "Submission is forbidden");
    assert(/^\s*(query\b|\{)/.test(body.query), "Only GraphQL queries allowed");
    return fetcher(url, options);
  };
}
function newClient() {
  return new SuiGraphQLClient({ network: "mainnet", url: C.graphql, fetch: readOnlyFetch() });
}
function verifyCandidate(data, now = Date.now()) {
  assert.equal(data.chainIdentifier, C.chain);
  const n = data.nft;
  assert.equal(n?.address, C.nft);
  assert.equal(n.owner?.__typename, "AddressOwner");
  assert.equal(n.owner.address.address, C.sender);
  assert.equal(n.asMoveObject?.contents?.type?.repr, C.nftType);
  assert.equal(n.asMoveObject.contents.json.number, "2720");
  assert(n.version && n.digest);
  const age = now - Date.parse(data.checkpoint.timestamp);
  assert(Number.isFinite(age) && age >= -3e4 && age <= 12e4, "Stale checkpoint");
}
async function readCandidate(client) {
  const r = await client.query({ query: `query { chainIdentifier checkpoint { sequenceNumber timestamp }
 nft:object(address:"${C.nft}"){address version digest owner{__typename ... on AddressOwner{address{address}}}
 asMoveObject{contents{type{repr} json}}}}`, signal: AbortSignal.timeout(2e4) });
  assert(!r.errors);
  verifyCandidate(r.data);
  return r.data;
}
function verifyPublication(result) {
  check(result?.$kind === "Transaction" && result.Transaction?.status?.success === true, "Publication did not succeed. No NFT deposit is permitted.");
  const t = result.Transaction;
  check(t.transaction?.sender === C.sender, "Wrong publication sender.");
  const commands = t.transaction.commands;
  check(commands?.length === 2 && commands[0].Publish && commands[1].TransferObjects, "Unexpected publication command.");
  equal(commands[0].Publish.modules, publication_bytecode_default.modules, "Wrong published modules.");
  equal(commands[0].Publish.dependencies, publication_bytecode_default.dependencies, "Wrong dependencies.");
  equal(commands[1].TransferObjects.objects.map((x) => x.NestedResult), [[0, 0]], "Upgrade authority transfer changed.");
  const inputs = t.transaction.inputs;
  check(inputs?.length === 1, "Unexpected publication inputs.");
  const target = inputs[commands[1].TransferObjects.address.Input]?.Pure?.bytes;
  check(target === btoa(String.fromCharCode(...Uint8Array.from(C.sender.slice(2).match(/../g), (x) => parseInt(x, 16)))), "Upgrade authority recipient changed.");
  check(t.transaction.gasData?.owner === C.sender, "Gas must be paid by the dev wallet.");
  const gasIds = /* @__PURE__ */ new Set([t.effects?.gasObject?.objectId, ...(t.transaction.gasData.payment ?? []).map((x) => x.objectId)]);
  const changes = t.effects?.changedObjects;
  check(Array.isArray(changes) && !changes.some((x) => x.objectId === C.nft), "Original NFT was unexpectedly touched.");
  const created = [];
  for (const x of changes) {
    if (x.inputState === "Exists") {
      check(gasIds.has(x.objectId) && x.inputOwner?.AddressOwner === C.sender, "Unexpected existing object mutation.");
    } else if (["ObjectWrite", "PackageWrite"].includes(x.outputState)) {
      created.push(x);
    } else {
      const transient = x.inputState === "DoesNotExist" && x.outputState === "DoesNotExist" && x.idOperation === "Created";
      const addressGas = x.inputState === "DoesNotExist" && x.outputState === "AccumulatorWriteV1" && x.idOperation === "None" && x.outputOwner === null;
      check(transient || addressGas, "Unexpected object effect.");
    }
  }
  check(created.length === 6, "Unexpected number of created objects.");
  const typed = created.map((x) => ({ id: x.objectId, type: t.objectTypes?.[x.objectId], owner: x.outputOwner }));
  const packages = typed.filter((x) => x.type === "package");
  check(packages.length === 1, "Missing new package.");
  const packageId = packages[0].id;
  const expected = [packageId + "::vault::Registry", packageId + "::vault::AdminCap", C.oappPackage + "::oapp::OApp", C.oappPackage + "::oapp::AdminCap", "0x0000000000000000000000000000000000000000000000000000000000000002::package::UpgradeCap"];
  for (const type of expected) {
    const found = typed.filter((x) => x.type === type);
    check(found.length === 1, "Created object type differs: " + type);
    if (type.endsWith("Cap")) check(found[0].owner?.AddressOwner === C.sender, "A capability left the dev wallet.");
    else check(found[0].owner?.Shared || found[0].owner?.$kind === "Shared", "Expected a shared empty registry/OApp.");
  }
  check((t.events ?? []).length === 0, "Unexpected publication events.");
  const g = t.effects.gasUsed;
  check(g, "Missing gas summary.");
  const gas = BigInt(g.computationCost) + BigInt(g.storageCost) - BigInt(g.storageRebate);
  check(gas > 0n && gas <= C.maxGasMist, "Estimated gas exceeds the reviewed 0.2-SUI limit.");
  check(t.balanceChanges?.length === 1 && t.balanceChanges[0].address === C.sender && /^0x0*2::sui::SUI$/.test(t.balanceChanges[0].coinType) && BigInt(t.balanceChanges[0].amount) === -gas, "Unexpected asset payment.");
  return { gasMist: String(gas), packageId, registryId: typed.find((x) => x.type === expected[0]).id, oappId: typed.find((x) => x.type === expected[2]).id, objects: typed };
}

// contracts/nftree-generation/scripts/publication-packet.mjs
import { Transaction as Transaction2 } from "@mysten/sui/transactions";
var GAS_BUDGET = 100000000n;
var MAX_AGE = 12e4;
function publicationTransaction() {
  const tx = publication();
  tx.setGasOwner(C.sender);
  tx.setGasBudget(GAS_BUDGET);
  return tx;
}

// contracts/nftree-generation/scripts/wallet-handoff.mjs
var hash = (b) => createHash2("sha256").update(b).digest("hex");
async function verifyResolvedBytes(bytes) {
  const tx = Transaction3.from(bytes), data = tx.getData();
  const expected = publicationTransaction();
  assert2.deepEqual(await tx.build({ onlyTransactionKind: true }), await expected.build({ onlyTransactionKind: true }), "Changed publication commands");
  assert2.equal(data.sender, C.sender);
  assert2.equal(data.gasData.owner, C.sender);
  assert2.equal(data.gasData.budget, String(GAS_BUDGET));
  assert2(BigInt(data.gasData.price) > 0n, "Missing gas price");
  assert2.deepEqual(data.gasData.payment, [], "Unexpected gas coin inputs");
  const validity = data.expiration?.ValidDuring;
  assert2(validity, "Address-balance gas requires bounded validity");
  assert2.equal(validity.chain, C.chain);
  assert2.equal(BigInt(validity.maxEpoch) - BigInt(validity.minEpoch), 1n);
  assert2.equal(validity.minTimestamp, null);
  assert2.equal(validity.maxTimestamp, null);
  assert2(Number.isInteger(validity.nonce) && validity.nonce >= 0);
  return tx;
}
async function verifyHandoff(packet, { address, chain, now = Date.now() } = {}) {
  assert2.equal(address?.toLowerCase(), C.sender);
  assert2.equal(chain, "sui:mainnet");
  assert2.equal(packet.schema, "tree-empty-publication-wallet-handoff-v1");
  assert2.equal(packet.upgradePolicy, "retain-new-capabilities-in-dev-wallet-for-private-pilot");
  assert2.equal(packet.authorized, false);
  assert2.equal(packet.submitted, false);
  assert2(now >= packet.preparedAt && now - packet.preparedAt <= MAX_AGE, "Refresh expired handoff");
  const bytes = Uint8Array.from(Buffer.from(packet.transactionBase64, "base64"));
  assert2.equal(hash(bytes), packet.transactionSha256);
  const tx = await verifyResolvedBytes(bytes);
  verifyCandidate(packet.candidateObservation, now);
  const proof = verifyPublication(packet.simulation);
  const epoch = BigInt(packet.simulation.Transaction.epoch);
  const validity = tx.getData().expiration.ValidDuring;
  assert2(epoch >= BigInt(validity.minEpoch) && epoch <= BigInt(validity.maxEpoch), "Simulation outside validity epochs");
  assert2.equal(proof.gasMist, packet.estimatedNetGasMist);
  assert2(BigInt(proof.gasMist) < GAS_BUDGET);
  assert2.deepEqual(Uint8Array.from(Object.values(packet.simulation.Transaction.bcs)), bytes, "Simulation bytes differ");
  return tx;
}
async function prepareHandoff(client = newClient()) {
  const before = await readCandidate(client);
  const tx = publicationTransaction();
  tx.setGasPayment([]);
  const bytes = await tx.build({ client });
  await verifyResolvedBytes(bytes);
  const simulation = await client.core.simulateTransaction({
    transaction: bytes,
    doGasSelection: false,
    checksEnabled: true,
    include: { effects: true, events: true, transaction: true, balanceChanges: true, objectTypes: true, bcs: true },
    signal: AbortSignal.timeout(45e3)
  });
  const proof = verifyPublication(simulation);
  const after = await readCandidate(client);
  assert2.deepEqual(before.nft, after.nft, "Candidate changed");
  const packet = {
    schema: "tree-empty-publication-wallet-handoff-v1",
    preparedAt: Date.now(),
    upgradePolicy: "retain-new-capabilities-in-dev-wallet-for-private-pilot",
    authorized: false,
    submitted: false,
    transactionBase64: Buffer.from(bytes).toString("base64"),
    transactionSha256: hash(bytes),
    estimatedNetGasMist: proof.gasMist,
    candidateObservation: after,
    simulation,
    warning: "Unsigned mainnet publication only. On-chain validity is bounded to the resolved two-epoch window; the stricter two-minute review gate is enforced by this verifier. Regenerate immediately before any separately approved wallet signature."
  };
  await verifyHandoff(packet, { address: C.sender, chain: "sui:mainnet" });
  return packet;
}

// netlify/preview-functions/generation-publication.mjs
var config = { path: "/api/generation-publication" };
async function handler(request) {
  const url = new URL(request.url);
  if (request.method !== "GET") return new Response("Read-only endpoint", { status: 405 });
  const headers = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };
  try {
    const digest = url.searchParams.get("digest");
    if (digest) {
      if (!/^[1-9A-HJ-NP-Za-km-z]{43,44}$/.test(digest)) throw Error("Invalid digest");
      const result = await newClient().core.getTransaction({ digest, include: { effects: true, events: true, transaction: true, balanceChanges: true, objectTypes: true, bcs: true } });
      return Response.json({ digest, ...verifyPublication(result) }, { headers });
    }
    if (url.search) throw Error("Unexpected parameters");
    return Response.json(await prepareHandoff(), { headers });
  } catch (error) {
    return Response.json({ error: String(error.message) }, { status: 502, headers });
  }
}
export {
  config,
  handler as default
};
