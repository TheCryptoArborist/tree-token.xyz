
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// ../../../../../tmp/arcade-monthly-ZzfwXy/netlify/monthly-functions/arcade-monthly.ts
import { createHash } from "node:crypto";
import { SuiGrpcClient } from "@mysten/sui/grpc";

// ../../../../../tmp/arcade-monthly-ZzfwXy/netlify/lib/arcade-monthly-core.ts
import { bcs } from "@mysten/sui/bcs";
var TREE_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var RECIPIENT = "0x6f1020c2fd6c91129f7cb5e0d651295e87f7245f96b7d090715c89b38197e77f";
var PRICE = "20000";
var DECIMALS = 6;
var AMOUNT = 20000000000n;
var ORIGINS = ["https://tree-token.xyz", "https://www.tree-token.xyz"];
var recoveryConfig = { coinType: TREE_TYPE, recipient: RECIPIENT, price: PRICE, decimals: DECIMALS, amountBaseUnits: AMOUNT.toString(), scope: "current-month", cutoffPolicy: "utc-month-end-v1", cutoffEffectiveMonth: "2026-11", lateVerification: true };
var memoFor = (intent) => `TREE:CHECKIN-RECOVERY:v1:${intent.id}:${intent.dateKey}`;
var MonthlyError = class extends Error {
  code;
  status;
  constructor(code, message, status = 400) {
    super(message);
    this.code = code;
    this.status = status;
  }
};
var fail = () => {
  throw new MonthlyError("payment-not-verified", "This payment could not be verified. Keep your transaction digest and retry verification.");
};
var norm = (a) => typeof a === "string" && /^0x[0-9a-f]{1,64}$/i.test(a) ? "0x" + a.slice(2).toLowerCase().padStart(64, "0") : "";
function recoverySeasonDeadline(intent) {
  const createdAt = Date.parse(intent?.createdAt), expiresAt = Date.parse(intent?.expiresAt);
  const dateKey = intent?.dateKey, date = typeof dateKey === "string" && /^\d{4}-\d{2}-\d{2}$/.test(dateKey) ? /* @__PURE__ */ new Date(dateKey + "T00:00:00.000Z") : null;
  if (!date || !Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== dateKey || !Number.isFinite(createdAt) || !Number.isFinite(expiresAt) || expiresAt <= createdAt || new Date(createdAt).toISOString().slice(0, 7) !== dateKey.slice(0, 7) || dateKey >= new Date(createdAt).toISOString().slice(0, 10)) throw new MonthlyError("invalid-intent", "This recovery checkout could not be verified. Keep your payment digest.");
  if (dateKey < "2026-11-01") return null;
  date.setUTCDate(1);
  date.setUTCMonth(date.getUTCMonth() + 1);
  return date.toISOString();
}
async function readRecoveryTransaction(client, digest, signal = AbortSignal.timeout(15e3)) {
  const result = await client.core.getTransaction({ digest, include: { transaction: true, balanceChanges: true }, signal });
  const t = result?.Transaction;
  if (result?.$kind !== "Transaction" || t?.status?.success !== true || t.digest !== digest) fail();
  const { response } = await client.ledgerService.getTransaction({ digest, readMask: { paths: ["digest", "timestamp", "checkpoint", "effects.status"] } }, { abort: signal });
  const ledger = response?.transaction;
  if (!ledger || ledger.digest !== digest || ledger.effects?.status?.success !== true) fail();
  if (ledger.timestamp == null || ledger.checkpoint == null) throw new MonthlyError("payment-pending", "Payment confirmation is not ready yet. Retry verification without paying again.", 409);
  const integerText = (value) => typeof value === "bigint" || typeof value === "string" ? String(value) : typeof value === "number" && Number.isSafeInteger(value) ? String(value) : "";
  const seconds = integerText(ledger.timestamp.seconds), checkpoint = integerText(ledger.checkpoint), nanos = ledger.timestamp.nanos;
  if (!/^\d+$/.test(seconds) || !/^\d+$/.test(checkpoint) || BigInt(checkpoint) <= 0n || !Number.isInteger(nanos) || nanos < 0 || nanos >= 1e9) fail();
  const timestampMs = Number(seconds) * 1e3 + Math.floor(nanos / 1e6);
  if (!Number.isSafeInteger(timestampMs) || timestampMs <= 0 || timestampMs > 864e13) fail();
  if (t.timestampMs != null && t.timestampMs !== timestampMs) fail();
  if (t.checkpoint != null && String(t.checkpoint) !== checkpoint) fail();
  return { ...result, Transaction: { ...t, timestampMs, checkpoint } };
}
function verifyRecoveryPayment(result, intent, digest, now = Date.now()) {
  const seasonEndsAt = recoverySeasonDeadline(intent);
  const t = result?.Transaction;
  if (result?.$kind !== "Transaction" || !t?.status?.success || t.digest !== digest || !Number.isSafeInteger(t.timestampMs) || !t.checkpoint || norm(t.transaction?.sender) !== intent.wallet) fail();
  if (seasonEndsAt && t.timestampMs >= Date.parse(seasonEndsAt)) throw new MonthlyError("payment-after-season-end", "This payment was confirmed after the UTC month closed and cannot recover that month\u2019s check-in. Keep the transaction digest; do not pay again for this checkout.");
  if (t.timestampMs < Date.parse(intent.createdAt) - 5e3 || t.timestampMs > Date.parse(intent.expiresAt) || t.timestampMs > now + 5e3) fail();
  let received = 0n, spent = 0n;
  try {
    for (const x of t.balanceChanges || []) {
      if (x.coinType === TREE_TYPE) {
        if (norm(x.address) === RECIPIENT) received += BigInt(x.amount);
        if (norm(x.address) === intent.wallet) spent += BigInt(x.amount);
      }
    }
  } catch {
    fail();
  }
  if (received !== AMOUNT || spent !== -AMOUNT || intent.wallet === RECIPIENT) fail();
  const inputs = t.transaction?.inputs || [], commands = t.transaction?.commands || [];
  const memo = commands.some((c) => {
    const m = c.MoveCall;
    if (!m || norm(m.package) !== norm("0x1") || m.module !== "string" || m.function !== "utf8" || m.typeArguments?.length || m.arguments?.length !== 1) return false;
    const i = m.arguments[0]?.Input;
    if (!Number.isInteger(i) || i < 0) return false;
    const bytes = inputs[i]?.Pure?.bytes;
    if (typeof bytes !== "string") return false;
    try {
      return new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(bcs.vector(bcs.u8()).fromBase64(bytes))) === memoFor(intent);
    } catch {
      return false;
    }
  });
  if (!memo) fail();
  return new Date(t.timestampMs).toISOString();
}

// ../../../../../tmp/arcade-monthly-ZzfwXy/netlify/monthly-functions/arcade-monthly.ts
var hash = (s) => createHash("sha256").update(s).digest("hex");
var json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store", "Netlify-CDN-Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
var environment = (key) => globalThis.Netlify?.env.get(key) ?? process.env[key];
var uuid = (s) => typeof s === "string" && /^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(s);
function database() {
  let url, secret;
  for (const prefix of ["ARCADE_GROWTH", "TREE_RAFFLE", "TREE_KNOWLEDGE_TRIAL"]) {
    url = environment(prefix + "_SUPABASE_URL");
    secret = environment(prefix + "_SUPABASE_SECRET_KEY");
    if (url || secret) break;
  }
  if (!url || !secret || !/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/.test(url)) throw new MonthlyError("service-unavailable", "Monthly progress is temporarily unavailable.", 503);
  return async (name, args) => {
    let r;
    try {
      r = await fetch(url.replace(/\/$/, "") + "/rest/v1/rpc/" + name, { method: "POST", headers: { apikey: secret, Authorization: "Bearer " + secret, "Content-Type": "application/json" }, body: JSON.stringify(args), signal: AbortSignal.timeout(12e3) });
    } catch {
      throw new MonthlyError("service-unavailable", "Monthly progress is temporarily unavailable. Retry without paying again.", 503);
    }
    const d = await r.json();
    if (!r.ok) {
      const e = String(d.message || "");
      if (e.includes("arcade-growth-invalid-session")) throw new MonthlyError("invalid-session", "Sign in to the Arcade again.", 401);
      if (e.includes("already-checked-in")) throw new MonthlyError("already-checked-in", "That date is already checked in.", 409);
      if (e.includes("invalid-date")) throw new MonthlyError("invalid-date", "Choose a missed date from the current UTC month.");
      if (e.includes("payment-used") || d.code === "23505") throw new MonthlyError("payment-used", "That payment or date has already been used.", 409);
      if (e.includes("payment-season-closed")) throw new MonthlyError("payment-after-season-end", "This payment was confirmed after the UTC month closed and cannot recover that month\u2019s check-in. Keep the transaction digest; do not pay again for this checkout.");
      if (e.includes("invalid-intent") || e.includes("payment-time")) throw new MonthlyError("invalid-intent", "This recovery checkout is invalid or the payment was outside its time window.");
      throw new MonthlyError("service-unavailable", "Monthly progress is temporarily unavailable. Keep your payment digest and retry.", 503);
    }
    return d;
  };
}
async function readBody(request, keys) {
  if (!request.headers.get("content-type")?.startsWith("application/json")) throw new MonthlyError("invalid-request", "Send JSON.");
  const reader = request.body?.getReader();
  let data = "", size = 0;
  const decoder = new TextDecoder();
  if (reader) for (; ; ) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > 4096) {
      await reader.cancel();
      throw new MonthlyError("invalid-request", "Request is too large.", 413);
    }
    data += decoder.decode(value, { stream: true });
  }
  let b;
  try {
    b = JSON.parse(data);
  } catch {
    throw new MonthlyError("invalid-request", "Invalid request.");
  }
  if (!b || typeof b !== "object" || Array.isArray(b) || Object.keys(b).some((k) => !keys.includes(k))) throw new MonthlyError("invalid-request", "Unsupported request fields.");
  return b;
}
function createMonthlyHandler(deps = {}) {
  return async (request) => {
    try {
      const action = new URL(request.url).searchParams.get("action") || "status";
      if (!["status", "intent", "verify"].includes(action)) throw new MonthlyError("invalid-request", "Unknown action.", 404);
      if (request.method !== (action === "status" ? "GET" : "POST")) throw new MonthlyError("method-not-allowed", "Method not allowed.", 405);
      const config2 = { recovery: recoveryConfig, monthlyReward: { requiredQuestDays: 20, rewardDetails: "To be announced", eligibleEvidence: "completed-result", eligibleGames: ["garden-bot", "pvp", "arborist-trials"] } };
      const authorization = /^Bearer ([a-f0-9]{64})$/.exec(request.headers.get("authorization") || "");
      if (action === "status" && !request.headers.has("authorization")) return json({ status: "ok", authenticated: false, configuration: config2 });
      if (!authorization) throw new MonthlyError("invalid-session", "Sign in to the Arcade first.", 401);
      const origin = request.headers.get("origin") || new URL(request.url).origin;
      if (!ORIGINS.includes(origin) || request.headers.get("sec-fetch-site") === "cross-site") throw new MonthlyError("origin-not-allowed", "Use the official TREE Arcade.", 403);
      const rpc = deps.rpc || database(), base = { p_token_sha256: hash(authorization[1]), p_origin: origin };
      const session = await rpc("arcade_growth_read_session_v1", base);
      const now = deps.now?.() ?? Date.now();
      if (session.revoked || session.origin !== origin || !Number.isFinite(Date.parse(session.expiresAt)) || Date.parse(session.expiresAt) <= now || !/^0x[0-9a-f]{64}$/.test(session.wallet)) throw new MonthlyError("invalid-session", "Sign in to the Arcade again.", 401);
      if (action === "status") return json({ status: "ok", authenticated: true, configuration: config2, progress: await rpc("arcade_monthly_status_v1", base) });
      const client = () => new SuiGrpcClient({ network: "mainnet", baseUrl: "https://fullnode.mainnet.sui.io:443" });
      if (action === "intent") {
        const b2 = await readBody(request, ["dateKey"]);
        if (typeof b2.dateKey !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(b2.dateKey)) throw new MonthlyError("invalid-date", "Select a missed date.");
        let own;
        if (deps.ownership) own = await deps.ownership(session.wallet);
        else {
          const r = await fetch("https://tree-token.xyz/api/nftree-wallet?address=" + session.wallet, { signal: AbortSignal.timeout(15e3) });
          if (!r.ok) throw new MonthlyError("ownership-unavailable", "NFTree ownership could not be checked.", 503);
          own = await r.json();
        }
        if (own.address !== session.wallet || own.network !== "sui-mainnet" || !Number.isSafeInteger(own.nftreeCount) || own.nftreeCount < 1) throw new MonthlyError("nftree-required", "Hold an NFTree in this wallet to recover attendance.", 403);
        const metadata = deps.metadata ? await deps.metadata() : await client().core.getCoinMetadata({ coinType: TREE_TYPE, signal: AbortSignal.timeout(12e3) });
        if (metadata.coinMetadata?.decimals !== DECIMALS) throw new MonthlyError("price-unavailable", "TREE precision could not be verified. No payment was requested.", 503);
        const intent2 = await rpc("arcade_recovery_intent_v1", { ...base, p_date_key: b2.dateKey });
        if (intent2.wallet !== session.wallet || intent2.dateKey !== b2.dateKey || !uuid(intent2.id) || Date.parse(intent2.expiresAt) <= now) throw new MonthlyError("invalid-intent", "Checkout could not be verified.");
        const seasonEndsAt = recoverySeasonDeadline(intent2);
        if (seasonEndsAt && Date.parse(intent2.expiresAt) > Date.parse(seasonEndsAt)) throw new MonthlyError("invalid-intent", "Checkout could not be verified. No payment was requested.");
        return json({ status: "ok", intent: { ...intent2, ...recoveryConfig, seasonEndsAt, memo: memoFor(intent2) } });
      }
      const b = await readBody(request, ["intentId", "digest"]);
      if (!uuid(b.intentId) || typeof b.digest !== "string" || !/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(b.digest)) throw new MonthlyError("invalid-request", "A valid checkout and transaction digest are required.");
      const intent = await rpc("arcade_recovery_intent_v1", { ...base, p_date_key: null, p_intent_id: b.intentId });
      if (intent.wallet !== session.wallet || intent.id !== b.intentId) throw new MonthlyError("invalid-intent", "Checkout identity mismatch.");
      const transaction = deps.getTransaction ? await deps.getTransaction(b.digest) : await readRecoveryTransaction(deps.client || client(), b.digest);
      const paidAt = verifyRecoveryPayment(transaction, intent, b.digest, now);
      const progress = await rpc("arcade_recovery_confirm_v1", { ...base, p_intent_id: b.intentId, p_digest: b.digest, p_paid_at: paidAt });
      return json({ status: "ok", authenticated: true, configuration: config2, progress, receipt: { dateKey: intent.dateKey, digest: b.digest, price: "20000" } });
    } catch (error) {
      const e = error instanceof MonthlyError ? error : new MonthlyError("service-unavailable", "Verification is temporarily unavailable. Keep your payment digest and retry without paying again.", 503);
      return json({ status: "error", error: e.code, message: e.message }, e.status);
    }
  };
}
var arcade_monthly_default = createMonthlyHandler();
var config = { path: "/api/arcade-monthly", method: ["GET", "POST"], rateLimit: { action: "rate_limit", aggregateBy: ["domain", "ip"], windowSize: 60, windowLimit: 60 } };
export {
  config,
  createMonthlyHandler,
  arcade_monthly_default as default
};
