
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));
function normalizeSuiAddress(value) {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  return SUI_ADDRESS.test(normalized) ? normalized : null;
}

// netlify/lib/cetus-tree-constants.ts
var CETUS_TREE_POOL_ID = "0x2ebaff75b8745896404085babb9ef3a77ccbb6c7d3f4db31626cefff04f7f355";
var CETUS_CLMM_PACKAGE = "0x1eabed72c53feb3805120a081dc15963c204dc8d091542592abaf7a35689b2fb";
var CETUS_TREE_POOL_URL = `https://app.cetus.zone/clmm?tab=deposit&poolAddress=${CETUS_TREE_POOL_ID}`;

// netlify/lib/suidex-v2-tree-lp-provider.ts
import { ChannelCredentials } from "@grpc/grpc-js";
import { GrpcTransport } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient } from "@mysten/sui/grpc";
var SUIDEX_V2_PACKAGE = "0xbfac5e1c6bf6ef29b12f7723857695fd2f4da9a11a7d88162c15e9124c243a4a";
var SUIDEX_V2_TREE_POOL_ID = "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc";
var SUI_COIN_TYPE = "0x2::sui::SUI";
var SUIDEX_V2_TREE_LP_TYPE = `${SUIDEX_V2_PACKAGE}::pair::LPCoin<${SUI_COIN_TYPE},${TREE_COIN_TYPE}>`;
var SUIDEX_V2_TREE_LP_COIN_TYPE = `0x2::coin::Coin<${SUIDEX_V2_TREE_LP_TYPE}>`;
var SUIDEX_V2_TREE_FARM_POSITION_TYPE = `${SUIDEX_V2_PACKAGE}::farm::StakingPosition<${SUIDEX_V2_TREE_LP_TYPE}>`;

// netlify/lib/suidex-v3-tree-lp-provider.ts
import { ChannelCredentials as ChannelCredentials2 } from "@grpc/grpc-js";
import { GrpcTransport as GrpcTransport2 } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient as SuiGrpcClient2 } from "@mysten/sui/grpc";

// netlify/lib/clmm-q64.ts
var CLMM_Q64 = 1n << 64n;

// netlify/lib/suidex-v3-tree-lp-provider.ts
var SUIDEX_V3_PACKAGE = "0xb5f529c1dcda6580a61bf7ee9fbd524b50be62f11044d137c8202c8cbace9e56";
var SUIDEX_V3_POSITION_TYPE = `${SUIDEX_V3_PACKAGE}::position::Position`;
function normalizeCoinType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  const parts = compact.split("::");
  if (parts.length !== 3 || !/^(0x)?[0-9a-f]+$/.test(parts[0]) || !parts[1] || !parts[2]) return null;
  const address = parts[0].replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${address}::${parts[1]}::${parts[2]}`;
}
var NORMALIZED_TREE = normalizeCoinType(TREE_COIN_TYPE);

// netlify/lib/turbos-tree-lp-provider.ts
import { ChannelCredentials as ChannelCredentials3 } from "@grpc/grpc-js";
import { GrpcTransport as GrpcTransport3 } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient as SuiGrpcClient3 } from "@mysten/sui/grpc";
var TURBOS_PACKAGE = "0x91bfbc386a41afcfd9b2533058d7e915a1d3829089cc268ff4333d54d6339ca1";
var TURBOS_POSITION_NFT_TYPE = `${TURBOS_PACKAGE}::position_nft::TurbosPositionNFT`;
var TURBOS_POSITION_TYPE = `${TURBOS_PACKAGE}::position_manager::Position`;
var TURBOS_POOL_POSITION_VALUE_TYPE = `${TURBOS_PACKAGE}::pool::Position`;
var TURBOS_TREE_POOL_IDS = [
  "0x4a8c450d393fee360fc8c2a2ed30bf6f9e4de5077024e9628cd3510e272bf490",
  "0xaa133ce1f8fd55d85b6fc87c1b3054cb717d83be477ef3635c661c21fbdfa0ee",
  "0xc327fdc9b129602e91df9bd59cf3e4a921ce5509844a3b6c8adddc5ed320636d",
  "0xd5d7d9a614327feed096a437f416aa98f440393d9ac52d97c87e6e0dd6e719bb",
  "0xe1468ece8e4d2940b30dec776eaee9b235b23458868027da871bc42817263a12"
];
function canonicalAddress(value) {
  const address = value.toLowerCase().replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${address}`;
}
function normalizeStructType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  const parts = compact.split("::");
  if (parts.length !== 3 || !/^(0x)?[0-9a-f]+$/.test(parts[0]) || !parts[1] || !parts[2]) return null;
  return `${canonicalAddress(parts[0])}::${parts[1]}::${parts[2]}`;
}
function canonicalizeMoveType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  if (!compact) return null;
  return compact.replace(/(^|[<,])((?:0x)?[0-9a-f]+)(?=::)/g, (_match, prefix, address) => `${prefix}${canonicalAddress(address)}`);
}
var NORMALIZED_TREE2 = normalizeStructType(TREE_COIN_TYPE);
var NORMALIZED_PACKAGE = canonicalAddress(TURBOS_PACKAGE);
var NORMALIZED_POSITION_TYPE = canonicalizeMoveType(TURBOS_POSITION_TYPE);
var NORMALIZED_POOL_POSITION_VALUE_TYPE = canonicalizeMoveType(TURBOS_POOL_POSITION_VALUE_TYPE);

// netlify/lib/tree-v3-overview.ts
var TREE_V3_PACKAGE = "0xb5f529c1dcda6580a61bf7ee9fbd524b50be62f11044d137c8202c8cbace9e56";
var TREE_V3_POOL_ID = "0x39d5ba22e01e45bc4129ec28a0bef52e8fee8db5d07d337adf9540e3cb9074cf";
var TREE_V3_POSITION_TYPE = `${TREE_V3_PACKAGE}::position::Position`;
var SUI_COIN_TYPE2 = "0x2::sui::SUI";
var TREE_DECIMALS2 = 6;
var TREE_V3_REWARD_TOKENS = Object.freeze([
  Object.freeze({ coinType: "0xbfac5e1c6bf6ef29b12f7723857695fd2f4da9a11a7d88162c15e9124c243a4a::victory_token::VICTORY_TOKEN", symbol: "VICTORY", decimals: 6 }),
  Object.freeze({ coinType: TREE_COIN_TYPE, symbol: "TREE", decimals: TREE_DECIMALS2 }),
  Object.freeze({ coinType: "0xaafb102dd0902f5055cadecd687fb5b71ca82ef0e0285d90afde828ec58ca96b::btc::BTC", symbol: "wBTC", decimals: 8 })
]);
function normalizeCoinType2(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  const parts = compact.split("::");
  if (parts.length !== 3 || !/^(0x)?[0-9a-f]+$/.test(parts[0]) || !parts[1] || !parts[2]) return null;
  const address = parts[0].replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${address}::${parts[1]}::${parts[2]}`;
}
var NORMALIZED_TREE3 = normalizeCoinType2(TREE_COIN_TYPE);
var NORMALIZED_SUI = normalizeCoinType2(SUI_COIN_TYPE2);
var U128_MODULUS = 1n << 128n;

// netlify/lib/tree-volume-overview.ts
var TURBOS_EVENT_PACKAGE = "0x91bfbc386a41afcfd9b2533058d7e915a1d3829089cc268ff4333d54d6339ca1";
var TREE_VOLUME_SOURCES = [
  { poolId: SUIDEX_V2_TREE_POOL_ID, venue: "suiDexV2", quote: "sui" },
  { poolId: TREE_V3_POOL_ID, venue: "suiDexV3", quote: "sui" },
  { poolId: CETUS_TREE_POOL_ID, venue: "cetus", quote: "sui" },
  { poolId: TURBOS_TREE_POOL_IDS[0], venue: "turbos", quote: "usdc" },
  { poolId: TURBOS_TREE_POOL_IDS[1], venue: "turbos", quote: "sui" },
  { poolId: TURBOS_TREE_POOL_IDS[2], venue: "turbos", quote: "usdc" },
  { poolId: TURBOS_TREE_POOL_IDS[3], venue: "turbos", quote: "sui" },
  { poolId: TURBOS_TREE_POOL_IDS[4], venue: "turbos", quote: "wbtc" }
];
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
async function collectVolumeEventPages(initialValue, fetchNextPage, maxPages = 20) {
  if (!Number.isSafeInteger(maxPages) || maxPages < 1) throw new Error("Transaction event page bound is invalid.");
  function checkedConnection(value) {
    const connection2 = record(value);
    if (!Array.isArray(connection2.nodes) || typeof record(connection2.pageInfo).hasNextPage !== "boolean") {
      throw new Error("Transaction event coverage was not verified.");
    }
    return connection2;
  }
  let connection = checkedConnection(initialValue);
  const nodes = Array.isArray(connection.nodes) ? [...connection.nodes] : [];
  let pageInfo = record(connection.pageInfo);
  let pages = 1;
  const seenCursors = /* @__PURE__ */ new Set();
  while (pageInfo.hasNextPage === true) {
    if (pages >= maxPages) throw new Error(`Transaction events exceeded the verified ${maxPages}-page bound.`);
    const after = typeof pageInfo.endCursor === "string" ? pageInfo.endCursor : "";
    if (!after || seenCursors.has(after)) throw new Error("Transaction event cursor was missing or repeated.");
    seenCursors.add(after);
    connection = checkedConnection(await fetchNextPage(after));
    if (Array.isArray(connection.nodes)) nodes.push(...connection.nodes);
    pageInfo = record(connection.pageInfo);
    pages += 1;
  }
  return { nodes, pages };
}
function unsigned(value) {
  const text = String(value ?? "").trim();
  return /^\d+$/.test(text) ? BigInt(text) : null;
}
function normalizedEventType(value) {
  return typeof value === "string" ? value.toLowerCase().replace(/0x0+/g, "0x") : "";
}
function amountUsd(raw, quote, prices) {
  const decimals = quote === "sui" ? 9 : quote === "usdc" ? 6 : 8;
  const price = quote === "sui" ? prices.suiUsd : quote === "usdc" ? prices.usdcUsd : prices.wbtcUsd;
  return Number(raw) / 10 ** decimals * price;
}
function parseVolumeTransaction(nodeValue, source, prices, windowStartMs, windowEndMs) {
  const node = record(nodeValue);
  const effects = record(node.effects);
  const timestamp = Date.parse(String(effects.timestamp || ""));
  if (effects.status !== "SUCCESS" || !Number.isFinite(timestamp) || timestamp < windowStartMs || timestamp > windowEndMs) return null;
  const events = record(effects.events);
  if (record(events.pageInfo).hasNextPage === true) throw new Error("Transaction events were not fully paginated.");
  let volumeUsd = 0;
  let swaps = 0;
  for (const eventValue of Array.isArray(events.nodes) ? events.nodes : []) {
    const contents = record(record(eventValue).contents);
    const type = normalizedEventType(record(contents.type).repr);
    const json = record(contents.json);
    let raw = null;
    if (source.venue === "suiDexV2" && type.startsWith(`${SUIDEX_V2_PACKAGE}::pair::swap<`) && type.includes("::sui::sui") && type.includes("::tree::tree")) {
      const input = unsigned(json.amount0_in);
      const output = unsigned(json.amount0_out);
      if (input !== null && output !== null && input > 0n !== output > 0n) raw = input > 0n ? input : output;
    } else if (source.venue === "suiDexV3" && type === `${SUIDEX_V3_PACKAGE}::trade::swapevent` && normalizeSuiAddress(json.pool_id) === source.poolId) {
      raw = unsigned(json.amount_x);
    } else if (source.venue === "turbos" && type === `${TURBOS_EVENT_PACKAGE}::pool::swapevent` && normalizeSuiAddress(json.pool) === source.poolId) {
      raw = unsigned(json.amount_b);
    } else if (source.venue === "cetus" && type === `${CETUS_CLMM_PACKAGE}::pool::swapevent` && normalizeSuiAddress(json.pool) === source.poolId) {
      raw = json.atob === false ? unsigned(json.amount_in) : json.atob === true ? unsigned(json.amount_out) : null;
    }
    if (raw !== null && raw > 0n) {
      volumeUsd += amountUsd(raw, source.quote, prices);
      swaps += 1;
    }
  }
  return swaps ? { timestamp, volumeUsd, swaps } : null;
}

// netlify/functions/tree-volume.ts
var GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var PAGE_SIZE = 50;
var MAX_PAGES_PER_POOL = 20;
var EVENT_PAGE_SIZE = 50;
var MAX_EVENT_PAGES_PER_TRANSACTION = 20;
var EVENT_FIELDS = `nodes { contents { type { repr } json } }`;
var QUERY = `query RecentPoolTransactions($pool: SuiAddress!, $last: Int!, $before: String, $eventFirst: Int!) {
  transactions(last: $last, before: $before, filter: { affectedObject: $pool }) {
    pageInfo { hasPreviousPage startCursor }
    nodes {
      digest
      effects {
        status timestamp
        events(first: $eventFirst) {
          pageInfo { hasNextPage endCursor }
          ${EVENT_FIELDS}
        }
      }
    }
  }
}`;
var EVENT_PAGE_QUERY = `query TransactionEventPage($digest: String!, $first: Int!, $after: String!) {
  transaction(digest: $digest) {
    effects {
      events(first: $first, after: $after) {
        pageInfo { hasNextPage endCursor }
        ${EVENT_FIELDS}
      }
    }
  }
}`;
function record2(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
async function requestGraphql(query, variables, timeoutMs = 8e3) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response2 = await fetch(GRAPHQL_URL, {
      method: "POST",
      signal: controller.signal,
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({ query, variables })
    });
    if (!response2.ok) throw new Error(`Sui GraphQL returned HTTP ${response2.status}.`);
    const payload = record2(await response2.json());
    if (Array.isArray(payload.errors) && payload.errors.length) throw new Error("Sui GraphQL returned transaction errors.");
    return payload;
  } finally {
    clearTimeout(timeout);
  }
}
async function completeTransactionEvents(node, digest) {
  const effects = record2(node.effects);
  const initialEvents = record2(effects.events);
  const collected = await collectVolumeEventPages(initialEvents, async (after) => {
    const payload = await requestGraphql(EVENT_PAGE_QUERY, { digest, first: EVENT_PAGE_SIZE, after });
    const transaction = record2(record2(payload.data).transaction);
    const nextEffects = record2(transaction.effects);
    const events = record2(nextEffects.events);
    if (!Object.keys(transaction).length || !Object.keys(nextEffects).length || !Object.keys(events).length) {
      throw new Error(`Sui GraphQL did not return event page data for transaction ${digest}.`);
    }
    return events;
  }, MAX_EVENT_PAGES_PER_TRANSACTION);
  return {
    node: { ...node, effects: { ...effects, events: { nodes: collected.nodes, pageInfo: { hasNextPage: false } } } },
    eventPages: collected.pages
  };
}
async function requestPool(source, prices, start, end) {
  let before = null;
  let volumeUsd = 0;
  let swaps = 0;
  let transactions = 0;
  let pages = 0;
  let eventPages = 0;
  let complete = false;
  const seen = /* @__PURE__ */ new Set();
  for (let page = 0; page < MAX_PAGES_PER_POOL; page += 1) {
    const payload = await requestGraphql(QUERY, { pool: source.poolId, last: PAGE_SIZE, before, eventFirst: EVENT_PAGE_SIZE });
    const connection = record2(record2(payload.data).transactions);
    if (!Array.isArray(connection.nodes) || typeof record2(connection.pageInfo).hasPreviousPage !== "boolean") {
      throw new Error("Pool transaction coverage was not verified.");
    }
    const nodes = connection.nodes;
    pages += 1;
    let oldest = Number.POSITIVE_INFINITY;
    for (const nodeValue of nodes) {
      const node = record2(nodeValue);
      const digest = typeof node.digest === "string" ? node.digest : "";
      const timestamp = Date.parse(String(record2(node.effects).timestamp || ""));
      if (Number.isFinite(timestamp)) oldest = Math.min(oldest, timestamp);
      if (!digest || seen.has(digest)) continue;
      seen.add(digest);
      const effects = record2(node.effects);
      if (effects.status !== "SUCCESS" || !Number.isFinite(timestamp) || timestamp < start || timestamp > end) continue;
      const completed = await completeTransactionEvents(node, digest);
      eventPages += completed.eventPages;
      const parsed = parseVolumeTransaction(completed.node, source, prices, start, end);
      if (!parsed) continue;
      volumeUsd += parsed.volumeUsd;
      swaps += parsed.swaps;
      transactions += 1;
    }
    const pageInfo = record2(connection.pageInfo);
    if (pageInfo.hasPreviousPage !== true || oldest <= start) {
      complete = true;
      break;
    }
    const cursor = typeof pageInfo.startCursor === "string" ? pageInfo.startCursor : "";
    if (!cursor || cursor === before) throw new Error("Sui transaction cursor was missing or repeated.");
    before = cursor;
  }
  if (!complete) throw new Error(`The 24-hour scan exceeded its verified bound for ${source.poolId}.`);
  return { source, volumeUsd, swaps, transactions, pages, eventPages };
}
async function getPrices() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 6e3);
  try {
    const result = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=sui,bitcoin,usd-coin&vs_currencies=usd", { headers: { Accept: "application/json" }, signal: controller.signal });
    if (!result.ok) throw new Error(`CoinGecko returned HTTP ${result.status}.`);
    const payload = record2(await result.json());
    const prices = { suiUsd: Number(record2(payload.sui).usd), wbtcUsd: Number(record2(payload.bitcoin).usd), usdcUsd: Number(record2(payload["usd-coin"]).usd) };
    if (Object.values(prices).some((value) => !Number.isFinite(value) || value <= 0)) throw new Error("Volume reference prices were incomplete.");
    return prices;
  } finally {
    clearTimeout(timeout);
  }
}
function response(body, status = 200, cache = "public, max-age=30, s-maxage=60, stale-while-revalidate=120") {
  return Response.json(body, { status, headers: { "Cache-Control": cache, "X-Content-Type-Options": "nosniff" } });
}
var tree_volume_default = async (request) => {
  if (request.method !== "GET") return response({ status: "error", error: "method-not-allowed" }, 405, "no-store");
  const windowEndMs = Date.now();
  const windowStartMs = windowEndMs - 24 * 60 * 60 * 1e3;
  try {
    const prices = await getPrices();
    const results = await Promise.all(TREE_VOLUME_SOURCES.map((source) => requestPool(source, prices, windowStartMs, windowEndMs)));
    const venues = { suiDexV2: 0, suiDexV3: 0, turbos: 0, cetus: 0 };
    const pools = {};
    let swaps = 0;
    let transactions = 0;
    let pages = 0;
    let eventPages = 0;
    for (const result of results) {
      venues[result.source.venue] += result.volumeUsd;
      pools[result.source.poolId] = { venue: result.source.venue, volume24hUsd: result.volumeUsd, swaps: result.swaps, transactions: result.transactions };
      swaps += result.swaps;
      transactions += result.transactions;
      pages += result.pages;
      eventPages += result.eventPages;
    }
    const volume24hUsd = venues.suiDexV2 + venues.suiDexV3 + venues.turbos + venues.cetus;
    return response({
      status: "ok",
      generatedAt: new Date(windowEndMs).toISOString(),
      network: "sui-mainnet",
      source: "Verified Sui Mainnet swap events",
      methodology: "recognized-tree-swap-volume-v2",
      windowStart: new Date(windowStartMs).toISOString(),
      windowEnd: new Date(windowEndMs).toISOString(),
      volume24hUsd,
      venues,
      pools,
      prices,
      coverage: { poolsChecked: TREE_VOLUME_SOURCES.length, swaps, transactions, pages, eventPages, complete: true },
      warnings: ["USD volume uses the non-TREE side of each successful recognized swap and current external reference prices."]
    });
  } catch (error) {
    console.error("TREE volume overview failed:", error);
    return response({ status: "error", generatedAt: (/* @__PURE__ */ new Date()).toISOString(), error: "volume-verification-unavailable", message: error instanceof Error ? error.message : String(error) }, 503, "no-store");
  }
};
var config = { path: "/api/tree-volume" };
export {
  config,
  tree_volume_default as default
};
