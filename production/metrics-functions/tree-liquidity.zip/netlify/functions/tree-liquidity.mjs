
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// data/tree-leaderboard-exclusions.json
var tree_leaderboard_exclusions_default = [
  {
    address: "0x0000000000000000000000000000000000000000000000000000000000000000",
    label: "Sui zero address",
    category: "system"
  },
  {
    address: "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc",
    label: "SuiDex V2 TREE/SUI pool",
    category: "shared-protocol-object"
  },
  {
    address: "0x9cdbbd092634efdc0e7033dc1c49d9ea5fc9bc5969ba708f55e05b6fcac12177",
    label: "SuiDex router",
    category: "shared-protocol-object"
  },
  {
    address: "0x81c286135713b4bf2e78c548f5643766b5913dcd27a8e76469f146ab811e922d",
    label: "SuiDex factory",
    category: "shared-protocol-object"
  }
];

// netlify/lib/leaderboard-provider.ts
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_COIN_OBJECT_TYPE = `0x2::coin::Coin<${TREE_COIN_TYPE}>`;
var SUI_ADDRESS = /^0x[0-9a-f]{64}$/;
var exclusionMap = new Map(tree_leaderboard_exclusions_default.map((item) => [item.address.toLowerCase(), item]));
function normalizeSuiAddress(value) {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  return SUI_ADDRESS.test(normalized) ? normalized : null;
}

// netlify/lib/cetus-tree-constants.ts
var CETUS_TREE_POOL_ID = "0x2ebaff75b8745896404085babb9ef3a77ccbb6c7d3f4db31626cefff04f7f355";
var CETUS_CLMM_PACKAGE = "0x1eabed72c53feb3805120a081dc15963c204dc8d091542592abaf7a35689b2fb";
var CETUS_TREE_POOL_URL = `https://app.cetus.zone/clmm?tab=deposit&poolAddress=${CETUS_TREE_POOL_ID}`;

// netlify/lib/suidex-v2-tree-lp-provider.ts
import { ChannelCredentials } from "@grpc/grpc-js";
import { GrpcTransport } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient } from "@mysten/sui/grpc";
var SUIDEX_V2_PACKAGE = "0xbfac5e1c6bf6ef29b12f7723857695fd2f4da9a11a7d88162c15e9124c243a4a";
var SUIDEX_V2_TREE_POOL_ID = "0x35a1be1f01f9edf7f5221d226f357d194d43c28f2a65cb38640935518d9a5bfc";
var SUI_COIN_TYPE = "0x2::sui::SUI";
var SUIDEX_V2_TREE_LP_TYPE = `${SUIDEX_V2_PACKAGE}::pair::LPCoin<${SUI_COIN_TYPE},${TREE_COIN_TYPE}>`;
var SUIDEX_V2_TREE_LP_COIN_TYPE = `0x2::coin::Coin<${SUIDEX_V2_TREE_LP_TYPE}>`;
var SUIDEX_V2_TREE_FARM_POSITION_TYPE = `${SUIDEX_V2_PACKAGE}::farm::StakingPosition<${SUIDEX_V2_TREE_LP_TYPE}>`;

// netlify/lib/turbos-tree-lp-provider.ts
import { ChannelCredentials as ChannelCredentials2 } from "@grpc/grpc-js";
import { GrpcTransport as GrpcTransport2 } from "@protobuf-ts/grpc-transport";
import { SuiGrpcClient as SuiGrpcClient2 } from "@mysten/sui/grpc";

// netlify/lib/clmm-q64.ts
var CLMM_Q64 = 1n << 64n;

// netlify/lib/turbos-tree-lp-provider.ts
var TURBOS_PACKAGE = "0x91bfbc386a41afcfd9b2533058d7e915a1d3829089cc268ff4333d54d6339ca1";
var TURBOS_POSITION_NFT_TYPE = `${TURBOS_PACKAGE}::position_nft::TurbosPositionNFT`;
var TURBOS_POSITION_TYPE = `${TURBOS_PACKAGE}::position_manager::Position`;
var TURBOS_POOL_POSITION_VALUE_TYPE = `${TURBOS_PACKAGE}::pool::Position`;
var TURBOS_TREE_POOL_IDS = [
  "0x4a8c450d393fee360fc8c2a2ed30bf6f9e4de5077024e9628cd3510e272bf490",
  "0xaa133ce1f8fd55d85b6fc87c1b3054cb717d83be477ef3635c661c21fbdfa0ee",
  "0xc327fdc9b129602e91df9bd59cf3e4a921ce5509844a3b6c8adddc5ed320636d",
  "0xd5d7d9a614327feed096a437f416aa98f440393d9ac52d97c87e6e0dd6e719bb",
  "0xe1468ece8e4d2940b30dec776eaee9b235b23458868027da871bc42817263a12"
];
function canonicalAddress(value) {
  const address = value.toLowerCase().replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${address}`;
}
function normalizeStructType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  const parts = compact.split("::");
  if (parts.length !== 3 || !/^(0x)?[0-9a-f]+$/.test(parts[0]) || !parts[1] || !parts[2]) return null;
  return `${canonicalAddress(parts[0])}::${parts[1]}::${parts[2]}`;
}
function canonicalizeMoveType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  if (!compact) return null;
  return compact.replace(/(^|[<,])((?:0x)?[0-9a-f]+)(?=::)/g, (_match, prefix, address) => `${prefix}${canonicalAddress(address)}`);
}
var NORMALIZED_TREE = normalizeStructType(TREE_COIN_TYPE);
var NORMALIZED_PACKAGE = canonicalAddress(TURBOS_PACKAGE);
var NORMALIZED_POSITION_TYPE = canonicalizeMoveType(TURBOS_POSITION_TYPE);
var NORMALIZED_POOL_POSITION_VALUE_TYPE = canonicalizeMoveType(TURBOS_POOL_POSITION_VALUE_TYPE);

// netlify/lib/tree-v3-overview.ts
var TREE_V3_PACKAGE = "0xb5f529c1dcda6580a61bf7ee9fbd524b50be62f11044d137c8202c8cbace9e56";
var TREE_V3_POOL_ID = "0x39d5ba22e01e45bc4129ec28a0bef52e8fee8db5d07d337adf9540e3cb9074cf";
var TREE_V3_POSITION_TYPE = `${TREE_V3_PACKAGE}::position::Position`;
var SUI_COIN_TYPE2 = "0x2::sui::SUI";
var TREE_V3_FEE_PERCENT = 0.25;
var TREE_DECIMALS2 = 6;
var SUI_DECIMALS = 9;
var TREE_V3_REWARD_TOKENS = Object.freeze([
  Object.freeze({ coinType: "0xbfac5e1c6bf6ef29b12f7723857695fd2f4da9a11a7d88162c15e9124c243a4a::victory_token::VICTORY_TOKEN", symbol: "VICTORY", decimals: 6 }),
  Object.freeze({ coinType: TREE_COIN_TYPE, symbol: "TREE", decimals: TREE_DECIMALS2 }),
  Object.freeze({ coinType: "0xaafb102dd0902f5055cadecd687fb5b71ca82ef0e0285d90afde828ec58ca96b::btc::BTC", symbol: "wBTC", decimals: 8 })
]);
function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function normalizeCoinType(value) {
  if (typeof value !== "string") return null;
  const compact = value.trim().toLowerCase().replace(/\s+/g, "");
  const parts = compact.split("::");
  if (parts.length !== 3 || !/^(0x)?[0-9a-f]+$/.test(parts[0]) || !parts[1] || !parts[2]) return null;
  const address = parts[0].replace(/^0x/, "").replace(/^0+/, "") || "0";
  return `0x${address}::${parts[1]}::${parts[2]}`;
}
function parseUnsigned(value) {
  if (typeof value === "bigint") return value >= 0n ? value : null;
  if (typeof value === "number") return Number.isSafeInteger(value) && value >= 0 ? BigInt(value) : null;
  if (typeof value !== "string" || !/^\d+$/.test(value.trim())) return null;
  try {
    return BigInt(value.trim());
  } catch {
    return null;
  }
}
function parseSignedI322(value) {
  const nested = record(value).bits;
  if (nested !== void 0) return parseSignedI322(nested);
  const numeric = typeof value === "number" ? value : typeof value === "string" && /^-?\d+$/.test(value.trim()) ? Number(value) : Number.NaN;
  if (!Number.isInteger(numeric) || numeric < -2147483648 || numeric > 4294967295) return null;
  return numeric > 2147483647 ? numeric - 4294967296 : numeric;
}
function formatRawAmount(raw, decimals2, maximumFractionDigits = decimals2) {
  const negative = raw < 0n;
  const value = negative ? -raw : raw;
  const scale = 10n ** BigInt(decimals2);
  const whole = value / scale;
  const fraction = (value % scale).toString().padStart(decimals2, "0").replace(/0+$/, "").slice(0, maximumFractionDigits);
  return `${negative ? "-" : ""}${whole.toString()}${fraction ? `.${fraction}` : ""}`;
}
function rationalToDecimal(numerator, denominator, digits = 14) {
  if (denominator <= 0n || numerator < 0n) return "0";
  const whole = numerator / denominator;
  let remainder = numerator % denominator;
  let fraction = "";
  for (let index = 0; index < digits && remainder > 0n; index += 1) {
    remainder *= 10n;
    fraction += (remainder / denominator).toString();
    remainder %= denominator;
  }
  fraction = fraction.replace(/0+$/, "");
  return `${whole.toString()}${fraction ? `.${fraction}` : ""}`;
}
var NORMALIZED_TREE2 = normalizeCoinType(TREE_COIN_TYPE);
var NORMALIZED_SUI = normalizeCoinType(SUI_COIN_TYPE2);
function parseTreeV3Pool(jsonValue, prices) {
  const json = record(jsonValue);
  const poolId = normalizeSuiAddress(json.id);
  const tokenX = normalizeCoinType(json.type_x);
  const tokenY = normalizeCoinType(json.type_y);
  const currentTick = parseSignedI322(json.tick_index);
  const sqrtPrice = parseUnsigned(json.sqrt_price);
  const liquidity = parseUnsigned(json.liquidity);
  const reserveX = parseUnsigned(json.reserve_x);
  const reserveY = parseUnsigned(json.reserve_y);
  const tickSpacing = Number(json.tick_spacing);
  const swapFeeRate = Number(json.swap_fee_rate);
  if (poolId !== TREE_V3_POOL_ID || !tokenX || !tokenY || currentTick === null || sqrtPrice === null || sqrtPrice <= 0n || liquidity === null || reserveX === null || reserveY === null || tickSpacing !== 60 || swapFeeRate !== 2500) return null;
  const pair = /* @__PURE__ */ new Set([tokenX, tokenY]);
  if (!pair.has(NORMALIZED_TREE2) || !pair.has(NORMALIZED_SUI) || pair.size !== 2) return null;
  const reserveSuiRaw = tokenX === NORMALIZED_SUI ? reserveX : reserveY;
  const reserveTreeRaw = tokenX === NORMALIZED_TREE2 ? reserveX : reserveY;
  const q128 = 1n << 128n;
  const rawYPerXNumerator = sqrtPrice * sqrtPrice;
  let suiPerTreeNumerator;
  let suiPerTreeDenominator;
  if (tokenX === NORMALIZED_TREE2 && tokenY === NORMALIZED_SUI) {
    suiPerTreeNumerator = rawYPerXNumerator * 10n ** BigInt(TREE_DECIMALS2);
    suiPerTreeDenominator = q128 * 10n ** BigInt(SUI_DECIMALS);
  } else {
    suiPerTreeNumerator = q128 * 10n ** BigInt(TREE_DECIMALS2);
    suiPerTreeDenominator = rawYPerXNumerator * 10n ** BigInt(SUI_DECIMALS);
  }
  if (suiPerTreeNumerator <= 0n || suiPerTreeDenominator <= 0n) return null;
  const treePerSuiNumerator = suiPerTreeDenominator;
  const treePerSuiDenominator = suiPerTreeNumerator;
  const suiUsd = Number(prices?.suiUsd);
  const treeUsd = Number(prices?.treeUsd);
  const reserveSui = Number(formatRawAmount(reserveSuiRaw, SUI_DECIMALS));
  const reserveTree = Number(formatRawAmount(reserveTreeRaw, TREE_DECIMALS2));
  const tvlUsdEstimate = Number.isFinite(suiUsd) && suiUsd > 0 && Number.isFinite(treeUsd) && treeUsd > 0 ? reserveSui * suiUsd + reserveTree * treeUsd : null;
  return {
    verified: true,
    poolId,
    tokenX,
    tokenY,
    currentTick,
    sqrtPriceRaw: sqrtPrice.toString(),
    liquidityRaw: liquidity.toString(),
    reserveSuiRaw: reserveSuiRaw.toString(),
    reserveTreeRaw: reserveTreeRaw.toString(),
    reserveSui: formatRawAmount(reserveSuiRaw, SUI_DECIMALS, 6),
    reserveTree: formatRawAmount(reserveTreeRaw, TREE_DECIMALS2, 2),
    priceSuiPerTree: rationalToDecimal(suiPerTreeNumerator, suiPerTreeDenominator, 12),
    priceTreePerSui: rationalToDecimal(treePerSuiNumerator, treePerSuiDenominator, 6),
    feePercent: TREE_V3_FEE_PERCENT,
    tickSpacing,
    tvlUsdEstimate: Number.isFinite(tvlUsdEstimate) ? tvlUsdEstimate : null,
    tvlSource: Number.isFinite(tvlUsdEstimate) ? "onchain-reserves-plus-coingecko" : "unavailable"
  };
}
var U128_MODULUS = 1n << 128n;

// netlify/lib/tree-liquidity-overview.ts
var USDC_COIN_TYPE = "0xdba34672e30cb065b1f93e3ab55318768fd6fef66c15942c9f7cb846e2f900e7::usdc::USDC";
var WBTC_COIN_TYPE = "0xaafb102dd0902f5055cadecd687fb5b71ca82ef0e0285d90afde828ec58ca96b::btc::BTC";
var decimals = /* @__PURE__ */ new Map([
  [normalizeCoinType(SUI_COIN_TYPE2), 9],
  [normalizeCoinType(TREE_COIN_TYPE), 6],
  [normalizeCoinType(USDC_COIN_TYPE), 6],
  [normalizeCoinType(WBTC_COIN_TYPE), 8]
]);
var Q64 = 18446744073709552e3;
function finitePrice(value) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : null;
}
function priceFor(type, prices) {
  const normalized = normalizeCoinType(type);
  if (normalized === normalizeCoinType(SUI_COIN_TYPE2)) return finitePrice(prices.suiUsd);
  if (normalized === normalizeCoinType(TREE_COIN_TYPE)) return finitePrice(prices.treeUsd);
  if (normalized === normalizeCoinType(USDC_COIN_TYPE)) return finitePrice(prices.usdcUsd);
  if (normalized === normalizeCoinType(WBTC_COIN_TYPE)) return finitePrice(prices.wbtcUsd);
  return null;
}
function unsigned(value) {
  if (typeof value !== "string" || !/^\d+$/.test(value)) return null;
  try {
    return BigInt(value);
  } catch {
    return null;
  }
}
function usdValue(raw, type, prices) {
  const normalized = normalizeCoinType(type);
  const tokenDecimals = normalized ? decimals.get(normalized) : void 0;
  const price = priceFor(type, prices);
  if (tokenDecimals === void 0 || price === null) return null;
  return Number(raw) / 10 ** tokenDecimals * price;
}
function genericTypes(type) {
  if (typeof type !== "string") return [];
  const start = type.indexOf("<");
  const end = type.lastIndexOf(">");
  if (start < 0 || end <= start) return [];
  const values = [];
  let depth = 0;
  let token = "";
  for (const character of type.slice(start + 1, end)) {
    if (character === "<") depth += 1;
    if (character === ">") depth -= 1;
    if (character === "," && depth === 0) {
      values.push(token.trim());
      token = "";
    } else token += character;
  }
  if (token.trim()) values.push(token.trim());
  return values;
}
function pairIsTree(typeA, typeB) {
  const pair = /* @__PURE__ */ new Set([normalizeCoinType(typeA), normalizeCoinType(typeB)]);
  return pair.has(normalizeCoinType(TREE_COIN_TYPE));
}
function valuePair(rawA, typeA, rawB, typeB, prices) {
  const valueA = usdValue(rawA, typeA, prices);
  const valueB = usdValue(rawB, typeB, prices);
  return valueA === null || valueB === null ? null : valueA + valueB;
}
function spotSuiPerTree(sqrtPrice, typeA, typeB) {
  const decimalsA = decimals.get(normalizeCoinType(typeA));
  const decimalsB = decimals.get(normalizeCoinType(typeB));
  if (decimalsA === void 0 || decimalsB === void 0 || sqrtPrice <= 0n) return null;
  const rawBPerA = (Number(sqrtPrice) / Q64) ** 2;
  const humanBPerA = rawBPerA * 10 ** (decimalsA - decimalsB);
  if (!Number.isFinite(humanBPerA) || humanBPerA <= 0) return null;
  if (normalizeCoinType(typeA) === normalizeCoinType(TREE_COIN_TYPE) && normalizeCoinType(typeB) === normalizeCoinType(SUI_COIN_TYPE2)) return humanBPerA;
  if (normalizeCoinType(typeA) === normalizeCoinType(SUI_COIN_TYPE2) && normalizeCoinType(typeB) === normalizeCoinType(TREE_COIN_TYPE)) return 1 / humanBPerA;
  return null;
}
function calculateTreeLiquidity(objects, prices) {
  const byId = new Map(objects.map((object) => [normalizeSuiAddress(object.address ?? record(object.json).id), object]));
  const v2 = byId.get(SUIDEX_V2_TREE_POOL_ID);
  const v3 = byId.get(TREE_V3_POOL_ID);
  const cetus = byId.get(CETUS_TREE_POOL_ID);
  if (!v2 || !v3 || !cetus) return null;
  const v2Types = genericTypes(v2.type);
  const v2Json = record(v2.json);
  const reserve0 = unsigned(v2Json.reserve0);
  const reserve1 = unsigned(v2Json.reserve1);
  if (v2Types.length !== 2 || !pairIsTree(v2Types[0], v2Types[1]) || reserve0 === null || reserve1 === null) return null;
  const suiDexV2TvlUsd = valuePair(reserve0, v2Types[0], reserve1, v2Types[1], prices);
  const v3Pool = parseTreeV3Pool(v3.json, prices);
  const suiDexV3TvlUsd = v3Pool?.tvlUsdEstimate ?? null;
  if (suiDexV2TvlUsd === null || suiDexV3TvlUsd === null) return null;
  const cetusTypes = genericTypes(cetus.type);
  const cetusJson = record(cetus.json);
  const cetusCoinA = unsigned(cetusJson.coin_a);
  const cetusCoinB = unsigned(cetusJson.coin_b);
  const cetusFeesA = unsigned(cetusJson.fee_protocol_coin_a);
  const cetusFeesB = unsigned(cetusJson.fee_protocol_coin_b);
  const cetusLiquidity = unsigned(cetusJson.liquidity);
  const cetusSqrtPrice = unsigned(cetusJson.current_sqrt_price);
  const cetusFeeRate = Number(cetusJson.fee_rate);
  if (cetusTypes.length !== 2 || !String(cetus.type).toLowerCase().startsWith(`${CETUS_CLMM_PACKAGE}::pool::pool<`) || normalizeCoinType(cetusTypes[0]) !== normalizeCoinType(TREE_COIN_TYPE) || normalizeCoinType(cetusTypes[1]) !== normalizeCoinType(SUI_COIN_TYPE2) || cetusCoinA === null || cetusCoinB === null || cetusFeesA === null || cetusFeesB === null || cetusCoinA < cetusFeesA || cetusCoinB < cetusFeesB || cetusLiquidity === null || cetusLiquidity === 0n || cetusSqrtPrice === null || !Number.isFinite(cetusFeeRate) || cetusFeeRate <= 0) return null;
  const cetusTvlUsd = valuePair(cetusCoinA - cetusFeesA, cetusTypes[0], cetusCoinB - cetusFeesB, cetusTypes[1], prices);
  const cetusPriceSuiPerTree = spotSuiPerTree(cetusSqrtPrice, cetusTypes[0], cetusTypes[1]);
  if (cetusTvlUsd === null || cetusPriceSuiPerTree === null) return null;
  const cetusPool = {
    poolId: CETUS_TREE_POOL_ID,
    tvlUsd: cetusTvlUsd,
    active: true,
    coinTypeA: cetusTypes[0],
    coinTypeB: cetusTypes[1],
    feePercent: cetusFeeRate / 1e4,
    priceSuiPerTree: cetusPriceSuiPerTree
  };
  let turbosTvlUsd = 0;
  let activeTurbosPools = 0;
  const turbosPools = [];
  for (const poolId of TURBOS_TREE_POOL_IDS) {
    const pool = byId.get(poolId);
    if (!pool) return null;
    const types = genericTypes(pool.type);
    const json = record(pool.json);
    const coinA = unsigned(json.coin_a);
    const coinB = unsigned(json.coin_b);
    const feesA = unsigned(json.protocol_fees_a);
    const feesB = unsigned(json.protocol_fees_b);
    const liquidity = unsigned(json.liquidity);
    const sqrtPrice = unsigned(json.sqrt_price);
    const feeRaw = Number(json.fee);
    if (types.length !== 3 || !String(pool.type).toLowerCase().startsWith(`${TURBOS_PACKAGE}::pool::pool<`) || !pairIsTree(types[0], types[1]) || coinA === null || coinB === null || feesA === null || feesB === null || coinA < feesA || coinB < feesB || liquidity === null) return null;
    const value = liquidity === 0n ? 0 : valuePair(coinA - feesA, types[0], coinB - feesB, types[1], prices);
    if (value === null) return null;
    const priceSuiPerTree = sqrtPrice ? spotSuiPerTree(sqrtPrice, types[0], types[1]) : null;
    const feePercent = Number.isFinite(feeRaw) && feeRaw > 0 ? feeRaw / 1e4 : null;
    const isActiveSuiTree = liquidity > 0n && (/* @__PURE__ */ new Set([normalizeCoinType(types[0]), normalizeCoinType(types[1])])).has(normalizeCoinType(SUI_COIN_TYPE2));
    if (isActiveSuiTree && (priceSuiPerTree === null || feePercent === null)) return null;
    turbosPools.push({ poolId, tvlUsd: value, active: liquidity > 0n, coinTypeA: types[0], coinTypeB: types[1], feePercent, priceSuiPerTree });
    if (liquidity === 0n) continue;
    turbosTvlUsd += value;
    activeTurbosPools += 1;
  }
  return {
    recognizedLiquidityUsd: suiDexV2TvlUsd + suiDexV3TvlUsd + turbosTvlUsd + cetusTvlUsd,
    suiDexV2TvlUsd,
    suiDexV3TvlUsd,
    turbosTvlUsd,
    cetusTvlUsd,
    cetusPool,
    activeTurbosPools,
    turbosPools
  };
}

// netlify/functions/tree-liquidity.ts
var GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
var POOL_IDS = [SUIDEX_V2_TREE_POOL_ID, TREE_V3_POOL_ID, ...TURBOS_TREE_POOL_IDS, CETUS_TREE_POOL_ID];
function response(body, status = 200, cache = "public, max-age=20, s-maxage=30, stale-while-revalidate=60") {
  return Response.json(body, { status, headers: { "Cache-Control": cache, "X-Content-Type-Options": "nosniff" } });
}
async function getPoolObjects() {
  const fields = POOL_IDS.map((id, index) => `p${index}: object(address: "${id}") { address asMoveObject { contents { type { repr } json } } }`).join("\n");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8e3);
  try {
    const result = await fetch(GRAPHQL_URL, {
      method: "POST",
      signal: controller.signal,
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({ query: `query TreeLiquidityPools { ${fields} }` })
    });
    if (!result.ok) throw new Error(`Sui GraphQL returned HTTP ${result.status}`);
    const payload = record(await result.json());
    if (Array.isArray(payload.errors) && payload.errors.length) throw new Error("Sui GraphQL returned pool errors.");
    const data = record(payload.data);
    return POOL_IDS.map((_id, index) => {
      const object = record(data[`p${index}`]);
      const contents = record(record(object.asMoveObject).contents);
      return { address: object.address, type: record(contents.type).repr, json: contents.json };
    });
  } finally {
    clearTimeout(timeout);
  }
}
async function getPrices() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 6e3);
  try {
    const result = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=sui,thickquidity,bitcoin,usd-coin&vs_currencies=usd", {
      headers: { Accept: "application/json" },
      signal: controller.signal
    });
    if (!result.ok) throw new Error(`CoinGecko returned HTTP ${result.status}`);
    const payload = record(await result.json());
    const price = (id) => Number(record(payload[id]).usd);
    const prices = { suiUsd: price("sui"), treeUsd: price("thickquidity"), wbtcUsd: price("bitcoin"), usdcUsd: price("usd-coin") };
    if (Object.values(prices).some((value) => !Number.isFinite(value) || value <= 0)) throw new Error("Reference prices were incomplete.");
    return prices;
  } finally {
    clearTimeout(timeout);
  }
}
var tree_liquidity_default = async (request) => {
  if (request.method !== "GET") return response({ status: "error", error: "method-not-allowed" }, 405, "no-store");
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  try {
    const [objects, prices] = await Promise.all([getPoolObjects(), getPrices()]);
    const liquidity = calculateTreeLiquidity(objects, prices);
    if (!liquidity) throw new Error("One or more recognized pools could not be completely verified.");
    return response({
      status: "ok",
      generatedAt,
      network: "sui-mainnet",
      source: "Sui Mainnet reserves + CoinGecko USD prices",
      methodology: "recognized-tree-liquidity-v2",
      prices,
      liquidity,
      coverage: { suiDexV2Pools: 1, suiDexV3Pools: 1, turbosPoolsChecked: TURBOS_TREE_POOL_IDS.length, activeTurbosPools: liquidity.activeTurbosPools, cetusPools: 1 },
      warnings: ["USD liquidity is estimated from current verified on-chain reserves and current external reference prices."]
    });
  } catch (error) {
    console.error("TREE liquidity overview failed:", error);
    return response({ status: "error", generatedAt, error: "liquidity-verification-unavailable", message: error instanceof Error ? error.message : String(error) }, 503, "no-store");
  }
};
var config = { path: "/api/tree-liquidity" };
export {
  config,
  tree_liquidity_default as default
};
