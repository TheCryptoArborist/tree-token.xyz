
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/client/protocol-version.mjs
var CLIENT_PROTOCOL_VERSION_HEADER = "x-sui-client-protocol-version";
var MAX_PROTOCOL_VERSION = 138;

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/transport.mjs
import { RpcError } from "@protobuf-ts/runtime-rpc";
import { GrpcStatusCode, GrpcWebFetchTransport } from "@protobuf-ts/grpcweb-transport";
var MESSAGE_DECODED = /* @__PURE__ */ Symbol.for("@mysten/sui/grpc/decoded-status-message");
function decodeGrpcStatusMessage(message) {
  if (!message.includes("%")) return message;
  try {
    return decodeURIComponent(message);
  } catch {
    return message;
  }
}
function markStatusMessageRead(error) {
  if (MESSAGE_DECODED in error) return false;
  Object.defineProperty(error, MESSAGE_DECODED, {
    value: true,
    configurable: true
  });
  return true;
}
function decodeStatusMessageOnce(error) {
  if (markStatusMessageRead(error)) error.message = decodeGrpcStatusMessage(error.message);
}
function hasDecodedStatusMessage(error) {
  return MESSAGE_DECODED in error;
}
function readProperty(value, key) {
  if (typeof value !== "object" || value === null) return void 0;
  try {
    return value[key];
  } catch {
    return;
  }
}
function abortStatus(reason) {
  const code = readProperty(reason, "code");
  if (typeof code === "string" && typeof GrpcStatusCode[code] === "number") return code;
  return readProperty(reason, "name") === "TimeoutError" ? GrpcStatusCode[GrpcStatusCode.DEADLINE_EXCEEDED] : GrpcStatusCode[GrpcStatusCode.CANCELLED];
}
function isAbortReasonText(message, reason) {
  if (typeof reason === "string") return message === reason;
  const reasonMessage = readProperty(reason, "message");
  return typeof reasonMessage === "string" && message === reasonMessage;
}
function normalizeGrpcError(error, signal) {
  try {
    normalize(error, signal);
  } catch {
  }
}
function normalize(error, signal) {
  if (!(error instanceof RpcError)) return;
  if (signal?.aborted && (error.code === GrpcStatusCode[GrpcStatusCode.INTERNAL] || error.code === GrpcStatusCode[GrpcStatusCode.CANCELLED])) {
    error.code = abortStatus(signal.reason);
    if (isAbortReasonText(error.message, signal.reason)) markStatusMessageRead(error);
    else decodeStatusMessageOnce(error);
    return;
  }
  decodeStatusMessageOnce(error);
}
function normalizeRejections(promises, signal) {
  for (const promise of promises) promise.then(void 0, (error) => normalizeGrpcError(error, signal));
}
var GrpcWebFetchTransport$1 = class extends GrpcWebFetchTransport {
  constructor(options) {
    super({
      ...options,
      meta: {
        [CLIENT_PROTOCOL_VERSION_HEADER]: String(MAX_PROTOCOL_VERSION),
        ...options.meta
      }
    });
  }
  unary(method, input, options) {
    const call = super.unary(method, input, options);
    normalizeRejections([
      call.headers,
      call.response,
      call.status,
      call.trailers
    ], options.abort);
    return call;
  }
  serverStreaming(method, input, options) {
    const call = super.serverStreaming(method, input, options);
    call.responses.onError((error) => normalizeGrpcError(error, options.abort));
    normalizeRejections([
      call.headers,
      call.status,
      call.trailers
    ], options.abort);
    return call;
  }
};
function withClientProtocolVersion(transport) {
  return {
    mergeOptions(options) {
      const merged = transport.mergeOptions(options);
      return {
        ...merged,
        meta: {
          [CLIENT_PROTOCOL_VERSION_HEADER]: String(MAX_PROTOCOL_VERSION),
          ...merged.meta
        }
      };
    },
    unary: transport.unary.bind(transport),
    serverStreaming: transport.serverStreaming.bind(transport),
    clientStreaming: transport.clientStreaming.bind(transport),
    duplex: transport.duplex.bind(transport)
  };
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/utils/suins.mjs
var SUI_NS_NAME_REGEX = /^(?!.*(^(?!@)|[-.@])($|[-.@]))(?:[a-z0-9-]{0,63}(?:\.[a-z0-9-]{0,63})*)?@[a-z0-9-]{0,63}$/i;
var SUI_NS_DOMAIN_REGEX = /^(?!.*(^|[-.])($|[-.]))(?:[a-z0-9-]{0,63}\.)+sui$/i;
var MAX_SUI_NS_NAME_LENGTH = 235;
function isValidSuiNSName(name) {
  if (name.length > MAX_SUI_NS_NAME_LENGTH) return false;
  if (name.includes("@")) return SUI_NS_NAME_REGEX.test(name);
  return SUI_NS_DOMAIN_REGEX.test(name);
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/utils/named-packages.mjs
var NAME_PATTERN = /^([a-z0-9]+(?:-[a-z0-9]+)*)$/;
var VERSION_REGEX = /^\d+$/;
var MAX_APP_SIZE = 64;
var NAME_SEPARATOR = "/";
var isValidNamedPackage = (name) => {
  const parts = name.split(NAME_SEPARATOR);
  if (parts.length < 2 || parts.length > 3) return false;
  const [org, app, version] = parts;
  if (version !== void 0 && !VERSION_REGEX.test(version)) return false;
  if (!isValidSuiNSName(org)) return false;
  return NAME_PATTERN.test(app) && app.length < MAX_APP_SIZE;
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/utils/sui-types.mjs
import { fromBase58, splitGenericParameters } from "@mysten/bcs";
var SUI_ADDRESS_LENGTH = 32;
function isValidSuiAddress(value) {
  return isHex(value) && getHexByteLength(value) === SUI_ADDRESS_LENGTH;
}
function parseTypeTag(type) {
  if (type.startsWith("vector<")) {
    if (!type.endsWith(">")) throw new Error(`Invalid type tag: ${type}`);
    const inner = type.slice(7, -1);
    if (!inner) throw new Error(`Invalid type tag: ${type}`);
    const parsed = parseTypeTag(inner);
    if (typeof parsed === "string") return `vector<${parsed}>`;
    return `vector<${normalizeStructTag(parsed)}>`;
  }
  if (!type.includes("::")) return type;
  return parseStructTag(type);
}
function parseStructTag(type) {
  const parts = type.split("::");
  if (parts.length < 3) throw new Error(`Invalid struct tag: ${type}`);
  const [address, module] = parts;
  if (!address || !module) throw new Error(`Invalid struct tag: ${type}`);
  const isMvrPackage = isValidNamedPackage(address);
  const rest = type.slice(address.length + module.length + 4);
  const name = rest.includes("<") ? rest.slice(0, rest.indexOf("<")) : rest;
  if (!name || rest.includes("<") && !rest.endsWith(">")) throw new Error(`Invalid struct tag: ${type}`);
  const typeParams = rest.includes("<") ? splitGenericParameters(rest.slice(rest.indexOf("<") + 1, rest.lastIndexOf(">"))).map((typeParam) => parseTypeTag(typeParam.trim())) : [];
  return {
    address: isMvrPackage ? address : normalizeSuiAddress(address),
    module,
    name,
    typeParams
  };
}
function normalizeStructTag(type) {
  if (typeof type === "string" && type.startsWith("vector<")) throw new Error("normalizeStructTag does not support vector types. Use normalizeTypeTag instead.");
  const { address, module, name, typeParams } = typeof type === "string" ? parseStructTag(type) : type;
  return `${address}::${module}::${name}${typeParams?.length > 0 ? `<${typeParams.map((typeParam) => typeof typeParam === "string" ? typeParam : normalizeStructTag(typeParam)).join(",")}>` : ""}`;
}
function normalizeSuiAddress(value, forceAdd0x = false) {
  let address = value.toLowerCase();
  if (!forceAdd0x && address.startsWith("0x")) address = address.slice(2);
  return `0x${address.padStart(SUI_ADDRESS_LENGTH * 2, "0")}`;
}
function isHex(value) {
  return /^(0x|0X)?[a-fA-F0-9]+$/.test(value) && value.length % 2 === 0;
}
function getHexByteLength(value) {
  return /^(0x|0X)/.test(value) ? (value.length - 2) / 2 : value.length / 2;
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/bcs/type-tag-serializer.mjs
import { splitGenericParameters as splitGenericParameters2 } from "@mysten/bcs";
var VECTOR_REGEX = /^vector<(.+)>$/;
var STRUCT_REGEX = /^([^:]+)::([^:]+)::([^<]+)(<(.+)>)?/;
var TypeTagSerializer = class TypeTagSerializer2 {
  static parseFromStr(str, normalizeAddress = false) {
    if (str === "address") return { address: null };
    else if (str === "bool") return { bool: null };
    else if (str === "u8") return { u8: null };
    else if (str === "u16") return { u16: null };
    else if (str === "u32") return { u32: null };
    else if (str === "u64") return { u64: null };
    else if (str === "u128") return { u128: null };
    else if (str === "u256") return { u256: null };
    else if (str === "signer") return { signer: null };
    const vectorMatch = str.match(VECTOR_REGEX);
    if (vectorMatch) return { vector: TypeTagSerializer2.parseFromStr(vectorMatch[1], normalizeAddress) };
    const structMatch = str.match(STRUCT_REGEX);
    if (structMatch) return { struct: {
      address: normalizeAddress ? normalizeSuiAddress(structMatch[1]) : structMatch[1],
      module: structMatch[2],
      name: structMatch[3],
      typeParams: structMatch[5] === void 0 ? [] : TypeTagSerializer2.parseStructTypeArgs(structMatch[5], normalizeAddress)
    } };
    throw new Error(`Encountered unexpected token when parsing type args for ${str}`);
  }
  static parseStructTypeArgs(str, normalizeAddress = false) {
    return splitGenericParameters2(str).map((tok) => TypeTagSerializer2.parseFromStr(tok, normalizeAddress));
  }
  static tagToString(tag) {
    if ("bool" in tag) return "bool";
    if ("u8" in tag) return "u8";
    if ("u16" in tag) return "u16";
    if ("u32" in tag) return "u32";
    if ("u64" in tag) return "u64";
    if ("u128" in tag) return "u128";
    if ("u256" in tag) return "u256";
    if ("address" in tag) return "address";
    if ("signer" in tag) return "signer";
    if ("vector" in tag) return `vector<${TypeTagSerializer2.tagToString(tag.vector)}>`;
    if ("struct" in tag) {
      const struct = tag.struct;
      const typeParams = struct.typeParams.map(TypeTagSerializer2.tagToString).join(", ");
      return `${struct.address}::${struct.module}::${struct.name}${typeParams ? `<${typeParams}>` : ""}`;
    }
    throw new Error("Invalid TypeTag");
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/bcs/bcs.mjs
import { bcs, fromBase58 as fromBase582, fromBase64, toBase58, toBase64, toHex } from "@mysten/bcs";
function unsafe_u64(options) {
  return bcs.u64({
    name: "unsafe_u64",
    ...options
  }).transform({
    input: (val) => val,
    output: (val) => Number(val)
  });
}
function optionEnum(type) {
  return bcs.enum("Option", {
    None: null,
    Some: type
  });
}
var HEX_NIBBLES = new Int8Array(128).fill(-1);
for (let i = 0; i < 16; i++) {
  HEX_NIBBLES["0123456789abcdef".charCodeAt(i)] = i;
  HEX_NIBBLES["0123456789ABCDEF".charCodeAt(i)] = i;
}
function hexNibble(code) {
  return code < 128 ? HEX_NIBBLES[code] : -1;
}
function decodeAddress(value) {
  if (!value) return null;
  const start = value.length >= 2 && value[0] === "0" && (value[1] === "x" || value[1] === "X") ? 2 : 0;
  if (value.length - start > SUI_ADDRESS_LENGTH * 2) return null;
  const bytes = new Uint8Array(SUI_ADDRESS_LENGTH);
  let byteIndex = SUI_ADDRESS_LENGTH - 1;
  let i = value.length - 1;
  for (; i >= start + 1; i -= 2) {
    const low = hexNibble(value.charCodeAt(i));
    const high = hexNibble(value.charCodeAt(i - 1));
    if (low < 0 || high < 0) return null;
    bytes[byteIndex--] = high << 4 | low;
  }
  if (i === start) {
    const low = hexNibble(value.charCodeAt(i));
    if (low < 0) return null;
    bytes[byteIndex] = low;
  }
  return bytes;
}
var Address = bcs.bytes(SUI_ADDRESS_LENGTH).transform({
  input: (val) => {
    if (typeof val === "string") {
      const bytes = decodeAddress(val);
      if (!bytes) throw new Error(`Invalid Sui address ${val}`);
      return bytes;
    }
    const address = toHex(val);
    if (!address || !isValidSuiAddress(normalizeSuiAddress(address))) throw new Error(`Invalid Sui address ${address}`);
    return val;
  },
  output: (val) => `0x${toHex(val)}`
});
var ObjectDigest = bcs.byteVector().transform({
  name: "ObjectDigest",
  input: (value) => {
    const bytes = fromBase582(value);
    if (bytes.length !== 32) throw new Error("ObjectDigest must be 32 bytes");
    return bytes;
  },
  output: (value) => toBase58(value)
});
var SuiObjectRef = bcs.struct("SuiObjectRef", {
  objectId: Address,
  version: bcs.u64(),
  digest: ObjectDigest
});
var SharedObjectRef = bcs.struct("SharedObjectRef", {
  objectId: Address,
  initialSharedVersion: bcs.u64(),
  mutable: bcs.bool()
});
var ObjectArg = bcs.enum("ObjectArg", {
  ImmOrOwnedObject: SuiObjectRef,
  SharedObject: SharedObjectRef,
  Receiving: SuiObjectRef
});
var Owner = bcs.enum("Owner", {
  AddressOwner: Address,
  ObjectOwner: Address,
  Shared: bcs.struct("Shared", { initialSharedVersion: bcs.u64() }),
  Immutable: null,
  ConsensusAddressOwner: bcs.struct("ConsensusAddressOwner", {
    startVersion: bcs.u64(),
    owner: Address
  })
});
var Reservation = bcs.enum("Reservation", { MaxAmountU64: bcs.u64() });
var WithdrawalType = bcs.enum("WithdrawalType", { Balance: bcs.lazy(() => TypeTag) });
var WithdrawFrom = bcs.enum("WithdrawFrom", {
  Sender: null,
  Sponsor: null,
  SenderAllowance: bcs.struct("SenderAllowance", {
    funder: Address,
    allowance: Address
  })
});
var FundsWithdrawal = bcs.struct("FundsWithdrawal", {
  reservation: Reservation,
  typeArg: WithdrawalType,
  withdrawFrom: WithdrawFrom
});
var CallArg = bcs.enum("CallArg", {
  Pure: bcs.struct("Pure", { bytes: bcs.byteVector().transform({
    input: (val) => typeof val === "string" ? fromBase64(val) : val,
    output: (val) => toBase64(val)
  }) }),
  Object: ObjectArg,
  FundsWithdrawal
});
var InnerTypeTag = bcs.enum("TypeTag", {
  bool: null,
  u8: null,
  u64: null,
  u128: null,
  address: null,
  signer: null,
  vector: bcs.lazy(() => InnerTypeTag),
  struct: bcs.lazy(() => StructTag),
  u16: null,
  u32: null,
  u256: null
});
var TypeTag = InnerTypeTag.transform({
  input: (typeTag) => typeof typeTag === "string" ? TypeTagSerializer.parseFromStr(typeTag, true) : typeTag,
  output: (typeTag) => TypeTagSerializer.tagToString(typeTag)
});
var Argument = bcs.enum("Argument", {
  GasCoin: null,
  Input: bcs.u16(),
  Result: bcs.u16(),
  NestedResult: bcs.tuple([bcs.u16(), bcs.u16()])
});
var ProgrammableMoveCall = bcs.struct("ProgrammableMoveCall", {
  package: Address,
  module: bcs.string(),
  function: bcs.string(),
  typeArguments: bcs.vector(TypeTag),
  arguments: bcs.vector(Argument)
});
var Command = bcs.enum("Command", {
  MoveCall: ProgrammableMoveCall,
  TransferObjects: bcs.struct("TransferObjects", {
    objects: bcs.vector(Argument),
    address: Argument
  }),
  SplitCoins: bcs.struct("SplitCoins", {
    coin: Argument,
    amounts: bcs.vector(Argument)
  }),
  MergeCoins: bcs.struct("MergeCoins", {
    destination: Argument,
    sources: bcs.vector(Argument)
  }),
  Publish: bcs.struct("Publish", {
    modules: bcs.vector(bcs.byteVector().transform({
      input: (val) => typeof val === "string" ? fromBase64(val) : val,
      output: (val) => toBase64(val)
    })),
    dependencies: bcs.vector(Address)
  }),
  MakeMoveVec: bcs.struct("MakeMoveVec", {
    type: optionEnum(TypeTag).transform({
      input: (val) => val === null ? { None: true } : { Some: val },
      output: (val) => val.Some ?? null
    }),
    elements: bcs.vector(Argument)
  }),
  Upgrade: bcs.struct("Upgrade", {
    modules: bcs.vector(bcs.byteVector().transform({
      input: (val) => typeof val === "string" ? fromBase64(val) : val,
      output: (val) => toBase64(val)
    })),
    dependencies: bcs.vector(Address),
    package: Address,
    ticket: Argument
  })
});
var ProgrammableTransaction = bcs.struct("ProgrammableTransaction", {
  inputs: bcs.vector(CallArg),
  commands: bcs.vector(Command)
});
var ValidDuring = bcs.struct("ValidDuring", {
  minEpoch: bcs.option(bcs.u64()),
  maxEpoch: bcs.option(bcs.u64()),
  minTimestamp: bcs.option(bcs.u64()),
  maxTimestamp: bcs.option(bcs.u64()),
  chain: ObjectDigest,
  nonce: bcs.u32()
});
function assertAllowedProposersNotEmpty(proposers) {
  if (proposers.length === 0) throw new Error("Allowed proposers must not be empty");
  return proposers;
}
function assertAllowedProposersStrictlyIncreasing(proposers) {
  assertAllowedProposersNotEmpty(proposers);
  for (let i = 1; i < proposers.length; i++) if (proposers[i] <= proposers[i - 1]) throw new Error("Allowed proposers must be strictly increasing");
  return proposers;
}
var AllowedProposerIndices = bcs.vector(bcs.u32()).transform({
  input: assertAllowedProposersStrictlyIncreasing,
  output: assertAllowedProposersNotEmpty
});
var AllowedProposers = bcs.struct("AllowedProposers", {
  epoch: bcs.u64(),
  proposers: AllowedProposerIndices
});
var Validity = bcs.struct("Validity", {
  minEpoch: bcs.option(bcs.u64()),
  maxEpoch: bcs.option(bcs.u64()),
  minTimestamp: bcs.option(bcs.u64()),
  maxTimestamp: bcs.option(bcs.u64()),
  chain: ObjectDigest,
  nonce: bcs.u32(),
  allowedProposers: bcs.option(AllowedProposers)
});
var TransactionExpiration = bcs.enum("TransactionExpiration", {
  None: null,
  Epoch: unsafe_u64(),
  ValidDuring,
  Validity
});
var StructTag = bcs.struct("StructTag", {
  address: Address,
  module: bcs.string(),
  name: bcs.string(),
  typeParams: bcs.vector(InnerTypeTag)
});
var GasData = bcs.struct("GasData", {
  payment: bcs.vector(SuiObjectRef),
  owner: Address,
  price: bcs.u64(),
  budget: bcs.u64()
});
var IntentScope = bcs.enum("IntentScope", {
  TransactionData: null,
  TransactionEffects: null,
  CheckpointSummary: null,
  PersonalMessage: null
});
var IntentVersion = bcs.enum("IntentVersion", { V0: null });
var AppId = bcs.enum("AppId", { Sui: null });
var Intent = bcs.struct("Intent", {
  scope: IntentScope,
  version: IntentVersion,
  appId: AppId
});
function IntentMessage(T) {
  return bcs.struct(`IntentMessage<${T.name}>`, {
    intent: Intent,
    value: T
  });
}
var CompressedSignature = bcs.enum("CompressedSignature", {
  ED25519: bcs.bytes(64),
  Secp256k1: bcs.bytes(64),
  Secp256r1: bcs.bytes(64),
  ZkLogin: bcs.byteVector(),
  Passkey: bcs.byteVector(),
  MLDSA65: bcs.bytes(3309)
});
var PublicKey = bcs.enum("PublicKey", {
  ED25519: bcs.bytes(32),
  Secp256k1: bcs.bytes(33),
  Secp256r1: bcs.bytes(33),
  ZkLogin: bcs.byteVector(),
  Passkey: bcs.bytes(33),
  MLDSA65: bcs.bytes(1952)
});
var MultiSigPkMap = bcs.struct("MultiSigPkMap", {
  pubKey: PublicKey,
  weight: bcs.u8()
});
var MultiSigPublicKey = bcs.struct("MultiSigPublicKey", {
  pk_map: bcs.vector(MultiSigPkMap),
  threshold: bcs.u16()
});
var MultiSig = bcs.struct("MultiSig", {
  sigs: bcs.vector(CompressedSignature),
  bitmap: bcs.u16(),
  multisig_pk: MultiSigPublicKey
});
var base64String = bcs.byteVector().transform({
  input: (val) => typeof val === "string" ? fromBase64(val) : val,
  output: (val) => toBase64(val)
});
var PasskeyAuthenticator = bcs.struct("PasskeyAuthenticator", {
  authenticatorData: bcs.byteVector(),
  clientDataJson: bcs.string(),
  userSignature: bcs.byteVector()
});
var MoveObjectType = bcs.enum("MoveObjectType", {
  Other: StructTag,
  GasCoin: null,
  StakedSui: null,
  Coin: TypeTag,
  AccumulatorBalanceWrapper: null
});
var TypeOrigin = bcs.struct("TypeOrigin", {
  moduleName: bcs.string(),
  datatypeName: bcs.string(),
  package: Address
});
var UpgradeInfo = bcs.struct("UpgradeInfo", {
  upgradedId: Address,
  upgradedVersion: bcs.u64()
});
var MovePackage = bcs.struct("MovePackage", {
  id: Address,
  version: bcs.u64(),
  moduleMap: bcs.map(bcs.string(), bcs.byteVector()),
  typeOriginTable: bcs.vector(TypeOrigin),
  linkageTable: bcs.map(Address, UpgradeInfo)
});
var MoveObject = bcs.struct("MoveObject", {
  type: MoveObjectType,
  hasPublicTransfer: bcs.bool(),
  version: bcs.u64(),
  contents: bcs.byteVector()
});
var Data = bcs.enum("Data", {
  Move: MoveObject,
  Package: MovePackage
});
var ObjectInner = bcs.struct("ObjectInner", {
  data: Data,
  owner: Owner,
  previousTransaction: ObjectDigest,
  storageRebate: bcs.u64()
});

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/bcs/transactions.mjs
import { bcs as bcs2 } from "@mysten/bcs";
var ChangeEpoch = bcs2.struct("ChangeEpoch", {
  epoch: bcs2.u64(),
  protocolVersion: bcs2.u64(),
  storageCharge: bcs2.u64(),
  computationCharge: bcs2.u64(),
  storageRebate: bcs2.u64(),
  nonRefundableStorageFee: bcs2.u64(),
  epochStartTimestampMs: bcs2.u64(),
  systemPackages: bcs2.vector(bcs2.tuple([
    bcs2.u64(),
    bcs2.vector(bcs2.byteVector()),
    bcs2.vector(Address)
  ]))
});
var GenesisObject = bcs2.enum("GenesisObject", { RawObject: bcs2.struct("RawObject", {
  data: Data,
  owner: Owner
}) });
var GenesisTransaction = bcs2.struct("GenesisTransaction", { objects: bcs2.vector(GenesisObject) });
var ConsensusCommitPrologue = bcs2.struct("ConsensusCommitPrologue", {
  epoch: bcs2.u64(),
  round: bcs2.u64(),
  commitTimestampMs: bcs2.u64()
});
var ConsensusCommitPrologueV2 = bcs2.struct("ConsensusCommitPrologueV2", {
  epoch: bcs2.u64(),
  round: bcs2.u64(),
  commitTimestampMs: bcs2.u64(),
  consensusCommitDigest: ObjectDigest
});
var ConsensusDeterminedVersionAssignments = bcs2.enum("ConsensusDeterminedVersionAssignments", {
  CancelledTransactions: bcs2.vector(bcs2.tuple([ObjectDigest, bcs2.vector(bcs2.tuple([Address, bcs2.u64()]))])),
  CancelledTransactionsV2: bcs2.vector(bcs2.tuple([ObjectDigest, bcs2.vector(bcs2.tuple([bcs2.tuple([Address, bcs2.u64()]), bcs2.u64()]))]))
});
var ConsensusCommitPrologueV3 = bcs2.struct("ConsensusCommitPrologueV3", {
  epoch: bcs2.u64(),
  round: bcs2.u64(),
  subDagIndex: bcs2.option(bcs2.u64()),
  commitTimestampMs: bcs2.u64(),
  consensusCommitDigest: ObjectDigest,
  consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments
});
var ConsensusCommitPrologueV4 = bcs2.struct("ConsensusCommitPrologueV4", {
  epoch: bcs2.u64(),
  round: bcs2.u64(),
  subDagIndex: bcs2.option(bcs2.u64()),
  commitTimestampMs: bcs2.u64(),
  consensusCommitDigest: ObjectDigest,
  consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments,
  additionalStateDigest: ObjectDigest
});
var ActiveJwk = bcs2.struct("ActiveJwk", {
  jwkId: bcs2.struct("JwkId", {
    iss: bcs2.string(),
    kid: bcs2.string()
  }),
  jwk: bcs2.struct("JWK", {
    kty: bcs2.string(),
    e: bcs2.string(),
    n: bcs2.string(),
    alg: bcs2.string()
  }),
  epoch: bcs2.u64()
});
var AuthenticatorStateUpdate = bcs2.struct("AuthenticatorStateUpdate", {
  epoch: bcs2.u64(),
  round: bcs2.u64(),
  newActiveJwks: bcs2.vector(ActiveJwk),
  authenticatorObjInitialSharedVersion: bcs2.u64()
});
var RandomnessStateUpdate = bcs2.struct("RandomnessStateUpdate", {
  epoch: bcs2.u64(),
  randomnessRound: bcs2.u64(),
  randomBytes: bcs2.byteVector(),
  randomnessObjInitialSharedVersion: bcs2.u64()
});
var AuthenticatorStateExpire = bcs2.struct("AuthenticatorStateExpire", {
  minEpoch: bcs2.u64(),
  authenticatorObjInitialSharedVersion: bcs2.u64()
});
var ExecutionTimeObservationKey = bcs2.enum("ExecutionTimeObservationKey", {
  MoveEntryPoint: bcs2.struct("MoveEntryPoint", {
    package: Address,
    module: bcs2.string(),
    function: bcs2.string(),
    typeArguments: bcs2.vector(TypeTag)
  }),
  TransferObjects: null,
  SplitCoins: null,
  MergeCoins: null,
  Publish: null,
  MakeMoveVec: null,
  Upgrade: null
});
var StoredExecutionTimeObservations = bcs2.enum("StoredExecutionTimeObservations", { V1: bcs2.vector(bcs2.tuple([ExecutionTimeObservationKey, bcs2.vector(bcs2.tuple([bcs2.byteVector(), bcs2.struct("Duration", {
  secs: bcs2.u64(),
  nanos: bcs2.u32()
})]))])) });
var WriteAccumulatorStorageCost = bcs2.struct("WriteAccumulatorStorageCost", { storageCost: bcs2.u64() });
var EndOfEpochTransactionKind = bcs2.enum("EndOfEpochTransactionKind", {
  ChangeEpoch,
  AuthenticatorStateCreate: null,
  AuthenticatorStateExpire,
  RandomnessStateCreate: null,
  DenyListStateCreate: null,
  BridgeStateCreate: ObjectDigest,
  BridgeCommitteeInit: bcs2.u64(),
  StoreExecutionTimeObservations: StoredExecutionTimeObservations,
  AccumulatorRootCreate: null,
  CoinRegistryCreate: null,
  DisplayRegistryCreate: null,
  AddressAliasStateCreate: null,
  WriteAccumulatorStorageCost,
  ForwardingAddressRegistryCreate: null
});
var TransactionKind = bcs2.enum("TransactionKind", {
  ProgrammableTransaction,
  ChangeEpoch,
  Genesis: GenesisTransaction,
  ConsensusCommitPrologue,
  AuthenticatorStateUpdate,
  EndOfEpochTransaction: bcs2.vector(EndOfEpochTransactionKind),
  RandomnessStateUpdate,
  ConsensusCommitPrologueV2,
  ConsensusCommitPrologueV3,
  ConsensusCommitPrologueV4,
  ProgrammableSystemTransaction: ProgrammableTransaction
});
var TransactionDataV1 = bcs2.struct("TransactionDataV1", {
  kind: TransactionKind,
  sender: Address,
  gasData: GasData,
  expiration: TransactionExpiration
});
var TransactionData = bcs2.enum("TransactionData", { V1: TransactionDataV1 });
var SenderSignedTransaction = bcs2.struct("SenderSignedTransaction", {
  intentMessage: IntentMessage(TransactionData),
  txSignatures: bcs2.vector(base64String)
});
var SenderSignedData = bcs2.vector(SenderSignedTransaction, { name: "SenderSignedData" });

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/bcs/effects.mjs
import { bcs as bcs3 } from "@mysten/bcs";
var PackageUpgradeError = bcs3.enum("PackageUpgradeError", {
  UnableToFetchPackage: bcs3.struct("UnableToFetchPackage", { packageId: Address }),
  NotAPackage: bcs3.struct("NotAPackage", { objectId: Address }),
  IncompatibleUpgrade: null,
  DigestDoesNotMatch: bcs3.struct("DigestDoesNotMatch", { digest: bcs3.byteVector() }),
  UnknownUpgradePolicy: bcs3.struct("UnknownUpgradePolicy", { policy: bcs3.u8() }),
  PackageIDDoesNotMatch: bcs3.struct("PackageIDDoesNotMatch", {
    packageId: Address,
    ticketId: Address
  })
});
var ModuleId = bcs3.struct("ModuleId", {
  address: Address,
  name: bcs3.string()
});
var MoveLocation = bcs3.struct("MoveLocation", {
  module: ModuleId,
  function: bcs3.u16(),
  instruction: bcs3.u16(),
  functionName: bcs3.option(bcs3.string())
});
var CommandArgumentError = bcs3.enum("CommandArgumentError", {
  TypeMismatch: null,
  InvalidBCSBytes: null,
  InvalidUsageOfPureArg: null,
  InvalidArgumentToPrivateEntryFunction: null,
  IndexOutOfBounds: bcs3.struct("IndexOutOfBounds", { idx: bcs3.u16() }),
  SecondaryIndexOutOfBounds: bcs3.struct("SecondaryIndexOutOfBounds", {
    resultIdx: bcs3.u16(),
    secondaryIdx: bcs3.u16()
  }),
  InvalidResultArity: bcs3.struct("InvalidResultArity", { resultIdx: bcs3.u16() }),
  InvalidGasCoinUsage: null,
  InvalidValueUsage: null,
  InvalidObjectByValue: null,
  InvalidObjectByMutRef: null,
  SharedObjectOperationNotAllowed: null,
  InvalidArgumentArity: null,
  InvalidTransferObject: null,
  InvalidMakeMoveVecNonObjectArgument: null,
  ArgumentWithoutValue: null,
  CannotMoveBorrowedValue: null,
  CannotWriteToExtendedReference: null,
  InvalidReferenceArgument: null,
  InvalidTxContext: null
});
var TypeArgumentError = bcs3.enum("TypeArgumentError", {
  TypeNotFound: null,
  ConstraintNotSatisfied: null
});
var ExecutionFailureStatus = bcs3.enum("ExecutionFailureStatus", {
  InsufficientGas: null,
  InvalidGasObject: null,
  InvariantViolation: null,
  FeatureNotYetSupported: null,
  MoveObjectTooBig: bcs3.struct("MoveObjectTooBig", {
    objectSize: bcs3.u64(),
    maxObjectSize: bcs3.u64()
  }),
  MovePackageTooBig: bcs3.struct("MovePackageTooBig", {
    objectSize: bcs3.u64(),
    maxObjectSize: bcs3.u64()
  }),
  CircularObjectOwnership: bcs3.struct("CircularObjectOwnership", { object: Address }),
  InsufficientCoinBalance: null,
  CoinBalanceOverflow: null,
  PublishErrorNonZeroAddress: null,
  SuiMoveVerificationError: null,
  MovePrimitiveRuntimeError: bcs3.option(MoveLocation),
  MoveAbort: bcs3.tuple([MoveLocation, bcs3.u64()]),
  VMVerificationOrDeserializationError: null,
  VMInvariantViolation: null,
  FunctionNotFound: null,
  ArityMismatch: null,
  TypeArityMismatch: null,
  NonEntryFunctionInvoked: null,
  CommandArgumentError: bcs3.struct("CommandArgumentError", {
    argIdx: bcs3.u16(),
    kind: CommandArgumentError
  }),
  TypeArgumentError: bcs3.struct("TypeArgumentError", {
    argumentIdx: bcs3.u16(),
    kind: TypeArgumentError
  }),
  UnusedValueWithoutDrop: bcs3.struct("UnusedValueWithoutDrop", {
    resultIdx: bcs3.u16(),
    secondaryIdx: bcs3.u16()
  }),
  InvalidPublicFunctionReturnType: bcs3.struct("InvalidPublicFunctionReturnType", { idx: bcs3.u16() }),
  InvalidTransferObject: null,
  EffectsTooLarge: bcs3.struct("EffectsTooLarge", {
    currentSize: bcs3.u64(),
    maxSize: bcs3.u64()
  }),
  PublishUpgradeMissingDependency: null,
  PublishUpgradeDependencyDowngrade: null,
  PackageUpgradeError: bcs3.struct("PackageUpgradeError", { upgradeError: PackageUpgradeError }),
  WrittenObjectsTooLarge: bcs3.struct("WrittenObjectsTooLarge", {
    currentSize: bcs3.u64(),
    maxSize: bcs3.u64()
  }),
  CertificateDenied: null,
  SuiMoveVerificationTimedout: null,
  SharedObjectOperationNotAllowed: null,
  InputObjectDeleted: null,
  ExecutionCancelledDueToSharedObjectCongestion: bcs3.struct("ExecutionCancelledDueToSharedObjectCongestion", { congested_objects: bcs3.vector(Address) }),
  AddressDeniedForCoin: bcs3.struct("AddressDeniedForCoin", {
    address: Address,
    coinType: bcs3.string()
  }),
  CoinTypeGlobalPause: bcs3.struct("CoinTypeGlobalPause", { coinType: bcs3.string() }),
  ExecutionCancelledDueToRandomnessUnavailable: null,
  MoveVectorElemTooBig: bcs3.struct("MoveVectorElemTooBig", {
    valueSize: bcs3.u64(),
    maxScaledSize: bcs3.u64()
  }),
  MoveRawValueTooBig: bcs3.struct("MoveRawValueTooBig", {
    valueSize: bcs3.u64(),
    maxScaledSize: bcs3.u64()
  }),
  InvalidLinkage: null,
  InsufficientBalanceForWithdraw: null,
  NonExclusiveWriteInputObjectModified: bcs3.struct("NonExclusiveWriteInputObjectModified", { id: Address })
});
var ExecutionStatus = bcs3.enum("ExecutionStatus", {
  Success: null,
  Failure: bcs3.struct("Failure", {
    error: ExecutionFailureStatus,
    command: bcs3.option(bcs3.u64())
  })
});
var GasCostSummary = bcs3.struct("GasCostSummary", {
  computationCost: bcs3.u64(),
  storageCost: bcs3.u64(),
  storageRebate: bcs3.u64(),
  nonRefundableStorageFee: bcs3.u64()
});
var TransactionEffectsV1 = bcs3.struct("TransactionEffectsV1", {
  status: ExecutionStatus,
  executedEpoch: bcs3.u64(),
  gasUsed: GasCostSummary,
  modifiedAtVersions: bcs3.vector(bcs3.tuple([Address, bcs3.u64()])),
  sharedObjects: bcs3.vector(SuiObjectRef),
  transactionDigest: ObjectDigest,
  created: bcs3.vector(bcs3.tuple([SuiObjectRef, Owner])),
  mutated: bcs3.vector(bcs3.tuple([SuiObjectRef, Owner])),
  unwrapped: bcs3.vector(bcs3.tuple([SuiObjectRef, Owner])),
  deleted: bcs3.vector(SuiObjectRef),
  unwrappedThenDeleted: bcs3.vector(SuiObjectRef),
  wrapped: bcs3.vector(SuiObjectRef),
  gasObject: bcs3.tuple([SuiObjectRef, Owner]),
  eventsDigest: bcs3.option(ObjectDigest),
  dependencies: bcs3.vector(ObjectDigest)
});
var VersionDigest = bcs3.tuple([bcs3.u64(), ObjectDigest]);
var ObjectIn = bcs3.enum("ObjectIn", {
  NotExist: null,
  Exist: bcs3.tuple([VersionDigest, Owner])
});
var AccumulatorAddress = bcs3.struct("AccumulatorAddress", {
  address: Address,
  ty: TypeTag
});
var AccumulatorOperation = bcs3.enum("AccumulatorOperation", {
  Merge: null,
  Split: null
});
var AccumulatorValue = bcs3.enum("AccumulatorValue", {
  Integer: bcs3.u64(),
  IntegerTuple: bcs3.tuple([bcs3.u64(), bcs3.u64()]),
  EventDigest: bcs3.vector(bcs3.tuple([bcs3.u64(), ObjectDigest]))
});
var AccumulatorWriteV1 = bcs3.struct("AccumulatorWriteV1", {
  address: AccumulatorAddress,
  operation: AccumulatorOperation,
  value: AccumulatorValue
});
var ObjectOut = bcs3.enum("ObjectOut", {
  NotExist: null,
  ObjectWrite: bcs3.tuple([ObjectDigest, Owner]),
  PackageWrite: VersionDigest,
  AccumulatorWriteV1
});
var IDOperation = bcs3.enum("IDOperation", {
  None: null,
  Created: null,
  Deleted: null
});
var EffectsObjectChange = bcs3.struct("EffectsObjectChange", {
  inputState: ObjectIn,
  outputState: ObjectOut,
  idOperation: IDOperation
});
var UnchangedConsensusKind = bcs3.enum("UnchangedConsensusKind", {
  ReadOnlyRoot: VersionDigest,
  MutateConsensusStreamEnded: bcs3.u64(),
  ReadConsensusStreamEnded: bcs3.u64(),
  Cancelled: bcs3.u64(),
  PerEpochConfig: null
});
var TransactionEffectsV2 = bcs3.struct("TransactionEffectsV2", {
  status: ExecutionStatus,
  executedEpoch: bcs3.u64(),
  gasUsed: GasCostSummary,
  transactionDigest: ObjectDigest,
  gasObjectIndex: bcs3.option(bcs3.u32()),
  eventsDigest: bcs3.option(ObjectDigest),
  dependencies: bcs3.vector(ObjectDigest),
  lamportVersion: bcs3.u64(),
  changedObjects: bcs3.vector(bcs3.tuple([Address, EffectsObjectChange])),
  unchangedConsensusObjects: bcs3.vector(bcs3.tuple([Address, UnchangedConsensusKind])),
  auxDataDigest: bcs3.option(ObjectDigest)
});
var TransactionEffects = bcs3.enum("TransactionEffects", {
  V1: TransactionEffectsV1,
  V2: TransactionEffectsV2
});

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/bcs/index.mjs
import { BcsEnum, BcsStruct, BcsTuple, BcsType, bcs as bcs4, compareBcsBytes } from "@mysten/bcs";
var suiBcs = {
  ...bcs4,
  U8: bcs4.u8(),
  U16: bcs4.u16(),
  U32: bcs4.u32(),
  U64: bcs4.u64(),
  U128: bcs4.u128(),
  U256: bcs4.u256(),
  ULEB128: bcs4.uleb128(),
  Bool: bcs4.bool(),
  String: bcs4.string(),
  Address,
  AppId,
  Argument,
  CallArg,
  Command,
  CompressedSignature,
  Data,
  GasData,
  Intent,
  IntentMessage,
  IntentScope,
  IntentVersion,
  MoveObject,
  MoveObjectType,
  MovePackage,
  MultiSig,
  MultiSigPkMap,
  MultiSigPublicKey,
  Object: ObjectInner,
  ObjectArg,
  ObjectDigest,
  Owner,
  PasskeyAuthenticator,
  ProgrammableMoveCall,
  ProgrammableTransaction,
  PublicKey,
  SenderSignedData,
  SenderSignedTransaction,
  SharedObjectRef,
  StructTag,
  SuiObjectRef,
  TransactionData,
  TransactionDataV1,
  TransactionEffects,
  TransactionExpiration,
  TransactionKind,
  TypeOrigin,
  TypeTag,
  UpgradeInfo
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/version.mjs
var PACKAGE_VERSION = "2.37.0";

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/client/mvr.mjs
import { DataLoader, chunk } from "@mysten/utils";
var NAME_SEPARATOR2 = "/";
var MVR_API_HEADER = { "Mvr-Source": `@mysten/sui@${PACKAGE_VERSION}` };
var MvrClient = class {
  #cache;
  #url;
  #pageSize;
  #overrides;
  constructor({ cache, url, pageSize = 50, overrides }) {
    this.#cache = cache;
    this.#url = url;
    this.#pageSize = pageSize;
    this.#overrides = {
      packages: overrides?.packages,
      types: overrides?.types
    };
    validateOverrides(this.#overrides);
  }
  get #mvrPackageDataLoader() {
    return this.#cache.readSync(["#mvrPackageDataLoader", this.#url ?? ""], () => {
      const loader = new DataLoader(async (packages) => {
        if (!this.#url) throw new Error(`MVR Api URL is not set for the current client (resolving ${packages.join(", ")})`);
        const resolved = await this.#resolvePackages(packages);
        return packages.map((pkg) => resolved[pkg] ?? /* @__PURE__ */ new Error(`Failed to resolve package: ${pkg}`));
      });
      const overrides = this.#overrides?.packages;
      if (overrides) for (const [pkg, id] of Object.entries(overrides)) loader.prime(pkg, id);
      return loader;
    });
  }
  get #mvrTypeDataLoader() {
    return this.#cache.readSync(["#mvrTypeDataLoader", this.#url ?? ""], () => {
      const loader = new DataLoader(async (types) => {
        if (!this.#url) throw new Error(`MVR Api URL is not set for the current client (resolving ${types.join(", ")})`);
        const resolved = await this.#resolveTypes(types);
        return types.map((type) => resolved[type] ?? /* @__PURE__ */ new Error(`Failed to resolve type: ${type}`));
      });
      const overrides = this.#overrides?.types;
      if (overrides) for (const [type, id] of Object.entries(overrides)) loader.prime(type, id);
      return loader;
    });
  }
  async #resolvePackages(packages) {
    if (packages.length === 0) return {};
    const batches = chunk(packages, this.#pageSize);
    const results = {};
    await Promise.all(batches.map(async (batch) => {
      const data = await this.#fetch("/v1/resolution/bulk", { names: batch });
      if (!data?.resolution) return;
      for (const pkg of Object.keys(data?.resolution)) {
        const pkgData = data.resolution[pkg]?.package_id;
        if (!pkgData) continue;
        results[pkg] = pkgData;
      }
    }));
    return results;
  }
  async #resolveTypes(types) {
    if (types.length === 0) return {};
    const batches = chunk(types, this.#pageSize);
    const results = {};
    await Promise.all(batches.map(async (batch) => {
      const data = await this.#fetch("/v1/struct-definition/bulk", { types: batch });
      if (!data?.resolution) return;
      for (const type of Object.keys(data?.resolution)) {
        const typeData = data.resolution[type]?.type_tag;
        if (!typeData) continue;
        results[type] = typeData;
      }
    }));
    return results;
  }
  async #fetch(url, body) {
    if (!this.#url) throw new Error("MVR Api URL is not set for the current client");
    const response2 = await fetch(`${this.#url}${url}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...MVR_API_HEADER
      },
      body: JSON.stringify(body)
    });
    if (!response2.ok) {
      const errorBody = await response2.json().catch(() => ({}));
      throw new Error(`Failed to resolve types: ${errorBody?.message}`);
    }
    return response2.json();
  }
  async resolvePackage({ package: name, signal }) {
    signal?.throwIfAborted();
    if (!hasMvrName(name)) return { package: name };
    return { package: await raceSignal(this.#mvrPackageDataLoader.load(name), signal) };
  }
  async resolveType({ type, signal }) {
    signal?.throwIfAborted();
    if (!hasMvrName(type)) return { type };
    const mvrTypes = [...extractMvrTypes(type)];
    const resolvedTypes = await raceSignal(this.#mvrTypeDataLoader.loadMany(mvrTypes), signal);
    const typeMap = {};
    for (let i = 0; i < mvrTypes.length; i++) {
      const resolvedType = resolvedTypes[i];
      if (resolvedType instanceof Error) throw resolvedType;
      typeMap[mvrTypes[i]] = resolvedType;
    }
    return { type: replaceMvrNames(type, typeMap) };
  }
  async resolve({ types = [], packages = [], signal }) {
    signal?.throwIfAborted();
    const mvrTypes = /* @__PURE__ */ new Set();
    for (const type of types ?? []) extractMvrTypes(type, mvrTypes);
    const typesArray = [...mvrTypes];
    const [resolvedTypes, resolvedPackages] = await raceSignal(Promise.all([typesArray.length > 0 ? this.#mvrTypeDataLoader.loadMany(typesArray) : [], packages.length > 0 ? this.#mvrPackageDataLoader.loadMany(packages) : []]), signal);
    const typeMap = { ...this.#overrides?.types };
    for (const [i, type] of typesArray.entries()) {
      const resolvedType = resolvedTypes[i];
      if (resolvedType instanceof Error) throw resolvedType;
      typeMap[type] = resolvedType;
    }
    const replacedTypes = {};
    for (const type of types ?? []) replacedTypes[type] = { type: replaceMvrNames(type, typeMap) };
    const replacedPackages = {};
    for (const [i, pkg] of (packages ?? []).entries()) {
      const resolvedPkg = this.#overrides?.packages?.[pkg] ?? resolvedPackages[i];
      if (resolvedPkg instanceof Error) throw resolvedPkg;
      replacedPackages[pkg] = { package: resolvedPkg };
    }
    return {
      types: replacedTypes,
      packages: replacedPackages
    };
  }
};
function validateOverrides(overrides) {
  if (overrides?.packages) for (const [pkg, id] of Object.entries(overrides.packages)) {
    if (!isValidNamedPackage(pkg)) throw new Error(`Invalid package name: ${pkg}`);
    if (!isValidSuiAddress(normalizeSuiAddress(id))) throw new Error(`Invalid package ID: ${id}`);
  }
  if (overrides?.types) for (const [type, val] of Object.entries(overrides.types)) {
    if (parseStructTag(type).typeParams.length > 0) throw new Error("Type overrides must be first-level only. If you want to supply generic types, just pass each type individually.");
    if (!isValidSuiAddress(parseStructTag(val).address)) throw new Error(`Invalid type: ${val}`);
  }
}
function extractMvrTypes(type, types = /* @__PURE__ */ new Set()) {
  if (typeof type === "string" && !hasMvrName(type)) return types;
  if (typeof type === "string" && type.startsWith("vector<") && type.endsWith(">")) return extractMvrTypes(type.slice(7, -1), types);
  const tag = isStructTag(type) ? type : parseStructTag(type);
  if (hasMvrName(tag.address)) types.add(`${tag.address}::${tag.module}::${tag.name}`);
  for (const param of tag.typeParams) extractMvrTypes(param, types);
  return types;
}
function replaceMvrNames(tag, typeCache) {
  if (typeof tag === "string" && !tag.includes("::")) return tag;
  if (typeof tag === "string" && tag.startsWith("vector<") && tag.endsWith(">")) return `vector<${replaceMvrNames(tag.slice(7, -1), typeCache)}>`;
  const type = isStructTag(tag) ? tag : parseStructTag(tag);
  const cacheHit = typeCache[`${type.address}::${type.module}::${type.name}`];
  return normalizeStructTag({
    ...type,
    address: cacheHit ? cacheHit.split("::")[0] : type.address,
    typeParams: type.typeParams.map((param) => replaceMvrNames(param, typeCache))
  });
}
function hasMvrName(nameOrType) {
  return nameOrType.includes(NAME_SEPARATOR2) || nameOrType.includes("@") || nameOrType.includes(".sui");
}
function raceSignal(promise, signal) {
  if (!signal) return promise;
  if (signal.aborted) return Promise.reject(signal.reason);
  return new Promise((resolve, reject) => {
    const onAbort = () => reject(signal.reason);
    signal.addEventListener("abort", onAbort, { once: true });
    promise.then(resolve, reject).finally(() => {
      signal.removeEventListener("abort", onAbort);
    });
  });
}
function isStructTag(type) {
  return typeof type === "object" && "address" in type && "module" in type && "name" in type && "typeParams" in type;
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/client/cache.mjs
var ClientCache = class ClientCache2 {
  #prefix;
  #cache;
  constructor({ prefix, cache } = {}) {
    this.#prefix = prefix ?? [];
    this.#cache = cache ?? /* @__PURE__ */ new Map();
  }
  read(key, load) {
    const cacheKey = [this.#prefix, ...key].join(":");
    if (this.#cache.has(cacheKey)) return this.#cache.get(cacheKey);
    const result = load();
    this.#cache.set(cacheKey, result);
    if (typeof result === "object" && result !== null && "then" in result) return Promise.resolve(result).then((v) => {
      this.#cache.set(cacheKey, v);
      return v;
    }).catch((err) => {
      this.#cache.delete(cacheKey);
      throw err;
    });
    return result;
  }
  readSync(key, load) {
    const cacheKey = [this.#prefix, ...key].join(":");
    if (this.#cache.has(cacheKey)) return this.#cache.get(cacheKey);
    const result = load();
    this.#cache.set(cacheKey, result);
    return result;
  }
  clear(prefix) {
    const prefixKey = [...this.#prefix, ...prefix ?? []].join(":");
    if (!prefixKey) {
      this.#cache.clear();
      return;
    }
    for (const key of this.#cache.keys()) if (key.startsWith(prefixKey)) this.#cache.delete(key);
  }
  scope(prefix) {
    return new ClientCache2({
      prefix: [...this.#prefix, ...Array.isArray(prefix) ? prefix : [prefix]],
      cache: this.#cache
    });
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/client/client.mjs
var BaseClient = class {
  constructor({ network, base, cache = base?.cache ?? new ClientCache() }) {
    this.network = network;
    this.base = base ?? this;
    this.cache = cache;
  }
  $extend(...registrations) {
    const extensions = Object.fromEntries(registrations.map((registration) => {
      return [registration.name, registration.register(this)];
    }));
    const methodCache = /* @__PURE__ */ new Map();
    return new Proxy(this, { get(target, prop, receiver) {
      if (typeof prop === "string" && prop in extensions) return extensions[prop];
      const value = Reflect.get(target, prop, receiver);
      if (typeof value === "function") {
        if (prop === "$extend") return value.bind(receiver);
        if (!methodCache.has(prop)) methodCache.set(prop, value.bind(target));
        return methodCache.get(prop);
      }
      return value;
    } });
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/utils/dynamic-fields.mjs
import { toHex as toHex2 } from "@mysten/bcs";
import { blake2b } from "@noble/hashes/blake2.js";
function deriveDynamicFieldID(parentId, typeTag, key) {
  const address = suiBcs.Address.serialize(parentId).toBytes();
  const tag = suiBcs.TypeTag.serialize(typeTag).toBytes();
  const keyLength = suiBcs.u64().serialize(key.length).toBytes();
  const hash3 = blake2b.create({ dkLen: 32 });
  hash3.update(new Uint8Array([240]));
  hash3.update(address);
  hash3.update(keyLength);
  hash3.update(key);
  hash3.update(tag);
  return `0x${toHex2(hash3.digest().slice(0, 32))}`;
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/client/core.mjs
var DEFAULT_MVR_URLS = {
  mainnet: "https://mainnet.mvr.mystenlabs.com",
  testnet: "https://testnet.mvr.mystenlabs.com"
};
var CoreClient = class extends BaseClient {
  constructor(options) {
    super(options);
    this.core = this;
    this.mvr = new MvrClient({
      cache: this.cache.scope("core.mvr"),
      url: options.mvr?.url ?? DEFAULT_MVR_URLS[this.network],
      pageSize: options.mvr?.pageSize,
      overrides: options.mvr?.overrides
    });
  }
  async getObject(options) {
    const { objectId } = options;
    const { objects: [result] } = await this.getObjects({
      objectIds: [objectId],
      signal: options.signal,
      include: options.include
    });
    if (result instanceof Error) throw result;
    return { object: result };
  }
  async getDynamicField(options) {
    const normalizedNameType = TypeTagSerializer.parseFromStr((await this.core.mvr.resolveType({
      type: options.name.type,
      signal: options.signal
    })).type);
    const fieldId = deriveDynamicFieldID(options.parentId, normalizedNameType, options.name.bcs);
    const { objects: [fieldObject] } = await this.getObjects({
      objectIds: [fieldId],
      signal: options.signal,
      include: {
        previousTransaction: true,
        content: true
      }
    });
    if (fieldObject instanceof Error) throw fieldObject;
    const fieldType = parseStructTag(fieldObject.type);
    const content = await fieldObject.content;
    const nameTypeParam = fieldType.typeParams[0];
    const isDynamicObject = typeof nameTypeParam !== "string" && nameTypeParam.module === "dynamic_object_field" && nameTypeParam.name === "Wrapper";
    const valueBcs = content.slice(SUI_ADDRESS_LENGTH + options.name.bcs.length);
    const valueType = typeof fieldType.typeParams[1] === "string" ? fieldType.typeParams[1] : normalizeStructTag(fieldType.typeParams[1]);
    return { dynamicField: {
      $kind: isDynamicObject ? "DynamicObject" : "DynamicField",
      fieldId: fieldObject.objectId,
      digest: fieldObject.digest,
      version: fieldObject.version,
      type: fieldObject.type,
      previousTransaction: fieldObject.previousTransaction,
      name: {
        type: typeof nameTypeParam === "string" ? nameTypeParam : normalizeStructTag(nameTypeParam),
        bcs: options.name.bcs
      },
      value: {
        type: valueType,
        bcs: valueBcs
      },
      childId: isDynamicObject ? suiBcs.Address.parse(valueBcs) : void 0
    } };
  }
  async getDynamicObjectField(options) {
    const wrappedType = `0x2::dynamic_object_field::Wrapper<${(await this.core.mvr.resolveType({
      type: options.name.type,
      signal: options.signal
    })).type}>`;
    const { dynamicField } = await this.getDynamicField({
      parentId: options.parentId,
      name: {
        type: wrappedType,
        bcs: options.name.bcs
      },
      signal: options.signal
    });
    const { object: object3 } = await this.getObject({
      objectId: dynamicField.childId,
      signal: options.signal,
      include: options.include
    });
    return { object: object3 };
  }
  async waitForTransaction(options) {
    const { signal, timeout = 60 * 1e3, pollSchedule, include } = options;
    const digest = "result" in options && options.result ? (options.result.Transaction ?? options.result.FailedTransaction).digest : options.digest;
    const abortSignal = signal ? AbortSignal.any([AbortSignal.timeout(timeout), signal]) : AbortSignal.timeout(timeout);
    const abortPromise = new Promise((_, reject) => {
      abortSignal.addEventListener("abort", () => reject(abortSignal.reason));
    });
    abortPromise.catch(() => {
    });
    const schedule = pollSchedule ?? [
      0,
      300,
      600,
      1500,
      3500
    ];
    const t0 = Date.now();
    let scheduleIndex = 0;
    const lastInterval = schedule.length > 0 ? schedule[schedule.length - 1] - (schedule[schedule.length - 2] ?? 0) : 2e3;
    while (true) {
      if (scheduleIndex < schedule.length) {
        const remaining = t0 + schedule[scheduleIndex] - Date.now();
        scheduleIndex++;
        if (remaining > 0) await Promise.race([new Promise((resolve) => setTimeout(resolve, remaining)), abortPromise]);
      } else await Promise.race([new Promise((resolve) => setTimeout(resolve, lastInterval)), abortPromise]);
      abortSignal.throwIfAborted();
      try {
        return await this.getTransaction({
          digest,
          include,
          signal: abortSignal
        });
      } catch {
      }
    }
  }
  async signAndExecuteTransaction({ transaction, signer, additionalSignatures = [], ...input }) {
    let transactionBytes;
    if (transaction instanceof Uint8Array) transactionBytes = transaction;
    else {
      transaction.setSenderIfNotSet(signer.toSuiAddress());
      transactionBytes = await transaction.build({ client: this });
    }
    const { signature } = await signer.signTransaction(transactionBytes);
    return this.executeTransaction({
      transaction: transactionBytes,
      signatures: [signature, ...additionalSignatures],
      ...input
    });
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/utils/constants.mjs
var MIST_PER_SUI = BigInt(1e9);
var SUI_FRAMEWORK_ADDRESS = "0x0000000000000000000000000000000000000000000000000000000000000002";
var SUI_TYPE_ARG = `${SUI_FRAMEWORK_ADDRESS}::sui::SUI`;
var MOCKED_GAS_OBJECT_ID = "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff";

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/transactions/data/internal.mjs
import { array, boolean, check, integer, lazy, literal, nullable, nullish, number, object, optional, pipe, record, string, transform, tuple, union, unknown, variant } from "valibot";
function safeEnum(options) {
  const schemas = Object.keys(options).map((key) => object({
    [key]: options[key],
    $kind: literal(key)
  }));
  return pipe(unknown(), check((input) => unsupportedEnumVariantMessage(input, options) === void 0, ({ input, message }) => unsupportedEnumVariantMessage(input, options) ?? message), transform(addMissingEnumKind), variant("$kind", schemas));
}
function getEnumKind(input) {
  if (typeof input !== "object" || input === null) return null;
  if ("$kind" in input && typeof input.$kind === "string") return input.$kind;
  return Object.keys(input).find((key) => key !== "$kind") ?? null;
}
function addMissingEnumKind(input) {
  if (typeof input !== "object" || input === null || "$kind" in input) return input;
  const kind = getEnumKind(input);
  return kind === null ? input : {
    ...input,
    $kind: kind
  };
}
function unsupportedEnumVariantMessage(input, options) {
  const kind = getEnumKind(input);
  if (kind === null || Object.hasOwn(options, kind)) return void 0;
  return `Unsupported enum variant "${kind}". Expected one of: ${Object.keys(options).map((key) => `"${key}"`).join(", ")}.`;
}
function withKind(key, schema) {
  return pipe(object({
    ...schema.entries,
    $kind: optional(literal(key))
  }), transform((value) => ({
    ...value,
    $kind: key
  })));
}
var SuiAddress = pipe(string(), transform((value) => normalizeSuiAddress(value)), check(isValidSuiAddress));
var ObjectID = SuiAddress;
var BCSBytes = string();
var JsonU64 = pipe(union([string(), pipe(number(), integer())]), check((val) => {
  try {
    BigInt(val);
    return BigInt(val) >= 0 && BigInt(val) <= 18446744073709551615n;
  } catch {
    return false;
  }
}, "Invalid u64"));
var U32 = pipe(number(), integer(), check((val) => val >= 0 && val < 2 ** 32, "Invalid u32"));
var ObjectRefSchema = object({
  objectId: SuiAddress,
  version: JsonU64,
  digest: string()
});
var ArgumentSchema = union([
  withKind("GasCoin", object({ GasCoin: literal(true) })),
  withKind("Input", object({
    Input: pipe(number(), integer()),
    type: optional(union([
      literal("pure"),
      literal("object"),
      literal("withdrawal")
    ]))
  })),
  withKind("Result", object({ Result: pipe(number(), integer()) })),
  withKind("NestedResult", object({ NestedResult: tuple([pipe(number(), integer()), pipe(number(), integer())]) }))
]);
var GasDataSchema = object({
  budget: nullable(JsonU64),
  price: nullable(JsonU64),
  owner: nullable(SuiAddress),
  payment: nullable(array(ObjectRefSchema))
});
var StructTagSchema = object({
  address: string(),
  module: string(),
  name: string(),
  typeParams: array(string())
});
var OpenSignatureBodySchema = union([
  object({ $kind: literal("address") }),
  object({ $kind: literal("bool") }),
  object({ $kind: literal("u8") }),
  object({ $kind: literal("u16") }),
  object({ $kind: literal("u32") }),
  object({ $kind: literal("u64") }),
  object({ $kind: literal("u128") }),
  object({ $kind: literal("u256") }),
  object({ $kind: literal("unknown") }),
  object({
    $kind: literal("vector"),
    vector: lazy(() => OpenSignatureBodySchema)
  }),
  object({
    $kind: literal("datatype"),
    datatype: object({
      typeName: string(),
      typeParameters: array(lazy(() => OpenSignatureBodySchema))
    })
  }),
  object({
    $kind: literal("typeParameter"),
    index: pipe(number(), integer())
  })
]);
var OpenSignatureSchema = object({
  reference: nullable(union([
    literal("mutable"),
    literal("immutable"),
    literal("unknown")
  ])),
  body: OpenSignatureBodySchema
});
var ProgrammableMoveCallSchema = object({
  package: ObjectID,
  module: string(),
  function: string(),
  typeArguments: array(string()),
  arguments: array(ArgumentSchema),
  _argumentTypes: optional(nullable(array(OpenSignatureSchema)))
});
var $Intent = object({
  name: string(),
  inputs: record(string(), union([ArgumentSchema, array(ArgumentSchema)])),
  data: record(string(), unknown())
});
var CommandSchema = safeEnum({
  MoveCall: ProgrammableMoveCallSchema,
  TransferObjects: object({
    objects: array(ArgumentSchema),
    address: ArgumentSchema
  }),
  SplitCoins: object({
    coin: ArgumentSchema,
    amounts: array(ArgumentSchema)
  }),
  MergeCoins: object({
    destination: ArgumentSchema,
    sources: array(ArgumentSchema)
  }),
  Publish: object({
    modules: array(BCSBytes),
    dependencies: array(ObjectID)
  }),
  MakeMoveVec: object({
    type: nullable(string()),
    elements: array(ArgumentSchema)
  }),
  Upgrade: object({
    modules: array(BCSBytes),
    dependencies: array(ObjectID),
    package: ObjectID,
    ticket: ArgumentSchema
  }),
  $Intent
});
var ObjectArgSchema = safeEnum({
  ImmOrOwnedObject: ObjectRefSchema,
  SharedObject: object({
    objectId: ObjectID,
    initialSharedVersion: JsonU64,
    mutable: boolean()
  }),
  Receiving: ObjectRefSchema
});
var ReservationSchema = safeEnum({ MaxAmountU64: JsonU64 });
var WithdrawalTypeArgSchema = safeEnum({ Balance: string() });
var WithdrawFromSchema = safeEnum({
  Sender: literal(true),
  Sponsor: literal(true),
  SenderAllowance: object({
    funder: SuiAddress,
    allowance: ObjectID
  })
});
var FundsWithdrawalArgSchema = object({
  reservation: ReservationSchema,
  typeArg: WithdrawalTypeArgSchema,
  withdrawFrom: WithdrawFromSchema
});
var CallArgSchema = safeEnum({
  Object: ObjectArgSchema,
  Pure: object({ bytes: BCSBytes }),
  UnresolvedPure: object({ value: unknown() }),
  UnresolvedObject: object({
    objectId: ObjectID,
    version: optional(nullable(JsonU64)),
    digest: optional(nullable(string())),
    initialSharedVersion: optional(nullable(JsonU64)),
    mutable: optional(nullable(boolean()))
  }),
  FundsWithdrawal: FundsWithdrawalArgSchema
});
var NormalizedCallArg = safeEnum({
  Object: ObjectArgSchema,
  Pure: object({ bytes: BCSBytes })
});
var ValidDuringSchema = object({
  minEpoch: nullable(JsonU64),
  maxEpoch: nullable(JsonU64),
  minTimestamp: nullable(JsonU64),
  maxTimestamp: nullable(JsonU64),
  chain: string(),
  nonce: U32
});
var AllowedProposersSchema = object({
  epoch: JsonU64,
  proposers: pipe(array(U32), check((proposers) => proposers.length > 0, "Allowed proposers must not be empty"))
});
var ValiditySchema = object({
  ...ValidDuringSchema.entries,
  allowedProposers: nullable(AllowedProposersSchema)
});
var TransactionExpiration2 = safeEnum({
  None: literal(true),
  Epoch: JsonU64,
  ValidDuring: ValidDuringSchema,
  Validity: ValiditySchema
});
var TransactionDataSchema = object({
  version: literal(2),
  sender: nullish(SuiAddress),
  expiration: nullish(TransactionExpiration2),
  gasData: GasDataSchema,
  inputs: array(CallArgSchema),
  commands: array(CommandSchema)
});

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/transactions/data/v1.mjs
import { fromBase64 as fromBase642, toBase64 as toBase642 } from "@mysten/bcs";
import { array as array2, bigint, boolean as boolean2, check as check2, integer as integer2, is, lazy as lazy2, literal as literal2, nullable as nullable2, nullish as nullish2, number as number2, object as object2, optional as optional2, parse, pipe as pipe2, string as string2, union as union2, unknown as unknown2 } from "valibot";
var ObjectRef = object2({
  digest: string2(),
  objectId: string2(),
  version: union2([
    pipe2(number2(), integer2()),
    string2(),
    bigint()
  ])
});
var ObjectArg2 = safeEnum({
  ImmOrOwned: ObjectRef,
  Shared: object2({
    objectId: ObjectID,
    initialSharedVersion: JsonU64,
    mutable: boolean2()
  }),
  Receiving: ObjectRef
});
var NormalizedCallArg2 = safeEnum({
  Object: ObjectArg2,
  Pure: array2(pipe2(number2(), integer2()))
});
var TransactionInput = union2([object2({
  kind: literal2("Input"),
  index: pipe2(number2(), integer2()),
  value: unknown2(),
  type: optional2(literal2("object"))
}), object2({
  kind: literal2("Input"),
  index: pipe2(number2(), integer2()),
  value: unknown2(),
  type: literal2("pure")
})]);
var TransactionExpiration3 = union2([
  object2({ Epoch: pipe2(number2(), integer2()) }),
  object2({ None: nullable2(literal2(true)) }),
  object2({ ValidDuring: ValidDuringSchema }),
  object2({ Validity: ValiditySchema })
]);
function expirationFromV1(expiration) {
  if (!expiration) return null;
  if ("Epoch" in expiration) return { Epoch: expiration.Epoch };
  if ("ValidDuring" in expiration) return { ValidDuring: expiration.ValidDuring };
  if ("Validity" in expiration) return { Validity: expiration.Validity };
  if ("None" in expiration) return { None: true };
  throw new Error(`Unknown transaction expiration in v1 transaction data: ${Object.keys(expiration).join(", ")}`);
}
var StringEncodedBigint = pipe2(union2([
  number2(),
  string2(),
  bigint()
]), check2((val) => {
  if (![
    "string",
    "number",
    "bigint"
  ].includes(typeof val)) return false;
  try {
    BigInt(val);
    return true;
  } catch {
    return false;
  }
}));
var TypeTag2 = union2([
  object2({ bool: nullable2(literal2(true)) }),
  object2({ u8: nullable2(literal2(true)) }),
  object2({ u64: nullable2(literal2(true)) }),
  object2({ u128: nullable2(literal2(true)) }),
  object2({ address: nullable2(literal2(true)) }),
  object2({ signer: nullable2(literal2(true)) }),
  object2({ vector: lazy2(() => TypeTag2) }),
  object2({ struct: lazy2(() => StructTag2) }),
  object2({ u16: nullable2(literal2(true)) }),
  object2({ u32: nullable2(literal2(true)) }),
  object2({ u256: nullable2(literal2(true)) })
]);
var StructTag2 = object2({
  address: string2(),
  module: string2(),
  name: string2(),
  typeParams: array2(TypeTag2)
});
var GasConfig = object2({
  budget: optional2(StringEncodedBigint),
  price: optional2(StringEncodedBigint),
  payment: optional2(array2(ObjectRef)),
  owner: optional2(string2())
});
var TransactionArgumentTypes = [
  TransactionInput,
  object2({ kind: literal2("GasCoin") }),
  object2({
    kind: literal2("Result"),
    index: pipe2(number2(), integer2())
  }),
  object2({
    kind: literal2("NestedResult"),
    index: pipe2(number2(), integer2()),
    resultIndex: pipe2(number2(), integer2())
  })
];
var TransactionArgument = union2([...TransactionArgumentTypes]);
var MoveCallTransaction = object2({
  kind: literal2("MoveCall"),
  target: pipe2(string2(), check2((target) => target.split("::").length === 3)),
  typeArguments: array2(string2()),
  arguments: array2(TransactionArgument)
});
var TransferObjectsTransaction = object2({
  kind: literal2("TransferObjects"),
  objects: array2(TransactionArgument),
  address: TransactionArgument
});
var SplitCoinsTransaction = object2({
  kind: literal2("SplitCoins"),
  coin: TransactionArgument,
  amounts: array2(TransactionArgument)
});
var MergeCoinsTransaction = object2({
  kind: literal2("MergeCoins"),
  destination: TransactionArgument,
  sources: array2(TransactionArgument)
});
var MakeMoveVecTransaction = object2({
  kind: literal2("MakeMoveVec"),
  type: union2([object2({ Some: TypeTag2 }), object2({ None: nullable2(literal2(true)) })]),
  objects: array2(TransactionArgument)
});
var TransactionType = union2([...[
  MoveCallTransaction,
  TransferObjectsTransaction,
  SplitCoinsTransaction,
  MergeCoinsTransaction,
  object2({
    kind: literal2("Publish"),
    modules: array2(array2(pipe2(number2(), integer2()))),
    dependencies: array2(string2())
  }),
  object2({
    kind: literal2("Upgrade"),
    modules: array2(array2(pipe2(number2(), integer2()))),
    dependencies: array2(string2()),
    packageId: string2(),
    ticket: TransactionArgument
  }),
  MakeMoveVecTransaction
]]);
var SerializedTransactionDataV1 = object2({
  version: literal2(1),
  sender: optional2(string2()),
  expiration: nullish2(TransactionExpiration3),
  gasConfig: GasConfig,
  inputs: array2(TransactionInput),
  transactions: array2(TransactionType)
});
function transactionDataFromV1(data) {
  return parse(TransactionDataSchema, {
    version: 2,
    sender: data.sender ?? null,
    expiration: expirationFromV1(data.expiration),
    gasData: {
      owner: data.gasConfig.owner ?? null,
      budget: data.gasConfig.budget?.toString() ?? null,
      price: data.gasConfig.price?.toString() ?? null,
      payment: data.gasConfig.payment?.map((ref) => ({
        digest: ref.digest,
        objectId: ref.objectId,
        version: ref.version.toString()
      })) ?? null
    },
    inputs: data.inputs.map((input) => {
      if (input.kind === "Input") {
        if (is(NormalizedCallArg2, input.value)) {
          const value = parse(NormalizedCallArg2, input.value);
          if (value.Object) {
            if (value.Object.ImmOrOwned) return { Object: { ImmOrOwnedObject: {
              objectId: value.Object.ImmOrOwned.objectId,
              version: String(value.Object.ImmOrOwned.version),
              digest: value.Object.ImmOrOwned.digest
            } } };
            if (value.Object.Shared) return { Object: { SharedObject: {
              mutable: value.Object.Shared.mutable ?? null,
              initialSharedVersion: value.Object.Shared.initialSharedVersion,
              objectId: value.Object.Shared.objectId
            } } };
            if (value.Object.Receiving) return { Object: { Receiving: {
              digest: value.Object.Receiving.digest,
              version: String(value.Object.Receiving.version),
              objectId: value.Object.Receiving.objectId
            } } };
            throw new Error("Invalid object input");
          }
          return { Pure: { bytes: toBase642(new Uint8Array(value.Pure)) } };
        }
        if (input.type === "object") return { UnresolvedObject: { objectId: input.value } };
        return { UnresolvedPure: { value: input.value } };
      }
      throw new Error("Invalid input");
    }),
    commands: data.transactions.map((transaction) => {
      switch (transaction.kind) {
        case "MakeMoveVec":
          return { MakeMoveVec: {
            type: "Some" in transaction.type ? TypeTagSerializer.tagToString(transaction.type.Some) : null,
            elements: transaction.objects.map((arg) => parseV1TransactionArgument(arg))
          } };
        case "MergeCoins":
          return { MergeCoins: {
            destination: parseV1TransactionArgument(transaction.destination),
            sources: transaction.sources.map((arg) => parseV1TransactionArgument(arg))
          } };
        case "MoveCall": {
          const [pkg, mod, fn] = transaction.target.split("::");
          return { MoveCall: {
            package: pkg,
            module: mod,
            function: fn,
            typeArguments: transaction.typeArguments,
            arguments: transaction.arguments.map((arg) => parseV1TransactionArgument(arg))
          } };
        }
        case "Publish":
          return { Publish: {
            modules: transaction.modules.map((mod) => toBase642(Uint8Array.from(mod))),
            dependencies: transaction.dependencies
          } };
        case "SplitCoins":
          return { SplitCoins: {
            coin: parseV1TransactionArgument(transaction.coin),
            amounts: transaction.amounts.map((arg) => parseV1TransactionArgument(arg))
          } };
        case "TransferObjects":
          return { TransferObjects: {
            objects: transaction.objects.map((arg) => parseV1TransactionArgument(arg)),
            address: parseV1TransactionArgument(transaction.address)
          } };
        case "Upgrade":
          return { Upgrade: {
            modules: transaction.modules.map((mod) => toBase642(Uint8Array.from(mod))),
            dependencies: transaction.dependencies,
            package: transaction.packageId,
            ticket: parseV1TransactionArgument(transaction.ticket)
          } };
      }
      throw new Error(`Unknown transaction ${Object.keys(transaction)}`);
    })
  });
}
function parseV1TransactionArgument(arg) {
  switch (arg.kind) {
    case "GasCoin":
      return { GasCoin: true };
    case "Result":
      return { Result: arg.index };
    case "NestedResult":
      return { NestedResult: [arg.index, arg.resultIndex] };
    case "Input":
      return { Input: arg.index };
  }
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/transactions/hash.mjs
import { blake2b as blake2b2 } from "@noble/hashes/blake2.js";
function hashTypedData(typeTag, data) {
  const typeTagBytes = Array.from(`${typeTag}::`).map((e) => e.charCodeAt(0));
  const dataWithTag = new Uint8Array(typeTagBytes.length + data.length);
  dataWithTag.set(typeTagBytes);
  dataWithTag.set(data, typeTagBytes.length);
  return blake2b2(dataWithTag, { dkLen: 32 });
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/transactions/utils.mjs
import { is as is2 } from "valibot";
function getIdFromCallArg(arg) {
  if (typeof arg === "string") return normalizeSuiAddress(arg);
  if (arg.Object) {
    if (arg.Object.ImmOrOwnedObject) return normalizeSuiAddress(arg.Object.ImmOrOwnedObject.objectId);
    if (arg.Object.Receiving) return normalizeSuiAddress(arg.Object.Receiving.objectId);
    return normalizeSuiAddress(arg.Object.SharedObject.objectId);
  }
  if (arg.UnresolvedObject) return normalizeSuiAddress(arg.UnresolvedObject.objectId);
}
function remapCommandArguments(command, inputMapping, commandMapping) {
  const remapArg = (arg) => {
    switch (arg.$kind) {
      case "Input": {
        const newInputIndex = inputMapping.get(arg.Input);
        if (newInputIndex === void 0) throw new Error(`Input ${arg.Input} not found in input mapping`);
        return {
          ...arg,
          Input: newInputIndex
        };
      }
      case "Result": {
        const newCommandIndex = commandMapping.get(arg.Result);
        if (newCommandIndex !== void 0) return {
          ...arg,
          Result: newCommandIndex
        };
        return arg;
      }
      case "NestedResult": {
        const newCommandIndex = commandMapping.get(arg.NestedResult[0]);
        if (newCommandIndex !== void 0) return {
          ...arg,
          NestedResult: [newCommandIndex, arg.NestedResult[1]]
        };
        return arg;
      }
      default:
        return arg;
    }
  };
  switch (command.$kind) {
    case "MoveCall":
      command.MoveCall.arguments = command.MoveCall.arguments.map(remapArg);
      break;
    case "TransferObjects":
      command.TransferObjects.objects = command.TransferObjects.objects.map(remapArg);
      command.TransferObjects.address = remapArg(command.TransferObjects.address);
      break;
    case "SplitCoins":
      command.SplitCoins.coin = remapArg(command.SplitCoins.coin);
      command.SplitCoins.amounts = command.SplitCoins.amounts.map(remapArg);
      break;
    case "MergeCoins":
      command.MergeCoins.destination = remapArg(command.MergeCoins.destination);
      command.MergeCoins.sources = command.MergeCoins.sources.map(remapArg);
      break;
    case "MakeMoveVec":
      command.MakeMoveVec.elements = command.MakeMoveVec.elements.map(remapArg);
      break;
    case "Upgrade":
      command.Upgrade.ticket = remapArg(command.Upgrade.ticket);
      break;
    case "$Intent": {
      const inputs = command.$Intent.inputs;
      command.$Intent.inputs = {};
      for (const [key, value] of Object.entries(inputs)) command.$Intent.inputs[key] = Array.isArray(value) ? value.map(remapArg) : remapArg(value);
      break;
    }
    case "Publish":
      break;
  }
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/transactions/TransactionData.mjs
import { toBase58 as toBase582 } from "@mysten/bcs";
import { parse as parse2 } from "valibot";
function prepareSuiAddress(address) {
  return normalizeSuiAddress(address).replace("0x", "");
}
var TransactionDataBuilder = class TransactionDataBuilder2 {
  static fromKindBytes(bytes) {
    const programmableTx = suiBcs.TransactionKind.parse(bytes).ProgrammableTransaction;
    if (!programmableTx) throw new Error("Unable to deserialize from bytes.");
    return TransactionDataBuilder2.restore({
      version: 2,
      sender: null,
      expiration: null,
      gasData: {
        budget: null,
        owner: null,
        payment: null,
        price: null
      },
      inputs: programmableTx.inputs,
      commands: programmableTx.commands
    });
  }
  static fromBytes(bytes) {
    const data = suiBcs.TransactionData.parse(bytes)?.V1;
    const programmableTx = data.kind.ProgrammableTransaction;
    if (!data || !programmableTx) throw new Error("Unable to deserialize from bytes.");
    return TransactionDataBuilder2.restore({
      version: 2,
      sender: data.sender,
      expiration: data.expiration,
      gasData: data.gasData,
      inputs: programmableTx.inputs,
      commands: programmableTx.commands
    });
  }
  static restore(data) {
    if (data.version === 2) return new TransactionDataBuilder2(parse2(TransactionDataSchema, data));
    else return new TransactionDataBuilder2(parse2(TransactionDataSchema, transactionDataFromV1(data)));
  }
  /**
  * Generate transaction digest.
  *
  * @param bytes BCS serialized transaction data
  * @returns transaction digest.
  */
  static getDigestFromBytes(bytes) {
    return toBase582(hashTypedData("TransactionData", bytes));
  }
  constructor(clone) {
    this.version = 2;
    this.sender = clone?.sender ?? null;
    this.expiration = clone?.expiration ?? null;
    this.inputs = clone?.inputs ?? [];
    this.commands = clone?.commands ?? [];
    this.gasData = clone?.gasData ?? {
      budget: null,
      price: null,
      owner: null,
      payment: null
    };
  }
  build({ maxSizeBytes = Infinity, overrides, onlyTransactionKind } = {}) {
    const inputs = this.inputs;
    const commands = this.commands;
    const kind = { ProgrammableTransaction: {
      inputs,
      commands
    } };
    if (onlyTransactionKind) return suiBcs.TransactionKind.serialize(kind, { maxSize: maxSizeBytes }).toBytes();
    const expiration = overrides?.expiration ?? this.expiration;
    const sender = overrides?.sender ?? this.sender;
    const gasData = {
      ...this.gasData,
      ...overrides?.gasData
    };
    if (!sender) throw new Error("Missing transaction sender");
    if (!gasData.budget) throw new Error("Missing gas budget");
    if (!gasData.payment) throw new Error("Missing gas payment");
    if (!gasData.price) throw new Error("Missing gas price");
    const transactionData = {
      sender: prepareSuiAddress(sender),
      expiration: expiration ? expiration : { None: true },
      gasData: {
        payment: gasData.payment,
        owner: prepareSuiAddress(this.gasData.owner ?? sender),
        price: BigInt(gasData.price),
        budget: BigInt(gasData.budget)
      },
      kind: { ProgrammableTransaction: {
        inputs,
        commands
      } }
    };
    return suiBcs.TransactionData.serialize({ V1: transactionData }, { maxSize: maxSizeBytes }).toBytes();
  }
  addInput(type, arg) {
    const index = this.inputs.length;
    this.inputs.push(arg);
    return {
      Input: index,
      type,
      $kind: "Input"
    };
  }
  getInputUses(index, fn) {
    this.mapArguments((arg, command) => {
      if (arg.$kind === "Input" && arg.Input === index) fn(arg, command);
      return arg;
    });
  }
  mapCommandArguments(index, fn) {
    const command = this.commands[index];
    switch (command.$kind) {
      case "MoveCall":
        command.MoveCall.arguments = command.MoveCall.arguments.map((arg) => fn(arg, command, index));
        break;
      case "TransferObjects":
        command.TransferObjects.objects = command.TransferObjects.objects.map((arg) => fn(arg, command, index));
        command.TransferObjects.address = fn(command.TransferObjects.address, command, index);
        break;
      case "SplitCoins":
        command.SplitCoins.coin = fn(command.SplitCoins.coin, command, index);
        command.SplitCoins.amounts = command.SplitCoins.amounts.map((arg) => fn(arg, command, index));
        break;
      case "MergeCoins":
        command.MergeCoins.destination = fn(command.MergeCoins.destination, command, index);
        command.MergeCoins.sources = command.MergeCoins.sources.map((arg) => fn(arg, command, index));
        break;
      case "MakeMoveVec":
        command.MakeMoveVec.elements = command.MakeMoveVec.elements.map((arg) => fn(arg, command, index));
        break;
      case "Upgrade":
        command.Upgrade.ticket = fn(command.Upgrade.ticket, command, index);
        break;
      case "$Intent":
        const inputs = command.$Intent.inputs;
        command.$Intent.inputs = {};
        for (const [key, value] of Object.entries(inputs)) command.$Intent.inputs[key] = Array.isArray(value) ? value.map((arg) => fn(arg, command, index)) : fn(value, command, index);
        break;
      case "Publish":
        break;
      default:
        throw new Error(`Unexpected transaction kind: ${command.$kind}`);
    }
  }
  mapArguments(fn) {
    for (const commandIndex of this.commands.keys()) this.mapCommandArguments(commandIndex, fn);
  }
  replaceCommand(index, replacement, resultIndex = index) {
    if (!Array.isArray(replacement)) {
      this.commands[index] = replacement;
      return;
    }
    const sizeDiff = replacement.length - 1;
    this.commands.splice(index, 1, ...structuredClone(replacement));
    this.mapArguments((arg, _command, commandIndex) => {
      if (commandIndex < index + replacement.length) return arg;
      if (typeof resultIndex !== "number") {
        if (arg.$kind === "Result" && arg.Result === index || arg.$kind === "NestedResult" && arg.NestedResult[0] === index) if (!("NestedResult" in arg) || arg.NestedResult[1] === 0) return parse2(ArgumentSchema, structuredClone(resultIndex));
        else throw new Error(`Cannot replace command ${index} with a specific result type: NestedResult[${index}, ${arg.NestedResult[1]}] references a nested element that cannot be mapped to the replacement result`);
      }
      switch (arg.$kind) {
        case "Result":
          if (arg.Result === index && typeof resultIndex === "number") arg.Result = resultIndex;
          if (arg.Result > index) arg.Result += sizeDiff;
          break;
        case "NestedResult":
          if (arg.NestedResult[0] === index && typeof resultIndex === "number") return {
            $kind: "NestedResult",
            NestedResult: [resultIndex, arg.NestedResult[1]]
          };
          if (arg.NestedResult[0] > index) arg.NestedResult[0] += sizeDiff;
          break;
      }
      return arg;
    });
  }
  replaceCommandWithTransaction(index, otherTransaction, result) {
    if (result.$kind !== "Result" && result.$kind !== "NestedResult") throw new Error("Result must be of kind Result or NestedResult");
    this.insertTransaction(index, otherTransaction);
    this.replaceCommand(index + otherTransaction.commands.length, [], "Result" in result ? { NestedResult: [result.Result + index, 0] } : { NestedResult: [result.NestedResult[0] + index, result.NestedResult[1]] });
  }
  insertTransaction(atCommandIndex, otherTransaction) {
    const inputMapping = /* @__PURE__ */ new Map();
    const commandMapping = /* @__PURE__ */ new Map();
    for (let i = 0; i < otherTransaction.inputs.length; i++) {
      const otherInput = otherTransaction.inputs[i];
      const id = getIdFromCallArg(otherInput);
      let existingIndex = -1;
      if (id !== void 0) {
        existingIndex = this.inputs.findIndex((input) => getIdFromCallArg(input) === id);
        if (existingIndex !== -1 && this.inputs[existingIndex].Object?.SharedObject && otherInput.Object?.SharedObject) this.inputs[existingIndex].Object.SharedObject.mutable = this.inputs[existingIndex].Object.SharedObject.mutable || otherInput.Object.SharedObject.mutable;
      }
      if (existingIndex !== -1) inputMapping.set(i, existingIndex);
      else {
        const newIndex = this.inputs.length;
        this.inputs.push(otherInput);
        inputMapping.set(i, newIndex);
      }
    }
    for (let i = 0; i < otherTransaction.commands.length; i++) commandMapping.set(i, atCommandIndex + i);
    const remappedCommands = [];
    for (let i = 0; i < otherTransaction.commands.length; i++) {
      const command = structuredClone(otherTransaction.commands[i]);
      remapCommandArguments(command, inputMapping, commandMapping);
      remappedCommands.push(command);
    }
    this.commands.splice(atCommandIndex, 0, ...remappedCommands);
    const sizeDiff = remappedCommands.length;
    if (sizeDiff > 0) this.mapArguments((arg, _command, commandIndex) => {
      if (commandIndex >= atCommandIndex && commandIndex < atCommandIndex + remappedCommands.length) return arg;
      switch (arg.$kind) {
        case "Result":
          if (arg.Result >= atCommandIndex) arg.Result += sizeDiff;
          break;
        case "NestedResult":
          if (arg.NestedResult[0] >= atCommandIndex) arg.NestedResult[0] += sizeDiff;
          break;
      }
      return arg;
    });
  }
  getDigest() {
    const bytes = this.build({ onlyTransactionKind: false });
    return TransactionDataBuilder2.getDigestFromBytes(bytes);
  }
  snapshot() {
    return parse2(TransactionDataSchema, this);
  }
  getData() {
    return this.snapshot();
  }
  shallowClone() {
    return new TransactionDataBuilder2({
      version: this.version,
      sender: this.sender,
      expiration: this.expiration,
      gasData: { ...this.gasData },
      inputs: [...this.inputs],
      commands: [...this.commands]
    });
  }
  applyResolvedData(resolved) {
    if (!this.sender) this.sender = resolved.sender ?? null;
    if (!this.expiration) this.expiration = resolved.expiration ?? null;
    if (!this.gasData.budget) this.gasData.budget = resolved.gasData.budget;
    if (!this.gasData.owner) this.gasData.owner = resolved.gasData.owner ?? null;
    if (!this.gasData.payment) this.gasData.payment = resolved.gasData.payment;
    if (!this.gasData.price) this.gasData.price = resolved.gasData.price;
    for (let i = 0; i < this.inputs.length; i++) {
      const input = this.inputs[i];
      const resolvedInput = resolved.inputs[i];
      switch (input.$kind) {
        case "UnresolvedPure":
          if (resolvedInput.$kind !== "Pure") throw new Error(`Expected input at index ${i} to resolve to a Pure argument, but got ${JSON.stringify(resolvedInput)}`);
          this.inputs[i] = resolvedInput;
          break;
        case "UnresolvedObject":
          if (resolvedInput.$kind !== "Object") throw new Error(`Expected input at index ${i} to resolve to an Object argument, but got ${JSON.stringify(resolvedInput)}`);
          if (resolvedInput.Object.$kind === "ImmOrOwnedObject" || resolvedInput.Object.$kind === "Receiving") {
            const original = input.UnresolvedObject;
            const resolved$1 = resolvedInput.Object.ImmOrOwnedObject ?? resolvedInput.Object.Receiving;
            if (normalizeSuiAddress(original.objectId) !== normalizeSuiAddress(resolved$1.objectId) || original.version != null && original.version !== resolved$1.version || original.digest != null && original.digest !== resolved$1.digest || original.mutable != null || original.initialSharedVersion != null) throw new Error(`Input at index ${i} did not match unresolved object. ${JSON.stringify(original)} is not compatible with ${JSON.stringify(resolved$1)}`);
          } else if (resolvedInput.Object.$kind === "SharedObject") {
            const original = input.UnresolvedObject;
            const resolved$1 = resolvedInput.Object.SharedObject;
            if (normalizeSuiAddress(original.objectId) !== normalizeSuiAddress(resolved$1.objectId) || original.initialSharedVersion != null && original.initialSharedVersion !== resolved$1.initialSharedVersion || original.mutable != null && original.mutable !== resolved$1.mutable || original.version != null || original.digest != null) throw new Error(`Input at index ${i} did not match unresolved object. ${JSON.stringify(original)} is not compatible with ${JSON.stringify(resolved$1)}`);
          } else throw new Error(`Input at index ${i} resolved to an unexpected Object kind: ${JSON.stringify(resolvedInput.Object)}`);
          this.inputs[i] = resolvedInput;
          break;
      }
    }
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/client/utils.mjs
import { toBase64 as toBase643 } from "@mysten/utils";
var ordinalRules = new Intl.PluralRules("en-US", { type: "ordinal" });
var ordinalSuffixes = /* @__PURE__ */ new Map([
  ["one", "st"],
  ["two", "nd"],
  ["few", "rd"],
  ["other", "th"]
]);
function formatOrdinal(n) {
  return `${n}${ordinalSuffixes.get(ordinalRules.select(n))}`;
}
function formatMoveAbortMessage(options) {
  const { command, location, abortCode, cleverError } = options;
  const parts = [];
  if (command != null) parts.push(`MoveAbort in ${formatOrdinal(command + 1)} command`);
  else parts.push("MoveAbort");
  if (cleverError?.constantName) {
    const errorStr = cleverError.value ? `'${cleverError.constantName}': ${cleverError.value}` : `'${cleverError.constantName}'`;
    parts.push(errorStr);
  } else parts.push(`abort code: ${abortCode}`);
  if (location?.package && location?.module) {
    const locationStr = [`in '${[
      location.package.startsWith("0x") ? location.package : `0x${location.package}`,
      location.module,
      location.functionName
    ].filter(Boolean).join("::")}'`];
    if (cleverError?.lineNumber != null) locationStr.push(`(line ${cleverError.lineNumber})`);
    else if (location.instruction != null) locationStr.push(`(instruction ${location.instruction})`);
    parts.push(locationStr.join(" "));
  }
  return parts.join(", ");
}
var MinimalEffectsWithError = suiBcs.struct("MinimalEffectsWithError", { status: ExecutionStatus });
var MinimalTransactionEffectsWithError = suiBcs.enum("MinimalTransactionEffectsWithError", {
  V1: MinimalEffectsWithError,
  V2: MinimalEffectsWithError
});
var MinimalExecutionStatusNoError = suiBcs.enum("MinimalExecutionStatusNoError", {
  Success: null,
  Failed: null
});
var MinimalEffectsNoError = suiBcs.struct("MinimalEffectsNoError", { status: MinimalExecutionStatusNoError });
var MinimalTransactionEffectsNoError = suiBcs.enum("MinimalTransactionEffectsNoError", {
  V1: MinimalEffectsNoError,
  V2: MinimalEffectsNoError
});
function formatErrorMessage($kind, data) {
  if (data !== null && data !== void 0 && typeof data !== "boolean") return `${$kind}(${JSON.stringify(data, (_key, value) => typeof value === "bigint" ? value.toString() : value)})`;
  return $kind;
}
function parseBcsExecutionError(failure3) {
  const error = failure3.error;
  const command = failure3.command != null ? Number(failure3.command) : void 0;
  switch (error.$kind) {
    case "MoveAbort": {
      const [location, abortCode] = error.MoveAbort;
      const moveLocation = {
        package: location.module.address,
        module: location.module.name,
        function: location.function,
        functionName: location.functionName ?? void 0,
        instruction: location.instruction
      };
      return {
        $kind: "MoveAbort",
        message: formatMoveAbortMessage({
          command,
          location: moveLocation,
          abortCode: String(abortCode)
        }),
        command,
        MoveAbort: {
          abortCode: String(abortCode),
          location: moveLocation
        }
      };
    }
    case "MoveObjectTooBig":
      return {
        $kind: "SizeError",
        message: formatErrorMessage("MoveObjectTooBig", error.MoveObjectTooBig),
        command,
        SizeError: {
          name: "ObjectTooBig",
          size: Number(error.MoveObjectTooBig.objectSize),
          maxSize: Number(error.MoveObjectTooBig.maxObjectSize)
        }
      };
    case "MovePackageTooBig":
      return {
        $kind: "SizeError",
        message: formatErrorMessage("MovePackageTooBig", error.MovePackageTooBig),
        command,
        SizeError: {
          name: "PackageTooBig",
          size: Number(error.MovePackageTooBig.objectSize),
          maxSize: Number(error.MovePackageTooBig.maxObjectSize)
        }
      };
    case "EffectsTooLarge":
      return {
        $kind: "SizeError",
        message: formatErrorMessage("EffectsTooLarge", error.EffectsTooLarge),
        command,
        SizeError: {
          name: "EffectsTooLarge",
          size: Number(error.EffectsTooLarge.currentSize),
          maxSize: Number(error.EffectsTooLarge.maxSize)
        }
      };
    case "WrittenObjectsTooLarge":
      return {
        $kind: "SizeError",
        message: formatErrorMessage("WrittenObjectsTooLarge", error.WrittenObjectsTooLarge),
        command,
        SizeError: {
          name: "WrittenObjectsTooLarge",
          size: Number(error.WrittenObjectsTooLarge.currentSize),
          maxSize: Number(error.WrittenObjectsTooLarge.maxSize)
        }
      };
    case "MoveVectorElemTooBig":
      return {
        $kind: "SizeError",
        message: formatErrorMessage("MoveVectorElemTooBig", error.MoveVectorElemTooBig),
        command,
        SizeError: {
          name: "MoveVectorElemTooBig",
          size: Number(error.MoveVectorElemTooBig.valueSize),
          maxSize: Number(error.MoveVectorElemTooBig.maxScaledSize)
        }
      };
    case "MoveRawValueTooBig":
      return {
        $kind: "SizeError",
        message: formatErrorMessage("MoveRawValueTooBig", error.MoveRawValueTooBig),
        command,
        SizeError: {
          name: "MoveRawValueTooBig",
          size: Number(error.MoveRawValueTooBig.valueSize),
          maxSize: Number(error.MoveRawValueTooBig.maxScaledSize)
        }
      };
    case "CommandArgumentError":
      return {
        $kind: "CommandArgumentError",
        message: formatErrorMessage("CommandArgumentError", error.CommandArgumentError),
        command,
        CommandArgumentError: {
          argument: error.CommandArgumentError.argIdx,
          name: error.CommandArgumentError.kind.$kind
        }
      };
    case "TypeArgumentError":
      return {
        $kind: "TypeArgumentError",
        message: formatErrorMessage("TypeArgumentError", error.TypeArgumentError),
        command,
        TypeArgumentError: {
          typeArgument: error.TypeArgumentError.argumentIdx,
          name: error.TypeArgumentError.kind.$kind
        }
      };
    case "PackageUpgradeError": {
      const upgradeError = error.PackageUpgradeError.upgradeError;
      return {
        $kind: "PackageUpgradeError",
        message: formatErrorMessage("PackageUpgradeError", error.PackageUpgradeError),
        command,
        PackageUpgradeError: {
          name: upgradeError.$kind,
          packageId: upgradeError.$kind === "UnableToFetchPackage" ? upgradeError.UnableToFetchPackage.packageId : void 0,
          digest: upgradeError.$kind === "DigestDoesNotMatch" ? toBase643(upgradeError.DigestDoesNotMatch.digest) : void 0
        }
      };
    }
    case "ExecutionCancelledDueToSharedObjectCongestion":
      return {
        $kind: "CongestedObjects",
        message: formatErrorMessage("ExecutionCancelledDueToSharedObjectCongestion", error.ExecutionCancelledDueToSharedObjectCongestion),
        command,
        CongestedObjects: {
          name: "ExecutionCanceledDueToConsensusObjectCongestion",
          objects: error.ExecutionCancelledDueToSharedObjectCongestion.congested_objects
        }
      };
    case "AddressDeniedForCoin":
      return {
        $kind: "CoinDenyListError",
        message: formatErrorMessage("AddressDeniedForCoin", error.AddressDeniedForCoin),
        command,
        CoinDenyListError: {
          name: "AddressDeniedForCoin",
          address: error.AddressDeniedForCoin.address,
          coinType: error.AddressDeniedForCoin.coinType
        }
      };
    case "CoinTypeGlobalPause":
      return {
        $kind: "CoinDenyListError",
        message: formatErrorMessage("CoinTypeGlobalPause", error.CoinTypeGlobalPause),
        command,
        CoinDenyListError: {
          name: "CoinTypeGlobalPause",
          coinType: error.CoinTypeGlobalPause.coinType
        }
      };
    case "CircularObjectOwnership":
      return {
        $kind: "ObjectIdError",
        message: formatErrorMessage("CircularObjectOwnership", error.CircularObjectOwnership),
        command,
        ObjectIdError: {
          name: "CircularObjectOwnership",
          objectId: error.CircularObjectOwnership.object
        }
      };
    case "InvalidGasObject":
      return {
        $kind: "ObjectIdError",
        message: "InvalidGasObject",
        command,
        ObjectIdError: {
          name: "InvalidGasObject",
          objectId: ""
        }
      };
    case "InputObjectDeleted":
      return {
        $kind: "ObjectIdError",
        message: "InputObjectDeleted",
        command,
        ObjectIdError: {
          name: "InputObjectDeleted",
          objectId: ""
        }
      };
    case "InvalidTransferObject":
      return {
        $kind: "ObjectIdError",
        message: "InvalidTransferObject",
        command,
        ObjectIdError: {
          name: "InvalidTransferObject",
          objectId: ""
        }
      };
    case "NonExclusiveWriteInputObjectModified":
      return {
        $kind: "Unknown",
        message: formatErrorMessage("NonExclusiveWriteInputObjectModified", error.NonExclusiveWriteInputObjectModified),
        command,
        Unknown: null
      };
    case "InsufficientGas":
    case "InvariantViolation":
    case "FeatureNotYetSupported":
    case "InsufficientCoinBalance":
    case "CoinBalanceOverflow":
    case "PublishErrorNonZeroAddress":
    case "SuiMoveVerificationError":
    case "MovePrimitiveRuntimeError":
    case "VMVerificationOrDeserializationError":
    case "VMInvariantViolation":
    case "FunctionNotFound":
    case "ArityMismatch":
    case "TypeArityMismatch":
    case "NonEntryFunctionInvoked":
    case "UnusedValueWithoutDrop":
    case "InvalidPublicFunctionReturnType":
    case "PublishUpgradeMissingDependency":
    case "PublishUpgradeDependencyDowngrade":
    case "CertificateDenied":
    case "SuiMoveVerificationTimedout":
    case "SharedObjectOperationNotAllowed":
    case "ExecutionCancelledDueToRandomnessUnavailable":
    case "InvalidLinkage":
    case "InsufficientBalanceForWithdraw":
      return {
        $kind: "Unknown",
        message: error.$kind,
        command,
        Unknown: null
      };
    default:
      return {
        $kind: "Unknown",
        message: "Unknown error",
        command,
        Unknown: null
      };
  }
}
function transactionBytesHaveEmptyGasPayment(bytes) {
  try {
    return suiBcs.TransactionData.parse(bytes).V1?.gasData.payment?.length === 0;
  } catch {
    return false;
  }
}
function isMockedGasObjectId(objectId) {
  return objectId != null && normalizeSuiAddress(objectId) === MOCKED_GAS_OBJECT_ID;
}
function parseTransactionEffectsBcs(effects) {
  const parsed = suiBcs.TransactionEffects.parse(effects);
  switch (parsed.$kind) {
    case "V1":
      return parseTransactionEffectsV1({
        bytes: effects,
        effects: parsed.V1
      });
    case "V2":
      return parseTransactionEffectsV2({
        bytes: effects,
        effects: parsed.V2
      });
    default:
      throw new Error(`Unknown transaction effects version: ${parsed.$kind}`);
  }
}
function parseTransactionEffectsV1({ bytes, effects }) {
  const modifiedAtVersions = new Map(effects.modifiedAtVersions);
  const sharedObjects = new Map(effects.sharedObjects.map((object3) => [object3.objectId, object3]));
  const mapChangedObject = (reference, change) => {
    const sharedInput = sharedObjects.get(reference.objectId);
    return {
      objectId: reference.objectId,
      inputState: change.inputState,
      inputVersion: change.inputState === "Exists" ? sharedInput?.version ?? modifiedAtVersions.get(reference.objectId) ?? null : null,
      inputDigest: change.inputState === "Exists" ? sharedInput?.digest ?? null : null,
      inputOwner: null,
      outputState: change.outputState,
      outputVersion: change.outputState === "DoesNotExist" ? null : reference.version,
      outputDigest: change.outputState === "DoesNotExist" ? null : reference.digest,
      outputOwner: change.outputOwner,
      idOperation: change.idOperation
    };
  };
  const written = (changes, inputState, idOperation) => changes.map(([reference, owner]) => mapChangedObject(reference, {
    inputState,
    outputState: "ObjectWrite",
    outputOwner: owner,
    idOperation
  }));
  const removed = (changes, inputState, idOperation) => changes.map((reference) => mapChangedObject(reference, {
    inputState,
    outputState: "DoesNotExist",
    outputOwner: null,
    idOperation
  }));
  const changedObjects = [
    ...written(effects.created, "DoesNotExist", "Created"),
    ...written(effects.mutated, "Exists", "None"),
    ...written(effects.unwrapped, "DoesNotExist", "None"),
    ...removed(effects.deleted, "Exists", "Deleted"),
    ...removed(effects.unwrappedThenDeleted, "DoesNotExist", "Deleted"),
    ...removed(effects.wrapped, "Exists", "None")
  ];
  const gasObjectId = effects.gasObject[0].objectId;
  const gasObject = changedObjects.find((object3) => object3.objectId === gasObjectId) ?? null;
  const changedObjectIds = new Set(changedObjects.map((object3) => object3.objectId));
  const lamportVersion = effects.modifiedAtVersions.reduce((max, [, version]) => BigInt(version) > max ? BigInt(version) : max, 0n);
  return {
    bcs: bytes,
    version: 1,
    status: effects.status.$kind === "Success" ? {
      success: true,
      error: null
    } : {
      success: false,
      error: parseBcsExecutionError(effects.status.Failure)
    },
    gasUsed: effects.gasUsed,
    transactionDigest: effects.transactionDigest,
    gasObject,
    eventsDigest: effects.eventsDigest,
    dependencies: effects.dependencies,
    lamportVersion: (lamportVersion + 1n).toString(),
    changedObjects,
    unchangedConsensusObjects: effects.sharedObjects.filter((object3) => !changedObjectIds.has(object3.objectId)).map((object3) => ({
      kind: "ReadOnlyRoot",
      objectId: object3.objectId,
      version: object3.version,
      digest: object3.digest
    })),
    auxiliaryDataDigest: null
  };
}
function parseTransactionEffectsV2({ bytes, effects }) {
  const changedObjects = effects.changedObjects.map(([id, change]) => {
    return {
      objectId: id,
      inputState: change.inputState.$kind === "Exist" ? "Exists" : "DoesNotExist",
      inputVersion: change.inputState.Exist?.[0][0] ?? null,
      inputDigest: change.inputState.Exist?.[0][1] ?? null,
      inputOwner: change.inputState.Exist?.[1] ?? null,
      outputState: change.outputState.$kind === "NotExist" ? "DoesNotExist" : change.outputState.$kind,
      outputVersion: change.outputState.$kind === "PackageWrite" ? change.outputState.PackageWrite?.[0] : change.outputState.$kind === "ObjectWrite" ? effects.lamportVersion : null,
      outputDigest: change.outputState.$kind === "PackageWrite" ? change.outputState.PackageWrite?.[1] : change.outputState.$kind === "ObjectWrite" ? change.outputState.ObjectWrite?.[0] ?? null : null,
      outputOwner: change.outputState.$kind === "ObjectWrite" ? change.outputState.ObjectWrite[1] : null,
      idOperation: change.idOperation.$kind
    };
  });
  return {
    bcs: bytes,
    version: 2,
    status: effects.status.$kind === "Success" ? {
      success: true,
      error: null
    } : {
      success: false,
      error: parseBcsExecutionError(effects.status.Failure)
    },
    gasUsed: effects.gasUsed,
    transactionDigest: effects.transactionDigest,
    gasObject: effects.gasObjectIndex === null ? null : changedObjects[effects.gasObjectIndex] ?? null,
    eventsDigest: effects.eventsDigest,
    dependencies: effects.dependencies,
    lamportVersion: effects.lamportVersion,
    changedObjects,
    unchangedConsensusObjects: effects.unchangedConsensusObjects.map(([objectId, object3]) => {
      return {
        kind: object3.$kind,
        objectId,
        version: object3.$kind === "ReadOnlyRoot" ? object3.ReadOnlyRoot[0] : object3[object3.$kind],
        digest: object3.$kind === "ReadOnlyRoot" ? object3.ReadOnlyRoot[1] : null
      };
    }),
    auxiliaryDataDigest: effects.auxDataDigest
  };
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/client/errors.mjs
var SuiClientError = class extends Error {
};
var SimulationError = class extends SuiClientError {
  constructor(message, options) {
    super(message, { cause: options?.cause });
    this.executionError = options?.executionError;
  }
};
var ObjectError = class extends SuiClientError {
  constructor(code, message, options) {
    super(message, { cause: options?.cause });
    this.code = code;
    this.reason = options?.reason ?? "unknown";
    this.objectId = options?.objectId;
  }
};
var TRANSACTION_ERROR_MESSAGES = { notFound: (digest) => `Transaction ${digest} not found` };
var TransactionError = class extends SuiClientError {
  constructor(reason, digest, options) {
    super(TRANSACTION_ERROR_MESSAGES[reason](digest), options);
    this.reason = reason;
    this.digest = digest;
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/struct.mjs
import { MessageType, isJsonObject, typeofJsonValue } from "@protobuf-ts/runtime";
var NullValue = /* @__PURE__ */ (function(NullValue$1) {
  NullValue$1[NullValue$1["NULL_VALUE"] = 0] = "NULL_VALUE";
  return NullValue$1;
})({});
var Struct$Type = class extends MessageType {
  constructor() {
    super("google.protobuf.Struct", [{
      no: 1,
      name: "fields",
      kind: "map",
      K: 9,
      V: {
        kind: "message",
        T: () => Value
      }
    }]);
  }
  /**
  * Encode `Struct` to JSON object.
  */
  internalJsonWrite(message, options) {
    let json = {};
    for (let [k, v] of Object.entries(message.fields)) json[k] = Value.toJson(v);
    return json;
  }
  /**
  * Decode `Struct` from JSON object.
  */
  internalJsonRead(json, options, target) {
    if (!isJsonObject(json)) throw new globalThis.Error("Unable to parse message " + this.typeName + " from JSON " + typeofJsonValue(json) + ".");
    if (!target) target = this.create();
    for (let [k, v] of globalThis.Object.entries(json)) target.fields[k] = Value.fromJson(v);
    return target;
  }
};
var Struct = new Struct$Type();
var Value$Type = class extends MessageType {
  constructor() {
    super("google.protobuf.Value", [
      {
        no: 1,
        name: "null_value",
        kind: "enum",
        oneof: "kind",
        T: () => ["google.protobuf.NullValue", NullValue]
      },
      {
        no: 2,
        name: "number_value",
        kind: "scalar",
        oneof: "kind",
        T: 1
      },
      {
        no: 3,
        name: "string_value",
        kind: "scalar",
        oneof: "kind",
        T: 9
      },
      {
        no: 4,
        name: "bool_value",
        kind: "scalar",
        oneof: "kind",
        T: 8
      },
      {
        no: 5,
        name: "struct_value",
        kind: "message",
        oneof: "kind",
        T: () => Struct
      },
      {
        no: 6,
        name: "list_value",
        kind: "message",
        oneof: "kind",
        T: () => ListValue
      }
    ]);
  }
  /**
  * Encode `Value` to JSON value.
  */
  internalJsonWrite(message, options) {
    if (message.kind.oneofKind === void 0) throw new globalThis.Error();
    switch (message.kind.oneofKind) {
      case void 0:
        throw new globalThis.Error();
      case "boolValue":
        return message.kind.boolValue;
      case "nullValue":
        return null;
      case "numberValue":
        let numberValue = message.kind.numberValue;
        if (typeof numberValue == "number" && !Number.isFinite(numberValue)) throw new globalThis.Error();
        return numberValue;
      case "stringValue":
        return message.kind.stringValue;
      case "listValue":
        let listValueField = this.fields.find((f) => f.no === 6);
        if (listValueField?.kind !== "message") throw new globalThis.Error();
        return listValueField.T().toJson(message.kind.listValue);
      case "structValue":
        let structValueField = this.fields.find((f) => f.no === 5);
        if (structValueField?.kind !== "message") throw new globalThis.Error();
        return structValueField.T().toJson(message.kind.structValue);
    }
  }
  /**
  * Decode `Value` from JSON value.
  */
  internalJsonRead(json, options, target) {
    if (!target) target = this.create();
    switch (typeof json) {
      case "number":
        target.kind = {
          oneofKind: "numberValue",
          numberValue: json
        };
        break;
      case "string":
        target.kind = {
          oneofKind: "stringValue",
          stringValue: json
        };
        break;
      case "boolean":
        target.kind = {
          oneofKind: "boolValue",
          boolValue: json
        };
        break;
      case "object":
        if (json === null) target.kind = {
          oneofKind: "nullValue",
          nullValue: NullValue.NULL_VALUE
        };
        else if (globalThis.Array.isArray(json)) target.kind = {
          oneofKind: "listValue",
          listValue: ListValue.fromJson(json)
        };
        else target.kind = {
          oneofKind: "structValue",
          structValue: Struct.fromJson(json)
        };
        break;
      default:
        throw new globalThis.Error("Unable to parse " + this.typeName + " from JSON " + typeofJsonValue(json));
    }
    return target;
  }
};
var Value = new Value$Type();
var ListValue$Type = class extends MessageType {
  constructor() {
    super("google.protobuf.ListValue", [{
      no: 1,
      name: "values",
      kind: "message",
      repeat: 2,
      T: () => Value
    }]);
  }
  /**
  * Encode `ListValue` to JSON array.
  */
  internalJsonWrite(message, options) {
    return message.values.map((v) => Value.toJson(v));
  }
  /**
  * Decode `ListValue` from JSON array.
  */
  internalJsonRead(json, options, target) {
    if (!globalThis.Array.isArray(json)) throw new globalThis.Error("Unable to parse " + this.typeName + " from JSON " + typeofJsonValue(json));
    if (!target) target = this.create();
    let values = json.map((v) => Value.fromJson(v));
    target.values.push(...values);
    return target;
  }
};
var ListValue = new ListValue$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/move_package.mjs
import { MessageType as MessageType2 } from "@protobuf-ts/runtime";
var DatatypeDescriptor_DatatypeKind = /* @__PURE__ */ (function(DatatypeDescriptor_DatatypeKind$1) {
  DatatypeDescriptor_DatatypeKind$1[DatatypeDescriptor_DatatypeKind$1["DATATYPE_KIND_UNKNOWN"] = 0] = "DATATYPE_KIND_UNKNOWN";
  DatatypeDescriptor_DatatypeKind$1[DatatypeDescriptor_DatatypeKind$1["STRUCT"] = 1] = "STRUCT";
  DatatypeDescriptor_DatatypeKind$1[DatatypeDescriptor_DatatypeKind$1["ENUM"] = 2] = "ENUM";
  return DatatypeDescriptor_DatatypeKind$1;
})({});
var OpenSignatureBody_Type = /* @__PURE__ */ (function(OpenSignatureBody_Type$1) {
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["TYPE_UNKNOWN"] = 0] = "TYPE_UNKNOWN";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["ADDRESS"] = 1] = "ADDRESS";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["BOOL"] = 2] = "BOOL";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U8"] = 3] = "U8";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U16"] = 4] = "U16";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U32"] = 5] = "U32";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U64"] = 6] = "U64";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U128"] = 7] = "U128";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U256"] = 8] = "U256";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["VECTOR"] = 9] = "VECTOR";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["DATATYPE"] = 10] = "DATATYPE";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["TYPE_PARAMETER"] = 11] = "TYPE_PARAMETER";
  return OpenSignatureBody_Type$1;
})({});
var FunctionDescriptor_Visibility = /* @__PURE__ */ (function(FunctionDescriptor_Visibility$1) {
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["VISIBILITY_UNKNOWN"] = 0] = "VISIBILITY_UNKNOWN";
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["PRIVATE"] = 1] = "PRIVATE";
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["PUBLIC"] = 2] = "PUBLIC";
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["FRIEND"] = 3] = "FRIEND";
  return FunctionDescriptor_Visibility$1;
})({});
var OpenSignature_Reference = /* @__PURE__ */ (function(OpenSignature_Reference$1) {
  OpenSignature_Reference$1[OpenSignature_Reference$1["REFERENCE_UNKNOWN"] = 0] = "REFERENCE_UNKNOWN";
  OpenSignature_Reference$1[OpenSignature_Reference$1["IMMUTABLE"] = 1] = "IMMUTABLE";
  OpenSignature_Reference$1[OpenSignature_Reference$1["MUTABLE"] = 2] = "MUTABLE";
  return OpenSignature_Reference$1;
})({});
var Ability = /* @__PURE__ */ (function(Ability$1) {
  Ability$1[Ability$1["ABILITY_UNKNOWN"] = 0] = "ABILITY_UNKNOWN";
  Ability$1[Ability$1["COPY"] = 1] = "COPY";
  Ability$1[Ability$1["DROP"] = 2] = "DROP";
  Ability$1[Ability$1["STORE"] = 3] = "STORE";
  Ability$1[Ability$1["KEY"] = 4] = "KEY";
  return Ability$1;
})({});
var Package$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.Package", [
      {
        no: 1,
        name: "storage_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "original_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "modules",
        kind: "message",
        repeat: 2,
        T: () => Module
      },
      {
        no: 5,
        name: "type_origins",
        kind: "message",
        repeat: 2,
        T: () => TypeOrigin2
      },
      {
        no: 6,
        name: "linkage",
        kind: "message",
        repeat: 2,
        T: () => Linkage
      }
    ]);
  }
};
var Package = new Package$Type();
var Module$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.Module", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "contents",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "datatypes",
        kind: "message",
        repeat: 2,
        T: () => DatatypeDescriptor
      },
      {
        no: 4,
        name: "functions",
        kind: "message",
        repeat: 2,
        T: () => FunctionDescriptor
      }
    ]);
  }
};
var Module = new Module$Type();
var DatatypeDescriptor$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.DatatypeDescriptor", [
      {
        no: 1,
        name: "type_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "defining_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "abilities",
        kind: "enum",
        repeat: 1,
        T: () => ["sui.rpc.v2.Ability", Ability]
      },
      {
        no: 6,
        name: "type_parameters",
        kind: "message",
        repeat: 2,
        T: () => TypeParameter
      },
      {
        no: 7,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.DatatypeDescriptor.DatatypeKind", DatatypeDescriptor_DatatypeKind]
      },
      {
        no: 8,
        name: "fields",
        kind: "message",
        repeat: 2,
        T: () => FieldDescriptor
      },
      {
        no: 9,
        name: "variants",
        kind: "message",
        repeat: 2,
        T: () => VariantDescriptor
      }
    ]);
  }
};
var DatatypeDescriptor = new DatatypeDescriptor$Type();
var TypeParameter$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.TypeParameter", [{
      no: 1,
      name: "constraints",
      kind: "enum",
      repeat: 1,
      T: () => ["sui.rpc.v2.Ability", Ability]
    }, {
      no: 2,
      name: "is_phantom",
      kind: "scalar",
      opt: true,
      T: 8
    }]);
  }
};
var TypeParameter = new TypeParameter$Type();
var FieldDescriptor$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.FieldDescriptor", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "position",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "type",
        kind: "message",
        T: () => OpenSignatureBody
      }
    ]);
  }
};
var FieldDescriptor = new FieldDescriptor$Type();
var VariantDescriptor$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.VariantDescriptor", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "position",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "fields",
        kind: "message",
        repeat: 2,
        T: () => FieldDescriptor
      }
    ]);
  }
};
var VariantDescriptor = new VariantDescriptor$Type();
var OpenSignatureBody$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.OpenSignatureBody", [
      {
        no: 1,
        name: "type",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.OpenSignatureBody.Type", OpenSignatureBody_Type]
      },
      {
        no: 2,
        name: "type_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "type_parameter_instantiation",
        kind: "message",
        repeat: 2,
        T: () => OpenSignatureBody
      },
      {
        no: 4,
        name: "type_parameter",
        kind: "scalar",
        opt: true,
        T: 13
      }
    ]);
  }
};
var OpenSignatureBody = new OpenSignatureBody$Type();
var FunctionDescriptor$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.FunctionDescriptor", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "visibility",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.FunctionDescriptor.Visibility", FunctionDescriptor_Visibility]
      },
      {
        no: 6,
        name: "is_entry",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 7,
        name: "type_parameters",
        kind: "message",
        repeat: 2,
        T: () => TypeParameter
      },
      {
        no: 8,
        name: "parameters",
        kind: "message",
        repeat: 2,
        T: () => OpenSignature
      },
      {
        no: 9,
        name: "returns",
        kind: "message",
        repeat: 2,
        T: () => OpenSignature
      }
    ]);
  }
};
var FunctionDescriptor = new FunctionDescriptor$Type();
var OpenSignature$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.OpenSignature", [{
      no: 1,
      name: "reference",
      kind: "enum",
      opt: true,
      T: () => ["sui.rpc.v2.OpenSignature.Reference", OpenSignature_Reference]
    }, {
      no: 2,
      name: "body",
      kind: "message",
      T: () => OpenSignatureBody
    }]);
  }
};
var OpenSignature = new OpenSignature$Type();
var TypeOrigin$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.TypeOrigin", [
      {
        no: 1,
        name: "module_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "datatype_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var TypeOrigin2 = new TypeOrigin$Type();
var Linkage$Type = class extends MessageType2 {
  constructor() {
    super("sui.rpc.v2.Linkage", [
      {
        no: 1,
        name: "original_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "upgraded_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "upgraded_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var Linkage = new Linkage$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/owner.mjs
import { MessageType as MessageType3 } from "@protobuf-ts/runtime";
var Owner_OwnerKind = /* @__PURE__ */ (function(Owner_OwnerKind$1) {
  Owner_OwnerKind$1[Owner_OwnerKind$1["OWNER_KIND_UNKNOWN"] = 0] = "OWNER_KIND_UNKNOWN";
  Owner_OwnerKind$1[Owner_OwnerKind$1["ADDRESS"] = 1] = "ADDRESS";
  Owner_OwnerKind$1[Owner_OwnerKind$1["OBJECT"] = 2] = "OBJECT";
  Owner_OwnerKind$1[Owner_OwnerKind$1["SHARED"] = 3] = "SHARED";
  Owner_OwnerKind$1[Owner_OwnerKind$1["IMMUTABLE"] = 4] = "IMMUTABLE";
  Owner_OwnerKind$1[Owner_OwnerKind$1["CONSENSUS_ADDRESS"] = 5] = "CONSENSUS_ADDRESS";
  return Owner_OwnerKind$1;
})({});
var Owner$Type = class extends MessageType3 {
  constructor() {
    super("sui.rpc.v2.Owner", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Owner.OwnerKind", Owner_OwnerKind]
      },
      {
        no: 2,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var Owner2 = new Owner$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/argument.mjs
import { MessageType as MessageType4 } from "@protobuf-ts/runtime";
var Argument_ArgumentKind = /* @__PURE__ */ (function(Argument_ArgumentKind$1) {
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["ARGUMENT_KIND_UNKNOWN"] = 0] = "ARGUMENT_KIND_UNKNOWN";
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["GAS"] = 1] = "GAS";
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["INPUT"] = 2] = "INPUT";
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["RESULT"] = 3] = "RESULT";
  return Argument_ArgumentKind$1;
})({});
var Argument$Type = class extends MessageType4 {
  constructor() {
    super("sui.rpc.v2.Argument", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Argument.ArgumentKind", Argument_ArgumentKind]
      },
      {
        no: 2,
        name: "input",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "result",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 4,
        name: "subresult",
        kind: "scalar",
        opt: true,
        T: 13
      }
    ]);
  }
};
var Argument2 = new Argument$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/input.mjs
import { MessageType as MessageType5 } from "@protobuf-ts/runtime";
var Input_InputKind = /* @__PURE__ */ (function(Input_InputKind$1) {
  Input_InputKind$1[Input_InputKind$1["INPUT_KIND_UNKNOWN"] = 0] = "INPUT_KIND_UNKNOWN";
  Input_InputKind$1[Input_InputKind$1["PURE"] = 1] = "PURE";
  Input_InputKind$1[Input_InputKind$1["IMMUTABLE_OR_OWNED"] = 2] = "IMMUTABLE_OR_OWNED";
  Input_InputKind$1[Input_InputKind$1["SHARED"] = 3] = "SHARED";
  Input_InputKind$1[Input_InputKind$1["RECEIVING"] = 4] = "RECEIVING";
  Input_InputKind$1[Input_InputKind$1["FUNDS_WITHDRAWAL"] = 5] = "FUNDS_WITHDRAWAL";
  return Input_InputKind$1;
})({});
var Input_Mutability = /* @__PURE__ */ (function(Input_Mutability$1) {
  Input_Mutability$1[Input_Mutability$1["MUTABILITY_UNKNOWN"] = 0] = "MUTABILITY_UNKNOWN";
  Input_Mutability$1[Input_Mutability$1["IMMUTABLE"] = 1] = "IMMUTABLE";
  Input_Mutability$1[Input_Mutability$1["MUTABLE"] = 2] = "MUTABLE";
  Input_Mutability$1[Input_Mutability$1["NON_EXCLUSIVE_WRITE"] = 3] = "NON_EXCLUSIVE_WRITE";
  return Input_Mutability$1;
})({});
var FundsWithdrawal_Source = /* @__PURE__ */ (function(FundsWithdrawal_Source$1) {
  FundsWithdrawal_Source$1[FundsWithdrawal_Source$1["SOURCE_UNKNOWN"] = 0] = "SOURCE_UNKNOWN";
  FundsWithdrawal_Source$1[FundsWithdrawal_Source$1["SENDER"] = 1] = "SENDER";
  FundsWithdrawal_Source$1[FundsWithdrawal_Source$1["SPONSOR"] = 2] = "SPONSOR";
  FundsWithdrawal_Source$1[FundsWithdrawal_Source$1["SENDER_ALLOWANCE"] = 3] = "SENDER_ALLOWANCE";
  return FundsWithdrawal_Source$1;
})({});
var Input$Type = class extends MessageType5 {
  constructor() {
    super("sui.rpc.v2.Input", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Input.InputKind", Input_InputKind]
      },
      {
        no: 2,
        name: "pure",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "mutable",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 7,
        name: "mutability",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Input.Mutability", Input_Mutability]
      },
      {
        no: 8,
        name: "funds_withdrawal",
        kind: "message",
        T: () => FundsWithdrawal2
      },
      {
        no: 1e3,
        name: "literal",
        kind: "message",
        T: () => Value
      }
    ]);
  }
};
var Input = new Input$Type();
var FundsWithdrawal$Type = class extends MessageType5 {
  constructor() {
    super("sui.rpc.v2.FundsWithdrawal", [
      {
        no: 1,
        name: "amount",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "source",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.FundsWithdrawal.Source", FundsWithdrawal_Source]
      },
      {
        no: 4,
        name: "funder",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "allowance",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var FundsWithdrawal2 = new FundsWithdrawal$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/duration.mjs
import { MessageType as MessageType6, PbLong, typeofJsonValue as typeofJsonValue2 } from "@protobuf-ts/runtime";
var Duration$Type = class extends MessageType6 {
  constructor() {
    super("google.protobuf.Duration", [{
      no: 1,
      name: "seconds",
      kind: "scalar",
      T: 3,
      L: 0
    }, {
      no: 2,
      name: "nanos",
      kind: "scalar",
      T: 5
    }]);
  }
  /**
  * Encode `Duration` to JSON string like "3.000001s".
  */
  internalJsonWrite(message, options) {
    let s = PbLong.from(message.seconds).toNumber();
    if (s > 315576e6 || s < -315576e6) throw new Error("Duration value out of range.");
    let text = message.seconds.toString();
    if (s === 0 && message.nanos < 0) text = "-" + text;
    if (message.nanos !== 0) {
      let nanosStr = Math.abs(message.nanos).toString();
      nanosStr = "0".repeat(9 - nanosStr.length) + nanosStr;
      if (nanosStr.substring(3) === "000000") nanosStr = nanosStr.substring(0, 3);
      else if (nanosStr.substring(6) === "000") nanosStr = nanosStr.substring(0, 6);
      text += "." + nanosStr;
    }
    return text + "s";
  }
  /**
  * Decode `Duration` from JSON string like "3.000001s"
  */
  internalJsonRead(json, options, target) {
    if (typeof json !== "string") throw new Error("Unable to parse Duration from JSON " + typeofJsonValue2(json) + ". Expected string.");
    let match = json.match(/^(-?)([0-9]+)(?:\.([0-9]+))?s/);
    if (match === null) throw new Error("Unable to parse Duration from JSON string. Invalid format.");
    if (!target) target = this.create();
    let [, sign, secs, nanos] = match;
    let longSeconds = PbLong.from(sign + secs);
    if (longSeconds.toNumber() > 315576e6 || longSeconds.toNumber() < -315576e6) throw new Error("Unable to parse Duration from JSON string. Value out of range.");
    target.seconds = longSeconds.toBigInt();
    if (typeof nanos == "string") {
      let nanosStr = sign + nanos + "0".repeat(9 - nanos.length);
      target.nanos = parseInt(nanosStr);
    }
    return target;
  }
};
var Duration = new Duration$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/jwk.mjs
import { MessageType as MessageType7 } from "@protobuf-ts/runtime";
var JwkId$Type = class extends MessageType7 {
  constructor() {
    super("sui.rpc.v2.JwkId", [{
      no: 1,
      name: "iss",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "kid",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var JwkId = new JwkId$Type();
var Jwk$Type = class extends MessageType7 {
  constructor() {
    super("sui.rpc.v2.Jwk", [
      {
        no: 1,
        name: "kty",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "e",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "n",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "alg",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var Jwk = new Jwk$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/bcs.mjs
import { MessageType as MessageType8 } from "@protobuf-ts/runtime";
var Bcs$Type = class extends MessageType8 {
  constructor() {
    super("sui.rpc.v2.Bcs", [{
      no: 1,
      name: "name",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "value",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var Bcs = new Bcs$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/object.mjs
import { MessageType as MessageType9 } from "@protobuf-ts/runtime";
var Object$Type = class extends MessageType9 {
  constructor() {
    super("sui.rpc.v2.Object", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "owner",
        kind: "message",
        T: () => Owner2
      },
      {
        no: 6,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "has_public_transfer",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 8,
        name: "contents",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 9,
        name: "package",
        kind: "message",
        T: () => Package
      },
      {
        no: 10,
        name: "previous_transaction",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 11,
        name: "storage_rebate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 100,
        name: "json",
        kind: "message",
        T: () => Value
      },
      {
        no: 101,
        name: "balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 102,
        name: "display",
        kind: "message",
        T: () => Display
      }
    ]);
  }
};
var Object$1 = new Object$Type();
var ObjectSet$Type = class extends MessageType9 {
  constructor() {
    super("sui.rpc.v2.ObjectSet", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Object$1
    }]);
  }
};
var ObjectSet = new ObjectSet$Type();
var Display$Type = class extends MessageType9 {
  constructor() {
    super("sui.rpc.v2.Display", [{
      no: 1,
      name: "output",
      kind: "message",
      T: () => Value
    }, {
      no: 2,
      name: "errors",
      kind: "message",
      T: () => Value
    }]);
  }
};
var Display = new Display$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/timestamp.mjs
import { MessageType as MessageType10, PbLong as PbLong2, typeofJsonValue as typeofJsonValue3 } from "@protobuf-ts/runtime";
var Timestamp$Type = class extends MessageType10 {
  constructor() {
    super("google.protobuf.Timestamp", [{
      no: 1,
      name: "seconds",
      kind: "scalar",
      T: 3,
      L: 0
    }, {
      no: 2,
      name: "nanos",
      kind: "scalar",
      T: 5
    }]);
  }
  /**
  * Creates a new `Timestamp` for the current time.
  */
  now() {
    const msg = this.create();
    const ms = Date.now();
    msg.seconds = PbLong2.from(Math.floor(ms / 1e3)).toBigInt();
    msg.nanos = ms % 1e3 * 1e6;
    return msg;
  }
  /**
  * Converts a `Timestamp` to a JavaScript Date.
  */
  toDate(message) {
    return new Date(PbLong2.from(message.seconds).toNumber() * 1e3 + Math.ceil(message.nanos / 1e6));
  }
  /**
  * Converts a JavaScript Date to a `Timestamp`.
  */
  fromDate(date) {
    const msg = this.create();
    const ms = date.getTime();
    msg.seconds = PbLong2.from(Math.floor(ms / 1e3)).toBigInt();
    msg.nanos = (ms % 1e3 + (ms < 0 && ms % 1e3 !== 0 ? 1e3 : 0)) * 1e6;
    return msg;
  }
  /**
  * In JSON format, the `Timestamp` type is encoded as a string
  * in the RFC 3339 format.
  */
  internalJsonWrite(message, options) {
    let ms = PbLong2.from(message.seconds).toNumber() * 1e3;
    if (ms < Date.parse("0001-01-01T00:00:00Z") || ms > Date.parse("9999-12-31T23:59:59Z")) throw new Error("Unable to encode Timestamp to JSON. Must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive.");
    if (message.nanos < 0) throw new Error("Unable to encode invalid Timestamp to JSON. Nanos must not be negative.");
    let z = "Z";
    if (message.nanos > 0) {
      let nanosStr = (message.nanos + 1e9).toString().substring(1);
      if (nanosStr.substring(3) === "000000") z = "." + nanosStr.substring(0, 3) + "Z";
      else if (nanosStr.substring(6) === "000") z = "." + nanosStr.substring(0, 6) + "Z";
      else z = "." + nanosStr + "Z";
    }
    return new Date(ms).toISOString().replace(".000Z", z);
  }
  /**
  * In JSON format, the `Timestamp` type is encoded as a string
  * in the RFC 3339 format.
  */
  internalJsonRead(json, options, target) {
    if (typeof json !== "string") throw new Error("Unable to parse Timestamp from JSON " + typeofJsonValue3(json) + ".");
    let matches = json.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(?:Z|\.([0-9]{3,9})Z|([+-][0-9][0-9]:[0-9][0-9]))$/);
    if (!matches) throw new Error("Unable to parse Timestamp from JSON. Invalid format.");
    let ms = Date.parse(matches[1] + "-" + matches[2] + "-" + matches[3] + "T" + matches[4] + ":" + matches[5] + ":" + matches[6] + (matches[8] ? matches[8] : "Z"));
    if (Number.isNaN(ms)) throw new Error("Unable to parse Timestamp from JSON. Invalid value.");
    if (ms < Date.parse("0001-01-01T00:00:00Z") || ms > Date.parse("9999-12-31T23:59:59Z")) throw new globalThis.Error("Unable to parse Timestamp from JSON. Must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive.");
    if (!target) target = this.create();
    target.seconds = PbLong2.from(ms / 1e3).toBigInt();
    target.nanos = 0;
    if (matches[7]) target.nanos = parseInt("1" + matches[7] + "0".repeat(9 - matches[7].length)) - 1e9;
    return target;
  }
};
var Timestamp = new Timestamp$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/object_reference.mjs
import { MessageType as MessageType11 } from "@protobuf-ts/runtime";
var ObjectReference$Type = class extends MessageType11 {
  constructor() {
    super("sui.rpc.v2.ObjectReference", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ObjectReference = new ObjectReference$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/transaction.mjs
import { MessageType as MessageType12 } from "@protobuf-ts/runtime";
var TransactionExpiration_TransactionExpirationKind = /* @__PURE__ */ (function(TransactionExpiration_TransactionExpirationKind$1) {
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["TRANSACTION_EXPIRATION_KIND_UNKNOWN"] = 0] = "TRANSACTION_EXPIRATION_KIND_UNKNOWN";
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["NONE"] = 1] = "NONE";
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["EPOCH"] = 2] = "EPOCH";
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["VALID_DURING"] = 3] = "VALID_DURING";
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["VALIDITY"] = 4] = "VALIDITY";
  return TransactionExpiration_TransactionExpirationKind$1;
})({});
var TransactionKind_Kind = /* @__PURE__ */ (function(TransactionKind_Kind$1) {
  TransactionKind_Kind$1[TransactionKind_Kind$1["KIND_UNKNOWN"] = 0] = "KIND_UNKNOWN";
  TransactionKind_Kind$1[TransactionKind_Kind$1["PROGRAMMABLE_TRANSACTION"] = 1] = "PROGRAMMABLE_TRANSACTION";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CHANGE_EPOCH"] = 2] = "CHANGE_EPOCH";
  TransactionKind_Kind$1[TransactionKind_Kind$1["GENESIS"] = 3] = "GENESIS";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V1"] = 4] = "CONSENSUS_COMMIT_PROLOGUE_V1";
  TransactionKind_Kind$1[TransactionKind_Kind$1["AUTHENTICATOR_STATE_UPDATE"] = 5] = "AUTHENTICATOR_STATE_UPDATE";
  TransactionKind_Kind$1[TransactionKind_Kind$1["END_OF_EPOCH"] = 6] = "END_OF_EPOCH";
  TransactionKind_Kind$1[TransactionKind_Kind$1["RANDOMNESS_STATE_UPDATE"] = 7] = "RANDOMNESS_STATE_UPDATE";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V2"] = 8] = "CONSENSUS_COMMIT_PROLOGUE_V2";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V3"] = 9] = "CONSENSUS_COMMIT_PROLOGUE_V3";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V4"] = 10] = "CONSENSUS_COMMIT_PROLOGUE_V4";
  TransactionKind_Kind$1[TransactionKind_Kind$1["PROGRAMMABLE_SYSTEM_TRANSACTION"] = 11] = "PROGRAMMABLE_SYSTEM_TRANSACTION";
  return TransactionKind_Kind$1;
})({});
var EndOfEpochTransactionKind_Kind = /* @__PURE__ */ (function(EndOfEpochTransactionKind_Kind$1) {
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["KIND_UNKNOWN"] = 0] = "KIND_UNKNOWN";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["CHANGE_EPOCH"] = 1] = "CHANGE_EPOCH";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["AUTHENTICATOR_STATE_CREATE"] = 2] = "AUTHENTICATOR_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["AUTHENTICATOR_STATE_EXPIRE"] = 3] = "AUTHENTICATOR_STATE_EXPIRE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["RANDOMNESS_STATE_CREATE"] = 4] = "RANDOMNESS_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["DENY_LIST_STATE_CREATE"] = 5] = "DENY_LIST_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["BRIDGE_STATE_CREATE"] = 6] = "BRIDGE_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["BRIDGE_COMMITTEE_INIT"] = 7] = "BRIDGE_COMMITTEE_INIT";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["STORE_EXECUTION_TIME_OBSERVATIONS"] = 8] = "STORE_EXECUTION_TIME_OBSERVATIONS";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["ACCUMULATOR_ROOT_CREATE"] = 9] = "ACCUMULATOR_ROOT_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["COIN_REGISTRY_CREATE"] = 10] = "COIN_REGISTRY_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["DISPLAY_REGISTRY_CREATE"] = 11] = "DISPLAY_REGISTRY_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["ADDRESS_ALIAS_STATE_CREATE"] = 12] = "ADDRESS_ALIAS_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["WRITE_ACCUMULATOR_STORAGE_COST"] = 13] = "WRITE_ACCUMULATOR_STORAGE_COST";
  return EndOfEpochTransactionKind_Kind$1;
})({});
var ExecutionTimeObservation_ExecutionTimeObservationKind = /* @__PURE__ */ (function(ExecutionTimeObservation_ExecutionTimeObservationKind$1) {
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["EXECUTION_TIME_OBSERVATION_KIND_UNKNOWN"] = 0] = "EXECUTION_TIME_OBSERVATION_KIND_UNKNOWN";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["MOVE_ENTRY_POINT"] = 1] = "MOVE_ENTRY_POINT";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["TRANSFER_OBJECTS"] = 2] = "TRANSFER_OBJECTS";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["SPLIT_COINS"] = 3] = "SPLIT_COINS";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["MERGE_COINS"] = 4] = "MERGE_COINS";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["PUBLISH"] = 5] = "PUBLISH";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["MAKE_MOVE_VECTOR"] = 6] = "MAKE_MOVE_VECTOR";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["UPGRADE"] = 7] = "UPGRADE";
  return ExecutionTimeObservation_ExecutionTimeObservationKind$1;
})({});
var Transaction$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.Transaction", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 5
      },
      {
        no: 4,
        name: "kind",
        kind: "message",
        T: () => TransactionKind2
      },
      {
        no: 5,
        name: "sender",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "gas_payment",
        kind: "message",
        T: () => GasPayment
      },
      {
        no: 7,
        name: "expiration",
        kind: "message",
        T: () => TransactionExpiration4
      }
    ]);
  }
};
var Transaction = new Transaction$Type();
var GasPayment$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.GasPayment", [
      {
        no: 1,
        name: "objects",
        kind: "message",
        repeat: 2,
        T: () => ObjectReference
      },
      {
        no: 2,
        name: "owner",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "budget",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var GasPayment = new GasPayment$Type();
var TransactionExpiration$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.TransactionExpiration", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.TransactionExpiration.TransactionExpirationKind", TransactionExpiration_TransactionExpirationKind]
      },
      {
        no: 2,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "min_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "min_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 5,
        name: "max_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 6,
        name: "chain",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "nonce",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 8,
        name: "allowed_proposers",
        kind: "message",
        T: () => AllowedProposers2
      }
    ]);
  }
};
var TransactionExpiration4 = new TransactionExpiration$Type();
var AllowedProposers$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.AllowedProposers", [{
      no: 1,
      name: "epoch",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "proposers",
      kind: "scalar",
      repeat: 1,
      T: 13
    }]);
  }
};
var AllowedProposers2 = new AllowedProposers$Type();
var TransactionKind$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.TransactionKind", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.TransactionKind.Kind", TransactionKind_Kind]
      },
      {
        no: 2,
        name: "programmable_transaction",
        kind: "message",
        oneof: "data",
        T: () => ProgrammableTransaction2
      },
      {
        no: 3,
        name: "change_epoch",
        kind: "message",
        oneof: "data",
        T: () => ChangeEpoch2
      },
      {
        no: 4,
        name: "genesis",
        kind: "message",
        oneof: "data",
        T: () => GenesisTransaction2
      },
      {
        no: 5,
        name: "consensus_commit_prologue",
        kind: "message",
        oneof: "data",
        T: () => ConsensusCommitPrologue2
      },
      {
        no: 6,
        name: "authenticator_state_update",
        kind: "message",
        oneof: "data",
        T: () => AuthenticatorStateUpdate2
      },
      {
        no: 7,
        name: "end_of_epoch",
        kind: "message",
        oneof: "data",
        T: () => EndOfEpochTransaction
      },
      {
        no: 8,
        name: "randomness_state_update",
        kind: "message",
        oneof: "data",
        T: () => RandomnessStateUpdate2
      }
    ]);
  }
};
var TransactionKind2 = new TransactionKind$Type();
var ProgrammableTransaction$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ProgrammableTransaction", [{
      no: 1,
      name: "inputs",
      kind: "message",
      repeat: 2,
      T: () => Input
    }, {
      no: 2,
      name: "commands",
      kind: "message",
      repeat: 2,
      T: () => Command2
    }]);
  }
};
var ProgrammableTransaction2 = new ProgrammableTransaction$Type();
var Command$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.Command", [
      {
        no: 1,
        name: "move_call",
        kind: "message",
        oneof: "command",
        T: () => MoveCall
      },
      {
        no: 2,
        name: "transfer_objects",
        kind: "message",
        oneof: "command",
        T: () => TransferObjects
      },
      {
        no: 3,
        name: "split_coins",
        kind: "message",
        oneof: "command",
        T: () => SplitCoins
      },
      {
        no: 4,
        name: "merge_coins",
        kind: "message",
        oneof: "command",
        T: () => MergeCoins
      },
      {
        no: 5,
        name: "publish",
        kind: "message",
        oneof: "command",
        T: () => Publish
      },
      {
        no: 6,
        name: "make_move_vector",
        kind: "message",
        oneof: "command",
        T: () => MakeMoveVector
      },
      {
        no: 7,
        name: "upgrade",
        kind: "message",
        oneof: "command",
        T: () => Upgrade
      }
    ]);
  }
};
var Command2 = new Command$Type();
var MoveCall$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.MoveCall", [
      {
        no: 1,
        name: "package",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "function",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "type_arguments",
        kind: "scalar",
        repeat: 2,
        T: 9
      },
      {
        no: 5,
        name: "arguments",
        kind: "message",
        repeat: 2,
        T: () => Argument2
      }
    ]);
  }
};
var MoveCall = new MoveCall$Type();
var TransferObjects$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.TransferObjects", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }, {
      no: 2,
      name: "address",
      kind: "message",
      T: () => Argument2
    }]);
  }
};
var TransferObjects = new TransferObjects$Type();
var SplitCoins$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.SplitCoins", [{
      no: 1,
      name: "coin",
      kind: "message",
      T: () => Argument2
    }, {
      no: 2,
      name: "amounts",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }]);
  }
};
var SplitCoins = new SplitCoins$Type();
var MergeCoins$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.MergeCoins", [{
      no: 1,
      name: "coin",
      kind: "message",
      T: () => Argument2
    }, {
      no: 2,
      name: "coins_to_merge",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }]);
  }
};
var MergeCoins = new MergeCoins$Type();
var Publish$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.Publish", [{
      no: 1,
      name: "modules",
      kind: "scalar",
      repeat: 2,
      T: 12
    }, {
      no: 2,
      name: "dependencies",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
};
var Publish = new Publish$Type();
var MakeMoveVector$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.MakeMoveVector", [{
      no: 1,
      name: "element_type",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "elements",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }]);
  }
};
var MakeMoveVector = new MakeMoveVector$Type();
var Upgrade$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.Upgrade", [
      {
        no: 1,
        name: "modules",
        kind: "scalar",
        repeat: 2,
        T: 12
      },
      {
        no: 2,
        name: "dependencies",
        kind: "scalar",
        repeat: 2,
        T: 9
      },
      {
        no: 3,
        name: "package",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "ticket",
        kind: "message",
        T: () => Argument2
      }
    ]);
  }
};
var Upgrade = new Upgrade$Type();
var RandomnessStateUpdate$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.RandomnessStateUpdate", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "randomness_round",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "random_bytes",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "randomness_object_initial_shared_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var RandomnessStateUpdate2 = new RandomnessStateUpdate$Type();
var ChangeEpoch$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ChangeEpoch", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "storage_charge",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "computation_charge",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "storage_rebate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "non_refundable_storage_fee",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "epoch_start_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 8,
        name: "system_packages",
        kind: "message",
        repeat: 2,
        T: () => SystemPackage
      }
    ]);
  }
};
var ChangeEpoch2 = new ChangeEpoch$Type();
var SystemPackage$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.SystemPackage", [
      {
        no: 1,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "modules",
        kind: "scalar",
        repeat: 2,
        T: 12
      },
      {
        no: 3,
        name: "dependencies",
        kind: "scalar",
        repeat: 2,
        T: 9
      }
    ]);
  }
};
var SystemPackage = new SystemPackage$Type();
var GenesisTransaction$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.GenesisTransaction", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Object$1
    }]);
  }
};
var GenesisTransaction2 = new GenesisTransaction$Type();
var ConsensusCommitPrologue$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ConsensusCommitPrologue", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "round",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "commit_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 4,
        name: "consensus_commit_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "sub_dag_index",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "consensus_determined_version_assignments",
        kind: "message",
        T: () => ConsensusDeterminedVersionAssignments2
      },
      {
        no: 7,
        name: "additional_state_digest",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ConsensusCommitPrologue2 = new ConsensusCommitPrologue$Type();
var VersionAssignment$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.VersionAssignment", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "start_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var VersionAssignment = new VersionAssignment$Type();
var CanceledTransaction$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.CanceledTransaction", [{
      no: 1,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "version_assignments",
      kind: "message",
      repeat: 2,
      T: () => VersionAssignment
    }]);
  }
};
var CanceledTransaction = new CanceledTransaction$Type();
var ConsensusDeterminedVersionAssignments$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ConsensusDeterminedVersionAssignments", [{
      no: 1,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 5
    }, {
      no: 3,
      name: "canceled_transactions",
      kind: "message",
      repeat: 2,
      T: () => CanceledTransaction
    }]);
  }
};
var ConsensusDeterminedVersionAssignments2 = new ConsensusDeterminedVersionAssignments$Type();
var AuthenticatorStateUpdate$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.AuthenticatorStateUpdate", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "round",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "new_active_jwks",
        kind: "message",
        repeat: 2,
        T: () => ActiveJwk2
      },
      {
        no: 4,
        name: "authenticator_object_initial_shared_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var AuthenticatorStateUpdate2 = new AuthenticatorStateUpdate$Type();
var ActiveJwk$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ActiveJwk", [
      {
        no: 1,
        name: "id",
        kind: "message",
        T: () => JwkId
      },
      {
        no: 2,
        name: "jwk",
        kind: "message",
        T: () => Jwk
      },
      {
        no: 3,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var ActiveJwk2 = new ActiveJwk$Type();
var EndOfEpochTransaction$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.EndOfEpochTransaction", [{
      no: 1,
      name: "transactions",
      kind: "message",
      repeat: 2,
      T: () => EndOfEpochTransactionKind2
    }]);
  }
};
var EndOfEpochTransaction = new EndOfEpochTransaction$Type();
var EndOfEpochTransactionKind$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.EndOfEpochTransactionKind", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.EndOfEpochTransactionKind.Kind", EndOfEpochTransactionKind_Kind]
      },
      {
        no: 2,
        name: "change_epoch",
        kind: "message",
        oneof: "data",
        T: () => ChangeEpoch2
      },
      {
        no: 3,
        name: "authenticator_state_expire",
        kind: "message",
        oneof: "data",
        T: () => AuthenticatorStateExpire2
      },
      {
        no: 4,
        name: "execution_time_observations",
        kind: "message",
        oneof: "data",
        T: () => ExecutionTimeObservations
      },
      {
        no: 5,
        name: "bridge_chain_id",
        kind: "scalar",
        oneof: "data",
        T: 9
      },
      {
        no: 6,
        name: "bridge_object_version",
        kind: "scalar",
        oneof: "data",
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "storage_cost",
        kind: "scalar",
        oneof: "data",
        T: 4,
        L: 0
      }
    ]);
  }
};
var EndOfEpochTransactionKind2 = new EndOfEpochTransactionKind$Type();
var AuthenticatorStateExpire$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.AuthenticatorStateExpire", [{
      no: 1,
      name: "min_epoch",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "authenticator_object_initial_shared_version",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var AuthenticatorStateExpire2 = new AuthenticatorStateExpire$Type();
var ExecutionTimeObservations$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ExecutionTimeObservations", [{
      no: 1,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 5
    }, {
      no: 2,
      name: "observations",
      kind: "message",
      repeat: 2,
      T: () => ExecutionTimeObservation
    }]);
  }
};
var ExecutionTimeObservations = new ExecutionTimeObservations$Type();
var ExecutionTimeObservation$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ExecutionTimeObservation", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.ExecutionTimeObservation.ExecutionTimeObservationKind", ExecutionTimeObservation_ExecutionTimeObservationKind]
      },
      {
        no: 2,
        name: "move_entry_point",
        kind: "message",
        T: () => MoveCall
      },
      {
        no: 3,
        name: "validator_observations",
        kind: "message",
        repeat: 2,
        T: () => ValidatorExecutionTimeObservation
      }
    ]);
  }
};
var ExecutionTimeObservation = new ExecutionTimeObservation$Type();
var ValidatorExecutionTimeObservation$Type = class extends MessageType12 {
  constructor() {
    super("sui.rpc.v2.ValidatorExecutionTimeObservation", [{
      no: 1,
      name: "validator",
      kind: "scalar",
      opt: true,
      T: 12
    }, {
      no: 2,
      name: "duration",
      kind: "message",
      T: () => Duration
    }]);
  }
};
var ValidatorExecutionTimeObservation = new ValidatorExecutionTimeObservation$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/client/transaction-resolver.mjs
import { fromBase64 as fromBase643, toBase64 as toBase644 } from "@mysten/bcs";
function millisecondsToGrpcTimestamp(value) {
  const milliseconds = BigInt(value);
  return {
    seconds: milliseconds / 1000n,
    nanos: Number(milliseconds % 1000n) * 1e6
  };
}
function grpcTimestampToMilliseconds(timestamp) {
  return (timestamp.seconds * 1000n + BigInt(Math.floor(timestamp.nanos / 1e6))).toString();
}
function callArgToGrpcInput(arg) {
  switch (arg.$kind) {
    case "Pure":
      return {
        kind: Input_InputKind.PURE,
        pure: fromBase643(arg.Pure.bytes)
      };
    case "Object":
      if (arg.Object.$kind === "ImmOrOwnedObject") return {
        kind: Input_InputKind.IMMUTABLE_OR_OWNED,
        objectId: arg.Object.ImmOrOwnedObject.objectId,
        version: BigInt(arg.Object.ImmOrOwnedObject.version),
        digest: arg.Object.ImmOrOwnedObject.digest
      };
      else if (arg.Object.$kind === "SharedObject") return {
        kind: Input_InputKind.SHARED,
        objectId: arg.Object.SharedObject.objectId,
        version: BigInt(arg.Object.SharedObject.initialSharedVersion),
        mutable: arg.Object.SharedObject.mutable
      };
      else if (arg.Object.$kind === "Receiving") return {
        kind: Input_InputKind.RECEIVING,
        objectId: arg.Object.Receiving.objectId,
        version: BigInt(arg.Object.Receiving.version),
        digest: arg.Object.Receiving.digest
      };
      throw new Error(`Unknown Object kind: ${JSON.stringify(arg.Object)}`);
    case "UnresolvedObject":
      const unresolved = arg.UnresolvedObject;
      return {
        objectId: unresolved.objectId,
        version: unresolved.version ? BigInt(unresolved.version) : unresolved.initialSharedVersion ? BigInt(unresolved.initialSharedVersion) : void 0,
        digest: unresolved.digest ?? void 0,
        mutable: unresolved.mutable ?? void 0
      };
    case "UnresolvedPure":
      throw new Error("UnresolvedPure arguments must be resolved before converting to gRPC format");
    case "FundsWithdrawal": {
      const withdrawal = arg.FundsWithdrawal;
      return {
        kind: Input_InputKind.FUNDS_WITHDRAWAL,
        fundsWithdrawal: {
          amount: withdrawal.reservation.$kind === "MaxAmountU64" ? BigInt(withdrawal.reservation.MaxAmountU64) : void 0,
          coinType: withdrawal.typeArg.$kind === "Balance" ? withdrawal.typeArg.Balance : void 0,
          ...tsWithdrawFromToGrpc(withdrawal.withdrawFrom)
        }
      };
    }
    default:
      throw new Error(`Unknown CallArg kind: ${JSON.stringify(arg)}`);
  }
}
function tsWithdrawFromToGrpc(withdrawFrom) {
  switch (withdrawFrom.$kind) {
    case "Sender":
      return { source: FundsWithdrawal_Source.SENDER };
    case "Sponsor":
      return { source: FundsWithdrawal_Source.SPONSOR };
    case "SenderAllowance":
      return {
        source: FundsWithdrawal_Source.SENDER_ALLOWANCE,
        funder: withdrawFrom.SenderAllowance.funder,
        allowance: withdrawFrom.SenderAllowance.allowance
      };
    default:
      throw new Error(`Unknown WithdrawFrom kind: ${JSON.stringify(withdrawFrom)}`);
  }
}
function grpcWithdrawFromToTs(withdrawal) {
  switch (withdrawal?.source) {
    case FundsWithdrawal_Source.SPONSOR:
      return {
        $kind: "Sponsor",
        Sponsor: true
      };
    case FundsWithdrawal_Source.SENDER_ALLOWANCE:
      if (!withdrawal.funder || !withdrawal.allowance) throw new Error(`SENDER_ALLOWANCE withdrawal is missing funder or allowance: ${JSON.stringify(withdrawal)}`);
      return {
        $kind: "SenderAllowance",
        SenderAllowance: {
          funder: withdrawal.funder,
          allowance: withdrawal.allowance
        }
      };
    default:
      return {
        $kind: "Sender",
        Sender: true
      };
  }
}
function tsArgumentToGrpcArgument(arg) {
  if ("GasCoin" in arg) return { kind: Argument_ArgumentKind.GAS };
  else if ("Input" in arg) return {
    kind: Argument_ArgumentKind.INPUT,
    input: arg.Input
  };
  else if ("Result" in arg) return {
    kind: Argument_ArgumentKind.RESULT,
    result: arg.Result
  };
  else if ("NestedResult" in arg) return {
    kind: Argument_ArgumentKind.RESULT,
    result: arg.NestedResult[0],
    subresult: arg.NestedResult[1]
  };
  throw new Error(`Unknown Argument: ${JSON.stringify(arg)}`);
}
function tsCommandToGrpcCommand(cmd) {
  switch (cmd.$kind) {
    case "MoveCall":
      return { command: {
        oneofKind: "moveCall",
        moveCall: {
          package: cmd.MoveCall.package,
          module: cmd.MoveCall.module,
          function: cmd.MoveCall.function,
          typeArguments: cmd.MoveCall.typeArguments,
          arguments: cmd.MoveCall.arguments.map(tsArgumentToGrpcArgument)
        }
      } };
    case "TransferObjects":
      return { command: {
        oneofKind: "transferObjects",
        transferObjects: {
          objects: cmd.TransferObjects.objects.map(tsArgumentToGrpcArgument),
          address: tsArgumentToGrpcArgument(cmd.TransferObjects.address)
        }
      } };
    case "SplitCoins":
      return { command: {
        oneofKind: "splitCoins",
        splitCoins: {
          coin: tsArgumentToGrpcArgument(cmd.SplitCoins.coin),
          amounts: cmd.SplitCoins.amounts.map(tsArgumentToGrpcArgument)
        }
      } };
    case "MergeCoins":
      return { command: {
        oneofKind: "mergeCoins",
        mergeCoins: {
          coin: tsArgumentToGrpcArgument(cmd.MergeCoins.destination),
          coinsToMerge: cmd.MergeCoins.sources.map(tsArgumentToGrpcArgument)
        }
      } };
    case "Publish":
      return { command: {
        oneofKind: "publish",
        publish: {
          modules: cmd.Publish.modules.map((m) => fromBase643(m)),
          dependencies: cmd.Publish.dependencies
        }
      } };
    case "MakeMoveVec":
      return { command: {
        oneofKind: "makeMoveVector",
        makeMoveVector: {
          elementType: cmd.MakeMoveVec.type ?? void 0,
          elements: cmd.MakeMoveVec.elements.map(tsArgumentToGrpcArgument)
        }
      } };
    case "Upgrade":
      return { command: {
        oneofKind: "upgrade",
        upgrade: {
          modules: cmd.Upgrade.modules.map((m) => fromBase643(m)),
          dependencies: cmd.Upgrade.dependencies,
          package: cmd.Upgrade.package,
          ticket: tsArgumentToGrpcArgument(cmd.Upgrade.ticket)
        }
      } };
    default:
      throw new Error(`Unknown Command kind: ${JSON.stringify(cmd)}`);
  }
}
function transactionDataToGrpcTransaction(data) {
  const transaction = {
    version: 1,
    kind: { data: {
      oneofKind: "programmableTransaction",
      programmableTransaction: {
        inputs: data.inputs.map(callArgToGrpcInput),
        commands: data.commands.map(tsCommandToGrpcCommand)
      }
    } }
  };
  if (data.sender) transaction.sender = data.sender;
  const gasOwner = data.gasData.owner ?? data.sender;
  transaction.gasPayment = {
    objects: data.gasData.payment ? data.gasData.payment.map((ref) => ({
      objectId: ref.objectId,
      version: BigInt(ref.version),
      digest: ref.digest
    })) : [],
    price: data.gasData.price ? BigInt(data.gasData.price) : void 0,
    budget: data.gasData.budget ? BigInt(data.gasData.budget) : void 0
  };
  if (gasOwner) transaction.gasPayment.owner = gasOwner;
  if (data.expiration) {
    if ("None" in data.expiration) transaction.expiration = { kind: TransactionExpiration_TransactionExpirationKind.NONE };
    else if (data.expiration.$kind === "Epoch") transaction.expiration = {
      kind: TransactionExpiration_TransactionExpirationKind.EPOCH,
      epoch: BigInt(data.expiration.Epoch)
    };
    else if (data.expiration.$kind === "ValidDuring" || data.expiration.$kind === "Validity") {
      const validity = data.expiration.$kind === "ValidDuring" ? data.expiration.ValidDuring : data.expiration.Validity;
      const allowedProposers = data.expiration.$kind === "Validity" ? data.expiration.Validity.allowedProposers : null;
      transaction.expiration = {
        kind: data.expiration.$kind === "ValidDuring" ? TransactionExpiration_TransactionExpirationKind.VALID_DURING : TransactionExpiration_TransactionExpirationKind.VALIDITY,
        minEpoch: validity.minEpoch != null ? BigInt(validity.minEpoch) : void 0,
        epoch: validity.maxEpoch != null ? BigInt(validity.maxEpoch) : void 0,
        minTimestamp: validity.minTimestamp != null ? millisecondsToGrpcTimestamp(validity.minTimestamp) : void 0,
        maxTimestamp: validity.maxTimestamp != null ? millisecondsToGrpcTimestamp(validity.maxTimestamp) : void 0,
        chain: validity.chain,
        nonce: validity.nonce,
        allowedProposers: allowedProposers ? {
          epoch: BigInt(allowedProposers.epoch),
          proposers: assertAllowedProposersStrictlyIncreasing(allowedProposers.proposers)
        } : void 0
      };
    }
  }
  return transaction;
}
function applyGrpcResolvedTransaction(transactionData, resolvedTransaction, options) {
  const resolved = grpcTransactionToTransactionData(resolvedTransaction);
  if (options?.onlyTransactionKind) transactionData.applyResolvedData({
    ...resolved,
    sender: null,
    gasData: {
      budget: null,
      owner: null,
      payment: null,
      price: null
    },
    expiration: null
  });
  else transactionData.applyResolvedData(resolved);
}
function transactionToGrpcTransaction(transaction) {
  const snapshot = transaction.getData();
  if (!snapshot.sender) snapshot.sender = "0x0000000000000000000000000000000000000000000000000000000000000000";
  return transactionDataToGrpcTransaction(snapshot);
}
function transactionToGrpcJson(transaction) {
  const grpcTransaction = transactionToGrpcTransaction(transaction);
  return Transaction.toJson(grpcTransaction);
}
function grpcInputToCallArg(input) {
  switch (input.kind) {
    case Input_InputKind.PURE:
      return {
        $kind: "Pure",
        Pure: { bytes: toBase644(input.pure) }
      };
    case Input_InputKind.IMMUTABLE_OR_OWNED:
      return {
        $kind: "Object",
        Object: {
          $kind: "ImmOrOwnedObject",
          ImmOrOwnedObject: {
            objectId: input.objectId,
            version: input.version.toString(),
            digest: input.digest
          }
        }
      };
    case Input_InputKind.SHARED:
      return {
        $kind: "Object",
        Object: {
          $kind: "SharedObject",
          SharedObject: {
            objectId: input.objectId,
            initialSharedVersion: input.version.toString(),
            mutable: input.mutable ?? false
          }
        }
      };
    case Input_InputKind.RECEIVING:
      return {
        $kind: "Object",
        Object: {
          $kind: "Receiving",
          Receiving: {
            objectId: input.objectId,
            version: input.version.toString(),
            digest: input.digest
          }
        }
      };
    case Input_InputKind.FUNDS_WITHDRAWAL:
      return {
        $kind: "FundsWithdrawal",
        FundsWithdrawal: {
          reservation: {
            $kind: "MaxAmountU64",
            MaxAmountU64: input.fundsWithdrawal?.amount?.toString() ?? "0"
          },
          typeArg: {
            $kind: "Balance",
            Balance: input.fundsWithdrawal?.coinType ?? "0x2::sui::SUI"
          },
          withdrawFrom: grpcWithdrawFromToTs(input.fundsWithdrawal)
        }
      };
    default:
      throw new Error(`Unknown Input kind: ${JSON.stringify(input)}`);
  }
}
function grpcArgumentToTsArgument(arg) {
  switch (arg.kind) {
    case Argument_ArgumentKind.GAS:
      return {
        $kind: "GasCoin",
        GasCoin: true
      };
    case Argument_ArgumentKind.INPUT:
      return {
        $kind: "Input",
        Input: arg.input
      };
    case Argument_ArgumentKind.RESULT:
      if (arg.subresult != null) return {
        $kind: "NestedResult",
        NestedResult: [arg.result, arg.subresult]
      };
      return {
        $kind: "Result",
        Result: arg.result
      };
    default:
      throw new Error(`Unknown Argument kind: ${JSON.stringify(arg)}`);
  }
}
function grpcCommandToTsCommand(cmd) {
  const command = cmd.command;
  if (!command) throw new Error("Command is missing");
  switch (command.oneofKind) {
    case "moveCall":
      return {
        $kind: "MoveCall",
        MoveCall: {
          package: command.moveCall.package,
          module: command.moveCall.module,
          function: command.moveCall.function,
          typeArguments: command.moveCall.typeArguments ?? [],
          arguments: command.moveCall.arguments.map(grpcArgumentToTsArgument)
        }
      };
    case "transferObjects":
      return {
        $kind: "TransferObjects",
        TransferObjects: {
          objects: command.transferObjects.objects.map(grpcArgumentToTsArgument),
          address: grpcArgumentToTsArgument(command.transferObjects.address)
        }
      };
    case "splitCoins":
      return {
        $kind: "SplitCoins",
        SplitCoins: {
          coin: grpcArgumentToTsArgument(command.splitCoins.coin),
          amounts: command.splitCoins.amounts.map(grpcArgumentToTsArgument)
        }
      };
    case "mergeCoins":
      return {
        $kind: "MergeCoins",
        MergeCoins: {
          destination: grpcArgumentToTsArgument(command.mergeCoins.coin),
          sources: command.mergeCoins.coinsToMerge.map(grpcArgumentToTsArgument)
        }
      };
    case "publish":
      return {
        $kind: "Publish",
        Publish: {
          modules: command.publish.modules.map((m) => toBase644(m)),
          dependencies: command.publish.dependencies ?? []
        }
      };
    case "makeMoveVector":
      return {
        $kind: "MakeMoveVec",
        MakeMoveVec: {
          type: command.makeMoveVector.elementType ?? null,
          elements: command.makeMoveVector.elements.map(grpcArgumentToTsArgument)
        }
      };
    case "upgrade":
      return {
        $kind: "Upgrade",
        Upgrade: {
          modules: command.upgrade.modules.map((m) => toBase644(m)),
          dependencies: command.upgrade.dependencies ?? [],
          package: command.upgrade.package,
          ticket: grpcArgumentToTsArgument(command.upgrade.ticket)
        }
      };
    default:
      throw new Error(`Unknown Command kind: ${JSON.stringify(command)}`);
  }
}
function grpcTransactionToTransactionData(grpcTx) {
  const programmableTx = grpcTx.kind?.data;
  if (programmableTx?.oneofKind !== "programmableTransaction") throw new Error("Only programmable transactions are supported");
  const inputs = programmableTx.programmableTransaction.inputs.map(grpcInputToCallArg);
  const commands = programmableTx.programmableTransaction.commands.map(grpcCommandToTsCommand);
  let expiration = null;
  if (grpcTx.expiration) switch (grpcTx.expiration.kind) {
    case TransactionExpiration_TransactionExpirationKind.NONE:
      expiration = {
        $kind: "None",
        None: true
      };
      break;
    case TransactionExpiration_TransactionExpirationKind.EPOCH:
      expiration = {
        $kind: "Epoch",
        Epoch: grpcTx.expiration.epoch.toString()
      };
      break;
    case TransactionExpiration_TransactionExpirationKind.VALID_DURING:
      expiration = {
        $kind: "ValidDuring",
        ValidDuring: {
          minEpoch: grpcTx.expiration.minEpoch?.toString() ?? null,
          maxEpoch: grpcTx.expiration.epoch?.toString() ?? null,
          minTimestamp: grpcTx.expiration.minTimestamp ? grpcTimestampToMilliseconds(grpcTx.expiration.minTimestamp) : null,
          maxTimestamp: grpcTx.expiration.maxTimestamp ? grpcTimestampToMilliseconds(grpcTx.expiration.maxTimestamp) : null,
          chain: grpcTx.expiration.chain ?? "",
          nonce: grpcTx.expiration.nonce ?? 0
        }
      };
      break;
    case TransactionExpiration_TransactionExpirationKind.VALIDITY:
      expiration = {
        $kind: "Validity",
        Validity: {
          minEpoch: grpcTx.expiration.minEpoch?.toString() ?? null,
          maxEpoch: grpcTx.expiration.epoch?.toString() ?? null,
          minTimestamp: grpcTx.expiration.minTimestamp ? grpcTimestampToMilliseconds(grpcTx.expiration.minTimestamp) : null,
          maxTimestamp: grpcTx.expiration.maxTimestamp ? grpcTimestampToMilliseconds(grpcTx.expiration.maxTimestamp) : null,
          chain: grpcTx.expiration.chain ?? "",
          nonce: grpcTx.expiration.nonce ?? 0,
          allowedProposers: grpcTx.expiration.allowedProposers ? {
            epoch: grpcTx.expiration.allowedProposers.epoch?.toString() ?? "0",
            proposers: assertAllowedProposersNotEmpty(grpcTx.expiration.allowedProposers.proposers)
          } : null
        }
      };
      break;
    default:
      throw new Error(`Unknown transaction expiration kind: ${grpcTx.expiration.kind}`);
  }
  return {
    version: 2,
    sender: grpcTx.sender ?? null,
    expiration,
    gasData: {
      budget: grpcTx.gasPayment?.budget?.toString() ?? null,
      owner: grpcTx.gasPayment?.owner ?? null,
      payment: grpcTx.gasPayment?.objects?.map((obj) => ({
        objectId: obj.objectId,
        version: obj.version.toString(),
        digest: obj.digest
      })) ?? null,
      price: grpcTx.gasPayment?.price?.toString() ?? null
    },
    inputs,
    commands
  };
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/client/address-balance-transaction-expiration.mjs
async function setAddressBalanceTransactionExpirationFromSimulatedEpoch({ transactionData, client, epoch, originalTransactionData, isTransactionKindOnly, doGasSelection }) {
  if (isTransactionKindOnly || doGasSelection || originalTransactionData.expiration || originalTransactionData.gasData.payment?.length !== 0) return;
  if (transactionData.expiration && transactionData.expiration.$kind !== "None") return;
  const [{ chainIdentifier }, systemStateResult] = await Promise.all([client.core.getChainIdentifier(), epoch == null ? client.core.getCurrentSystemState() : null]);
  const currentEpoch = BigInt(epoch ?? systemStateResult.systemState.epoch);
  transactionData.expiration = {
    $kind: "ValidDuring",
    ValidDuring: {
      minEpoch: String(currentEpoch),
      maxEpoch: String(currentEpoch + 1n),
      minTimestamp: null,
      maxTimestamp: null,
      chain: chainIdentifier,
      nonce: Math.random() * 4294967296 >>> 0
    }
  };
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/execution_status.mjs
import { MessageType as MessageType13 } from "@protobuf-ts/runtime";
var ExecutionError_ExecutionErrorKind = /* @__PURE__ */ (function(ExecutionError_ExecutionErrorKind$1) {
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EXECUTION_ERROR_KIND_UNKNOWN"] = 0] = "EXECUTION_ERROR_KIND_UNKNOWN";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INSUFFICIENT_GAS"] = 1] = "INSUFFICIENT_GAS";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_GAS_OBJECT"] = 2] = "INVALID_GAS_OBJECT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVARIANT_VIOLATION"] = 3] = "INVARIANT_VIOLATION";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["FEATURE_NOT_YET_SUPPORTED"] = 4] = "FEATURE_NOT_YET_SUPPORTED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["OBJECT_TOO_BIG"] = 5] = "OBJECT_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PACKAGE_TOO_BIG"] = 6] = "PACKAGE_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["CIRCULAR_OBJECT_OWNERSHIP"] = 7] = "CIRCULAR_OBJECT_OWNERSHIP";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INSUFFICIENT_COIN_BALANCE"] = 8] = "INSUFFICIENT_COIN_BALANCE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["COIN_BALANCE_OVERFLOW"] = 9] = "COIN_BALANCE_OVERFLOW";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PUBLISH_ERROR_NON_ZERO_ADDRESS"] = 10] = "PUBLISH_ERROR_NON_ZERO_ADDRESS";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["SUI_MOVE_VERIFICATION_ERROR"] = 11] = "SUI_MOVE_VERIFICATION_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_PRIMITIVE_RUNTIME_ERROR"] = 12] = "MOVE_PRIMITIVE_RUNTIME_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_ABORT"] = 13] = "MOVE_ABORT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["VM_VERIFICATION_OR_DESERIALIZATION_ERROR"] = 14] = "VM_VERIFICATION_OR_DESERIALIZATION_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["VM_INVARIANT_VIOLATION"] = 15] = "VM_INVARIANT_VIOLATION";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["FUNCTION_NOT_FOUND"] = 16] = "FUNCTION_NOT_FOUND";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["ARITY_MISMATCH"] = 17] = "ARITY_MISMATCH";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["TYPE_ARITY_MISMATCH"] = 18] = "TYPE_ARITY_MISMATCH";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["NON_ENTRY_FUNCTION_INVOKED"] = 19] = "NON_ENTRY_FUNCTION_INVOKED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["COMMAND_ARGUMENT_ERROR"] = 20] = "COMMAND_ARGUMENT_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["TYPE_ARGUMENT_ERROR"] = 21] = "TYPE_ARGUMENT_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["UNUSED_VALUE_WITHOUT_DROP"] = 22] = "UNUSED_VALUE_WITHOUT_DROP";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_PUBLIC_FUNCTION_RETURN_TYPE"] = 23] = "INVALID_PUBLIC_FUNCTION_RETURN_TYPE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_TRANSFER_OBJECT"] = 24] = "INVALID_TRANSFER_OBJECT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EFFECTS_TOO_LARGE"] = 25] = "EFFECTS_TOO_LARGE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PUBLISH_UPGRADE_MISSING_DEPENDENCY"] = 26] = "PUBLISH_UPGRADE_MISSING_DEPENDENCY";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PUBLISH_UPGRADE_DEPENDENCY_DOWNGRADE"] = 27] = "PUBLISH_UPGRADE_DEPENDENCY_DOWNGRADE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PACKAGE_UPGRADE_ERROR"] = 28] = "PACKAGE_UPGRADE_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["WRITTEN_OBJECTS_TOO_LARGE"] = 29] = "WRITTEN_OBJECTS_TOO_LARGE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["CERTIFICATE_DENIED"] = 30] = "CERTIFICATE_DENIED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["SUI_MOVE_VERIFICATION_TIMEDOUT"] = 31] = "SUI_MOVE_VERIFICATION_TIMEDOUT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED"] = 32] = "CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INPUT_OBJECT_DELETED"] = 33] = "INPUT_OBJECT_DELETED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EXECUTION_CANCELED_DUE_TO_CONSENSUS_OBJECT_CONGESTION"] = 34] = "EXECUTION_CANCELED_DUE_TO_CONSENSUS_OBJECT_CONGESTION";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["ADDRESS_DENIED_FOR_COIN"] = 35] = "ADDRESS_DENIED_FOR_COIN";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["COIN_TYPE_GLOBAL_PAUSE"] = 36] = "COIN_TYPE_GLOBAL_PAUSE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EXECUTION_CANCELED_DUE_TO_RANDOMNESS_UNAVAILABLE"] = 37] = "EXECUTION_CANCELED_DUE_TO_RANDOMNESS_UNAVAILABLE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_VECTOR_ELEM_TOO_BIG"] = 38] = "MOVE_VECTOR_ELEM_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_RAW_VALUE_TOO_BIG"] = 39] = "MOVE_RAW_VALUE_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_LINKAGE"] = 40] = "INVALID_LINKAGE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INSUFFICIENT_FUNDS_FOR_WITHDRAW"] = 41] = "INSUFFICIENT_FUNDS_FOR_WITHDRAW";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["NON_EXCLUSIVE_WRITE_INPUT_OBJECT_MODIFIED"] = 42] = "NON_EXCLUSIVE_WRITE_INPUT_OBJECT_MODIFIED";
  return ExecutionError_ExecutionErrorKind$1;
})({});
var CommandArgumentError_CommandArgumentErrorKind = /* @__PURE__ */ (function(CommandArgumentError_CommandArgumentErrorKind$1) {
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["COMMAND_ARGUMENT_ERROR_KIND_UNKNOWN"] = 0] = "COMMAND_ARGUMENT_ERROR_KIND_UNKNOWN";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["TYPE_MISMATCH"] = 1] = "TYPE_MISMATCH";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_BCS_BYTES"] = 2] = "INVALID_BCS_BYTES";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_USAGE_OF_PURE_ARGUMENT"] = 3] = "INVALID_USAGE_OF_PURE_ARGUMENT";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_ARGUMENT_TO_PRIVATE_ENTRY_FUNCTION"] = 4] = "INVALID_ARGUMENT_TO_PRIVATE_ENTRY_FUNCTION";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INDEX_OUT_OF_BOUNDS"] = 5] = "INDEX_OUT_OF_BOUNDS";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["SECONDARY_INDEX_OUT_OF_BOUNDS"] = 6] = "SECONDARY_INDEX_OUT_OF_BOUNDS";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_RESULT_ARITY"] = 7] = "INVALID_RESULT_ARITY";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_GAS_COIN_USAGE"] = 8] = "INVALID_GAS_COIN_USAGE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_VALUE_USAGE"] = 9] = "INVALID_VALUE_USAGE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_OBJECT_BY_VALUE"] = 10] = "INVALID_OBJECT_BY_VALUE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_OBJECT_BY_MUT_REF"] = 11] = "INVALID_OBJECT_BY_MUT_REF";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED"] = 12] = "CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_ARGUMENT_ARITY"] = 13] = "INVALID_ARGUMENT_ARITY";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_TRANSFER_OBJECT"] = 14] = "INVALID_TRANSFER_OBJECT";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_MAKE_MOVE_VEC_NON_OBJECT_ARGUMENT"] = 15] = "INVALID_MAKE_MOVE_VEC_NON_OBJECT_ARGUMENT";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["ARGUMENT_WITHOUT_VALUE"] = 16] = "ARGUMENT_WITHOUT_VALUE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["CANNOT_MOVE_BORROWED_VALUE"] = 17] = "CANNOT_MOVE_BORROWED_VALUE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["CANNOT_WRITE_TO_EXTENDED_REFERENCE"] = 18] = "CANNOT_WRITE_TO_EXTENDED_REFERENCE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_REFERENCE_ARGUMENT"] = 19] = "INVALID_REFERENCE_ARGUMENT";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_TX_CONTEXT"] = 20] = "INVALID_TX_CONTEXT";
  return CommandArgumentError_CommandArgumentErrorKind$1;
})({});
var PackageUpgradeError_PackageUpgradeErrorKind = /* @__PURE__ */ (function(PackageUpgradeError_PackageUpgradeErrorKind$1) {
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["PACKAGE_UPGRADE_ERROR_KIND_UNKNOWN"] = 0] = "PACKAGE_UPGRADE_ERROR_KIND_UNKNOWN";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["UNABLE_TO_FETCH_PACKAGE"] = 1] = "UNABLE_TO_FETCH_PACKAGE";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["NOT_A_PACKAGE"] = 2] = "NOT_A_PACKAGE";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["INCOMPATIBLE_UPGRADE"] = 3] = "INCOMPATIBLE_UPGRADE";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["DIGEST_DOES_NOT_MATCH"] = 4] = "DIGEST_DOES_NOT_MATCH";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["UNKNOWN_UPGRADE_POLICY"] = 5] = "UNKNOWN_UPGRADE_POLICY";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["PACKAGE_ID_DOES_NOT_MATCH"] = 6] = "PACKAGE_ID_DOES_NOT_MATCH";
  return PackageUpgradeError_PackageUpgradeErrorKind$1;
})({});
var TypeArgumentError_TypeArgumentErrorKind = /* @__PURE__ */ (function(TypeArgumentError_TypeArgumentErrorKind$1) {
  TypeArgumentError_TypeArgumentErrorKind$1[TypeArgumentError_TypeArgumentErrorKind$1["TYPE_ARGUMENT_ERROR_KIND_UNKNOWN"] = 0] = "TYPE_ARGUMENT_ERROR_KIND_UNKNOWN";
  TypeArgumentError_TypeArgumentErrorKind$1[TypeArgumentError_TypeArgumentErrorKind$1["TYPE_NOT_FOUND"] = 1] = "TYPE_NOT_FOUND";
  TypeArgumentError_TypeArgumentErrorKind$1[TypeArgumentError_TypeArgumentErrorKind$1["CONSTRAINT_NOT_SATISFIED"] = 2] = "CONSTRAINT_NOT_SATISFIED";
  return TypeArgumentError_TypeArgumentErrorKind$1;
})({});
var ExecutionStatus$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.ExecutionStatus", [{
      no: 1,
      name: "success",
      kind: "scalar",
      opt: true,
      T: 8
    }, {
      no: 2,
      name: "error",
      kind: "message",
      T: () => ExecutionError
    }]);
  }
};
var ExecutionStatus2 = new ExecutionStatus$Type();
var ExecutionError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.ExecutionError", [
      {
        no: 1,
        name: "description",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "command",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.ExecutionError.ExecutionErrorKind", ExecutionError_ExecutionErrorKind]
      },
      {
        no: 4,
        name: "abort",
        kind: "message",
        oneof: "errorDetails",
        T: () => MoveAbort
      },
      {
        no: 5,
        name: "size_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => SizeError
      },
      {
        no: 6,
        name: "command_argument_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => CommandArgumentError2
      },
      {
        no: 7,
        name: "type_argument_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => TypeArgumentError2
      },
      {
        no: 8,
        name: "package_upgrade_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => PackageUpgradeError2
      },
      {
        no: 9,
        name: "index_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => IndexError
      },
      {
        no: 10,
        name: "object_id",
        kind: "scalar",
        oneof: "errorDetails",
        T: 9
      },
      {
        no: 11,
        name: "coin_deny_list_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => CoinDenyListError
      },
      {
        no: 12,
        name: "congested_objects",
        kind: "message",
        oneof: "errorDetails",
        T: () => CongestedObjects
      }
    ]);
  }
};
var ExecutionError = new ExecutionError$Type();
var MoveAbort$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.MoveAbort", [
      {
        no: 1,
        name: "abort_code",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "location",
        kind: "message",
        T: () => MoveLocation2
      },
      {
        no: 3,
        name: "clever_error",
        kind: "message",
        T: () => CleverError
      }
    ]);
  }
};
var MoveAbort = new MoveAbort$Type();
var MoveLocation$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.MoveLocation", [
      {
        no: 1,
        name: "package",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "function",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 4,
        name: "instruction",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 5,
        name: "function_name",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var MoveLocation2 = new MoveLocation$Type();
var CleverError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.CleverError", [
      {
        no: 1,
        name: "error_code",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "line_number",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "constant_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "constant_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "rendered",
        kind: "scalar",
        oneof: "value",
        T: 9
      },
      {
        no: 6,
        name: "raw",
        kind: "scalar",
        oneof: "value",
        T: 12
      }
    ]);
  }
};
var CleverError = new CleverError$Type();
var SizeError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.SizeError", [{
      no: 1,
      name: "size",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "max_size",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var SizeError = new SizeError$Type();
var IndexError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.IndexError", [{
      no: 1,
      name: "index",
      kind: "scalar",
      opt: true,
      T: 13
    }, {
      no: 2,
      name: "subresult",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var IndexError = new IndexError$Type();
var CoinDenyListError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.CoinDenyListError", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "coin_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var CoinDenyListError = new CoinDenyListError$Type();
var CongestedObjects$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.CongestedObjects", [{
      no: 1,
      name: "objects",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
};
var CongestedObjects = new CongestedObjects$Type();
var CommandArgumentError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.CommandArgumentError", [
      {
        no: 1,
        name: "argument",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 2,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.CommandArgumentError.CommandArgumentErrorKind", CommandArgumentError_CommandArgumentErrorKind]
      },
      {
        no: 3,
        name: "index_error",
        kind: "message",
        T: () => IndexError
      }
    ]);
  }
};
var CommandArgumentError2 = new CommandArgumentError$Type();
var PackageUpgradeError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.PackageUpgradeError", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.PackageUpgradeError.PackageUpgradeErrorKind", PackageUpgradeError_PackageUpgradeErrorKind]
      },
      {
        no: 2,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "policy",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 5,
        name: "ticket_id",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var PackageUpgradeError2 = new PackageUpgradeError$Type();
var TypeArgumentError$Type = class extends MessageType13 {
  constructor() {
    super("sui.rpc.v2.TypeArgumentError", [{
      no: 1,
      name: "type_argument",
      kind: "scalar",
      opt: true,
      T: 13
    }, {
      no: 2,
      name: "kind",
      kind: "enum",
      opt: true,
      T: () => ["sui.rpc.v2.TypeArgumentError.TypeArgumentErrorKind", TypeArgumentError_TypeArgumentErrorKind]
    }]);
  }
};
var TypeArgumentError2 = new TypeArgumentError$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/gas_cost_summary.mjs
import { MessageType as MessageType14 } from "@protobuf-ts/runtime";
var GasCostSummary$Type = class extends MessageType14 {
  constructor() {
    super("sui.rpc.v2.GasCostSummary", [
      {
        no: 1,
        name: "computation_cost",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "storage_cost",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "storage_rebate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "non_refundable_storage_fee",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var GasCostSummary2 = new GasCostSummary$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/effects.mjs
import { MessageType as MessageType15 } from "@protobuf-ts/runtime";
var ChangedObject_InputObjectState = /* @__PURE__ */ (function(ChangedObject_InputObjectState$1) {
  ChangedObject_InputObjectState$1[ChangedObject_InputObjectState$1["UNKNOWN"] = 0] = "UNKNOWN";
  ChangedObject_InputObjectState$1[ChangedObject_InputObjectState$1["DOES_NOT_EXIST"] = 1] = "DOES_NOT_EXIST";
  ChangedObject_InputObjectState$1[ChangedObject_InputObjectState$1["EXISTS"] = 2] = "EXISTS";
  return ChangedObject_InputObjectState$1;
})({});
var ChangedObject_OutputObjectState = /* @__PURE__ */ (function(ChangedObject_OutputObjectState$1) {
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["UNKNOWN"] = 0] = "UNKNOWN";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["DOES_NOT_EXIST"] = 1] = "DOES_NOT_EXIST";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["OBJECT_WRITE"] = 2] = "OBJECT_WRITE";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["PACKAGE_WRITE"] = 3] = "PACKAGE_WRITE";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["ACCUMULATOR_WRITE"] = 4] = "ACCUMULATOR_WRITE";
  return ChangedObject_OutputObjectState$1;
})({});
var ChangedObject_IdOperation = /* @__PURE__ */ (function(ChangedObject_IdOperation$1) {
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["ID_OPERATION_UNKNOWN"] = 0] = "ID_OPERATION_UNKNOWN";
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["NONE"] = 1] = "NONE";
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["CREATED"] = 2] = "CREATED";
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["DELETED"] = 3] = "DELETED";
  return ChangedObject_IdOperation$1;
})({});
var AccumulatorWrite_AccumulatorOperation = /* @__PURE__ */ (function(AccumulatorWrite_AccumulatorOperation$1) {
  AccumulatorWrite_AccumulatorOperation$1[AccumulatorWrite_AccumulatorOperation$1["ACCUMULATOR_OPERATION_UNKNOWN"] = 0] = "ACCUMULATOR_OPERATION_UNKNOWN";
  AccumulatorWrite_AccumulatorOperation$1[AccumulatorWrite_AccumulatorOperation$1["MERGE"] = 1] = "MERGE";
  AccumulatorWrite_AccumulatorOperation$1[AccumulatorWrite_AccumulatorOperation$1["SPLIT"] = 2] = "SPLIT";
  return AccumulatorWrite_AccumulatorOperation$1;
})({});
var AccumulatorWrite_AccumulatorValue = /* @__PURE__ */ (function(AccumulatorWrite_AccumulatorValue$1) {
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["ACCUMULATOR_VALUE_UNKNOWN"] = 0] = "ACCUMULATOR_VALUE_UNKNOWN";
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["INTEGER"] = 1] = "INTEGER";
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["INTEGER_TUPLE"] = 2] = "INTEGER_TUPLE";
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["EVENT_DIGEST"] = 3] = "EVENT_DIGEST";
  return AccumulatorWrite_AccumulatorValue$1;
})({});
var UnchangedConsensusObject_UnchangedConsensusObjectKind = /* @__PURE__ */ (function(UnchangedConsensusObject_UnchangedConsensusObjectKind$1) {
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["UNCHANGED_CONSENSUS_OBJECT_KIND_UNKNOWN"] = 0] = "UNCHANGED_CONSENSUS_OBJECT_KIND_UNKNOWN";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["READ_ONLY_ROOT"] = 1] = "READ_ONLY_ROOT";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["MUTATE_CONSENSUS_STREAM_ENDED"] = 2] = "MUTATE_CONSENSUS_STREAM_ENDED";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["READ_CONSENSUS_STREAM_ENDED"] = 3] = "READ_CONSENSUS_STREAM_ENDED";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["CANCELED"] = 4] = "CANCELED";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["PER_EPOCH_CONFIG"] = 5] = "PER_EPOCH_CONFIG";
  return UnchangedConsensusObject_UnchangedConsensusObjectKind$1;
})({});
var TransactionEffects$Type = class extends MessageType15 {
  constructor() {
    super("sui.rpc.v2.TransactionEffects", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 5
      },
      {
        no: 4,
        name: "status",
        kind: "message",
        T: () => ExecutionStatus2
      },
      {
        no: 5,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "gas_used",
        kind: "message",
        T: () => GasCostSummary2
      },
      {
        no: 7,
        name: "transaction_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "gas_object",
        kind: "message",
        T: () => ChangedObject
      },
      {
        no: 9,
        name: "events_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 10,
        name: "dependencies",
        kind: "scalar",
        repeat: 2,
        T: 9
      },
      {
        no: 11,
        name: "lamport_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 12,
        name: "changed_objects",
        kind: "message",
        repeat: 2,
        T: () => ChangedObject
      },
      {
        no: 13,
        name: "unchanged_consensus_objects",
        kind: "message",
        repeat: 2,
        T: () => UnchangedConsensusObject
      },
      {
        no: 14,
        name: "auxiliary_data_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 15,
        name: "unchanged_loaded_runtime_objects",
        kind: "message",
        repeat: 2,
        T: () => ObjectReference
      }
    ]);
  }
};
var TransactionEffects2 = new TransactionEffects$Type();
var ChangedObject$Type = class extends MessageType15 {
  constructor() {
    super("sui.rpc.v2.ChangedObject", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "input_state",
        kind: "enum",
        opt: true,
        T: () => [
          "sui.rpc.v2.ChangedObject.InputObjectState",
          ChangedObject_InputObjectState,
          "INPUT_OBJECT_STATE_"
        ]
      },
      {
        no: 3,
        name: "input_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "input_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "input_owner",
        kind: "message",
        T: () => Owner2
      },
      {
        no: 6,
        name: "output_state",
        kind: "enum",
        opt: true,
        T: () => [
          "sui.rpc.v2.ChangedObject.OutputObjectState",
          ChangedObject_OutputObjectState,
          "OUTPUT_OBJECT_STATE_"
        ]
      },
      {
        no: 7,
        name: "output_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "output_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 9,
        name: "output_owner",
        kind: "message",
        T: () => Owner2
      },
      {
        no: 12,
        name: "accumulator_write",
        kind: "message",
        T: () => AccumulatorWrite
      },
      {
        no: 10,
        name: "id_operation",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.ChangedObject.IdOperation", ChangedObject_IdOperation]
      },
      {
        no: 11,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ChangedObject = new ChangedObject$Type();
var EventDigestEntry$Type = class extends MessageType15 {
  constructor() {
    super("sui.rpc.v2.EventDigestEntry", [{
      no: 1,
      name: "event_index",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EventDigestEntry = new EventDigestEntry$Type();
var AccumulatorWrite$Type = class extends MessageType15 {
  constructor() {
    super("sui.rpc.v2.AccumulatorWrite", [
      {
        no: 1,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "accumulator_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "operation",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.AccumulatorWrite.AccumulatorOperation", AccumulatorWrite_AccumulatorOperation]
      },
      {
        no: 4,
        name: "value_kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.AccumulatorWrite.AccumulatorValue", AccumulatorWrite_AccumulatorValue]
      },
      {
        no: 5,
        name: "integer_value",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "integer_tuple",
        kind: "scalar",
        repeat: 1,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "event_digest_value",
        kind: "message",
        repeat: 2,
        T: () => EventDigestEntry
      }
    ]);
  }
};
var AccumulatorWrite = new AccumulatorWrite$Type();
var UnchangedConsensusObject$Type = class extends MessageType15 {
  constructor() {
    super("sui.rpc.v2.UnchangedConsensusObject", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.UnchangedConsensusObject.UnchangedConsensusObjectKind", UnchangedConsensusObject_UnchangedConsensusObjectKind]
      },
      {
        no: 2,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var UnchangedConsensusObject = new UnchangedConsensusObject$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/client/query-filters.mjs
var DEFAULT_PAGE_SIZE = 50;
function resolvePagination(options) {
  if (options.after != null && options.before != null) throw new Error("Only one of `after` or `before` may be provided");
  const descending = options.order ? options.order === "descending" : options.before != null;
  if (options.after != null && descending) throw new Error("`after` can not be combined with descending queries");
  if (options.before != null && !descending) throw new Error("`before` can not be combined with ascending queries");
  return {
    descending,
    after: options.after ?? void 0,
    before: options.before ?? void 0,
    limit: options.limit ?? DEFAULT_PAGE_SIZE
  };
}
function validateTransactionQuery(filter, pagination) {
  if (filter?.$kind === "function" && (pagination.after != null || pagination.before != null) && (!filter.module || !filter.function)) throw new Error("Paginating transactions filtered by function requires a fully qualified `package::module::function`");
}
async function resolveTransactionFilter(mvr, filter, signal) {
  assertSinglePredicate(filter, ["sender", "function"], "transaction");
  if (filter.sender != null) return {
    $kind: "sender",
    sender: normalizeSuiAddress(filter.sender)
  };
  const [pkg, module, fn, ...rest] = filter.function.split("::");
  if (!pkg || rest.length > 0 || module === "" || fn === "") throw new Error(`Invalid function filter "${filter.function}": expected "package", "package::module", or "package::module::function"`);
  return {
    $kind: "function",
    package: normalizeSuiAddress((await mvr.resolvePackage({
      package: pkg,
      signal
    })).package),
    module,
    function: fn
  };
}
async function resolveEventFilter(mvr, filter, signal) {
  assertSinglePredicate(filter, [
    "sender",
    "emitModule",
    "eventType"
  ], "event");
  if (filter.sender != null) return {
    $kind: "sender",
    sender: normalizeSuiAddress(filter.sender)
  };
  if (filter.emitModule != null) {
    const [pkg, module, ...rest] = filter.emitModule.split("::");
    if (!pkg || !module || rest.length > 0) throw new Error(`Invalid emitModule filter "${filter.emitModule}": expected "package::module"`);
    return {
      $kind: "emitModule",
      package: normalizeSuiAddress((await mvr.resolvePackage({
        package: pkg,
        signal
      })).package),
      module
    };
  }
  const eventType = filter.eventType;
  const segments = eventType.split("::");
  if (segments.length === 2 && segments.every((segment) => segment !== "")) return {
    $kind: "eventTypeModule",
    package: normalizeSuiAddress((await mvr.resolvePackage({
      package: segments[0],
      signal
    })).package),
    module: segments[1]
  };
  if (segments.length < 3 || segments.some((segment) => segment === "")) throw new Error(`Invalid eventType filter "${eventType}": expected "package::module" or a fully qualified type name`);
  return {
    $kind: "eventType",
    eventType: (await mvr.resolveType({
      type: eventType,
      signal
    })).type
  };
}
function assertSinglePredicate(filter, predicates, kind) {
  const present = predicates.filter((predicate) => filter[predicate] != null);
  if (present.length !== 1) throw new Error(`A ${kind} filter must specify exactly one of ${predicates.join(", ")}${present.length ? ` (got ${present.join(", ")})` : ""}`);
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/balance_change.mjs
import { MessageType as MessageType16 } from "@protobuf-ts/runtime";
var BalanceChange$Type = class extends MessageType16 {
  constructor() {
    super("sui.rpc.v2.BalanceChange", [
      {
        no: 1,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "amount",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var BalanceChange = new BalanceChange$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/event.mjs
import { MessageType as MessageType17 } from "@protobuf-ts/runtime";
var TransactionEvents$Type = class extends MessageType17 {
  constructor() {
    super("sui.rpc.v2.TransactionEvents", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "events",
        kind: "message",
        repeat: 2,
        T: () => Event
      }
    ]);
  }
};
var TransactionEvents = new TransactionEvents$Type();
var Event$Type = class extends MessageType17 {
  constructor() {
    super("sui.rpc.v2.Event", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "sender",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "event_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "contents",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 6,
        name: "json",
        kind: "message",
        T: () => Value
      },
      {
        no: 7,
        name: "checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "transaction_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 9,
        name: "transaction_index",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 10,
        name: "event_index",
        kind: "scalar",
        opt: true,
        T: 13
      }
    ]);
  }
};
var Event = new Event$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature_scheme.mjs
var SignatureScheme = /* @__PURE__ */ (function(SignatureScheme$1) {
  SignatureScheme$1[SignatureScheme$1["ED25519"] = 0] = "ED25519";
  SignatureScheme$1[SignatureScheme$1["SECP256K1"] = 1] = "SECP256K1";
  SignatureScheme$1[SignatureScheme$1["SECP256R1"] = 2] = "SECP256R1";
  SignatureScheme$1[SignatureScheme$1["MULTISIG"] = 3] = "MULTISIG";
  SignatureScheme$1[SignatureScheme$1["BLS12381"] = 4] = "BLS12381";
  SignatureScheme$1[SignatureScheme$1["ZKLOGIN"] = 5] = "ZKLOGIN";
  SignatureScheme$1[SignatureScheme$1["PASSKEY"] = 6] = "PASSKEY";
  return SignatureScheme$1;
})({});

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature.mjs
import { MessageType as MessageType18 } from "@protobuf-ts/runtime";
var UserSignature$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.UserSignature", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 3,
        name: "simple",
        kind: "message",
        oneof: "signature",
        T: () => SimpleSignature
      },
      {
        no: 4,
        name: "multisig",
        kind: "message",
        oneof: "signature",
        T: () => MultisigAggregatedSignature
      },
      {
        no: 5,
        name: "zklogin",
        kind: "message",
        oneof: "signature",
        T: () => ZkLoginAuthenticator
      },
      {
        no: 6,
        name: "passkey",
        kind: "message",
        oneof: "signature",
        T: () => PasskeyAuthenticator2
      }
    ]);
  }
};
var UserSignature = new UserSignature$Type();
var SimpleSignature$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.SimpleSignature", [
      {
        no: 1,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 2,
        name: "signature",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "public_key",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var SimpleSignature = new SimpleSignature$Type();
var ZkLoginPublicIdentifier$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ZkLoginPublicIdentifier", [{
      no: 1,
      name: "iss",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "address_seed",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var ZkLoginPublicIdentifier = new ZkLoginPublicIdentifier$Type();
var MultisigMemberPublicKey$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.MultisigMemberPublicKey", [
      {
        no: 1,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 2,
        name: "public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "zklogin",
        kind: "message",
        T: () => ZkLoginPublicIdentifier
      }
    ]);
  }
};
var MultisigMemberPublicKey = new MultisigMemberPublicKey$Type();
var MultisigMember$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.MultisigMember", [{
      no: 1,
      name: "public_key",
      kind: "message",
      T: () => MultisigMemberPublicKey
    }, {
      no: 2,
      name: "weight",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var MultisigMember = new MultisigMember$Type();
var MultisigCommittee$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.MultisigCommittee", [{
      no: 1,
      name: "members",
      kind: "message",
      repeat: 2,
      T: () => MultisigMember
    }, {
      no: 2,
      name: "threshold",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var MultisigCommittee = new MultisigCommittee$Type();
var MultisigAggregatedSignature$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.MultisigAggregatedSignature", [
      {
        no: 1,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => MultisigMemberSignature
      },
      {
        no: 2,
        name: "bitmap",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "legacy_bitmap",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "committee",
        kind: "message",
        T: () => MultisigCommittee
      }
    ]);
  }
};
var MultisigAggregatedSignature = new MultisigAggregatedSignature$Type();
var MultisigMemberSignature$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.MultisigMemberSignature", [
      {
        no: 1,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 2,
        name: "signature",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "zklogin",
        kind: "message",
        T: () => ZkLoginAuthenticator
      },
      {
        no: 4,
        name: "passkey",
        kind: "message",
        T: () => PasskeyAuthenticator2
      }
    ]);
  }
};
var MultisigMemberSignature = new MultisigMemberSignature$Type();
var ZkLoginAuthenticator$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ZkLoginAuthenticator", [
      {
        no: 1,
        name: "inputs",
        kind: "message",
        T: () => ZkLoginInputs
      },
      {
        no: 2,
        name: "max_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "signature",
        kind: "message",
        T: () => SimpleSignature
      },
      {
        no: 4,
        name: "public_identifier",
        kind: "message",
        T: () => ZkLoginPublicIdentifier
      },
      {
        no: 5,
        name: "jwk_id",
        kind: "message",
        T: () => JwkId
      }
    ]);
  }
};
var ZkLoginAuthenticator = new ZkLoginAuthenticator$Type();
var ZkLoginInputs$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ZkLoginInputs", [
      {
        no: 1,
        name: "proof_points",
        kind: "message",
        T: () => ZkLoginProof
      },
      {
        no: 2,
        name: "iss_base64_details",
        kind: "message",
        T: () => ZkLoginClaim
      },
      {
        no: 3,
        name: "header_base64",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "address_seed",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ZkLoginInputs = new ZkLoginInputs$Type();
var ZkLoginProof$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ZkLoginProof", [
      {
        no: 1,
        name: "a",
        kind: "message",
        T: () => CircomG1
      },
      {
        no: 2,
        name: "b",
        kind: "message",
        T: () => CircomG2
      },
      {
        no: 3,
        name: "c",
        kind: "message",
        T: () => CircomG1
      }
    ]);
  }
};
var ZkLoginProof = new ZkLoginProof$Type();
var ZkLoginClaim$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ZkLoginClaim", [{
      no: 1,
      name: "value",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "index_mod_4",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var ZkLoginClaim = new ZkLoginClaim$Type();
var CircomG1$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.CircomG1", [
      {
        no: 1,
        name: "e0",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "e1",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "e2",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var CircomG1 = new CircomG1$Type();
var CircomG2$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.CircomG2", [
      {
        no: 1,
        name: "e00",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "e01",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "e10",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "e11",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "e20",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "e21",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var CircomG2 = new CircomG2$Type();
var PasskeyAuthenticator$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.PasskeyAuthenticator", [
      {
        no: 1,
        name: "authenticator_data",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 2,
        name: "client_data_json",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "signature",
        kind: "message",
        T: () => SimpleSignature
      }
    ]);
  }
};
var PasskeyAuthenticator2 = new PasskeyAuthenticator$Type();
var ValidatorCommittee$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ValidatorCommittee", [{
      no: 1,
      name: "epoch",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "members",
      kind: "message",
      repeat: 2,
      T: () => ValidatorCommitteeMember
    }]);
  }
};
var ValidatorCommittee = new ValidatorCommittee$Type();
var ValidatorCommitteeMember$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ValidatorCommitteeMember", [{
      no: 1,
      name: "public_key",
      kind: "scalar",
      opt: true,
      T: 12
    }, {
      no: 2,
      name: "weight",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var ValidatorCommitteeMember = new ValidatorCommitteeMember$Type();
var ValidatorAggregatedSignature$Type = class extends MessageType18 {
  constructor() {
    super("sui.rpc.v2.ValidatorAggregatedSignature", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "signature",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "bitmap",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var ValidatorAggregatedSignature = new ValidatorAggregatedSignature$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/executed_transaction.mjs
import { MessageType as MessageType19 } from "@protobuf-ts/runtime";
var ExecutedTransaction$Type = class extends MessageType19 {
  constructor() {
    super("sui.rpc.v2.ExecutedTransaction", [
      {
        no: 1,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "transaction",
        kind: "message",
        T: () => Transaction
      },
      {
        no: 3,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => UserSignature
      },
      {
        no: 4,
        name: "effects",
        kind: "message",
        T: () => TransactionEffects2
      },
      {
        no: 5,
        name: "events",
        kind: "message",
        T: () => TransactionEvents
      },
      {
        no: 6,
        name: "checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 8,
        name: "balance_changes",
        kind: "message",
        repeat: 2,
        T: () => BalanceChange
      },
      {
        no: 9,
        name: "objects",
        kind: "message",
        T: () => ObjectSet
      },
      {
        no: 10,
        name: "transaction_index",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var ExecutedTransaction = new ExecutedTransaction$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/field_mask.mjs
import { MessageType as MessageType20, lowerCamelCase, typeofJsonValue as typeofJsonValue4 } from "@protobuf-ts/runtime";
var FieldMask$Type = class extends MessageType20 {
  constructor() {
    super("google.protobuf.FieldMask", [{
      no: 1,
      name: "paths",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
  /**
  * Encode `FieldMask` to JSON object.
  */
  internalJsonWrite(message, options) {
    const invalidFieldMaskJsonRegex = /[A-Z]|(_([.0-9_]|$))/g;
    return message.paths.map((p) => {
      if (invalidFieldMaskJsonRegex.test(p)) throw new Error('Unable to encode FieldMask to JSON. lowerCamelCase of path name "' + p + '" is irreversible.');
      return lowerCamelCase(p);
    }).join(",");
  }
  /**
  * Decode `FieldMask` from JSON object.
  */
  internalJsonRead(json, options, target) {
    if (typeof json !== "string") throw new Error("Unable to parse FieldMask from JSON " + typeofJsonValue4(json) + ". Expected string.");
    if (!target) target = this.create();
    if (json === "") return target;
    let camelToSnake = (str) => {
      if (str.includes("_")) throw new Error("Unable to parse FieldMask from JSON. Path names must be lowerCamelCase.");
      return str.replace(/[A-Z]/g, (letter) => "_" + letter.toLowerCase());
    };
    target.paths = json.split(",").map(camelToSnake);
    return target;
  }
};
var FieldMask = new FieldMask$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/transaction_execution_service.mjs
import { MessageType as MessageType21 } from "@protobuf-ts/runtime";
import { ServiceType } from "@protobuf-ts/runtime-rpc";
var SimulateTransactionRequest_TransactionChecks = /* @__PURE__ */ (function(SimulateTransactionRequest_TransactionChecks$1) {
  SimulateTransactionRequest_TransactionChecks$1[SimulateTransactionRequest_TransactionChecks$1["ENABLED"] = 0] = "ENABLED";
  SimulateTransactionRequest_TransactionChecks$1[SimulateTransactionRequest_TransactionChecks$1["DISABLED"] = 1] = "DISABLED";
  return SimulateTransactionRequest_TransactionChecks$1;
})({});
var ExecuteTransactionRequest$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.ExecuteTransactionRequest", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => Transaction
      },
      {
        no: 2,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => UserSignature
      },
      {
        no: 3,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var ExecuteTransactionRequest = new ExecuteTransactionRequest$Type();
var ExecuteTransactionResponse$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.ExecuteTransactionResponse", [{
      no: 1,
      name: "transaction",
      kind: "message",
      T: () => ExecutedTransaction
    }]);
  }
};
var ExecuteTransactionResponse = new ExecuteTransactionResponse$Type();
var SimulateTransactionRequest$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.SimulateTransactionRequest", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => Transaction
      },
      {
        no: 2,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 3,
        name: "checks",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SimulateTransactionRequest.TransactionChecks", SimulateTransactionRequest_TransactionChecks]
      },
      {
        no: 4,
        name: "do_gas_selection",
        kind: "scalar",
        opt: true,
        T: 8
      }
    ]);
  }
};
var SimulateTransactionRequest = new SimulateTransactionRequest$Type();
var SimulateTransactionResponse$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.SimulateTransactionResponse", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => ExecutedTransaction
      },
      {
        no: 2,
        name: "command_outputs",
        kind: "message",
        repeat: 2,
        T: () => CommandResult
      },
      {
        no: 3,
        name: "suggested_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var SimulateTransactionResponse = new SimulateTransactionResponse$Type();
var CommandResult$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.CommandResult", [{
      no: 1,
      name: "return_values",
      kind: "message",
      repeat: 2,
      T: () => CommandOutput
    }, {
      no: 2,
      name: "mutated_by_ref",
      kind: "message",
      repeat: 2,
      T: () => CommandOutput
    }]);
  }
};
var CommandResult = new CommandResult$Type();
var CommandOutput$Type = class extends MessageType21 {
  constructor() {
    super("sui.rpc.v2.CommandOutput", [
      {
        no: 1,
        name: "argument",
        kind: "message",
        T: () => Argument2
      },
      {
        no: 2,
        name: "value",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 3,
        name: "json",
        kind: "message",
        T: () => Value
      }
    ]);
  }
};
var CommandOutput = new CommandOutput$Type();
var TransactionExecutionService = new ServiceType("sui.rpc.v2.TransactionExecutionService", [{
  name: "ExecuteTransaction",
  options: {},
  I: ExecuteTransactionRequest,
  O: ExecuteTransactionResponse
}, {
  name: "SimulateTransaction",
  options: {},
  I: SimulateTransactionRequest,
  O: SimulateTransactionResponse
}]);

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/query_options.mjs
import { MessageType as MessageType22 } from "@protobuf-ts/runtime";
var Ordering = /* @__PURE__ */ (function(Ordering$1) {
  Ordering$1[Ordering$1["ASCENDING"] = 0] = "ASCENDING";
  Ordering$1[Ordering$1["DESCENDING"] = 1] = "DESCENDING";
  return Ordering$1;
})({});
var QueryEndReason = /* @__PURE__ */ (function(QueryEndReason$1) {
  QueryEndReason$1[QueryEndReason$1["UNKNOWN"] = 0] = "UNKNOWN";
  QueryEndReason$1[QueryEndReason$1["ITEM_LIMIT"] = 1] = "ITEM_LIMIT";
  QueryEndReason$1[QueryEndReason$1["SCAN_LIMIT"] = 2] = "SCAN_LIMIT";
  QueryEndReason$1[QueryEndReason$1["CHECKPOINT_BOUND"] = 3] = "CHECKPOINT_BOUND";
  QueryEndReason$1[QueryEndReason$1["CURSOR_BOUND"] = 4] = "CURSOR_BOUND";
  QueryEndReason$1[QueryEndReason$1["LEDGER_TIP"] = 5] = "LEDGER_TIP";
  return QueryEndReason$1;
})({});
var QueryOptions$Type = class extends MessageType22 {
  constructor() {
    super("sui.rpc.v2.QueryOptions", [
      {
        no: 1,
        name: "limit",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 2,
        name: "after",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "before",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "ordering",
        kind: "enum",
        opt: true,
        T: () => [
          "sui.rpc.v2.Ordering",
          Ordering,
          "ORDERING_"
        ]
      }
    ]);
  }
};
var QueryOptions = new QueryOptions$Type();
var Watermark$Type = class extends MessageType22 {
  constructor() {
    super("sui.rpc.v2.Watermark", [{
      no: 1,
      name: "cursor",
      kind: "scalar",
      opt: true,
      T: 12
    }, {
      no: 2,
      name: "checkpoint",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var Watermark = new Watermark$Type();
var QueryEnd$Type = class extends MessageType22 {
  constructor() {
    super("sui.rpc.v2.QueryEnd", [{
      no: 1,
      name: "reason",
      kind: "enum",
      opt: true,
      T: () => [
        "sui.rpc.v2.QueryEndReason",
        QueryEndReason,
        "QUERY_END_REASON_"
      ]
    }]);
  }
};
var QueryEnd = new QueryEnd$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/filters.mjs
function toGrpcTransactionFilter(filter) {
  return { terms: [{ literals: [filter.$kind === "sender" ? {
    negated: false,
    predicate: {
      oneofKind: "sender",
      sender: { address: filter.sender }
    }
  } : {
    negated: false,
    predicate: {
      oneofKind: "moveCall",
      moveCall: { function: [
        filter.package,
        filter.module,
        filter.function
      ].filter(Boolean).join("::") }
    }
  }] }] };
}
function toGrpcEventFilter(filter) {
  return { terms: [{ literals: [filter.$kind === "sender" ? {
    negated: false,
    predicate: {
      oneofKind: "sender",
      sender: { address: filter.sender }
    }
  } : filter.$kind === "emitModule" ? {
    negated: false,
    predicate: {
      oneofKind: "emitModule",
      emitModule: { module: `${filter.package}::${filter.module}` }
    }
  } : {
    negated: false,
    predicate: {
      oneofKind: "eventType",
      eventType: { eventType: filter.$kind === "eventTypeModule" ? `${filter.package}::${filter.module}` : filter.eventType }
    }
  }] }] };
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/core.mjs
import { chunk as chunk2, fromBase64 as fromBase644, toBase64 as toBase645 } from "@mysten/utils";
import { RpcError as RpcError2 } from "@protobuf-ts/runtime-rpc";
import { GrpcStatusCode as GrpcStatusCode2 } from "@protobuf-ts/grpcweb-transport";
function isNameServiceResolutionMiss(error) {
  if (typeof error !== "object" || error === null) return false;
  const { code, message } = error;
  if (typeof code !== "string" || typeof message !== "string") return false;
  if (code === GrpcStatusCode2[GrpcStatusCode2.NOT_FOUND]) return true;
  if (code !== GrpcStatusCode2[GrpcStatusCode2.RESOURCE_EXHAUSTED]) return false;
  if (message === "name has expired") return true;
  return !hasDecodedStatusMessage(error) && message === "name%20has%20expired";
}
var GrpcCoreClient = class extends CoreClient {
  #client;
  constructor({ client, ...options }) {
    super(options);
    this.#client = client;
  }
  async getObjects(options) {
    const batches = chunk2(options.objectIds, 50);
    const results = [];
    const paths = [
      "owner",
      "object_type",
      "digest",
      "version",
      "object_id"
    ];
    if (options.include?.content) paths.push("contents");
    if (options.include?.previousTransaction) paths.push("previous_transaction");
    if (options.include?.objectBcs) paths.push("bcs");
    if (options.include?.json) paths.push("json");
    if (options.include?.display) paths.push("display");
    for (const batch of batches) {
      const response2 = await this.#client.ledgerService.batchGetObjects({
        requests: batch.map((id) => ({ objectId: id })),
        readMask: { paths }
      }, { abort: options.signal });
      results.push(...response2.response.objects.map((object3, index) => {
        if (object3.result.oneofKind === "error") {
          const error = object3.result.error;
          if (error.code === GrpcStatusCode2.NOT_FOUND) return new ObjectError("notExists", error.message, {
            cause: error,
            reason: "notFound",
            objectId: batch[index]
          });
          return new ObjectError(GrpcStatusCode2[error.code] ?? "unknown", error.message, {
            cause: error,
            reason: "unknown",
            objectId: batch[index]
          });
        }
        if (object3.result.oneofKind !== "object") return new ObjectError("unknown", "Unexpected result type", {
          reason: "unknown",
          objectId: batch[index]
        });
        const bcsContent = object3.result.object.contents?.value ?? void 0;
        const objectBcs = object3.result.object.bcs?.value ?? void 0;
        const objectType = object3.result.object.objectType;
        const type = objectType && objectType.includes("::") ? normalizeStructTag(objectType) : objectType ?? "";
        const jsonContent = options.include?.json ? object3.result.object.json ? Value.toJson(object3.result.object.json) : null : void 0;
        const displayData = mapDisplayProto(options.include?.display, object3.result.object.display);
        return {
          objectId: object3.result.object.objectId,
          version: object3.result.object.version?.toString(),
          digest: object3.result.object.digest,
          content: bcsContent,
          owner: mapOwner(object3.result.object.owner),
          type,
          previousTransaction: object3.result.object.previousTransaction ?? void 0,
          objectBcs,
          json: jsonContent,
          display: displayData
        };
      }));
    }
    return { objects: results };
  }
  async listOwnedObjects(options) {
    const paths = [
      "owner",
      "object_type",
      "digest",
      "version",
      "object_id"
    ];
    if (options.include?.content) paths.push("contents");
    if (options.include?.previousTransaction) paths.push("previous_transaction");
    if (options.include?.objectBcs) paths.push("bcs");
    if (options.include?.json) paths.push("json");
    if (options.include?.display) paths.push("display");
    const response2 = await this.#client.stateService.listOwnedObjects({
      owner: options.owner,
      objectType: options.type ? (await this.mvr.resolveType({
        type: options.type,
        signal: options.signal
      })).type : void 0,
      pageToken: options.cursor ? fromBase644(options.cursor) : void 0,
      pageSize: options.limit,
      readMask: { paths }
    }, { abort: options.signal });
    return {
      objects: response2.response.objects.map((object3) => ({
        objectId: object3.objectId,
        version: object3.version?.toString(),
        digest: object3.digest,
        content: object3.contents?.value,
        owner: mapOwner(object3.owner),
        type: object3.objectType,
        previousTransaction: object3.previousTransaction ?? void 0,
        objectBcs: object3.bcs?.value,
        json: options.include?.json ? object3.json ? Value.toJson(object3.json) : null : void 0,
        display: mapDisplayProto(options.include?.display, object3.display)
      })),
      cursor: response2.response.nextPageToken ? toBase645(response2.response.nextPageToken) : null,
      hasNextPage: response2.response.nextPageToken !== void 0
    };
  }
  async listCoins(options) {
    const paths = [
      "owner",
      "object_type",
      "digest",
      "version",
      "object_id",
      "balance"
    ];
    const coinType = options.coinType ?? SUI_TYPE_ARG;
    const response2 = await this.#client.stateService.listOwnedObjects({
      owner: options.owner,
      objectType: `0x2::coin::Coin<${(await this.mvr.resolveType({
        type: coinType,
        signal: options.signal
      })).type}>`,
      pageToken: options.cursor ? fromBase644(options.cursor) : void 0,
      pageSize: options.limit,
      readMask: { paths }
    }, { abort: options.signal });
    return {
      objects: response2.response.objects.map((object3) => ({
        objectId: object3.objectId,
        version: object3.version?.toString(),
        digest: object3.digest,
        owner: mapOwner(object3.owner),
        type: object3.objectType,
        balance: object3.balance?.toString()
      })),
      cursor: response2.response.nextPageToken ? toBase645(response2.response.nextPageToken) : null,
      hasNextPage: response2.response.nextPageToken !== void 0
    };
  }
  async getBalance(options) {
    const coinType = options.coinType ?? SUI_TYPE_ARG;
    const result = await this.#client.stateService.getBalance({
      owner: options.owner,
      coinType: (await this.mvr.resolveType({
        type: coinType,
        signal: options.signal
      })).type
    }, { abort: options.signal });
    return { balance: {
      balance: result.response.balance?.balance?.toString() ?? "0",
      coinType: result.response.balance?.coinType ?? coinType,
      coinBalance: result.response.balance?.coinBalance?.toString() ?? "0",
      addressBalance: result.response.balance?.addressBalance?.toString() ?? "0"
    } };
  }
  async getCoinMetadata(options) {
    const coinType = (await this.mvr.resolveType({
      type: options.coinType,
      signal: options.signal
    })).type;
    let response2;
    try {
      ({ response: response2 } = await this.#client.stateService.getCoinInfo({ coinType }, { abort: options.signal }));
    } catch (error) {
      if (options.signal?.aborted) throw error;
      return { coinMetadata: null };
    }
    if (!response2.metadata) return { coinMetadata: null };
    return { coinMetadata: {
      id: response2.metadata.id ?? null,
      decimals: response2.metadata.decimals ?? 0,
      name: response2.metadata.name ?? "",
      symbol: response2.metadata.symbol ?? "",
      description: response2.metadata.description ?? "",
      iconUrl: response2.metadata.iconUrl ?? null
    } };
  }
  async listBalances(options) {
    const result = await this.#client.stateService.listBalances({
      owner: options.owner,
      pageToken: options.cursor ? fromBase644(options.cursor) : void 0,
      pageSize: options.limit
    }, { abort: options.signal });
    return {
      hasNextPage: !!result.response.nextPageToken,
      cursor: result.response.nextPageToken ? toBase645(result.response.nextPageToken) : null,
      balances: result.response.balances.map((balance) => ({
        balance: balance.balance?.toString() ?? "0",
        coinType: balance.coinType,
        coinBalance: balance.coinBalance?.toString() ?? "0",
        addressBalance: balance.addressBalance?.toString() ?? "0"
      }))
    };
  }
  async getTransaction(options) {
    try {
      const { response: response2 } = await this.#client.ledgerService.getTransaction({
        digest: options.digest,
        readMask: { paths: transactionReadMaskPaths(options.include) }
      }, { abort: options.signal });
      if (!response2.transaction) throw new TransactionError("notFound", options.digest);
      return withProtoJson(parseGrpcTransactionResponse(response2.transaction, { include: options.include }), options.include, () => ExecutedTransaction.toJson(response2.transaction));
    } catch (error) {
      if (error instanceof RpcError2 && error.code === GrpcStatusCode2[GrpcStatusCode2.NOT_FOUND]) throw new TransactionError("notFound", options.digest, { cause: error });
      throw error;
    }
  }
  async executeTransaction(options) {
    const { response: response2 } = await this.#client.transactionExecutionService.executeTransaction({
      transaction: { bcs: { value: options.transaction } },
      signatures: options.signatures.map((signature) => ({
        bcs: { value: fromBase644(signature) },
        signature: { oneofKind: void 0 }
      })),
      readMask: { paths: transactionReadMaskPaths(options.include) }
    }, { abort: options.signal });
    return withProtoJson(parseGrpcTransactionResponse(response2.transaction, { include: options.include }), options.include, () => ExecutedTransaction.toJson(response2.transaction));
  }
  async simulateTransaction(options) {
    const paths = transactionReadMaskPaths(options.include, "transaction.");
    if (options.include?.commandResults) paths.push("command_outputs");
    if (!options.include?.effects) paths.push("transaction.effects.gas_object.object_id");
    if (!(options.transaction instanceof Uint8Array)) await options.transaction.prepareForSerialization({ client: this });
    const doGasSelection = options.doGasSelection ?? (options.transaction instanceof Uint8Array ? transactionBytesHaveEmptyGasPayment(options.transaction) : options.transaction.getData().gasData.payment?.length === 0);
    const { response: response2 } = await this.#client.transactionExecutionService.simulateTransaction({
      transaction: options.transaction instanceof Uint8Array ? { bcs: { value: options.transaction } } : transactionToGrpcTransaction(options.transaction),
      readMask: { paths },
      doGasSelection,
      checks: options.checksEnabled === false ? SimulateTransactionRequest_TransactionChecks.DISABLED : SimulateTransactionRequest_TransactionChecks.ENABLED
    }, { abort: options.signal });
    return withProtoJson(parseGrpcSimulateTransactionResponse(response2, { include: options.include }), options.include, () => SimulateTransactionResponse.toJson(response2));
  }
  async getReferenceGasPrice(options) {
    return { referenceGasPrice: (await this.#client.ledgerService.getEpoch({ readMask: { paths: ["reference_gas_price"] } }, { abort: options?.signal })).response.epoch?.referenceGasPrice?.toString() ?? "" };
  }
  async getProtocolConfig(options) {
    const protocolConfig = (await this.#client.ledgerService.getEpoch({ readMask: { paths: ["protocol_config"] } }, { abort: options?.signal })).response.epoch?.protocolConfig;
    if (!protocolConfig) throw new Error("Protocol config not found in response");
    const featureFlags = { ...protocolConfig.featureFlags };
    const attributes = {};
    if (protocolConfig.attributes) for (const [key, value] of Object.entries(protocolConfig.attributes)) attributes[key] = value ?? null;
    return { protocolConfig: {
      protocolVersion: protocolConfig.protocolVersion?.toString() ?? null,
      featureFlags,
      attributes
    } };
  }
  async getCurrentSystemState(options) {
    const epoch = (await this.#client.ledgerService.getEpoch({ readMask: { paths: [
      "system_state.version",
      "system_state.epoch",
      "system_state.protocol_version",
      "system_state.reference_gas_price",
      "system_state.epoch_start_timestamp_ms",
      "system_state.safe_mode",
      "system_state.safe_mode_storage_rewards",
      "system_state.safe_mode_computation_rewards",
      "system_state.safe_mode_storage_rebates",
      "system_state.safe_mode_non_refundable_storage_fee",
      "system_state.parameters",
      "system_state.storage_fund",
      "system_state.stake_subsidy"
    ] } }, { abort: options?.signal })).response.epoch;
    const systemState = epoch?.systemState;
    if (!systemState) throw new Error("System state not found in response");
    const startMs = epoch?.start?.seconds ? Number(epoch.start.seconds) * 1e3 + Math.floor((epoch.start.nanos || 0) / 1e6) : systemState.epochStartTimestampMs ? Number(systemState.epochStartTimestampMs) : null;
    return { systemState: {
      systemStateVersion: systemState.version?.toString() ?? null,
      epoch: systemState.epoch?.toString() ?? null,
      protocolVersion: systemState.protocolVersion?.toString() ?? null,
      referenceGasPrice: systemState.referenceGasPrice?.toString() ?? null,
      epochStartTimestampMs: startMs.toString(),
      safeMode: systemState.safeMode ?? false,
      safeModeStorageRewards: systemState.safeModeStorageRewards?.toString() ?? null,
      safeModeComputationRewards: systemState.safeModeComputationRewards?.toString() ?? null,
      safeModeStorageRebates: systemState.safeModeStorageRebates?.toString() ?? null,
      safeModeNonRefundableStorageFee: systemState.safeModeNonRefundableStorageFee?.toString() ?? null,
      parameters: {
        epochDurationMs: systemState.parameters?.epochDurationMs?.toString() ?? null,
        stakeSubsidyStartEpoch: systemState.parameters?.stakeSubsidyStartEpoch?.toString() ?? null,
        maxValidatorCount: systemState.parameters?.maxValidatorCount?.toString() ?? null,
        minValidatorJoiningStake: systemState.parameters?.minValidatorJoiningStake?.toString() ?? null,
        validatorLowStakeThreshold: systemState.parameters?.validatorLowStakeThreshold?.toString() ?? null,
        validatorLowStakeGracePeriod: systemState.parameters?.validatorLowStakeGracePeriod?.toString() ?? null
      },
      storageFund: {
        totalObjectStorageRebates: systemState.storageFund?.totalObjectStorageRebates?.toString() ?? null,
        nonRefundableBalance: systemState.storageFund?.nonRefundableBalance?.toString() ?? null
      },
      stakeSubsidy: {
        balance: systemState.stakeSubsidy?.balance?.toString() ?? null,
        distributionCounter: systemState.stakeSubsidy?.distributionCounter?.toString() ?? null,
        currentDistributionAmount: systemState.stakeSubsidy?.currentDistributionAmount?.toString() ?? null,
        stakeSubsidyPeriodLength: systemState.stakeSubsidy?.stakeSubsidyPeriodLength?.toString() ?? null,
        stakeSubsidyDecreaseRate: systemState.stakeSubsidy?.stakeSubsidyDecreaseRate ?? null
      }
    } };
  }
  async listDynamicFields(options) {
    return this.#client.listDynamicFields(options);
  }
  async listTransactions(options) {
    const paths = transactionReadMaskPaths(options.include);
    const filter = options.filter ? await resolveTransactionFilter(this.mvr, options.filter, options.signal) : void 0;
    const pagination = resolvePagination(options);
    validateTransactionQuery(filter, pagination);
    const call = this.#client.ledgerService.listTransactions({
      readMask: { paths },
      filter: filter && toGrpcTransactionFilter(filter),
      options: toGrpcQueryOptions(pagination, pagination.limit + 1)
    }, { abort: options.signal });
    const transactions = [];
    let startCursor = null;
    let endCursor = null;
    let frontier = null;
    let end;
    let sawLookaheadItem = false;
    for await (const frame of call.responses) {
      if (frame.watermark?.cursor) frontier = toBase645(frame.watermark.cursor);
      if (frame.transaction) if (transactions.length >= pagination.limit) sawLookaheadItem = true;
      else {
        startCursor ??= frontier;
        endCursor = frontier;
        transactions.push(parseGrpcTransactionResponse(frame.transaction, { include: options.include }));
      }
      if (frame.end) end = frame.end;
    }
    const hasNextPage = sawLookaheadItem || end?.reason === QueryEndReason.SCAN_LIMIT || end?.reason === QueryEndReason.ITEM_LIMIT;
    return {
      transactions,
      hasNextPage,
      startCursor,
      endCursor: sawLookaheadItem ? endCursor : hasNextPage ? frontier ?? endCursor : endCursor
    };
  }
  async listEvents(options) {
    const pagination = resolvePagination(options);
    const call = this.#client.ledgerService.listEvents({
      readMask: { paths: [
        "package_id",
        "module",
        "sender",
        "event_type",
        "contents",
        "json",
        "checkpoint",
        "transaction_digest",
        "event_index"
      ] },
      filter: options.filter ? toGrpcEventFilter(await resolveEventFilter(this.mvr, options.filter, options.signal)) : void 0,
      options: toGrpcQueryOptions(pagination, pagination.limit + 1)
    }, { abort: options.signal });
    const events = [];
    let startCursor = null;
    let endCursor = null;
    let frontier = null;
    let end;
    let sawLookaheadItem = false;
    for await (const frame of call.responses) {
      if (frame.watermark?.cursor) frontier = toBase645(frame.watermark.cursor);
      if (frame.event) if (events.length >= pagination.limit) sawLookaheadItem = true;
      else {
        startCursor ??= frontier;
        endCursor = frontier;
        const event = frame.event;
        events.push({
          packageId: normalizeSuiAddress(event.packageId),
          module: event.module,
          sender: normalizeSuiAddress(event.sender),
          eventType: normalizeStructTag(event.eventType),
          bcs: event.contents?.value ?? new Uint8Array(),
          json: event.json ? Value.toJson(event.json) : null,
          checkpoint: event.checkpoint?.toString() ?? null,
          transactionDigest: event.transactionDigest,
          eventIndex: event.eventIndex
        });
      }
      if (frame.end) end = frame.end;
    }
    const hasNextPage = sawLookaheadItem || end?.reason === QueryEndReason.SCAN_LIMIT || end?.reason === QueryEndReason.ITEM_LIMIT;
    return {
      events,
      hasNextPage,
      startCursor,
      endCursor: sawLookaheadItem ? endCursor : hasNextPage ? frontier ?? endCursor : endCursor
    };
  }
  async verifyZkLoginSignature(options) {
    const messageBytes = fromBase644(options.bytes);
    const messageValue = options.intentScope === "PersonalMessage" ? suiBcs.byteVector().serialize(messageBytes).toBytes() : messageBytes;
    const { response: response2 } = await this.#client.signatureVerificationService.verifySignature({
      message: {
        name: options.intentScope,
        value: messageValue
      },
      signature: {
        bcs: { value: fromBase644(options.signature) },
        signature: { oneofKind: void 0 }
      },
      address: options.address,
      jwks: []
    }, { abort: options.signal });
    return {
      success: response2.isValid ?? false,
      errors: response2.reason ? [response2.reason] : []
    };
  }
  async defaultNameServiceName(options) {
    try {
      const { response: response2 } = await this.#client.nameService.reverseLookupName({ address: options.address }, { abort: options.signal });
      return { data: { name: response2.record?.name ?? null } };
    } catch (error) {
      if (isNameServiceResolutionMiss(error)) return { data: { name: null } };
      throw error;
    }
  }
  async resolveNameServiceAddress(options) {
    try {
      const { response: response2 } = await this.#client.nameService.lookupName({ name: options.name }, { abort: options.signal });
      return { address: response2.record?.targetAddress ?? null };
    } catch (error) {
      if (isNameServiceResolutionMiss(error)) return { address: null };
      throw error;
    }
  }
  async getMoveFunction(options) {
    const resolvedPackageId = (await this.mvr.resolvePackage({
      package: options.packageId,
      signal: options.signal
    })).package;
    const { response: response2 } = await this.#client.movePackageService.getFunction({
      packageId: resolvedPackageId,
      moduleName: options.moduleName,
      name: options.name
    }, { abort: options.signal });
    let visibility = "unknown";
    switch (response2.function?.visibility) {
      case FunctionDescriptor_Visibility.PUBLIC:
        visibility = "public";
        break;
      case FunctionDescriptor_Visibility.PRIVATE:
        visibility = "private";
        break;
      case FunctionDescriptor_Visibility.FRIEND:
        visibility = "friend";
        break;
    }
    return { function: {
      packageId: normalizeSuiAddress(resolvedPackageId),
      moduleName: options.moduleName,
      name: response2.function?.name,
      visibility,
      isEntry: response2.function?.isEntry ?? false,
      typeParameters: response2.function?.typeParameters?.map(({ constraints }) => ({
        isPhantom: false,
        constraints: constraints.map((constraint) => {
          switch (constraint) {
            case Ability.COPY:
              return "copy";
            case Ability.DROP:
              return "drop";
            case Ability.STORE:
              return "store";
            case Ability.KEY:
              return "key";
            default:
              return "unknown";
          }
        }) ?? []
      })) ?? [],
      parameters: response2.function?.parameters?.map((param) => parseNormalizedSuiMoveType(param)) ?? [],
      returns: response2.function?.returns?.map((ret) => parseNormalizedSuiMoveType(ret)) ?? []
    } };
  }
  async getChainIdentifier(options) {
    return raceSignal(Promise.resolve(this.cache.read(["chainIdentifier"], async () => {
      const { response: response2 } = await this.#client.ledgerService.getServiceInfo({});
      if (!response2.chainId) throw new Error("Chain identifier not found in service info");
      return { chainIdentifier: response2.chainId };
    })), options?.signal);
  }
  resolveTransactionPlugin() {
    const client = this.#client;
    return async function resolveTransactionData(transactionData, options, next) {
      const snapshot = transactionData.snapshot();
      if (!snapshot.sender) snapshot.sender = "0x0000000000000000000000000000000000000000000000000000000000000000";
      const grpcTransaction = transactionDataToGrpcTransaction(snapshot);
      const doGasSelection = !options.onlyTransactionKind && (snapshot.gasData.budget == null || snapshot.gasData.payment == null);
      let response2;
      try {
        response2 = (await client.transactionExecutionService.simulateTransaction({
          transaction: grpcTransaction,
          doGasSelection,
          checks: options.onlyTransactionKind ? SimulateTransactionRequest_TransactionChecks.DISABLED : SimulateTransactionRequest_TransactionChecks.ENABLED,
          readMask: { paths: [
            "transaction.transaction.sender",
            "transaction.transaction.gas_payment",
            "transaction.transaction.expiration",
            "transaction.transaction.kind",
            "transaction.effects.status",
            "transaction.effects.epoch"
          ] }
        })).response;
      } catch (error) {
        if (error instanceof Error && error.message) throw new SimulationError(error.message, { cause: error });
        throw error;
      }
      if (!options.onlyTransactionKind && response2.transaction?.effects?.status && !response2.transaction.effects.status.success) {
        const executionError = response2.transaction.effects.status.error ? parseGrpcExecutionError(response2.transaction.effects.status.error) : void 0;
        throw new SimulationError(`Transaction resolution failed: ${executionError?.message ?? "Transaction failed"}`, { executionError });
      }
      if (!response2.transaction?.transaction) throw new Error("simulateTransaction did not return resolved transaction data");
      applyGrpcResolvedTransaction(transactionData, response2.transaction.transaction, options);
      await setAddressBalanceTransactionExpirationFromSimulatedEpoch({
        transactionData,
        client,
        epoch: response2.transaction.effects?.epoch,
        originalTransactionData: snapshot,
        isTransactionKindOnly: !!options.onlyTransactionKind,
        doGasSelection
      });
      return await next();
    };
  }
};
function toGrpcQueryOptions(pagination, limit) {
  return {
    limit,
    ordering: pagination.descending ? Ordering.DESCENDING : Ordering.ASCENDING,
    after: pagination.after ? fromBase644(pagination.after) : void 0,
    before: pagination.before ? fromBase644(pagination.before) : void 0
  };
}
function transactionReadMaskPaths(include, prefix = "") {
  const paths = [
    "digest",
    "transaction.digest",
    "signatures",
    "effects.status",
    "timestamp",
    "checkpoint"
  ];
  if (include?.transaction) paths.push("transaction.sender", "transaction.gas_payment", "transaction.expiration", "transaction.kind");
  if (include?.bcs) paths.push("transaction.bcs");
  if (include?.balanceChanges) paths.push("balance_changes");
  if (include?.effects) paths.push("effects");
  if (include?.events) paths.push("events");
  if (include?.objectTypes) {
    paths.push("effects.changed_objects.object_type");
    paths.push("effects.changed_objects.object_id");
  }
  return prefix ? paths.map((path) => prefix + path) : paths;
}
function withProtoJson(result, include, getProtoJson) {
  if (!include?.protoJson) return result;
  return {
    ...result,
    protoJson: getProtoJson()
  };
}
function mapDisplayProto(include, display) {
  if (!include) return void 0;
  if (display === void 0) return null;
  return {
    output: display.output !== void 0 ? Value.toJson(display.output) : null,
    errors: display.errors !== void 0 ? Value.toJson(display.errors) : null
  };
}
function mapOwner(owner) {
  if (!owner) return null;
  if (owner.kind === Owner_OwnerKind.IMMUTABLE) return {
    $kind: "Immutable",
    Immutable: true
  };
  if (owner.kind === Owner_OwnerKind.ADDRESS) return {
    AddressOwner: owner.address,
    $kind: "AddressOwner"
  };
  if (owner.kind === Owner_OwnerKind.OBJECT) return {
    $kind: "ObjectOwner",
    ObjectOwner: owner.address
  };
  if (owner.kind === Owner_OwnerKind.SHARED) return {
    $kind: "Shared",
    Shared: { initialSharedVersion: owner.version?.toString() }
  };
  if (owner.kind === Owner_OwnerKind.CONSENSUS_ADDRESS) return {
    $kind: "ConsensusAddressOwner",
    ConsensusAddressOwner: {
      startVersion: owner.version?.toString(),
      owner: owner.address
    }
  };
  throw new Error(`Unknown owner kind ${JSON.stringify(owner, (_k, v) => typeof v === "bigint" ? v.toString() : v)}`);
}
function parseGrpcExecutionError(error) {
  const message = error.description ?? "Unknown error";
  const command = error.command != null ? Number(error.command) : void 0;
  const details = error.errorDetails;
  switch (details?.oneofKind) {
    case "abort": {
      const abort = details.abort;
      const cleverError = abort.cleverError;
      return {
        $kind: "MoveAbort",
        message: formatMoveAbortMessage({
          command,
          location: abort.location,
          abortCode: String(abort.abortCode ?? 0n),
          cleverError: cleverError ? {
            lineNumber: cleverError.lineNumber != null ? Number(cleverError.lineNumber) : void 0,
            constantName: cleverError.constantName,
            value: cleverError.value?.oneofKind === "rendered" ? cleverError.value.rendered : void 0
          } : void 0
        }),
        command,
        MoveAbort: parseMoveAbort(abort)
      };
    }
    case "sizeError":
      return {
        $kind: "SizeError",
        message,
        command,
        SizeError: {
          name: mapErrorName(error.kind),
          size: Number(details.sizeError.size ?? 0n),
          maxSize: Number(details.sizeError.maxSize ?? 0n)
        }
      };
    case "commandArgumentError":
      return {
        $kind: "CommandArgumentError",
        message,
        command,
        CommandArgumentError: {
          argument: details.commandArgumentError.argument ?? 0,
          name: mapErrorName(details.commandArgumentError.kind)
        }
      };
    case "typeArgumentError":
      return {
        $kind: "TypeArgumentError",
        message,
        command,
        TypeArgumentError: {
          typeArgument: details.typeArgumentError.typeArgument ?? 0,
          name: mapErrorName(details.typeArgumentError.kind)
        }
      };
    case "packageUpgradeError":
      return {
        $kind: "PackageUpgradeError",
        message,
        command,
        PackageUpgradeError: {
          name: mapErrorName(details.packageUpgradeError.kind),
          packageId: details.packageUpgradeError.packageId,
          digest: details.packageUpgradeError.digest
        }
      };
    case "indexError":
      return {
        $kind: "IndexError",
        message,
        command,
        IndexError: {
          index: details.indexError.index,
          subresult: details.indexError.subresult
        }
      };
    case "coinDenyListError":
      return {
        $kind: "CoinDenyListError",
        message,
        command,
        CoinDenyListError: {
          name: mapErrorName(error.kind),
          coinType: details.coinDenyListError.coinType,
          address: details.coinDenyListError.address
        }
      };
    case "congestedObjects":
      return {
        $kind: "CongestedObjects",
        message,
        command,
        CongestedObjects: {
          name: mapErrorName(error.kind),
          objects: details.congestedObjects.objects
        }
      };
    case "objectId":
      return {
        $kind: "ObjectIdError",
        message,
        command,
        ObjectIdError: {
          name: mapErrorName(error.kind),
          objectId: details.objectId
        }
      };
    default:
      return {
        $kind: "Unknown",
        message,
        command,
        Unknown: null
      };
  }
}
function parseMoveAbort(abort) {
  return {
    abortCode: String(abort.abortCode ?? 0n),
    location: { ...abort.location },
    cleverError: abort.cleverError ? {
      errorCode: abort.cleverError.errorCode != null ? Number(abort.cleverError.errorCode) : void 0,
      lineNumber: abort.cleverError.lineNumber != null ? Number(abort.cleverError.lineNumber) : void 0,
      constantName: abort.cleverError.constantName,
      constantType: abort.cleverError.constantType,
      value: abort.cleverError.value?.oneofKind === "rendered" ? abort.cleverError.value.rendered : abort.cleverError.value?.oneofKind === "raw" ? toBase645(abort.cleverError.value.raw) : void 0
    } : void 0
  };
}
function mapErrorName(kind) {
  if (kind == null) return "Unknown";
  const name = CommandArgumentError_CommandArgumentErrorKind[kind];
  if (!name || name.endsWith("_UNKNOWN")) return "Unknown";
  return name.split("_").map((word) => word.charAt(0) + word.slice(1).toLowerCase()).join("");
}
function mapIdOperation(operation) {
  if (operation == null) return null;
  switch (operation) {
    case ChangedObject_IdOperation.CREATED:
      return "Created";
    case ChangedObject_IdOperation.DELETED:
      return "Deleted";
    case ChangedObject_IdOperation.NONE:
    case ChangedObject_IdOperation.ID_OPERATION_UNKNOWN:
      return "None";
    default:
      return "Unknown";
  }
}
function mapInputObjectState(state) {
  if (state == null) return null;
  switch (state) {
    case ChangedObject_InputObjectState.EXISTS:
      return "Exists";
    case ChangedObject_InputObjectState.DOES_NOT_EXIST:
      return "DoesNotExist";
    case ChangedObject_InputObjectState.UNKNOWN:
      return "Unknown";
    default:
      return "Unknown";
  }
}
function mapOutputObjectState(state) {
  if (state == null) return null;
  switch (state) {
    case ChangedObject_OutputObjectState.OBJECT_WRITE:
      return "ObjectWrite";
    case ChangedObject_OutputObjectState.PACKAGE_WRITE:
      return "PackageWrite";
    case ChangedObject_OutputObjectState.DOES_NOT_EXIST:
      return "DoesNotExist";
    case ChangedObject_OutputObjectState.ACCUMULATOR_WRITE:
      return "AccumulatorWriteV1";
    case ChangedObject_OutputObjectState.UNKNOWN:
      return "Unknown";
    default:
      return "Unknown";
  }
}
function mapUnchangedConsensusObjectKind(kind) {
  if (kind == null) return null;
  switch (kind) {
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.UNCHANGED_CONSENSUS_OBJECT_KIND_UNKNOWN:
      return "Unknown";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.READ_ONLY_ROOT:
      return "ReadOnlyRoot";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.MUTATE_CONSENSUS_STREAM_ENDED:
      return "MutateConsensusStreamEnded";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.READ_CONSENSUS_STREAM_ENDED:
      return "ReadConsensusStreamEnded";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.CANCELED:
      return "Cancelled";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.PER_EPOCH_CONFIG:
      return "PerEpochConfig";
    default:
      return "Unknown";
  }
}
function parseTransactionEffects({ effects }) {
  if (!effects) return null;
  const changedObjects = effects.changedObjects.map((change) => {
    return {
      objectId: change.objectId,
      inputState: mapInputObjectState(change.inputState),
      inputVersion: change.inputVersion?.toString() ?? null,
      inputDigest: change.inputDigest ?? null,
      inputOwner: mapOwner(change.inputOwner),
      outputState: mapOutputObjectState(change.outputState),
      outputVersion: change.outputVersion?.toString() ?? null,
      outputDigest: change.outputDigest ?? null,
      outputOwner: mapOwner(change.outputOwner),
      idOperation: mapIdOperation(change.idOperation)
    };
  });
  return {
    bcs: effects.bcs?.value,
    version: effects.version ?? 2,
    status: effects.status?.success ? {
      success: true,
      error: null
    } : {
      success: false,
      error: parseGrpcExecutionError(effects.status.error)
    },
    gasUsed: {
      computationCost: effects.gasUsed?.computationCost?.toString(),
      storageCost: effects.gasUsed?.storageCost?.toString(),
      storageRebate: effects.gasUsed?.storageRebate?.toString(),
      nonRefundableStorageFee: effects.gasUsed?.nonRefundableStorageFee?.toString()
    },
    transactionDigest: effects.transactionDigest,
    gasObject: effects.gasObject ? {
      objectId: effects.gasObject.objectId,
      inputState: mapInputObjectState(effects.gasObject.inputState),
      inputVersion: effects.gasObject.inputVersion?.toString() ?? null,
      inputDigest: effects.gasObject.inputDigest ?? null,
      inputOwner: mapOwner(effects.gasObject.inputOwner),
      outputState: mapOutputObjectState(effects.gasObject.outputState),
      outputVersion: effects.gasObject.outputVersion?.toString() ?? null,
      outputDigest: effects.gasObject.outputDigest ?? null,
      outputOwner: mapOwner(effects.gasObject.outputOwner),
      idOperation: mapIdOperation(effects.gasObject.idOperation)
    } : null,
    eventsDigest: effects.eventsDigest ?? null,
    dependencies: effects.dependencies,
    lamportVersion: effects.lamportVersion?.toString() ?? null,
    changedObjects,
    unchangedConsensusObjects: effects.unchangedConsensusObjects.map((object3) => {
      return {
        kind: mapUnchangedConsensusObjectKind(object3.kind),
        objectId: object3.objectId,
        version: object3.version?.toString() ?? null,
        digest: object3.digest ?? null
      };
    }),
    auxiliaryDataDigest: effects.auxiliaryDataDigest ?? null
  };
}
function parseGrpcTransactionResponse(transaction, options) {
  const include = options?.include;
  const objectTypes = {};
  if (include?.objectTypes) transaction.effects?.changedObjects?.forEach((change) => {
    if (change.objectId && change.objectType) objectTypes[change.objectId] = change.objectType;
  });
  let transactionData;
  if (include?.transaction) {
    const tx = transaction.transaction;
    if (!tx) throw new Error("Transaction data is required but missing from gRPC response");
    const resolved = grpcTransactionToTransactionData(tx);
    transactionData = {
      gasData: resolved.gasData,
      sender: resolved.sender,
      expiration: resolved.expiration,
      commands: resolved.commands,
      inputs: resolved.inputs,
      version: resolved.version
    };
  }
  const bcsBytes = include?.bcs ? transaction.transaction?.bcs?.value : void 0;
  const effects = include?.effects ? parseTransactionEffects({ effects: transaction.effects }) : void 0;
  const status = transaction.effects?.status?.success ? {
    success: true,
    error: null
  } : {
    success: false,
    error: transaction.effects?.status?.error ? parseGrpcExecutionError(transaction.effects.status.error) : {
      $kind: "Unknown",
      message: "Transaction failed",
      Unknown: null
    }
  };
  const result = {
    digest: transaction.digest,
    epoch: transaction.effects?.epoch?.toString() ?? null,
    timestampMs: transaction.timestamp ? Number(transaction.timestamp.seconds) * 1e3 + Math.floor(transaction.timestamp.nanos / 1e6) : null,
    checkpoint: transaction.checkpoint?.toString() ?? null,
    status,
    effects,
    objectTypes: include?.objectTypes ? objectTypes : void 0,
    transaction: transactionData,
    bcs: bcsBytes,
    signatures: transaction.signatures?.map((sig) => toBase645(sig.bcs?.value)) ?? [],
    balanceChanges: include?.balanceChanges ? transaction.balanceChanges?.map((change) => ({
      coinType: change.coinType,
      address: change.address,
      amount: change.amount
    })) ?? [] : void 0,
    events: include?.events ? transaction.events?.events.map((event) => ({
      packageId: normalizeSuiAddress(event.packageId),
      module: event.module,
      sender: normalizeSuiAddress(event.sender),
      eventType: event.eventType,
      bcs: event.contents?.value ?? new Uint8Array(),
      json: event.json ? Value.toJson(event.json) : null
    })) ?? [] : void 0
  };
  return status.success ? {
    $kind: "Transaction",
    Transaction: result
  } : {
    $kind: "FailedTransaction",
    FailedTransaction: result
  };
}
function parseGrpcSimulateTransactionResponse(response2, options) {
  const include = options?.include;
  const transactionResult = parseGrpcTransactionResponse(response2.transaction, { include });
  const gasPaymentMocked = isMockedGasObjectId(response2.transaction?.effects?.gasObject?.objectId);
  const commandResults = include?.commandResults && response2.commandOutputs ? response2.commandOutputs.map((output) => ({
    returnValues: (output.returnValues ?? []).map((rv) => ({ bcs: rv.value?.value ?? null })),
    mutatedReferences: (output.mutatedByRef ?? []).map((mr) => ({ bcs: mr.value?.value ?? null }))
  })) : void 0;
  if (transactionResult.$kind === "Transaction") return {
    $kind: "Transaction",
    Transaction: transactionResult.Transaction,
    commandResults,
    gasPaymentMocked
  };
  return {
    $kind: "FailedTransaction",
    FailedTransaction: transactionResult.FailedTransaction,
    commandResults,
    gasPaymentMocked
  };
}
function parseNormalizedSuiMoveType(type) {
  let reference = null;
  if (type.reference === OpenSignature_Reference.IMMUTABLE) reference = "immutable";
  else if (type.reference === OpenSignature_Reference.MUTABLE) reference = "mutable";
  return {
    reference,
    body: parseNormalizedSuiMoveTypeBody(type.body)
  };
}
function parseNormalizedSuiMoveTypeBody(type) {
  switch (type.type) {
    case OpenSignatureBody_Type.TYPE_UNKNOWN:
      return { $kind: "unknown" };
    case OpenSignatureBody_Type.ADDRESS:
      return { $kind: "address" };
    case OpenSignatureBody_Type.BOOL:
      return { $kind: "bool" };
    case OpenSignatureBody_Type.U8:
      return { $kind: "u8" };
    case OpenSignatureBody_Type.U16:
      return { $kind: "u16" };
    case OpenSignatureBody_Type.U32:
      return { $kind: "u32" };
    case OpenSignatureBody_Type.U64:
      return { $kind: "u64" };
    case OpenSignatureBody_Type.U128:
      return { $kind: "u128" };
    case OpenSignatureBody_Type.U256:
      return { $kind: "u256" };
    case OpenSignatureBody_Type.VECTOR:
      return {
        $kind: "vector",
        vector: parseNormalizedSuiMoveTypeBody(type.typeParameterInstantiation[0])
      };
    case OpenSignatureBody_Type.DATATYPE:
      return {
        $kind: "datatype",
        datatype: {
          typeName: type.typeName,
          typeParameters: type.typeParameterInstantiation.map((t) => parseNormalizedSuiMoveTypeBody(t))
        }
      };
    case OpenSignatureBody_Type.TYPE_PARAMETER:
      return {
        $kind: "typeParameter",
        index: type.typeParameter
      };
    default:
      return { $kind: "unknown" };
  }
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/transaction_execution_service.client.mjs
import { stackIntercept } from "@protobuf-ts/runtime-rpc";
var TransactionExecutionServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = TransactionExecutionService.typeName;
    this.methods = TransactionExecutionService.methods;
    this.options = TransactionExecutionService.options;
  }
  /**
  * @generated from protobuf rpc: ExecuteTransaction(sui.rpc.v2.ExecuteTransactionRequest) returns (sui.rpc.v2.ExecuteTransactionResponse);
  */
  executeTransaction(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: SimulateTransaction(sui.rpc.v2.SimulateTransactionRequest) returns (sui.rpc.v2.SimulateTransactionResponse);
  */
  simulateTransaction(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept("unary", this._transport, method, opt, input);
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/filter.mjs
import { MessageType as MessageType23 } from "@protobuf-ts/runtime";
var TransactionFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.TransactionFilter", [{
      no: 1,
      name: "terms",
      kind: "message",
      repeat: 2,
      T: () => TransactionTerm
    }]);
  }
};
var TransactionFilter = new TransactionFilter$Type();
var TransactionTerm$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.TransactionTerm", [{
      no: 1,
      name: "literals",
      kind: "message",
      repeat: 2,
      T: () => TransactionLiteral
    }]);
  }
};
var TransactionTerm = new TransactionTerm$Type();
var TransactionLiteral$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.TransactionLiteral", [
      {
        no: 1,
        name: "negated",
        kind: "scalar",
        T: 8
      },
      {
        no: 2,
        name: "sender",
        kind: "message",
        oneof: "predicate",
        T: () => SenderFilter
      },
      {
        no: 3,
        name: "affected_address",
        kind: "message",
        oneof: "predicate",
        T: () => AffectedAddressFilter
      },
      {
        no: 4,
        name: "affected_object",
        kind: "message",
        oneof: "predicate",
        T: () => AffectedObjectFilter
      },
      {
        no: 5,
        name: "move_call",
        kind: "message",
        oneof: "predicate",
        T: () => MoveCallFilter
      },
      {
        no: 6,
        name: "emit_module",
        kind: "message",
        oneof: "predicate",
        T: () => EmitModuleFilter
      },
      {
        no: 7,
        name: "event_type",
        kind: "message",
        oneof: "predicate",
        T: () => EventTypeFilter
      },
      {
        no: 8,
        name: "event_stream_head",
        kind: "message",
        oneof: "predicate",
        T: () => EventStreamHeadFilter
      },
      {
        no: 9,
        name: "package_write",
        kind: "message",
        oneof: "predicate",
        T: () => PackageWriteFilter
      }
    ]);
  }
};
var TransactionLiteral = new TransactionLiteral$Type();
var EventFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EventFilter", [{
      no: 1,
      name: "terms",
      kind: "message",
      repeat: 2,
      T: () => EventTerm
    }]);
  }
};
var EventFilter = new EventFilter$Type();
var EventTerm$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EventTerm", [{
      no: 1,
      name: "literals",
      kind: "message",
      repeat: 2,
      T: () => EventLiteral
    }]);
  }
};
var EventTerm = new EventTerm$Type();
var EventLiteral$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EventLiteral", [
      {
        no: 1,
        name: "negated",
        kind: "scalar",
        T: 8
      },
      {
        no: 2,
        name: "sender",
        kind: "message",
        oneof: "predicate",
        T: () => SenderFilter
      },
      {
        no: 3,
        name: "emit_module",
        kind: "message",
        oneof: "predicate",
        T: () => EmitModuleFilter
      },
      {
        no: 4,
        name: "event_type",
        kind: "message",
        oneof: "predicate",
        T: () => EventTypeFilter
      },
      {
        no: 5,
        name: "event_stream_head",
        kind: "message",
        oneof: "predicate",
        T: () => EventStreamHeadFilter
      }
    ]);
  }
};
var EventLiteral = new EventLiteral$Type();
var SenderFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.SenderFilter", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var SenderFilter = new SenderFilter$Type();
var AffectedAddressFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.AffectedAddressFilter", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var AffectedAddressFilter = new AffectedAddressFilter$Type();
var AffectedObjectFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.AffectedObjectFilter", [{
      no: 1,
      name: "object_id",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var AffectedObjectFilter = new AffectedObjectFilter$Type();
var MoveCallFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.MoveCallFilter", [{
      no: 1,
      name: "function",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var MoveCallFilter = new MoveCallFilter$Type();
var EmitModuleFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EmitModuleFilter", [{
      no: 1,
      name: "module",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EmitModuleFilter = new EmitModuleFilter$Type();
var EventTypeFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EventTypeFilter", [{
      no: 1,
      name: "event_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EventTypeFilter = new EventTypeFilter$Type();
var EventStreamHeadFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.EventStreamHeadFilter", [{
      no: 1,
      name: "stream_id",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EventStreamHeadFilter = new EventStreamHeadFilter$Type();
var PackageWriteFilter$Type = class extends MessageType23 {
  constructor() {
    super("sui.rpc.v2.PackageWriteFilter", []);
  }
};
var PackageWriteFilter = new PackageWriteFilter$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/protocol_config.mjs
import { MessageType as MessageType24 } from "@protobuf-ts/runtime";
var ProtocolConfig$Type = class extends MessageType24 {
  constructor() {
    super("sui.rpc.v2.ProtocolConfig", [
      {
        no: 1,
        name: "protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "feature_flags",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 8
        }
      },
      {
        no: 3,
        name: "attributes",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 9
        }
      },
      {
        no: 4,
        name: "configs",
        kind: "map",
        K: 9,
        V: {
          kind: "message",
          T: () => Value
        }
      }
    ]);
  }
};
var ProtocolConfig = new ProtocolConfig$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/system_state.mjs
import { MessageType as MessageType25 } from "@protobuf-ts/runtime";
var SystemState$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.SystemState", [
      {
        no: 1,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "validators",
        kind: "message",
        T: () => ValidatorSet
      },
      {
        no: 5,
        name: "storage_fund",
        kind: "message",
        T: () => StorageFund
      },
      {
        no: 6,
        name: "parameters",
        kind: "message",
        T: () => SystemParameters
      },
      {
        no: 7,
        name: "reference_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "validator_report_records",
        kind: "message",
        repeat: 2,
        T: () => ValidatorReportRecord
      },
      {
        no: 9,
        name: "stake_subsidy",
        kind: "message",
        T: () => StakeSubsidy
      },
      {
        no: 10,
        name: "safe_mode",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 11,
        name: "safe_mode_storage_rewards",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 12,
        name: "safe_mode_computation_rewards",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 13,
        name: "safe_mode_storage_rebates",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 14,
        name: "safe_mode_non_refundable_storage_fee",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 15,
        name: "epoch_start_timestamp_ms",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 16,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var SystemState = new SystemState$Type();
var ValidatorReportRecord$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.ValidatorReportRecord", [{
      no: 1,
      name: "reported",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "reporters",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
};
var ValidatorReportRecord = new ValidatorReportRecord$Type();
var SystemParameters$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.SystemParameters", [
      {
        no: 1,
        name: "epoch_duration_ms",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "stake_subsidy_start_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "min_validator_count",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "max_validator_count",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "min_validator_joining_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "validator_low_stake_threshold",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "validator_very_low_stake_threshold",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "validator_low_stake_grace_period",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 9,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var SystemParameters = new SystemParameters$Type();
var MoveTable$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.MoveTable", [{
      no: 1,
      name: "id",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "size",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var MoveTable = new MoveTable$Type();
var StakeSubsidy$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.StakeSubsidy", [
      {
        no: 1,
        name: "balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "distribution_counter",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "current_distribution_amount",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "stake_subsidy_period_length",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "stake_subsidy_decrease_rate",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 6,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var StakeSubsidy = new StakeSubsidy$Type();
var StorageFund$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.StorageFund", [{
      no: 1,
      name: "total_object_storage_rebates",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "non_refundable_balance",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var StorageFund = new StorageFund$Type();
var ValidatorSet$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.ValidatorSet", [
      {
        no: 1,
        name: "total_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "active_validators",
        kind: "message",
        repeat: 2,
        T: () => Validator
      },
      {
        no: 3,
        name: "pending_active_validators",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 4,
        name: "pending_removals",
        kind: "scalar",
        repeat: 1,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "staking_pool_mappings",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 6,
        name: "inactive_validators",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 7,
        name: "validator_candidates",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 8,
        name: "at_risk_validators",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 4,
          L: 0
        }
      },
      {
        no: 9,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var ValidatorSet = new ValidatorSet$Type();
var Validator$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.Validator", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "description",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "image_url",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "project_url",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "protocol_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 8,
        name: "proof_of_possession",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 10,
        name: "network_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 12,
        name: "worker_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 13,
        name: "network_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 14,
        name: "p2p_address",
        kind: "scalar",
        jsonName: "p2pAddress",
        opt: true,
        T: 9
      },
      {
        no: 15,
        name: "primary_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 16,
        name: "worker_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 18,
        name: "next_epoch_protocol_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 19,
        name: "next_epoch_proof_of_possession",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 21,
        name: "next_epoch_network_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 23,
        name: "next_epoch_worker_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 24,
        name: "next_epoch_network_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 25,
        name: "next_epoch_p2p_address",
        kind: "scalar",
        jsonName: "nextEpochP2pAddress",
        opt: true,
        T: 9
      },
      {
        no: 26,
        name: "next_epoch_primary_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 27,
        name: "next_epoch_worker_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 28,
        name: "metadata_extra_fields",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 29,
        name: "voting_power",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 30,
        name: "operation_cap_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 31,
        name: "gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 32,
        name: "staking_pool",
        kind: "message",
        T: () => StakingPool
      },
      {
        no: 33,
        name: "commission_rate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 34,
        name: "next_epoch_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 35,
        name: "next_epoch_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 36,
        name: "next_epoch_commission_rate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 37,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var Validator = new Validator$Type();
var StakingPool$Type = class extends MessageType25 {
  constructor() {
    super("sui.rpc.v2.StakingPool", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "activation_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "deactivation_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "sui_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "rewards_pool",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "pool_token_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "exchange_rates",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 8,
        name: "pending_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 9,
        name: "pending_total_sui_withdraw",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 10,
        name: "pending_pool_token_withdraw",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 11,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var StakingPool = new StakingPool$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/epoch.mjs
import { MessageType as MessageType26 } from "@protobuf-ts/runtime";
var Epoch$Type = class extends MessageType26 {
  constructor() {
    super("sui.rpc.v2.Epoch", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "committee",
        kind: "message",
        T: () => ValidatorCommittee
      },
      {
        no: 3,
        name: "system_state",
        kind: "message",
        T: () => SystemState
      },
      {
        no: 4,
        name: "first_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "last_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "start",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 7,
        name: "end",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 8,
        name: "reference_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 9,
        name: "protocol_config",
        kind: "message",
        T: () => ProtocolConfig
      }
    ]);
  }
};
var Epoch = new Epoch$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/checkpoint_contents.mjs
import { MessageType as MessageType27 } from "@protobuf-ts/runtime";
var CheckpointContents$Type = class extends MessageType27 {
  constructor() {
    super("sui.rpc.v2.CheckpointContents", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 5
      },
      {
        no: 4,
        name: "transactions",
        kind: "message",
        repeat: 2,
        T: () => CheckpointedTransactionInfo
      }
    ]);
  }
};
var CheckpointContents = new CheckpointContents$Type();
var CheckpointedTransactionInfo$Type = class extends MessageType27 {
  constructor() {
    super("sui.rpc.v2.CheckpointedTransactionInfo", [
      {
        no: 1,
        name: "transaction",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "effects",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => UserSignature
      },
      {
        no: 4,
        name: "address_aliases_versions",
        kind: "message",
        repeat: 2,
        T: () => AddressAliasesVersion
      }
    ]);
  }
};
var CheckpointedTransactionInfo = new CheckpointedTransactionInfo$Type();
var AddressAliasesVersion$Type = class extends MessageType27 {
  constructor() {
    super("sui.rpc.v2.AddressAliasesVersion", [{
      no: 1,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var AddressAliasesVersion = new AddressAliasesVersion$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/checkpoint_summary.mjs
import { MessageType as MessageType28 } from "@protobuf-ts/runtime";
var CheckpointCommitment_CheckpointCommitmentKind = /* @__PURE__ */ (function(CheckpointCommitment_CheckpointCommitmentKind$1) {
  CheckpointCommitment_CheckpointCommitmentKind$1[CheckpointCommitment_CheckpointCommitmentKind$1["CHECKPOINT_COMMITMENT_KIND_UNKNOWN"] = 0] = "CHECKPOINT_COMMITMENT_KIND_UNKNOWN";
  CheckpointCommitment_CheckpointCommitmentKind$1[CheckpointCommitment_CheckpointCommitmentKind$1["ECMH_LIVE_OBJECT_SET"] = 1] = "ECMH_LIVE_OBJECT_SET";
  CheckpointCommitment_CheckpointCommitmentKind$1[CheckpointCommitment_CheckpointCommitmentKind$1["CHECKPOINT_ARTIFACTS"] = 2] = "CHECKPOINT_ARTIFACTS";
  return CheckpointCommitment_CheckpointCommitmentKind$1;
})({});
var CheckpointSummary$Type = class extends MessageType28 {
  constructor() {
    super("sui.rpc.v2.CheckpointSummary", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "sequence_number",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "total_network_transactions",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "content_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "previous_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "epoch_rolling_gas_cost_summary",
        kind: "message",
        T: () => GasCostSummary2
      },
      {
        no: 9,
        name: "timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 10,
        name: "commitments",
        kind: "message",
        repeat: 2,
        T: () => CheckpointCommitment
      },
      {
        no: 11,
        name: "end_of_epoch_data",
        kind: "message",
        T: () => EndOfEpochData
      },
      {
        no: 12,
        name: "version_specific_data",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var CheckpointSummary = new CheckpointSummary$Type();
var EndOfEpochData$Type = class extends MessageType28 {
  constructor() {
    super("sui.rpc.v2.EndOfEpochData", [
      {
        no: 1,
        name: "next_epoch_committee",
        kind: "message",
        repeat: 2,
        T: () => ValidatorCommitteeMember
      },
      {
        no: 2,
        name: "next_epoch_protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "epoch_commitments",
        kind: "message",
        repeat: 2,
        T: () => CheckpointCommitment
      }
    ]);
  }
};
var EndOfEpochData = new EndOfEpochData$Type();
var CheckpointCommitment$Type = class extends MessageType28 {
  constructor() {
    super("sui.rpc.v2.CheckpointCommitment", [{
      no: 1,
      name: "kind",
      kind: "enum",
      opt: true,
      T: () => ["sui.rpc.v2.CheckpointCommitment.CheckpointCommitmentKind", CheckpointCommitment_CheckpointCommitmentKind]
    }, {
      no: 2,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var CheckpointCommitment = new CheckpointCommitment$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/checkpoint.mjs
import { MessageType as MessageType29 } from "@protobuf-ts/runtime";
var Checkpoint$Type = class extends MessageType29 {
  constructor() {
    super("sui.rpc.v2.Checkpoint", [
      {
        no: 1,
        name: "sequence_number",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "summary",
        kind: "message",
        T: () => CheckpointSummary
      },
      {
        no: 4,
        name: "signature",
        kind: "message",
        T: () => ValidatorAggregatedSignature
      },
      {
        no: 5,
        name: "contents",
        kind: "message",
        T: () => CheckpointContents
      },
      {
        no: 6,
        name: "transactions",
        kind: "message",
        repeat: 2,
        T: () => ExecutedTransaction
      },
      {
        no: 7,
        name: "objects",
        kind: "message",
        T: () => ObjectSet
      }
    ]);
  }
};
var Checkpoint = new Checkpoint$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/any.mjs
import { MessageType as MessageType30, isJsonObject as isJsonObject2, jsonWriteOptions, typeofJsonValue as typeofJsonValue5 } from "@protobuf-ts/runtime";
var Any$Type = class extends MessageType30 {
  constructor() {
    super("google.protobuf.Any", [{
      no: 1,
      name: "type_url",
      kind: "scalar",
      T: 9
    }, {
      no: 2,
      name: "value",
      kind: "scalar",
      T: 12
    }]);
  }
  /**
  * Pack the message into a new `Any`.
  *
  * Uses 'type.googleapis.com/full.type.name' as the type URL.
  */
  pack(message, type) {
    return {
      typeUrl: this.typeNameToUrl(type.typeName),
      value: type.toBinary(message)
    };
  }
  /**
  * Unpack the message from the `Any`.
  */
  unpack(any, type, options) {
    if (!this.contains(any, type)) throw new Error("Cannot unpack google.protobuf.Any with typeUrl '" + any.typeUrl + "' as " + type.typeName + ".");
    return type.fromBinary(any.value, options);
  }
  /**
  * Does the given `Any` contain a packed message of the given type?
  */
  contains(any, type) {
    if (!any.typeUrl.length) return false;
    return (typeof type == "string" ? type : type.typeName) === this.typeUrlToName(any.typeUrl);
  }
  /**
  * Convert the message to canonical JSON value.
  *
  * You have to provide the `typeRegistry` option so that the
  * packed message can be converted to JSON.
  *
  * The `typeRegistry` option is also required to read
  * `google.protobuf.Any` from JSON format.
  */
  internalJsonWrite(any, options) {
    if (any.typeUrl === "") return {};
    let typeName = this.typeUrlToName(any.typeUrl);
    let opt = jsonWriteOptions(options);
    let type = opt.typeRegistry?.find((t) => t.typeName === typeName);
    if (!type) throw new globalThis.Error("Unable to convert google.protobuf.Any with typeUrl '" + any.typeUrl + "' to JSON. The specified type " + typeName + " is not available in the type registry.");
    let value = type.fromBinary(any.value, { readUnknownField: false });
    let json = type.internalJsonWrite(value, opt);
    if (typeName.startsWith("google.protobuf.") || !isJsonObject2(json)) json = { value: json };
    json["@type"] = any.typeUrl;
    return json;
  }
  internalJsonRead(json, options, target) {
    if (!isJsonObject2(json)) throw new globalThis.Error("Unable to parse google.protobuf.Any from JSON " + typeofJsonValue5(json) + ".");
    if (typeof json["@type"] != "string" || json["@type"] == "") return this.create();
    let typeName = this.typeUrlToName(json["@type"]);
    let type = options?.typeRegistry?.find((t) => t.typeName == typeName);
    if (!type) throw new globalThis.Error("Unable to parse google.protobuf.Any from JSON. The specified type " + typeName + " is not available in the type registry.");
    let value;
    if (typeName.startsWith("google.protobuf.") && json.hasOwnProperty("value")) value = type.fromJson(json["value"], options);
    else {
      let copy = Object.assign({}, json);
      delete copy["@type"];
      value = type.fromJson(copy, options);
    }
    if (target === void 0) target = this.create();
    target.typeUrl = json["@type"];
    target.value = type.toBinary(value);
    return target;
  }
  typeNameToUrl(name) {
    if (!name.length) throw new Error("invalid type name: " + name);
    return "type.googleapis.com/" + name;
  }
  typeUrlToName(url) {
    if (!url.length) throw new Error("invalid type url: " + url);
    let slash = url.lastIndexOf("/");
    let name = slash > 0 ? url.substring(slash + 1) : url;
    if (!name.length) throw new Error("invalid type url: " + url);
    return name;
  }
};
var Any = new Any$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/google/rpc/status.mjs
import { MessageType as MessageType31 } from "@protobuf-ts/runtime";
var Status$Type = class extends MessageType31 {
  constructor() {
    super("google.rpc.Status", [
      {
        no: 1,
        name: "code",
        kind: "scalar",
        T: 5
      },
      {
        no: 2,
        name: "message",
        kind: "scalar",
        T: 9
      },
      {
        no: 3,
        name: "details",
        kind: "message",
        repeat: 2,
        T: () => Any
      }
    ]);
  }
};
var Status = new Status$Type();

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/ledger_service.mjs
import { MessageType as MessageType32 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType2 } from "@protobuf-ts/runtime-rpc";
var GetServiceInfoRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetServiceInfoRequest", []);
  }
};
var GetServiceInfoRequest = new GetServiceInfoRequest$Type();
var GetServiceInfoResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetServiceInfoResponse", [
      {
        no: 1,
        name: "chain_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "chain",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "checkpoint_height",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 6,
        name: "lowest_available_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "lowest_available_checkpoint_objects",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "server",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var GetServiceInfoResponse = new GetServiceInfoResponse$Type();
var GetObjectRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetObjectRequest", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var GetObjectRequest = new GetObjectRequest$Type();
var GetObjectResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetObjectResponse", [{
      no: 1,
      name: "object",
      kind: "message",
      T: () => Object$1
    }]);
  }
};
var GetObjectResponse = new GetObjectResponse$Type();
var BatchGetObjectsRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.BatchGetObjectsRequest", [{
      no: 1,
      name: "requests",
      kind: "message",
      repeat: 2,
      T: () => GetObjectRequest
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var BatchGetObjectsRequest = new BatchGetObjectsRequest$Type();
var BatchGetObjectsResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.BatchGetObjectsResponse", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => GetObjectResult
    }]);
  }
};
var BatchGetObjectsResponse = new BatchGetObjectsResponse$Type();
var GetObjectResult$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetObjectResult", [{
      no: 1,
      name: "object",
      kind: "message",
      oneof: "result",
      T: () => Object$1
    }, {
      no: 2,
      name: "error",
      kind: "message",
      oneof: "result",
      T: () => Status
    }]);
  }
};
var GetObjectResult = new GetObjectResult$Type();
var GetTransactionRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetTransactionRequest", [{
      no: 1,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var GetTransactionRequest = new GetTransactionRequest$Type();
var GetTransactionResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetTransactionResponse", [{
      no: 1,
      name: "transaction",
      kind: "message",
      T: () => ExecutedTransaction
    }]);
  }
};
var GetTransactionResponse = new GetTransactionResponse$Type();
var BatchGetTransactionsRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.BatchGetTransactionsRequest", [{
      no: 1,
      name: "digests",
      kind: "scalar",
      repeat: 2,
      T: 9
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var BatchGetTransactionsRequest = new BatchGetTransactionsRequest$Type();
var BatchGetTransactionsResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.BatchGetTransactionsResponse", [{
      no: 1,
      name: "transactions",
      kind: "message",
      repeat: 2,
      T: () => GetTransactionResult
    }]);
  }
};
var BatchGetTransactionsResponse = new BatchGetTransactionsResponse$Type();
var GetTransactionResult$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetTransactionResult", [{
      no: 1,
      name: "transaction",
      kind: "message",
      oneof: "result",
      T: () => ExecutedTransaction
    }, {
      no: 2,
      name: "error",
      kind: "message",
      oneof: "result",
      T: () => Status
    }]);
  }
};
var GetTransactionResult = new GetTransactionResult$Type();
var GetCheckpointRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetCheckpointRequest", [
      {
        no: 1,
        name: "sequence_number",
        kind: "scalar",
        oneof: "checkpointId",
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        oneof: "checkpointId",
        T: 9
      },
      {
        no: 3,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var GetCheckpointRequest = new GetCheckpointRequest$Type();
var GetCheckpointResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetCheckpointResponse", [{
      no: 1,
      name: "checkpoint",
      kind: "message",
      T: () => Checkpoint
    }]);
  }
};
var GetCheckpointResponse = new GetCheckpointResponse$Type();
var GetEpochRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetEpochRequest", [{
      no: 1,
      name: "epoch",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var GetEpochRequest = new GetEpochRequest$Type();
var GetEpochResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.GetEpochResponse", [{
      no: 1,
      name: "epoch",
      kind: "message",
      T: () => Epoch
    }]);
  }
};
var GetEpochResponse = new GetEpochResponse$Type();
var ListCheckpointsRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListCheckpointsRequest", [
      {
        no: 1,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 2,
        name: "start_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "end_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "filter",
        kind: "message",
        T: () => TransactionFilter
      },
      {
        no: 5,
        name: "options",
        kind: "message",
        T: () => QueryOptions
      }
    ]);
  }
};
var ListCheckpointsRequest = new ListCheckpointsRequest$Type();
var ListCheckpointsResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListCheckpointsResponse", [
      {
        no: 1,
        name: "checkpoint",
        kind: "message",
        T: () => Checkpoint
      },
      {
        no: 2,
        name: "watermark",
        kind: "message",
        T: () => Watermark
      },
      {
        no: 3,
        name: "end",
        kind: "message",
        T: () => QueryEnd
      }
    ]);
  }
};
var ListCheckpointsResponse = new ListCheckpointsResponse$Type();
var ListTransactionsRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListTransactionsRequest", [
      {
        no: 1,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 2,
        name: "start_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "end_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "filter",
        kind: "message",
        T: () => TransactionFilter
      },
      {
        no: 5,
        name: "options",
        kind: "message",
        T: () => QueryOptions
      }
    ]);
  }
};
var ListTransactionsRequest = new ListTransactionsRequest$Type();
var ListTransactionsResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListTransactionsResponse", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => ExecutedTransaction
      },
      {
        no: 2,
        name: "watermark",
        kind: "message",
        T: () => Watermark
      },
      {
        no: 3,
        name: "end",
        kind: "message",
        T: () => QueryEnd
      }
    ]);
  }
};
var ListTransactionsResponse = new ListTransactionsResponse$Type();
var ListEventsRequest$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListEventsRequest", [
      {
        no: 1,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 2,
        name: "start_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "end_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "filter",
        kind: "message",
        T: () => EventFilter
      },
      {
        no: 5,
        name: "options",
        kind: "message",
        T: () => QueryOptions
      }
    ]);
  }
};
var ListEventsRequest = new ListEventsRequest$Type();
var ListEventsResponse$Type = class extends MessageType32 {
  constructor() {
    super("sui.rpc.v2.ListEventsResponse", [
      {
        no: 1,
        name: "event",
        kind: "message",
        T: () => Event
      },
      {
        no: 2,
        name: "watermark",
        kind: "message",
        T: () => Watermark
      },
      {
        no: 3,
        name: "end",
        kind: "message",
        T: () => QueryEnd
      }
    ]);
  }
};
var ListEventsResponse = new ListEventsResponse$Type();
var LedgerService = new ServiceType2("sui.rpc.v2.LedgerService", [
  {
    name: "GetServiceInfo",
    options: {},
    I: GetServiceInfoRequest,
    O: GetServiceInfoResponse
  },
  {
    name: "GetObject",
    options: {},
    I: GetObjectRequest,
    O: GetObjectResponse
  },
  {
    name: "BatchGetObjects",
    options: {},
    I: BatchGetObjectsRequest,
    O: BatchGetObjectsResponse
  },
  {
    name: "GetTransaction",
    options: {},
    I: GetTransactionRequest,
    O: GetTransactionResponse
  },
  {
    name: "BatchGetTransactions",
    options: {},
    I: BatchGetTransactionsRequest,
    O: BatchGetTransactionsResponse
  },
  {
    name: "GetCheckpoint",
    options: {},
    I: GetCheckpointRequest,
    O: GetCheckpointResponse
  },
  {
    name: "GetEpoch",
    options: {},
    I: GetEpochRequest,
    O: GetEpochResponse
  },
  {
    name: "ListCheckpoints",
    serverStreaming: true,
    options: {},
    I: ListCheckpointsRequest,
    O: ListCheckpointsResponse
  },
  {
    name: "ListTransactions",
    serverStreaming: true,
    options: {},
    I: ListTransactionsRequest,
    O: ListTransactionsResponse
  },
  {
    name: "ListEvents",
    serverStreaming: true,
    options: {},
    I: ListEventsRequest,
    O: ListEventsResponse
  }
]);

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/ledger_service.client.mjs
import { stackIntercept as stackIntercept2 } from "@protobuf-ts/runtime-rpc";
var LedgerServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = LedgerService.typeName;
    this.methods = LedgerService.methods;
    this.options = LedgerService.options;
  }
  /**
  * Query the service for general information about its current state.
  *
  * @generated from protobuf rpc: GetServiceInfo(sui.rpc.v2.GetServiceInfoRequest) returns (sui.rpc.v2.GetServiceInfoResponse);
  */
  getServiceInfo(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetObject(sui.rpc.v2.GetObjectRequest) returns (sui.rpc.v2.GetObjectResponse);
  */
  getObject(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: BatchGetObjects(sui.rpc.v2.BatchGetObjectsRequest) returns (sui.rpc.v2.BatchGetObjectsResponse);
  */
  batchGetObjects(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetTransaction(sui.rpc.v2.GetTransactionRequest) returns (sui.rpc.v2.GetTransactionResponse);
  */
  getTransaction(input, options) {
    const method = this.methods[3], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: BatchGetTransactions(sui.rpc.v2.BatchGetTransactionsRequest) returns (sui.rpc.v2.BatchGetTransactionsResponse);
  */
  batchGetTransactions(input, options) {
    const method = this.methods[4], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetCheckpoint(sui.rpc.v2.GetCheckpointRequest) returns (sui.rpc.v2.GetCheckpointResponse);
  */
  getCheckpoint(input, options) {
    const method = this.methods[5], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetEpoch(sui.rpc.v2.GetEpochRequest) returns (sui.rpc.v2.GetEpochResponse);
  */
  getEpoch(input, options) {
    const method = this.methods[6], opt = this._transport.mergeOptions(options);
    return stackIntercept2("unary", this._transport, method, opt, input);
  }
  /**
  * List checkpoints matching the provided filters.
  *
  * Checkpoints are returned in ascending or descending checkpoint sequence
  * number order according to the query options ordering.
  * A checkpoint matches if any transaction it contains satisfies the filter.
  *
  * @generated from protobuf rpc: ListCheckpoints(sui.rpc.v2.ListCheckpointsRequest) returns (stream sui.rpc.v2.ListCheckpointsResponse);
  */
  listCheckpoints(input, options) {
    const method = this.methods[7], opt = this._transport.mergeOptions(options);
    return stackIntercept2("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * List transactions matching the provided filters.
  *
  * Transactions are returned in ascending or descending transaction sequence
  * order according to the query options ordering.
  *
  * @generated from protobuf rpc: ListTransactions(sui.rpc.v2.ListTransactionsRequest) returns (stream sui.rpc.v2.ListTransactionsResponse);
  */
  listTransactions(input, options) {
    const method = this.methods[8], opt = this._transport.mergeOptions(options);
    return stackIntercept2("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * List events matching the provided filters.
  *
  * Events are returned in ascending or descending packed event sequence order
  * according to the query options ordering.
  *
  * @generated from protobuf rpc: ListEvents(sui.rpc.v2.ListEventsRequest) returns (stream sui.rpc.v2.ListEventsResponse);
  */
  listEvents(input, options) {
    const method = this.methods[9], opt = this._transport.mergeOptions(options);
    return stackIntercept2("serverStreaming", this._transport, method, opt, input);
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/move_package_service.mjs
import { MessageType as MessageType33 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType3 } from "@protobuf-ts/runtime-rpc";
var GetPackageRequest$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetPackageRequest", [{
      no: 1,
      name: "package_id",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var GetPackageRequest = new GetPackageRequest$Type();
var GetPackageResponse$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetPackageResponse", [{
      no: 1,
      name: "package",
      kind: "message",
      T: () => Package
    }]);
  }
};
var GetPackageResponse = new GetPackageResponse$Type();
var GetDatatypeRequest$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetDatatypeRequest", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var GetDatatypeRequest = new GetDatatypeRequest$Type();
var GetDatatypeResponse$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetDatatypeResponse", [{
      no: 1,
      name: "datatype",
      kind: "message",
      T: () => DatatypeDescriptor
    }]);
  }
};
var GetDatatypeResponse = new GetDatatypeResponse$Type();
var GetFunctionRequest$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetFunctionRequest", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var GetFunctionRequest = new GetFunctionRequest$Type();
var GetFunctionResponse$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.GetFunctionResponse", [{
      no: 1,
      name: "function",
      kind: "message",
      T: () => FunctionDescriptor
    }]);
  }
};
var GetFunctionResponse = new GetFunctionResponse$Type();
var ListPackageVersionsRequest$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.ListPackageVersionsRequest", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var ListPackageVersionsRequest = new ListPackageVersionsRequest$Type();
var ListPackageVersionsResponse$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.ListPackageVersionsResponse", [{
      no: 1,
      name: "versions",
      kind: "message",
      repeat: 2,
      T: () => PackageVersion
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListPackageVersionsResponse = new ListPackageVersionsResponse$Type();
var PackageVersion$Type = class extends MessageType33 {
  constructor() {
    super("sui.rpc.v2.PackageVersion", [{
      no: 1,
      name: "package_id",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var PackageVersion = new PackageVersion$Type();
var MovePackageService = new ServiceType3("sui.rpc.v2.MovePackageService", [
  {
    name: "GetPackage",
    options: {},
    I: GetPackageRequest,
    O: GetPackageResponse
  },
  {
    name: "GetDatatype",
    options: {},
    I: GetDatatypeRequest,
    O: GetDatatypeResponse
  },
  {
    name: "GetFunction",
    options: {},
    I: GetFunctionRequest,
    O: GetFunctionResponse
  },
  {
    name: "ListPackageVersions",
    options: {},
    I: ListPackageVersionsRequest,
    O: ListPackageVersionsResponse
  }
]);

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/move_package_service.client.mjs
import { stackIntercept as stackIntercept3 } from "@protobuf-ts/runtime-rpc";
var MovePackageServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = MovePackageService.typeName;
    this.methods = MovePackageService.methods;
    this.options = MovePackageService.options;
  }
  /**
  * @generated from protobuf rpc: GetPackage(sui.rpc.v2.GetPackageRequest) returns (sui.rpc.v2.GetPackageResponse);
  */
  getPackage(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept3("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetDatatype(sui.rpc.v2.GetDatatypeRequest) returns (sui.rpc.v2.GetDatatypeResponse);
  */
  getDatatype(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept3("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetFunction(sui.rpc.v2.GetFunctionRequest) returns (sui.rpc.v2.GetFunctionResponse);
  */
  getFunction(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return stackIntercept3("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ListPackageVersions(sui.rpc.v2.ListPackageVersionsRequest) returns (sui.rpc.v2.ListPackageVersionsResponse);
  */
  listPackageVersions(input, options) {
    const method = this.methods[3], opt = this._transport.mergeOptions(options);
    return stackIntercept3("unary", this._transport, method, opt, input);
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature_verification_service.mjs
import { MessageType as MessageType34 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType4 } from "@protobuf-ts/runtime-rpc";
var VerifySignatureRequest$Type = class extends MessageType34 {
  constructor() {
    super("sui.rpc.v2.VerifySignatureRequest", [
      {
        no: 1,
        name: "message",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "signature",
        kind: "message",
        T: () => UserSignature
      },
      {
        no: 3,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "jwks",
        kind: "message",
        repeat: 2,
        T: () => ActiveJwk2
      }
    ]);
  }
};
var VerifySignatureRequest = new VerifySignatureRequest$Type();
var VerifySignatureResponse$Type = class extends MessageType34 {
  constructor() {
    super("sui.rpc.v2.VerifySignatureResponse", [{
      no: 1,
      name: "is_valid",
      kind: "scalar",
      opt: true,
      T: 8
    }, {
      no: 2,
      name: "reason",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var VerifySignatureResponse = new VerifySignatureResponse$Type();
var SignatureVerificationService = new ServiceType4("sui.rpc.v2.SignatureVerificationService", [{
  name: "VerifySignature",
  options: {},
  I: VerifySignatureRequest,
  O: VerifySignatureResponse
}]);

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature_verification_service.client.mjs
import { stackIntercept as stackIntercept4 } from "@protobuf-ts/runtime-rpc";
var SignatureVerificationServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = SignatureVerificationService.typeName;
    this.methods = SignatureVerificationService.methods;
    this.options = SignatureVerificationService.options;
  }
  /**
  * Perform signature verification of a UserSignature against the provided message.
  *
  * @generated from protobuf rpc: VerifySignature(sui.rpc.v2.VerifySignatureRequest) returns (sui.rpc.v2.VerifySignatureResponse);
  */
  verifySignature(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept4("unary", this._transport, method, opt, input);
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/state_service.mjs
import { MessageType as MessageType35 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType5 } from "@protobuf-ts/runtime-rpc";
var CoinMetadata_MetadataCapState = /* @__PURE__ */ (function(CoinMetadata_MetadataCapState$1) {
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["METADATA_CAP_STATE_UNKNOWN"] = 0] = "METADATA_CAP_STATE_UNKNOWN";
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["CLAIMED"] = 1] = "CLAIMED";
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["UNCLAIMED"] = 2] = "UNCLAIMED";
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["DELETED"] = 3] = "DELETED";
  return CoinMetadata_MetadataCapState$1;
})({});
var CoinTreasury_SupplyState = /* @__PURE__ */ (function(CoinTreasury_SupplyState$1) {
  CoinTreasury_SupplyState$1[CoinTreasury_SupplyState$1["SUPPLY_STATE_UNKNOWN"] = 0] = "SUPPLY_STATE_UNKNOWN";
  CoinTreasury_SupplyState$1[CoinTreasury_SupplyState$1["FIXED"] = 1] = "FIXED";
  CoinTreasury_SupplyState$1[CoinTreasury_SupplyState$1["BURN_ONLY"] = 2] = "BURN_ONLY";
  return CoinTreasury_SupplyState$1;
})({});
var RegulatedCoinMetadata_CoinRegulatedState = /* @__PURE__ */ (function(RegulatedCoinMetadata_CoinRegulatedState$1) {
  RegulatedCoinMetadata_CoinRegulatedState$1[RegulatedCoinMetadata_CoinRegulatedState$1["COIN_REGULATED_STATE_UNKNOWN"] = 0] = "COIN_REGULATED_STATE_UNKNOWN";
  RegulatedCoinMetadata_CoinRegulatedState$1[RegulatedCoinMetadata_CoinRegulatedState$1["REGULATED"] = 1] = "REGULATED";
  RegulatedCoinMetadata_CoinRegulatedState$1[RegulatedCoinMetadata_CoinRegulatedState$1["UNREGULATED"] = 2] = "UNREGULATED";
  return RegulatedCoinMetadata_CoinRegulatedState$1;
})({});
var DynamicField_DynamicFieldKind = /* @__PURE__ */ (function(DynamicField_DynamicFieldKind$1) {
  DynamicField_DynamicFieldKind$1[DynamicField_DynamicFieldKind$1["DYNAMIC_FIELD_KIND_UNKNOWN"] = 0] = "DYNAMIC_FIELD_KIND_UNKNOWN";
  DynamicField_DynamicFieldKind$1[DynamicField_DynamicFieldKind$1["FIELD"] = 1] = "FIELD";
  DynamicField_DynamicFieldKind$1[DynamicField_DynamicFieldKind$1["OBJECT"] = 2] = "OBJECT";
  return DynamicField_DynamicFieldKind$1;
})({});
var GetCoinInfoRequest$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.GetCoinInfoRequest", [{
      no: 1,
      name: "coin_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var GetCoinInfoRequest = new GetCoinInfoRequest$Type();
var GetCoinInfoResponse$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.GetCoinInfoResponse", [
      {
        no: 1,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "metadata",
        kind: "message",
        T: () => CoinMetadata
      },
      {
        no: 3,
        name: "treasury",
        kind: "message",
        T: () => CoinTreasury
      },
      {
        no: 4,
        name: "regulated_metadata",
        kind: "message",
        T: () => RegulatedCoinMetadata
      }
    ]);
  }
};
var GetCoinInfoResponse = new GetCoinInfoResponse$Type();
var CoinMetadata$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.CoinMetadata", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "decimals",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "symbol",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "description",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "icon_url",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "metadata_cap_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "metadata_cap_state",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.CoinMetadata.MetadataCapState", CoinMetadata_MetadataCapState]
      }
    ]);
  }
};
var CoinMetadata = new CoinMetadata$Type();
var CoinTreasury$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.CoinTreasury", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "total_supply",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "supply_state",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.CoinTreasury.SupplyState", CoinTreasury_SupplyState]
      }
    ]);
  }
};
var CoinTreasury = new CoinTreasury$Type();
var RegulatedCoinMetadata$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.RegulatedCoinMetadata", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "coin_metadata_object",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "deny_cap_object",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "allow_global_pause",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 5,
        name: "variant",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 6,
        name: "coin_regulated_state",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.RegulatedCoinMetadata.CoinRegulatedState", RegulatedCoinMetadata_CoinRegulatedState]
      }
    ]);
  }
};
var RegulatedCoinMetadata = new RegulatedCoinMetadata$Type();
var GetBalanceRequest$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.GetBalanceRequest", [{
      no: 1,
      name: "owner",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "coin_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var GetBalanceRequest = new GetBalanceRequest$Type();
var GetBalanceResponse$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.GetBalanceResponse", [{
      no: 1,
      name: "balance",
      kind: "message",
      T: () => Balance
    }]);
  }
};
var GetBalanceResponse = new GetBalanceResponse$Type();
var ListBalancesRequest$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListBalancesRequest", [
      {
        no: 1,
        name: "owner",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var ListBalancesRequest = new ListBalancesRequest$Type();
var ListBalancesResponse$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListBalancesResponse", [{
      no: 1,
      name: "balances",
      kind: "message",
      repeat: 2,
      T: () => Balance
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListBalancesResponse = new ListBalancesResponse$Type();
var Balance$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.Balance", [
      {
        no: 1,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "address_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "coin_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var Balance = new Balance$Type();
var ListDynamicFieldsRequest$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListDynamicFieldsRequest", [
      {
        no: 1,
        name: "parent",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var ListDynamicFieldsRequest = new ListDynamicFieldsRequest$Type();
var ListDynamicFieldsResponse$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListDynamicFieldsResponse", [{
      no: 1,
      name: "dynamic_fields",
      kind: "message",
      repeat: 2,
      T: () => DynamicField
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListDynamicFieldsResponse = new ListDynamicFieldsResponse$Type();
var DynamicField$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.DynamicField", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.DynamicField.DynamicFieldKind", DynamicField_DynamicFieldKind]
      },
      {
        no: 2,
        name: "parent",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "field_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "field_object",
        kind: "message",
        T: () => Object$1
      },
      {
        no: 5,
        name: "name",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 6,
        name: "value",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 7,
        name: "value_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "child_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 9,
        name: "child_object",
        kind: "message",
        T: () => Object$1
      }
    ]);
  }
};
var DynamicField = new DynamicField$Type();
var ListOwnedObjectsRequest$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListOwnedObjectsRequest", [
      {
        no: 1,
        name: "owner",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 5,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ListOwnedObjectsRequest = new ListOwnedObjectsRequest$Type();
var ListOwnedObjectsResponse$Type = class extends MessageType35 {
  constructor() {
    super("sui.rpc.v2.ListOwnedObjectsResponse", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Object$1
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListOwnedObjectsResponse = new ListOwnedObjectsResponse$Type();
var StateService = new ServiceType5("sui.rpc.v2.StateService", [
  {
    name: "ListDynamicFields",
    options: {},
    I: ListDynamicFieldsRequest,
    O: ListDynamicFieldsResponse
  },
  {
    name: "ListOwnedObjects",
    options: {},
    I: ListOwnedObjectsRequest,
    O: ListOwnedObjectsResponse
  },
  {
    name: "GetCoinInfo",
    options: {},
    I: GetCoinInfoRequest,
    O: GetCoinInfoResponse
  },
  {
    name: "GetBalance",
    options: {},
    I: GetBalanceRequest,
    O: GetBalanceResponse
  },
  {
    name: "ListBalances",
    options: {},
    I: ListBalancesRequest,
    O: ListBalancesResponse
  }
]);

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/state_service.client.mjs
import { stackIntercept as stackIntercept5 } from "@protobuf-ts/runtime-rpc";
var StateServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = StateService.typeName;
    this.methods = StateService.methods;
    this.options = StateService.options;
  }
  /**
  * @generated from protobuf rpc: ListDynamicFields(sui.rpc.v2.ListDynamicFieldsRequest) returns (sui.rpc.v2.ListDynamicFieldsResponse);
  */
  listDynamicFields(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept5("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ListOwnedObjects(sui.rpc.v2.ListOwnedObjectsRequest) returns (sui.rpc.v2.ListOwnedObjectsResponse);
  */
  listOwnedObjects(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept5("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetCoinInfo(sui.rpc.v2.GetCoinInfoRequest) returns (sui.rpc.v2.GetCoinInfoResponse);
  */
  getCoinInfo(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return stackIntercept5("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetBalance(sui.rpc.v2.GetBalanceRequest) returns (sui.rpc.v2.GetBalanceResponse);
  */
  getBalance(input, options) {
    const method = this.methods[3], opt = this._transport.mergeOptions(options);
    return stackIntercept5("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ListBalances(sui.rpc.v2.ListBalancesRequest) returns (sui.rpc.v2.ListBalancesResponse);
  */
  listBalances(input, options) {
    const method = this.methods[4], opt = this._transport.mergeOptions(options);
    return stackIntercept5("unary", this._transport, method, opt, input);
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/subscription_service.mjs
import { MessageType as MessageType36 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType6 } from "@protobuf-ts/runtime-rpc";
var SubscribeCheckpointsRequest$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeCheckpointsRequest", [{
      no: 1,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }, {
      no: 2,
      name: "filter",
      kind: "message",
      T: () => TransactionFilter
    }]);
  }
};
var SubscribeCheckpointsRequest = new SubscribeCheckpointsRequest$Type();
var SubscribeCheckpointsResponse$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeCheckpointsResponse", [{
      no: 1,
      name: "cursor",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "checkpoint",
      kind: "message",
      T: () => Checkpoint
    }]);
  }
};
var SubscribeCheckpointsResponse = new SubscribeCheckpointsResponse$Type();
var SubscribeTransactionsRequest$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeTransactionsRequest", [{
      no: 1,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }, {
      no: 2,
      name: "filter",
      kind: "message",
      T: () => TransactionFilter
    }]);
  }
};
var SubscribeTransactionsRequest = new SubscribeTransactionsRequest$Type();
var SubscribeTransactionsResponse$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeTransactionsResponse", [{
      no: 1,
      name: "transaction",
      kind: "message",
      T: () => ExecutedTransaction
    }, {
      no: 2,
      name: "watermark",
      kind: "message",
      T: () => Watermark
    }]);
  }
};
var SubscribeTransactionsResponse = new SubscribeTransactionsResponse$Type();
var SubscribeEventsRequest$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeEventsRequest", [{
      no: 1,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }, {
      no: 2,
      name: "filter",
      kind: "message",
      T: () => EventFilter
    }]);
  }
};
var SubscribeEventsRequest = new SubscribeEventsRequest$Type();
var SubscribeEventsResponse$Type = class extends MessageType36 {
  constructor() {
    super("sui.rpc.v2.SubscribeEventsResponse", [{
      no: 1,
      name: "event",
      kind: "message",
      T: () => Event
    }, {
      no: 2,
      name: "watermark",
      kind: "message",
      T: () => Watermark
    }]);
  }
};
var SubscribeEventsResponse = new SubscribeEventsResponse$Type();
var SubscriptionService = new ServiceType6("sui.rpc.v2.SubscriptionService", [
  {
    name: "SubscribeCheckpoints",
    serverStreaming: true,
    options: {},
    I: SubscribeCheckpointsRequest,
    O: SubscribeCheckpointsResponse
  },
  {
    name: "SubscribeTransactions",
    serverStreaming: true,
    options: {},
    I: SubscribeTransactionsRequest,
    O: SubscribeTransactionsResponse
  },
  {
    name: "SubscribeEvents",
    serverStreaming: true,
    options: {},
    I: SubscribeEventsRequest,
    O: SubscribeEventsResponse
  }
]);

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/subscription_service.client.mjs
import { stackIntercept as stackIntercept6 } from "@protobuf-ts/runtime-rpc";
var SubscriptionServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = SubscriptionService.typeName;
    this.methods = SubscriptionService.methods;
    this.options = SubscriptionService.options;
  }
  /**
  * Subscribe to the stream of checkpoints.
  *
  * The stream begins at the latest executed checkpoint as seen by the
  * server and yields checkpoints matching the filter as they are executed.
  * A checkpoint matches if any transaction it contains satisfies the
  * filter.
  *
  * @generated from protobuf rpc: SubscribeCheckpoints(sui.rpc.v2.SubscribeCheckpointsRequest) returns (stream sui.rpc.v2.SubscribeCheckpointsResponse);
  */
  subscribeCheckpoints(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept6("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * Subscribe to the stream of transactions.
  *
  * The stream begins at the latest executed checkpoint as seen by the
  * server and yields transactions matching the filter as they are executed.
  *
  * @generated from protobuf rpc: SubscribeTransactions(sui.rpc.v2.SubscribeTransactionsRequest) returns (stream sui.rpc.v2.SubscribeTransactionsResponse);
  */
  subscribeTransactions(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept6("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * Subscribe to the stream of events.
  *
  * The stream begins at the latest executed checkpoint as seen by the
  * server and yields events matching the filter as they are emitted.
  *
  * @generated from protobuf rpc: SubscribeEvents(sui.rpc.v2.SubscribeEventsRequest) returns (stream sui.rpc.v2.SubscribeEventsResponse);
  */
  subscribeEvents(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return stackIntercept6("serverStreaming", this._transport, method, opt, input);
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/name_service.mjs
import { MessageType as MessageType37 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType7 } from "@protobuf-ts/runtime-rpc";
var LookupNameRequest$Type = class extends MessageType37 {
  constructor() {
    super("sui.rpc.v2.LookupNameRequest", [{
      no: 1,
      name: "name",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var LookupNameRequest = new LookupNameRequest$Type();
var LookupNameResponse$Type = class extends MessageType37 {
  constructor() {
    super("sui.rpc.v2.LookupNameResponse", [{
      no: 1,
      name: "record",
      kind: "message",
      T: () => NameRecord
    }]);
  }
};
var LookupNameResponse = new LookupNameResponse$Type();
var ReverseLookupNameRequest$Type = class extends MessageType37 {
  constructor() {
    super("sui.rpc.v2.ReverseLookupNameRequest", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var ReverseLookupNameRequest = new ReverseLookupNameRequest$Type();
var ReverseLookupNameResponse$Type = class extends MessageType37 {
  constructor() {
    super("sui.rpc.v2.ReverseLookupNameResponse", [{
      no: 1,
      name: "record",
      kind: "message",
      T: () => NameRecord
    }]);
  }
};
var ReverseLookupNameResponse = new ReverseLookupNameResponse$Type();
var NameRecord$Type = class extends MessageType37 {
  constructor() {
    super("sui.rpc.v2.NameRecord", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "registration_nft_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "expiration_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 5,
        name: "target_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "data",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 9
        }
      }
    ]);
  }
};
var NameRecord = new NameRecord$Type();
var NameService = new ServiceType7("sui.rpc.v2.NameService", [{
  name: "LookupName",
  options: {},
  I: LookupNameRequest,
  O: LookupNameResponse
}, {
  name: "ReverseLookupName",
  options: {},
  I: ReverseLookupNameRequest,
  O: ReverseLookupNameResponse
}]);

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/name_service.client.mjs
import { stackIntercept as stackIntercept7 } from "@protobuf-ts/runtime-rpc";
var NameServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = NameService.typeName;
    this.methods = NameService.methods;
    this.options = NameService.options;
  }
  /**
  * @generated from protobuf rpc: LookupName(sui.rpc.v2.LookupNameRequest) returns (sui.rpc.v2.LookupNameResponse);
  */
  lookupName(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept7("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ReverseLookupName(sui.rpc.v2.ReverseLookupNameRequest) returns (sui.rpc.v2.ReverseLookupNameResponse);
  */
  reverseLookupName(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept7("unary", this._transport, method, opt, input);
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/forking/v1alpha/forking_service.mjs
import { MessageType as MessageType38 } from "@protobuf-ts/runtime";
import { ServiceType as ServiceType8 } from "@protobuf-ts/runtime-rpc";
var AdvanceClockRequest$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.AdvanceClockRequest", [{
      no: 1,
      name: "duration_ms",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var AdvanceClockRequest = new AdvanceClockRequest$Type();
var AdvanceClockResponse$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.AdvanceClockResponse", [{
      no: 1,
      name: "timestamp_ms",
      kind: "scalar",
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "tx_digest",
      kind: "scalar",
      T: 9
    }]);
  }
};
var AdvanceClockResponse = new AdvanceClockResponse$Type();
var AdvanceCheckpointRequest$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.AdvanceCheckpointRequest", []);
  }
};
var AdvanceCheckpointRequest = new AdvanceCheckpointRequest$Type();
var AdvanceCheckpointResponse$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.AdvanceCheckpointResponse", [{
      no: 1,
      name: "checkpoint_sequence_number",
      kind: "scalar",
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "timestamp_ms",
      kind: "scalar",
      T: 4,
      L: 0
    }]);
  }
};
var AdvanceCheckpointResponse = new AdvanceCheckpointResponse$Type();
var GetStatusRequest$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.GetStatusRequest", []);
  }
};
var GetStatusRequest = new GetStatusRequest$Type();
var GetStatusResponse$Type = class extends MessageType38 {
  constructor() {
    super("sui.forking.v1alpha.GetStatusResponse", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "checkpoint_sequence_number",
        kind: "scalar",
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "timestamp_ms",
        kind: "scalar",
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "forked_at_checkpoint",
        kind: "scalar",
        T: 4,
        L: 0
      }
    ]);
  }
};
var GetStatusResponse = new GetStatusResponse$Type();
var ForkingService = new ServiceType8("sui.forking.v1alpha.ForkingService", [
  {
    name: "AdvanceClock",
    options: {},
    I: AdvanceClockRequest,
    O: AdvanceClockResponse
  },
  {
    name: "AdvanceCheckpoint",
    options: {},
    I: AdvanceCheckpointRequest,
    O: AdvanceCheckpointResponse
  },
  {
    name: "GetStatus",
    options: {},
    I: GetStatusRequest,
    O: GetStatusResponse
  }
]);

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/proto/sui/forking/v1alpha/forking_service.client.mjs
import { stackIntercept as stackIntercept8 } from "@protobuf-ts/runtime-rpc";
var ForkingServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = ForkingService.typeName;
    this.methods = ForkingService.methods;
    this.options = ForkingService.options;
  }
  /**
  * Advance the forked network's clock by a given duration.
  *
  * @generated from protobuf rpc: AdvanceClock(sui.forking.v1alpha.AdvanceClockRequest) returns (sui.forking.v1alpha.AdvanceClockResponse);
  */
  advanceClock(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return stackIntercept8("unary", this._transport, method, opt, input);
  }
  /**
  * Seal pending transactions into a new checkpoint.
  *
  * @generated from protobuf rpc: AdvanceCheckpoint(sui.forking.v1alpha.AdvanceCheckpointRequest) returns (sui.forking.v1alpha.AdvanceCheckpointResponse);
  */
  advanceCheckpoint(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return stackIntercept8("unary", this._transport, method, opt, input);
  }
  /**
  * Return the current state of the forked network.
  *
  * @generated from protobuf rpc: GetStatus(sui.forking.v1alpha.GetStatusRequest) returns (sui.forking.v1alpha.GetStatusResponse);
  */
  getStatus(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return stackIntercept8("unary", this._transport, method, opt, input);
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/client.mjs
import { fromBase64 as fromBase645, toBase64 as toBase646 } from "@mysten/utils";
var SUI_CLIENT_BRAND = /* @__PURE__ */ Symbol.for("@mysten/SuiGrpcClient");
var SuiGrpcClient = class extends BaseClient {
  get mvr() {
    return this.core.mvr;
  }
  get [SUI_CLIENT_BRAND]() {
    return true;
  }
  constructor(options) {
    super({ network: options.network });
    const { network: _network, mvr: _mvr, abort: _abort, transport: providedTransport, ...transportOptions } = options;
    const transport = withClientProtocolVersion(providedTransport ?? new GrpcWebFetchTransport$1(transportOptions));
    this.transactionExecutionService = new TransactionExecutionServiceClient(transport);
    this.ledgerService = new LedgerServiceClient(transport);
    this.stateService = new StateServiceClient(transport);
    this.subscriptionService = new SubscriptionServiceClient(transport);
    this.movePackageService = new MovePackageServiceClient(transport);
    this.signatureVerificationService = new SignatureVerificationServiceClient(transport);
    this.nameService = new NameServiceClient(transport);
    this.forkingService = new ForkingServiceClient(transport);
    this.core = new GrpcCoreClient({
      client: this,
      base: this,
      network: options.network,
      mvr: options.mvr
    });
  }
  getObjects(input) {
    return this.core.getObjects(input);
  }
  getObject(input) {
    return this.core.getObject(input);
  }
  listCoins(input) {
    return this.core.listCoins(input);
  }
  listOwnedObjects(input) {
    return this.core.listOwnedObjects(input);
  }
  getBalance(input) {
    return this.core.getBalance(input);
  }
  listBalances(input) {
    return this.core.listBalances(input);
  }
  getCoinMetadata(input) {
    return this.core.getCoinMetadata(input);
  }
  getTransaction(input) {
    return this.core.getTransaction(input);
  }
  executeTransaction(input) {
    return this.core.executeTransaction(input);
  }
  signAndExecuteTransaction(input) {
    return this.core.signAndExecuteTransaction(input);
  }
  waitForTransaction(input) {
    return this.core.waitForTransaction(input);
  }
  simulateTransaction(input) {
    return this.core.simulateTransaction(input);
  }
  getReferenceGasPrice(input) {
    return this.core.getReferenceGasPrice(input);
  }
  getCurrentSystemState(input) {
    return this.core.getCurrentSystemState(input);
  }
  getProtocolConfig(input) {
    return this.core.getProtocolConfig(input);
  }
  getChainIdentifier(input) {
    return this.core.getChainIdentifier(input);
  }
  async listDynamicFields(input) {
    const includeValue = input.include?.value ?? false;
    const paths = [
      "field_id",
      "name",
      "value_type",
      "kind",
      "child_id"
    ];
    if (includeValue) paths.push("value");
    const response2 = await this.stateService.listDynamicFields({
      parent: input.parentId,
      pageToken: input.cursor ? fromBase645(input.cursor) : void 0,
      pageSize: input.limit,
      readMask: { paths }
    }, { abort: input.signal });
    return {
      dynamicFields: response2.response.dynamicFields.map((field) => {
        const isDynamicObject = field.kind === DynamicField_DynamicFieldKind.OBJECT;
        const fieldType = isDynamicObject ? `0x2::dynamic_field::Field<0x2::dynamic_object_field::Wrapper<${field.name?.name}>,0x2::object::ID>` : `0x2::dynamic_field::Field<${field.name?.name},${field.valueType}>`;
        return {
          $kind: isDynamicObject ? "DynamicObject" : "DynamicField",
          fieldId: field.fieldId,
          name: {
            type: field.name?.name,
            bcs: field.name?.value
          },
          valueType: field.valueType,
          type: normalizeStructTag(fieldType),
          childId: field.childId,
          value: includeValue ? {
            type: field.valueType,
            bcs: field.value?.value ?? new Uint8Array()
          } : void 0
        };
      }),
      cursor: response2.response.nextPageToken ? toBase646(response2.response.nextPageToken) : null,
      hasNextPage: response2.response.nextPageToken !== void 0
    };
  }
  getDynamicField(input) {
    return this.core.getDynamicField(input);
  }
  getDynamicObjectField(input) {
    return this.core.getDynamicObjectField(input);
  }
  listTransactions(input) {
    return this.core.listTransactions(input);
  }
  listEvents(input) {
    return this.core.listEvents(input);
  }
  getMoveFunction(input) {
    return this.core.getMoveFunction(input);
  }
  resolveTransactionPlugin() {
    return this.core.resolveTransactionPlugin();
  }
  verifyZkLoginSignature(input) {
    return this.core.verifyZkLoginSignature(input);
  }
  defaultNameServiceName(input) {
    return this.core.defaultNameServiceName(input);
  }
  resolveNameServiceAddress(input) {
    return this.core.resolveNameServiceAddress(input);
  }
};

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/grpc/index.mjs
import { RpcError as RpcError3 } from "@protobuf-ts/runtime-rpc";
import { GrpcStatusCode as GrpcStatusCode3 } from "@protobuf-ts/grpcweb-transport";

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/graphql/generated/queries.mjs
var ExecutionStatus3 = /* @__PURE__ */ (function(ExecutionStatus$1) {
  ExecutionStatus$1["Failure"] = "FAILURE";
  ExecutionStatus$1["Success"] = "SUCCESS";
  return ExecutionStatus$1;
})({});
var ZkLoginIntentScope = /* @__PURE__ */ (function(ZkLoginIntentScope$1) {
  ZkLoginIntentScope$1["PersonalMessage"] = "PERSONAL_MESSAGE";
  ZkLoginIntentScope$1["TransactionData"] = "TRANSACTION_DATA";
  return ZkLoginIntentScope$1;
})({});
var TypedDocumentString = class extends String {
  constructor(value, __meta__) {
    super(value);
    this.value = value;
    this.__meta__ = __meta__;
  }
  toString() {
    return this.value;
  }
};
var Object_Owner_FieldsFragmentDoc = new TypedDocumentString(`
    fragment OBJECT_OWNER_FIELDS on Owner {
  __typename
  ... on AddressOwner {
    address {
      address
    }
  }
  ... on ObjectOwner {
    address {
      address
    }
  }
  ... on Shared {
    initialSharedVersion
  }
  ... on ConsensusAddressOwner {
    startVersion
    address {
      address
    }
  }
}
    `, { "fragmentName": "OBJECT_OWNER_FIELDS" });
var Object_FieldsFragmentDoc = new TypedDocumentString(`
    fragment OBJECT_FIELDS on Object {
  address
  digest
  version
  objectBcs @include(if: $includeObjectBcs)
  asMoveObject {
    contents {
      bcs @include(if: $includeContent)
      json @include(if: $includeJson)
      display @include(if: $includeDisplay) {
        output
        errors
      }
      type {
        repr
      }
    }
  }
  asMovePackage {
    __typename
  }
  owner {
    ...OBJECT_OWNER_FIELDS
  }
  previousTransaction @include(if: $includePreviousTransaction) {
    digest
  }
}
    fragment OBJECT_OWNER_FIELDS on Owner {
  __typename
  ... on AddressOwner {
    address {
      address
    }
  }
  ... on ObjectOwner {
    address {
      address
    }
  }
  ... on Shared {
    initialSharedVersion
  }
  ... on ConsensusAddressOwner {
    startVersion
    address {
      address
    }
  }
}`, { "fragmentName": "OBJECT_FIELDS" });
var Move_Object_FieldsFragmentDoc = new TypedDocumentString(`
    fragment MOVE_OBJECT_FIELDS on MoveObject {
  address
  digest
  version
  objectBcs @include(if: $includeObjectBcs)
  contents {
    bcs @include(if: $includeContent)
    json @include(if: $includeJson)
    display @include(if: $includeDisplay) {
      output
      errors
    }
    type {
      repr
    }
  }
  owner {
    ...OBJECT_OWNER_FIELDS
  }
  previousTransaction @include(if: $includePreviousTransaction) {
    digest
  }
}
    fragment OBJECT_OWNER_FIELDS on Owner {
  __typename
  ... on AddressOwner {
    address {
      address
    }
  }
  ... on ObjectOwner {
    address {
      address
    }
  }
  ... on Shared {
    initialSharedVersion
  }
  ... on ConsensusAddressOwner {
    startVersion
    address {
      address
    }
  }
}`, { "fragmentName": "MOVE_OBJECT_FIELDS" });
var Transaction_FieldsFragmentDoc = new TypedDocumentString(`
    fragment TRANSACTION_FIELDS on Transaction {
  digest
  transactionJson @include(if: $includeTransaction)
  transactionBcs @include(if: $includeBcs)
  signatures {
    signatureBytes
  }
  effects {
    status
    timestamp
    checkpoint {
      sequenceNumber
    }
    executionError {
      message
      abortCode
      identifier
      constant
      sourceLineNumber
      instructionOffset
      module {
        name
        package {
          address
        }
      }
      function {
        name
      }
    }
    epoch {
      epochId
    }
    effectsBcs @include(if: $includeEffects)
    effectsJson @include(if: $includeObjectTypes)
    objectChanges(first: 50) @include(if: $includeObjectTypes) {
      nodes {
        address
        outputState {
          asMoveObject {
            contents {
              type {
                repr
              }
            }
          }
        }
      }
    }
    balanceChangesJson @include(if: $includeBalanceChanges)
    events(first: 50) @include(if: $includeEvents) {
      pageInfo {
        hasNextPage
      }
      nodes {
        transactionModule {
          package {
            address
          }
          name
        }
        sender {
          address
        }
        contents {
          type {
            repr
          }
          bcs
          json
        }
      }
    }
  }
}
    `, { "fragmentName": "TRANSACTION_FIELDS" });
var GetAllBalancesDocument = new TypedDocumentString(`
    query getAllBalances($owner: SuiAddress!, $limit: Int, $cursor: String) {
  address(address: $owner) {
    balances(first: $limit, after: $cursor) {
      pageInfo {
        hasNextPage
        endCursor
      }
      nodes {
        coinType {
          repr
        }
        totalBalance
        addressBalance
      }
    }
  }
}
    `);
var GetBalanceDocument = new TypedDocumentString(`
    query getBalance($owner: SuiAddress!, $coinType: String = "0x2::sui::SUI") {
  address(address: $owner) {
    balance(coinType: $coinType) {
      coinType {
        repr
      }
      totalBalance
      addressBalance
    }
  }
}
    `);
var GetChainIdentifierDocument = new TypedDocumentString(`
    query getChainIdentifier {
  checkpoint(sequenceNumber: 0) {
    digest
  }
}
    `);
var GetCoinMetadataDocument = new TypedDocumentString(`
    query getCoinMetadata($coinType: String!) {
  coinMetadata(coinType: $coinType) {
    address
    decimals
    name
    symbol
    description
    iconUrl
  }
}
    `);
var GetCoinsDocument = new TypedDocumentString(`
    query getCoins($owner: SuiAddress!, $first: Int, $cursor: String, $type: String = "0x2::coin::Coin<0x2::sui::SUI>") {
  address(address: $owner) {
    address
    objects(first: $first, after: $cursor, filter: {type: $type}) {
      pageInfo {
        hasNextPage
        endCursor
      }
      nodes {
        owner {
          ...OBJECT_OWNER_FIELDS
        }
        contents {
          json
          type {
            repr
          }
        }
        address
        version
        digest
      }
    }
  }
}
    fragment OBJECT_OWNER_FIELDS on Owner {
  __typename
  ... on AddressOwner {
    address {
      address
    }
  }
  ... on ObjectOwner {
    address {
      address
    }
  }
  ... on Shared {
    initialSharedVersion
  }
  ... on ConsensusAddressOwner {
    startVersion
    address {
      address
    }
  }
}`);
var GetCurrentSystemStateDocument = new TypedDocumentString(`
    query getCurrentSystemState {
  epoch {
    epochId
    referenceGasPrice
    startTimestamp
    protocolConfigs {
      protocolVersion
    }
    systemState {
      json
    }
  }
}
    `);
var GetDynamicFieldsDocument = new TypedDocumentString(`
    query getDynamicFields($parentId: SuiAddress!, $first: Int, $cursor: String, $includeValue: Boolean = false) {
  address(address: $parentId) {
    dynamicFields(first: $first, after: $cursor) {
      pageInfo {
        hasNextPage
        endCursor
      }
      nodes {
        name {
          bcs
          type {
            repr
          }
        }
        value {
          __typename
          ... on MoveValue {
            bcs @include(if: $includeValue)
            type {
              repr
            }
          }
          ... on MoveObject {
            address
            contents {
              bcs @include(if: $includeValue)
              type {
                repr
              }
            }
          }
        }
      }
    }
  }
}
    `);
var GetMoveFunctionDocument = new TypedDocumentString(`
    query getMoveFunction($package: SuiAddress!, $module: String!, $function: String!) {
  package(address: $package) {
    module(name: $module) {
      function(name: $function) {
        name
        visibility
        isEntry
        typeParameters {
          constraints
        }
        parameters {
          signature
        }
        return {
          signature
        }
      }
    }
  }
}
    `);
var GetProtocolConfigDocument = new TypedDocumentString(`
    query getProtocolConfig {
  epoch {
    protocolConfigs {
      protocolVersion
      featureFlags {
        key
        value
      }
      configs {
        key
        value
      }
    }
  }
}
    `);
var GetReferenceGasPriceDocument = new TypedDocumentString(`
    query getReferenceGasPrice {
  epoch {
    referenceGasPrice
  }
}
    `);
var ListEventsDocument = new TypedDocumentString(`
    query listEvents($filter: EventFilter, $first: Int, $after: String, $last: Int, $before: String) {
  events(
    filter: $filter
    first: $first
    after: $after
    last: $last
    before: $before
  ) {
    pageInfo {
      hasNextPage
      hasPreviousPage
      startCursor
      endCursor
    }
    nodes {
      sequenceNumber
      transaction {
        digest
        effects {
          checkpoint {
            sequenceNumber
          }
        }
      }
      transactionModule {
        package {
          address
        }
        name
      }
      sender {
        address
      }
      contents {
        type {
          repr
        }
        bcs
        json
      }
    }
  }
}
    `);
var DefaultSuinsNameDocument = new TypedDocumentString(`
    query defaultSuinsName($address: SuiAddress!) {
  address(address: $address) {
    defaultNameRecord {
      domain
    }
  }
}
    `);
var ResolveNameServiceAddressDocument = new TypedDocumentString(`
    query resolveNameServiceAddress($name: String!) {
  address(name: $name) {
    address
  }
}
    `);
var GetOwnedObjectsDocument = new TypedDocumentString(`
    query getOwnedObjects($owner: SuiAddress!, $limit: Int, $cursor: String, $filter: ObjectFilter, $includeContent: Boolean = false, $includePreviousTransaction: Boolean = false, $includeObjectBcs: Boolean = false, $includeJson: Boolean = false, $includeDisplay: Boolean = false) {
  address(address: $owner) {
    objects(first: $limit, after: $cursor, filter: $filter) {
      pageInfo {
        hasNextPage
        endCursor
      }
      nodes {
        ...MOVE_OBJECT_FIELDS
      }
    }
  }
}
    fragment MOVE_OBJECT_FIELDS on MoveObject {
  address
  digest
  version
  objectBcs @include(if: $includeObjectBcs)
  contents {
    bcs @include(if: $includeContent)
    json @include(if: $includeJson)
    display @include(if: $includeDisplay) {
      output
      errors
    }
    type {
      repr
    }
  }
  owner {
    ...OBJECT_OWNER_FIELDS
  }
  previousTransaction @include(if: $includePreviousTransaction) {
    digest
  }
}
fragment OBJECT_OWNER_FIELDS on Owner {
  __typename
  ... on AddressOwner {
    address {
      address
    }
  }
  ... on ObjectOwner {
    address {
      address
    }
  }
  ... on Shared {
    initialSharedVersion
  }
  ... on ConsensusAddressOwner {
    startVersion
    address {
      address
    }
  }
}`);
var MultiGetObjectsDocument = new TypedDocumentString(`
    query multiGetObjects($objectKeys: [ObjectKey!]!, $includeContent: Boolean = false, $includePreviousTransaction: Boolean = false, $includeObjectBcs: Boolean = false, $includeJson: Boolean = false, $includeDisplay: Boolean = false) {
  multiGetObjects(keys: $objectKeys) {
    ...OBJECT_FIELDS
  }
}
    fragment OBJECT_FIELDS on Object {
  address
  digest
  version
  objectBcs @include(if: $includeObjectBcs)
  asMoveObject {
    contents {
      bcs @include(if: $includeContent)
      json @include(if: $includeJson)
      display @include(if: $includeDisplay) {
        output
        errors
      }
      type {
        repr
      }
    }
  }
  asMovePackage {
    __typename
  }
  owner {
    ...OBJECT_OWNER_FIELDS
  }
  previousTransaction @include(if: $includePreviousTransaction) {
    digest
  }
}
fragment OBJECT_OWNER_FIELDS on Owner {
  __typename
  ... on AddressOwner {
    address {
      address
    }
  }
  ... on ObjectOwner {
    address {
      address
    }
  }
  ... on Shared {
    initialSharedVersion
  }
  ... on ConsensusAddressOwner {
    startVersion
    address {
      address
    }
  }
}`);
var SimulateTransactionDocument = new TypedDocumentString(`
    query simulateTransaction($transaction: JSON!, $includeTransaction: Boolean = false, $includeEffects: Boolean = false, $includeEvents: Boolean = false, $includeBalanceChanges: Boolean = false, $includeObjectTypes: Boolean = false, $includeCommandResults: Boolean = false, $includeBcs: Boolean = false, $doGasSelection: Boolean = false, $checksEnabled: Boolean = true) {
  simulateTransaction(
    transaction: $transaction
    doGasSelection: $doGasSelection
    checksEnabled: $checksEnabled
  ) {
    effects {
      transaction {
        ...TRANSACTION_FIELDS
        effects {
          gasEffects {
            gasObject {
              address
            }
          }
        }
      }
    }
    outputs @include(if: $includeCommandResults) {
      returnValues {
        value {
          bcs
        }
      }
      mutatedReferences {
        value {
          bcs
        }
      }
    }
  }
}
    fragment TRANSACTION_FIELDS on Transaction {
  digest
  transactionJson @include(if: $includeTransaction)
  transactionBcs @include(if: $includeBcs)
  signatures {
    signatureBytes
  }
  effects {
    status
    timestamp
    checkpoint {
      sequenceNumber
    }
    executionError {
      message
      abortCode
      identifier
      constant
      sourceLineNumber
      instructionOffset
      module {
        name
        package {
          address
        }
      }
      function {
        name
      }
    }
    epoch {
      epochId
    }
    effectsBcs @include(if: $includeEffects)
    effectsJson @include(if: $includeObjectTypes)
    objectChanges(first: 50) @include(if: $includeObjectTypes) {
      nodes {
        address
        outputState {
          asMoveObject {
            contents {
              type {
                repr
              }
            }
          }
        }
      }
    }
    balanceChangesJson @include(if: $includeBalanceChanges)
    events(first: 50) @include(if: $includeEvents) {
      pageInfo {
        hasNextPage
      }
      nodes {
        transactionModule {
          package {
            address
          }
          name
        }
        sender {
          address
        }
        contents {
          type {
            repr
          }
          bcs
          json
        }
      }
    }
  }
}`);
var ExecuteTransactionDocument = new TypedDocumentString(`
    mutation executeTransaction($transactionDataBcs: Base64!, $signatures: [Base64!]!, $includeTransaction: Boolean = false, $includeEffects: Boolean = false, $includeEvents: Boolean = false, $includeBalanceChanges: Boolean = false, $includeObjectTypes: Boolean = false, $includeBcs: Boolean = false) {
  executeTransaction(
    transactionDataBcs: $transactionDataBcs
    signatures: $signatures
  ) {
    effects {
      transaction {
        ...TRANSACTION_FIELDS
      }
    }
  }
}
    fragment TRANSACTION_FIELDS on Transaction {
  digest
  transactionJson @include(if: $includeTransaction)
  transactionBcs @include(if: $includeBcs)
  signatures {
    signatureBytes
  }
  effects {
    status
    timestamp
    checkpoint {
      sequenceNumber
    }
    executionError {
      message
      abortCode
      identifier
      constant
      sourceLineNumber
      instructionOffset
      module {
        name
        package {
          address
        }
      }
      function {
        name
      }
    }
    epoch {
      epochId
    }
    effectsBcs @include(if: $includeEffects)
    effectsJson @include(if: $includeObjectTypes)
    objectChanges(first: 50) @include(if: $includeObjectTypes) {
      nodes {
        address
        outputState {
          asMoveObject {
            contents {
              type {
                repr
              }
            }
          }
        }
      }
    }
    balanceChangesJson @include(if: $includeBalanceChanges)
    events(first: 50) @include(if: $includeEvents) {
      pageInfo {
        hasNextPage
      }
      nodes {
        transactionModule {
          package {
            address
          }
          name
        }
        sender {
          address
        }
        contents {
          type {
            repr
          }
          bcs
          json
        }
      }
    }
  }
}`);
var GetTransactionBlockDocument = new TypedDocumentString(`
    query getTransactionBlock($digest: String!, $includeTransaction: Boolean = false, $includeEffects: Boolean = false, $includeEvents: Boolean = false, $includeBalanceChanges: Boolean = false, $includeObjectTypes: Boolean = false, $includeBcs: Boolean = false) {
  transaction(digest: $digest) {
    ...TRANSACTION_FIELDS
  }
}
    fragment TRANSACTION_FIELDS on Transaction {
  digest
  transactionJson @include(if: $includeTransaction)
  transactionBcs @include(if: $includeBcs)
  signatures {
    signatureBytes
  }
  effects {
    status
    timestamp
    checkpoint {
      sequenceNumber
    }
    executionError {
      message
      abortCode
      identifier
      constant
      sourceLineNumber
      instructionOffset
      module {
        name
        package {
          address
        }
      }
      function {
        name
      }
    }
    epoch {
      epochId
    }
    effectsBcs @include(if: $includeEffects)
    effectsJson @include(if: $includeObjectTypes)
    objectChanges(first: 50) @include(if: $includeObjectTypes) {
      nodes {
        address
        outputState {
          asMoveObject {
            contents {
              type {
                repr
              }
            }
          }
        }
      }
    }
    balanceChangesJson @include(if: $includeBalanceChanges)
    events(first: 50) @include(if: $includeEvents) {
      pageInfo {
        hasNextPage
      }
      nodes {
        transactionModule {
          package {
            address
          }
          name
        }
        sender {
          address
        }
        contents {
          type {
            repr
          }
          bcs
          json
        }
      }
    }
  }
}`);
var ListTransactionsDocument = new TypedDocumentString(`
    query listTransactions($filter: TransactionFilter, $first: Int, $after: String, $last: Int, $before: String, $includeTransaction: Boolean = false, $includeEffects: Boolean = false, $includeEvents: Boolean = false, $includeBalanceChanges: Boolean = false, $includeObjectTypes: Boolean = false, $includeBcs: Boolean = false) {
  transactions(
    filter: $filter
    first: $first
    after: $after
    last: $last
    before: $before
  ) {
    pageInfo {
      hasNextPage
      hasPreviousPage
      startCursor
      endCursor
    }
    nodes {
      ...TRANSACTION_FIELDS
    }
  }
}
    fragment TRANSACTION_FIELDS on Transaction {
  digest
  transactionJson @include(if: $includeTransaction)
  transactionBcs @include(if: $includeBcs)
  signatures {
    signatureBytes
  }
  effects {
    status
    timestamp
    checkpoint {
      sequenceNumber
    }
    executionError {
      message
      abortCode
      identifier
      constant
      sourceLineNumber
      instructionOffset
      module {
        name
        package {
          address
        }
      }
      function {
        name
      }
    }
    epoch {
      epochId
    }
    effectsBcs @include(if: $includeEffects)
    effectsJson @include(if: $includeObjectTypes)
    objectChanges(first: 50) @include(if: $includeObjectTypes) {
      nodes {
        address
        outputState {
          asMoveObject {
            contents {
              type {
                repr
              }
            }
          }
        }
      }
    }
    balanceChangesJson @include(if: $includeBalanceChanges)
    events(first: 50) @include(if: $includeEvents) {
      pageInfo {
        hasNextPage
      }
      nodes {
        transactionModule {
          package {
            address
          }
          name
        }
        sender {
          address
        }
        contents {
          type {
            repr
          }
          bcs
          json
        }
      }
    }
  }
}`);
var ResolveTransactionDocument = new TypedDocumentString(`
    query resolveTransaction($transaction: JSON!, $doGasSelection: Boolean = true, $checksEnabled: Boolean = true) {
  simulateTransaction(
    transaction: $transaction
    doGasSelection: $doGasSelection
    checksEnabled: $checksEnabled
  ) {
    effects {
      transaction {
        transactionBcs
        effects {
          epoch {
            epochId
          }
          status
          executionError {
            message
            abortCode
            identifier
            constant
            sourceLineNumber
            instructionOffset
            module {
              name
              package {
                address
              }
            }
            function {
              name
            }
          }
        }
      }
    }
  }
}
    `);
var VerifyZkLoginSignatureDocument = new TypedDocumentString(`
    query verifyZkLoginSignature($bytes: Base64!, $signature: Base64!, $intentScope: ZkLoginIntentScope!, $author: SuiAddress!) {
  verifyZkLoginSignature(
    bytes: $bytes
    signature: $signature
    intentScope: $intentScope
    author: $author
  ) {
    success
  }
}
    `);

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/graphql/core.mjs
import { chunk as chunk3, fromBase64 as fromBase646, toBase64 as toBase647 } from "@mysten/utils";
var GRAPHQL_OBJECT_BATCH_SIZE = 40;
var GraphQLCoreClient = class extends CoreClient {
  #graphqlClient;
  constructor({ graphqlClient, mvr }) {
    super({
      network: graphqlClient.network,
      base: graphqlClient,
      mvr
    });
    this.#graphqlClient = graphqlClient;
  }
  async #graphqlQuery(options, getData, createMissingDataError) {
    const { data, errors } = await this.#graphqlClient.query(options);
    handleGraphQLErrors(errors);
    const extractedData = data && (getData ? getData(data) : data);
    if (extractedData == null) throw createMissingDataError?.() ?? /* @__PURE__ */ new Error("Missing response data");
    return extractedData;
  }
  async getObjects(options) {
    const batches = chunk3(options.objectIds, GRAPHQL_OBJECT_BATCH_SIZE);
    const results = [];
    for (const batch of batches) {
      const page = await this.#graphqlQuery({
        query: MultiGetObjectsDocument,
        signal: options.signal,
        variables: {
          objectKeys: batch.map((address) => ({ address })),
          includeContent: options.include?.content ?? false,
          includePreviousTransaction: options.include?.previousTransaction ?? false,
          includeObjectBcs: options.include?.objectBcs ?? false,
          includeJson: options.include?.json ?? false,
          includeDisplay: options.include?.display ?? false
        }
      }, (result) => result.multiGetObjects);
      results.push(...batch.map((objectId) => ({
        objectId,
        normalized: normalizeSuiAddress(objectId)
      })).map(({ objectId, normalized }) => page.find((obj) => obj?.address === normalized) ?? new ObjectError("notFound", `Object ${normalized} not found`, {
        reason: "notFound",
        objectId
      })).map((obj) => {
        if (obj instanceof ObjectError) return obj;
        const bcsContent = obj.asMoveObject?.contents?.bcs ? fromBase646(obj.asMoveObject.contents.bcs) : void 0;
        const objectBcs = obj.objectBcs ? fromBase646(obj.objectBcs) : void 0;
        let type;
        if (obj.asMovePackage) type = "package";
        else if (obj.asMoveObject?.contents?.type?.repr) type = obj.asMoveObject.contents.type.repr;
        else type = "";
        const jsonContent = options.include?.json ? obj.asMoveObject?.contents?.json ? obj.asMoveObject.contents.json : null : void 0;
        const displayData = mapDisplay(options.include?.display, obj.asMoveObject?.contents?.display);
        return {
          objectId: obj.address,
          version: obj.version?.toString(),
          digest: obj.digest,
          owner: mapOwner2(obj.owner),
          type,
          content: bcsContent,
          previousTransaction: obj.previousTransaction?.digest ?? void 0,
          objectBcs,
          json: jsonContent,
          display: displayData
        };
      }));
    }
    return { objects: results };
  }
  async listOwnedObjects(options) {
    const objects = await this.#graphqlQuery({
      query: GetOwnedObjectsDocument,
      signal: options.signal,
      variables: {
        owner: options.owner,
        limit: options.limit,
        cursor: options.cursor,
        filter: options.type ? { type: (await this.mvr.resolveType({
          type: options.type,
          signal: options.signal
        })).type } : void 0,
        includeContent: options.include?.content ?? false,
        includePreviousTransaction: options.include?.previousTransaction ?? false,
        includeObjectBcs: options.include?.objectBcs ?? false,
        includeJson: options.include?.json ?? false,
        includeDisplay: options.include?.display ?? false
      }
    }, (result) => result.address?.objects);
    return {
      objects: objects.nodes.map((obj) => ({
        objectId: obj.address,
        version: obj.version?.toString(),
        digest: obj.digest,
        owner: mapOwner2(obj.owner),
        type: obj.contents?.type?.repr,
        content: obj.contents?.bcs ? fromBase646(obj.contents.bcs) : void 0,
        previousTransaction: obj.previousTransaction?.digest ?? void 0,
        objectBcs: obj.objectBcs ? fromBase646(obj.objectBcs) : void 0,
        json: options.include?.json ? obj.contents?.json ? obj.contents.json : null : void 0,
        display: mapDisplay(options.include?.display, obj.contents?.display)
      })),
      hasNextPage: objects.pageInfo.hasNextPage,
      cursor: objects.pageInfo.endCursor ?? null
    };
  }
  async listCoins(options) {
    const coinType = options.coinType ?? SUI_TYPE_ARG;
    const coins = await this.#graphqlQuery({
      query: GetCoinsDocument,
      signal: options.signal,
      variables: {
        owner: options.owner,
        cursor: options.cursor,
        first: options.limit,
        type: `0x2::coin::Coin<${(await this.mvr.resolveType({
          type: coinType,
          signal: options.signal
        })).type}>`
      }
    }, (result) => result.address?.objects);
    return {
      cursor: coins.pageInfo.endCursor ?? null,
      hasNextPage: coins.pageInfo.hasNextPage,
      objects: coins.nodes.map((coin) => ({
        objectId: coin.address,
        version: coin.version?.toString(),
        digest: coin.digest,
        owner: mapOwner2(coin.owner),
        type: coin.contents?.type?.repr,
        balance: coin.contents?.json?.balance
      }))
    };
  }
  async getBalance(options) {
    const coinType = options.coinType ?? SUI_TYPE_ARG;
    const result = await this.#graphqlQuery({
      query: GetBalanceDocument,
      signal: options.signal,
      variables: {
        owner: options.owner,
        coinType: (await this.mvr.resolveType({
          type: coinType,
          signal: options.signal
        })).type
      }
    }, (result$1) => result$1.address?.balance);
    const addressBalance = BigInt(result.addressBalance ?? "0");
    const coinBalance = BigInt(result.totalBalance ?? "0") - addressBalance;
    return { balance: {
      coinType: result.coinType?.repr ?? coinType,
      balance: result.totalBalance ?? "0",
      coinBalance: coinBalance.toString(),
      addressBalance: addressBalance.toString()
    } };
  }
  async getCoinMetadata(options) {
    const coinType = (await this.mvr.resolveType({
      type: options.coinType,
      signal: options.signal
    })).type;
    const { data, errors } = await this.#graphqlClient.query({
      query: GetCoinMetadataDocument,
      signal: options.signal,
      variables: { coinType }
    });
    handleGraphQLErrors(errors);
    if (!data?.coinMetadata) return { coinMetadata: null };
    return { coinMetadata: {
      id: data.coinMetadata.address,
      decimals: data.coinMetadata.decimals,
      name: data.coinMetadata.name,
      symbol: data.coinMetadata.symbol,
      description: data.coinMetadata.description,
      iconUrl: data.coinMetadata.iconUrl ?? null
    } };
  }
  async listBalances(options) {
    const balances = await this.#graphqlQuery({
      query: GetAllBalancesDocument,
      signal: options.signal,
      variables: {
        owner: options.owner,
        limit: options.limit,
        cursor: options.cursor
      }
    }, (result) => result.address?.balances);
    return {
      cursor: balances.pageInfo.endCursor ?? null,
      hasNextPage: balances.pageInfo.hasNextPage,
      balances: balances.nodes.map((balance) => {
        const addressBalance = BigInt(balance.addressBalance ?? "0");
        const coinBalance = BigInt(balance.totalBalance ?? "0") - addressBalance;
        return {
          coinType: balance.coinType?.repr,
          balance: balance.totalBalance,
          coinBalance: coinBalance.toString(),
          addressBalance: addressBalance.toString()
        };
      })
    };
  }
  async getTransaction(options) {
    return parseTransaction(await this.#graphqlQuery({
      query: GetTransactionBlockDocument,
      signal: options.signal,
      variables: {
        digest: options.digest,
        includeTransaction: options.include?.transaction ?? false,
        includeEffects: options.include?.effects ?? false,
        includeEvents: options.include?.events ?? false,
        includeBalanceChanges: options.include?.balanceChanges ?? false,
        includeObjectTypes: options.include?.objectTypes ?? false,
        includeBcs: options.include?.bcs ?? false
      }
    }, (result) => result.transaction, () => new TransactionError("notFound", options.digest)), options.include);
  }
  async executeTransaction(options) {
    return parseTransaction((await this.#graphqlQuery({
      query: ExecuteTransactionDocument,
      signal: options.signal,
      variables: {
        transactionDataBcs: toBase647(options.transaction),
        signatures: options.signatures,
        includeTransaction: options.include?.transaction ?? false,
        includeEffects: options.include?.effects ?? false,
        includeEvents: options.include?.events ?? false,
        includeBalanceChanges: options.include?.balanceChanges ?? false,
        includeObjectTypes: options.include?.objectTypes ?? false,
        includeBcs: options.include?.bcs ?? false
      }
    }, (result) => result.executeTransaction)).effects?.transaction, options.include);
  }
  async simulateTransaction(options) {
    if (!(options.transaction instanceof Uint8Array)) await options.transaction.prepareForSerialization({ client: this });
    const doGasSelection = options.doGasSelection ?? (options.transaction instanceof Uint8Array ? transactionBytesHaveEmptyGasPayment(options.transaction) : options.transaction.getData().gasData.payment?.length === 0);
    const result = await this.#graphqlQuery({
      query: SimulateTransactionDocument,
      signal: options.signal,
      variables: {
        transaction: options.transaction instanceof Uint8Array ? { bcs: { value: toBase647(options.transaction) } } : transactionToGrpcJson(options.transaction),
        includeTransaction: options.include?.transaction ?? false,
        includeEffects: options.include?.effects ?? false,
        includeEvents: options.include?.events ?? false,
        includeBalanceChanges: options.include?.balanceChanges ?? false,
        includeObjectTypes: options.include?.objectTypes ?? false,
        includeCommandResults: options.include?.commandResults ?? false,
        includeBcs: options.include?.bcs ?? false,
        doGasSelection,
        checksEnabled: options.checksEnabled ?? true
      }
    }, (result$1) => result$1.simulateTransaction);
    const transactionResult = parseTransaction(result.effects?.transaction, options.include);
    const gasPaymentMocked = isMockedGasObjectId(result.effects?.transaction?.effects?.gasEffects?.gasObject?.address);
    const commandResults = options.include?.commandResults && result.outputs ? result.outputs.map((output) => ({
      returnValues: (output.returnValues ?? []).map((rv) => ({ bcs: rv.value?.bcs ? fromBase646(rv.value.bcs) : null })),
      mutatedReferences: (output.mutatedReferences ?? []).map((mr) => ({ bcs: mr.value?.bcs ? fromBase646(mr.value.bcs) : null }))
    })) : void 0;
    if (transactionResult.$kind === "Transaction") return {
      $kind: "Transaction",
      Transaction: transactionResult.Transaction,
      commandResults,
      gasPaymentMocked
    };
    else return {
      $kind: "FailedTransaction",
      FailedTransaction: transactionResult.FailedTransaction,
      commandResults,
      gasPaymentMocked
    };
  }
  async getReferenceGasPrice(options) {
    return { referenceGasPrice: await this.#graphqlQuery({
      query: GetReferenceGasPriceDocument,
      signal: options?.signal
    }, (result) => result.epoch?.referenceGasPrice) ?? "" };
  }
  async getProtocolConfig(options) {
    const result = await this.#graphqlQuery({
      query: GetProtocolConfigDocument,
      signal: options?.signal
    }, (result$1) => result$1.epoch?.protocolConfigs);
    const featureFlags = {};
    for (const flag of result?.featureFlags ?? []) featureFlags[flag.key] = flag.value;
    const attributes = {};
    for (const config2 of result?.configs ?? []) attributes[config2.key] = config2.value ?? null;
    return { protocolConfig: {
      protocolVersion: result?.protocolVersion?.toString() ?? null,
      featureFlags,
      attributes
    } };
  }
  async getCurrentSystemState(options) {
    const result = await this.#graphqlQuery({
      query: GetCurrentSystemStateDocument,
      signal: options?.signal
    }, (result$1) => result$1.epoch);
    if (!result) throw new Error("Epoch data not found in response");
    const startMs = result.startTimestamp ? new Date(result.startTimestamp).getTime().toString() : null;
    const systemStateJson = result.systemState?.json;
    return { systemState: {
      systemStateVersion: systemStateJson?.system_state_version?.toString() ?? null,
      epoch: result.epochId?.toString() ?? null,
      protocolVersion: result.protocolConfigs?.protocolVersion?.toString() ?? null,
      referenceGasPrice: result.referenceGasPrice ?? null,
      epochStartTimestampMs: startMs,
      safeMode: systemStateJson?.safe_mode ?? false,
      safeModeStorageRewards: systemStateJson?.safe_mode_storage_rewards ?? null,
      safeModeComputationRewards: systemStateJson?.safe_mode_computation_rewards ?? null,
      safeModeStorageRebates: systemStateJson?.safe_mode_storage_rebates?.toString() ?? null,
      safeModeNonRefundableStorageFee: systemStateJson?.safe_mode_non_refundable_storage_fee?.toString() ?? null,
      parameters: {
        epochDurationMs: systemStateJson?.parameters?.epoch_duration_ms?.toString() ?? null,
        stakeSubsidyStartEpoch: systemStateJson?.parameters?.stake_subsidy_start_epoch?.toString() ?? null,
        maxValidatorCount: systemStateJson?.parameters?.max_validator_count?.toString() ?? null,
        minValidatorJoiningStake: systemStateJson?.parameters?.min_validator_joining_stake?.toString() ?? null,
        validatorLowStakeThreshold: systemStateJson?.parameters?.validator_low_stake_threshold?.toString() ?? null,
        validatorLowStakeGracePeriod: systemStateJson?.parameters?.validator_low_stake_grace_period?.toString() ?? null
      },
      storageFund: {
        totalObjectStorageRebates: systemStateJson?.storage_fund?.total_object_storage_rebates ?? null,
        nonRefundableBalance: systemStateJson?.storage_fund?.non_refundable_balance ?? null
      },
      stakeSubsidy: {
        balance: systemStateJson?.stake_subsidy?.balance ?? null,
        distributionCounter: systemStateJson?.stake_subsidy?.distribution_counter?.toString() ?? null,
        currentDistributionAmount: systemStateJson?.stake_subsidy?.current_distribution_amount?.toString() ?? null,
        stakeSubsidyPeriodLength: systemStateJson?.stake_subsidy?.stake_subsidy_period_length?.toString() ?? null,
        stakeSubsidyDecreaseRate: systemStateJson?.stake_subsidy?.stake_subsidy_decrease_rate ?? null
      }
    } };
  }
  async listDynamicFields(options) {
    return this.#graphqlClient.listDynamicFields(options);
  }
  async listTransactions(options) {
    const pagination = resolvePagination(options);
    const { descending, after, before, limit } = pagination;
    const filter = options.filter ? await resolveTransactionFilter(this.mvr, options.filter, options.signal) : void 0;
    validateTransactionQuery(filter, pagination);
    const transactions = await this.#graphqlQuery({
      query: ListTransactionsDocument,
      signal: options.signal,
      variables: {
        filter: filter && {
          sentAddress: filter.$kind === "sender" ? filter.sender : void 0,
          function: filter.$kind === "function" ? [
            filter.package,
            filter.module,
            filter.function
          ].filter(Boolean).join("::") : void 0
        },
        first: descending ? void 0 : limit,
        after,
        last: descending ? limit : void 0,
        before,
        includeTransaction: options.include?.transaction ?? false,
        includeEffects: options.include?.effects ?? false,
        includeEvents: options.include?.events ?? false,
        includeBalanceChanges: options.include?.balanceChanges ?? false,
        includeObjectTypes: options.include?.objectTypes ?? false,
        includeBcs: options.include?.bcs ?? false
      }
    }, (result) => result.transactions);
    return {
      transactions: (descending ? [...transactions.nodes].reverse() : transactions.nodes).map((transaction) => parseTransaction(transaction, options.include)),
      hasNextPage: descending ? transactions.pageInfo.hasPreviousPage : transactions.pageInfo.hasNextPage,
      startCursor: (descending ? transactions.pageInfo.endCursor : transactions.pageInfo.startCursor) ?? null,
      endCursor: (descending ? transactions.pageInfo.startCursor : transactions.pageInfo.endCursor) ?? null
    };
  }
  async listEvents(options) {
    const { descending, after, before, limit } = resolvePagination(options);
    const filter = options.filter ? await resolveEventFilter(this.mvr, options.filter, options.signal) : void 0;
    const events = await this.#graphqlQuery({
      query: ListEventsDocument,
      signal: options.signal,
      variables: {
        filter: filter && {
          sender: filter.$kind === "sender" ? filter.sender : void 0,
          module: filter.$kind === "emitModule" ? `${filter.package}::${filter.module}` : void 0,
          type: filter.$kind === "eventTypeModule" ? `${filter.package}::${filter.module}` : filter.$kind === "eventType" ? filter.eventType : void 0
        },
        first: descending ? void 0 : limit,
        after,
        last: descending ? limit : void 0,
        before
      }
    }, (result) => result.events);
    return {
      events: (descending ? [...events.nodes].reverse() : events.nodes).map((event) => {
        const packageId = event.transactionModule?.package?.address;
        const module = event.transactionModule?.name;
        const sender = event.sender?.address;
        const eventType = event.contents?.type?.repr;
        const transactionDigest = event.transaction?.digest;
        if (!packageId || !module || !sender || !eventType || !transactionDigest) throw new Error("listEvents response is missing expected event fields");
        return {
          packageId: normalizeSuiAddress(packageId),
          module,
          sender: normalizeSuiAddress(sender),
          eventType: normalizeStructTag(eventType),
          bcs: event.contents?.bcs ? fromBase646(event.contents.bcs) : new Uint8Array(),
          json: event.contents?.json ?? null,
          checkpoint: event.transaction?.effects?.checkpoint?.sequenceNumber?.toString() ?? null,
          transactionDigest,
          eventIndex: event.sequenceNumber
        };
      }),
      hasNextPage: descending ? events.pageInfo.hasPreviousPage : events.pageInfo.hasNextPage,
      startCursor: (descending ? events.pageInfo.endCursor : events.pageInfo.startCursor) ?? null,
      endCursor: (descending ? events.pageInfo.startCursor : events.pageInfo.endCursor) ?? null
    };
  }
  async verifyZkLoginSignature(options) {
    const intentScope = options.intentScope === "TransactionData" ? ZkLoginIntentScope.TransactionData : ZkLoginIntentScope.PersonalMessage;
    const { data } = await this.#graphqlClient.query({
      query: VerifyZkLoginSignatureDocument,
      signal: options.signal,
      variables: {
        bytes: options.bytes,
        signature: options.signature,
        intentScope,
        author: options.address
      }
    });
    return {
      success: data?.verifyZkLoginSignature?.success ?? false,
      errors: []
    };
  }
  async defaultNameServiceName(options) {
    const { data, errors } = await this.#graphqlClient.query({
      query: DefaultSuinsNameDocument,
      signal: options.signal,
      variables: { address: options.address }
    });
    handleGraphQLErrors(errors);
    return { data: { name: data?.address?.defaultNameRecord?.domain ?? null } };
  }
  async resolveNameServiceAddress(options) {
    const { data, errors } = await this.#graphqlClient.query({
      query: ResolveNameServiceAddressDocument,
      signal: options.signal,
      variables: { name: options.name }
    });
    handleGraphQLErrors(errors);
    return { address: data?.address?.address ?? null };
  }
  async getMoveFunction(options) {
    const moveFunction = await this.#graphqlQuery({
      query: GetMoveFunctionDocument,
      signal: options.signal,
      variables: {
        package: (await this.mvr.resolvePackage({
          package: options.packageId,
          signal: options.signal
        })).package,
        module: options.moduleName,
        function: options.name
      }
    }, (result) => result.package?.module?.function);
    let visibility = "unknown";
    switch (moveFunction.visibility) {
      case "PUBLIC":
        visibility = "public";
        break;
      case "PRIVATE":
        visibility = "private";
        break;
      case "FRIEND":
        visibility = "friend";
        break;
    }
    return { function: {
      packageId: normalizeSuiAddress(options.packageId),
      moduleName: options.moduleName,
      name: moveFunction.name,
      visibility,
      isEntry: moveFunction.isEntry ?? false,
      typeParameters: moveFunction.typeParameters?.map(({ constraints }) => ({
        isPhantom: false,
        constraints: constraints.map((constraint) => {
          switch (constraint) {
            case "COPY":
              return "copy";
            case "DROP":
              return "drop";
            case "STORE":
              return "store";
            case "KEY":
              return "key";
            default:
              return "unknown";
          }
        }) ?? []
      })) ?? [],
      parameters: moveFunction.parameters?.map((param) => parseNormalizedSuiMoveType2(param.signature)) ?? [],
      returns: moveFunction.return?.map(({ signature }) => parseNormalizedSuiMoveType2(signature)) ?? []
    } };
  }
  async getChainIdentifier(options) {
    const cached2 = this.cache.read(["chainIdentifier"], async () => {
      const checkpoint = await this.#graphqlQuery({ query: GetChainIdentifierDocument }, (result) => result.checkpoint);
      if (!checkpoint?.digest) throw new Error("Genesis checkpoint digest not found");
      return { chainIdentifier: checkpoint.digest };
    });
    return raceSignal(Promise.resolve(cached2), options?.signal);
  }
  resolveTransactionPlugin() {
    const graphqlClient = this.#graphqlClient;
    return async function resolveTransactionData(transactionData, options, next) {
      const snapshot = transactionData.snapshot();
      if (!snapshot.sender) snapshot.sender = "0x0000000000000000000000000000000000000000000000000000000000000000";
      const grpcTransaction = transactionDataToGrpcTransaction(snapshot);
      const transactionJson = Transaction.toJson(grpcTransaction);
      const doGasSelection = !options.onlyTransactionKind && (snapshot.gasData.budget == null || snapshot.gasData.payment == null);
      const { data, errors } = await graphqlClient.query({
        query: ResolveTransactionDocument,
        variables: {
          transaction: transactionJson,
          doGasSelection,
          checksEnabled: !options.onlyTransactionKind
        }
      });
      handleGraphQLErrors(errors);
      const transactionEffects = data?.simulateTransaction?.effects?.transaction?.effects;
      if (!options.onlyTransactionKind && transactionEffects?.status === ExecutionStatus3.Failure) {
        const executionError = parseGraphQLExecutionError(transactionEffects.executionError);
        throw new SimulationError(`Transaction resolution failed: ${executionError?.message ?? "Transaction failed"}`, { executionError });
      }
      const resolvedTransactionBcs = data?.simulateTransaction?.effects?.transaction?.transactionBcs;
      if (!resolvedTransactionBcs) throw new Error("simulateTransaction did not return resolved transaction data");
      const resolved = TransactionDataBuilder.fromBytes(fromBase646(resolvedTransactionBcs)).snapshot();
      if (options.onlyTransactionKind) transactionData.applyResolvedData({
        ...resolved,
        sender: null,
        gasData: {
          budget: null,
          owner: null,
          payment: null,
          price: null
        },
        expiration: null
      });
      else transactionData.applyResolvedData(resolved);
      await setAddressBalanceTransactionExpirationFromSimulatedEpoch({
        transactionData,
        client: graphqlClient,
        epoch: transactionEffects?.epoch?.epochId,
        originalTransactionData: snapshot,
        isTransactionKindOnly: !!options.onlyTransactionKind,
        doGasSelection
      });
      return await next();
    };
  }
};
function mapDisplay(include, display) {
  if (!include) return void 0;
  if (!display) return null;
  return {
    output: display.output ?? null,
    errors: display.errors ?? null
  };
}
function handleGraphQLErrors(errors) {
  if (!errors || errors.length === 0) return;
  const errorInstances = errors.map((error) => new GraphQLResponseError(error));
  if (errorInstances.length === 1) throw errorInstances[0];
  throw new AggregateError(errorInstances);
}
var GraphQLResponseError = class extends Error {
  constructor(error) {
    super(error.message);
    this.locations = error.locations;
  }
};
function mapOwner2(owner) {
  switch (owner.__typename) {
    case "AddressOwner":
      return {
        $kind: "AddressOwner",
        AddressOwner: owner.address?.address
      };
    case "ConsensusAddressOwner":
      return {
        $kind: "ConsensusAddressOwner",
        ConsensusAddressOwner: {
          owner: owner?.address?.address,
          startVersion: String(owner.startVersion)
        }
      };
    case "ObjectOwner":
      return {
        $kind: "ObjectOwner",
        ObjectOwner: owner.address?.address
      };
    case "Immutable":
      return {
        $kind: "Immutable",
        Immutable: true
      };
    case "Shared":
      return {
        $kind: "Shared",
        Shared: { initialSharedVersion: String(owner.initialSharedVersion) }
      };
  }
}
function parseTransaction(transaction, include) {
  const objectTypes = {};
  if (include?.objectTypes) {
    const effectsJson = transaction.effects?.effectsJson;
    if (effectsJson) TransactionEffects2.fromJson(effectsJson).changedObjects?.forEach((change) => {
      if (change.objectId && change.objectType) objectTypes[change.objectId] = change.objectType;
    });
    const objectChanges = transaction.effects?.objectChanges?.nodes;
    if (objectChanges) for (const change of objectChanges) {
      const type = change.outputState?.asMoveObject?.contents?.type?.repr;
      if (change.address && type) objectTypes[change.address] = type;
    }
  }
  let balanceChanges;
  if (include?.balanceChanges) {
    const balanceChangesJson = transaction.effects?.balanceChangesJson;
    if (Array.isArray(balanceChangesJson)) balanceChanges = balanceChangesJson.map((json) => {
      const change = BalanceChange.fromJson(json);
      return {
        coinType: change.coinType,
        address: change.address,
        amount: change.amount
      };
    });
    else balanceChanges = [];
  }
  const status = transaction.effects?.status === ExecutionStatus3.Success ? {
    success: true,
    error: null
  } : {
    success: false,
    error: parseGraphQLExecutionError(transaction.effects?.executionError)
  };
  let transactionData;
  if (include?.transaction && transaction.transactionJson) {
    const resolved = grpcTransactionToTransactionData(Transaction.fromJson(transaction.transactionJson));
    transactionData = {
      gasData: resolved.gasData,
      sender: resolved.sender,
      expiration: resolved.expiration,
      commands: resolved.commands,
      inputs: resolved.inputs,
      version: resolved.version
    };
  }
  const bcsBytes = include?.bcs && transaction.transactionBcs ? fromBase646(transaction.transactionBcs) : void 0;
  const timestampMs = transaction.effects?.timestamp ? Date.parse(transaction.effects.timestamp) : null;
  const result = {
    digest: transaction.digest,
    status,
    effects: include?.effects ? parseTransactionEffectsBcs(fromBase646(transaction.effects?.effectsBcs)) : void 0,
    epoch: transaction.effects?.epoch?.epochId?.toString() ?? null,
    timestampMs: timestampMs !== null && !Number.isNaN(timestampMs) ? timestampMs : null,
    checkpoint: transaction.effects?.checkpoint?.sequenceNumber?.toString() ?? null,
    objectTypes: include?.objectTypes ? objectTypes : void 0,
    transaction: transactionData,
    bcs: bcsBytes,
    signatures: transaction.signatures.map((sig) => sig.signatureBytes),
    balanceChanges,
    events: include?.events ? transaction.effects?.events?.nodes.map((event) => {
      const eventType = event.contents?.type?.repr;
      const [packageId, module] = eventType.split("::");
      return {
        packageId,
        module,
        sender: event.sender?.address,
        eventType,
        bcs: event.contents?.bcs ? fromBase646(event.contents.bcs) : new Uint8Array(),
        json: event.contents?.json ?? null
      };
    }) ?? [] : void 0
  };
  return status.success ? {
    $kind: "Transaction",
    Transaction: result,
    FailedTransaction: void 0
  } : {
    $kind: "FailedTransaction",
    Transaction: void 0,
    FailedTransaction: result
  };
}
function parseNormalizedSuiMoveType2(type) {
  let reference = null;
  if (type.ref === "&") reference = "immutable";
  else if (type.ref === "&mut") reference = "mutable";
  return {
    reference,
    body: parseNormalizedSuiMoveTypeBody2(type.body)
  };
}
function parseGraphQLExecutionError(executionError) {
  if (mapGraphQLExecutionErrorKind(executionError) === "MoveAbort" && executionError?.abortCode != null) {
    const location = parseGraphQLMoveLocation(executionError);
    const cleverError = parseGraphQLCleverError(executionError);
    const commandMatch = executionError.message?.match(/in (\d+)\w* command/);
    const command = commandMatch ? parseInt(commandMatch[1], 10) - 1 : void 0;
    return {
      $kind: "MoveAbort",
      message: formatMoveAbortMessage({
        command,
        location: location ? {
          package: location.package,
          module: location.module,
          functionName: location.functionName,
          instruction: location.instruction
        } : void 0,
        abortCode: executionError.abortCode,
        cleverError: cleverError ? {
          lineNumber: cleverError.lineNumber,
          constantName: cleverError.constantName,
          value: cleverError.value
        } : void 0
      }),
      command,
      MoveAbort: {
        abortCode: executionError.abortCode,
        location,
        cleverError
      }
    };
  }
  return {
    $kind: "Unknown",
    message: executionError?.message ?? "Transaction failed",
    Unknown: null
  };
}
function mapGraphQLExecutionErrorKind(executionError) {
  if (executionError?.abortCode != null) return "MoveAbort";
  return executionError?.message?.match(/^(\w+)/)?.[1] ?? "Unknown";
}
function parseGraphQLMoveLocation(executionError) {
  if (!(executionError.module?.package?.address && executionError.module?.name)) return;
  return {
    package: executionError.module?.package?.address,
    module: executionError.module?.name,
    functionName: executionError.function?.name,
    instruction: executionError.instructionOffset ?? void 0
  };
}
function parseGraphQLCleverError(executionError) {
  if (!(executionError.identifier || executionError.constant)) return;
  return {
    constantName: executionError.identifier ?? void 0,
    value: executionError.constant ?? void 0,
    lineNumber: executionError.sourceLineNumber ?? void 0
  };
}
function parseNormalizedSuiMoveTypeBody2(type) {
  switch (type) {
    case "address":
      return { $kind: "address" };
    case "bool":
      return { $kind: "bool" };
    case "u8":
      return { $kind: "u8" };
    case "u16":
      return { $kind: "u16" };
    case "u32":
      return { $kind: "u32" };
    case "u64":
      return { $kind: "u64" };
    case "u128":
      return { $kind: "u128" };
    case "u256":
      return { $kind: "u256" };
  }
  if (typeof type === "string") throw new Error(`Unknown type: ${type}`);
  if ("vector" in type) return {
    $kind: "vector",
    vector: parseNormalizedSuiMoveTypeBody2(type.vector)
  };
  if ("datatype" in type) return {
    $kind: "datatype",
    datatype: {
      typeName: `${normalizeSuiAddress(type.datatype.package)}::${type.datatype.module}::${type.datatype.type}`,
      typeParameters: type.datatype.typeParameters.map((t) => parseNormalizedSuiMoveTypeBody2(t))
    }
  };
  if ("typeParameter" in type) return {
    $kind: "typeParameter",
    index: type.typeParameter
  };
  throw new Error(`Unknown type: ${JSON.stringify(type)}`);
}

// netlify/preview-lib/treeforce89-source/node_modules/@mysten/sui/dist/graphql/client.mjs
import { fromBase64 as fromBase647 } from "@mysten/utils";
import { print } from "graphql";
var SuiGraphQLRequestError = class extends Error {
};
var SUI_CLIENT_BRAND2 = /* @__PURE__ */ Symbol.for("@mysten/SuiGraphQLClient");
var SuiGraphQLClient = class extends BaseClient {
  #url;
  #queries;
  #headers;
  #fetch;
  get mvr() {
    return this.core.mvr;
  }
  get [SUI_CLIENT_BRAND2]() {
    return true;
  }
  constructor({ url, fetch: fetchFn = fetch, headers: headers4 = {}, queries = {}, network, mvr }) {
    super({ network });
    this.#url = url;
    this.#queries = queries;
    this.#headers = headers4;
    this.#fetch = (...args) => fetchFn(...args);
    this.core = new GraphQLCoreClient({
      graphqlClient: this,
      mvr
    });
  }
  async query(options) {
    const headers4 = new Headers({
      "Content-Type": "application/json",
      ...this.#headers
    });
    if (!headers4.has(CLIENT_PROTOCOL_VERSION_HEADER)) headers4.set(CLIENT_PROTOCOL_VERSION_HEADER, String(MAX_PROTOCOL_VERSION));
    const res = await this.#fetch(this.#url, {
      method: "POST",
      headers: headers4,
      body: JSON.stringify({
        query: typeof options.query === "string" || options.query instanceof String ? String(options.query) : print(options.query),
        variables: options.variables,
        extensions: options.extensions,
        operationName: options.operationName
      }),
      signal: options.signal
    });
    if (!res.ok) throw new SuiGraphQLRequestError(`GraphQL request failed: ${res.statusText} (${res.status})`);
    return await res.json();
  }
  async execute(query, options) {
    return this.query({
      ...options,
      query: this.#queries[query]
    });
  }
  getObjects(input) {
    return this.core.getObjects(input);
  }
  getObject(input) {
    return this.core.getObject(input);
  }
  listCoins(input) {
    return this.core.listCoins(input);
  }
  listOwnedObjects(input) {
    return this.core.listOwnedObjects(input);
  }
  getBalance(input) {
    return this.core.getBalance(input);
  }
  listBalances(input) {
    return this.core.listBalances(input);
  }
  getCoinMetadata(input) {
    return this.core.getCoinMetadata(input);
  }
  getTransaction(input) {
    return this.core.getTransaction(input);
  }
  executeTransaction(input) {
    return this.core.executeTransaction(input);
  }
  signAndExecuteTransaction(input) {
    return this.core.signAndExecuteTransaction(input);
  }
  waitForTransaction(input) {
    return this.core.waitForTransaction(input);
  }
  simulateTransaction(input) {
    return this.core.simulateTransaction(input);
  }
  getReferenceGasPrice(input) {
    return this.core.getReferenceGasPrice(input);
  }
  getCurrentSystemState(input) {
    return this.core.getCurrentSystemState(input);
  }
  getProtocolConfig(input) {
    return this.core.getProtocolConfig(input);
  }
  getChainIdentifier(input) {
    return this.core.getChainIdentifier(input);
  }
  async listDynamicFields(input) {
    const includeValue = input.include?.value ?? false;
    const { data, errors } = await this.query({
      query: GetDynamicFieldsDocument,
      signal: input.signal,
      variables: {
        parentId: input.parentId,
        first: input.limit,
        cursor: input.cursor,
        includeValue
      }
    });
    if (errors?.length) throw errors.length === 1 ? new Error(errors[0].message) : new AggregateError(errors.map((e) => new Error(e.message)));
    const result = data?.address?.dynamicFields;
    if (!result) throw new Error("Missing response data");
    return {
      dynamicFields: result.nodes.map((dynamicField) => {
        const valueType = dynamicField.value?.__typename === "MoveObject" ? dynamicField.value.contents?.type?.repr : dynamicField.value?.type?.repr;
        const isDynamicObject = dynamicField.value?.__typename === "MoveObject";
        const derivedNameType = isDynamicObject ? `0x2::dynamic_object_field::Wrapper<${dynamicField.name?.type?.repr}>` : dynamicField.name?.type?.repr;
        let value;
        if (includeValue) {
          let valueBcs;
          if (dynamicField.value?.__typename === "MoveValue") valueBcs = fromBase647(dynamicField.value.bcs ?? "");
          else if (dynamicField.value?.__typename === "MoveObject") valueBcs = fromBase647(dynamicField.value.contents?.bcs ?? "");
          else valueBcs = new Uint8Array();
          value = {
            type: valueType,
            bcs: valueBcs
          };
        }
        return {
          $kind: isDynamicObject ? "DynamicObject" : "DynamicField",
          fieldId: deriveDynamicFieldID(input.parentId, derivedNameType, fromBase647(dynamicField.name?.bcs)),
          type: normalizeStructTag(isDynamicObject ? `0x2::dynamic_field::Field<0x2::dynamic_object_field::Wrapper<${dynamicField.name?.type?.repr}>,0x2::object::ID>` : `0x2::dynamic_field::Field<${dynamicField.name?.type?.repr},${valueType}>`),
          name: {
            type: dynamicField.name?.type?.repr,
            bcs: fromBase647(dynamicField.name?.bcs)
          },
          valueType,
          childId: isDynamicObject && dynamicField.value?.__typename === "MoveObject" ? dynamicField.value.address : void 0,
          value: includeValue ? value : void 0
        };
      }),
      cursor: result.pageInfo.endCursor ?? null,
      hasNextPage: result.pageInfo.hasNextPage
    };
  }
  getDynamicField(input) {
    return this.core.getDynamicField(input);
  }
  getDynamicObjectField(input) {
    return this.core.getDynamicObjectField(input);
  }
  listTransactions(input) {
    return this.core.listTransactions(input);
  }
  listEvents(input) {
    return this.core.listEvents(input);
  }
  getMoveFunction(input) {
    return this.core.getMoveFunction(input);
  }
  resolveTransactionPlugin() {
    return this.core.resolveTransactionPlugin();
  }
  verifyZkLoginSignature(input) {
    return this.core.verifyZkLoginSignature(input);
  }
  defaultNameServiceName(input) {
    return this.core.defaultNameServiceName(input);
  }
  resolveNameServiceAddress(input) {
    return this.core.resolveNameServiceAddress(input);
  }
};

// netlify/preview-lib/treeforce89-source/game/wallet-challenge.mjs
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

// netlify/preview-lib/treeforce89-source/game/tree-payment.mjs
function normalizeSuiAddress2(value) {
  if (typeof value !== "string" || !/^0x[0-9a-fA-F]{1,64}$/.test(value)) {
    throw new Error("Invalid Sui address");
  }
  return "0x" + value.slice(2).toLowerCase().padStart(64, "0");
}

// netlify/preview-lib/treeforce89-source/game/wallet-challenge.mjs
var hash = (value) => createHash("sha256").update(value, "utf8").digest("hex");
function createWalletChallengeService({ challengeStore, signatureVerifier, origin, now = () => Date.now() }) {
  if (typeof challengeStore?.save !== "function" || typeof challengeStore?.consumeOnce !== "function")
    throw new Error("Durable atomic challenge store required");
  if (typeof signatureVerifier !== "function") throw new Error("Trusted signature verifier required");
  if (typeof origin !== "string" || !/^https:\/\/[a-z0-9.-]+(?::[0-9]+)?$/i.test(origin))
    throw new Error("Fixed HTTPS application origin required");
  return {
    async issue({ wallet }) {
      const address = normalizeSuiAddress2(wallet);
      const nonce = randomBytes(32).toString("hex");
      const issuedAt = now();
      const expiresAt = issuedAt + 5 * 6e4;
      const message = [
        "TREE FORCE '89 wallet login",
        "Origin: " + origin,
        "Network: sui:mainnet",
        "Wallet: " + address,
        "Nonce: " + nonce,
        "Expires: " + new Date(expiresAt).toISOString(),
        "This signature does not authorize a token transfer."
      ].join("\n");
      await challengeStore.save({ challengeHash: hash(nonce), wallet: address, message, expiresAt });
      return { nonce, message, expiresAt };
    },
    async verify({ wallet, nonce, signature }) {
      const address = normalizeSuiAddress2(wallet);
      if (typeof nonce !== "string" || !/^[a-f0-9]{64}$/.test(nonce)) throw new Error("Invalid challenge nonce");
      if (typeof signature !== "string" || signature.length < 8 || signature.length > 2048)
        throw new Error("Invalid signature");
      const saved = await challengeStore.consumeOnce(hash(nonce));
      if (!saved) throw new Error("Challenge missing or already used");
      if (saved.expiresAt <= now()) throw new Error("Challenge expired");
      if (normalizeSuiAddress2(saved.wallet) !== address) throw new Error("Challenge wallet mismatch");
      if (typeof saved.message !== "string" || !saved.message.includes("Origin: " + origin + "\n"))
        throw new Error("Challenge origin mismatch");
      const valid = await signatureVerifier({ message: saved.message, signature, wallet: address });
      if (valid !== true) throw new Error("Wallet signature invalid");
      return { wallet: address, verified: true };
    }
  };
}

// netlify/preview-lib/treeforce89-source/game/postgres-wallet-challenges.mjs
function createPostgresChallengeStore(pool) {
  if (!pool || typeof pool.query !== "function") {
    throw new Error("PostgreSQL pool required for wallet challenges");
  }
  return {
    async save({ challengeHash, wallet, message, expiresAt }) {
      if (typeof challengeHash !== "string" || !/^[a-f0-9]{64}$/.test(challengeHash)) {
        throw new Error("Invalid challenge hash");
      }
      if (typeof wallet !== "string" || typeof message !== "string" || !Number.isSafeInteger(expiresAt)) {
        throw new Error("Invalid wallet challenge");
      }
      const result = await pool.query(
        `INSERT INTO tree_wallet_challenges
          (challenge_hash, wallet, message, expires_at)
         VALUES ($1,$2,$3,$4) RETURNING challenge_hash`,
        [challengeHash, wallet, message, new Date(expiresAt)]
      );
      if (result.rows?.length !== 1) throw new Error("Challenge not saved");
    },
    async consumeOnce(challengeHash) {
      if (typeof challengeHash !== "string" || !/^[a-f0-9]{64}$/.test(challengeHash)) {
        throw new Error("Invalid challenge hash");
      }
      const result = await pool.query(
        `DELETE FROM tree_wallet_challenges
         WHERE challenge_hash = $1
         RETURNING wallet, message, expires_at`,
        [challengeHash]
      );
      if (result.rows?.length !== 1) return null;
      const row = result.rows[0];
      const expiresAt = row.expires_at instanceof Date ? row.expires_at.getTime() : new Date(row.expires_at).getTime();
      if (!Number.isFinite(expiresAt)) throw new Error("Invalid stored challenge expiry");
      return { wallet: row.wallet, message: row.message, expiresAt };
    }
  };
}

// netlify/preview-lib/treeforce89-source/game/postgres-wallet-logins.mjs
import { createHash as createHash2 } from "node:crypto";
function createPostgresWalletLoginStore(pool) {
  if (typeof pool?.query !== "function") throw new Error("PostgreSQL pool required");
  return {
    async save({ tokenHash: tokenHash2, wallet, expiresAt }) {
      if (typeof tokenHash2 !== "string" || !/^[a-f0-9]{64}$/.test(tokenHash2))
        throw new Error("Invalid token hash");
      if (!Number.isSafeInteger(expiresAt)) throw new Error("Invalid login expiration");
      const address = normalizeSuiAddress2(wallet);
      const result = await pool.query(
        `INSERT INTO tree_wallet_logins(token_hash,wallet,expires_at)
         VALUES($1,$2,$3) RETURNING token_hash`,
        [tokenHash2, address, new Date(expiresAt)]
      );
      if (result.rows?.length !== 1) throw new Error("Login credential not persisted");
    },
    async resolve(token) {
      if (typeof token !== "string" || !/^[a-f0-9]{64}$/.test(token))
        throw new Error("Invalid login credential");
      const tokenHash2 = createHash2("sha256").update(token, "utf8").digest("hex");
      const result = await pool.query(
        `SELECT wallet FROM tree_wallet_logins
         WHERE token_hash=$1 AND expires_at>NOW() AND revoked_at IS NULL`,
        [tokenHash2]
      );
      if (result.rows?.length !== 1) throw new Error("Login credential expired or revoked");
      return { wallet: normalizeSuiAddress2(result.rows[0].wallet) };
    }
  };
}

// netlify/preview-lib/treeforce89-source/game/wallet-login-issuer.mjs
import { createHash as createHash3, randomBytes as randomBytes2 } from "node:crypto";
var sha256 = (value) => createHash3("sha256").update(value, "utf8").digest("hex");
function createWalletLoginIssuer({ store, now = () => Date.now(), ttlMs = 30 * 6e4 }) {
  if (typeof store?.save !== "function") throw new Error("Durable wallet login store required");
  if (!Number.isSafeInteger(ttlMs) || ttlMs < 6e4 || ttlMs > 24 * 60 * 6e4)
    throw new Error("Invalid wallet login lifetime");
  return {
    async issueVerifiedWallet({ wallet, verified }) {
      if (verified !== true) throw new Error("Verified wallet signature required");
      const address = normalizeSuiAddress2(wallet);
      const token = randomBytes2(32).toString("hex");
      const expiresAt = now() + ttlMs;
      await store.save({ tokenHash: sha256(token), wallet: address, expiresAt });
      return { token, expiresAt };
    }
  };
}
function createWalletLoginService({ challengeService, issuer }) {
  if (typeof challengeService?.verify !== "function" || typeof issuer?.issueVerifiedWallet !== "function")
    throw new Error("Trusted challenge verifier and login issuer required");
  return {
    async authenticate({ wallet, nonce, signature }) {
      const proof = await challengeService.verify({ wallet, nonce, signature });
      if (proof?.verified !== true || !proof.wallet) throw new Error("Wallet signature not verified");
      return issuer.issueVerifiedWallet({ wallet: proof.wallet, verified: true });
    }
  };
}

// netlify/preview-lib/treeforce89-source/game/sui-personal-message-verifier.mjs
import { isValidPersonalMessageSignature } from "@mysten/sui/verify";
function createSuiPersonalMessageVerifier({ client, verify = isValidPersonalMessageSignature } = {}) {
  if (typeof verify !== "function") throw new Error("Sui personal-message verifier required");
  return async function signatureVerifier({ message, signature, wallet }) {
    if (typeof message !== "string" || message.length < 1 || message.length > 4096)
      throw new Error("Invalid wallet challenge message");
    if (typeof signature !== "string" || signature.length < 8 || signature.length > 2048)
      throw new Error("Invalid wallet signature");
    const address = normalizeSuiAddress2(wallet);
    return await verify(new TextEncoder().encode(message), signature, { address, ...client ? { client } : {} }) === true;
  };
}

// netlify/preview-lib/treeforce89-source/game/game-session-issuer.mjs
import { randomBytes as randomBytes3, createHash as createHash4 } from "node:crypto";
function createGameSessionIssuer({ loginStore, ownershipChecker, pool, now = () => Date.now(), ttlMs = 2 * 60 * 6e4 }) {
  if (typeof loginStore?.resolve !== "function") throw new Error("Authenticated wallet login store required");
  if (typeof ownershipChecker !== "function") throw new Error("Trusted NFTree ownership checker required");
  if (typeof pool?.query !== "function") throw new Error("PostgreSQL pool required");
  if (!Number.isSafeInteger(ttlMs) || ttlMs < 6e4 || ttlMs > 24 * 60 * 6e4) throw new Error("Invalid session lifetime");
  return {
    async create({ loginToken }) {
      if (typeof loginToken !== "string" || !/^[a-f0-9]{64}$/.test(loginToken))
        throw new Error("Valid wallet login credential required");
      const login = await loginStore.resolve(loginToken);
      if (!login?.wallet) throw new Error("Wallet login not authenticated");
      const wallet = normalizeSuiAddress2(login.wallet);
      const eligible = await ownershipChecker({ wallet });
      if (eligible !== true) throw Object.assign(new Error("NFTree ownership required"), { code: "NFTREE_REQUIRED" });
      const sessionId = randomBytes3(24).toString("hex");
      const runId = "grove-" + randomBytes3(16).toString("hex");
      const sessionToken = randomBytes3(32).toString("hex");
      const tokenHash2 = createHash4("sha256").update(sessionToken, "utf8").digest("hex");
      const expiresAt = now() + ttlMs;
      const inserted = await pool.query(
        `INSERT INTO tree_game_sessions
          (session_id,wallet,session_token_hash,expires_at,run_id,wave,
           continuation_number,game_over,cleared,continue_pending)
         VALUES($1,$2,$3,$4,$5,0,0,FALSE,FALSE,FALSE)
         RETURNING session_id`,
        [sessionId, wallet, tokenHash2, new Date(expiresAt), runId]
      );
      if (inserted.rows?.length !== 1) throw new Error("Game session not persisted");
      return { sessionId, sessionToken, runId, wallet, expiresAt };
    }
  };
}

// netlify/preview-lib/treeforce89-source/game/nftree-access.mjs
var NFTREE_TYPE = "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705::collection::NFT";
async function checkDirectNFTreeOwnership({ client, wallet, network = "mainnet" }) {
  if (network !== "mainnet") throw new Error("NFTree gateway requires Sui mainnet");
  if (!client?.core?.listOwnedObjects) throw new Error("Sui Core API client required");
  const owner = normalizeSuiAddress2(wallet);
  let cursor;
  const seen = /* @__PURE__ */ new Set();
  for (let page = 0; page < 200; page++) {
    const result = await client.core.listOwnedObjects({
      owner,
      type: NFTREE_TYPE,
      limit: 50,
      ...cursor ? { cursor } : {}
    });
    if (!result || !Array.isArray(result.objects)) throw new Error("Invalid NFTree ownership response");
    if (result.objects.some((object3) => object3 && !(object3 instanceof Error) && object3.type === NFTREE_TYPE)) {
      return true;
    }
    if (!result.cursor) return false;
    if (seen.has(result.cursor)) throw new Error("Repeated NFTree pagination cursor");
    seen.add(result.cursor);
    cursor = result.cursor;
  }
  throw new Error("NFTree ownership query exceeded page limit");
}

// netlify/preview-lib/treeforce89-source/game/nftree-session-service.mjs
function createNFTreeSessionService({ postgresPool, suiClient: suiClient2, now, ttlMs }) {
  if (suiClient2?.network !== "mainnet" || typeof suiClient2?.core?.listOwnedObjects !== "function") {
    throw new Error("Trusted Sui mainnet Core API client required");
  }
  const loginStore = createPostgresWalletLoginStore(postgresPool);
  const ownershipChecker = ({ wallet }) => checkDirectNFTreeOwnership({ client: suiClient2, wallet, network: "mainnet" });
  return createGameSessionIssuer({
    loginStore,
    ownershipChecker,
    pool: postgresPool,
    ...now ? { now } : {},
    ...ttlMs ? { ttlMs } : {}
  });
}

// netlify/preview-lib/treeforce89-source/game/credential-revocation.mjs
import { createHash as createHash5 } from "node:crypto";
var tokenHash = (token) => {
  if (typeof token !== "string" || !/^[a-f0-9]{64}$/.test(token))
    throw new Error("Invalid authentication credential");
  return createHash5("sha256").update(token, "utf8").digest("hex");
};
function createCredentialRevoker(pool) {
  if (typeof pool?.connect !== "function") throw new Error("PostgreSQL transaction pool required");
  return {
    async revoke({ loginToken, sessionToken } = {}) {
      if (loginToken === void 0 && sessionToken === void 0)
        throw new Error("At least one credential required");
      const loginHash = loginToken === void 0 ? null : tokenHash(loginToken);
      const sessionHash = sessionToken === void 0 ? null : tokenHash(sessionToken);
      const client = await pool.connect();
      let begun = false;
      try {
        await client.query("BEGIN");
        begun = true;
        let loginRevoked = false, sessionRevoked = false;
        if (loginHash) {
          const result = await client.query(
            `UPDATE tree_wallet_logins SET revoked_at=NOW()
             WHERE token_hash=$1 AND revoked_at IS NULL
             RETURNING token_hash`,
            [loginHash]
          );
          loginRevoked = result.rows?.length === 1;
        }
        if (sessionHash) {
          const result = await client.query(
            `UPDATE tree_game_sessions SET expires_at=NOW(),
                continue_pending=FALSE
             WHERE session_token_hash=$1 AND expires_at>NOW()
             RETURNING session_id`,
            [sessionHash]
          );
          sessionRevoked = result.rows?.length === 1;
        }
        await client.query("COMMIT");
        begun = false;
        return { loginRevoked, sessionRevoked };
      } catch (error) {
        if (begun) {
          try {
            await client.query("ROLLBACK");
          } catch {
          }
        }
        throw error;
      } finally {
        client.release();
      }
    }
  };
}

// netlify/preview-lib/treeforce89-source/game/wallet-gateway-service.mjs
function createWalletGatewayService({ pool, client, origin }) {
  const challengeService = createWalletChallengeService({
    challengeStore: createPostgresChallengeStore(pool),
    signatureVerifier: createSuiPersonalMessageVerifier({ client }),
    origin
  });
  const loginService = createWalletLoginService({
    challengeService,
    issuer: createWalletLoginIssuer({ store: createPostgresWalletLoginStore(pool) })
  });
  const sessions = createNFTreeSessionService({ postgresPool: pool, suiClient: client });
  const revoker = createCredentialRevoker(pool);
  return {
    issue: (input) => challengeService.issue(input),
    async enter(input) {
      let login;
      try {
        login = await loginService.authenticate(input);
      } catch {
        throw Object.assign(new Error("Sign-in could not be verified. Please sign a new message."), { code: "SIGN_IN_REJECTED", status: 401 });
      }
      let session;
      try {
        session = await sessions.create({ loginToken: login.token });
      } catch (error) {
        if (error.code === "NFTREE_REQUIRED") throw Object.assign(new Error("No directly owned NFTree was found in the signing wallet. Kiosk holdings are not supported in this preview."), { code: "NFTREE_REQUIRED", status: 403 });
        throw Object.assign(new Error("NFTree verification is temporarily unavailable. Please retry."), { code: "VERIFICATION_UNAVAILABLE", status: 503 });
      } finally {
        await revoker.revoke({ loginToken: login.token });
      }
      return { sessionToken: session.sessionToken, runId: session.runId, expiresAt: session.expiresAt };
    },
    revoke: (input) => revoker.revoke(input)
  };
}

// netlify/preview-lib/treeforce89-source/game/game-run-service.mjs
import { createHash as createHash7, randomBytes as randomBytes4 } from "node:crypto";

// netlify/preview-lib/treeforce89-source/game/authenticated-session.mjs
import { createHash as createHash6 } from "node:crypto";
function createAuthenticatedSessionResolver(pool) {
  if (!pool || typeof pool.query !== "function") {
    throw new Error("PostgreSQL pool with query() required");
  }
  return async function resolveSession(authContext) {
    const token = authContext?.sessionToken;
    if (typeof token !== "string" || !/^[a-f0-9]{64}$/.test(token)) {
      throw Object.assign(new Error("Valid authenticated session token required"), { code: "SESSION_REQUIRED" });
    }
    const hash3 = createHash6("sha256").update(token, "utf8").digest("hex");
    const result = await pool.query(
      `SELECT session_id, wallet, run_id, wave, continuation_number,
              game_over, cleared, continue_pending, created_at, expires_at
       FROM tree_game_sessions
       WHERE session_token_hash = $1 AND expires_at > NOW()`,
      [hash3]
    );
    if (result.rows?.length !== 1) {
      throw Object.assign(new Error("Session expired or not authenticated"), { code: "SESSION_REQUIRED" });
    }
    const row = result.rows[0];
    const createdAt = new Date(row.created_at).getTime(), expiresAt = new Date(row.expires_at).getTime();
    if (!Number.isSafeInteger(createdAt) || !Number.isSafeInteger(expiresAt) || createdAt >= expiresAt)
      throw new Error("Invalid authoritative session lifetime");
    if (!Number.isSafeInteger(Number(row.wave)) || Number(row.wave) < 0 || !Number.isSafeInteger(Number(row.continuation_number)) || Number(row.continuation_number) < 0) {
      throw new Error("Invalid authoritative session state");
    }
    return {
      sessionId: row.session_id,
      wallet: normalizeSuiAddress2(row.wallet),
      runId: row.run_id,
      wave: Number(row.wave),
      continuationNumber: Number(row.continuation_number),
      gameOver: row.game_over === true,
      cleared: row.cleared === true,
      continuePending: row.continue_pending === true,
      createdAt,
      expiresAt
    };
  };
}

// netlify/preview-lib/treeforce89-source/game/game-run-service.mjs
var failure = (code) => Object.assign(new Error(code), { code });
function createGameRunService({ pool, ownershipChecker }) {
  if (typeof pool?.connect !== "function" || typeof ownershipChecker !== "function")
    throw Error("Trusted database and NFTree checker required");
  const resolve = createAuthenticatedSessionResolver(pool);
  return {
    async restart({ sessionToken, runId }) {
      let previous;
      try {
        previous = await resolve({ sessionToken });
      } catch (error) {
        if (error?.code === "SESSION_REQUIRED") throw failure("SESSION_REQUIRED");
        throw error;
      }
      if (previous.runId !== runId) throw failure("RUN_CHANGED");
      if (await ownershipChecker({ wallet: previous.wallet }) !== true) throw failure("NFTREE_REQUIRED");
      const hash3 = createHash7("sha256").update(sessionToken, "utf8").digest("hex");
      const nextToken = randomBytes4(32).toString("hex");
      const nextHash = createHash7("sha256").update(nextToken, "utf8").digest("hex");
      const nextRun = "grove-" + randomBytes4(16).toString("hex");
      const nextId = randomBytes4(24).toString("hex");
      const db = await pool.connect();
      let begun = false;
      try {
        await db.query("BEGIN");
        begun = true;
        const locked = await db.query(`SELECT session_id,wallet,run_id,expires_at
          FROM tree_game_sessions
          WHERE session_token_hash=$1 AND expires_at>clock_timestamp() FOR UPDATE`, [hash3]);
        const row = locked.rows?.[0];
        if (!row || row.wallet !== previous.wallet) throw failure("SESSION_REQUIRED");
        if (row.run_id !== runId) throw failure("RUN_CHANGED");
        const expiresAt = new Date(row.expires_at).getTime();
        if (!Number.isSafeInteger(expiresAt)) throw Error("Invalid expiry");
        await db.query(`UPDATE tree_game_sessions
          SET expires_at=clock_timestamp(),continue_pending=FALSE WHERE session_id=$1`, [row.session_id]);
        const inserted = await db.query(
          `INSERT INTO tree_game_sessions
          (session_id,wallet,session_token_hash,expires_at,run_id,wave,
           continuation_number,game_over,cleared,continue_pending)
          VALUES($1,$2,$3,$4,$5,0,0,FALSE,FALSE,FALSE) RETURNING session_id`,
          [nextId, previous.wallet, nextHash, new Date(expiresAt), nextRun]
        );
        if (inserted.rows?.length !== 1) throw Error("Run not persisted");
        await db.query("COMMIT");
        begun = false;
        return { sessionToken: nextToken, runId: nextRun, expiresAt };
      } catch (error) {
        if (begun) {
          try {
            await db.query("ROLLBACK");
          } catch {
          }
        }
        throw error;
      } finally {
        db.release();
      }
    }
  };
}

// netlify/preview-lib/treeforce89-database.mjs
import { createHash as createHash8 } from "node:crypto";
import { getDatabase, getConnectionString } from "@netlify/database";

// netlify/preview-lib/treeforce89-database-evidence.json
var treeforce89_database_evidence_default = {
  branch: "feature/treeforce89-play-integration",
  siteId: "aa62f324-b880-47d6-85b8-4ba0700ff5bf",
  productionDatabaseIdentities: [
    "5a940f1b6bdcce4a96dff3ffcfeb6a2b5de01b09fcfe2f8f1e351a9a0ef47712",
    "5db7840e95d93a2a62119d00e7f2774591f307ea086ac00026f9a91777247141"
  ],
  productionSupabaseProject: "lehswszuekjqottolmsf",
  previewDatabaseIdentity: "df2f0abee059d9898495a125018fa0a291d50b9050c0d4557231f409bed53065",
  isolationVerified: true,
  paymentsEnabled: false,
  dashboardVerifiedDeploy: "6ae551d85e378ea57f261a7f",
  previewPr: 70
};

// scripts/lib/treeforce89-schema.mjs
var tables = {
  tree_wallet_challenges: {
    challenge_hash: ["character", 64, false],
    wallet: ["text", null, false],
    message: ["text", null, false],
    expires_at: ["timestamp with time zone", null, false],
    created_at: ["timestamp with time zone", null, false]
  },
  tree_wallet_logins: {
    token_hash: ["character", 64, false],
    wallet: ["text", null, false],
    expires_at: ["timestamp with time zone", null, false],
    revoked_at: ["timestamp with time zone", null, true],
    created_at: ["timestamp with time zone", null, false]
  },
  tree_game_sessions: {
    session_id: ["text", null, false],
    wallet: ["text", null, false],
    session_token_hash: ["character", 64, true],
    expires_at: ["timestamp with time zone", null, false],
    run_id: ["text", null, false],
    wave: ["integer", null, false],
    continuation_number: ["integer", null, false],
    game_over: ["boolean", null, false],
    cleared: ["boolean", null, false],
    continue_pending: ["boolean", null, false],
    created_at: ["timestamp with time zone", null, false]
  },
  tree_continue_redemptions: {
    digest: ["text", null, false],
    session_id: ["text", null, false],
    continuation_number: ["integer", null, false],
    wallet: ["text", null, false],
    run_id: ["text", null, false],
    redeemed_at: ["timestamp with time zone", null, false]
  }
};
async function inspectTreeForceSchema(pool) {
  const db = await pool.connect();
  let begun = false;
  try {
    await db.query("BEGIN TRANSACTION READ ONLY");
    begun = true;
    const names = Object.keys(tables);
    const { rows: columns } = await db.query(`SELECT table_name,column_name,data_type,
      character_maximum_length,is_nullable,column_default
      FROM information_schema.columns
      WHERE table_schema='public' AND table_name=ANY($1::text[])`, [names]);
    const columnChecks = {};
    for (const [table, expected] of Object.entries(tables)) {
      for (const [name, [type, length, nullable3]] of Object.entries(expected)) {
        const column = columns.find((c) => c.table_name === table && c.column_name === name);
        columnChecks[table + "." + name] = !!column && column.data_type === type && column.character_maximum_length === length && column.is_nullable === (nullable3 ? "YES" : "NO");
      }
    }
    const { rows: constraints } = await db.query(`SELECT t.relname AS table_name,
      c.contype AS kind,c.convalidated AS validated,
      array(SELECT a.attname::text FROM unnest(c.conkey) WITH ORDINALITY k(attnum,n)
        JOIN pg_attribute a ON a.attrelid=c.conrelid AND a.attnum=k.attnum
        ORDER BY k.n) AS columns,
      f.relname AS referenced_table, fn.nspname AS referenced_schema,
      array(SELECT a.attname::text FROM unnest(c.confkey) WITH ORDINALITY k(attnum,n)
        JOIN pg_attribute a ON a.attrelid=c.confrelid AND a.attnum=k.attnum
        ORDER BY k.n) AS referenced_columns,
      pg_get_constraintdef(c.oid) AS definition
      FROM pg_constraint c JOIN pg_class t ON t.oid=c.conrelid
      JOIN pg_namespace n ON n.oid=t.relnamespace
      LEFT JOIN pg_class f ON f.oid=c.confrelid
      LEFT JOIN pg_namespace fn ON fn.oid=f.relnamespace
      WHERE n.nspname='public' AND t.relname=ANY($1::text[])`, [names]);
    const has = (table, kind, keys2) => constraints.some((c) => c.table_name === table && c.kind === kind && c.validated === true && JSON.stringify(c.columns) === JSON.stringify(keys2));
    const keys = {
      challengePrimaryKey: has(names[0], "p", ["challenge_hash"]),
      loginPrimaryKey: has(names[1], "p", ["token_hash"]),
      sessionPrimaryKey: has(names[2], "p", ["session_id"]),
      uniqueSessionToken: has(names[2], "u", ["session_token_hash"]),
      uniqueRun: has(names[2], "u", ["run_id"]),
      uniquePaymentDigest: has(names[3], "p", ["digest"]),
      uniqueContinuation: has(names[3], "u", ["session_id", "continuation_number"]),
      sessionForeignKey: constraints.some((c) => c.table_name === names[3] && c.kind === "f" && c.validated === true && JSON.stringify(c.columns) === '["session_id"]' && c.referenced_schema === "public" && c.referenced_table === names[2] && JSON.stringify(c.referenced_columns) === '["session_id"]')
    };
    const nonnegative = (column) => constraints.some((c) => c.table_name === names[2] && c.kind === "c" && c.validated === true && c.definition.replace(/[()\s]/g, "") === "CHECK" + column + ">=0");
    const checks = {
      waveNonnegative: nonnegative("wave"),
      continuationNonnegative: nonnegative("continuation_number")
    };
    const { rows: indexes } = await db.query(`SELECT t.relname AS table_name,
      i.indisvalid,i.indisready,i.indpred IS NULL AS unfiltered,
      array(SELECT a.attname::text FROM unnest(i.indkey) WITH ORDINALITY k(attnum,n)
        JOIN pg_attribute a ON a.attrelid=i.indrelid AND a.attnum=k.attnum
        ORDER BY k.n) AS columns
      FROM pg_index i JOIN pg_class t ON t.oid=i.indrelid
      JOIN pg_namespace n ON n.oid=t.relnamespace
      WHERE n.nspname='public' AND t.relname=ANY($1::text[])`, [names]);
    const walletIndex = (table) => indexes.some((i) => i.table_name === table && i.indisvalid && i.indisready && i.unfiltered && JSON.stringify(i.columns) === '["wallet"]');
    const indexChecks = { loginWallet: walletIndex(names[1]), sessionWallet: walletIndex(names[2]) };
    const defaultIs = (table, column, pattern) => pattern.test(columns.find((c) => c.table_name === table && c.column_name === column)?.column_default || "");
    const defaults = {
      sessionExpiry: defaultIs(names[2], "expires_at", /now\(\).*02:00:00/),
      wave: defaultIs(names[2], "wave", /^0$/),
      continuation: defaultIs(names[2], "continuation_number", /^0$/),
      gameOver: defaultIs(names[2], "game_over", /^false$/),
      cleared: defaultIs(names[2], "cleared", /^false$/),
      continuePending: defaultIs(names[2], "continue_pending", /^false$/)
    };
    for (const table of names) defaults[table + ".created"] = defaultIs(
      table,
      table === names[3] ? "redeemed_at" : "created_at",
      /^now\(\)$/
    );
    await db.query("ROLLBACK");
    begun = false;
    return {
      schemaReady: [columnChecks, keys, checks, indexChecks, defaults].every((group) => Object.values(group).every(Boolean)),
      tableCount: names.filter((table) => columns.some((c) => c.table_name === table)).length,
      columnChecks,
      keys,
      checks,
      indexChecks,
      defaults,
      hostedIsolationVerified: false,
      paymentsEnabled: false
    };
  } finally {
    if (begun) try {
      await db.query("ROLLBACK");
    } catch {
    }
    db.release();
  }
}

// netlify/preview-lib/treeforce89-database.mjs
var cached;
var canonicalCached;
function databaseIdentity(connectionString) {
  const url = new URL(connectionString);
  if (!["postgres:", "postgresql:"].includes(url.protocol) || !url.hostname.endsWith(".db.netlify.com") || url.pathname !== "/netlifydb")
    throw Error("Unapproved database provider");
  const host = url.hostname.replace(/-pooler(?=\.)/, "");
  return createHash8("sha256").update(host + "|" + url.pathname).digest("hex");
}
function previewRequestAllowed(build2, context, request) {
  if (build2?.branch !== treeforce89_database_evidence_default.branch || build2?.context !== "deploy-preview" || context?.deploy?.context !== "deploy-preview" || context?.site?.id !== treeforce89_database_evidence_default.siteId || !/^[a-f0-9]{24}$/.test(context?.deploy?.id || "") || !Number.isSafeInteger(build2.prNumber) || build2.prNumber < 1) return false;
  const url = new URL(request.url);
  return url.protocol === "https:" && [
    `deploy-preview-${build2.prNumber}--tree-token.netlify.app`,
    `${context.deploy.id}--tree-token.netlify.app`
  ].includes(url.host) && request.method === "POST" && request.headers.get("origin") === url.origin && request.headers.get("sec-fetch-site") !== "cross-site";
}
function canonicalDevelopmentRequestAllowed(build2, context, request) {
  if (build2?.branch !== treeforce89_database_evidence_default.branch || build2?.mode !== "canonical-development" || context?.deploy?.context !== "production" || context?.site?.id !== treeforce89_database_evidence_default.siteId || !/^[a-f0-9]{24}$/.test(context?.deploy?.id || "")) return false;
  const url = new URL(request.url);
  return url.protocol === "https:" && [
    "tree-token.xyz",
    "www.tree-token.xyz",
    // An immutable candidate can be verified with unfunded test keys before publication.
    `${context.deploy.id}--tree-token.netlify.app`
  ].includes(url.host) && url.pathname.startsWith("/play/treeforce89/api/") && request.method === "POST" && request.headers.get("origin") === url.origin && request.headers.get("sec-fetch-site") !== "cross-site";
}
function gatewayRequestAllowed(build2, context, request) {
  return build2?.mode === "canonical-development" ? canonicalDevelopmentRequestAllowed(build2, context, request) : previewRequestAllowed(build2, context, request);
}
function getCanonicalDevelopmentDatabase() {
  const connectionString = process.env.TREEFORCE89_DEV_DATABASE_URL;
  if (!connectionString) throw Error("Development database binding unavailable");
  const identity = databaseIdentity(connectionString);
  if (treeforce89_database_evidence_default.isolationVerified !== true || treeforce89_database_evidence_default.productionDatabaseIdentities.includes(identity) || identity !== treeforce89_database_evidence_default.previewDatabaseIdentity) throw Error("Database isolation unverified");
  if (!canonicalCached || canonicalCached.identity !== identity)
    canonicalCached = { identity, pool: getDatabase({ connectionString }).pool };
  return canonicalCached;
}
function getPreviewDatabase({ requireVerified = true } = {}) {
  const identity = databaseIdentity(getConnectionString());
  if (treeforce89_database_evidence_default.productionDatabaseIdentities.includes(identity)) throw Error("Production database refused");
  if (requireVerified && (treeforce89_database_evidence_default.isolationVerified !== true || identity !== treeforce89_database_evidence_default.previewDatabaseIdentity)) throw Error("Database isolation unverified");
  if (!cached || cached.identity !== identity) cached = { identity, pool: getDatabase().pool };
  return cached;
}

// netlify/preview-lib/treeforce89-source/game/preview-access.mjs
var previewAccessAllowed = gatewayRequestAllowed;

// netlify/preview-lib/treeforce89-source/game/wallet-gateway-http.mjs
var headers = { "Cache-Control": "no-store", "X-Robots-Tag": "noindex" };
var response = (body, status) => Response.json(body, { status, headers });
async function readInput(request, allowed) {
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) throw Error("JSON required");
  const reader = request.body?.getReader();
  if (!reader) throw Error("JSON required");
  let size = 0;
  const chunks = [];
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > 4096) {
        await reader.cancel();
        throw Error("Request too large");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk4 of chunks) {
    bytes.set(chunk4, offset);
    offset += chunk4.length;
  }
  const input = JSON.parse(new TextDecoder().decode(bytes));
  if (!input || Array.isArray(input) || typeof input !== "object" || Object.keys(input).length !== allowed.length || !allowed.every((key) => typeof input[key] === "string")) throw Error("Invalid fields");
  input.wallet = normalizeSuiAddress2(input.wallet);
  return input;
}
function createWalletGatewayHttpHandler({ action, build: build2, getService }) {
  return async function handler2(request, context) {
    if (!previewAccessAllowed(build2, context, request)) return response({ enabled: false }, 503);
    if (request.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405, headers: { ...headers, Allow: "POST" } });
    const origin = new URL(request.url).origin;
    if (request.headers.get("origin") !== origin || request.headers.get("sec-fetch-site") === "cross-site")
      return response({ error: "Use this game\u2019s own sign-in page." }, 403);
    let input;
    try {
      input = await readInput(request, action === "challenge" ? ["wallet"] : ["wallet", "nonce", "signature"]);
    } catch {
      return response({ error: "Invalid sign-in request." }, 400);
    }
    try {
      const service = await getService(origin);
      if (action === "challenge") return response(await service.issue(input), 201);
      return response(await service.enter(input), 201);
    } catch (error) {
      const messages = {
        SIGN_IN_REJECTED: ["Sign-in could not be verified. Please sign a new message.", 401],
        NFTREE_REQUIRED: ["No directly owned NFTree was found in the signing wallet. Kiosk holdings are not supported in this preview.", 403],
        VERIFICATION_UNAVAILABLE: ["NFTree verification is temporarily unavailable. Please retry.", 503]
      };
      if (action !== "challenge" && Object.hasOwn(messages, error?.code)) {
        const [message, status] = messages[error.code];
        return response({ error: message, code: error.code }, status);
      }
      return response(
        { error: action === "challenge" ? "Sign-in is temporarily unavailable. Please try again." : "Access could not be verified. Use the signing wallet with a directly owned NFTree and try again." },
        action === "challenge" ? 503 : 403
      );
    }
  };
}

// netlify/preview-lib/treeforce89-source/game/game-run-http.mjs
var headers2 = { "Cache-Control": "no-store", "X-Robots-Tag": "noindex" };
var reply = (body, status) => Response.json(body, { status, headers: headers2 });
function createAuthenticatedRunHttpHandler({ build: build2, getService, action }) {
  if (!["restart", "review"].includes(action)) throw Error("Invalid authenticated run action");
  return async function handler2(request, context) {
    if (!previewAccessAllowed(build2, context, request)) return reply({ enabled: false }, 503);
    if (request.method !== "POST") return Response.json(
      { error: "Method not allowed" },
      { status: 405, headers: { ...headers2, Allow: "POST" } }
    );
    if (request.headers.get("origin") !== new URL(request.url).origin || request.headers.get("sec-fetch-site") === "cross-site") return reply({ error: "Origin not permitted" }, 403);
    const token = /^Bearer ([a-f0-9]{64})$/.exec(request.headers.get("authorization") || "")?.[1];
    if (!token) return reply({ error: "Verify your NFTree again.", code: "SESSION_REQUIRED" }, 401);
    if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json"))
      return reply({ error: "JSON required" }, 415);
    let runId;
    try {
      const reader = request.body?.getReader();
      if (!reader) throw Error("Body required");
      const chunks = [];
      let size = 0;
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          size += value.byteLength;
          if (size > 256) {
            await reader.cancel();
            throw Error("Too large");
          }
          chunks.push(value);
        }
      } finally {
        reader.releaseLock();
      }
      const bytes = new Uint8Array(size);
      let offset = 0;
      for (const chunk4 of chunks) {
        bytes.set(chunk4, offset);
        offset += chunk4.length;
      }
      const body = JSON.parse(new TextDecoder().decode(bytes));
      if (!body || Array.isArray(body) || Object.keys(body).length !== 1 || typeof body.runId !== "string" || !/^grove-[a-f0-9]{32}$/.test(body.runId)) throw Error("Invalid run");
      runId = body.runId;
    } catch {
      return reply({ error: "Only the current run identifier is permitted." }, 400);
    }
    try {
      const service = await getService();
      return reply(await service[action]({ sessionToken: token, runId }), 201);
    } catch (error) {
      const errors = {
        SESSION_REQUIRED: [401, "Verify your NFTree again."],
        RUN_CHANGED: [409, "This run has changed. Verify your NFTree again."],
        NFTREE_REQUIRED: [403, "A directly held NFTree is required."]
      };
      if (Object.hasOwn(errors, error?.code)) {
        const [status, message] = errors[error.code];
        return reply({ code: error.code, error: message }, status);
      }
      return reply({ error: action === "review" ? "Checkout details could not be confirmed. Please retry." : "A new run could not be confirmed. Retry, or disconnect and verify your NFTree again." }, 503);
    }
  };
}
function createGameRunHttpHandler(options) {
  return createAuthenticatedRunHttpHandler({ ...options, action: "restart" });
}

// netlify/preview-lib/treeforce89-source/game/game-logout-http.mjs
function createGameLogoutHttpHandler({ revoker }) {
  if (typeof revoker?.revoke !== "function") {
    throw new Error("Trusted credential revocation service required");
  }
  return async function handle(request) {
    const headers4 = { "Cache-Control": "no-store", "Content-Type": "application/json" };
    if (request.method !== "POST") {
      return Response.json({ error: "Method not allowed" }, { status: 405, headers: { ...headers4, Allow: "POST" } });
    }
    const origin = request.headers.get("origin");
    const expectedOrigin = new URL(request.url).origin;
    if (origin && origin !== expectedOrigin) {
      return Response.json({ error: "Origin not permitted" }, { status: 403, headers: headers4 });
    }
    const authorization = request.headers.get("authorization") || "";
    const match = /^Bearer ([a-f0-9]{64})$/.exec(authorization);
    if (!match) {
      return Response.json({ error: "Game session authentication required" }, { status: 401, headers: headers4 });
    }
    if (await request.text()) {
      return Response.json({ error: "No client game-state payload permitted" }, { status: 400, headers: headers4 });
    }
    try {
      const result = await revoker.revoke({ sessionToken: match[1] });
      return Response.json({ loggedOut: true }, { status: 200, headers: headers4 });
    } catch {
      return Response.json({ loggedOut: false, error: "Logout unavailable" }, { status: 503, headers: headers4 });
    }
  };
}

// netlify/preview-lib/treeforce89-paid-continue.mjs
import { randomBytes as randomBytes5, createHash as createHash9 } from "node:crypto";

// treeforce89/paid/contract.mjs
var TREE_COIN_TYPE = "0x6c5a609f6d0288523ce4a6ed87d19ae127f62073ab75fd9b0b1c9b455d4895cf::tree::TREE";
var TREE_RECIPIENT = "0x6f1020c2fd6c91129f7cb5e0d651295e87f7245f96b7d090715c89b38197e77f";
var PRICE = "20000";
var baseUnits = (decimals) => {
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 18) throw Error("Unverified TREE decimals");
  return 20000n * 10n ** BigInt(decimals);
};
var normalizedAddress = (value) => {
  if (typeof value !== "string" || !/^0x[0-9a-fA-F]{1,64}$/.test(value)) throw Error("Invalid Sui address");
  return "0x" + value.slice(2).toLowerCase().padStart(64, "0");
};
function validateSnapshot(value, runId) {
  const fields = ["runId", "seed", "score", "wave", "kills", "perfect", "maxStage", "shotsFired", "shotsHit", "start", "mode"];
  if (!value || Array.isArray(value) || Object.keys(value).length !== fields.length || !fields.every((k) => Object.hasOwn(value, k)) || value.runId !== runId || !/^grove-[a-f0-9]{32}$/.test(runId) || value.mode !== "ARCADE") throw Error("Invalid interrupted run");
  for (const k of fields.filter((k2) => !["runId", "mode"].includes(k2)))
    if (!Number.isSafeInteger(value[k]) || value[k] < 0) throw Error("Invalid interrupted run");
  if (value.seed > 4294967295 || value.wave > 9 || value.maxStage > 4 || value.shotsHit > value.shotsFired)
    throw Error("Invalid interrupted run");
  return Object.fromEntries(fields.map((k) => [k, value[k]]));
}

// treeforce89/paid/mainnet-transaction-reader.mjs
function createMainnetTransactionReader(client, { archivalClient: archivalClient2 } = {}) {
  if (!client?.core?.getTransaction) throw new Error("Trusted Sui Core client required");
  if (client.network !== "mainnet") throw new Error("Mainnet Sui client required");
  if (archivalClient2 && (archivalClient2.network !== "mainnet" || !archivalClient2.core?.getTransaction))
    throw new Error("Trusted mainnet archival client required");
  return async function fetchTransaction(digest) {
    if (typeof digest !== "string" || !/^[1-9A-HJ-NP-Za-km-z]{32,64}$/.test(digest)) {
      throw new Error("Invalid transaction digest");
    }
    const options = {
      digest,
      include: { effects: true, balanceChanges: true, transaction: true },
      signal: AbortSignal.timeout(15e3)
    };
    let result;
    try {
      result = await client.core.getTransaction(options);
    } catch (e) {
      if (!archivalClient2) throw e;
      result = await archivalClient2.core.getTransaction({ ...options, signal: AbortSignal.timeout(15e3) });
    }
    if (!result || result.$kind !== "Transaction" || !result.Transaction) {
      throw new Error("Transaction unavailable or failed");
    }
    const tx = result.Transaction;
    if (tx.digest !== digest) throw new Error("Digest mismatch");
    if (tx.status?.success !== true || !tx.effects || tx.effects.status?.success !== true) {
      throw new Error("Transaction effects do not confirm success");
    }
    if (typeof tx.checkpoint !== "string" || !/^\d+$/.test(tx.checkpoint) || !Number.isSafeInteger(tx.timestampMs) || tx.timestampMs <= 0)
      throw new Error("Transaction has not been checkpointed");
    if (typeof tx.transaction?.sender !== "string") {
      throw new Error("Missing transaction sender");
    }
    if (!Array.isArray(tx.balanceChanges)) {
      throw new Error("Missing transaction balance changes");
    }
    const balanceChanges = tx.balanceChanges.map((change) => {
      if (typeof change.coinType !== "string" || typeof change.amount !== "string" || !/^-?\d+$/.test(change.amount) || typeof change.address !== "string") {
        throw new Error("Invalid transaction balance change");
      }
      return {
        coinType: change.coinType,
        amount: change.amount,
        owner: { kind: "AddressOwner", address: normalizedAddress(change.address) }
      };
    });
    return {
      network: "mainnet",
      success: true,
      checkpoint: tx.checkpoint,
      timestampMs: tx.timestampMs,
      sender: normalizedAddress(tx.transaction.sender),
      balanceChanges
    };
  };
}

// netlify/preview-lib/treeforce89-paid-continue.mjs
var failure2 = (code, message) => Object.assign(Error(message), { code });
var hash2 = (token) => createHash9("sha256").update(token).digest("hex");
var offerColumns = ["continue_offer_id", "continue_offer_created_at", "continue_offer_expires_at", "continue_offer_checkpoint", "continue_snapshot"];
async function paidContinueSchemaReady(pool) {
  const r = await pool.query(`SELECT table_name,column_name,data_type,is_nullable FROM information_schema.columns
  WHERE table_schema='public' AND table_name IN ('tree_game_sessions','tree_continue_redemptions')`);
  const column = (table, name, type) => r.rows.some((x) => x.table_name === table && x.column_name === name && x.data_type === type && x.is_nullable === "YES");
  const types = ["text", "timestamp with time zone", "timestamp with time zone", "text", "jsonb"];
  if (!offerColumns.every((c, i) => column("tree_game_sessions", c, types[i])) || !Object.entries({ offer_id: "text", snapshot: "jsonb", payment_timestamp_ms: "bigint", checkpoint: "text" }).every(([c, type]) => column("tree_continue_redemptions", c, type))) return false;
  const { rows: indexes } = await pool.query(`SELECT t.relname AS table_name,i.indisunique,i.indisvalid,i.indisready,
  pg_get_expr(i.indpred,i.indrelid) AS predicate,
  array(SELECT a.attname::text FROM unnest(i.indkey) WITH ORDINALITY k(attnum,n)
   JOIN pg_attribute a ON a.attrelid=i.indrelid AND a.attnum=k.attnum ORDER BY k.n) AS columns
  FROM pg_index i JOIN pg_class t ON t.oid=i.indrelid JOIN pg_namespace n ON n.oid=t.relnamespace
  WHERE n.nspname='public' AND t.relname IN ('tree_game_sessions','tree_continue_redemptions')`);
  return [["tree_game_sessions", "continue_offer_id"], ["tree_continue_redemptions", "offer_id"]].every(([table, key]) => indexes.some((i) => i.table_name === table && i.indisunique && i.indisvalid && i.indisready && JSON.stringify(i.columns) === JSON.stringify([key]) && i.predicate?.replace(/[()\s]/g, "") === key + "ISNOTNULL"));
}
function createPaidContinueService({ pool, client, archivalClient: archivalClient2, ownershipChecker, enabled = false, now = () => Date.now() }) {
  const resolveSession = createAuthenticatedSessionResolver(pool);
  const readTransaction = createMainnetTransactionReader(client, { archivalClient: archivalClient2 });
  const atomic = async (operation) => {
    const db = await pool.connect();
    try {
      await db.query("BEGIN");
      const result = await operation(db);
      await db.query("COMMIT");
      return result;
    } catch (e) {
      await db.query("ROLLBACK").catch(() => {
      });
      throw e;
    } finally {
      db.release();
    }
  };
  const requireEnabled = () => {
    if (!enabled) throw failure2("PAYMENTS_DISABLED", "Paid continues are not enabled.");
  };
  const authenticatedRow = async (db, session, token) => {
    const r = await db.query("SELECT * FROM tree_game_sessions WHERE session_id=$1 FOR UPDATE", [session.sessionId]);
    const row = r.rows[0];
    if (!row || row.session_token_hash !== hash2(token) || new Date(row.expires_at).getTime() <= now())
      throw failure2("SESSION_REQUIRED", "Verify your NFTree again.");
    return row;
  };
  const publicOffer = (row, decimals) => ({
    enabled: true,
    recipientConfirmed: true,
    offerId: row.continue_offer_id,
    wallet: row.wallet,
    runId: row.run_id,
    network: "sui:mainnet",
    coinType: TREE_COIN_TYPE,
    recipient: TREE_RECIPIENT,
    price: PRICE,
    decimals,
    amountBaseUnits: baseUnits(decimals).toString(),
    lives: 3,
    expiresAt: new Date(row.continue_offer_expires_at).getTime()
  });
  const metadata = async () => {
    const { coinMetadata } = await client.core.getCoinMetadata({ coinType: TREE_COIN_TYPE, signal: AbortSignal.timeout(15e3) });
    const decimals = coinMetadata?.decimals;
    baseUnits(decimals);
    return decimals;
  };
  return {
    async offer({ sessionToken, runId, snapshot, lives }) {
      requireEnabled();
      if (lives !== 0) throw failure2("RUN_NOT_ELIGIBLE", "Continue is available after all lives are lost.");
      const session = await resolveSession({ sessionToken });
      if (session.runId !== runId) throw failure2("RUN_CHANGED", "This run has changed.");
      let saved;
      try {
        saved = validateSnapshot(snapshot, runId);
      } catch {
        throw failure2("INVALID_REQUEST", "Invalid interrupted run.");
      }
      if (session.wallet === TREE_RECIPIENT) throw failure2("RUN_NOT_ELIGIBLE", "Use a player wallet different from the receiving treasury.");
      if (await ownershipChecker({ wallet: session.wallet }) !== true) throw failure2("NFTREE_REQUIRED", "A directly held NFTree is required.");
      const [decimals, anchor] = await Promise.all([metadata(), client.ledgerService.getCheckpoint({
        checkpointId: { oneofKind: void 0 },
        readMask: { paths: ["sequence_number"] }
      }, { abort: AbortSignal.timeout(15e3) })]);
      const checkpoint = anchor?.response?.checkpoint?.sequenceNumber?.toString();
      if (!/^\d+$/.test(checkpoint || "")) throw Error("Mainnet checkpoint unavailable");
      return atomic(async (db) => {
        const row = await authenticatedRow(db, session, sessionToken);
        if (row.run_id !== runId || row.cleared) throw failure2("RUN_CHANGED", "This run is not eligible.");
        if (row.continue_pending && row.continue_offer_id) {
          if (new Date(row.continue_offer_expires_at).getTime() <= now()) throw failure2("OFFER_EXPIRED", "Checkout expired. Start a new run.");
          if (JSON.stringify(validateSnapshot(row.continue_snapshot, runId)) !== JSON.stringify(saved))
            throw failure2("RUN_CHANGED", "The interrupted run does not match the open checkout.");
          return publicOffer(row, decimals);
        }
        const r = await db.query(`UPDATE tree_game_sessions SET game_over=TRUE,continue_pending=TRUE,wave=$2,
     continue_offer_id=$3,continue_offer_created_at=clock_timestamp(),
     continue_offer_expires_at=expires_at,continue_snapshot=$4::jsonb,continue_offer_checkpoint=$5
     WHERE session_id=$1 RETURNING *`, [session.sessionId, saved.wave, randomBytes5(24).toString("hex"), JSON.stringify(saved), checkpoint]);
        return publicOffer(r.rows[0], decimals);
      });
    },
    async redeem({ sessionToken, offerId, digest }) {
      requireEnabled();
      if (!/^[a-f0-9]{48}$/.test(offerId || "") || !/^[1-9A-HJ-NP-Za-km-z]{32,64}$/.test(digest || ""))
        throw failure2("INVALID_REQUEST", "Invalid payment reference.");
      const authenticated = await resolveSession({ sessionToken });
      const lookup = await pool.query("SELECT * FROM tree_game_sessions WHERE continue_offer_id=$1 AND wallet=$2", [offerId, authenticated.wallet]);
      const offer = lookup.rows[0];
      if (!offer) throw failure2("OFFER_REQUIRED", "Checkout does not belong to this wallet.");
      const existing = await pool.query("SELECT * FROM tree_continue_redemptions WHERE offer_id=$1", [offerId]);
      let receipt;
      if (!existing.rows.length) {
        const tx = await readTransaction(digest), decimals = await metadata();
        const start = new Date(offer.continue_offer_created_at).getTime(), end = new Date(offer.continue_offer_expires_at).getTime();
        if (!/^\d+$/.test(offer.continue_offer_checkpoint || "") || BigInt(tx.checkpoint) <= BigInt(offer.continue_offer_checkpoint) || tx.timestampMs < start - 3e4 || tx.timestampMs >= end || normalizedAddress(tx.sender) !== authenticated.wallet)
          throw failure2("PAYMENT_MISMATCH", "The payment does not match this checkout.");
        const received = tx.balanceChanges.reduce((sum, c) => c.coinType === TREE_COIN_TYPE && c.owner?.kind === "AddressOwner" && normalizedAddress(c.owner.address) === TREE_RECIPIENT ? sum + BigInt(c.amount) : sum, 0n);
        if (received < baseUnits(decimals)) throw failure2("PAYMENT_MISMATCH", "20,000 TREE has not been confirmed at the treasury.");
        receipt = tx;
      }
      return atomic(async (db) => {
        const rows = await db.query(
          "SELECT * FROM tree_game_sessions WHERE session_id=ANY($1::text[]) ORDER BY session_id FOR UPDATE",
          [[authenticated.sessionId, offer.session_id]]
        );
        const auth = rows.rows.find((r) => r.session_id === authenticated.sessionId), row = rows.rows.find((r) => r.session_id === offer.session_id);
        if (!auth || auth.session_token_hash !== hash2(sessionToken) || new Date(auth.expires_at).getTime() <= now())
          throw failure2("SESSION_REQUIRED", "Verify your NFTree again.");
        if (!row || row.wallet !== authenticated.wallet || row.continue_offer_id !== offerId || row.cleared)
          throw failure2("RUN_CHANGED", "The interrupted run has changed.");
        const prior = await db.query("SELECT * FROM tree_continue_redemptions WHERE offer_id=$1", [offerId]);
        if (prior.rows.length) {
          const used = prior.rows[0];
          if (used.digest !== digest || Number(row.continuation_number) !== Number(used.continuation_number) + 1 || row.continue_pending)
            throw failure2("PAYMENT_USED", "This payment has already been used.");
        } else {
          if (!receipt || !row.continue_pending || !row.game_over || row.continuation_number !== offer.continuation_number)
            throw failure2("RUN_CHANGED", "This checkout is no longer pending.");
          const inserted = await db.query(
            `INSERT INTO tree_continue_redemptions
      (digest,session_id,continuation_number,wallet,run_id,offer_id,snapshot,payment_timestamp_ms,checkpoint)
      VALUES($1,$2,$3,$4,$5,$6,$7::jsonb,$8,$9) ON CONFLICT DO NOTHING RETURNING digest`,
            [digest, row.session_id, row.continuation_number, row.wallet, row.run_id, offerId, JSON.stringify(row.continue_snapshot), receipt.timestampMs, receipt.checkpoint]
          );
          if (inserted.rows.length !== 1) throw failure2("PAYMENT_USED", "This payment has already been used.");
          await db.query(`UPDATE tree_game_sessions SET game_over=FALSE,continue_pending=FALSE,
      continuation_number=continuation_number+1 WHERE session_id=$1`, [row.session_id]);
          row.continuation_number++;
          row.continue_pending = false;
          row.game_over = false;
        }
        if (auth.session_id !== row.session_id) {
          await db.query("UPDATE tree_game_sessions SET session_token_hash=NULL,expires_at=clock_timestamp() WHERE session_id=$1", [auth.session_id]);
          await db.query(
            "UPDATE tree_game_sessions SET session_token_hash=$2,expires_at=$3 WHERE session_id=$1",
            [row.session_id, hash2(sessionToken), auth.expires_at]
          );
        }
        return {
          authorized: true,
          offerId,
          digest,
          runId: row.run_id,
          lives: 3,
          wave: row.wave,
          continuationNumber: Number(row.continuation_number),
          snapshot: row.continue_snapshot,
          session: { wallet: row.wallet, runId: row.run_id, sessionToken, expiresAt: new Date(auth.expires_at).getTime() }
        };
      });
    }
  };
}
function createPaidContinueHttpHandler({ action, getService }) {
  if (!["offer", "redeem"].includes(action)) throw Error("Unknown paid continue action");
  const headers4 = { "Cache-Control": "no-store", "X-Robots-Tag": "noindex" };
  const reply2 = (body, status) => Response.json(body, { status, headers: headers4 });
  return async (request) => {
    if (request.method !== "POST") return reply2({ error: "POST required" }, 405);
    if (request.headers.get("origin") !== new URL(request.url).origin || request.headers.get("sec-fetch-site") === "cross-site")
      return reply2({ error: "Origin not permitted" }, 403);
    const token = /^Bearer ([a-f0-9]{64})$/.exec(request.headers.get("authorization") || "")?.[1];
    if (!token) return reply2({ code: "SESSION_REQUIRED", error: "Verify your NFTree again." }, 401);
    if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) return reply2({ error: "JSON required" }, 415);
    let input;
    try {
      const reader = request.body?.getReader();
      if (!reader) throw Error();
      let length = 0;
      const chunks = [];
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          length += value.byteLength;
          if (length > 2048) {
            await reader.cancel();
            throw Error();
          }
          chunks.push(value);
        }
      } finally {
        reader.releaseLock();
      }
      const buffer = new Uint8Array(length);
      let offset = 0;
      for (const part of chunks) {
        buffer.set(part, offset);
        offset += part.length;
      }
      input = JSON.parse(new TextDecoder().decode(buffer));
      const fields = action === "offer" ? ["runId", "snapshot", "lives"] : ["offerId", "digest"];
      if (!input || Array.isArray(input) || Object.keys(input).length !== fields.length || !fields.every((k) => Object.hasOwn(input, k))) throw Error();
    } catch {
      return reply2({ code: "INVALID_REQUEST", error: "Invalid checkout request." }, 400);
    }
    try {
      return reply2(await (await getService())[action]({ ...input, sessionToken: token }), 200);
    } catch (e) {
      const codes = {
        SESSION_REQUIRED: 401,
        NFTREE_REQUIRED: 403,
        INVALID_REQUEST: 400,
        RUN_NOT_ELIGIBLE: 409,
        RUN_CHANGED: 409,
        OFFER_REQUIRED: 409,
        OFFER_EXPIRED: 409,
        PAYMENT_MISMATCH: 402,
        PAYMENT_USED: 409,
        PAYMENTS_DISABLED: 503
      };
      return Object.hasOwn(codes, e.code) ? reply2({ code: e.code, error: e.message }, codes[e.code]) : reply2({ code: "RETRY_VERIFICATION", error: action === "redeem" ? "Payment not confirmed yet. Retry verification; do not pay again." : "Checkout is unavailable. Please retry." }, 503);
    }
  };
}

// netlify/preview-lib/treeforce89-gateway.mjs
var schemaReady;
var suiClient;
var archivalClient;
function paidContinuesEnabled() {
  const value = typeof Netlify !== "undefined" ? Netlify.env.get("TREEFORCE89_PAID_CONTINUES_ENABLED") : process.env.TREEFORCE89_PAID_CONTINUES_ENABLED;
  return value === "true";
}
async function getPaidContinueService(origin, database = getPreviewDatabase) {
  await getGatewayServices(origin, database);
  const { pool } = database();
  if (!await paidContinueSchemaReady(pool)) throw Error("Paid continuation schema unavailable");
  archivalClient ??= new SuiGraphQLClient({ network: "mainnet", url: "https://graphql.mainnet.sui.io/graphql" });
  return createPaidContinueService({
    pool,
    client: suiClient,
    archivalClient,
    enabled: paidContinuesEnabled(),
    ownershipChecker: ({ wallet }) => checkDirectNFTreeOwnership({ client: suiClient, wallet, network: "mainnet" })
  });
}
async function getGatewayServices(origin, database = getPreviewDatabase) {
  const { pool } = database();
  schemaReady ??= inspectTreeForceSchema(pool).then((result) => {
    if (!result.schemaReady) throw Error("Authentication schema unavailable");
  });
  await schemaReady;
  suiClient ??= new SuiGrpcClient({ network: "mainnet", baseUrl: "https://fullnode.mainnet.sui.io:443" });
  return {
    gateway: createWalletGatewayService({ pool, client: suiClient, origin }),
    runs: createGameRunService({ pool, ownershipChecker: ({ wallet }) => checkDirectNFTreeOwnership({ client: suiClient, wallet, network: "mainnet" }) })
  };
}
function createIntegratedGatewayHandler({ action, build: build2, services: services2 = getGatewayServices, requestAllowed = previewRequestAllowed }) {
  if (!["challenge", "enter", "logout", "restart"].includes(action)) throw Error("Unknown Gateway action");
  return async (request, context) => {
    const headers4 = { "Cache-Control": "no-store", "X-Robots-Tag": "noindex" };
    if (!requestAllowed(build2, context, request))
      return Response.json({ enabled: false, authorized: false }, { status: 503, headers: headers4 });
    const origin = new URL(request.url).origin;
    if (action === "challenge" || action === "enter") return createWalletGatewayHttpHandler({
      action,
      build: build2,
      getService: async () => (await services2(origin)).gateway
    })(request, context);
    if (action === "restart") return createGameRunHttpHandler({
      build: build2,
      getService: async () => (await services2(origin)).runs
    })(request, context);
    return createGameLogoutHttpHandler({ revoker: { revoke: async (input) => (await services2(origin)).gateway.revoke(input) } })(request);
  };
}

// netlify/canonical-development-functions/treeforce89-dev.mts
var build = { branch: "feature/treeforce89-play-integration", mode: "canonical-development" };
var headers3 = { "Cache-Control": "no-store", "X-Robots-Tag": "noindex" };
var services = (origin) => getGatewayServices(origin, getCanonicalDevelopmentDatabase);
var actions = { "tree-challenge": "challenge", "tree-session": "enter", "tree-logout": "logout", "tree-run": "restart" };
var handlers = Object.fromEntries(Object.entries(actions).map(([path, action]) => [
  path,
  createIntegratedGatewayHandler({ action, build, services, requestAllowed: canonicalDevelopmentRequestAllowed })
]));
async function handler(request, context) {
  if (!canonicalDevelopmentRequestAllowed(build, context, request))
    return Response.json({ enabled: false, authorized: false }, { status: 503, headers: headers3 });
  const path = new URL(request.url).pathname.slice("/play/treeforce89/api/".length);
  if (["tree-continue", "tree-continue-offer", "tree-continue-recover"].includes(path))
    return createPaidContinueHttpHandler({
      action: path === "tree-continue-offer" ? "offer" : "redeem",
      getService: () => getPaidContinueService(new URL(request.url).origin, getCanonicalDevelopmentDatabase)
    })(request);
  if (path === "status") {
    try {
      const { pool } = getCanonicalDevelopmentDatabase();
      const schema = await inspectTreeForceSchema(pool);
      const paymentSchemaReady = await paidContinueSchemaReady(pool);
      return Response.json({
        schemaReady: schema.schemaReady,
        tableCount: schema.tableCount,
        isolationVerified: true,
        paymentSchemaReady,
        paymentsEnabled: paymentSchemaReady && paidContinuesEnabled()
      }, { status: schema.schemaReady ? 200 : 503, headers: headers3 });
    } catch {
      return Response.json({ schemaReady: false, paymentsEnabled: false }, { status: 503, headers: headers3 });
    }
  }
  return Object.hasOwn(handlers, path) ? handlers[path](request, context) : Response.json({ error: "Not found" }, { status: 404, headers: headers3 });
}
var config = {
  path: "/play/treeforce89/api/*",
  rateLimit: { action: "rate_limit", aggregateBy: ["ip"], windowSize: 60, windowLimit: 60 }
};
export {
  config,
  handler as default
};
