
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// ../../../../tmp/tree-growth-function-4Z9Jba/netlify/lib/nftree-wallet-verification.ts
function normalizeSuiAddress(value) {
  const match = String(value || "").toLowerCase().match(/^0x([a-f0-9]{1,64})$/);
  return match ? `0x${match[1].padStart(64, "0")}` : null;
}
var init_nftree_wallet_verification = __esm({
  "../../../../tmp/tree-growth-function-4Z9Jba/netlify/lib/nftree-wallet-verification.ts"() {
  }
});

// ../../../../tmp/tree-growth-function-4Z9Jba/netlify/lib/tree-nftree-overview.ts
var NFTREE_PACKAGE_ID, NFTREE_TYPE;
var init_tree_nftree_overview = __esm({
  "../../../../tmp/tree-growth-function-4Z9Jba/netlify/lib/tree-nftree-overview.ts"() {
    NFTREE_PACKAGE_ID = "0xf6c6d439ea0da2f3e9ba79e4992a7a4c113215fbf54c442ac9020c315f953705";
    NFTREE_TYPE = `${NFTREE_PACKAGE_ID}::collection::NFT`;
  }
});

// ../../../../tmp/tree-growth-function-4Z9Jba/netlify/functions/nftree-wallet.ts
var nftree_wallet_exports = {};
__export(nftree_wallet_exports, {
  config: () => config,
  default: () => nftree_wallet_default,
  getCanonicalNftreeOwnership: () => getCanonicalNftreeOwnership
});
function response(body2, status = 200, cache = "no-store") {
  return Response.json(body2, { status, headers: { "Cache-Control": cache, "X-Content-Type-Options": "nosniff" } });
}
async function graphql(query, variables, signal) {
  const result = await fetch(GRAPHQL_URL, {
    method: "POST",
    signal,
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({ query, variables })
  });
  const payload = await result.json().catch(() => ({}));
  if (!result.ok || Array.isArray(payload.errors) && payload.errors.length) throw new Error("Sui GraphQL verification failed.");
  return payload.data;
}
async function getOwnedObjects(owner, type, signal) {
  const nodes = [];
  const ids = /* @__PURE__ */ new Set();
  let after = null;
  for (let pageNumber = 0; pageNumber < 100; pageNumber += 1) {
    const data = await graphql(OWNED_OBJECTS_QUERY, { first: 50, after, type, owner }, signal);
    const connection = data?.objects;
    if (!Array.isArray(connection?.nodes)) throw new Error("Owned object page was unavailable.");
    for (const node of connection.nodes) {
      const id = normalizeSuiAddress(node?.address);
      if (!id || ids.has(id)) throw new Error("Owned object identities were invalid.");
      ids.add(id);
      nodes.push(node);
    }
    if (connection.pageInfo?.hasNextPage !== true) return nodes;
    after = connection.pageInfo?.endCursor || null;
    if (!after) throw new Error("Owned object scan lacked a cursor.");
  }
  throw new Error("Owned object scan did not reach its end.");
}
async function getKioskItemIds(kiosk, signal) {
  const ids = /* @__PURE__ */ new Set();
  let after = null;
  for (let pageNumber = 0; pageNumber < 100; pageNumber += 1) {
    const data = await graphql(KIOSK_FIELDS_QUERY, { kiosk, first: 50, after }, signal);
    const fields = data?.object?.dynamicFields;
    if (!Array.isArray(fields?.nodes)) throw new Error("Kiosk contents were unavailable.");
    for (const node of fields.nodes) {
      if (!String(node?.name?.type?.repr || "").endsWith(KIOSK_ITEM_SUFFIX)) continue;
      const id = normalizeSuiAddress(node?.name?.json?.id);
      if (!id || ids.has(id)) throw new Error("Kiosk item identities were invalid.");
      ids.add(id);
    }
    if (fields.pageInfo?.hasNextPage !== true) return [...ids];
    after = fields.pageInfo?.endCursor || null;
    if (!after) throw new Error("Kiosk scan lacked a cursor.");
  }
  throw new Error("Kiosk scan did not reach its end.");
}
async function getObjectTypes(ids, signal) {
  const result = /* @__PURE__ */ new Map();
  const batches = [];
  for (let offset = 0; offset < ids.length; offset += 20) batches.push(ids.slice(offset, offset + 20));
  const responses = await Promise.all(batches.map(async (batch) => {
    const fields = batch.map((id, index) => `o${index}: object(address: "${id}") { asMoveObject { contents { type { repr } } } }`).join("\n");
    const data = await graphql(`query KioskItemTypes { ${fields} }`, {}, signal);
    return { batch, data };
  }));
  responses.forEach(({ batch, data }) => batch.forEach((id, index) => {
    const type = String(data?.[`o${index}`]?.asMoveObject?.contents?.type?.repr || "");
    if (!type) throw new Error("A Kiosk item type was unavailable.");
    result.set(id, type);
  }));
  return result;
}
async function getCanonicalNftreeOwnership(address2) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 26e3);
  try {
    const [directNftrees, ownerCaps] = await Promise.all([
      getOwnedObjects(address2, NFTREE_TYPE, controller.signal),
      getOwnedObjects(address2, KIOSK_OWNER_CAP_TYPE, controller.signal)
    ]);
    const kioskIds = ownerCaps.map((cap) => normalizeSuiAddress(cap.asMoveObject?.contents?.json?.for));
    if (kioskIds.some((id) => !id) || new Set(kioskIds).size !== kioskIds.length) throw new Error("Kiosk ownership capabilities were invalid.");
    const kioskItems = (await Promise.all(kioskIds.map((id) => getKioskItemIds(id, controller.signal)))).flat();
    if (new Set(kioskItems).size !== kioskItems.length) throw new Error("Kiosk item identities overlapped.");
    const itemTypes = await getObjectTypes(kioskItems, controller.signal);
    const kioskCount = kioskItems.filter((id) => itemTypes.get(id) === NFTREE_TYPE).length;
    const directCount = directNftrees.length;
    return {
      address: address2,
      network: "sui-mainnet",
      nftreeType: NFTREE_TYPE,
      methodology: "canonical-nftree-direct-and-kiosk-cap-v2",
      nftreeCount: directCount + kioskCount,
      directCount,
      kioskCount,
      kiosksScanned: kioskIds.length,
      kioskItemsScanned: kioskItems.length
    };
  } finally {
    clearTimeout(timeout);
  }
}
var GRAPHQL_URL, KIOSK_OWNER_CAP_TYPE, KIOSK_ITEM_SUFFIX, OWNED_OBJECTS_QUERY, KIOSK_FIELDS_QUERY, nftree_wallet_default, config;
var init_nftree_wallet = __esm({
  "../../../../tmp/tree-growth-function-4Z9Jba/netlify/functions/nftree-wallet.ts"() {
    init_tree_nftree_overview();
    init_nftree_wallet_verification();
    GRAPHQL_URL = "https://graphql.mainnet.sui.io/graphql";
    KIOSK_OWNER_CAP_TYPE = "0x2::kiosk::KioskOwnerCap";
    KIOSK_ITEM_SUFFIX = "::kiosk::Item";
    OWNED_OBJECTS_QUERY = `query OwnedObjects($first: Int!, $after: String, $type: String!, $owner: SuiAddress!) {
  objects(first: $first, after: $after, filter: { type: $type, owner: $owner }) {
    pageInfo { hasNextPage endCursor }
    nodes { address asMoveObject { contents { json } } }
  }
}`;
    KIOSK_FIELDS_QUERY = `query KioskFields($kiosk: SuiAddress!, $first: Int!, $after: String) {
  object(address: $kiosk) {
    dynamicFields(first: $first, after: $after) {
      pageInfo { hasNextPage endCursor }
      nodes { name { type { repr } json } }
    }
  }
}`;
    nftree_wallet_default = async (request) => {
      if (request.method !== "GET") return response({ status: "error", error: "method-not-allowed" }, 405);
      const address2 = normalizeSuiAddress(new URL(request.url).searchParams.get("address"));
      if (!address2) return response({ status: "error", error: "invalid-address" }, 400);
      try {
        const ownership2 = await getCanonicalNftreeOwnership(address2);
        return response({ status: "ok", ...ownership2 }, 200, "public, max-age=15, s-maxage=30, stale-while-revalidate=60");
      } catch (error) {
        console.error("NFTree wallet verification failed:", error);
        return response({ status: "error", error: "nftree-verification-unavailable" }, 503);
      }
    };
    config = { path: "/api/nftree-wallet" };
  }
});

// ../../../../tmp/tree-growth-function-4Z9Jba/netlify/functions/arcade-growth.ts
import { createHash, createHmac, randomBytes, randomUUID } from "node:crypto";

// ../../../../tmp/tree-growth-function-4Z9Jba/netlify/lib/arcade-growth-games.ts
init_nftree_wallet_verification();
var ARCADE_ENABLED_GAME_IDS = ["garden-bot", "pvp", "arborist-trials"];
var GARDEN_API_ORIGIN = "https://gardenbattles-production.up.railway.app";
var GARDEN_BOT_ADDRESS = "0xbbe518c2a2025d2d95b9e5b6435911771f64d7d9fe037fbf2ec661981890d5b4";
var HISTORY_LIMIT = 50;
var MAX_RESPONSE_BYTES = 128 * 1024;
var REQUEST_TIMEOUT_MS = 2e4;
var DAY_MS = 864e5;
var BASE58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
var BATTLE_VERSIONS = /* @__PURE__ */ new Set(["legacy", "pvp-v2", "pvp-v3", "bot-v2"]);
function record(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Invalid result document.");
  return value;
}
function address(value) {
  const normalized = typeof value === "string" ? normalizeSuiAddress(value) : null;
  if (!normalized || /^0x0{64}$/.test(normalized)) throw new Error("Invalid result identity.");
  return normalized;
}
function integer(value, minimum, maximum = Number.MAX_SAFE_INTEGER) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new Error("Invalid result number.");
  }
  return value;
}
function timestamp(value, context) {
  return integer(value, 1, context.now);
}
function transactionDigest(value) {
  if (typeof value !== "string" || !/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(value)) {
    throw new Error("Invalid transaction digest.");
  }
  let decoded = 0n;
  for (const character of value) decoded = decoded * 58n + BigInt(BASE58.indexOf(character));
  let bytes = 0;
  for (let rest = decoded; rest > 0n; rest >>= 8n) bytes += 1;
  bytes += /^1*/.exec(value)[0].length;
  if (bytes !== 32 || decoded === 0n) throw new Error("Invalid transaction digest.");
  return value;
}
function assertNoSourceError(document) {
  if (document.ok === false || document.error != null && document.error !== "") {
    throw new Error("Source reported an error.");
  }
}
async function readJson(path, fetchImpl) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response2 = await fetchImpl(`${GARDEN_API_ORIGIN}${path}`, {
      method: "GET",
      headers: { Accept: "application/json" },
      cache: "no-store",
      credentials: "omit",
      redirect: "error",
      signal: controller.signal
    });
    if (response2.status !== 200 || response2.redirected || !/^application\/json(?:\s*;|$)/i.test(response2.headers.get("content-type") || "")) {
      throw new Error("Source response was unavailable.");
    }
    const length = response2.headers.get("content-length");
    if (length !== null && (!/^\d+$/.test(length) || Number(length) > MAX_RESPONSE_BYTES)) {
      throw new Error("Source response exceeded its limit.");
    }
    if (!response2.body) throw new Error("Source response was empty.");
    const reader = response2.body.getReader();
    const chunks = [];
    let size = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > MAX_RESPONSE_BYTES) {
          await reader.cancel();
          throw new Error("Source response exceeded its limit.");
        }
        chunks.push(value);
      }
    } finally {
      reader.releaseLock();
    }
    const bytes = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.byteLength;
    }
    const document = record(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes)));
    assertNoSourceError(document);
    return document;
  } finally {
    clearTimeout(timeout);
    controller.abort();
  }
}
function statuses(gameIds, events) {
  return gameIds.map((gameId) => ({
    gameId,
    status: events.some((event) => event.gameId === gameId) ? "verified" : "no-result",
    message: events.some((event) => event.gameId === gameId) ? "A completed result for this UTC day was verified." : "No completed result is available for this UTC day yet."
  }));
}
function sourceFailure(gameIds) {
  return {
    events: [],
    games: gameIds.map((gameId) => ({
      gameId,
      status: "unavailable",
      message: "Completed results could not be verified. Previously saved progress is unchanged; try syncing again."
    }))
  };
}
async function syncBattles(context, fetchImpl) {
  const modes = ["garden-bot", "pvp"];
  try {
    const document = await readJson(`/api/player/${context.wallet}/battles?limit=${HISTORY_LIMIT}`, fetchImpl);
    if (!Array.isArray(document.battles) || document.battles.length > HISTORY_LIMIT) {
      throw new Error("Invalid battle history.");
    }
    const reportedPartial = document.truncated === true || document.hasMore === true || document.hasNextPage === true || document.complete === false;
    const events = /* @__PURE__ */ new Map();
    const digestBattles = /* @__PURE__ */ new Map();
    let previousTime = context.now;
    for (const value of document.battles) {
      const row = record(value);
      const finishedAt = timestamp(row.finished_at, context);
      if (finishedAt > previousTime) throw new Error("Battle history was not ordered.");
      previousTime = finishedAt;
      const player1 = address(row.player1);
      const player2 = address(row.player2);
      if (player1 === player2 || player1 !== context.wallet && player2 !== context.wallet) {
        throw new Error("Battle history did not belong to this wallet.");
      }
      if (finishedAt < context.start) continue;
      if (finishedAt >= context.end) throw new Error("Result belongs to another UTC day.");
      const battleId = address(row.battle_id);
      if (row.is_bot_battle !== 0 && row.is_bot_battle !== 1) throw new Error("Battle mode was unavailable.");
      if (typeof row.battle_version !== "string" || !BATTLE_VERSIONS.has(row.battle_version)) {
        throw new Error("Battle version was unavailable.");
      }
      const bot = row.is_bot_battle === 1;
      if (bot ? player1 !== context.wallet || player1 === GARDEN_BOT_ADDRESS || player2 !== GARDEN_BOT_ADDRESS || row.battle_version.startsWith("pvp-") : player1 === GARDEN_BOT_ADDRESS || player2 === GARDEN_BOT_ADDRESS || row.battle_version === "bot-v2") {
        throw new Error("Battle mode contradicted its participants.");
      }
      if (row.winner === null) continue;
      const winner = address(row.winner);
      if (winner !== player1 && winner !== player2) throw new Error("Battle outcome was invalid.");
      const digest = transactionDigest(row.transaction_digest);
      const priorBattle = digestBattles.get(digest);
      if (priorBattle && priorBattle !== battleId) throw new Error("Transaction identity was reused.");
      digestBattles.set(digest, battleId);
      const event = {
        source: "garden-battles",
        sourceId: `battle:${battleId}:${context.wallet}`,
        gameId: bot ? "garden-bot" : "pvp",
        wallet: context.wallet,
        completedAt: new Date(finishedAt).toISOString(),
        proofDigest: digest
      };
      const prior = events.get(battleId);
      if (prior && JSON.stringify(prior) !== JSON.stringify(event)) throw new Error("Battle identity conflicted.");
      events.set(battleId, event);
    }
    const completed = [...events.values()];
    if (reportedPartial || document.battles.length === HISTORY_LIMIT && previousTime >= context.start) {
      return { events: completed, games: modes.map((gameId) => ({
        gameId,
        status: "partial",
        message: completed.some((event) => event.gameId === gameId) ? "Completed results were verified, but recent history may omit other results. Previously saved progress is unchanged." : "Recent history does not cover the full UTC day, so missing results cannot be ruled out. Previously saved progress is unchanged."
      })) };
    }
    return { events: completed, games: statuses(modes, completed) };
  } catch {
    return sourceFailure(modes);
  }
}
async function syncTrial(context, fetchImpl) {
  const modes = ["arborist-trials"];
  try {
    const document = await readJson(`/api/arborist-trials/today?wallet=${context.wallet}`, fetchImpl);
    const challenge2 = record(document.challenge);
    if (challenge2.date !== context.dateKey || typeof challenge2.id !== "string" || !/^arborist-trial-v[1-9]\d{0,2}-\d{4}-\d{2}-\d{2}$/.test(challenge2.id) || !challenge2.id.endsWith(`-${context.dateKey}`) || typeof document.rankedAttemptUsed !== "boolean") {
      throw new Error("Daily Trial identity was unavailable or stale.");
    }
    if (document.result === null && document.rankedAttemptUsed === false) {
      return { events: [], games: statuses(modes, []) };
    }
    const result = record(document.result);
    if (document.rankedAttemptUsed !== true || address(result.wallet) !== context.wallet || typeof result.won !== "boolean") {
      throw new Error("Official Trial result did not belong to this wallet.");
    }
    integer(result.rounds, 1, 100);
    integer(result.score, 0);
    integer(result.uniqueMoves, 1, 5);
    integer(result.playerGrowth, 0);
    integer(result.botGrowth, 0);
    const completedAt = timestamp(result.completedAt, context);
    if (completedAt < context.start || completedAt >= context.end) throw new Error("Trial was saved on another UTC day.");
    const event = {
      source: "garden-battles",
      sourceId: `trial:${challenge2.id}:${context.wallet}`,
      gameId: "arborist-trials",
      wallet: context.wallet,
      completedAt: new Date(completedAt).toISOString()
    };
    return { events: [event], games: statuses(modes, [event]) };
  } catch {
    return sourceFailure(modes);
  }
}
async function syncGardenParticipation({
  wallet: walletInput,
  dateKey,
  fetchImpl = fetch,
  now = /* @__PURE__ */ new Date()
}) {
  const wallet = address(walletInput);
  const nowMs = now instanceof Date ? now.getTime() : NaN;
  if (!Number.isSafeInteger(nowMs) || nowMs <= 0 || typeof dateKey !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(dateKey) || dateKey !== new Date(nowMs).toISOString().slice(0, 10)) {
    throw new Error("Only the current server UTC day can be synchronized.");
  }
  const start = Date.parse(`${dateKey}T00:00:00.000Z`);
  const context = { wallet, dateKey, start, end: start + DAY_MS, now: nowMs };
  const [battles, trial] = await Promise.all([syncBattles(context, fetchImpl), syncTrial(context, fetchImpl)]);
  return { events: [...battles.events, ...trial.events], games: [...battles.games, ...trial.games], checkedAt: now.toISOString() };
}

// ../../../../tmp/tree-growth-function-4Z9Jba/netlify/lib/arcade-growth-core.ts
var ARCADE_GROWTH_VERSION = "arcade-growth-v1";
var ARCADE_GROWTH_CHALLENGE_MS = 5 * 6e4;
var ARCADE_GROWTH_SESSION_MS = 60 * 6e4;
var ARCADE_GROWTH_ORIGINS = ["https://tree-token.xyz", "https://www.tree-token.xyz"];
var ARCADE_GROWTH_MILESTONES = [
  { id: "seedling", label: "Seedling", target: 3 },
  { id: "sapling", label: "Sapling", target: 7 },
  { id: "deep-roots", label: "Deep Roots", target: 14 },
  { id: "full-canopy", label: "Full Canopy", target: 21 }
];
var GAME_DETAILS = {
  "garden-bot": { id: "garden-bot", label: "Garden Bot", href: "https://nftree.net/battle/garden-bot" },
  pvp: { id: "pvp", label: "PvP Battle", href: "https://nftree.net/battle/pvp" },
  "arborist-trials": { id: "arborist-trials", label: "Arborist Trials", href: "https://nftree.net/battle/trials" }
};
var ArcadeGrowthError = class extends Error {
  code;
  status;
  constructor(code, message, status = 400) {
    super(message);
    this.name = "ArcadeGrowthError";
    this.code = code;
    this.status = status;
  }
};
function growthWallet(value) {
  if (typeof value !== "string" || !/^0x[0-9a-f]{64}$/i.test(value) || /^0x0{64}$/i.test(value)) {
    throw new ArcadeGrowthError("invalid-wallet", "Choose a valid Sui wallet.");
  }
  return value.toLowerCase();
}
function growthDateKey(now) {
  if (!Number.isFinite(now.getTime())) throw new ArcadeGrowthError("service-unavailable", "The server clock is unavailable.", 503);
  return now.toISOString().slice(0, 10);
}
function growthEnabledGames(value) {
  if (!Array.isArray(value) || value.length < 1 || value.length > ARCADE_ENABLED_GAME_IDS.length || value.some((id) => !ARCADE_ENABLED_GAME_IDS.includes(id)) || new Set(value).size !== value.length) {
    throw new ArcadeGrowthError("service-unavailable", "The saved monthly game rules could not be verified.", 503);
  }
  return [...value];
}
function growthConfiguration(enabled, now) {
  const ids = growthEnabledGames(enabled);
  const ordinal = Math.floor(Date.parse(`${growthDateKey(now)}T00:00:00.000Z`) / 864e5);
  const soloIds = ids.filter((id) => id === "garden-bot" || id === "arborist-trials");
  if (!soloIds.length) throw new ArcadeGrowthError("service-unavailable", "Today\u2019s solo game selection is unavailable.", 503);
  return {
    ruleVersion: ARCADE_GROWTH_VERSION,
    enabledGames: ids.map((id) => GAME_DETAILS[id]),
    todayPick: GAME_DETAILS[soloIds[ordinal % soloIds.length]],
    questRule: "Complete any eligible official game result; a win is not required.",
    resetAt: new Date(Date.parse(`${growthDateKey(now)}T00:00:00.000Z`) + 864e5).toISOString()
  };
}
function growthChallengeMessage(input) {
  if (!ARCADE_GROWTH_ORIGINS.includes(input.origin)) {
    throw new ArcadeGrowthError("origin-not-allowed", "Sign in from the official TREE Arcade website.", 403);
  }
  return [
    "TREE Arcade Daily Growth",
    "Action: Sign in to save check-ins and verified game participation",
    `Domain: ${new URL(input.origin).host}`,
    `URI: ${input.origin}/play/`,
    "Network: sui:mainnet",
    `Wallet: ${growthWallet(input.wallet)}`,
    `UTC date: ${growthDateKey(input.now)}`,
    `Challenge: ${input.challengeId}`,
    `Nonce: ${input.nonce}`,
    `Issued at: ${input.now.toISOString()}`,
    `Expires: ${input.expiresAt}`,
    "This signature does not authorize a transaction, token approval, payment, or reward claim."
  ].join("\n");
}
function validateGrowthEvents(events, wallet, dateKey, now) {
  if (!Array.isArray(events) || events.length > 100) throw new ArcadeGrowthError("verification-unavailable", "Game results could not be verified.", 503);
  const seen = /* @__PURE__ */ new Set();
  return events.map((event) => {
    if (!event || typeof event !== "object" || event.source !== "garden-battles" || typeof event.sourceId !== "string" || event.sourceId.length < 3 || event.sourceId.length > 200 || !/^[a-zA-Z0-9:_-]+$/.test(event.sourceId) || event.wallet !== wallet || !ARCADE_ENABLED_GAME_IDS.includes(event.gameId)) {
      throw new ArcadeGrowthError("verification-unavailable", "A game result identity could not be verified.", 503);
    }
    const completedAt = typeof event.completedAt === "string" ? Date.parse(event.completedAt) : NaN;
    if (!Number.isFinite(completedAt) || completedAt > now.getTime() || new Date(completedAt).toISOString().slice(0, 10) !== dateKey || event.proofDigest !== void 0 && (typeof event.proofDigest !== "string" || !/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(event.proofDigest))) {
      throw new ArcadeGrowthError("verification-unavailable", "A game result date or proof could not be verified.", 503);
    }
    const key = `${event.source}:${event.sourceId}`;
    if (seen.has(key)) throw new ArcadeGrowthError("verification-unavailable", "Game results contained a duplicate identity.", 503);
    seen.add(key);
    return {
      source: event.source,
      sourceId: event.sourceId,
      gameId: event.gameId,
      wallet,
      completedAt: new Date(completedAt).toISOString(),
      ...event.proofDigest ? { proofDigest: event.proofDigest } : {}
    };
  });
}
function buildGrowthProgress(snapshot) {
  const wallet = growthWallet(snapshot.wallet);
  const date = /* @__PURE__ */ new Date(`${snapshot.dateKey}T00:00:00.000Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(snapshot.dateKey) || growthDateKey(date) !== snapshot.dateKey || snapshot.monthKey !== snapshot.dateKey.slice(0, 7)) {
    throw new ArcadeGrowthError("service-unavailable", "The saved progress date could not be verified.", 503);
  }
  const enabledGames = growthEnabledGames(snapshot.enabledGames);
  const validDay = (value) => typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value) && value.slice(0, 7) === snapshot.monthKey && value <= snapshot.dateKey && Number.isFinite(Date.parse(`${value}T00:00:00.000Z`)) && (/* @__PURE__ */ new Date(`${value}T00:00:00.000Z`)).toISOString().slice(0, 10) === value;
  if (!Array.isArray(snapshot.checkins) || snapshot.checkins.some((day) => !validDay(day)) || new Set(snapshot.checkins).size !== snapshot.checkins.length || !Array.isArray(snapshot.quests) || snapshot.quests.some((item) => !item || !validDay(item.dateKey) || !enabledGames.includes(item.gameId)) || new Set(snapshot.quests.map((item) => item.dateKey)).size !== snapshot.quests.length || !Array.isArray(snapshot.gamesByDay) || snapshot.gamesByDay.some((item) => !item || !validDay(item.dateKey) || !Array.isArray(item.gameIds) || item.gameIds.length === 0 || new Set(item.gameIds).size !== item.gameIds.length || item.gameIds.some((id) => !enabledGames.includes(id))) || new Set(snapshot.gamesByDay.map((item) => item.dateKey)).size !== snapshot.gamesByDay.length || !Array.isArray(snapshot.badges)) {
    throw new ArcadeGrowthError("service-unavailable", "Saved progress could not be verified.", 503);
  }
  const checked = new Set(snapshot.checkins);
  const quests = new Set(snapshot.quests.map((item) => item.dateKey));
  if ([...quests].some((day) => !checked.has(day))) throw new ArcadeGrowthError("service-unavailable", "Saved quest attendance is inconsistent.", 503);
  const games = new Map(snapshot.gamesByDay.map((item) => [item.dateKey, [...new Set(item.gameIds)]]));
  if ([...games.keys()].some((day) => !checked.has(day) || !quests.has(day)) || snapshot.quests.some((quest) => !games.get(quest.dateKey)?.includes(quest.gameId))) {
    throw new ArcadeGrowthError("service-unavailable", "Saved game and quest progress is inconsistent.", 503);
  }
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth();
  const calendar = Array.from({ length: new Date(Date.UTC(year, month + 1, 0)).getUTCDate() }, (_, index) => {
    const dateKey = new Date(Date.UTC(year, month, index + 1)).toISOString().slice(0, 10);
    return { dateKey, checkedIn: checked.has(dateKey), questCompleted: quests.has(dateKey), gameIds: games.get(dateKey) || [] };
  });
  const completedGameIds = enabledGames.filter((id) => [...games.values()].some((ids) => ids.includes(id)));
  const badgeLabels = new Map([...ARCADE_GROWTH_MILESTONES.map((item) => [item.id, item.label]), ["arcade-passport", "Arcade Passport"]]);
  const badges = snapshot.badges.map((badge) => {
    if (!badge || !badgeLabels.has(badge.id) || !/^\d{4}-(?:0[1-9]|1[0-2])$/.test(badge.monthKey) || badge.monthKey > snapshot.monthKey || !Number.isFinite(Date.parse(badge.earnedAt))) throw new ArcadeGrowthError("service-unavailable", "Saved badges could not be verified.", 503);
    return { ...badge, label: badgeLabels.get(badge.id) };
  });
  const today = calendar.find((day) => day.dateKey === snapshot.dateKey);
  return {
    wallet,
    monthKey: snapshot.monthKey,
    dateKey: snapshot.dateKey,
    calendar,
    checkedInDays: checked.size,
    questDays: quests.size,
    today: { checkedIn: today.checkedIn, questCompleted: today.questCompleted, gameIds: today.gameIds },
    passport: {
      monthKey: snapshot.monthKey,
      enabledGames: enabledGames.map((id) => GAME_DETAILS[id]),
      completedGameIds,
      complete: enabledGames.every((id) => completedGameIds.includes(id))
    },
    milestones: ARCADE_GROWTH_MILESTONES.map((item) => ({ ...item, earned: checked.size >= item.target })),
    badges
  };
}

// ../../../../tmp/tree-growth-function-4Z9Jba/netlify/lib/arcade-growth-store.ts
function arcadeGrowthSupabaseConfig(env) {
  const prefixes = ["ARCADE_GROWTH", "TREE_RAFFLE", "TREE_KNOWLEDGE_TRIAL"];
  for (const prefix of prefixes) {
    const url = env[`${prefix}_SUPABASE_URL`];
    const secretKey = env[`${prefix}_SUPABASE_SECRET_KEY`];
    if (!url && !secretKey) continue;
    if (!url || !secretKey) throw new ArcadeGrowthError("service-unavailable", "Daily Growth storage is not configured.", 503);
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      throw new ArcadeGrowthError("service-unavailable", "Daily Growth storage is not configured.", 503);
    }
    if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.pathname !== "/" || parsed.search || parsed.hash) {
      throw new ArcadeGrowthError("service-unavailable", "Daily Growth storage is not configured.", 503);
    }
    return { url: parsed.origin, secretKey };
  }
  throw new ArcadeGrowthError("service-unavailable", "Daily Growth storage is not configured.", 503);
}
var record2 = (value) => {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new ArcadeGrowthError("service-unavailable", "The progress service returned an invalid response.", 503);
  return value;
};
var text = (value) => {
  if (typeof value !== "string" || !value) throw new ArcadeGrowthError("service-unavailable", "The progress service returned an invalid response.", 503);
  return value;
};
function challenge(value) {
  const row = record2(value);
  if (typeof row.consumed !== "boolean") throw new ArcadeGrowthError("service-unavailable", "The sign-in challenge could not be read.", 503);
  return {
    challengeId: text(row.challengeId),
    wallet: growthWallet(row.wallet),
    origin: text(row.origin),
    dateKey: text(row.dateKey),
    message: text(row.message),
    expiresAt: text(row.expiresAt),
    consumed: row.consumed
  };
}
function session(value) {
  const row = record2(value);
  if (typeof row.revoked !== "boolean") throw new ArcadeGrowthError("service-unavailable", "The sign-in session could not be read.", 503);
  return { wallet: growthWallet(row.wallet), origin: text(row.origin), expiresAt: text(row.expiresAt), revoked: row.revoked };
}
var STORE_ERRORS = {
  "arcade-growth-rate-limited": ["rate-limited", "Too many sign-in requests. Please wait a few minutes.", 429],
  "arcade-growth-invalid-challenge": ["expired-challenge", "This sign-in request expired or was already used. Sign in again.", 401],
  "arcade-growth-invalid-session": ["invalid-session", "Your Daily Growth session expired. Sign in again.", 401],
  "arcade-growth-day-changed": ["utc-day-changed", "The UTC day changed. Refresh and try again.", 409],
  "arcade-growth-event-conflict": ["verification-unavailable", "A saved game result could not be reconciled.", 503]
};
var SupabaseArcadeGrowthStore = class {
  connection;
  fetchImpl;
  constructor(connection, fetchImpl = fetch) {
    this.connection = connection;
    this.fetchImpl = fetchImpl;
  }
  async rpc(name, body2) {
    try {
      const response2 = await this.fetchImpl(`${this.connection.url}/rest/v1/rpc/${name}`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.connection.secretKey}`,
          apikey: this.connection.secretKey,
          "X-Client-Info": "tree-arcade-growth/1"
        },
        body: JSON.stringify(body2),
        signal: AbortSignal.timeout(8e3)
      });
      const payload = await response2.json().catch(() => null);
      if (!response2.ok) {
        const message = payload && typeof payload === "object" ? String(payload.message || "") : "";
        const mapped = STORE_ERRORS[message];
        if (mapped) throw new ArcadeGrowthError(...mapped);
        throw new ArcadeGrowthError("service-unavailable", "Daily Growth storage is temporarily unavailable.", 503);
      }
      return payload;
    } catch (error) {
      if (error instanceof ArcadeGrowthError) throw error;
      throw new ArcadeGrowthError("service-unavailable", "Daily Growth storage is temporarily unavailable.", 503);
    }
  }
  async publicRules(enabledGames) {
    return growthEnabledGames(await this.rpc("arcade_growth_public_rules_v1", { p_enabled_games: enabledGames }));
  }
  async createChallenge(input) {
    return challenge(await this.rpc("arcade_growth_create_challenge_v1", {
      p_challenge_id: input.challengeId,
      p_wallet: input.wallet,
      p_origin: input.origin,
      p_date_key: input.dateKey,
      p_nonce_sha256: input.nonceSha256,
      p_message: input.message,
      p_expires_at: input.expiresAt,
      p_request_fingerprint: input.requestFingerprint
    }));
  }
  async readChallenge(challengeId) {
    return challenge(await this.rpc("arcade_growth_read_challenge_v1", { p_challenge_id: challengeId }));
  }
  async createSession(input) {
    return session(await this.rpc("arcade_growth_create_session_v1", {
      p_challenge_id: input.challengeId,
      p_wallet: input.wallet,
      p_origin: input.origin,
      p_token_sha256: input.tokenSha256,
      p_expires_at: input.expiresAt
    }));
  }
  async readSession(tokenSha256, origin) {
    return session(await this.rpc("arcade_growth_read_session_v1", { p_token_sha256: tokenSha256, p_origin: origin }));
  }
  async revokeSession(tokenSha256, origin) {
    await this.rpc("arcade_growth_revoke_session_v1", { p_token_sha256: tokenSha256, p_origin: origin });
  }
  async snapshot(tokenSha256, origin, enabledGames) {
    return record2(await this.rpc("arcade_growth_snapshot_v1", { p_token_sha256: tokenSha256, p_origin: origin, p_enabled_games: enabledGames }));
  }
  async checkIn(tokenSha256, origin, enabledGames) {
    return record2(await this.rpc("arcade_growth_check_in_v1", { p_token_sha256: tokenSha256, p_origin: origin, p_enabled_games: enabledGames }));
  }
  async recordEvents(tokenSha256, origin, enabledGames, dateKey, events) {
    return record2(await this.rpc("arcade_growth_record_events_v1", {
      p_token_sha256: tokenSha256,
      p_origin: origin,
      p_enabled_games: enabledGames,
      p_date_key: dateKey,
      p_events: events
    }));
  }
};
function configuredArcadeGrowthStore(env, fetchImpl = fetch) {
  return new SupabaseArcadeGrowthStore(arcadeGrowthSupabaseConfig(env), fetchImpl);
}

// ../../../../tmp/tree-growth-function-4Z9Jba/netlify/functions/arcade-growth.ts
var ENV_KEYS = [
  "ARCADE_GROWTH_ENABLED",
  "ARCADE_GROWTH_RATE_LIMIT_SECRET",
  "TREE_KNOWLEDGE_TRIAL_RATE_LIMIT_SECRET",
  ...["ARCADE_GROWTH", "TREE_RAFFLE", "TREE_KNOWLEDGE_TRIAL"].flatMap((key) => [`${key}_SUPABASE_URL`, `${key}_SUPABASE_SECRET_KEY`])
];
var RELEASE_ENABLED_BY_DEFAULT = true;
var sha256 = (value) => createHash("sha256").update(value).digest("hex");
function environment() {
  const netlify = globalThis.Netlify;
  return Object.fromEntries(ENV_KEYS.map((key) => [key, netlify?.env.get(key) ?? process.env[key]]));
}
function json(body2, status = 200) {
  return new Response(JSON.stringify(body2), { status, headers: {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Netlify-CDN-Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  } });
}
function productionOrigin(request) {
  const origin = request.headers.get("origin") || new URL(request.url).origin;
  if (!ARCADE_GROWTH_ORIGINS.includes(origin)) {
    throw new ArcadeGrowthError("origin-not-allowed", "Use Daily Growth from the official TREE Arcade website.", 403);
  }
  return origin;
}
async function body(request, allowed) {
  if (!(request.headers.get("content-type") || "").toLowerCase().startsWith("application/json")) {
    throw new ArcadeGrowthError("invalid-request", "Send a JSON request.");
  }
  const declared = Number(request.headers.get("content-length") || 0);
  if (declared > 16384) throw new ArcadeGrowthError("invalid-request", "This request is too large.", 413);
  const reader = request.body?.getReader();
  let length = 0;
  const chunks = [];
  if (reader) {
    while (true) {
      const { value: value2, done } = await reader.read();
      if (done) break;
      length += value2.byteLength;
      if (length > 16384) {
        await reader.cancel();
        throw new ArcadeGrowthError("invalid-request", "This request is too large.", 413);
      }
      chunks.push(value2);
    }
  }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  let value;
  try {
    value = JSON.parse(new TextDecoder().decode(bytes));
  } catch {
    throw new ArcadeGrowthError("invalid-request", "This request is not valid JSON.");
  }
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((key) => !allowed.includes(key))) {
    throw new ArcadeGrowthError("invalid-request", "This request contains unsupported fields.");
  }
  return value;
}
function tokenHash(request) {
  const header = request.headers.get("authorization");
  if (!header) throw new ArcadeGrowthError("authentication-required", "Sign in to save Daily Growth progress.", 401);
  const match = /^Bearer ([0-9a-f]{64})$/.exec(header);
  if (!match) throw new ArcadeGrowthError("invalid-session", "Your Daily Growth session is invalid. Sign in again.", 401);
  return sha256(match[1]);
}
async function verifySignature(message, signature, wallet) {
  const [{ isValidPersonalMessageSignature }, { SuiGrpcClient }] = await Promise.all([
    import("@mysten/sui/verify"),
    import("@mysten/sui/grpc")
  ]);
  const client = new SuiGrpcClient({ network: "mainnet", baseUrl: "https://fullnode.mainnet.sui.io:443" });
  const verifyZkLogin = client.core.verifyZkLoginSignature.bind(client.core);
  client.core.verifyZkLoginSignature = (options) => verifyZkLogin({ ...options, signal: AbortSignal.timeout(12e3) });
  return isValidPersonalMessageSignature(message, signature, { address: wallet, client });
}
async function ownership(wallet) {
  const { getCanonicalNftreeOwnership: getCanonicalNftreeOwnership2 } = await Promise.resolve().then(() => (init_nftree_wallet(), nftree_wallet_exports));
  return getCanonicalNftreeOwnership2(wallet);
}
function createArcadeGrowthHandler(dependencies = {}) {
  const now = dependencies.now || (() => /* @__PURE__ */ new Date());
  const randomToken = dependencies.randomToken || (() => randomBytes(32).toString("hex"));
  return async (request, context = {}) => {
    try {
      const env = dependencies.env || environment();
      const action = new URL(request.url).searchParams.get("action") || "status";
      if (action === "status" && request.method !== "GET" || action !== "status" && request.method !== "POST") {
        throw new ArcadeGrowthError("method-not-allowed", "This action does not support that request method.", 405);
      }
      if (!["status", "challenge", "session", "check-in", "sync", "logout"].includes(action)) {
        throw new ArcadeGrowthError("invalid-request", "Unknown Daily Growth action.", 404);
      }
      const enabled = env.ARCADE_GROWTH_ENABLED === void 0 ? RELEASE_ENABLED_BY_DEFAULT : env.ARCADE_GROWTH_ENABLED === "true";
      if (!enabled) throw new ArcadeGrowthError("service-unavailable", "Daily Growth is not available yet.", 503);
      const store = dependencies.store || configuredArcadeGrowthStore(env);
      const origin = action === "status" && !request.headers.has("authorization") ? null : productionOrigin(request);
      const envelope = (snapshot2) => {
        const time = now();
        if (snapshot2 && snapshot2.dateKey !== growthDateKey(time)) throw new ArcadeGrowthError("utc-day-changed", "The UTC day changed. Refresh and try again.", 409);
        return {
          status: "ok",
          serverTime: time.toISOString(),
          dateKey: growthDateKey(time),
          monthKey: growthDateKey(time).slice(0, 7),
          authenticated: !!snapshot2,
          ...snapshot2 ? { configuration: growthConfiguration(snapshot2.enabledGames, time), progress: buildGrowthProgress(snapshot2) } : {}
        };
      };
      const requireOwnership = async (wallet2) => {
        let result;
        try {
          result = await (dependencies.ownership || ownership)(wallet2);
        } catch {
          throw new ArcadeGrowthError("ownership-unavailable", "NFTree ownership could not be checked. Please try again.", 503);
        }
        if (result.address !== wallet2 || result.network !== "sui-mainnet" || !Number.isSafeInteger(result.nftreeCount) || result.nftreeCount < 0) {
          throw new ArcadeGrowthError("ownership-unavailable", "NFTree ownership could not be verified. Please try again.", 503);
        }
        if (result.nftreeCount < 1) throw new ArcadeGrowthError("nftree-required", "Hold an NFTree in this wallet or its owned Kiosk to save Daily Growth progress.", 403);
      };
      const authenticate = async () => {
        const hash2 = tokenHash(request);
        const session2 = await store.readSession(hash2, origin);
        if (session2.revoked || session2.origin !== origin || !Number.isFinite(Date.parse(session2.expiresAt)) || Date.parse(session2.expiresAt) <= now().getTime()) {
          throw new ArcadeGrowthError("invalid-session", "Your Daily Growth session expired. Sign in again.", 401);
        }
        return { hash: hash2, wallet: growthWallet(session2.wallet) };
      };
      if (action === "status") {
        if (!request.headers.has("authorization")) {
          const enabled2 = await store.publicRules(ARCADE_ENABLED_GAME_IDS);
          return json({ ...envelope(), configuration: growthConfiguration(enabled2, now()) });
        }
        const { hash: hash2, wallet: wallet2 } = await authenticate();
        const snapshot2 = await store.snapshot(hash2, origin, ARCADE_ENABLED_GAME_IDS);
        if (snapshot2.wallet !== wallet2) throw new ArcadeGrowthError("service-unavailable", "Saved progress identity could not be verified.", 503);
        return json(envelope(snapshot2));
      }
      if (action === "challenge") {
        const data = await body(request, ["wallet"]);
        const wallet2 = growthWallet(data.wallet);
        const secret = env.ARCADE_GROWTH_RATE_LIMIT_SECRET || env.TREE_KNOWLEDGE_TRIAL_RATE_LIMIT_SECRET;
        if (!secret || secret.length < 32 || typeof context.ip !== "string" || !context.ip || context.ip.length > 128) {
          throw new ArcadeGrowthError("service-unavailable", "Secure sign-in is temporarily unavailable.", 503);
        }
        const time = now();
        const expiresAt = new Date(time.getTime() + ARCADE_GROWTH_CHALLENGE_MS).toISOString();
        const challengeId = (dependencies.randomId || randomUUID)();
        const nonce = randomToken();
        const message = growthChallengeMessage({ wallet: wallet2, origin, challengeId, nonce, now: time, expiresAt });
        const challenge2 = await store.createChallenge({
          challengeId,
          wallet: wallet2,
          origin,
          dateKey: growthDateKey(time),
          nonceSha256: sha256(nonce),
          message,
          expiresAt,
          requestFingerprint: createHmac("sha256", secret).update(`arcade-growth-v1:challenge:${context.ip}`).digest("hex")
        });
        if (challenge2.challengeId !== challengeId || challenge2.wallet !== wallet2 || challenge2.origin !== origin || challenge2.message !== message || challenge2.consumed) {
          throw new ArcadeGrowthError("service-unavailable", "The sign-in challenge could not be verified.", 503);
        }
        return json({ status: "ok", challenge: { challengeId, wallet: wallet2, message, expiresAt: challenge2.expiresAt, dateKey: challenge2.dateKey } });
      }
      if (action === "session") {
        const data = await body(request, ["wallet", "challengeId", "signature"]);
        const wallet2 = growthWallet(data.wallet);
        if (typeof data.challengeId !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(data.challengeId) || typeof data.signature !== "string" || data.signature.length < 40 || data.signature.length > 12e3 || !/^[A-Za-z0-9+/]+={0,2}$/.test(data.signature)) {
          throw new ArcadeGrowthError("invalid-signature", "The wallet sign-in response could not be verified.", 401);
        }
        const challenge2 = await store.readChallenge(data.challengeId);
        if (challenge2.challengeId !== data.challengeId || challenge2.wallet !== wallet2 || challenge2.origin !== origin || challenge2.consumed || challenge2.dateKey !== growthDateKey(now()) || !Number.isFinite(Date.parse(challenge2.expiresAt)) || Date.parse(challenge2.expiresAt) <= now().getTime()) {
          throw new ArcadeGrowthError("expired-challenge", "This sign-in request expired or was already used. Sign in again.", 401);
        }
        const verify = async () => {
          let valid;
          try {
            valid = await (dependencies.verifySignature || verifySignature)(new TextEncoder().encode(challenge2.message), data.signature, wallet2);
          } catch {
            throw new ArcadeGrowthError("verification-unavailable", "Wallet signature verification is temporarily unavailable. Please try again.", 503);
          }
          if (!valid) throw new ArcadeGrowthError("invalid-signature", "The signature does not match this wallet and sign-in message.", 401);
        };
        await Promise.all([verify(), requireOwnership(wallet2)]);
        const token = randomToken();
        const expiresAt = new Date(now().getTime() + ARCADE_GROWTH_SESSION_MS).toISOString();
        const session2 = await store.createSession({ challengeId: data.challengeId, wallet: wallet2, origin, tokenSha256: sha256(token), expiresAt });
        if (session2.wallet !== wallet2 || session2.origin !== origin || session2.revoked) throw new ArcadeGrowthError("service-unavailable", "The sign-in session could not be verified.", 503);
        const snapshot2 = await store.snapshot(sha256(token), origin, ARCADE_ENABLED_GAME_IDS);
        if (snapshot2.wallet !== wallet2) throw new ArcadeGrowthError("service-unavailable", "Saved progress identity could not be verified.", 503);
        return json({ ...envelope(snapshot2), session: { token, wallet: wallet2, expiresAt: session2.expiresAt } });
      }
      await body(request, []);
      const { hash, wallet } = await authenticate();
      if (action === "logout") {
        await store.revokeSession(hash, origin);
        return json({ status: "ok", authenticated: false });
      }
      let snapshot;
      let sync;
      if (action === "check-in") {
        await requireOwnership(wallet);
        snapshot = await store.checkIn(hash, origin, ARCADE_ENABLED_GAME_IDS);
      } else {
        const time = now();
        const dateKey = growthDateKey(time);
        [, sync] = await Promise.all([requireOwnership(wallet), (dependencies.syncGames || syncGardenParticipation)({ wallet, dateKey, now: time })]);
        if (growthDateKey(now()) !== dateKey) throw new ArcadeGrowthError("utc-day-changed", "The UTC day changed. Refresh to verify today\u2019s games.", 409);
        const events = validateGrowthEvents(sync.events, wallet, dateKey, now());
        snapshot = await store.recordEvents(hash, origin, ARCADE_ENABLED_GAME_IDS, dateKey, events);
      }
      if (snapshot.wallet !== wallet) throw new ArcadeGrowthError("service-unavailable", "Saved progress identity could not be verified.", 503);
      return json({ ...envelope(snapshot), ...sync ? { sync: { games: sync.games, checkedAt: sync.checkedAt } } : {} });
    } catch (error) {
      const known = error instanceof ArcadeGrowthError ? error : new ArcadeGrowthError("service-unavailable", "Daily Growth is temporarily unavailable. Your saved progress has not been removed.", 503);
      return json({ status: "error", error: known.code, message: known.message }, known.status);
    }
  };
}
var arcade_growth_default = createArcadeGrowthHandler();
var config2 = {
  path: "/api/arcade-growth",
  method: ["GET", "POST"],
  rateLimit: { action: "rate_limit", aggregateBy: ["domain", "ip"], windowSize: 60, windowLimit: 60 }
};
export {
  config2 as config,
  createArcadeGrowthHandler,
  arcade_growth_default as default
};
